"""Finite exact da3a helper/callback bindings; no producer invocation by this reader."""

import ctypes as C
import functools
import hashlib
import importlib.machinery
from importlib.metadata import version
import json
import os
import stat
import sys
import threading
from pathlib import Path
from types import FunctionType

from ac77_source_gate import Gate, HERE, nested, shape


R13 = "Tests.Backup_Recovery.test_windows_metadata_baseline_opt36_opt74"
NEW = "Tests.Backup_Recovery.test_user_data_directory_posture_adapter"
BASELINE = (
    "test_current_config_stamps_preserve_five_fields_order_duplicates_missing_empty",
    "test_current_config_custom_posture_affinity_arguments_and_oserror",
    "test_current_config_scalar_native_schedule",
    "test_current_scalar_and_batch_use_identical_requested_workload",
)
CAUSAL = "test_shipping_helper_uses_one_fresh_batch_after_equal_values_and_retirement"
MEMO = (
    "test_windows_memo_warm_reload_replacement_and_native_permissions",
    "test_windows_memo_refuses_public_ancestor_and_preserves_original_key_timing",
    "test_windows_bracketed_posture_drift",
)

CANDIDATE = ('test_shipping_helper_uses_one_fresh_batch_after_equal_values_and_retirement', 'test_direct_custom_posture_keeps_original_dispatch_before_optional_work', 'test_direct_custom_facade_keeps_scalar_arguments_and_receiver', 'test_actual_batch_return_or_projection_source_change_discards_whole_sample', 'test_custom_scalar_error_and_empty_keep_original_route', 'test_empty_and_missing_descendants_preserve_original_positions_without_optional_empty_work', 'test_nonstock_input_forms_keep_original_scalar_route', 'test_shipping_large_descriptor_uses_original_scalar_only_after_physical_drain', 'test_shipping_helper_propagates_exact_retained_native_close')
RETAINED = "test_shipping_helper_propagates_exact_retained_native_close"


class CandidateReader:
    def __init__(self, root, pytest_config):
        runtime = json.loads((HERE / "runtime-binding.json").read_text())
        assert os.name == "nt" and sys.platform == "win32" and C.sizeof(C.c_void_p) == 8
        assert sys.version_info[:3] == (3, 12, 10)
        assert sys.modules["pytest"].__version__ == runtime["pytest"]
        assert version("textual") == runtime["textual"]
        self.gate = Gate(root, runtime["sources"], pytest_config=pytest_config)
        selectors = json.loads((HERE / "nodeids.json").read_text())
        self.allowed_nodes = set(selectors["candidate31"] + selectors["compatible_r13_5"])
        self.callbacks, self.observers, self.caches = [], [], []
        self.caller = threading.get_ident()
        self.generator_code = None
        self.launcher = None
        self.prepared, self.child_mode = False, False
        self.wrapper_code, self.getter_code = None, None
        self.children, self.resolvers = {}, {}
        self.shipping, self.retained_controls = [], None
        self.helper_code, self.shipping_code = None, None

    def prepare(self, item):
        self.item, self.item_nodeid = item, item.nodeid
        assert item.nodeid in self.allowed_nodes
        assert item.module.__name__ in {R13, NEW}
        assert item.originalname in ((BASELINE[:2] + MEMO) if item.module.__name__ == R13 else CANDIDATE)
        assert item.module.__name__ == NEW or not hasattr(item, "callspec")
        self.child_mode = os.environ.get("TLDW_TEST_PRIVATE_PROFILE_NODE") == item.nodeid
        assert not self.child_mode or item.originalname in MEMO
        if self.child_mode:
            assert sys.modules["__main__"].__spec__.name == "pytest.__main__"
        self.gate.loaded()
        from _pytest.assertion import rewrite
        for module, *_ in self.gate.sources.values():
            loader = module.__loader__
            assert type(loader) in (importlib.machinery.SourceFileLoader, rewrite.AssertionRewritingHook)
            if not module.__name__.startswith("Tests."):
                assert type(loader) is importlib.machinery.SourceFileLoader
        files = sys.modules["tldw_chatbook.Utils.windows_files"]
        storage = sys.modules["tldw_chatbook.Backup_Recovery.storage_admission"]
        platform_files = sys.modules["tldw_chatbook.Utils.platform_files"]
        assert type(storage.os) is files.WindowsOS and storage.os is platform_files.os
        assert platform_files.__all__ == ["fcntl", "os"]
        assert files.C is C and files.contextlib is sys.modules["contextlib"]
        assert files.functools is functools and files._stat is stat and files._os is os
        assert storage.stat is stat and storage._posture.__globals__ is vars(storage)
        for owner, name, capacity in ((files, "_native", 1), (files._Native, "_decoded_security", 128)):
            cache = vars(owner)[name]
            assert type(cache) is functools._lru_cache_wrapper
            body = vars(cache)["__wrapped__"]
            self.gate.pin(body)
            info = cache.cache_info
            assert info.__self__ is cache and info.__name__ == "cache_info"
            assert info().maxsize == capacity
            self.caches.append((owner, name, cache, body))
        for name in ("stat", "stat_for_admission", "stat_many_for_admission", "_stat_handle"):
            bound = vars(storage.os)[name]
            assert bound.__self__ is storage.os and bound.__func__ is vars(files.WindowsOS)[name]
        original = vars(sys.modules[R13]._native_returns)["__wrapped__"]
        self.gate.pin(original)
        self.generator_code = original.__code__
        assert original.__globals__ is vars(sys.modules[R13])
        self.gate.module(sys.modules["contextlib"])
        self.gate.pin(sys.modules["contextlib"].contextmanager)
        self.gate.pin(sys.modules["contextlib"]._GeneratorContextManager.__enter__)
        self.gate.pin(sys.modules["contextlib"]._GeneratorContextManager.__exit__)
        self.stock_resolver = vars(sys.modules["tldw_chatbook.config"])["_resolve_user_data_dir"]
        self._adapter_capture()
        self.helper_code = self.adapter[0].__code__
        self.shipping_code = None
        if item.module.__name__ == NEW:
            shipping = vars(sys.modules[NEW]._shipping_events)["__wrapped__"]
            self.gate.pin(shipping)
            self.shipping_code = shipping.__code__
        if item.originalname in MEMO:
            public = vars(sys.modules[R13])[item.originalname]
            assert vars(public)["_private_profile_test"] is True
            self.wrapper_code = public.__code__
            self.case_body = vars(public)["__wrapped__"]
            self.getter_code = vars(sys.modules["tldw_chatbook.config"].get_user_data_dir)["__wrapped__"].__code__
        if not self.child_mode:
            self._launcher()
        self.prepared = True

    def _captured_function(self, function, values):
        """Pin one of these fixed lexical functions against its actual capture."""
        assert type(function) is FunctionType
        module = sys.modules[function.__globals__["__name__"]]
        assert function.__globals__ is vars(module)
        record = self.gate.source(module)
        code = function.__code__
        assert Path(code.co_filename).resolve() == record[1]
        expected = nested(record[5], code)
        assert expected is not None and shape(expected) == shape(code)
        node = record[7][code.co_qualname]
        expected_defaults = tuple(self.gate.default(value, module, record[6]) for value in node.args.defaults)
        assert len(function.__defaults__ or ()) == len(expected_defaults)
        assert all(type(actual) is type(wanted) and actual == wanted
                   for actual, wanted in zip(function.__defaults__ or (), expected_defaults))
        expected_kw = {arg.arg: self.gate.default(value, module, record[6])
                       for arg, value in zip(node.args.kwonlyargs, node.args.kw_defaults) if value is not None}
        assert (function.__kwdefaults__ or {}).keys() == expected_kw.keys()
        assert all(type(value) is type(expected_kw[name]) and value == expected_kw[name]
                   for name, value in (function.__kwdefaults__ or {}).items())
        assert not getattr(function, "__type_params__", ())
        cells = tuple(zip(code.co_freevars, function.__closure__ or ()))
        assert len(cells) == len(code.co_freevars)
        assert all(cell.cell_contents is values[name] for name, cell in cells)
        self.gate.functions[id(function)] = (
            function, code, function.__globals__, function.__defaults__, function.__kwdefaults__,
            tuple((function.__kwdefaults__ or {}).items()), function.__closure__,
            tuple((cell, cell.cell_contents) for _name, cell in cells), vars(function).get("__wrapped__"),
        )

    def _adapter_capture(self):
        # Read the installed helper; never invoke the deleted factory or checker.
        import inspect
        import pathlib
        from types import MethodType, ModuleType
        config = sys.modules["tldw_chatbook.config"]
        assert config.os is os and config.sys is sys and config.Path is pathlib.Path
        storage = sys.modules["tldw_chatbook.Backup_Recovery.storage_admission"]
        platform = sys.modules["tldw_chatbook.Utils.platform_files"]
        files = sys.modules["tldw_chatbook.Utils.windows_files"]
        helper = vars(config)["_user_data_dir_stamps"]
        assert "_bind_user_data_dir_stamps" not in vars(config)
        assert helper.__code__.co_qualname == "_bind_user_data_dir_stamps.<locals>._user_data_dir_stamps"
        cells = dict(zip(helper.__code__.co_freevars, helper.__closure__ or ()))
        assert set(cells) == {"WindowsPath", "batch", "close_errors", "projection", "source_current"}
        checker = cells["source_current"].cell_contents
        assert checker.__code__.co_qualname == "_bind_user_data_dir_stamps.<locals>.source_current"
        closed = {name: cell.cell_contents for name, cell in zip(checker.__code__.co_freevars, checker.__closure__ or ())}
        facade, owner, native = platform.os, files.WindowsOS, files._Native
        close_error, posture = files._AdmissionMetadataCloseError, storage._posture
        projection = cells["projection"].cell_contents
        assert type(projection) is tuple and len(projection) == 2
        assert projection[0] is stat.S_IFMT and projection[1] is stat.S_IMODE
        close_errors = cells["close_errors"].cell_contents
        assert type(close_errors) is tuple and len(close_errors) == 1 and close_errors[0] is close_error
        assert files.Path is pathlib.Path and files.ntpath is sys.modules["ntpath"]
        modules = closed["modules"]
        assert type(modules) is tuple and len(modules) == 3
        for row, module in zip(modules, (storage, platform, files)):
            assert type(row) is tuple and len(row) == 5
            assert row[0] is module and row[1] is vars(module)
            assert row[2] == module.__file__ and row[3] is module.__spec__ and row[4] == module.__spec__.origin
            self.gate.source(module)
        bindings = (
            (vars(storage), "_posture", posture), (vars(storage), "os", facade), (vars(storage), "stat", stat),
            (vars(platform), "os", facade), (vars(platform), "WindowsOS", owner),
            (vars(files), "WindowsOS", owner), (vars(files), "_Native", native),
            (vars(files), "_AdmissionMetadataCloseError", close_error),
            *((vars(stat), name, value) for name, value in zip(("S_IFMT", "S_IMODE"), projection)),
            *((vars(files), name, vars(files)[name]) for name in (
                "_os", "_stat", "Path", "ntpath", "contextlib", "functools",
                "_parent", "_component", "_native", "_acl_mode", "_AdmissionMetadataHandle")),
            *((vars(owner), name, vars(owner)[name]) for name in (
                "__getattr__", "stat", "_stat_handle", "stat_many_for_admission")),
            *((vars(native), name, vars(native)[name]) for name in (
                "__init__", "_user_sid", "reopen", "open_handle", "info", "ntfs", "security",
                "_decoded_security", "_decode_security", "sid_string", "check", "ntcheck")),
            (vars(close_error), "__init__", close_error.__init__),
            (vars(files._AdmissionMetadataHandle), "__init__", files._AdmissionMetadataHandle.__init__),
        )
        actual_bindings = closed["bindings"]
        assert type(actual_bindings) is tuple and len(actual_bindings) == len(bindings)
        for actual, wanted in zip(actual_bindings, bindings):
            assert type(actual) is tuple and len(actual) == 3
            assert actual[0] is wanted[0] and actual[1] == wanted[1] and actual[2] is wanted[2]
        functions = (
            posture, owner.__getattr__, owner.stat, owner._stat_handle, owner.stat_many_for_admission,
            files._component, files._acl_mode, native.__init__, native._user_sid, native.open_handle,
            native.info, native.ntfs, native.security, native._decode_security, native.sid_string,
            native.check, native.ntcheck, close_error.__init__, files._AdmissionMetadataHandle.__init__,
            files._parent, files._parent.__wrapped__, files._native.__wrapped__, native.reopen,
            native.reopen.__wrapped__, native._decoded_security.__wrapped__,
        )
        records = closed["records"]
        assert type(records) is tuple and len(records) == len(functions) == 25
        for record, function in zip(records, functions):
            self.gate.pin(function)
            assert type(record) is tuple and len(record) == 9
            fn, code, namespace, defaults, kw, items, closure, saved_cells, body = record
            assert fn is function and code is function.__code__ and namespace is function.__globals__
            assert defaults is function.__defaults__ and kw is function.__kwdefaults__
            assert type(items) is tuple and len(items) == len(kw or {})
            assert all(name == actual_name and value is actual_value
                       for (name, value), (actual_name, actual_value) in zip(items, (kw or {}).items()))
            assert closure is function.__closure__ and type(saved_cells) is tuple
            assert len(saved_cells) == len(closure or ())
            assert all(saved is actual and value is actual.cell_contents
                       for (saved, value), actual in zip(saved_cells, closure or ()))
            assert body is vars(function).get("__wrapped__")
        wrapped = closed["wrapped"]
        wrappers = (files._parent, files._native, native.reopen, native._decoded_security)
        assert type(wrapped) is tuple and len(wrapped) == 4
        assert all(type(row) is tuple and len(row) == 2 and row[0] is wrapper and row[1] is vars(wrapper)["__wrapped__"]
                   for row, wrapper in zip(wrapped, wrappers))
        lookup = closed["lookup"]
        expected_lookup = tuple((cls, name, inspect.getattr_static(cls, name, None))
                                for cls in (owner, native) for name in ("__getattribute__", "__getattr__", "__dict__"))
        assert type(lookup) is tuple and len(lookup) == len(expected_lookup)
        assert all(type(row) is tuple and len(row) == 3 and row[0] is cls and row[1] == name and row[2] is value
                   for row, (cls, name, value) in zip(lookup, expected_lookup))
        cached = closed["cached"]
        assert type(cached) is tuple and len(cached) == 3
        for row, name in zip(cached, ("stat", "_stat_handle", "stat_many_for_admission")):
            assert type(row) is tuple and len(row) == 3 and row[0] == name
            bound, function = row[1:]
            assert type(bound) is MethodType and vars(facade)[name] is bound
            assert bound.__self__ is facade and bound.__func__ is function is vars(owner)[name]
        assert cells["batch"].cell_contents is cached[-1][1]
        expected_closed = dict(FunctionType=FunctionType, MethodType=MethodType, ModuleType=ModuleType,
            bindings=actual_bindings, cached=cached, facade=facade, inspect=inspect, lookup=lookup,
            modules=modules, native=native, original_posture=posture, owner=owner,
            records=records, stat=stat, storage=storage, wrapped=wrapped)
        assert set(closed) == set(expected_closed)
        assert all(closed[name] is value for name, value in expected_closed.items())
        self._captured_function(checker, expected_closed)
        self._captured_function(helper, dict(WindowsPath=pathlib.WindowsPath, batch=cached[-1][1],
            close_errors=close_errors, projection=projection, source_current=checker))
        self.gate.slots.append((config, "_user_data_dir_stamps", helper))
        self.adapter = (helper, checker, records, actual_bindings, cached, modules)

    def _test_locals(self, frame):
        parent = frame.f_back
        while parent is not None and parent.f_code.co_name != self.item_name:
            parent = parent.f_back
        assert parent is not None and parent.f_globals is vars(sys.modules[NEW])
        local = parent.f_locals
        # These are the only direct customization/retirement controls in this TEST.
        for name in ("custom", "changed_stat", "changed_handle", "class_stat", "changed", "mutate", "restore",
                     "refused", "observed_close", "record_open", "record_scalar", "delegated_posture"):
            function = local.get(name)
            if function is not None:
                self._captured_function(function, local)
        cls = local.get("Callback")
        if cls is not None:
            assert type(cls) is type and cls.__module__ == NEW
            self._captured_function(vars(cls)["__call__"], local)
        pathlike = local.get("PathLike")
        if pathlike is not None:
            assert type(pathlike) is type and pathlike.__module__ == NEW
            self._captured_function(vars(pathlike)["__fspath__"], local)
        if self.item_name == RETAINED:
            assert local["scalar"] is self.adapter[0]
            assert local["opener"] is sys.modules["tldw_chatbook.Utils.windows_files"]._Native.open_handle
            files, native = sys.modules["tldw_chatbook.Utils.windows_files"], local["native"]
            for label, name, arguments in (
                ("get_flags", "GetHandleInformation", [files._HANDLE, C.POINTER(files._U32)]),
                ("set_flags", "SetHandleInformation", [files._HANDLE, files._U32, files._U32]),
            ):
                function = local[label]
                assert function is vars(native.kernel)[name]
                assert type(function) is vars(native.kernel)["_FuncPtr"] and function.__name__ == name
                assert function.argtypes == arguments and function.restype is files._I32
                assert function._flags_ & C._FUNCFLAG_USE_LASTERROR
            self.retained_controls = parent
        return local

    def observe_shipping_yield(self, frame, value):
        assert frame.f_code is self.shipping_code and frame.f_globals is vars(sys.modules[NEW])
        assert frame.f_globals["C"] is C and frame.f_globals["stat"] is stat
        assert frame.f_globals["sys"] is sys and frame.f_globals["threading"] is threading
        local = frame.f_locals
        assert threading.get_ident() == self.caller == local["caller"]
        assert local["helper"] is self.adapter[0] and local["checker"] is self.adapter[1]
        assert local["win"] is sys.modules["tldw_chatbook.Backup_Recovery.storage_admission"].os
        for name in ("drained", "start", "returned", "unwound", "projected"):
            self._captured_function(local[name], local)
        self._test_locals(frame)
        assert value is local["state"]
        monitor, slot = sys.monitoring, local["slot"]
        assert monitor.get_tool(slot) == "shipping-posture-boundary"
        assert monitor.get_events(slot) == monitor.events.PY_UNWIND
        for code in local["codes"]:
            expected = monitor.events.PY_START | (monitor.events.PY_RETURN if code is local["batch_code"] else 0)
            assert monitor.get_local_events(slot, code) == expected
        if local["restore"] is not None:
            assert monitor.get_local_events(slot, local["checker_code"]) == monitor.events.PY_RETURN
            assert local["restore"] is self._test_locals(frame)["restore"]
        if local["projection"]:
            assert sys.getprofile() is local["projected"]
        self.shipping.append(local)

    def observe_helper(self, frame):
        assert frame.f_code is self.adapter[0].__code__
        assert frame.f_globals is vars(sys.modules["tldw_chatbook.config"])
        assert threading.get_ident() == self.caller
        storage = sys.modules["tldw_chatbook.Backup_Recovery.storage_admission"]
        posture = vars(storage)["_posture"]
        if posture is self.adapter[2][0][0]:
            return
        parent = frame.f_back
        while parent is not None and parent.f_code.co_name != self.item_name:
            parent = parent.f_back
        assert parent is not None
        if parent.f_globals is vars(sys.modules[R13]):
            assert self.item_name == BASELINE[1]
            assert any(posture is parent.f_locals.get(name) for name in ("posture", "refused"))
            self._callback(posture, parent.f_locals)
        else:
            assert parent.f_globals is vars(sys.modules[NEW])
            if type(posture) is FunctionType:
                assert any(posture is parent.f_locals.get(name) for name in ("custom", "refused", "delegated_posture"))
                self._captured_function(posture, parent.f_locals)
            else:
                cls = parent.f_locals["Callback"]
                assert type(posture) is cls and cls.__module__ == NEW
                self._captured_function(vars(cls)["__call__"], parent.f_locals)



    def observe_wrapper(self, frame):
        assert frame.f_code is self.wrapper_code
        assert frame.f_globals is vars(sys.modules["Tests.private_profile"])
        assert threading.get_ident() == self.caller
        local = frame.f_locals
        assert local["request"].node.nodeid == self.item_nodeid
        assert local["function"] is self.case_body
        if self.child_mode:
            assert "process" not in local
            return
        process = local.get("process")
        if process is None:
            return
        assert type(process) is sys.modules["asyncio.subprocess"].Process
        assert type(process.pid) is int and process.pid > 0 and process.pid != os.getpid()
        self.children[process.pid] = (process, local["report"], local["log"], local["work"], local["profile"], local["timeout"])

    def observe_resolver(self, frame):
        assert frame.f_code is self.getter_code
        assert frame.f_globals is vars(sys.modules["tldw_chatbook.config"])
        function = frame.f_globals["_resolve_user_data_dir"]
        if function is self.stock_resolver:
            return
        assert self.child_mode and type(function) is FunctionType
        allowed = {"_warm.<locals>.resolve", MEMO[1] + ".<locals>.resolve", MEMO[2] + ".<locals>.changed"}
        assert function.__code__.co_qualname in allowed
        if self.resolvers.get(id(function)) is function:
            records = [record for record in self.callbacks if record[0] is function]
            assert len(records) == 1
            _function, code, namespace, closure, cells = records[0]
            assert function.__code__ is code and function.__globals__ is namespace
            assert function.__defaults__ is None and function.__kwdefaults__ is None
            assert function.__closure__ is closure
            assert all(cell.cell_contents is value for cell, value in cells)
            return
        parent = frame.f_back
        while parent is not None and all(parent.f_locals.get(name) is not function for name in ("resolve", "changed")):
            parent = parent.f_back
        assert parent is not None and parent.f_globals is vars(sys.modules[R13])
        self._callback(function, parent.f_locals)
        original = parent.f_locals["original"]
        assert original is self.stock_resolver or id(original) in self.resolvers
        self.resolvers[id(function)] = function

    def _launcher(self):
        # python -m naturally executes this actual installed module as __main__.
        # Keep that truthful relation; do not add an import alias or rerun it.
        main = sys.modules["__main__"]
        row = self.gate.rows["Tests.windows_private_fixture_runner"]
        path = self.gate.root / row["logical_path"]
        data = (HERE / row["snapshot_path"]).read_bytes()
        assert Path(main.__file__).resolve() == path and path.read_bytes() == data
        assert hashlib.sha256(data).hexdigest() == row["sha256"]
        assert main.__spec__.name == "Tests.windows_private_fixture_runner"
        assert Path(main.__spec__.origin).resolve() == path
        assert type(main.__loader__) is importlib.machinery.SourceFileLoader
        compiled = compile(data, str(path), "exec", dont_inherit=True)
        wrapper, entry = vars(main)["user_fixture_default_owner"], vars(main)["main"]
        body = vars(wrapper)["__wrapped__"]
        for function in (entry, body):
            assert type(function) is FunctionType and function.__globals__ is vars(main)
            expected = nested(compiled, function.__code__)
            assert expected is not None and shape(expected) == shape(function.__code__)
            assert function.__defaults__ is None and function.__kwdefaults__ is None and function.__closure__ is None
        contextlib = sys.modules["contextlib"]
        expected_wrapper = nested(self.gate.source(contextlib)[5], wrapper.__code__)
        assert expected_wrapper is not None and shape(expected_wrapper) == shape(wrapper.__code__)
        assert wrapper.__globals__ is vars(contextlib) and wrapper.__code__.co_freevars == ("func",)
        assert wrapper.__defaults__ is None and wrapper.__kwdefaults__ is None
        assert len(wrapper.__closure__) == 1
        assert wrapper.__closure__[0].cell_contents is body and vars(wrapper)["__wrapped__"] is body
        frame = sys._getframe()
        while frame is not None and frame.f_code is not entry.__code__:
            frame = frame.f_back
        assert frame is not None and frame.f_globals is vars(main)
        self.launcher = (main, path, data, wrapper, body, entry, wrapper.__code__, body.__code__, entry.__code__)

    def _callback(self, function, local):
        assert type(function) is FunctionType and function.__globals__ is vars(sys.modules[R13])
        assert function.__defaults__ is None and function.__kwdefaults__ is None
        compiled = self.gate.source(sys.modules[R13])[5]
        expected = nested(compiled, function.__code__)
        assert expected is not None and shape(expected) == shape(function.__code__)
        cells = tuple(zip(function.__code__.co_freevars, function.__closure__ or ()))
        assert all(cell.cell_contents is local[name] for name, cell in cells)
        self.callbacks.append((function, function.__code__, function.__globals__, function.__closure__,
                               tuple((cell, cell.cell_contents) for _name, cell in cells)))

    def observe_yield(self, frame, value):
        assert frame.f_code is self.generator_code and frame.f_globals is vars(sys.modules[R13])
        local, files = frame.f_locals, sys.modules["tldw_chatbook.Utils.windows_files"]
        assert threading.get_ident() == self.caller == local["caller"]
        win, native = local["win"], local["native"]
        assert type(win) is files.WindowsOS and type(native) is files._Native
        assert win is sys.modules["tldw_chatbook.Backup_Recovery.storage_admission"].os
        assert native.kernel is local["kernel"] and native.nt is local["nt"]
        assert type(native.user_sid) is str and native.user_sid == local["token_user_sid"]
        for name in ("opened", "closed", "started", "returned", "frame_for", "qualified_frame", "source_current"):
            self._callback(local[name], local)
        assert vars(native.nt)["NtCreateFile"] is local["opened"]
        assert vars(native.kernel)["CloseHandle"] is local["closed"]
        real_close = local["real_close"]
        if self.item_name == RETAINED:
            control = self._test_locals(frame)
            assert real_close is control["observed_close"]
            assert control["kernel"] is native.kernel
            real_close = control["real_close"]
            assert type(real_close) is vars(native.kernel)["_FuncPtr"]
            assert vars(control["observed_close"])["argtypes"] is real_close.argtypes
            assert vars(control["observed_close"])["restype"] is real_close.restype
        self._native_abi(files, native, local["real_open"], real_close)
        monitor, slot = sys.monitoring, local["slot"]
        assert monitor.get_tool(slot) == "native-baseline-returns"
        assert monitor.get_events(slot) == 0
        for code, label in local["names"].items():
            assert monitor.get_local_events(slot, code) == monitor.events.PY_START | monitor.events.PY_RETURN
            assert label in {"open", "info", "ntfs", "security", "stat", "batch", "component"}
        assert type(value) is tuple and len(value) == 7
        expected = tuple(local[name] for name in ("counts", "ancestry", "births", "closes", "errors", "excluded", "security_observations"))
        assert all(a is b for a, b in zip(value, expected))
        self.observers.append((local, value, native, win))

    def _native_abi(self, files, native, real_open, real_close):
        assert native.kernel._name == "kernel32" and native.nt._name == "ntdll" and native.advapi._name == "advapi32"
        assert all(type(dll) is C.WinDLL for dll in (native.kernel, native.nt, native.advapi))
        assert (files._U32, files._I32, files._U16, files._P, files._HANDLE) == (C.c_uint32, C.c_int32, C.c_uint16, C.c_void_p, C.c_void_p)
        U, I, P, H = files._U32, files._I32, files._P, files._HANDLE
        fields = (
            (files._UnicodeString, [("Length", files._U16), ("MaximumLength", files._U16), ("Buffer", P)], 16),
            (files._ObjectAttributes, [("Length", U), ("RootDirectory", H), ("ObjectName", C.POINTER(files._UnicodeString)), ("Attributes", U), ("SecurityDescriptor", P), ("SecurityQualityOfService", P)], 48),
            (files._IOStatus, [("Status", P), ("Information", C.c_size_t)], 16),
            (files._FileInfo, [("attributes", U), ("created", U * 2), ("accessed", U * 2), ("written", U * 2), ("volume", U), ("size_high", U), ("size_low", U), ("links", U), ("index_high", U), ("index_low", U)], 52),
            (files._BasicInfo, [("created", C.c_int64), ("accessed", C.c_int64), ("written", C.c_int64), ("changed", C.c_int64), ("attributes", U)], 40),
        )
        for cls, expected, size in fields:
            assert cls.__bases__ == (C.Structure,) and cls.__module__ == files.__name__
            assert cls._fields_ == expected and C.sizeof(cls) == size and not vars(cls).get("_pack_")
        signatures = (
            (native.nt, "NtCreateFile", real_open, [C.POINTER(H), U, C.POINTER(files._ObjectAttributes), C.POINTER(files._IOStatus), P, U, U, U, U, P, U], I),
            (native.kernel, "CloseHandle", real_close, [H], I),
            (native.kernel, "GetFileInformationByHandle", None, [H, C.POINTER(files._FileInfo)], I),
            (native.kernel, "GetFileType", None, [H], U),
            (native.kernel, "GetVolumeInformationByHandleW", None, [H, P, U, P, P, P, P, U], I),
            (native.nt, "NtQueryVolumeInformationFile", None, [H, C.POINTER(files._IOStatus), P, U, U], I),
            (native.kernel, "GetFileInformationByHandleEx", None, [H, I, P, U], I),
            (native.kernel, "LocalFree", None, [P], P),
            (native.advapi, "GetSecurityInfo", None, [H, I, U, C.POINTER(P), P, C.POINTER(P), P, C.POINTER(P)], U),
            (native.advapi, "GetSecurityDescriptorLength", None, [P], U),
            (native.advapi, "GetSecurityDescriptorOwner", None, [P, C.POINTER(P), C.POINTER(I)], I),
            (native.advapi, "GetSecurityDescriptorDacl", None, [P, C.POINTER(I), C.POINTER(P), C.POINTER(I)], I),
            (native.advapi, "GetAce", None, [P, U, C.POINTER(P)], I),
            (native.advapi, "ConvertSidToStringSidW", None, [P, C.POINTER(P)], I),
            (native.nt, "RtlNtStatusToDosError", None, [I], U),
            (native.kernel, "GetCurrentProcess", None, [], H),
            (native.advapi, "OpenProcessToken", None, [H, U, C.POINTER(H)], I),
            (native.advapi, "GetTokenInformation", None, [H, I, P, U, C.POINTER(U)], I),
            (native.advapi, "ConvertStringSecurityDescriptorToSecurityDescriptorW", None, [C.c_wchar_p, U, C.POINTER(P), P], I),
            (native.advapi, "SetSecurityInfo", None, [H, I, U, P, P, P, P], U),
        )
        for dll, name, captured, arguments, result in signatures:
            function = captured if captured is not None else vars(dll)[name]
            assert type(function) is vars(dll)["_FuncPtr"] and function.__name__ == name
            assert function.argtypes == arguments and function.restype is result
            assert function._flags_ & C._FUNCFLAG_USE_LASTERROR

    def finish(self):
        self.gate.loaded()
        self.gate.unchanged()
        if self.launcher is not None:
            main, path, data, wrapper, body, entry, wrapper_code, body_code, entry_code = self.launcher
            assert path.read_bytes() == data and vars(main)["main"] is entry
            assert vars(main)["user_fixture_default_owner"] is wrapper
            assert wrapper.__code__ is wrapper_code and body.__code__ is body_code and entry.__code__ is entry_code
            assert wrapper.__closure__[0].cell_contents is body and vars(wrapper)["__wrapped__"] is body
            assert wrapper.__defaults__ is None and wrapper.__kwdefaults__ is None
            assert body.__globals__ is vars(main) and entry.__globals__ is vars(main)
            assert body.__defaults__ is None and entry.__defaults__ is None
            assert body.__kwdefaults__ is None and entry.__kwdefaults__ is None
        for owner, name, cache, body in self.caches:
            assert vars(owner)[name] is cache and vars(cache)["__wrapped__"] is body
        for function, code, namespace, closure, cells in self.callbacks:
            assert function.__code__ is code and function.__globals__ is namespace
            assert function.__defaults__ is None and function.__kwdefaults__ is None
            assert function.__closure__ is closure and all(cell.cell_contents is value for cell, value in cells)
        parameter = self.item.callspec.params if hasattr(self.item, "callspec") else {}
        expected = 0
        if self.item_name in {CAUSAL, "test_actual_batch_return_or_projection_source_change_discards_whole_sample",
                              "test_shipping_large_descriptor_uses_original_scalar_only_after_physical_drain", RETAINED}:
            expected = 1
        elif self.item_name == "test_direct_custom_posture_keeps_original_dispatch_before_optional_work":
            expected = int(parameter["change"] not in {"function", "callable"})
        elif self.item_name == "test_empty_and_missing_descendants_preserve_original_positions_without_optional_empty_work":
            expected = 2
        assert len(self.observers) == expected
        for local in self.shipping:
            assert not local["state"]["errors"]
            assert sys.monitoring.get_tool(local["slot"]) is None
            if local["projection"]:
                assert sys.getprofile() is local["previous"]
        if self.item_name in MEMO:
            if self.child_mode:
                assert not self.children and self.resolvers
            else:
                assert len(self.children) == 1
                assert all(process.returncode is not None for process, *_rest in self.children.values())
        for index, (local, _value, native, _win) in enumerate(self.observers):
            assert not local["excluded"]
            empty = self.item_name == "test_empty_and_missing_descendants_preserve_original_positions_without_optional_empty_work" and index == 0
            if self.item_name == RETAINED:
                assert self.retained_controls is not None
                control = self.retained_controls.f_locals
                assert len(control["selected"]) == 1
                record = control["selected"][0]
                assert record.native is native and control["calls"] == [record.handle]
                retained = control["selected_births"]
                assert len(retained) == 1 and local["errors"] == ["native-birth-not-retired-once", "post-drain-handle-still-valid"]
                assert any(retained[0] is row for row in local["births"])
                assert retained[0]["handle"] == record.handle
                assert set(local["current"]) == {record.handle}
                assert local["current"][record.handle] is retained[0]
                assert all(row is retained[0] or row["closes"] == [(True, 0)] for row in local["births"])
                assert retained[0]["closes"] == ([] if parameter["outcome"] == "raising" else [(False, record.close_error)])
                properties = dict(self.item.user_properties)
                cleanup = json.loads(properties["retained_fixture_finally_retired"])
                assert cleanup["continuous_handle"] == record.handle
                assert tuple(cleanup["continuous_identity"]) == record.identity
                assert cleanup["fixture_unprotected_then_native_closed"] and cleanup["native_invalid_error"] == 6
                assert not control["monitor_cleanup_errors"] and sys.monitoring.get_tool(control["slot"]) is None
                assert native.kernel.CloseHandle is control["real_close"]
            else:
                assert not local["current"]
                deliberate_batch_metadata = (
                    self.item_name == "test_actual_batch_return_or_projection_source_change_discards_whole_sample"
                    and parameter["change"] in {"batch_body", "batch_defaults"})
                if deliberate_batch_metadata:
                    assert len(self.shipping) == 1
                    state = self.shipping[0]["state"]
                    assert state["changed"] and state["drains"]
                    assert state["false_checkpoints"] == ["batch-return"] and state["restored_at_false_return"]
                    assert local["errors"] in ([], ["source-changed"])
                else:
                    assert not local["errors"]
                assert bool(local["births"]) is not empty
                assert len(local["births"]) == len(local["closes"])
                assert {id(row) for row in local["births"]} == {id(row) for row in local["closes"]}
                assert all(row["closes"] == [(True, 0)] for row in local["births"])
                assert native.kernel.CloseHandle is local["real_close"]
            assert native.nt.NtCreateFile is local["real_open"]
            assert sys.monitoring.get_tool(local["slot"]) is None

    def receipt(self):
        return {"gate": self.gate.receipt(), "caller": self.caller,
                "scope": "31 exact candidate native controls or five compatible R13 parent/three memo children; each native ledger retains its own empty/positive/retained scope",
                "adapter_capture": {"factory_present_at_runtime": False, "helper_qualname": self.adapter[0].__code__.co_qualname,
                    "checker_qualname": self.adapter[1].__code__.co_qualname, "function_records": len(self.adapter[2]),
                    "fixed_bindings": len(self.adapter[3]), "cached_receivers": len(self.adapter[4]), "canonical_modules": len(self.adapter[5]),
                    "independently_compiled_actual_closures": True, "reader_invoked_factory_checker_or_producer": False},
                "shipping_observers": [{"starts": dict(local["state"]["starts"]), "returns": local["state"]["returns"],
                    "changed": local["state"]["changed"], "drains": local["state"]["drains"],
                    "false_checkpoints": local["state"]["false_checkpoints"],
                    "restored_at_false_return": local["state"]["restored_at_false_return"],
                    "errors": local["state"]["errors"], "monitor_retired": sys.monitoring.get_tool(local["slot"]) is None}
                    for local in self.shipping],
                "private_profile_child": self.child_mode,
                "memo_resolver_callbacks": [{"code_qualname": function.__code__.co_qualname,
                    "definer": function.__globals__["__name__"], "source_shape_and_actual_lexical_cells_equal": True}
                    for function in self.resolvers.values()],
                "private_profile_children": [{"pid": process.pid, "returncode": process.returncode,
                    "xml": str(report), "log": str(log), "work": str(work), "profile": str(profile), "original_timeout": timeout,
                    "ownership": "Actual original asyncio Process observed in original private_profile wrapper; unchanged helper awaits/kills+awaits. No independent poll/ECHILD receipt."}
                    for process, report, log, work, profile, timeout in self.children.values()],
                "launcher": {"natural_module_name": "__main__", "spec_name": "Tests.windows_private_fixture_runner",
                    "path": str(self.launcher[1]), "sha256": hashlib.sha256(self.launcher[2]).hexdigest(),
                    "actual_main_stack_observed": True,
                    "limit": "Original owner restoration checks execute after pytest returns; process exit must be archived. No captured owner SID/token-handle receipt."} if self.launcher is not None else {
                        "natural_module_name": "__main__", "spec_name": "pytest.__main__",
                        "scope": "Original private_profile child argv, actual PID and exact child marker; fixture launcher not rerun or aliased in child."},
                "native_observers": [{"births": [dict(ordinal=i, **row) for i, row in enumerate(local["births"])],
                    "close_birth_ordinals": [next(i for i, birth in enumerate(local["births"]) if birth is row) for row in local["closes"]],
                    "counts": dict(local["counts"]), "ancestry": dict(local["ancestry"]),
                    "errors": local["errors"], "excluded": local["excluded"],
                    "security": local["security_observations"], "pending_births": len(local["current"]),
                    "actual_monitor_retired": sys.monitoring.get_tool(local["slot"]) is None}
                    for local, _value, _native, _win in self.observers]}
