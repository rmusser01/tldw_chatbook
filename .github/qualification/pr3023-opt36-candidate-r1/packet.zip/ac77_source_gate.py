"""UNEXECUTED original AC77 TEST reader: reused finite definer/compiler checks."""

import ast
import hashlib
import inspect
import json
import struct
import sys
from pathlib import Path
from types import CodeType, FunctionType, ModuleType


HERE = Path(__file__).resolve().parent


def _constant_shape(value):
    kind = type(value)
    if kind is CodeType:
        return kind, shape(value)
    if kind is tuple:
        return kind, tuple(_constant_shape(item) for item in value)
    if kind is frozenset:
        return kind, frozenset(_constant_shape(item) for item in value)
    if kind is float:
        return kind, struct.pack("!d", value)
    if kind is complex:
        return kind, struct.pack("!dd", value.real, value.imag)
    if kind in (type(None), type(Ellipsis), bool, int, str, bytes):
        return kind, value
    raise AssertionError("unsupported compiled constant type")


def shape(code):
    # Exact constant types/bits, recursively; no marshal or product execution.
    return (
        code.co_name, code.co_qualname, code.co_firstlineno, code.co_code,
        code.co_exceptiontable, code.co_stacksize, code.co_flags,
        code.co_argcount, code.co_posonlyargcount, code.co_kwonlyargcount,
        code.co_names, code.co_varnames, code.co_freevars, code.co_cellvars,
        tuple(_constant_shape(x) for x in code.co_consts),
    )


def nested(code, actual):
    if (code.co_qualname, code.co_firstlineno) == (
        actual.co_qualname, actual.co_firstlineno
    ):
        return code
    for child in code.co_consts:
        if type(child) is CodeType:
            found = nested(child, actual)
            if found is not None:
                return found
    return None


def node_index(tree):
    result = {}

    def walk(body, prefix=""):
        for node in body:
            if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef, ast.ClassDef)):
                name = prefix + node.name
                result[name] = node
                walk(node.body, name + ("." if isinstance(node, ast.ClassDef) else ".<locals>."))
            else:
                # Functions declared under if/try retain the lexical owner.
                for field in ("body", "orelse", "finalbody"):
                    children = getattr(node, field, None)
                    if isinstance(children, list):
                        walk(children, prefix)
                for handler in getattr(node, "handlers", ()):
                    walk(handler.body, prefix)

    walk(tree.body)
    return result


class Gate:
    def __init__(self, installed_root, runtime_binding, *, pytest_config=None):
        self.root = Path(installed_root).resolve()
        self.pytest_config = pytest_config
        self.compilers = {}
        self.fixture_binding = None
        document = json.loads((HERE / "expected-sources.json").read_text())
        self.rows = {row["module"]: row for row in document["sources"]}
        # Runtime binding is separately frozen/reviewed, never learned from an
        # arbitrary actual function passed to pin(). Required for contextlib.
        for row in runtime_binding:
            if row["module"] not in {"contextlib", "_pytest.fixtures", "_pytest.assertion.rewrite"} or row["module"] in self.rows:
                raise AssertionError("unexpected runtime source")
            self.rows[row["module"]] = row
        self.aliases = document["aliases"]
        self.sources, self.functions, self.slots, self.classes = {}, {}, [], []

    def source(self, module):
        assert type(module) is ModuleType
        name = module.__name__
        assert name in self.rows, ("unbound definer", name)
        row = self.rows[name]
        path = Path(module.__file__).resolve()
        expected_path = (
            Path(row["runtime_path"]).resolve()
            if "runtime_path" in row else self.root / row["logical_path"]
        )
        assert path == expected_path
        assert module.__spec__.name == name
        assert Path(module.__spec__.origin).resolve() == path
        assert module.__loader__ is module.__spec__.loader
        data = (HERE / row["snapshot_path"]).read_bytes()
        assert hashlib.sha256(data).hexdigest() == row["sha256"]
        assert path.read_bytes() == data
        key = id(module)
        if key not in self.sources:
            tree = ast.parse(data, filename=str(path))
            compiled_tree = ast.parse(data, filename=str(path))
            compiler = "raw installed module compiler"
            if name.startswith("Tests.") or name == "test_task37_original_hook_pin":
                from _pytest.assertion import rewrite
                if type(module.__loader__) is rewrite.AssertionRewritingHook:
                    # Only actual parent TEST imports use pytest's compiler.
                    # Plain child imports retain their original raw route.
                    assert self.pytest_config is not None
                    assert module.__loader__.config is self.pytest_config
                    assert self.pytest_config.getoption("assertmode") == "rewrite"
                    self.source(rewrite)
                    self.pin(rewrite.rewrite_asserts)
                    rewrite.rewrite_asserts(compiled_tree, data, str(path), self.pytest_config)
                    compiler = "actual pytest assertion compiler and same loader config"
            self.compilers[name] = compiler
            self.sources[key] = (
                module, path, module.__spec__, module.__loader__, data,
                compile(compiled_tree, str(path), "exec", dont_inherit=True),
                tree, node_index(tree),
            )
        return self.sources[key]

    def default(self, node, module, tree):
        try:
            return ast.literal_eval(node)
        except (ValueError, TypeError):
            pass
        # Only named defaults actually used by these fixed slots. Resolve a
        # frozen literal assignment, or the raw module's unique sentinel.
        assert isinstance(node, ast.Name), ("unsupported default", ast.dump(node))
        assignments = [n.value for n in tree.body if isinstance(n, ast.Assign)
                       and any(isinstance(t, ast.Name) and t.id == node.id for t in n.targets)]
        assert len(assignments) == 1, ("ambiguous default", node.id)
        value = assignments[0]
        if (module.__name__, node.id) in {
            ("tldw_chatbook.Backup_Recovery.raw_participants", "_UNCHECKED"),
            ("tldw_chatbook.config", "_CLI_SETTING_DEFAULT_UNSET"),
        }:
            assert ast.dump(value) == ast.dump(ast.parse("object()", mode="eval").body)
            actual = vars(module)[node.id]
            assert type(actual) is object
            return actual
        return ast.literal_eval(value)

    def pin(self, function):
        assert type(function) is FunctionType
        if id(function) in self.functions:
            return
        module = sys.modules.get(function.__globals__["__name__"])
        assert type(module) is ModuleType and function.__globals__ is vars(module)
        record = self.source(module)
        _, path, _, _, _, compiled, tree, nodes = record
        code = function.__code__
        assert Path(code.co_filename).resolve() == path
        expected = nested(compiled, code)
        assert expected is not None and shape(expected) == shape(code)
        fixture_callback = self.fixture_binding is not None and function is self.fixture_binding[1]
        if fixture_callback:
            assert module.__name__ == "Tests.Backup_Recovery.test_participant_lifetimes"
            assert code.co_qualname == "local_root.<locals>.<lambda>"
            matches = [n for n in ast.walk(tree) if isinstance(n, ast.Lambda) and n.lineno == code.co_firstlineno]
            assert len(matches) == 1 and ast.dump(matches[0].body) == ast.dump(ast.Name(id="root", ctx=ast.Load()))
            node = matches[0]
        else:
            node = nodes[code.co_qualname]
            assert isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef))
        expected_defaults = tuple(self.default(n, module, tree) for n in node.args.defaults)
        actual_defaults = function.__defaults__ or ()
        assert len(actual_defaults) == len(expected_defaults)
        for actual, expected_value in zip(actual_defaults, expected_defaults):
            assert type(actual) is type(expected_value) and actual == expected_value
        expected_kw = {arg.arg: self.default(value, module, tree)
                       for arg, value in zip(node.args.kwonlyargs, node.args.kw_defaults)
                       if value is not None}
        actual_kw = function.__kwdefaults__ or {}
        assert actual_kw.keys() == expected_kw.keys()
        for name, value in actual_kw.items():
            assert type(value) is type(expected_kw[name]) and value == expected_kw[name]
        assert not getattr(function, "__type_params__", ())
        cells = tuple((cell, cell.cell_contents) for cell in function.__closure__ or ())
        self.functions[id(function)] = (
            function, code, function.__globals__, function.__defaults__,
            function.__kwdefaults__, tuple(actual_kw.items()), function.__closure__,
            cells, vars(function).get("__wrapped__"),
        )
        closed = dict(zip(code.co_freevars, (value for _, value in cells)))
        for name, value in closed.items():
            if type(value) is FunctionType:
                self.pin(value)
                # Every selected decorator transports its actual body by one
                # of these named cells; arbitrary extra callback cells refuse.
                assert name in {"func", "function", "guarded", "wrapped"}
            elif name == "writing":
                assert type(value) is bool and "function" in closed
                assert value is (closed["function"].__name__ != "_load")
            elif fixture_callback and name == "root":
                assert value is self.fixture_binding[2] and code.co_freevars == ("root",)
            elif name == "__class__":
                assert isinstance(value, type) and vars(module).get(value.__name__) is value
            else:
                raise AssertionError(("unsupported closure", code.co_qualname, name))
        wrapped = vars(function).get("__wrapped__")
        if wrapped is not None:
            assert type(wrapped) is FunctionType
            assert any(value is wrapped for value in closed.values())
            self.pin(wrapped)
        if "wrapped" in closed and code.co_name == "wrapped":
            assert closed["wrapped"] is function
        if "function" in closed and wrapped is not None:
            assert closed["function"] is wrapped
        if "guarded" in closed:
            guard_body = vars(closed["guarded"]).get("__wrapped__")
            assert type(guard_body) is FunctionType
            guard_cells = dict(zip(guard_body.__code__.co_freevars,
                                   (c.cell_contents for c in guard_body.__closure__ or ())))
            assert guard_cells["function"] is wrapped
            assert guard_cells["wrapped"] is function

    def module(self, module):
        self.source(module)
        for dotted in self.rows[module.__name__].get("slots", ()):
            if dotted.endswith(".__wrapped__"):
                # pytest invokes this original fixture body, not its public
                # direct-call error wrapper. Keep both original body links.
                name = dotted.removesuffix(".__wrapped__")
                public = vars(module)[name]
                body = vars(public)["__wrapped__"]
                from _pytest import fixtures
                assert type(public) is fixtures.FixtureFunctionDefinition
                assert vars(public)["_fixture_function"] is body
                fixture_module = self.module(fixtures)
                fixture_class = vars(fixture_module)["FixtureFunctionDefinition"]
                self.classes.append((fixture_module, "FixtureFunctionDefinition", fixture_class, fixture_class.__bases__))
                getter = vars(fixture_class)["_get_wrapped_function"]
                self.slots.append((fixture_class, "_get_wrapped_function", getter))
                self.pin(getter)
                assert getter(public) is body
                self.slots.extend(((module, name, public), (public, "__wrapped__", body),
                                   (public, "_fixture_function", body)))
                self.pin(body)
                continue
            parts = dotted.split(".")
            owner = module
            if len(parts) == 2:
                owner = vars(module)[parts[0]]
                assert isinstance(owner, type)
                assert owner.__module__ == module.__name__
                assert owner.__qualname__ == parts[0]
                self.classes.append((module, parts[0], owner, owner.__bases__))
            assert len(parts) in (1, 2)
            slot = parts[-1]
            descriptor = vars(owner)[slot]  # no inherited or dynamic lookup
            if (module.__name__, slot) == ("tldw_chatbook.Backup_Recovery.bootstrap", "default_bootstrap_root") and self.fixture_binding is not None:
                fixture_module, callback, _ = self.fixture_binding
                assert fixture_module is module and descriptor is callback
                assert any(saved_owner is module and saved_name == slot for saved_owner, saved_name, _ in self.slots)
                self.pin(callback)
                # The original fixture restores this public slot; retain its earlier stock pin.
                continue
            self.slots.append((owner, slot, descriptor))
            function = descriptor.__func__ if type(descriptor) in (classmethod, staticmethod) else descriptor
            self.pin(function)
        return module

    def loaded(self):
        for name in self.rows:
            module = sys.modules.get(name)
            if module is not None:
                self.module(module)
        for left, slot, right, right_slot in self.aliases:
            if left in sys.modules and right in sys.modules:
                expected = sys.modules[right]
                if right_slot is not None:
                    expected = vars(expected)[right_slot]
                assert vars(sys.modules[left])[slot] is expected
        admission = sys.modules.get("tldw_chatbook.Backup_Recovery.admission")
        if admission is not None:
            cls = vars(admission)["Admission"]
            query = vars(cls)["pause_requested"]
            expected = (admission, cls, query, query.__code__, query.__globals__,
                        query.__defaults__, query.__kwdefaults__, query.__closure__,
                        vars(cls).get("__getattribute__"), vars(cls).get("__dict__"))
            actual = vars(admission)["_ORDINARY_PAUSE_REQUEST_BINDING"]
            assert type(actual) is tuple and len(actual) == len(expected)
            assert all(a is b for a, b in zip(actual, expected))

    def unchanged(self):
        self.source_bytes_unchanged()
        for module, name, cls, bases in self.classes:
            assert vars(module)[name] is cls and cls.__bases__ == bases
        for owner, name, value in self.slots:
            assert vars(owner)[name] is value
        for function, code, namespace, defaults, kw, items, closure, cells, wrapped in self.functions.values():
            assert function.__code__ is code and function.__globals__ is namespace
            assert function.__defaults__ is defaults and function.__kwdefaults__ is kw
            assert tuple((kw or {}).items()) == items
            assert function.__closure__ is closure
            assert all(cell.cell_contents is value for cell, value in cells)
            assert vars(function).get("__wrapped__") is wrapped

    def source_bytes_unchanged(self):
        for module, path, spec, loader, data, *_ in self.sources.values():
            assert module.__spec__ is spec and module.__loader__ is loader
            assert Path(module.__file__).resolve() == path
            assert Path(spec.origin).resolve() == path and spec.loader is loader
            assert path.read_bytes() == data

    def receipt(self):
        return {
            "sources": [{"module": m.__name__, "path": str(path),
                         "expected_code_compiler": self.compilers[m.__name__],
                         "sha256": hashlib.sha256(data).hexdigest()}
                        for m, path, _, _, data, *_ in self.sources.values()],
            "functions": [{"definer": f.__globals__["__name__"],
                           "code_qualname": code.co_qualname,
                           "line": code.co_firstlineno, "filename": code.co_filename,
                           "compiled_shape_equal": True,
                           "globals_is_definer_namespace": True,
                           "defaults_match_frozen_source": True,
                           "closure_names": list(code.co_freevars)}
                          for f, code, *_ in self.functions.values()],
            "classes": [{"module": m.__name__, "name": name,
                         "public_identity": id(cls),
                         "bases": [base.__module__ + "." + base.__qualname__ for base in bases]}
                        for m, name, cls, bases in self.classes],
            "slots": [{"owner_kind": type(owner).__name__,
                       "owner_module": vars(owner).get("__module__", vars(owner).get("__name__")),
                       "owner_qualname": vars(owner).get("__qualname__"),
                       "name": name, "value_identity": id(value)}
                      for owner, name, value in self.slots],
            "slot_count": len(self.slots), "class_count": len(self.classes),
            "original_fixture_callback_observed": self.fixture_binding is not None,
        }
