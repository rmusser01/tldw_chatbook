# One-case Windows installation-binding bridge for current config47de

**Minimum direction: one natural Windows metadata-only TEST, using the complete unchanged reader capture method.** A passing bridge plus the already accepted current12+11 ordinary result makes the extra POSIX binding proposal unnecessary for this gap. Do not replay31+5/3,122 or152 controls and do not export the whole current8546-source Goal.

This packet contains the **complete proposed one-TEST source and final14-row source table, unrun and not dispatch-ready**. Root still needs to author and independently review/seal its small operational runner/command/publication. No existing Goal/R source is changed here. `verify_static.py` imports only stdlib and reads/compiles frozen E data; it never imports or executes the proposed TEST, reader or product.

## Exact subject and stage paths

Use the approved component prefix at `cb89cd956ff60f9560949fb710dcac35ee2a0701`, whose Python baseline is8479/map11c and config096. Temporarily replace only `tldw_chatbook/config.py` with the complete frozen current candidate47de2fc374da8c98431e4111ec76b5ca594974482bdac66514085094979d371b and create one absent TEST:

`Tests/Backup_Recovery/test_opt36_current_windows_installation_binding.py`

Proposed sole node:

`Tests/Backup_Recovery/test_opt36_current_windows_installation_binding.py::test_current_windows_helper_retains_exact_installed_definition_capture`

This is explicitly **component8479/config096 → component8480/config47de + oneTEST → exact8479/config096 restoration**. It is not current Goal8546/config21f staging, a new whole-Goal export or an assertion that the old prefix is current Goal.

`expected-sources.seed.json` retains13 exact source rows from the previously reviewed reader graph, replacing only the config snapshot/hash with47de and removing the two unstaged behavior TEST rows/aliases. The new TEST row and its one slot are now enrolled in final14-row `expected-sources.json`. The original13-row seed is retained as authoring history and is not consumed by Gate. The original3 runtime rows/files and `nodeids.json` constructor input are retained byte-exact. The original behavior selectors in that file are inert constructor data; the bridge never invokes `prepare(item)` or pretends to be one of those cases.

The unchanged reader is0316231e…a6f0 and Gate is2e24fa48…666. Reuse their complete methods; do not copy/rewrite a new capture implementation. Packet byte/loader/path guards must precede the child's ordinary imports under the existing accepted finite trusted-harness scope.

## Natural runtime and fixture path

Run separate exact collection and one body through the existing `python -m Tests.windows_private_fixture_runner`, with the supported Windows2022/CPython3.12.10 x64/pytest8.4.2/Textual8.2.8 runtime and the original three runtime source checks. Keep original explicit asyncio/timeout plugins, `--timeout=180`, fresh basetemp/XML and the original environment cleanup/disabled plugin autoload. Do not load `opt36_candidate_plugin`.

The new TEST uses the existing `@pytest.mark.bootstrap_profile` opt-in understood by `Tests/conftest.py`. This retains the actual root fixture's collection-selected private profile, network backstop and natural config import. It adds no fixture replacement or custom profile authority. The existing Windows launcher sets/restores its actual ordinary fixture default owner and closes its token; do not rerun it, alias `__main__`, change TokenUser/privileges or claim a captured/elevated TokenOwner receipt.

There is one parent body, **no private-profile memo child**, no native behavior ledger and no metadata workload. The source-pinned `_launcher()` reader method can observe the real wrapper/main code and actual main stack while the natural launcher is active; it does not invoke the ownership helper.

## Exact authored body contract

1. Under the natural selected profile, import the actual installed config and obtain the real pytest config/request. Require47de bytes/path/spec/loader and the current factory-nested helper source location; no import alias or replacement helper.
2. Instantiate `CandidateReader(actual_checkout_root, request.config)`. Its unchanged constructor checks the actual Windows runtime and creates Gate metadata only; it never calls `_native()` or constructs `_Native`.
3. Call the unchanged `reader.gate.loaded()`, `reader._adapter_capture()` and `reader._launcher()`. Retain their actual capture objects. Apply the existing prepare method's short loader-type assertions to the resulting Gate source table: Tests use only SourceFileLoader or the actual assertion-rewriting loader; non-Tests use SourceFileLoader. No wholesale `prepare`, behavior observation/start or `finish` is appropriate for this distinct metadata-only case.
4. Directly require each retained `(namespace, name, value)` to satisfy `namespace.get(name) is value`, both before and after the bracket. This is a noninvoking equivalent check of the live binding rows; do **not** call the product's source_current checker. Require25 retained records,39 fixed bindings, four wrapped-body links,3 cached bound receivers and3 canonical modules. The complete original method independently checks the actual code/globals/defaults/keywords/closure/cells, class namespace backing identity, lookup descriptors and canonical receiver identities against compiled47de/native source.
5. Before a second capture, call `gate.unchanged()` so no earlier function/code/default/cell reference can be silently recaptured after drift. Bracket with `gate.loaded()`, the same whole `_adapter_capture()` and `_launcher()` again, and `gate.unchanged()` afterward. Require first/last helper, checker, retained record/binding/cached/module objects and launcher defining function/code identities to remain the same. The three module dict/spec/path and source bytes stay current through the original Gate checks.
6. Capture and compare existing monitoring tool ownership/global masks, profile/trace callbacks and the two existing lru_cache cache_info values around the inspection. The bridge allocates **no monitoring ID**, registers no callback, sets no mask and installs no profiler. The comparison establishes it leaves that existing instrumentation/cache state unchanged; it is not a new global native-call trace. No lifecycle needing monitor retirement is introduced.
7. Emit a distinct `opt36_current_windows_installation` XML property containing `gate.receipt()`, actual47de/compiler/path/helper/checker locations,25/39/4/3/3 capture counts, unchanged bracket identities/instrumentation/cache metadata, natural launcher relation and explicit metadata-only scope. Do **not** use `CandidateReader.receipt()` because its hard-coded31/five-cohort wording would mislabel this case. Require the property in independent raw XML review.

No direct factory/checker/helper/batch/scalar producer/native constructor call belongs in this TEST. `_adapter_capture` reads `_Native` as a class and `_native` as an existing lru wrapper; it does not instantiate either producer. Standard Gate compiler/default/fixture-getter inspection still executes its existing metadata logic. Natural fixture/module initialization may perform ordinary startup/native I/O before the inspection; the bridge must not claim the whole process performed zero native work. Cache/instrumentation stability plus reviewed call sites are finite inspection evidence, not universal transitive provenance.

## Dependency and incoming-prefix reconciliation

The direct metadata seam's entire storage1ea88, platform9e985 and windows6b665 files are the same as current Goal's frozen files. The related config_participants fa786, raw_participants30a79, bootstrap398ac, admissiond8faf and control_records49325 files also match between the frozen component and current ordinary maps. `_posture` directly reads only its canonical `os` and `stat` globals; the Windows file's native definitions import ordinary stdlib modules, not Goal private_paths or input_validation.

The complete47de config intentionally includes current non-native incoming changes: derived-key-cache clearing, sync-table extraction/projection, generated sync defaults and egress documentation. The adapter/install/delete bytes are identical to qualified da3a; frozen compiler enrollment identifies21 equal recursive code objects with an explicit+25 line translation. Gate must independently compile actual47de under **actual Windows3.12.10** and match the actual functions; do not substitute the Python3.12.11 data table for that live check.

One concrete mixed-prefix dependency is excluded: current47de `set_encryption_password` and `clear_encryption_password` call `get_encryption_module().clear_derived_key_cache()`. Root's source inspection establishes that old R's `Utils/config_encryption.py` lacks that method, while the actual current Goal encryption module defines it. The frozen map comparison records those different file hashes. This bridge never calls either transition and does not qualify that unrelated encryption lifecycle or whole current config behavior on the old prefix. No broader export is needed to inspect the metadata adapter; any accidental transition during the natural fixture path must fail visibly and be investigated, not ignored.

Current Goal's private_paths fd8fa, input_validation a322f, root fixture9f7d88 and private-profile helper35ec differ from the old component graph. This bridge intentionally retains the approved component prefix/fixtures and guards their exact bytes via its full component before/staged/after maps. Those different current files do not define the captured25 metadata records, and are **not exported or qualified by this bridge**. Their integration remains represented by the separately accepted current23 ordinary run. `prefix-reconciliation.json` lists the exact equal/different hashes rather than silently treating old prefix and current Goal as equivalent.

The actual R prefix keeps its own immutable non-Python guards. Current Task28e898/ADR1264f71 source-selection policy is a separately frozen design input; do not relabel old ADR126467a checkout bytes as4f71 or replace unrelated R files to force that label.

## Root operational requirements and claims

Root's dependent runner must bind the exact actual publication parent/base and full component8479 map11c; archive config096 original bytes/mode before mutation; use reviewed atomic same-directory staging/restoration; journal exactly one owned TEST; refuse drift; and restore exact8479 after both child invocations. Keep foreground Windows Popen wait/return/poll/final_poll, outer/finalizer outcomes and full hidden artifact inventory. Use180 seconds per natural case and210 seconds outer custody per one-case command; no raised native deadline or extra inner child is needed. Old outer62ed cannot be dispatched unchanged because its fixed31+5 plan/configda3a predicates describe another operation.

Acceptance is exact one-case collection, one parent XML PASS/0F/E/S including teardown, the complete actual capture property, unchanged source/runtime/instrumentation bindings, actual direct custody and exact restoration, followed by independent raw-result review. Any binding mismatch is a gap to investigate, not permission to weaken the capture or automatically run broader native cohorts.

If this passes, the exact47de Windows installation/capture gap is closed **within the approved component prefix**. Together with unchanged qualified native component behavior and current ordinary23 integration, this supports a precise local source-retention reconciliation and makes the proposed additional POSIX owner case redundant. It still does not establish every current Windows caller/private_paths behavior, current whole-Goal/platform qualification, global resource retirement, Task35/OPT74, latency, Task28/branch completion or deployment acceptance.

ADR required: no new ADR for this metadata-only bridge; existing ADR126/230 source/custody boundaries remain. The one fixed TEST/source enrollment is complete as a proposal. The remaining gap is reviewed concrete orchestration/publication, not a new reader or generalized provenance service.

Skipped: operational-runner/publication authoring and execution, SUT/reader/TEST imports or execution, native runs, Goal/R reads or writes, current full-map attestation, network and publication. Risk: no live47de Windows capture exists yet; this source proposal still needs Root operational packaging and distinct review before execution.
