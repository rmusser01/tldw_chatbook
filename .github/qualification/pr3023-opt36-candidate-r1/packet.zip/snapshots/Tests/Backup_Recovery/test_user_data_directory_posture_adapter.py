"""Unexecuted shipping-helper controls; no product adapter lives in this file."""

from __future__ import annotations

import ctypes as C
import errno
import json
import os
import stat
import sys
import threading
from collections import Counter
from contextlib import contextmanager
from types import CodeType, FunctionType

import pytest

from Tests.Backup_Recovery.test_windows_metadata_baseline_opt36_opt74 import (
    _native_returns,
    _ObserverSourceChanged,
    _posture,
)
from tldw_chatbook.Utils import windows_files as files


pytestmark = pytest.mark.skipif(os.name != "nt", reason="actual Windows shipping helper")


def _fixture_paths(tmp_path):
    from tldw_chatbook.Backup_Recovery import storage_admission as storage

    win = storage.os
    root, branch = tmp_path / "shipping-root", tmp_path / "shipping-root" / "branch"
    win.mkdir(root, 0o700)
    win.mkdir(branch, 0o700)
    first, second = branch / "first.bin", branch / "second.bin"
    for path in (first, second):
        fd = win.open(path, win.O_CREAT | win.O_EXCL | win.O_RDWR, 0o600)
        win.close(fd)
    return win, (second, branch, first, root, first)


def _retired(ledger):
    counts, ancestry, births, closes, errors, excluded, security = ledger
    assert not errors and not excluded and births
    assert len(births) == len(closes)
    assert Counter(map(id, births)) == Counter(map(id, closes))
    assert all(row["status"] >= 0 and row["thread"] == threading.get_ident() for row in births)
    assert all(row["closes"] == [(True, 0)] for row in births)
    assert security and all(owner and user for owner, user, _uid, _mode in security)
    return counts, ancestry, births


@contextmanager
def _shipping_events(win, ledger=None, *, change=None, projection=False, restore=None):
    """Observe these exact current helper/API entries and one genuine boundary."""
    from tldw_chatbook import config
    from tldw_chatbook.Backup_Recovery import storage_admission as storage

    helper, posture = config._user_data_dir_stamps, storage._posture
    batch = type(win).stat_many_for_admission
    caller = threading.get_ident()
    helper_code, batch_code = helper.__code__, batch.__code__
    posture_code = posture.__code__ if type(posture) is FunctionType else None
    helper_cells = dict(zip(helper.__code__.co_freevars, helper.__closure__ or ()))
    checker = helper_cells["source_current"].cell_contents
    checker_code = checker.__code__
    codes = {helper_code: "helper", batch_code: "batch", files._component.__code__: "component",
             files._native.__wrapped__.__code__: "native_miss"}
    if posture_code is not None:
        codes[posture_code] = "posture"
    state = {"starts": Counter(), "paths": [], "returns": 0, "changed": False,
             "producer_errors": [], "drains": [], "errors": [], "false_checkpoints": [], "restored_at_false_return": False}
    native = files._native() if ledger is not None else None

    def drained():
        assert ledger is not None and native is not None
        births, closes = ledger[2], ledger[3]
        assert births and len(births) == len(closes)
        assert all(row["closes"] == [(True, 0)] for row in births)
        valid = native.kernel.GetHandleInformation
        valid.argtypes, valid.restype = [files._HANDLE, C.POINTER(files._U32)], files._I32
        for handle in {row["handle"] for row in births}:
            flags = files._U32()
            assert not valid(handle, C.byref(flags)) and C.get_last_error() == 6
        state["drains"].append(len(births))

    def start(code, offset):
        frame = None
        try:
            frame = sys._getframe(1)
            assert frame.f_code is code and threading.get_ident() == caller
            state["starts"][codes[code]] += 1
            if code is posture_code:
                state["paths"].append((frame.f_locals["path"], caller))
        except BaseException as error:
            state["errors"].append(type(error).__name__ + ":" + str(error))
        finally:
            frame = None

    def returned(code, offset, value):
        frame = None
        try:
            frame = sys._getframe(1)
            assert frame.f_code is code and threading.get_ident() == caller
            if code is checker_code:
                assert frame.f_globals is checker.__globals__ and type(value) is bool
                if value is False and state["changed"] and restore is not None:
                    state["false_checkpoints"].append("projection" if projection else "batch-return")
                    restore()
                    state["restored_at_false_return"] = True
                return
            if code is batch_code:
                assert frame.f_globals is batch.__globals__ and frame.f_locals["self"] is win
                assert type(value) is dict
                drained()
                state["returns"] += 1
                if change is not None and not projection:
                    change()
                    state["changed"] = True
        except BaseException as error:
            state["errors"].append(type(error).__name__ + ":" + str(error))
        finally:
            frame = None

    def unwound(code, offset, error):
        if code is not batch_code:
            return
        try:
            assert threading.get_ident() == caller
            tail, nodes = error.__traceback__, []
            while tail is not None:
                nodes.append((tail, tail.tb_frame, tail.tb_frame.f_code, tail.tb_lineno, tail.tb_next))
                tail = tail.tb_next
            state["producer_errors"].append((error, error.__cause__, error.__context__,
                                              error.__suppress_context__, error.__traceback__, tuple(nodes)))
            if type(error) is PermissionError and error.errno == 13 and error.strerror == "windows_admission_descriptor_unavailable":
                drained()
        except BaseException as observer_error:
            state["errors"].append(type(observer_error).__name__ + ":" + str(observer_error))

    previous, mask = sys.getprofile(), stat.S_IFMT

    def projected(frame, event, value):
        try:
            if projection and state["returns"] and not state["changed"] and event == "c_return" and value is mask:
                parent = frame if frame.f_code is helper_code else frame.f_back
                if parent is not None and parent.f_code is helper_code and parent.f_globals is helper.__globals__:
                    change()
                    state["changed"] = True
        except BaseException as error:
            state["errors"].append(type(error).__name__ + ":" + str(error))
        finally:
            if previous is not None:
                previous(frame, event, value)

    monitor = sys.monitoring
    slot = next(n for n in range(5, 0, -1) if n != monitor.DEBUGGER_ID and monitor.get_tool(n) is None)
    monitor.use_tool_id(slot, "shipping-posture-boundary")
    registered = []
    try:
        for event, callback in ((monitor.events.PY_START, start), (monitor.events.PY_RETURN, returned),
                                (monitor.events.PY_UNWIND, unwound)):
            assert monitor.register_callback(slot, event, callback) is None
            registered.append(event)
        for code in codes:
            monitor.set_local_events(slot, code, monitor.events.PY_START | (monitor.events.PY_RETURN if code is batch_code else 0))
        if restore is not None:
            monitor.set_local_events(slot, checker_code, monitor.events.PY_RETURN)
        monitor.set_events(slot, monitor.events.PY_UNWIND)
        if projection:
            sys.setprofile(projected)
        yield state
    finally:
        operations = ([lambda: sys.setprofile(previous)] if projection else [])
        operations.append(lambda: monitor.set_events(slot, 0))
        if restore is not None:
            operations.append(lambda: monitor.set_local_events(slot, checker_code, 0))
        operations.extend(lambda code=code: monitor.set_local_events(slot, code, 0) for code in codes)
        operations.extend(lambda event=event: monitor.register_callback(slot, event, None) for event in registered)
        operations.append(lambda: monitor.free_tool_id(slot))
        for operation in operations:
            try:
                operation()
            except BaseException as error:
                state["errors"].append("monitor-cleanup:" + type(error).__name__ + ":" + str(error))
        if monitor.get_tool(slot) is not None:
            state["errors"].append("monitor-not-retired")


def test_shipping_helper_uses_one_fresh_batch_after_equal_values_and_retirement(tmp_path, record_property):
    """Original-source RED must be the final schedule assertion, after custody."""
    from tldw_chatbook import config
    from tldw_chatbook.Backup_Recovery import storage_admission as storage

    win, paths = _fixture_paths(tmp_path)
    expected = tuple(storage._posture(path) for path in paths)
    with _native_returns(win) as ledger:
        actual = config._user_data_dir_stamps(paths)
    counts, ancestry, births = _retired(ledger)
    assert actual == expected and all(len(value) == 5 for value in actual)
    assert actual[2] == actual[4]
    nodes = {node for path in paths for node in (*path.parents, path)}
    n, depth = len(nodes), sum(len(path.parts) for path in paths)
    batch = {"batch": 1, "component": sum(len(node.parts) - 1 for node in nodes),
             "open": 2 * n, "info": 3 * n, "ntfs": 2 * n, "stat": n, "security": n}
    record_property("shipping_causal_before_schedule_assert", json.dumps({
        "paths": [str(path) for path in paths], "nodes": n, "scalar_depth": depth,
        "five_field_values_equal": True, "same_order_duplicate": True,
        "counts": dict(counts), "ancestry": dict(ancestry), "births_retired_once": len(births),
        "observer_errors": ledger[4], "caller": threading.get_ident(),
        "expected_batch_counts": batch, "scope": "helper counts only; no elapsed acceptance",
    }, sort_keys=True))
    assert dict(counts) == batch
    assert dict(ancestry) == {"open": 2 * n, "stat": n}
    assert len(births) == 2 * n


@pytest.mark.parametrize("change", ["function", "callable", "body", "defaults", "kwdefaults"])
def test_direct_custom_posture_keeps_original_dispatch_before_optional_work(tmp_path, monkeypatch, change):
    from tldw_chatbook import config
    from tldw_chatbook.Backup_Recovery import storage_admission as storage

    win, paths = _fixture_paths(tmp_path)
    original = storage._posture
    reference_before = files._native.cache_info()
    expected = tuple(original(path) for path in paths)
    reference_after = files._native.cache_info()
    calls, caller = [], threading.get_ident()
    marker = object()

    def custom(path):
        calls.append((path, threading.get_ident()))
        return marker

    class Callback:
        def __call__(self, path):
            return custom(path)

    with monkeypatch.context() as patch:
        if change in {"function", "callable"}:
            patch.setattr(storage, "_posture", custom if change == "function" else Callback())
        elif change == "body":
            patch.setattr(original, "__code__", original.__code__.replace(co_consts=original.__code__.co_consts + ("shipping source marker",)))
        elif change == "defaults":
            patch.setattr(original, "__defaults__", (None,))
        else:
            patch.setattr(original, "__kwdefaults__", {"unused_shipping_marker": None})
        before = files._native.cache_info()
        # Fixed existing callbacks only; custom callables have no __code__.
        if change in {"function", "callable"}:
            with _shipping_events(win) as state:
                assert config._user_data_dir_stamps(paths) == (marker,) * len(paths)
            assert calls == [(path, caller) for path in paths]
            assert files._native.cache_info() == before
            assert not state["errors"] and state["starts"]["batch"] == 0
            assert state["starts"]["component"] == state["starts"]["native_miss"] == 0
        else:
            with _native_returns(win) as ledger:
                actual_before = files._native.cache_info()
                actual = config._user_data_dir_stamps(paths)
                actual_after = files._native.cache_info()
            assert actual == expected
            assert ledger[0]["batch"] == 0 and ledger[0]["stat"] == len(paths)
            assert actual_after.hits - actual_before.hits == reference_after.hits - reference_before.hits
            assert actual_after.misses == actual_before.misses
            _retired(ledger)


@pytest.mark.parametrize("slot", ["stat", "_stat_handle", "class_stat"])
def test_direct_custom_facade_keeps_scalar_arguments_and_receiver(tmp_path, monkeypatch, slot):
    from tldw_chatbook import config
    from tldw_chatbook.Backup_Recovery import storage_admission as storage

    win, paths = _fixture_paths(tmp_path)
    calls, caller = [], threading.get_ident()
    original_stat, original_handle = win.stat, win._stat_handle

    def changed_stat(path, *, dir_fd=None, follow_symlinks=True):
        calls.append((path, dir_fd, follow_symlinks, threading.get_ident()))
        return original_stat(path, dir_fd=dir_fd, follow_symlinks=follow_symlinks)

    def changed_handle(handle, *, with_descriptor=False):
        calls.append((handle, with_descriptor, threading.get_ident()))
        return original_handle(handle, with_descriptor=with_descriptor)

    def class_stat(self, path, *, dir_fd=None, follow_symlinks=True):
        assert self is win
        return changed_stat(path, dir_fd=dir_fd, follow_symlinks=follow_symlinks)

    with monkeypatch.context() as patch:
        if slot == "class_stat":
            patch.setattr(type(win), "stat", class_stat)
        else:
            patch.setattr(win, slot, changed_stat if slot == "stat" else changed_handle)
        reference_before = files._native.cache_info()
        expected = tuple(storage._posture(path) for path in paths)
        reference_after = files._native.cache_info()
        reference_calls = tuple(calls)
        calls.clear()
        actual_before = files._native.cache_info()
        with _shipping_events(win) as state:
            assert config._user_data_dir_stamps(paths) == expected
        actual_after = files._native.cache_info()
        assert not state["errors"] and state["starts"]["batch"] == 0
        if slot == "_stat_handle":
            assert [(descriptor, thread) for _handle, descriptor, thread in calls] == [
                (descriptor, thread) for _handle, descriptor, thread in reference_calls
            ]
        else:
            assert tuple(calls) == reference_calls
        assert actual_after.hits - actual_before.hits == reference_after.hits - reference_before.hits
        assert actual_after.misses == actual_before.misses
    if slot == "class_stat":
        # The actual facade already owns its cached original bound stat.
        # Changing the class slot must decline batching without inventing a
        # class callback call that the original scalar route does not make.
        assert not calls and not reference_calls
    elif slot != "_stat_handle":
        assert len(calls) == len(paths)
        assert calls == [(path, None, False, caller) for path in paths]
    else:
        assert len(calls) == len(paths)
        assert all(type(handle) is int and not descriptor and thread == caller for handle, descriptor, thread in calls)


@pytest.mark.parametrize("change", ["posture_slot", "posture_body", "posture_defaults", "facade_stat", "batch_body", "batch_defaults", "projection"])
def test_actual_batch_return_or_projection_source_change_discards_whole_sample(tmp_path, monkeypatch, record_property, change):
    from tldw_chatbook import config
    from tldw_chatbook.Backup_Recovery import storage_admission as storage

    win, paths = _fixture_paths(tmp_path)
    original, batch = storage._posture, type(win).stat_many_for_admission
    original_code, original_defaults, original_stat = original.__code__, original.__defaults__, win.stat
    batch_code, batch_defaults = batch.__code__, batch.__defaults__
    calls = []
    with monkeypatch.context() as patch:
        def changed(path):
            calls.append(path)
            return ("custom fresh value",)

        def mutate():
            if change in {"posture_slot", "projection"}:
                patch.setattr(storage, "_posture", changed)
            elif change == "posture_body":
                patch.setattr(original, "__code__", original.__code__.replace(co_consts=original.__code__.co_consts + ("held source marker",)))
            elif change == "posture_defaults":
                patch.setattr(original, "__defaults__", (None,))
            elif change == "facade_stat":
                patch.setattr(win, "stat", lambda path, **kwargs: changed(path))
            elif change == "batch_body":
                patch.setattr(batch, "__code__", batch.__code__.replace(co_consts=batch.__code__.co_consts + ("held source marker",)))
            else:
                patch.setattr(batch, "__defaults__", ((),))

        def restore():
            # Restore only these exact controlled slots after the genuine
            # checker has already computed False, before its caller consumes it.
            if change in {"posture_slot", "projection"}:
                storage._posture = original
            elif change == "posture_body":
                original.__code__ = original_code
            elif change == "posture_defaults":
                original.__defaults__ = original_defaults
            elif change == "facade_stat":
                win.stat = original_stat
            elif change == "batch_body":
                batch.__code__ = batch_code
            else:
                batch.__defaults__ = batch_defaults

        observer_problem = None
        try:
            with _native_returns(win) as ledger:
                with _shipping_events(win, ledger, change=mutate, projection=change == "projection", restore=restore) as state:
                    actual = config._user_data_dir_stamps(paths)
        except _ObserverSourceChanged as error:
            observer_problem = error
        assert state["returns"] == 1 and state["changed"]
        assert state["false_checkpoints"] == ["projection" if change == "projection" else "batch-return"]
        assert state["restored_at_false_return"]
        assert not state["errors"] and state["drains"] and not state["producer_errors"]
        if change in {"batch_body", "batch_defaults"}:
            # The two owned monitor tools have no claimed callback ordering.
            # Original R13 may see this deliberate drift at the same return.
            assert ledger[4] in ([], ["source-changed"])
            assert (observer_problem is not None) == bool(ledger[4])
            assert not ledger[5] and ledger[2]
            assert len(ledger[2]) == len(ledger[3])
            assert Counter(map(id, ledger[2])) == Counter(map(id, ledger[3]))
            assert all(row["closes"] == [(True, 0)] and row["status"] >= 0
                       and row["thread"] == threading.get_ident() for row in ledger[2])
            assert ledger[6] and all(owner and user for owner, user, _uid, _mode in ledger[6])
        else:
            assert observer_problem is None
            _retired(ledger)
        assert ledger[0]["batch"] == 1 and state["starts"]["posture"] == 0 and not calls
        record_property("actual_shipping_source_boundary", json.dumps({
            "change": change, "actual_batch_returns": state["returns"], "mutation_fired": state["changed"],
            "physical_drains_before_change": state["drains"], "scalar_calls_after_batch": state["starts"]["posture"],
            "observer_errors": state["errors"], "native_source_errors": ledger[4],
            "genuine_false_checkpoints": state["false_checkpoints"],
            "original_slots_restored_before_false_was_consumed": state["restored_at_false_return"],
        }, sort_keys=True))
        assert actual is None


@pytest.mark.parametrize("kind", ["oserror", "lookup", "permission_subclass", "exact_marker", "wrong_marker", "wrong_errno"])
def test_custom_scalar_error_and_empty_keep_original_route(tmp_path, monkeypatch, kind):
    from tldw_chatbook import config
    from tldw_chatbook.Backup_Recovery import storage_admission as storage

    win, paths = _fixture_paths(tmp_path)
    calls = []

    class CustomPermission(PermissionError):
        pass

    problem = (LookupError("original scalar customization") if kind == "lookup" else
               CustomPermission(13, "windows_admission_descriptor_unavailable") if kind == "permission_subclass" else
               PermissionError(13, "windows_admission_descriptor_unavailable") if kind == "exact_marker" else
               PermissionError(13, "unrelated_marker") if kind == "wrong_marker" else
               PermissionError(5, "windows_admission_descriptor_unavailable") if kind == "wrong_errno" else
               OSError(errno.EACCES, "unrelated scalar error"))

    def refused(path):
        calls.append((path, threading.get_ident()))
        raise problem

    with monkeypatch.context() as patch:
        patch.setattr(storage, "_posture", refused)
        before = files._native.cache_info()
        with _shipping_events(win) as state:
            if kind == "lookup":
                with pytest.raises(LookupError) as caught:
                    config._user_data_dir_stamps(paths)
                assert caught.value is problem
            else:
                assert config._user_data_dir_stamps(paths) is None
            assert config._user_data_dir_stamps(()) == ()
        assert files._native.cache_info() == before
    assert calls == [(paths[0], threading.get_ident())]
    assert not state["errors"] and state["starts"]["batch"] == 0
    assert state["starts"]["component"] == state["starts"]["native_miss"] == 0


def test_empty_and_missing_descendants_preserve_original_positions_without_optional_empty_work(tmp_path):
    from tldw_chatbook import config
    from tldw_chatbook.Backup_Recovery import storage_admission as storage

    win, original = _fixture_paths(tmp_path)
    with _native_returns(win) as empty:
        before = files._native.cache_info()
        with _shipping_events(win) as state:
            assert config._user_data_dir_stamps(()) == ()
        assert files._native.cache_info() == before
    assert not empty[0] and not empty[2] and not empty[4] and not empty[5]
    assert not state["errors"] and state["starts"]["batch"] == 0
    assert state["starts"]["component"] == state["starts"]["native_miss"] == 0
    missing = original[1] / "absent" / "descendant"
    paths = (missing, original[0], missing, missing.parent)
    expected = tuple(storage._posture(path) for path in paths)
    with _native_returns(win) as ledger:
        actual = config._user_data_dir_stamps(paths)
    _retired(ledger)
    assert actual == expected and actual[0] is actual[2] is actual[3] is None
    assert len(actual[1]) == 5


@pytest.mark.parametrize("form", ["relative", "pathlike", "borrowed_fd"])
def test_nonstock_input_forms_keep_original_scalar_route(tmp_path, monkeypatch, form):
    from tldw_chatbook import config
    from tldw_chatbook.Backup_Recovery import storage_admission as storage

    win, original = _fixture_paths(tmp_path)
    leaf, fd = original[0], None
    calls = []

    class PathLike:
        def __fspath__(self):
            calls.append(threading.get_ident())
            return str(leaf)

    try:
        if form == "relative":
            monkeypatch.chdir(leaf.parent)
            paths = (type(leaf)(leaf.name),)
        elif form == "pathlike":
            paths = (PathLike(),)
        else:
            fd = win.open(leaf, win.O_RDONLY)
            paths = (fd,)
        reference_before = files._native.cache_info()
        expected = tuple(storage._posture(path) for path in paths)
        reference_after = files._native.cache_info()
        reference_calls = tuple(calls)
        calls.clear()
        actual_before = files._native.cache_info()
        with _shipping_events(win) as state:
            assert config._user_data_dir_stamps(paths) == expected
        actual_after = files._native.cache_info()
        assert state["starts"]["batch"] == 0 and not state["errors"]
        assert tuple(calls) == reference_calls
        assert actual_after.hits - actual_before.hits == reference_after.hits - reference_before.hits
        assert actual_after.misses == actual_before.misses
        if fd is not None:
            assert _posture(win.fstat(fd)) == expected[0]
    finally:
        if fd is not None:
            win.close(fd)



def test_shipping_large_descriptor_uses_original_scalar_only_after_physical_drain(tmp_path, record_property):
    """Use the genuine shipping entry; retain the original193-ACE fixture."""
    from tldw_chatbook import config
    from tldw_chatbook.Backup_Recovery import storage_admission as storage

    win, native = storage.os, files._native()
    leaf = tmp_path / "large-private-dacl.bin"
    # Distinct ordinary DENY trustees grant no public authority. The stock
    # projection ignores deny ACEs; READ_DATA denial cannot deny the metadata
    # READ_CONTROL/READ_ATTRIBUTES accesses even if a trustee were in a token.
    denied_sids = tuple("S-1-5-21-101-202-303-" + str(1000000 + i) for i in range(192))
    assert len(set(denied_sids)) == 192 and native.user_sid not in denied_sids
    sddl = ("O:" + native.user_sid + "D:P"
            + "".join("(D;;0x1;;;" + sid + ")" for sid in denied_sids)
            + "(A;;FA;;;" + native.user_sid + ")")
    fd = win.open(leaf, win.O_CREAT | win.O_EXCL | win.O_RDWR, 0o600)
    descriptor = files._P()
    observed_descriptor = files._P()
    owner, dacl = files._P(), files._P()
    descriptor_facts = {}
    paths = (leaf, leaf)
    try:
        native.check(native.advapi.ConvertStringSecurityDescriptorToSecurityDescriptorW(
            sddl, 1, C.byref(descriptor), None))
        present, defaulted = files._I32(), files._I32()
        native.check(native.advapi.GetSecurityDescriptorDacl(
            descriptor, C.byref(present), C.byref(dacl), C.byref(defaulted)))
        assert present.value and dacl.value
        import struct
        descriptor_facts["conversion_descriptor_length"] = native.advapi.GetSecurityDescriptorLength(descriptor)
        descriptor_facts["conversion_acl_count"] = struct.unpack_from("<H", C.string_at(dacl, 8), 4)[0]
        descriptor_facts["conversion_acl_length"] = struct.unpack_from("<H", C.string_at(dacl, 8), 2)[0]
        record_property("descriptor_conversion_native_shape", json.dumps(descriptor_facts))
        with native.reopen(native.handle(fd), files._READ_CONTROL | files._WRITE_DAC) as writable:
            result = native.advapi.SetSecurityInfo(writable, 1, 4 | 0x80000000, None, None, dacl, None)
            if result:
                raise C.WinError(result)
        actual_dacl = files._P()
        result = native.advapi.GetSecurityInfo(native.handle(fd), 1, 5, C.byref(owner), None,
                                             C.byref(actual_dacl), None, C.byref(observed_descriptor))
        if result:
            raise C.WinError(result)
        size = native.advapi.GetSecurityDescriptorLength(observed_descriptor)
        queried_dacl = files._P()
        native.check(native.advapi.GetSecurityDescriptorDacl(
            observed_descriptor, C.byref(present), C.byref(queried_dacl), C.byref(defaulted)))
        assert present.value and queried_dacl.value
        descriptor_facts["installed_queried_descriptor_length"] = size
        descriptor_facts["installed_queried_acl_count"] = struct.unpack_from("<H", C.string_at(queried_dacl, 8), 4)[0]
        descriptor_facts["installed_queried_acl_length"] = struct.unpack_from("<H", C.string_at(queried_dacl, 8), 2)[0]
        record_property("descriptor_installed_native_shape", json.dumps(descriptor_facts))
        assert descriptor_facts["conversion_acl_count"] == 193
        assert descriptor_facts["installed_queried_acl_count"] == 193
        assert 4096 < descriptor_facts["conversion_descriptor_length"] < 16384
        assert 4096 < size < 16384
        expected = tuple(storage._posture(path) for path in paths)
        assert expected is not None and expected[0] == expected[1]
        assert expected[0][3:] == (0o600, 1000)

        with _native_returns(win) as ledger:
            with _shipping_events(win, ledger) as state:
                actual = config._user_data_dir_stamps(paths)
        counts, _ancestry, births = _retired(ledger)
        assert not state["errors"] and state["starts"]["helper"] == 1
        assert state["starts"]["batch"] == 1 and state["returns"] == 0
        assert len(state["producer_errors"]) == len(state["drains"]) == 1
        error = state["producer_errors"][0][0]
        assert type(error) is PermissionError and error.errno == 13
        assert error.strerror == "windows_admission_descriptor_unavailable"
        assert state["paths"] == [(path, threading.get_ident()) for path in paths]
        assert actual == expected
        record_property("shipping_descriptor_fallback_after_original_drain", json.dumps({
            "native_shape": descriptor_facts, "native_births": len(births),
            "counts": dict(counts), "actual_batch_errors": 1,
            "original_error": [type(error).__name__, error.errno, error.strerror],
            "physical_drain_before_scalar": state["drains"],
            "original_scalar_paths": [str(path) for path, _ in state["paths"]],
            "helper_entries": state["starts"]["helper"], "postures_equal": True,
        }, sort_keys=True))
    finally:
        if observed_descriptor.value:
            native.kernel.LocalFree(observed_descriptor)
        if descriptor.value:
            native.kernel.LocalFree(descriptor)
        # This continuously owned CRT descriptor was created by the fixture,
        # never handed to metadata retirement or retried as a stale HANDLE.
        try:
            win.fchmod(fd, 0o600)
        finally:
            win.close(fd)


@pytest.mark.parametrize("api", ["scalar", "batch"])
@pytest.mark.parametrize("outcome", ["protected_false", "raising"])
def test_shipping_helper_propagates_exact_retained_native_close(tmp_path, monkeypatch, record_property, api, outcome):
    """Retain actual continuous failed owner; only fixture can unprotect it."""
    from tldw_chatbook import config
    from tldw_chatbook.Backup_Recovery import storage_admission as storage

    win, native = storage.os, files._native()
    leaf = tmp_path / "retained-close.bin"
    fd = win.open(leaf, win.O_CREAT | win.O_EXCL | win.O_RDWR, 0o600)
    win.close(fd)
    paths = (leaf,)
    kernel = native.kernel
    real_close = kernel.CloseHandle
    get_flags, set_flags = kernel.GetHandleInformation, kernel.SetHandleInformation
    get_flags.argtypes, get_flags.restype = [files._HANDLE, C.POINTER(files._U32)], files._I32
    set_flags.argtypes, set_flags.restype = [files._HANDLE, files._U32, files._U32], files._I32
    selected, errors, calls = [], [], []
    selected_births = []
    protected = set()
    helper_calls = []
    failure = RuntimeError("controlled defining close raised")
    ledger = None
    caller = threading.get_ident()
    scalar = config._user_data_dir_stamps
    opener = type(native).open_handle
    monitor, slot = sys.monitoring, None

    def observed_close(handle):
        if selected and selected[0] in protected and handle == selected[0].handle:
            calls.append(handle)
            if outcome == "raising":
                raise failure
        return real_close(handle)
    observed_close.argtypes = real_close.argtypes
    observed_close.restype = real_close.restype

    def record_open(code, offset, value):
        frame = None
        try:
            frame = sys._getframe(1)
            assert code is opener.__code__ and frame.f_code is code
            assert frame.f_globals is opener.__globals__ and frame.f_locals['self'] is native
            record = frame.f_locals.get('_metadata_record')
            if record is None or record.path != leaf or selected:
                return
            assert type(record) is files._AdmissionMetadataHandle
            assert record.native is native and record.handle == value
            assert record.identity is not None and record.close_error is None
            assert threading.get_ident() == caller
            assert ledger is not None
            active_births = [birth for birth in ledger[2]
                             if birth["handle"] == record.handle and not birth["closes"]]
            assert len(active_births) == 1
            selected_births.append(active_births[0])
            flags = files._U32()
            native.check(get_flags(record.handle, C.byref(flags)))
            assert not flags.value & 2
            selected.append(record)  # retain exact known birth before fixture mutation
            native.check(set_flags(record.handle, 2, 2))
            protected.add(record)
            native.check(get_flags(record.handle, C.byref(flags)))
            assert flags.value & 2
        except BaseException as error:  # noqa: BLE001 - passive test control records failure without replacing producer outcome.
            errors.append(type(error).__name__ + ':' + str(error))
        finally:
            frame = None

    def record_scalar(code, offset):
        frame = None
        try:
            frame = sys._getframe(1)
            assert code is scalar.__code__ and frame.f_code is code
            assert frame.f_globals is scalar.__globals__ and threading.get_ident() == caller
            helper_calls.append(frame.f_locals['paths'])
        except BaseException as error:  # noqa: BLE001 - passive observer reports only after exact native cleanup.
            errors.append(type(error).__name__)
        finally:
            frame = None

    delegated = []

    def delegated_posture(path):
        delegated.append((path, threading.get_ident()))
        return _posture(win.stat_for_admission(path)[0])

    try:
        slot = next(n for n in range(5, 0, -1) if n != monitor.DEBUGGER_ID and monitor.get_tool(n) is None)
        monitor.use_tool_id(slot, 'actual-retained-close-control')
        assert monitor.register_callback(slot, monitor.events.PY_RETURN, record_open) is None
        assert monitor.register_callback(slot, monitor.events.PY_START, record_scalar) is None
        monitor.set_local_events(slot, opener.__code__, monitor.events.PY_RETURN)
        monitor.set_local_events(slot, scalar.__code__, monitor.events.PY_START)
        # This explicit defining API control either calls the actual native
        # CloseHandle (real protected FALSE) or raises before touching exactly
        # that still-protected continuous incarnation. Other births use native.
        kernel.CloseHandle = observed_close
        with monkeypatch.context() as patch:
            if api == "scalar":
                patch.setattr(storage, "_posture", delegated_posture)
            with pytest.raises(files._AdmissionMetadataCloseError) as caught:
                with _native_returns(win) as ledger:
                    with _shipping_events(win, ledger) as shipping:
                        config._user_data_dir_stamps(paths)
        assert not shipping["errors"] and len(shipping["producer_errors"]) == 1
        producer_error, cause, context, suppression, original_tail, original_nodes = shipping["producer_errors"][0]
        assert caught.value is producer_error
        assert caught.value.__cause__ is cause
        assert caught.value.__context__ is context
        assert caught.value.__suppress_context__ is suppression
        assert original_tail is not None and original_nodes
        cursor = caught.value.__traceback__
        caller_code = sys._getframe().f_code
        outer_frames = 0
        while cursor is not original_tail:
            assert cursor is not None
            allowed = {caller_code, scalar.__code__, delegated_posture.__code__,
                       type(win).stat_for_admission.__code__}
            allowed.update(value for value in scalar.__code__.co_consts
                           if isinstance(value, CodeType) and value.co_name == "<genexpr>")
            assert cursor.tb_frame.f_code in allowed
            outer_frames += 1
            cursor = cursor.tb_next
        assert outer_frames == (5 if api == "scalar" else 2)
        for node, frame, code, line, successor in original_nodes:
            assert cursor is node and cursor.tb_frame is frame
            assert cursor.tb_frame.f_code is code and cursor.tb_lineno == line
            assert cursor.tb_next is successor
            cursor = cursor.tb_next
        assert cursor is None
        assert len(selected) == len(calls) == 1 and not errors
        assert helper_calls == [paths]
        assert delegated == ([(leaf, caller)] if api == "scalar" else [])
        assert shipping["starts"]["batch"] == 1
        assert shipping["starts"]["posture"] == (1 if api == "scalar" else 0)
        assert shipping["starts"]["helper"] == 1
        record = selected[0]
        assert caught.value.failed_handles == (record,)
        assert record.native is native and record.path == leaf and record.handle == calls[0]
        assert caught.value.errno == 5 and caught.value.strerror == 'windows_admission_metadata_not_retired'
        if outcome == 'raising':
            assert record.close_error is failure
        else:
            assert type(record.close_error) is int and record.close_error != 0
        flags = files._U32()
        native.check(get_flags(record.handle, C.byref(flags)))
        assert flags.value & 2
        info = native.info(record.handle)
        assert (info.volume, info.index_high << 32 | info.index_low) == record.identity
        _counts, _ancestry, births, _closes, observer_errors, excluded, _security = ledger
        retained = selected_births
        assert len(retained) == 1 and any(retained[0] is birth for birth in births) and not excluded
        assert retained[0]["handle"] == record.handle
        if outcome == 'protected_false':
            assert retained[0]['closes'] == [(False, record.close_error)]
        else:
            assert retained[0]['closes'] == []
        assert all(birth is retained[0] or birth['closes'] == [(True, 0)] for birth in births)
        assert observer_errors == ['native-birth-not-retired-once', 'post-drain-handle-still-valid']
        record_property('retained_close_without_fallback_or_retry', json.dumps({'api': api, 'outcome': outcome,
            'births': len(births), 'native_close_attempts_for_exact_owner': len(calls), 'helper_entries': len(helper_calls), 'delegated_scalar_calls': len(delegated), 'scalar_fallbacks_after_error': 0,
            'same_failed_owner': True, 'protected_physical_owner_still_valid': True,
            'same_actual_cause_context_suppression': True, 'original_traceback_tail_preserved': True,
            'expected_outer_caller_frames': outer_frames, 'same_shipping_error_object': True,
            'observer_retention_expected_not_retirement_claim': observer_errors}))
    finally:
        # Restore observer/defining API after original metadata call fully
        # returned; it has no asynchronous worker or outstanding native call.
        kernel.CloseHandle = real_close
        monitor_cleanup_errors = []
        if slot is not None:
            operations = (
                lambda: monitor.set_local_events(slot, opener.__code__, 0),
                lambda: monitor.set_local_events(slot, scalar.__code__, 0),
                lambda: monitor.register_callback(slot, monitor.events.PY_RETURN, None),
                lambda: monitor.register_callback(slot, monitor.events.PY_START, None),
                lambda: monitor.free_tool_id(slot),
            )
            for operation in operations:
                try:
                    operation()
                except BaseException as error:
                    monitor_cleanup_errors.append(type(error).__name__ + ":" + str(error))
        if selected and selected[0] in protected:
            record = selected[0]
            flags = files._U32()
            native.check(get_flags(record.handle, C.byref(flags)))
            assert flags.value & 2 and record.native is native
            info = native.info(record.handle)
            assert (info.volume, info.index_high << 32 | info.index_low) == record.identity
            native.check(set_flags(record.handle, 2, 0))
            native.check(real_close(record.handle))
            assert not get_flags(record.handle, C.byref(flags)) and C.get_last_error() == 6
            record_property("retained_fixture_finally_retired", json.dumps({
                "api": api, "outcome": outcome, "continuous_handle": record.handle,
                "continuous_identity": record.identity, "original_close_attempts": len(calls),
                "fixture_unprotected_then_native_closed": True, "native_invalid_error": 6,
                "scope": "fixture cleanup after original metadata outcome, including assertion failure",
            }, sort_keys=True))

        assert not monitor_cleanup_errors, monitor_cleanup_errors
