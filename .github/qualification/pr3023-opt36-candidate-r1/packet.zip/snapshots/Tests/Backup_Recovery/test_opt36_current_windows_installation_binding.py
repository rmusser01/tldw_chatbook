"""One current Windows installation capture; no metadata workload or native claim."""

import functools
import hashlib
import importlib.machinery
import json
import sys
from pathlib import Path

import pytest


@pytest.mark.bootstrap_profile
def test_current_windows_helper_retains_exact_installed_definition_capture(
    request, record_property
):
    import ac77_source_gate as gate_module
    import opt36_candidate_reader as reader_module
    from _pytest.assertion import rewrite

    from tldw_chatbook import config

    assert not sys.flags.optimize
    assert (
        hashlib.sha256(Path(reader_module.__file__).read_bytes()).hexdigest()
        == "0316231e094b7b0f2a07296ebfb27da0066dbb80ab71d2b24a91e5a83356a6f0"
    )
    assert (
        hashlib.sha256(Path(gate_module.__file__).read_bytes()).hexdigest()
        == "2e24fa486c043b8ce8526b33ca1dcf49806ac39a407079327cc3d439f7ea2666"
    )
    for module in (reader_module, gate_module):
        assert type(module.__loader__) is importlib.machinery.SourceFileLoader
        assert Path(module.__spec__.origin).resolve() == Path(module.__file__).resolve()
        assert module.__spec__.loader is module.__loader__
    root = Path(request.config.rootpath).resolve()
    target = root / "tldw_chatbook/config.py"
    assert Path(config.__file__).resolve() == target
    digest = hashlib.sha256(target.read_bytes()).hexdigest()
    assert digest == "47de2fc374da8c98431e4111ec76b5ca594974482bdac66514085094979d371b"
    files = sys.modules["tldw_chatbook.Utils.windows_files"]
    caches = (vars(files)["_native"], vars(files._Native)["_decoded_security"])
    for cache, capacity in zip(caches, (1, 128)):
        assert type(cache) is functools._lru_cache_wrapper
        assert (
            cache.cache_info.__self__ is cache
            and cache.cache_info.__name__ == "cache_info"
        )
        assert cache.cache_info().maxsize == capacity

    def cache_state():
        return [cache.cache_info()._asdict() for cache in caches]

    def monitor_state():
        return [
            (
                slot,
                sys.monitoring.get_tool(slot),
                sys.monitoring.get_events(slot)
                if sys.monitoring.get_tool(slot) is not None
                else None,
            )
            for slot in range(6)
        ]

    before_caches, before_monitor = cache_state(), monitor_state()
    profile, trace = sys.getprofile(), sys.gettrace()
    reader = reader_module.CandidateReader(root, request.config)
    reader.gate.loaded()
    reader._adapter_capture()
    reader._launcher()
    first, launcher = reader.adapter, reader.launcher
    assert tuple(map(len, first[2:])) == (25, 39, 3, 3)
    # The unchanged adapter moved by exactly 25 lines in the current config.
    assert first[0].__code__.co_firstlineno == 11054 + 25
    assert first[1].__code__.co_firstlineno == 11014 + 25
    for namespace, name, value in first[3]:
        assert namespace.get(name) is value
    reader.gate.unchanged()
    reader.gate.loaded()
    reader._adapter_capture()
    reader._launcher()
    assert all(a is b for a, b in zip(first, reader.adapter))
    assert launcher[0] is reader.launcher[0] and launcher[1:3] == reader.launcher[1:3]
    assert all(a is b for a, b in zip(launcher[3:], reader.launcher[3:]))
    for namespace, name, value in first[3]:
        assert namespace.get(name) is value
    for module, *_ in reader.gate.sources.values():
        assert type(module.__loader__) in (
            importlib.machinery.SourceFileLoader,
            rewrite.AssertionRewritingHook,
        )
        if not module.__name__.startswith("Tests."):
            assert type(module.__loader__) is importlib.machinery.SourceFileLoader
    reader.gate.unchanged()
    assert cache_state() == before_caches and monitor_state() == before_monitor
    assert sys.getprofile() is profile and sys.gettrace() is trace
    assert (
        reader.prepared is False
        and not reader.observers
        and not reader.shipping
        and not reader.children
    )
    assert "opt36_candidate_plugin" not in sys.modules
    record_property(
        "opt36_current_windows_installation",
        json.dumps(
            {
                "scope": "actual47de Windows installation metadata on approved component prefix only",
                "config_sha256": digest,
                "path": str(target),
                "gate": reader.gate.receipt(),
                "helper_qualname": first[0].__code__.co_qualname,
                "helper_line": first[0].__code__.co_firstlineno,
                "checker_qualname": first[1].__code__.co_qualname,
                "checker_line": first[1].__code__.co_firstlineno,
                "qualified_old_helper_line": 11054,
                "qualified_old_checker_line": 11014,
                "current_lexical_line_delta": 25,
                "records": 25,
                "bindings": 39,
                "wrapped_links": 4,
                "cached_receivers": 3,
                "canonical_modules": 3,
                "live_binding_rows_current_before_and_after": True,
                "capture_identities_unchanged": True,
                "native_cache_state_before_and_after": before_caches,
                "monitor_tools_before_and_after": before_monitor,
                "bridge_owned_monitor_ids": [],
                "profile_and_trace_unchanged": True,
                "launcher": {
                    "natural_name": "__main__",
                    "spec_name": "Tests.windows_private_fixture_runner",
                    "path": str(launcher[1]),
                    "sha256": hashlib.sha256(launcher[2]).hexdigest(),
                    "actual_main_stack_observed": True,
                },
                "extra_direct_factory_checker_helper_or_native_producer_calls": 0,
                "native_behavior_observers_run": False,
                "whole_current_goal_qualified": False,
                "whole_current_config_behavior_qualified": False,
                "excluded_incoming_callers": [
                    "set_encryption_password",
                    "clear_encryption_password",
                ],
                "limit": "ordinary startup may perform native I/O; no global call trace or captured TokenOwner/handle receipt",
            },
            sort_keys=True,
        ),
    )
