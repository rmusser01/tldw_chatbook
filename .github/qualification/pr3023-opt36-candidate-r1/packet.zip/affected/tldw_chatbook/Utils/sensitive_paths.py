# tldw_chatbook/Utils/sensitive_paths.py
"""Paths refused by the agent-facing file tools, regardless of configured root.

TWO independent agent file-tool families enforce this, and both must:

1. ``Tools/file_operation_tools.py``'s ``ReadFileTool``, ``WriteFileTool``,
   ``ListDirectoryTool``, ``GlobFiles`` and ``GrepFiles`` (sandbox-root
   confined) -- each calls :func:`is_sensitive_path` (directly, or through
   that module's ``is_within`` helper) on every candidate path immediately
   after path validation and before touching the filesystem.
2. The workspace-local ``fs_*``/``git_*`` family --
   ``Tools/local_tool_impls.py``'s ``resolve_workspace_path``, the single
   choke point through which every one of them resolves a path ARGUMENT
   (``Tools/patch_tool_impls.py``'s ``patch_files`` directly; the four
   repo-scoped tools in ``Tools/git_tool_impls.py`` one hop away, via
   ``prepare_repository``/``_prepare_for_path``/``_repo_relative_path``).

   Read what that sentence does and does not say. It covers a path the
   model NAMES. It does not make a tool's OUTPUT safe:

   * The three enumerating ``fs_*`` tools (``list_directory``/
     ``glob_files``/``grep_files``) present entries the model never named,
     so each additionally filters its own walked candidates against
     :func:`is_sensitive_path` -- the choke point only ever sees their
     root.
   * The ``git_*`` tools present entries the model never named too --
     ``path`` is OPTIONAL on ``git_status``/``git_log``/``git_diff``, and
     with it omitted nothing but the repository root reaches this module
     (``Agents/local_tool_provider.py``'s ``path_targets`` returns the
     repo root and stops). They do not filter git's OUTPUT; they
     constrain its INPUT, translating this module's denials into
     ``:(exclude)`` PATHSPECS computed per call from
     :func:`sensitive_exclusions_under` (see ``Tools/git_tool_impls.py``'s
     ``_denylist_pathspecs``). git stays the authority on what matches,
     and no diff or porcelain text is ever parsed to decide what to
     withhold -- a half-parsed diff is worse than none. TASK-19632, which
     that closed: on a ``$HOME``-rooted workspace containing
     ``~/.ssh/id_rsa``, ``git_diff`` with no ``path`` returned the file's
     CONTENT from a CLEAN worktree (``commit_range="HEAD~1..HEAD"`` reads
     it out of history -- no write primitive and no dirty tree needed),
     and ``git_diff(stat=True)`` / ``git_status`` returned its NAME.
     ``git_log`` leaked nothing (commit metadata only -- no paths, no
     content) and is deliberately left unfiltered, so its output is
     unchanged by any of this.

   One consequence of using pathspecs belongs here, where the denials are
   defined: **a pathspec is not a path**. A repository file whose NAME is
   itself pathspec magic (``:(exclude)notes.txt`` is a legal POSIX
   filename) inverts the scope of whatever argv it is spliced into --
   ``git_diff(path=":(exclude)notes.txt")`` was measured returning the
   whole-repo diff, ``~/.ssh/id_rsa``'s content included, while nominally
   scoping to that one file, and it did so THROUGH the choke point, since
   the string is a real filename that resolves inside the workspace. The
   ``--`` separator does not stop it: ``--`` ends OPTIONS, and everything
   after it is parsed as a pathspec, magic and all. Every pathspec those
   tools build is therefore rendered with explicit ``:(literal)`` /
   ``:(exclude,literal)`` magic, the model-supplied ``path`` included.

   This family was added AFTER this contract was written and, until
   TASK-19551, called none of this: it confined paths to ``[console]
   workspace_root`` and stopped there. With the shipped default root (the
   app's cwd at startup) an app launched from ``$HOME`` made ``$HOME`` the
   confinement root, so ``fs_read`` returned ``~/.ssh/id_rsa`` and
   ``fs_write``/``fs_patch`` could rewrite ``mcp_permissions.json`` -- the
   one-step gate bypass described below -- reachable by prompt injection
   from fetched web content. The failure was not a wrong check; it was an
   enforcer list that could only ever name the implementations existing
   when it was written, and a second family that never joined it. Hence
   the exception above is stated rather than smoothed over: **a new
   agent-facing file tool joins one of these two families; it does not get
   a third path-resolution seam** --
   ``Tests/Tools/test_local_tool_sensitive_paths.py`` pins that
   structurally (an AST tripwire over all three ``fs_*``/``git_*`` core
   modules) and pins the two families' agreement on the denylist, so they
   cannot drift apart again.

Two instruments express what is denied, and the choice between them is
made per case rather than by taste (TASK-19633):

* **Location rules** -- ``_SENSITIVE_DIRS`` plus the accessor-resolved
  paths further down -- for anything whose LOCATION is the unambiguous
  part. ``~/.ssh``, ``~/.aws``, ``~/.config/gh``: everything under them is
  credential material, and their filenames are NOT self-identifying
  (``hosts.yml`` is just as often an Ansible inventory).
* **A name rule** (``_SENSITIVE_FILE_NAMES``) for the handful of
  filenames that identify a credential store wherever they appear.
  Adopted after ``~/.netrc``, ``~/.git-credentials``, ``~/.npmrc``,
  ``~/.pypirc``, ``~/.cargo/credentials.toml`` and
  ``~/.config/gh/hosts.yml`` were each measured returning their body
  through ``fs_read``. A location rule cannot cover most of that set: the
  credential is not confined to one directory (a project-local
  ``.npmrc``/``.pypirc`` carries an auth token exactly like the home one,
  and a copy of ``credentials.toml`` is a credential wherever it lands),
  and refusing the whole of ``~/.cargo`` or ``~/.config/git`` would take
  down things an agent legitimately reads.

BOTH are enumerations and both trail reality -- names no less than
locations. The name rule is preferred where it applies because one entry
covers unbounded locations while one location entry covers exactly one,
and because a tool's config DIRECTORY migrates between XDG/legacy/OS
conventions far more often than its credential FILENAME ever changes. It
is kept deliberately small and biased toward names that are credential
stores by definition; a name is added only when a false refusal would be
a curiosity rather than routine obstruction -- which is why ``.env`` is
deliberately NOT here (as often build configuration as secrets, and
refusing it would break the ADR-032 coding-agent use case this module
must not break). The cost is real and accepted: an agent cannot read a
test fixture named ``credentials``, and the refusal names it as protected
rather than failing silently.

The two families' HIDDEN-COMPONENT policies still differ, and that
difference is design, not residue. Family 1 confines through
``validate_path_multi``, which defaults ``allow_hidden=False`` and so
refuses any dotted component before this module is consulted; family 2
passes ``allow_hidden=True`` (ADR-032 -- a coding agent that cannot read
``.github/`` or ``.gitignore`` is useless). Family 1 is therefore
strictly stricter for dotted NAMES, which is acceptable because the two
roots are different kinds of place: family 1's sandbox root is app-owned
storage where a dotfile has no legitimate purpose, while family 2's root
is a user source tree where dotfiles are the point. What must not differ
is THIS module's answer -- and since TASK-19633 it does not: every
credential path measured above is refused by the denylist itself, under
either family, so the part of the gap that was weaker-by-accident is
gone and only the deliberate difference remains.

This is *not* wired into
``Utils/path_validation.validate_path``/``validate_path_multi`` themselves:
those helpers are the app's general-purpose validators, used by ~40
first-party call sites (config screens, DB path resolution, exports, ...) to
validate paths to this application's own config and database files -- which
are exactly the paths this module refuses. Baking the check in there would
block legitimate first-party access; it belongs at the agent-tool boundary
instead, shared by every file tool, so they cannot drift from each other.

Two distinct reasons a path lands here:

1. **Credentials.** ``read_file`` carries no elevated risk beyond ``reads``,
   so an unconfined read is a path from a private key into a persisted
   transcript that may be sent to any provider.
2. **This application's own gate state and data.** A tool able to rewrite
   ``mcp_permissions.json`` or ``config.toml`` can turn every ``ask`` into
   ``allow`` -- a one-step bypass of the permission system. A tool able to
   read or rewrite this app's own SQLite databases can exfiltrate or
   corrupt every conversation, note and credential-adjacent record they
   hold, bypassing the application layer entirely.

Every one of those is resolved through the app's OWN accessors at call
time, never a hardcoded literal: ``config.toml``'s location honors the
``TLDW_CONFIG_PATH`` override (``config._get_effective_config_path()``),
the MCP permission store and its companions live under
``config.get_user_data_dir()`` (never under the legacy config-directory
literal a first look at ``app.py`` might suggest -- see
``_sensitive_single_file_paths()``), and the SQLite DB paths honor
``[database]`` overrides and the active user folder (see
``_sensitive_db_paths()``). A literal here would drift the moment any of
those is overridden -- which is exactly how the permission-store literal
went stale (Finding 1) and how a ``TLDW_CONFIG_PATH`` override defeated the
``config.toml`` entry (Finding 3).

Every file this app creates directly under ``get_user_data_dir()`` is also
refused, as a RULE rather than an enumeration (see the direct-child-file
loop in ``is_sensitive_path``): new state files land there constantly
(agent-run logs, eval/RAG-indexing/search-history/event/kanban/sync-state
DBs, ...) without ever touching ``config.py``, so an accessor-name
enumeration permanently trails reality. The SAME rule is applied to three
more directories, for the same reason: the effective config directory
(``config._get_effective_config_path().parent``, which honors
``TLDW_CONFIG_PATH`` the same way the config file itself does -- it holds
``config.toml``'s own ``.bak``/``.tmp`` backup sidecars plus
``runtime_policy.json``/``ui_state.toml``, none of which is enumerated by
name here either); the ChromaDB vector-store persist directory
(``RAG_Search.simplified.config.default_chroma_persist_directory()``,
which holds ``chroma.sqlite3`` -- plaintext chunks of the same
conversations and notes ``ChaChaNotes.db`` protects); and the RAG-profile
store (``RAG_Search.config_profiles.default_rag_profiles_dir()``, plaintext
per-profile RAG/embedding-provider config). Existing DIRECTORIES nested
directly under any of these four are excluded from the rule and stay fully
reachable -- most importantly the default file-tool sandbox root,
``get_user_data_dir() / "tool_sandbox"``; see that check's own comment for
why a directory/file distinction, not a name, is what exempts them.

The skill trust/grant store gets a DIFFERENT treatment: the WHOLE
``get_user_data_dir() / "skills" / "trust"`` subtree is refused, not just
its direct children, because ``skills`` itself is one of the exempted
container directories above and everything nested under it would otherwise
inherit that exemption -- see ``_sensitive_skill_trust_dir`` for why that
one subtree needs an explicit carve-out.

A directory can also be CREATED to collide with a not-yet-existing state
file at one of these locations (e.g. an agent asking ``write_file`` to
create parent directories for ``search_history.db/note.txt`` before this
app has ever created ``search_history.db`` as a file) -- the app's later
attempt to open its own state file then fails outright, a denial of
service. ``refuses_new_directory_chain`` is the guard against that: callers
that create directories on the agent's behalf (``WriteFileTool``'s
``create_directories=True`` path) must consult it before calling
``Path.mkdir(parents=True, ...)``.

This is a guardrail, not a security boundary: it stops accidents and naive
injected payloads, not a determined ``python -c``. The sandbox/workspace-root
track is the real answer for shell execution.
"""

from __future__ import annotations

import os
import threading
from pathlib import Path
from typing import Iterable, Literal, NamedTuple

#: Resolution failures seen on this thread; ``_raw_inputs`` never memoizes a
#: snapshot built while one occurred (it would keep a gap in the deny list).
_failures = threading.local()


def _debug(message: str) -> None:
    """Emit one resolution-failure diagnostic.

    Loguru is imported here rather than at module scope: this module sits
    inside the pinned workspace worker's stdlib-only import closure
    (Phase 0c), so merely importing it must not pull loguru. Every call
    site is a rare resolution-failure path, so the import cost lands only
    when a diagnostic is actually emitted — the same laziness rule the
    ``config``/Skills/RAG imports throughout this module already follow.

    Inside the remote worker bundle loguru does not exist (the import is a
    stub that raises ImportError), so the diagnostic is dropped there --
    raising would turn one unresolvable directory entry into a failed
    ``fs_list`` instead of a skipped entry.
    """
    _failures.count = getattr(_failures, "count", 0) + 1
    try:
        from loguru import logger
    except ImportError:
        return
    logger.debug(message)


#: Directory prefixes that are refused along with everything beneath them.
#: The LOCATION rule (see the module docstring): used where the directory
#: is unambiguously a credential store and its filenames are not
#: self-identifying. ``~/.config/gh`` joined in TASK-19633 for exactly
#: that reason -- it holds the GitHub CLI's OAuth tokens in
#: ``hosts.yml``, a filename far too generic to put in the name rule
#: below.
_SENSITIVE_DIRS = (
    "~/.ssh",
    "~/.aws",
    "~/.gnupg",
    "~/.config/gcloud",
    "~/.docker",
    "~/.kube",
    "~/.local/share/keyrings",
    "~/.config/gh",
)

#: The NAME rule (TASK-19633): filenames that identify a credential store
#: WHEREVER they appear, refused by name in addition to every location
#: rule. Compared case-folded, because the macOS and Windows filesystems
#: this app runs on are case-insensitive -- ``.NETRC`` opens the same file
#: an exact-case check would wave through. See the module docstring for
#: why a name rule earns its place here (and why ``.env`` does not).
#:
#: Matching is skipped for an existing DIRECTORY, mirroring the
#: direct-child-file rule's own ``is_dir()`` gate below: a directory named
#: ``credentials`` is a container, not a credential, and refusing it would
#: make everything under it unlistable. A path that does not exist is not
#: a directory either, so it still fails closed.
_SENSITIVE_FILE_NAMES = frozenset(
    name.casefold()
    for name in (
        ".netrc",  # curl/ftp/python-netrc credentials
        "_netrc",  # the same file's Windows spelling (and it is NOT dotted)
        ".git-credentials",  # git credential-store default
        ".npmrc",  # npm `_authToken` -- per-project as often as per-user
        ".pypirc",  # PyPI upload credentials
        "credentials",  # cargo (legacy), git credential-store under XDG
        "credentials.toml",  # cargo's current registry-token file
    )
)

#: NOTE: this app's own ``config.toml`` and the MCP-permission-store family
#: used to be listed here as static literals (``~/.config/tldw_cli/
#: config.toml``, ``~/.config/tldw_cli/mcp_permissions.json``). Both can
#: move at runtime -- ``config.toml`` honors the ``TLDW_CONFIG_PATH``
#: override, and the permission store's REAL location was never actually
#: ``~/.config/tldw_cli/`` at all; the app builds it under
#: ``get_user_data_dir()`` (see ``_sensitive_single_file_paths()`` below for
#: exactly how). A literal here would silently stop matching the moment
#: either moved -- which is precisely how the permission-store entry went
#: stale (Finding 1) and the ``config.toml`` entry missed a
#: ``TLDW_CONFIG_PATH`` override (Finding 3). Both are now resolved lazily,
#: the same way the DB paths are, by ``_sensitive_single_file_paths()``.

#: Names of the ``config`` accessors for this app's own SQLite databases.
#: Called lazily (see ``_sensitive_db_paths``) rather than imported at module
#: scope: ``config`` also honors ``[database] *_db_path`` overrides and a
#: per-test ``HOME``, so the real path can only be known at call time -- and
#: importing a large, slow module at ``Utils`` import time is itself a cost
#: worth avoiding when most callers never need it.
_DB_PATH_ACCESSOR_NAMES = (
    "get_chachanotes_db_path",
    "get_prompts_db_path",
    "get_media_db_path",
    "get_library_collections_db_path",
    "get_library_ingest_jobs_db_path",
    "get_workspaces_db_path",
    "get_subscriptions_db_path",
    "get_notifications_db_path",
    "get_research_db_path",
    "get_writing_db_path",
    "get_scheduled_tasks_db_path",
    # task-15465 fix round: both honor `[database] *_db_path` overrides via
    # `_get_custom_database_path` exactly like every accessor above, so an
    # override that relocates either DB outside `get_user_data_dir()` was
    # previously invisible to this enumeration (only the RULE below catches
    # a DB at its *default* location). Were previously missing here even
    # though `config.py` has carried both accessors since before this file's
    # own docstring named "eval/RAG-indexing ... DBs" as examples of state
    # this module means to cover.
    "get_evals_db_path",
    "get_rag_indexing_db_path",
)

#: Suffixes SQLite appends to a database's own filename for its sidecar
#: files: ``-wal``/``-shm`` under ``PRAGMA journal_mode=WAL`` (several of
#: this app's databases run in WAL mode) and ``-journal`` under the default
#: rollback-journal mode. Each sidecar holds the same class of recent data
#: as the database itself, so refusing only the ``.db`` path leaves them
#: readable the moment a sandbox/workspace root is widened to contain the
#: user data directory -- exactly the misconfiguration the DB denial exists
#: to guard against. Matching is exact-equality against a name built from
#: each enumerated DB's own filename (see ``_db_sidecar_paths``), never a
#: loose prefix: a file that merely *starts with* a DB's name (e.g.
#: ``chachanotes.db.backup-2026`` or ``chachanotes.db2``) is a different
#: file and is not matched by this.
_DB_SIDECAR_SUFFIXES = ("-wal", "-shm", "-journal")


def _resolved(path_str: str) -> Path | None:
    """Resolve a path string, returning ``None`` on ANY resolution failure.

    ``is_sensitive_path``'s fail-closed guarantee ("a path that cannot be
    resolved is treated as sensitive") depends on this returning ``None``
    for every way resolution can fail, not just the two most common ones.
    ``Path.resolve()``/``expanduser()`` normally raise ``OSError`` (e.g. a
    symlink loop) or ``RuntimeError`` (older Pythons' own loop-detection),
    but a path containing an embedded NUL byte raises ``ValueError``
    instead -- narrowing this catch to ``(OSError, RuntimeError)`` let that
    case escape ``is_sensitive_path`` entirely as an uncaught exception
    rather than the promised ``True`` (TASK-847). Broad by design: whatever
    exception ``pathlib`` raises for a candidate this function cannot make
    sense of, the caller must still get ``None`` back, never a propagated
    error.
    """
    try:
        return Path(path_str).expanduser().resolve()
    except Exception as exc:  # noqa: BLE001 - fail-closed for ANY resolution failure
        _debug(f"sensitive_paths: could not resolve {path_str!r}: {exc}")
        return None


def _sensitive_db_paths() -> tuple[Path, ...]:
    """Resolve this app's own SQLite database paths, lazily.

    These databases live under ``config.get_user_data_dir()`` -- by default
    a sibling of ``~/.config/tldw_cli`` (e.g. ``~/.local/share/tldw_cli/...``),
    not beneath it, so the static ``_SENSITIVE_DIRS`` tuple above cannot
    express their location. Each path is resolved via the app's own
    accessor (which also honors ``[database]`` path overrides and the
    active user folder) rather than hardcoded, since neither the user
    folder nor an override is known statically.

    Returns:
        Resolved paths to every database whose accessor could be called.
        An accessor that raises is skipped rather than failing the whole
        check -- it is additional coverage, not the primary guarantee.
    """
    from .. import config as _config

    resolved: list[Path] = []
    for accessor_name in _DB_PATH_ACCESSOR_NAMES:
        accessor = getattr(_config, accessor_name, None)
        if accessor is None:
            continue
        try:
            resolved.append(accessor())
        except Exception as exc:  # noqa: BLE001 - defensive, additive coverage only
            _debug(f"sensitive_paths: could not resolve {accessor_name}: {exc}")
    return tuple(resolved)


def _sensitive_single_file_paths() -> tuple[Path, ...]:
    """Resolve this app's own non-DB sensitive single files, lazily.

    Two families, each resolved through the same accessor the app itself
    uses to build the real path -- never a literal -- because both can move
    at runtime:

    1. **config.toml.** ``config._get_effective_config_path()`` honors the
       ``TLDW_CONFIG_PATH`` override (set throughout this project's own
       test suite, and by any deployment that relocates the config file).
       A literal default-path check misses the file actually holding the
       user's API keys whenever that override is set (Finding 3).
    2. **The MCP permission store and its companions.** The store's real
       path is ``get_user_data_dir() / "mcp_permissions.json"`` -- built by
       ``MCP.unified_control_plane_service``'s ``permission_store`` property
       as ``Path(store.path).with_name("mcp_permissions.json")``, where
       ``store.path`` is the ``LocalMCPStore`` path ``app.py`` constructs as
       ``get_user_data_dir() / "local_mcp_store.json"``. A tool able to
       rewrite this file can turn every ``ask`` into ``allow`` -- the
       CRITICAL one-step permission-gate bypass this module exists to
       prevent (Finding 1; see the module docstring). Two companions built
       the exact same ``Path(...).with_name(...)`` way from that same base
       path carry the same class of gate-relevant state:
       ``local_mcp_store.json`` itself (server definitions and their env)
       and ``mcp_execution_log.jsonl`` (the execution audit trail).

    Returns:
        Resolved paths for every file above whose accessor could be
        called. An accessor that raises is skipped rather than failing the
        whole check -- additional coverage, not the primary guarantee (see
        ``_sensitive_db_paths``, which does the same for the DB paths).
    """
    from .. import config as _config

    resolved: list[Path] = []

    try:
        resolved.append(_config._get_effective_config_path())
    except Exception as exc:  # noqa: BLE001 - defensive, additive coverage only
        _debug(f"sensitive_paths: could not resolve config.toml path: {exc}")

    try:
        user_data_dir = _config.get_user_data_dir()
    except Exception as exc:  # noqa: BLE001 - defensive, additive coverage only
        _debug(f"sensitive_paths: could not resolve user data dir: {exc}")
    else:
        resolved.append(user_data_dir / "mcp_permissions.json")
        resolved.append(user_data_dir / "local_mcp_store.json")
        resolved.append(user_data_dir / "mcp_execution_log.jsonl")

    return tuple(resolved)


def _sensitive_skill_trust_dir() -> Path | None:
    """Resolve this app's skill trust/grant store directory, lazily.

    ``get_user_data_dir() / "skills"`` is one of the existing-directory
    exemptions the direct-child-file rule (applied in ``is_sensitive_path``)
    carves out -- every trusted skill bundle lives as a named subdirectory
    under it, so a file inside it is deliberately NOT covered by that rule,
    letting agent tools browse/read a user's own skill bundles.

    The ``trust`` subdirectory nested one level inside it is the ONE
    exception carved back OUT of that exemption: it holds
    ``skill_trust_manifest.json`` (the authenticated trust manifest),
    ``skill_script_grants.json`` (the plain, UNAUTHENTICATED JSON file
    ``SkillTrustService.has_script_grant`` consults to authorize script
    EXECUTION -- deliberately kept outside the manifest's own HMAC+keyring
    integrity check; see ``Skills_Interop/skill_trust_service.py``),
    ``generation_marker.json`` (the local rollback-protection marker), and
    ``snapshots/`` (encrypted trusted-skill snapshots). A tool able to
    rewrite the grants file can authorize its own future script execution
    -- the same class of one-step gate bypass the MCP permission store's
    entry exists to prevent (see this module's docstring) -- so this
    caller refuses the WHOLE subtree by ancestry (the same way
    ``_SENSITIVE_DIRS`` is matched), not just its direct children: a file
    several levels inside ``snapshots/`` must be refused exactly like the
    manifest itself.

    Resolved via ``Skills_Interop.local_skills_service.default_local_skills_store_dir``
    and ``Skills_Interop.skill_trust_store.default_trust_store_dir`` -- the
    SAME functions ``app.py`` calls to build the live ``SkillTrustStore`` --
    never a re-spelled ``"skills"``/``"trust"`` literal, which would drift
    the moment either name changed (see this module's docstring for why
    that class of drift is exactly how a past finding went stale).

    Returns:
        The trust store directory, or ``None`` if ``get_user_data_dir()``
        could not be resolved.
    """
    from .. import config as _config
    from ..Skills_Interop.local_skills_service import default_local_skills_store_dir
    from ..Skills_Interop.skill_trust_store import default_trust_store_dir

    try:
        user_data_dir = _config.get_user_data_dir()
    except Exception as exc:  # noqa: BLE001 - defensive, additive coverage only
        _debug(f"sensitive_paths: could not resolve user data dir: {exc}")
        return None

    local_skills_store_dir = default_local_skills_store_dir(user_data_dir)
    return default_trust_store_dir(local_skills_store_dir)


def _direct_child_rule_container_dirs() -> tuple[Path, ...]:
    """Resolve every directory whose direct (non-recursive) child FILES are refused, lazily.

    Each of these is a directory this app treats as a bounded container for
    its own state, where new files land constantly without ever being
    named here individually -- this is the set the "Finding 2" rule in
    ``is_sensitive_path`` applies to. Existing DIRECTORIES nested directly
    inside any one of them (``tool_sandbox``, ``chat_dicts``, ``chromadb``,
    ``exports``, ``rag_profiles``, ``skills``, and any future sibling) are
    exempt from the rule and stay fully reachable; only a same-level FILE
    is refused. See that rule's own comment for why "is an existing
    directory", not a name, is what exempts them.

    Returns:
        Every container directory whose accessor could be resolved:

        * ``config.get_user_data_dir()``.
        * The effective config directory
          (``config._get_effective_config_path().parent``) -- honors
          ``TLDW_CONFIG_PATH`` the same way the config file itself does.
          This is what covers ``config.toml``'s own ``.bak``/``.tmp``
          backup sidecars (``UI/Screens/settings_screen.py``'s Advanced
          config save writes both, byte-identical to the live config,
          API keys included) and any other loose file dropped beside it
          (``runtime_policy.json``, ``ui_state.toml``, a hand-made backup
          copy under any other name) -- none of which is enumerated here
          by name either, for the same reason the user-data-dir rule
          isn't: an enumeration permanently trails whatever gets written
          there next.
        * The ChromaDB vector-store persist directory
          (``RAG_Search.simplified.config.default_chroma_persist_directory()``),
          which holds ``chroma.sqlite3`` -- plaintext chunks of the same
          conversations and notes ``ChaChaNotes.db`` protects.
        * The RAG-profile store directory
          (``RAG_Search.config_profiles.default_rag_profiles_dir()``),
          plaintext per-profile RAG/embedding-provider config.

        An accessor that raises is skipped rather than failing the whole
        check, as elsewhere in this module.
    """
    from .. import config as _config
    from ..RAG_Search.config_profiles import default_rag_profiles_dir
    from ..RAG_Search.simplified.config import default_chroma_persist_directory

    resolved: list[Path] = []

    try:
        resolved.append(_config.get_user_data_dir())
    except Exception as exc:  # noqa: BLE001 - defensive, additive coverage only
        _debug(f"sensitive_paths: could not resolve user data dir: {exc}")

    try:
        resolved.append(_config._get_effective_config_path().parent)
    except Exception as exc:  # noqa: BLE001 - defensive, additive coverage only
        _debug(f"sensitive_paths: could not resolve effective config dir: {exc}")

    try:
        resolved.append(default_chroma_persist_directory())
    except Exception as exc:  # noqa: BLE001 - defensive, additive coverage only
        _debug(f"sensitive_paths: could not resolve chroma persist dir: {exc}")

    try:
        resolved.append(default_rag_profiles_dir())
    except Exception as exc:  # noqa: BLE001 - defensive, additive coverage only
        _debug(f"sensitive_paths: could not resolve rag profiles dir: {exc}")

    return tuple(resolved)


def _db_sidecar_paths(db_path: Path) -> tuple[Path, ...]:
    """Build the WAL/SHM/rollback-journal sidecar paths for one DB path.

    Args:
        db_path: A resolved path to one of this app's SQLite databases, as
            returned by ``_sensitive_db_paths()``.

    Returns:
        One path per entry in ``_DB_SIDECAR_SUFFIXES``, each formed by
        appending the suffix to ``db_path``'s own filename -- e.g.
        ``chachanotes.db`` -> ``chachanotes.db-wal``. Built from an explicit
        name construction, not a prefix, so callers must compare by exact
        equality: appending is not the same as matching anything that
        merely starts with the DB's name.
    """
    return tuple(
        db_path.with_name(db_path.name + suffix) for suffix in _DB_SIDECAR_SUFFIXES
    )


class SensitivePathContext(NamedTuple):
    """A snapshot of the resolved sensitive-path set, valid for one tool call.

    Building one of these costs the same 11 config-accessor resolutions
    ``is_sensitive_path`` would otherwise repeat on every invocation. A
    caller that tests many candidate paths within a single tool invocation
    (``GlobFiles``/``GrepFiles`` and ``ListDirectoryTool``'s recursive walk,
    all in ``Tools/file_operation_tools.py``) should build exactly ONE of
    these at the start of that invocation and pass it into every
    ``is_sensitive_path``/``is_within`` call it makes, rather than let each
    call re-resolve the set from scratch.

    Deliberately not cached at module or process scope -- see
    ``resolve_sensitive_context`` (only its raw inputs are memoized).
    """

    files: tuple[Path, ...]
    dirs: tuple[Path, ...]
    db_paths: tuple[Path, ...]
    #: Resolved ``config.get_user_data_dir()``, or ``None`` if it could not
    #: be resolved. Kept as its own field for callers/tests that care about
    #: this one specific directory; the direct-child-file rule itself now
    #: consults ``direct_child_denied_dirs`` below, which already includes
    #: this value alongside the other container directories that get the
    #: same treatment.
    user_data_dir: Path | None
    #: Every directory whose direct (non-recursive) child FILES are
    #: refused -- ``user_data_dir``, the effective config directory, the
    #: ChromaDB persist directory, and the RAG-profile store directory (see
    #: ``_direct_child_rule_container_dirs``). Entries that failed to
    #: resolve are dropped, same as ``files``/``dirs``/``db_paths``.
    direct_child_denied_dirs: tuple[Path, ...]


#: PERF-07 (TASK-33266; ADR-126 amendment D2): the raw, config-derived inputs
#: of ``resolve_sensitive_context`` -- ``(key, inputs)`` or None, guarded by the
#: lock. Every path in them is still resolved on each call.
_RAW_INPUTS_MEMO: tuple | None = None
_RAW_INPUTS_LOCK = threading.Lock()


def _raw_inputs() -> tuple:
    """Return the unresolved sensitive paths, memoized on the config and data dir.

    The key is the config cache object (by identity) and its generation, the
    effective config path, the user data directory -- itself re-verified on
    every call by ``config.get_user_data_dir`` -- the whole environment,
    since accessors read overrides such as ``RAG_PERSIST_DIR`` that outrank
    config, and the working directory a relative custom database path is
    resolved against. So a config reload or write, any environment change, a
    moved data directory or a directory change is observed on the very next
    call. A snapshot built while
    any accessor failed is never kept: it would carry a gap in the deny list.

    Returns:
        ``(user_data_dir, single_files, skill_trust_dir, db_paths,
        container_dirs)``, unresolved.
    """
    global _RAW_INPUTS_MEMO
    user_data_dir, config_path, key = _raw_inputs_key()
    with _RAW_INPUTS_LOCK:
        memo = _RAW_INPUTS_MEMO
    if memo is not None and _same_key(memo[0], key):
        return memo[1]
    failures = getattr(_failures, "count", 0)
    inputs = (
        user_data_dir,
        _sensitive_single_file_paths(),
        _sensitive_skill_trust_dir(),
        _sensitive_db_paths(),
        _direct_child_rule_container_dirs(),
    )
    # The accessors read the live config and environment, so inputs built
    # while either moved describe some other key; keeping them could serve a
    # deny list with a gap once the override returns to this key's value.
    if (
        user_data_dir is not None
        and config_path is not None
        and getattr(_failures, "count", 0) == failures
        and _same_key(key, _raw_inputs_key()[2])
    ):
        with _RAW_INPUTS_LOCK:
            _RAW_INPUTS_MEMO = (key, inputs)
    return inputs


def _raw_inputs_key() -> tuple:
    """Read what the raw inputs depend on, as ``_raw_inputs``' memo key.

    Returns:
        ``(user_data_dir, config_path, key)``; either of the first two is
        ``None`` when it could not be resolved, and such a key is not memoized.
    """
    from .. import config as _config

    try:
        user_data_dir = _config.get_user_data_dir()
    except Exception as exc:  # noqa: BLE001 - defensive, additive coverage only
        _debug(f"sensitive_paths: could not resolve user data dir: {exc}")
        user_data_dir = None
    try:
        config_path = str(_config._get_effective_config_path())
        # A relative custom database path is made absolute against it.
        cwd = os.getcwd()
    except Exception:  # noqa: BLE001 - an unkeyable call is simply not memoized
        config_path = cwd = None
    key = (
        _config._CONFIG_CACHE,
        _config._CONFIG_GENERATION,
        _config._CONFIG_CACHE_SOURCE,
        config_path,
        str(user_data_dir),
        os.environ.copy(),
        cwd,
    )
    return user_data_dir, config_path, key


def _same_key(left: tuple, right: tuple) -> bool:
    """Compare two memo keys: the config cache by identity, the rest by value.

    Args:
        left: A key from ``_raw_inputs_key``.
        right: Another key from ``_raw_inputs_key``.

    Returns:
        True when both describe the same config object, generation, source,
        paths and environment.
    """
    return left[0] is right[0] and left[1:] == right[1:]


def resolve_sensitive_context() -> SensitivePathContext:
    """Resolve the full sensitive-path set once, for reuse across many checks.

    Call this ONCE per tool invocation and thread the result through to
    every ``is_sensitive_path``/``is_within`` call that invocation makes.
    Do NOT cache the returned context at module or process scope. Its paths
    are resolved (symlinks followed) on every call, so a filesystem change
    is seen at once. PERF-07 memoizes only the raw, config-derived inputs
    (``_raw_inputs``), keyed on the config cache identity, generation and
    source, the effective config path, the re-verified user data directory,
    the whole environment and the working directory, so a config change (e.g.
    the test suite swapping ``TLDW_CONFIG_PATH`` between cases), an override
    such as ``RAG_PERSIST_DIR`` or a directory change is observed on the very
    next call rather than serving a stale answer.

    Returns:
        A ``SensitivePathContext`` snapshotting the currently configured
        sensitive files, directories, database paths, and user data
        directory (entries that failed to resolve are dropped; the user
        data directory is ``None`` if it could not be resolved).
    """
    raw_user_dir, single_files, skill_trust_dir, db_paths, containers = _raw_inputs()
    user_data_dir = _resolved(str(raw_user_dir)) if raw_user_dir is not None else None
    dynamic_dirs = (skill_trust_dir,) if skill_trust_dir is not None else ()

    return SensitivePathContext(
        files=tuple(
            p for p in (_resolved(str(raw)) for raw in single_files) if p is not None
        ),
        dirs=tuple(
            p
            for p in (_resolved(str(entry)) for entry in _SENSITIVE_DIRS + dynamic_dirs)
            if p is not None
        ),
        db_paths=tuple(
            p for p in (_resolved(str(raw)) for raw in db_paths) if p is not None
        ),
        user_data_dir=user_data_dir,
        direct_child_denied_dirs=tuple(
            p for p in (_resolved(str(raw)) for raw in containers) if p is not None
        ),
    )


# Direct call-shape anchor; no sensitive-path data is retained.
_RESOLVE_SENSITIVE_CONTEXT_ORIGINAL = (resolve_sensitive_context, resolve_sensitive_context.__code__, resolve_sensitive_context.__defaults__)


def merge_sensitive_context(
    base: SensitivePathContext,
    *,
    extra_files: Iterable[Path] = (),
    extra_dirs: Iterable[Path] = (),
) -> SensitivePathContext:
    """Fold per-workspace user exclusions into a per-call context snapshot.

    The workspace-exclusions injection point (spec 2026-09-20): extras join
    ``files``/``dirs`` resolved and deduped by the denylist's own
    ``_compare_key`` discipline, so ``is_sensitive_path``,
    ``sensitive_exclusions_under``, and ``refuses_new_directory_chain``
    enforce them with no further call-site changes. Extras that fail
    resolution are dropped, mirroring how the base set's own unresolved
    entries are dropped.

    Args:
        base: The call's base sensitive-path context (denylist plus any
            earlier folds).
        extra_files: Additional absolute file paths to protect (e.g.
            per-binding user exclusions of file kind).
        extra_dirs: Additional absolute directory paths to protect; a
            directory entry also shields its descendants.

    Returns:
        A new ``SensitivePathContext`` with the extras merged in; ``base``
        is never mutated. Unresolvable extras are silently omitted.
    """
    files = list(base.files)
    dirs = list(base.dirs)
    seen_files = {_compare_key(p) for p in files}
    seen_dirs = {_compare_key(p) for p in dirs}
    for raw in extra_files:
        resolved = _resolved(str(raw))
        if resolved is None:
            continue
        key = _compare_key(resolved)
        if key not in seen_files:
            seen_files.add(key)
            files.append(resolved)
    for raw in extra_dirs:
        resolved = _resolved(str(raw))
        if resolved is None:
            continue
        key = _compare_key(resolved)
        if key not in seen_dirs and key not in seen_files:
            seen_dirs.add(key)
            dirs.append(resolved)
    return base._replace(files=tuple(files), dirs=tuple(dirs))


def _compare_key(path: Path) -> tuple[str, ...]:
    """The form two paths are compared in by the denylist (TASK-19800).

    macOS and Windows filesystems are case-insensitive by DEFAULT, and
    ``Path.resolve()`` does NOT canonicalise case on them -- it resolves
    symlinks and ``..`` but preserves whatever spelling the caller typed.
    So ``~/.SSH/id_rsa`` opens the very same file as ``~/.ssh/id_rsa``
    while comparing unequal to every entry in the denylist. Verified
    end-to-end before this fix: reading ``TLDW_CLI/config.toml`` through
    ``fs_read`` returned the user's real config -- the file holding their
    provider API keys -- while the lowercase spelling was refused.

    Casefolding is applied UNCONDITIONALLY rather than gated on the
    platform or probed per volume. Platform is only a proxy for the real
    question (macOS can be configured case-sensitive; Linux can mount a
    case-insensitive volume), a per-path probe would add I/O to a check
    that runs on every candidate, and the two error directions are not
    symmetric: over-refusing a genuinely distinct ``~/.SSH`` on a
    case-sensitive filesystem costs one explained refusal of a very
    unusual path, while under-refusing leaks a credential. A denylist
    should fail in the cheap direction.

    Comparison stays COMPONENT-wise, so ancestry and lookalike behaviour
    are unchanged: ``~/.sshfoo`` is still not ``~/.ssh``.

    **Do not reuse this for CONFINEMENT checks.** The two fail in opposite
    directions. For a denylist ("is this path forbidden?") folding produces
    extra refusals -- it fails safe. For confinement ("is this path inside
    the allowed root?") folding produces extra ADMISSIONS: on a
    case-sensitive filesystem ``/Root/evil`` would start counting as inside
    ``/root``, which is a loosening, not a hardening. ``is_within`` in
    ``Tools/file_operation_tools.py`` is deliberately left case-sensitive
    for exactly that reason.

    Args:
        path: An already-resolved absolute path.

    Returns:
        The path's components, each casefolded.
    """
    return tuple(part.casefold() for part in path.parts)


def _same_path(a: Path, b: Path) -> bool:
    """Whether two resolved paths denote the same file (see :func:`_compare_key`)."""
    return _compare_key(a) == _compare_key(b)


def _is_within(child: Path, ancestor: Path) -> bool:
    """Whether ``child`` is ``ancestor`` or below it (see :func:`_compare_key`)."""
    child_key = _compare_key(child)
    ancestor_key = _compare_key(ancestor)
    return child_key[: len(ancestor_key)] == ancestor_key


def _name_key(path: Path) -> str:
    """The final component of ``path``, in the same folded form (TASK-19633).

    The name rule's half of :func:`_compare_key`. Kept here rather than
    spelled ``path.name.casefold()`` at the one call site so this module
    has exactly ONE definition of how two path spellings are compared --
    the property TASK-19800 established and the reason a name rule could
    be added without opening a second normalization path.
    """
    key = _compare_key(path)
    return key[-1] if key else ""


def is_sensitive_path(
    candidate: Path, context: SensitivePathContext | None = None
) -> bool:
    """Whether ``candidate`` is a credential, gate-state, or app-state path.

    Comparison is by RESOLVED ancestry, never by string prefix, so
    ``~/.sshfoo`` is not mistaken for ``~/.ssh`` and a symlink cannot
    smuggle a path past the check. Each enumerated database's WAL/SHM/
    rollback-journal sidecar files are refused by the same exact-equality
    rule (see ``_db_sidecar_paths``), since they carry the same class of
    recent data as the database itself.

    This function only decides the question; it enforces nothing by
    itself. Callers must call it explicitly on their target before touching
    the filesystem:

    * ``ReadFileTool.execute``, ``WriteFileTool.execute``,
      ``ListDirectoryTool.execute``, ``GlobFiles.execute`` and
      ``GrepFiles.execute`` in ``Tools/file_operation_tools.py`` (directly,
      or via that module's ``is_within``).
    * ``Tools/local_tool_impls.py``'s ``resolve_workspace_path`` -- the
      choke point the workspace-local ``fs_*``/``git_*`` family resolves
      its path ARGUMENTS through -- plus the per-candidate filters in
      ``list_directory``/``glob_files``/``grep_files`` there (TASK-19551).
      The ``git_*`` tools additionally translate this function's denials
      into git ``:(exclude)`` pathspecs, via
      :func:`sensitive_exclusions_under`, so git never reports a denied
      path in the first place (TASK-19632); see this module's docstring.

    Args:
        candidate: The path a tool intends to touch.
        context: An optional pre-resolved ``SensitivePathContext`` from
            ``resolve_sensitive_context()``. Pass one in when checking many
            candidates within a single tool invocation, so the sensitive-path
            set is resolved once instead of once per candidate. Leave this
            ``None`` (the default) for a one-off, single-path check -- that
            keeps this function's resolution genuinely per-call, which is
            what lets it observe a config-path switch (e.g. the test suite's
            ``TLDW_CONFIG_PATH`` swaps) without going stale.

    Returns:
        True when the path is refused. Fails CLOSED: a path that cannot be
        resolved is treated as sensitive.
    """
    resolved = _resolved(str(candidate))
    if resolved is None:
        return True

    ctx = context if context is not None else resolve_sensitive_context()

    # Every comparison below goes through `_compare_key` (TASK-19800): a
    # case-variant spelling reaches the same file on a case-insensitive
    # filesystem and must reach the same verdict.
    for target in ctx.files:
        if _same_path(resolved, target):
            return True

    for db_path in ctx.db_paths:
        if _same_path(resolved, db_path):
            return True
        if any(_same_path(resolved, s) for s in _db_sidecar_paths(db_path)):
            return True

    for root in ctx.dirs:
        if _is_within(resolved, root):
            return True

    # TASK-19633: the NAME rule, applied wherever the file sits. See the
    # module docstring for why this instrument exists alongside the
    # location rules above and why it is kept small. `is_dir()` exempts a
    # container directory that happens to carry one of these names; a
    # path that does not exist yet is not a directory, so it still fails
    # closed.
    #
    # Normalized through `_compare_key` like every comparison above, NOT
    # through a second casefold of its own: TASK-19800 made this module's
    # folding rule one function on purpose, and a security primitive with
    # two independently-normalized comparison paths is how they drift.
    if _name_key(resolved) in _SENSITIVE_FILE_NAMES and not resolved.is_dir():
        return True

    # Finding 2 (substrate review), generalized beyond `get_user_data_dir()`
    # to every container directory `_direct_child_rule_container_dirs()`
    # resolves (also the effective config directory, the ChromaDB persist
    # directory, and the RAG-profile store -- TASK-848): refuse every FILE
    # sitting directly (non-recursively) inside one of them, as a RULE
    # rather than an enumeration. New state files land there constantly
    # without ever touching config.py -- agent-run logs, eval/RAG-indexing/
    # search-history/event/kanban/sync-state DBs, the MCP local-store/
    # context JSON files, the rotating app log, config.toml's own
    # `.bak`/`.tmp` backup sidecars -- and an accessor-name enumeration
    # (`_DB_PATH_ACCESSOR_NAMES` above) permanently trails whatever the app
    # actually creates there next.
    #
    # Checked by "is it a directory", never by name: every legitimate use
    # of one of these directories as a CONTAINER creates a named
    # subdirectory instead of a loose file directly inside it -- e.g.
    # `tool_sandbox` (the default file-tool sandbox root itself),
    # `chat_dicts`, `chromadb`, `exports`, `rag_profiles`, `skills` nested
    # under `get_user_data_dir()`. Excluding "is an existing directory"
    # rather than hardcoding any of those names keeps every one of them
    # reachable, including ones added later, without needing this rule to
    # be updated in lockstep -- while a candidate that does not exist yet
    # (e.g. a `write_file` target for a brand-new file) is NOT a directory
    # either, so it still fails closed and is refused. TASK-849: that same
    # gate means an agent COULD plant a directory at a name the app has
    # never used yet (before this check ever sees it as "existing") --
    # closing that hole is `refuses_new_directory_chain` below, consulted
    # by callers BEFORE they create a directory on the agent's behalf,
    # never by loosening this check's own "is a directory" gate (which
    # would break every legitimate container above).
    for denied_parent in ctx.direct_child_denied_dirs:
        if _same_path(resolved.parent, denied_parent) and not resolved.is_dir():
            return True

    return False


# Direct call-shape anchor; no sensitive-path data is retained.
_IS_SENSITIVE_PATH_ORIGINAL = (is_sensitive_path, is_sensitive_path.__code__, is_sensitive_path.__defaults__)


class SensitiveExclusion(NamedTuple):
    """One denial of :func:`is_sensitive_path`, expressed relative to a root.

    Produced by :func:`sensitive_exclusions_under` for callers that cannot
    ask this module about each candidate one at a time because they never
    see the candidates -- the ``git_*`` tools, which hand a whole
    repository to ``git`` and get finished output back. Such a caller
    translates these into whatever exclusion syntax its own subprocess
    speaks (git pathspecs, in the only current case) instead of parsing
    that output to decide what to withhold.

    Attributes:
        kind: Which rule produced this denial.

            * ``"subtree"`` -- ``value`` and everything beneath it.
            * ``"file"`` -- exactly ``value``.
            * ``"direct_children"`` -- the direct, non-recursive child
              FILES of the directory ``value`` (never anything deeper,
              and never the subdirectories themselves): the
              container-directory rule in :func:`is_sensitive_path`.
            * ``"name"`` -- any file named ``value`` at ANY depth under
              the root: the TASK-19633 name rule.
        value: For every kind but ``"name"``, a POSIX path RELATIVE to
            the root passed to :func:`sensitive_exclusions_under`, and
            the empty string when it IS that root (possible only for
            ``"subtree"`` -- the whole root is denied, which a caller
            must treat as "refuse outright", there being nothing left to
            show -- and for ``"direct_children"``). For ``"name"``, a
            bare filename, not a path.
    """

    kind: Literal["subtree", "file", "direct_children", "name"]
    value: str


def _relative_within(root: Path, candidate: Path) -> str | None:
    """POSIX path of ``candidate`` relative to ``root``, or ``None`` if outside.

    Returns ``""`` when ``candidate`` IS ``root`` (both already resolved).

    Containment is decided by :func:`_is_within`, i.e. through the SAME
    folded key every other denylist comparison uses (TASK-19800), not by
    ``Path.relative_to``'s exact-case parts. ``root`` here is a repository
    root the caller resolved from git's own output while the candidates
    come from config accessors and ``$HOME``; on a case-insensitive
    filesystem those two chains can legitimately disagree about the
    spelling of a shared ancestor, and an exclusion that silently decides
    "outside the repository" for that reason would be a hole, not a
    no-op.

    The RETURNED value is built from the candidate's own components, not
    the folded ones -- the folding decides the relationship, never what
    gets rendered.
    """
    if _same_path(candidate, root):
        return ""
    if not _is_within(candidate, root):
        return None
    return Path(*candidate.parts[len(root.parts) :]).as_posix()


def sensitive_exclusions_under(
    root: Path, context: SensitivePathContext | None = None
) -> tuple[SensitiveExclusion, ...]:
    """Every denial that could match something inside ``root``.

    The bridge for callers that delegate enumeration to a subprocess and
    therefore cannot consult :func:`is_sensitive_path` per candidate --
    today only ``Tools/git_tool_impls.py``, which renders these as git
    ``:(exclude)`` pathspecs so ``git diff``/``git status`` never emit a
    denied path's name or content (TASK-19632).

    This function is deliberately the ONE place that enumerates the
    module's rules for that purpose, so a denial added to
    :func:`is_sensitive_path` flows into those tools by being added here
    rather than by someone remembering to update a second list in a
    different package. ``Tests/Tools/test_git_tool_sensitive_paths.py``
    pins the two against each other.

    Args:
        root: The directory the exclusions will be expressed relative to
            (a repository root, in the current caller). Resolved here.
        context: Optional pre-resolved ``SensitivePathContext``; see
            ``resolve_sensitive_context``.

    Returns:
        Deduplicated ``SensitiveExclusion`` entries, in a deterministic
        order. Location-based denials that fall entirely OUTSIDE ``root``
        are omitted (nothing under the root can match them); the name
        rule is always present, since it can match at any depth.
    """
    ctx = context if context is not None else resolve_sensitive_context()
    resolved_root = _resolved(str(root))
    if resolved_root is None:
        # Fail closed the same way `is_sensitive_path` does: a root we
        # cannot resolve gets the most restrictive answer available.
        return (SensitiveExclusion("subtree", ""),)

    found: list[SensitiveExclusion] = []
    seen: set[SensitiveExclusion] = set()

    def _record(kind: str, value: str) -> None:
        entry = SensitiveExclusion(kind, value)  # type: ignore[arg-type]
        if entry not in seen:
            seen.add(entry)
            found.append(entry)

    for denied_dir in ctx.dirs:
        relative = _relative_within(resolved_root, denied_dir)
        if relative is not None:
            _record("subtree", relative)

    denied_files: list[Path] = list(ctx.files)
    for db_path in ctx.db_paths:
        denied_files.append(db_path)
        denied_files.extend(_db_sidecar_paths(db_path))
    for denied_file in denied_files:
        relative = _relative_within(resolved_root, denied_file)
        if relative:  # "" would mean the root itself is a file -- not possible
            _record("file", relative)

    for container in ctx.direct_child_denied_dirs:
        relative = _relative_within(resolved_root, container)
        if relative is not None:
            _record("direct_children", relative)

    for name in sorted(_SENSITIVE_FILE_NAMES):
        _record("name", name)

    return tuple(found)


def find_root_binding_conflict(
    root: Path, context: SensitivePathContext | None = None
) -> Path | None:
    """Whether granting recursive access under ``root`` would reach a protected path.

    TASK-857: consulted by ``Workspaces.registry_service.add_folder_binding``,
    the gate that decides whether a folder root may be bound as an
    additional file-tool access root (``Tools/workspace_file_roots.py``
    layers every bound folder on top of the sandbox root, and the file
    tools then trust any path under any of them, subject only to the
    the per-path checks below). That is a fundamentally different question
    from ``is_sensitive_path``'s: that function asks whether one candidate
    READ/WRITE target falls inside a denied area; this asks whether an
    entire subtree about to be granted blanket, recursive reachability
    conflicts with one, which matters in BOTH directions:

    1. ``root`` itself resolves to, or under, one of the fixed sensitive
       directories (``~/.ssh``, ``~/.aws``, ..., the skill-trust subtree)
       or one of this app's own state-container directories
       (``get_user_data_dir()``, the effective config directory, the
       ChromaDB persist directory, the RAG-profile directory). Binding a
       root already inside one of these would make everything else in
       there reachable too -- including subdirectories
       ``is_sensitive_path``'s direct-child-file rule deliberately leaves
       alone for per-path reads (e.g. ``tool_sandbox`` nested under
       ``get_user_data_dir()``), because that rule was designed to catch
       stray loose files in an otherwise-normal directory, not to make an
       entire application-state directory safe to use as a binding root.
       Nothing legitimate needs to bind these directly: the sandbox root
       is already included automatically by
       ``Tools.workspace_file_roots.allowed_file_roots`` without ever
       going through this gate.
    2. ``root`` is coarse enough to CONTAIN one of those same directories
       or one of this app's sensitive single files/database paths -- e.g.
       binding ``~/.local/share`` (which contains ``get_user_data_dir()``
       on a typical Linux install) or ``~/.config`` (which contains
       ``~/.config/tldw_cli``). ``root`` need not itself look sensitive
       for this direction to matter.

    Args:
        root: The already-resolved candidate folder-binding root.
        context: Optional pre-resolved ``SensitivePathContext``; see
            ``resolve_sensitive_context``.

    Returns:
        The protected path ``root`` conflicts with, or ``None`` if it
        conflicts with nothing this module tracks. The returned path is
        meant to be named directly in the caller's rejection message, so
        the user can see exactly what stood in the way. When more than one
        protected path would match, the most specific/direct relationship
        wins, in this priority order: (1) ``root`` IS the protected path
        itself, (2) ``root`` is nested INSIDE a protected directory --
        ties broken toward the DEEPEST (closest, most specific) enclosing
        directory, (3) ``root`` CONTAINS a protected directory or file --
        ties broken toward the SHALLOWEST (closest, most immediate)
        contained path. E.g. binding ``get_user_data_dir()`` itself is
        reported as case (1) even though it also technically contains the
        skill-trust subtree several levels down (case (3)); binding
        ``get_user_data_dir()``'s own PARENT is reported as containing
        ``get_user_data_dir()`` itself (the nearest contained protected
        directory), not the more deeply nested skill-trust subtree beneath
        it -- naming the closest conflict is more actionable than naming
        an obscure one several levels further away.
    """
    ctx = context if context is not None else resolve_sensitive_context()

    protected_dirs = ctx.dirs + ctx.direct_child_denied_dirs
    protected_files: list[Path] = list(ctx.files)
    for db_path in ctx.db_paths:
        protected_files.append(db_path)
        protected_files.extend(_db_sidecar_paths(db_path))

    # (1) `root` IS a protected path itself -- the most direct, most
    # actionable case, checked before either containment direction so it
    # always wins when several apply at once.
    # TASK-19800 / Qodo (PR #1936): this gate enforces the same
    # protected-path policy as `is_sensitive_path`, so it compares through
    # the same case-folded key. It is NOT a confinement check -- folding
    # here reports MORE conflicts (fails safe); see `_compare_key`.
    for protected in tuple(protected_dirs) + tuple(protected_files):
        if _same_path(root, protected):
            return protected

    # (2) `root` is nested INSIDE a protected directory. Several enclosing
    # directories can match at once (e.g. the skill-trust subtree nested
    # inside `get_user_data_dir()`); the one with the MOST path parts is
    # the deepest/closest enclosing directory, hence the most specific.
    nested_inside = [
        protected
        for protected in protected_dirs
        if _is_within(root, protected) and not _same_path(root, protected)
    ]
    if nested_inside:
        return max(nested_inside, key=lambda candidate: len(candidate.parts))

    # (3) `root` is coarse enough to CONTAIN a protected directory or
    # file. Several contained paths can match at once (e.g. an ancestor of
    # `get_user_data_dir()` also contains the skill-trust subtree nested
    # inside it); the one with the FEWEST path parts is the shallowest/
    # nearest contained path, hence the most immediate, least obscure one
    # to report.
    contains = [
        protected
        for protected in protected_dirs
        if _is_within(protected, root) and not _same_path(protected, root)
    ]
    contains.extend(
        protected
        for protected in protected_files
        if _is_within(protected, root) and not _same_path(protected, root)
    )
    if contains:
        return min(contains, key=lambda candidate: len(candidate.parts))

    return None


def refuses_new_directory_chain(
    target_dir: Path, context: SensitivePathContext | None = None
) -> bool:
    """Whether creating ``target_dir`` (or any not-yet-existing parent of it)
    would plant a directory where this app expects a plain state file.

    ``is_sensitive_path``'s direct-child-file rule is deliberately gated on
    "does this candidate already exist as a directory", so a pre-existing
    container (``tool_sandbox``, ``chromadb``, ``skills``, ...) stays fully
    reachable. That same gate means a candidate that does NOT yet exist is
    judged as if it were a plain file -- correctly refused. But
    ``WriteFileTool``'s ``create_directories=True`` path only ever validates
    the FINAL file being written, never the new directory levels
    ``Path.mkdir(parents=True)`` creates on the way there: a target like
    ``search_history.db/note.txt`` has a parent (``.../search_history.db``)
    that is never itself checked, so nothing stopped an agent from planting
    a directory at that exact name before this app ever created
    ``search_history.db`` as a SQLite file (TASK-849, verified reachable
    end to end through ``WriteFileTool`` under a widened sandbox root). The
    app's own later ``sqlite3.connect(...)`` (or equivalent open) then fails
    outright -- a denial of service, not a disclosure: the collision itself
    carries no credential and grants no elevated access.

    Walking upward from ``target_dir`` while each level still does not
    exist mirrors exactly what ``Path.mkdir(parents=True)`` is about to
    create, and checks each such level with ``is_sensitive_path`` --
    reusing the exact same direct-child-file rule, never a separate check.
    Any level found to already exist ends the walk immediately: an existing
    ancestor is never touched by ``mkdir(parents=True)``, so nothing new
    needs checking above it -- which is what keeps every legitimate
    container directory (created by the app itself before an agent tool
    ever runs) fully reachable.

    Consequence worth naming (Finding 2, follow-up hardening review): a
    not-yet-existing name always fails ``is_sensitive_path``'s ``is_dir()``
    gate, so this refuses creating **any** brand-new subdirectory directly
    inside one of the container directories the direct-child-file rule
    protects (``get_user_data_dir()``, the ChromaDB persist directory,
    ...) -- not only a name that happens to collide with a state file this
    app actually uses. Reproduced: with the sandbox root widened to
    contain the ChromaDB persist directory,
    ``write_file("chromadb/newcoll/x.txt", create_directories=True)`` is
    refused (``newcoll`` does not exist yet, so it fails the same gate a
    genuine collision would), while ``write_file("chromadb/coll1/new.txt",
    create_directories=True)`` succeeds once ``coll1`` already exists as a
    directory -- the walk stops at the first already-existing ancestor, as
    documented above. This is deliberate, not a bug to fix here: telling
    "a legitimate brand-new container" apart from "a shadow directory
    aimed at a not-yet-created state file" by name alone would require
    exactly the enumeration this design avoids (see the module
    docstring), so failing closed is the right default. It is only
    reachable when the sandbox root (or a bound workspace folder) is
    widened to actually contain one of these container directories -- the
    default sandbox root never does. Noted here so the next reader is not
    surprised by an agent's brand-new-subdirectory `write_file` call being
    refused under such a configuration.

    Args:
        target_dir: The directory ``mkdir(parents=True)`` is about to
            create -- typically a write target's parent directory.
        context: Optional pre-resolved ``SensitivePathContext``; see
            ``resolve_sensitive_context``.

    Returns:
        True if ``target_dir`` or any of its not-yet-existing ancestors
        would be a sensitive path once created.
    """
    ctx = context if context is not None else resolve_sensitive_context()
    node = target_dir
    while True:
        resolved = _resolved(str(node))
        if resolved is None:
            return True
        if resolved.exists():
            return False
        if is_sensitive_path(resolved, context=ctx):
            return True
        parent = node.parent
        if parent == node:
            return False
        node = parent


#: The one directory (or, in a linked worktree, FILE) name that holds a
#: repository's own metadata. Matched as an exact path COMPONENT, never as a
#: prefix: `.gitignore`, `.gitattributes` and `.github/` are ordinary tracked
#: files and stay writable (TASK-19700 policy).
GIT_METADATA_COMPONENT = ".git"


def is_git_metadata_write(path: Path) -> bool:
    """Whether writing ``path`` would modify a repository's own git metadata.

    TASK-19700. Surfaced by TASK-16801's git-modes arc: a repository-supplied
    ``.git/config`` or ``.git/HEAD`` was the precondition for four proven
    data-destruction vectors -- an option-shaped remote or branch name
    reaching git's argv, and ``remote.push``/``remote.mirror``/
    ``push.default=matching`` turning an ordinary push into a forced update
    or a ref deletion. Each is fixed defensively inside the git engine, but
    an agent that can write ``.git/`` reconfigures git for EVERY feature
    that shells out to it, so the upstream cause is denied here.

    Deliberately WRITE-only and deliberately NOT part of
    :func:`is_sensitive_path`: that denylist governs reads as well, and an
    agent reading repository state is legitimate (ADR-032 adopted
    ``allow_hidden`` precisely so a coding agent can see dotfiles). The
    read-side question -- ``.git/config`` can embed a credential in a remote
    URL -- is tracked separately rather than smuggled in here.

    Matching is on an exact path component, so the near-miss names that
    share the prefix stay writable:

    Matching is case-insensitive (a case-insensitive filesystem makes
    ``.GIT`` the same directory), but still component-exact:

    * refused: ``.git``, ``.GIT``, ``.git/config``, ``.git/hooks/pre-commit``, and the
      ``.git`` FILE a linked worktree carries (rewriting it redirects the
      whole repository, so a directory-only check would miss it);
    * allowed: ``.gitignore``, ``.gitattributes``, ``.github/workflows/``.

    Args:
        path: An already-resolved absolute path (the callers resolve before
            calling, so a symlink cannot smuggle a ``.git`` component past
            this check).

    Returns:
        True when any component of ``path`` is exactly ``.git``.
    """
    # Case-INSENSITIVE component match (Qodo, PR #1934): macOS and Windows
    # filesystems are case-insensitive by default, so `.GIT/config` opens the
    # very same file as `.git/config`. Verified before this fix: a
    # `.GIT/config` write sailed past an exact-match guard and landed a
    # hostile remote in the real config. Still COMPONENT-exact, so
    # `.GITIGNORE` stays writable.
    folded = GIT_METADATA_COMPONENT.casefold()
    return any(part.casefold() == folded for part in path.parts)
