"""Read frozen E files and compile them as data; never import supplied modules."""

import ast
import hashlib
import json
from pathlib import Path
import struct
import sys
from types import CodeType


P = Path(__file__).resolve().parent
E = P.parent
D = E / "root-opt36-reader-repair-packet-r2"
TEST = "Tests/Backup_Recovery/test_opt36_current_windows_installation_binding.py"
CASE = "test_current_windows_helper_retains_exact_installed_definition_capture"
CONFIG = "tldw_chatbook/config.py"
READER = "0316231e094b7b0f2a07296ebfb27da0066dbb80ab71d2b24a91e5a83356a6f0"
GATE = "2e24fa486c043b8ce8526b33ca1dcf49806ac39a407079327cc3d439f7ea2666"
CURRENT = "47de2fc374da8c98431e4111ec76b5ca594974482bdac66514085094979d371b"
assert not sys.flags.optimize


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def load(path):
    return json.loads(path.read_text())


assert sha(P / "opt36_candidate_reader.py") == sha(D / "opt36_candidate_reader.py") == READER
assert sha(P / "ac77_source_gate.py") == sha(D / "ac77_source_gate.py") == GATE
baseline_path = P / "component-baseline-source-map.json"
assert sha(baseline_path) == "11c4741b7b544c89d30f2f2536558d3480f9fe968086d794fc6db2d0eb667b01"
baseline = load(baseline_path)
assert len(baseline) == 8479 and TEST not in baseline
original, expected = load(D / "expected-sources.json"), load(P / "expected-sources.json")
assert sha(D / "manifest.json") == "db1448cc8a9d78731eafdb081ad792925465e1e71ae406ed5ef5032557fb4e93"
old_assets = {row["path"]: row for row in load(D / "manifest.json")["assets"]}
for filename in ("expected-sources.json", "snapshots/" + CONFIG,
                 "nodeids.json", "runtime-binding.json", "opt36_candidate_reader.py",
                 "ac77_source_gate.py", "runtime/contextlib.py.txt",
                 "runtime/_pytest_fixtures.py.txt", "runtime/_pytest_assertion_rewrite.py.txt"):
    assert sha(D / filename) == old_assets[filename]["sha256"]
assert len(original["sources"]) == 15 and len(expected["sources"]) == 14
assert len({row["module"] for row in expected["sources"]}) == 14
assert len({row["logical_path"] for row in expected["sources"]}) == 14
removed = {
    "Tests.Backup_Recovery.test_windows_metadata_baseline_opt36_opt74",
    "Tests.Backup_Recovery.test_user_data_directory_posture_adapter",
}
retained = [dict(row) for row in original["sources"] if row["module"] not in removed]
assert len(retained) == 13
for row in retained:
    if row["logical_path"] == CONFIG:
        row["sha256"] = CURRENT
assert expected["sources"][:-1] == retained
assert expected["aliases"] == [row for row in original["aliases"]
                                if row[0] not in removed and row[2] not in removed]
assert len(expected["aliases"]) == 5
test_row = expected["sources"][-1]
assert test_row == {
    "module": "Tests.Backup_Recovery.test_opt36_current_windows_installation_binding",
    "logical_path": TEST, "snapshot_path": "snapshots/" + TEST,
    "sha256": sha(P / "snapshots" / TEST), "slots": [CASE],
}
lint = load(P / "lint-receipt.json")
assert lint["test_sha256"] == test_row["sha256"] and len(lint["checks"]) == 2
assert all(row["exit_code"] == 0 for row in lint["checks"])
compiled = []
for row in expected["sources"]:
    path = P / row["snapshot_path"]
    assert sha(path) == row["sha256"]
    if row["logical_path"] not in (TEST, CONFIG):
        assert baseline[row["logical_path"]] == row["sha256"]
    compile(path.read_bytes(), row["logical_path"], "exec", dont_inherit=True)
    compiled.append(row["snapshot_path"])
assert sha(P / "runtime-binding.json") == sha(D / "runtime-binding.json")
assert sha(P / "nodeids.json") == sha(D / "nodeids.json")
runtime = load(P / "runtime-binding.json")
assert (runtime["python"], runtime["pytest"], runtime["textual"]) == ("3.12.10", "8.4.2", "8.2.8")
assert len(runtime["sources"]) == 3
for row in runtime["sources"]:
    path = P / row["snapshot_path"]
    assert sha(path) == row["sha256"] and path.stat().st_size == row["bytes"]
    assert path.read_bytes() == (D / row["snapshot_path"]).read_bytes()
    compile(path.read_bytes(), row["runtime_path"], "exec", dont_inherit=True)
    compiled.append(row["snapshot_path"])
for filename in ("opt36_candidate_reader.py", "ac77_source_gate.py"):
    compile((P / filename).read_bytes(), filename, "exec", dont_inherit=True)
    compiled.append(filename)
assert len(compiled) == 19

tree = ast.parse((P / "snapshots" / TEST).read_bytes())
assert sha(P / "formatting-before.py.txt") == "8d3883c83c430c01a9da2433cb1aeb6527700869dd6add7a9044a114796f0b8e"
before_format = ast.parse((P / "formatting-before.py.txt").read_bytes())
assert sorted(ast.dump(n) for n in ast.walk(before_format) if isinstance(n, (ast.Import, ast.ImportFrom))) == sorted(
    ast.dump(n) for n in ast.walk(tree) if isinstance(n, (ast.Import, ast.ImportFrom)))


class WithoutImports(ast.NodeTransformer):
    def visit_Import(self, node):
        return None

    def visit_ImportFrom(self, node):
        return None


assert ast.dump(WithoutImports().visit(before_format)) == ast.dump(
    WithoutImports().visit(ast.parse((P / "snapshots" / TEST).read_bytes())))
tests = [node for node in tree.body if isinstance(node, ast.FunctionDef)]
assert len(tests) == 1 and tests[0].name == CASE
assert [ast.unparse(node) for node in tests[0].decorator_list] == ["pytest.mark.bootstrap_profile"]
assert [arg.arg for arg in tests[0].args.args] == ["request", "record_property"]
calls = [ast.unparse(node.func) for node in ast.walk(tree) if isinstance(node, ast.Call)]
for method, count in {
    "reader_module.CandidateReader": 1, "reader.gate.loaded": 2,
    "reader._adapter_capture": 2, "reader._launcher": 2,
    "reader.gate.unchanged": 2, "reader.gate.receipt": 1, "record_property": 1,
}.items():
    assert calls.count(method) == count, (method, calls.count(method))
forbidden = {"_bind_user_data_dir_stamps", "source_current", "_user_data_dir_stamps",
             "_Native", "_native", "_posture", "stat", "stat_for_admission",
             "stat_many_for_admission", "_stat_handle", "prepare", "finish",
             "setprofile", "settrace", "use_tool_id", "free_tool_id", "register_callback",
             "set_events", "set_local_events", "cache_clear", "exec", "eval", "__import__"}
forbidden.update({"set_encryption_password", "clear_encryption_password", "clear_derived_key_cache"})
assert not {call.rsplit(".", 1)[-1] for call in calls} & forbidden
assert "reader.receipt" not in calls
assert len([node for node in ast.walk(tree) if isinstance(node, ast.Assert)]) >= 25

old_source = (D / "snapshots" / CONFIG).read_bytes()
new_source = (P / "snapshots" / CONFIG).read_bytes()
old_ast, new_ast = ast.parse(old_source), ast.parse(new_source)
old_factory, = [n for n in old_ast.body if isinstance(n, ast.FunctionDef) and n.name == "_bind_user_data_dir_stamps"]
new_factory, = [n for n in new_ast.body if isinstance(n, ast.FunctionDef) and n.name == "_bind_user_data_dir_stamps"]
assert ast.get_source_segment(old_source.decode(), old_factory) == ast.get_source_segment(new_source.decode(), new_factory)
assert (old_factory.lineno, new_factory.lineno) == (10939, 10964)


def codes(code):
    yield code
    for value in code.co_consts:
        if type(value) is CodeType:
            yield from codes(value)


def typed(value, offset):
    kind = type(value)
    if kind is CodeType:
        return kind, shape(value, offset)
    if kind is tuple:
        return kind, tuple(typed(item, offset) for item in value)
    if kind is frozenset:
        return kind, frozenset(typed(item, offset) for item in value)
    if kind is float:
        return kind, struct.pack("!d", value)
    if kind is complex:
        return kind, struct.pack("!dd", value.real, value.imag)
    assert kind in (type(None), type(Ellipsis), bool, int, str, bytes)
    return kind, value


def shape(code, offset):
    return (code.co_name, code.co_qualname, code.co_firstlineno - offset,
            code.co_code, code.co_exceptiontable, code.co_linetable,
            code.co_stacksize, code.co_flags, code.co_argcount,
            code.co_posonlyargcount, code.co_kwonlyargcount, code.co_nlocals,
            code.co_names, code.co_varnames, code.co_freevars, code.co_cellvars,
            tuple(typed(value, offset) for value in code.co_consts))


old_code, = [c for c in codes(compile(old_source, CONFIG, "exec", dont_inherit=True))
             if c.co_qualname == "_bind_user_data_dir_stamps"]
new_code, = [c for c in codes(compile(new_source, CONFIG, "exec", dont_inherit=True))
             if c.co_qualname == "_bind_user_data_dir_stamps"]
assert shape(old_code, 0) == shape(new_code, 25)
assert len(list(codes(old_code))) == len(list(codes(new_code))) == 21
locations = {c.co_qualname: c.co_firstlineno for c in codes(new_code)}
assert locations["_bind_user_data_dir_stamps.<locals>.source_current"] == 11039
assert locations["_bind_user_data_dir_stamps.<locals>._user_data_dir_stamps"] == 11079
inputs = load(P / "inputs.json")
for row in inputs:
    path = Path(row["path"])
    assert path.is_relative_to(E) and sha(path) == row["sha256"] and path.stat().st_size == row["bytes"]
current_map = load(E / "root-opt36-current-plain-actual-r2/sources-before.json")
assert len(current_map) == 8546
relationships = load(P / "prefix-reconciliation.json")["relationships"]
for row in relationships:
    key = row["logical_path"]
    assert row["component_before_sha256"] == baseline[key]
    assert row["current_ordinary_before_sha256"] == current_map[key]
    assert row["equal"] is (baseline[key] == current_map[key])

if sys.argv[1:] == ["--manifest"]:
    manifest = load(P / "manifest.json")
    actual = {str(path.relative_to(P)) for path in P.rglob("*") if path.is_file() and path.name != "manifest.json"}
    assert actual == {row["path"] for row in manifest["assets"]}
    for row in manifest["assets"]:
        path = P / row["path"]
        assert sha(path) == row["sha256"] and path.stat().st_size == row["bytes"]
    print(json.dumps({"status": "PASS manifest and all static checks", "assets": len(actual),
                      "manifest_sha256": sha(P / "manifest.json")}))
else:
    assert not sys.argv[1:]
    print(json.dumps({
        "status": "PASS source packet static checks only; proposed TEST is UNRUN",
        "python": sys.version, "source_rows": 14, "runtime_rows": 3,
        "compiled_python_data": compiled, "new_test_sha256": test_row["sha256"],
        "new_test_assertions": sum(isinstance(n, ast.Assert) for n in ast.walk(tree)),
        "ruff_import_order_and_layout_only": True,
        "ruff_check_and_format_receipt_sha256": sha(P / "lint-receipt.json"),
        "preformat_test_sha256": sha(P / "formatting-before.py.txt"),
        "reader_sha256_unchanged": READER, "gate_sha256_unchanged": GATE,
        "current_config_sha256": CURRENT, "component_baseline_rows": len(baseline),
        "factory_source_exact": True, "recursive_compiled_codes_equal_except_line_shift": 21,
        "lexical_line_translation": 25, "current_helper_line": 11079, "current_checker_line": 11039,
        "frozen_external_inputs_verified": len(inputs), "test_call_names": sorted(set(calls)),
        "prefix_relationships_verified_against_frozen_maps": len(relationships),
        "explicit_forbidden_producer_or_instrumentation_calls": [],
        "scope": "Frozen E file reads, AST and compile data only. No supplied module import/execution, Goal/R access, native run, network or publication.",
    }, indent=2) + "\n")
