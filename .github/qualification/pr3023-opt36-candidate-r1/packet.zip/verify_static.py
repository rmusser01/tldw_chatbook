"""Pure-stdlib byte/AST/compile-as-data verifier. Imports no supplied module."""
import ast
from collections import Counter
import hashlib
import itertools
import json
from pathlib import Path
import sys

D = Path(__file__).resolve().parent
E = D.parent
assert sys.version_info[:3] == (3, 12, 11)
def load(name):
    return json.loads((D / name).read_text())
def digest(data):
    return hashlib.sha256(data).hexdigest()
def dump(node):
    return ast.dump(node, include_attributes=False)
def functions(tree):
    return {node.name: node for node in tree.body if isinstance(node, ast.FunctionDef)}
pins = load("static-pins.json")
compiled = []
for row in pins["python_data"]:
    path = D / row["path"]
    data = path.read_bytes()
    assert digest(data) == row["sha256"]
    tree = ast.parse(data, filename=str(path), feature_version=(3, 12))
    assert digest(dump(tree).encode()) == row["ast_sha256"]
    compile(data, str(path), "exec", dont_inherit=True)
    compiled.append(row["path"])
for row in load("expected-sources.json")["sources"] + load("runtime-binding.json")["sources"]:
    data = (D / row["snapshot_path"]).read_bytes()
    assert digest(data) == row["sha256"]
for row in load("inputs.json"):
    path = E / row["path"]
    assert path.stat().st_size == row["bytes"] and digest(path.read_bytes()) == row["sha256"]
test_path = "snapshots/Tests/Backup_Recovery/test_user_data_directory_posture_adapter.py"
new = functions(ast.parse((D / test_path).read_bytes()))
old = functions(ast.parse((E / "root-opt36-shipping-posture-candidate-controls-r1/unselected/test_user_data_directory_posture_adapter.py").read_bytes()))
changed = {name for name in old if dump(old[name]) != dump(new[name])}
assert changed == {"_shipping_events", "test_direct_custom_facade_keeps_scalar_arguments_and_receiver", "test_actual_batch_return_or_projection_source_change_discards_whole_sample", "test_shipping_helper_propagates_exact_retained_native_close"}
original_causal = functions(ast.parse((E / "root-opt36-shipping-posture-controls-r2" / test_path).read_bytes()))
causal = "test_shipping_helper_uses_one_fresh_batch_after_equal_values_and_retirement"
assert dump(new[causal]) == dump(original_causal[causal])
assert (D/"ac77_source_gate.py").read_bytes() == (E/"root-opt36-shipping-posture-controls-r2/ac77_source_gate.py").read_bytes()
assert (D/"runtime-binding.json").read_bytes() == (E/"root-opt36-shipping-posture-controls-r2/runtime-binding.json").read_bytes()
assert (D/"snapshots/Tests/Backup_Recovery/test_windows_metadata_baseline_opt36_opt74.py").read_bytes() == (E/"root-opt36-shipping-posture-controls-r2/snapshots/Tests/Backup_Recovery/test_windows_metadata_baseline_opt36_opt74.py").read_bytes()
assert digest((D/"snapshots/tldw_chatbook/config.py").read_bytes()) == "da3a1d55cc080bd193fe1a37a04ae5f4fc83d8d5cb9bb78a05fa13135b4ce026"
source_tree = ast.parse((D/"snapshots/tldw_chatbook/config.py").read_bytes())
factory = functions(source_tree)["_bind_user_data_dir_stamps"]
reader_tree = ast.parse((D/"opt36_candidate_reader.py").read_bytes())
reader_class = next(n for n in reader_tree.body if isinstance(n, ast.ClassDef) and n.name == "CandidateReader")
methods = functions(reader_class)
class Normalize(ast.NodeTransformer):
    def visit_Name(self, node):
        return ast.copy_location(ast.Name(id={"windows_files":"files", "platform_files":"platform", "original_posture":"posture"}.get(node.id, node.id), ctx=node.ctx), node)
for name in ("functions", "bindings"):
    source_assignment = next(n for n in ast.walk(factory) if isinstance(n, ast.Assign) and any(isinstance(t, ast.Name) and t.id == name for t in n.targets))
    reader_assignment = next(n for n in ast.walk(methods["_adapter_capture"]) if isinstance(n, ast.Assign) and any(isinstance(t, ast.Name) and t.id == name for t in n.targets))
    assert dump(Normalize().visit(source_assignment.value)) == dump(reader_assignment.value)
source_functions = next(n.value for n in ast.walk(factory) if isinstance(n, ast.Assign) and any(isinstance(t, ast.Name) and t.id == "functions" for t in n.targets))
assert len(source_functions.elts) == 25
selectors = load("nodeids.json")
assert len(selectors["candidate31"]) == len(set(selectors["candidate31"])) == 31
assert len(selectors["compatible_r13_5"]) == 5
actual_nodes = []
for node in new.values():
    if not node.name.startswith("test_"):
        continue
    dims = [ast.literal_eval(d.args[1]) for d in reversed(node.decorator_list)
            if isinstance(d, ast.Call) and isinstance(d.func, ast.Attribute) and d.func.attr == "parametrize"]
    for values in itertools.product(*dims) if dims else [()]:
        suffix = "[" + "-".join(str(v) for v in values) + "]" if values else ""
        actual_nodes.append("Tests/Backup_Recovery/test_user_data_directory_posture_adapter.py::"+node.name+suffix)
assert actual_nodes == selectors["candidate31"]
plan = load("candidate-command-plan.json")
assert len(plan["stage"]) == 2 and len(plan["products_staged"]) == 1
for row in plan["stage"] + plan["products_staged"]:
    assert digest((D / row["source"]).read_bytes()) == row["sha256"]
assert plan["products_staged"][0]["before_sha256"] == "096361f6c4255a49646d3b9383282ed180bd82cde90caf4b376b9ba8e840c960"
assert [c["expected_gates"] for c in plan["commands"]] == [0, 31, 0, 8]
assert [c["group"] for c in plan["commands"]] == ["candidate31", "candidate31", "compatible_r13_5", "compatible_r13_5"]
assert all(c["expected_returncode"] == 0 for c in plan["commands"])
assert all(c["argv"][:3] == ["{python}", "-m", "Tests.windows_private_fixture_runner"] for c in plan["commands"])
assert all("--timeout=180" in c["argv"] for c in plan["commands"])
separate = load("separate-affected-command-plan.json")
assert [g["cases"] for g in separate["groups"]] == [12, 11]
result = dict(status="PASS static data only; no reader/TEST/product imports or execution", python=sys.version,
    compiled_python_data=len(compiled), source_rows=15, runtime_rows=3, native_cases=31, compatible_parent_cases=5,
    genuine_memo_children_planned=3, source_capture_functions=25, changed_test_functions=sorted(changed),
    original_causal_function_ast_unchanged=True, gate_runtime_and_r13_bytes_unchanged=True,
    new_test_assertions=sum(isinstance(n, ast.Assert) for n in ast.walk(ast.parse((D/test_path).read_bytes()))),
    reader_assertions=sum(isinstance(n, ast.Assert) for n in ast.walk(reader_tree)))
if len(sys.argv) == 2:
    Path(sys.argv[1]).write_text(json.dumps(result, indent=2)+"\n")
print(json.dumps(result, indent=2))
