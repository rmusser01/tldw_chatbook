"""Four fixed original Video controls; passive source and fixture observations."""

import ast
import asyncio
import dis
import hashlib
import importlib.machinery
import json
import os
import sys
from importlib.metadata import version
from pathlib import Path
from types import BuiltinFunctionType, FunctionType, MethodType

from ac77_source_gate import HERE, Gate, nested, shape

PICKER_TEST = "Tests.UI.test_console_video_picker_cancel"
CAPACITY_TEST = "Tests.Chat.test_console_video_capacity"
FACTORY = "Tests.UI.app_factory"
QUIT = "Tests.UI.test_app_quit_under_modal"
FLIGHT = "Tests.UI.test_app_quit_in_flight_modals"
VIDEO = "tldw_chatbook.UI.Console_Modules.video"
WIRING = "tldw_chatbook.UI.Console_Modules.wiring"
CHAT = "tldw_chatbook.UI.Screens.chat_screen"
APP = "tldw_chatbook.app"
FIXTURES = "Tests.conftest"

VIDEO_CALLBACKS = {
    "_sync_native_console_chat_ui_fn": "sync_native_console_chat_ui",
    "_ensure_console_chat_store_fn": "ensure_console_chat_store",
    "_wait_for_console_screen_result_fn": "wait_for_console_screen_result",
    "_open_video_with_os_fn": "open_video_with_os",
    "_append_native_console_system_message_fn": "append_native_console_system_message",
    "_default_console_session_settings_fn": "default_console_session_settings",
    "_console_composer_or_none_fn": "console_composer_or_none",
    "_clear_console_composer_draft_fn": "clear_console_composer_draft",
}


class VideoGate(Gate):
    def default(self, node, module, tree):
        if (
            module.__name__ == "Tests.app_module_patches"
            and isinstance(node, ast.Name)
            and node.id == "DEFAULT"
        ):
            imports = [
                statement
                for statement in tree.body
                if isinstance(statement, ast.ImportFrom)
                and statement.module == "unittest.mock"
                and any(
                    alias.name == "DEFAULT" and alias.asname is None
                    for alias in statement.names
                )
            ]
            assert len(imports) == 1
            assert (
                vars(module)["DEFAULT"] is vars(sys.modules["unittest.mock"])["DEFAULT"]
            )
            return vars(module)["DEFAULT"]
        return super().default(node, module, tree)


class VideoReader:
    start_labels = {"capability", "copy"}
    yield_labels = {"drain_fixture", "retire_fixture"}

    def __init__(self, installed_root, item):
        self.item = item
        binding = json.loads((HERE / "runtime-binding.json").read_text())
        assert binding["status"] == "sealed-for-video-four"
        assert sys.platform == "win32" and sys.version.split()[0] == binding["python"]
        for distribution in ("pytest", "textual", "pytest-asyncio"):
            assert version(distribution) == binding[distribution]
        self.gate = VideoGate(
            installed_root, binding["sources"], pytest_config=item.config
        )
        self.codes = {}
        self.code_globals = {}
        self.launcher = None
        self.app = self.console = self.video = None
        self.artifact = self.worker = self.harness = None
        self.save_returns = []
        self.cleanup_order = []
        self.copy_gate = None
        self.real_ui = item.module.__name__ == PICKER_TEST
        assert self.real_ui or item.module.__name__ == CAPACITY_TEST
        self.first = (
            item.name == "test_cancelling_the_save_picker_returns_to_the_storage_choice"
        )
        self.counts = {}
        self.fixture_defs = {}
        self.fixture_yield_offsets = {}
        self.directories = ()
        self.native = {
            name: vars(os).get(name)
            for name in (
                "open",
                "stat",
                "link",
                "unlink",
                "replace",
                "O_DIRECTORY",
                "O_NOFOLLOW",
                "supports_dir_fd",
                "supports_follow_symlinks",
            )
        }
        self.native_sets = {
            name: frozenset(vars(os)[name])
            for name in ("supports_dir_fd", "supports_follow_symlinks")
        }

    def module(self, name):
        module = sys.modules[name]
        self.gate.module(module)
        return module

    def function(self, module_name, dotted):
        owner = self.module(module_name)
        for part in dotted.split("."):
            owner = vars(owner)[part]
        if isinstance(owner, (staticmethod, classmethod)):
            owner = owner.__func__
        self.gate.pin(owner)
        return owner

    def watch(self, module_name, dotted, label, *, unwrapped=False):
        function = self.function(module_name, dotted)
        if unwrapped:
            function = vars(function)["__wrapped__"]
            self.gate.pin(function)
        assert function.__code__ not in self.codes
        self.codes[function.__code__] = label
        self.code_globals[function.__code__] = function.__globals__
        return function

    def count(self, label):
        self.counts[label] = self.counts.get(label, 0) + 1

    def native_unchanged(self):
        assert vars(sys.modules[VIDEO])["os"] is os
        for name, value in self.native.items():
            assert vars(os).get(name) is value
        for name, value in self.native_sets.items():
            assert frozenset(vars(os)[name]) == value

    def class_binding(self, module_name, name):
        module = self.module(module_name)
        cls = vars(module)[name]
        assert isinstance(cls, type)
        assert cls.__module__ == module_name and cls.__qualname__ == name
        self.gate.classes.append((module, name, cls, cls.__bases__))
        return cls

    def resolved(self, cls, name, owner, slot=None):
        expected = vars(owner)[slot or name]
        defining = next(base for base in cls.__mro__ if name in vars(base))
        assert defining is owner and vars(defining)[name] is expected
        self.gate.slots.append((defining, name, expected))
        return expected

    def _captured_function(self, function, values):
        """The captured-function algorithm, only for the explicitly named captures."""
        assert type(function) is FunctionType
        module = sys.modules[function.__globals__["__name__"]]
        assert function.__globals__ is vars(module)
        record = self.gate.source(module)
        code = function.__code__
        assert Path(code.co_filename).resolve() == record[1]
        expected = nested(record[5], code)
        assert expected is not None and shape(expected) == shape(code)
        node = record[7][code.co_qualname]
        expected_defaults = tuple(
            self.gate.default(value, module, record[6]) for value in node.args.defaults
        )
        assert len(function.__defaults__ or ()) == len(expected_defaults)
        assert all(
            type(actual) is type(wanted) and actual == wanted
            for actual, wanted in zip(function.__defaults__ or (), expected_defaults)
        )
        expected_kw = {
            arg.arg: self.gate.default(value, module, record[6])
            for arg, value in zip(node.args.kwonlyargs, node.args.kw_defaults)
            if value is not None
        }
        assert (function.__kwdefaults__ or {}).keys() == expected_kw.keys()
        assert all(
            type(value) is type(expected_kw[name]) and value == expected_kw[name]
            for name, value in (function.__kwdefaults__ or {}).items()
        )
        assert not getattr(function, "__type_params__", ())
        cells = tuple(zip(code.co_freevars, function.__closure__ or ()))
        assert len(cells) == len(code.co_freevars)
        assert set(values) == set(code.co_freevars)
        assert all(cell.cell_contents is values[name] for name, cell in cells)
        self.gate.functions[id(function)] = (
            function,
            code,
            function.__globals__,
            function.__defaults__,
            function.__kwdefaults__,
            tuple((function.__kwdefaults__ or {}).items()),
            function.__closure__,
            tuple((cell, cell.cell_contents) for _name, cell in cells),
            vars(function).get("__wrapped__"),
        )

    def video_capture(self, function, keyword):
        # Exactly the eight constructor arguments in this one original call.
        assert type(function) is FunctionType
        module = self.module(WIRING)
        record = self.gate.source(module)
        owner = record[7]["build_console_controllers"]
        calls = [
            node
            for node in ast.walk(owner)
            if isinstance(node, ast.Call)
            and isinstance(node.func, ast.Name)
            and node.func.id == "ConsoleVideoController"
        ]
        assert len(calls) == 1
        arguments = {argument.arg: argument.value for argument in calls[0].keywords}
        node = arguments[keyword]
        assert isinstance(node, ast.Lambda)
        code = function.__code__
        assert function.__globals__ is vars(module)
        assert code.co_qualname == "build_console_controllers.<locals>.<lambda>"
        assert code.co_firstlineno == node.lineno
        assert function.__defaults__ is None and function.__kwdefaults__ is None
        assert code.co_freevars == ("screen",)
        assert (
            len(function.__closure__) == 1
            and function.__closure__[0].cell_contents is self.console
        )
        assert Path(code.co_filename).resolve() == record[1]
        candidates = [
            value
            for value in self._nested_codes(record[5])
            if value.co_qualname == code.co_qualname
            and value.co_firstlineno == node.lineno
            and value.co_argcount == code.co_argcount
        ]
        assert len(candidates) == 1 and shape(candidates[0]) == shape(code)
        self.gate.functions[id(function)] = (
            function,
            code,
            function.__globals__,
            None,
            None,
            (),
            function.__closure__,
            ((function.__closure__[0], self.console),),
            vars(function).get("__wrapped__"),
        )

    def _nested_codes(self, code):
        from types import CodeType

        yield code
        for child in code.co_consts:
            if type(child) is CodeType:
                yield from self._nested_codes(child)

    def _launcher(self):
        # The original installed -m launcher is still __main__, with no alias.
        main = sys.modules["__main__"]
        row = self.gate.rows["Tests.windows_private_fixture_runner"]
        path = self.gate.root / row["logical_path"]
        data = (HERE / row["snapshot_path"]).read_bytes()
        assert Path(main.__file__).resolve() == path and path.read_bytes() == data
        assert hashlib.sha256(data).hexdigest() == row["sha256"]
        assert main.__spec__.name == "Tests.windows_private_fixture_runner"
        assert Path(main.__spec__.origin).resolve() == path
        assert type(main.__loader__) is importlib.machinery.SourceFileLoader
        compiled = compile(data, str(path), "exec", dont_inherit=True)
        wrapper, entry = vars(main)["user_fixture_default_owner"], vars(main)["main"]
        body = vars(wrapper)["__wrapped__"]
        for function in (entry, body):
            assert type(function) is FunctionType and function.__globals__ is vars(main)
            expected = nested(compiled, function.__code__)
            assert expected is not None and shape(expected) == shape(function.__code__)
            assert (
                function.__defaults__ is None
                and function.__kwdefaults__ is None
                and function.__closure__ is None
            )
        contextlib = sys.modules["contextlib"]
        expected_wrapper = nested(self.gate.source(contextlib)[5], wrapper.__code__)
        assert expected_wrapper is not None and shape(expected_wrapper) == shape(
            wrapper.__code__
        )
        assert wrapper.__globals__ is vars(
            contextlib
        ) and wrapper.__code__.co_freevars == ("func",)
        assert wrapper.__defaults__ is None and wrapper.__kwdefaults__ is None
        assert len(wrapper.__closure__) == 1
        assert (
            wrapper.__closure__[0].cell_contents is body
            and vars(wrapper)["__wrapped__"] is body
        )
        frame = sys._getframe()
        while frame is not None and frame.f_code is not entry.__code__:
            frame = frame.f_back
        assert frame is not None and frame.f_globals is vars(main)
        self.launcher = (
            main,
            path,
            data,
            wrapper,
            body,
            entry,
            wrapper.__code__,
            body.__code__,
            entry.__code__,
        )

    def prepare(self):
        self.gate.loaded()
        self._launcher()
        self.native_unchanged()
        native_module = sys.modules["nt"]
        assert native_module.__spec__.origin == "built-in"
        for name in ("open", "stat", "link", "unlink", "replace"):
            callback = vars(os)[name]
            assert type(callback) is BuiltinFunctionType
            assert callback is vars(native_module)[name] and callback.__name__ == name
        # Collection imported the original modules; no reader-owned SUT import.
        assert self.item.obj is vars(self.item.module)[self.item.name]
        self.test_function = self.item.obj
        self.gate.pin(self.test_function)
        self.codes[self.test_function.__code__] = "test"
        self.code_globals[self.test_function.__code__] = self.test_function.__globals__
        self.watch(CAPACITY_TEST, "_artifact", "artifact")
        self.watch(CAPACITY_TEST, "_OutcomeHarness.__init__", "harness")
        self.watch(
            VIDEO,
            "ConsoleVideoController._require_external_video_pinned_capabilities",
            "capability",
        )
        self.watch(VIDEO, "ConsoleVideoController._copy_pending_video_external", "copy")
        self.watch(
            VIDEO, "ConsoleVideoController._save_pending_console_video_external", "save"
        )
        self.watch(
            VIDEO, "ConsoleVideoController._resolve_generated_video_outcome", "resolver"
        )
        for name, label in (
            ("drain_test_app_user_data_dirs", "drain_fixture"),
            ("retire_test_app_owners", "retire_fixture"),
        ):
            public = vars(self.module(FIXTURES))[name]
            body = vars(public)["_fixture_function"]
            self.gate.pin(body)
            self.codes[body.__code__] = label
            self.code_globals[body.__code__] = body.__globals__
            definitions = self.item.session._fixturemanager._arg2fixturedefs[name]
            matching = [
                definition
                for definition in definitions
                if definition.func is body and definition.scope == "function"
            ]
            assert len(matching) == 1
            assert type(matching[0]) is self.class_binding(
                "_pytest.fixtures", "FixtureDef"
            )
            self.fixture_defs[name] = (matching[0], body)
            instructions = list(dis.get_instructions(body.__code__))
            offsets = [
                instruction.offset
                for index, instruction in enumerate(instructions)
                if instruction.opname == "YIELD_VALUE"
                and (
                    label == "drain_fixture"
                    or (
                        index > 0
                        and instructions[index - 1].opname == "CALL_INTRINSIC_1"
                        and instructions[index - 1].argrepr
                        == "INTRINSIC_ASYNC_GEN_WRAP"
                    )
                )
            ]
            assert len(offsets) == 1
            self.fixture_yield_offsets[body.__code__] = offsets[0]
        if self.real_ui:
            self.watch(FACTORY, "_build_test_app", "factory")
            self.watch(QUIT, "_mounted_console", "mounted")
            self.watch(QUIT, "_until", "until")
            self.watch(FLIGHT, "_video_waiting_in_the_save_picker", "picker")
            self.watch(FLIGHT, "_recording_cleanup", "cleanup_recorder")
            self.watch(QUIT, "_record_cleanup_then_exit", "quit_recorder")
            self.watch(FACTORY, "drain_created_runtimes", "runtimes")
            self.watch(FACTORY, "drain_created_dirs", "directories")
            self.watch("textual.dom", "DOMNode.run_worker", "worker")
            worker_class = self.class_binding("textual.worker", "Worker")
            finished = vars(worker_class)["is_finished"]
            assert type(finished) is property
            self.gate.pin(finished.fget)
            self.gate.slots.append((worker_class, "is_finished", finished))
            self.watch("textual.app", "App.notify", "notify")
            self.watch(
                "asyncio.base_events",
                "BaseEventLoop.shutdown_default_executor",
                "executor",
            )

    def fixture_frame(self, frame, label, *, yielding):
        name = (
            "drain_test_app_user_data_dirs"
            if label == "drain_fixture"
            else "retire_test_app_owners"
        )
        definition, body = self.fixture_defs[name]
        assert frame.f_code is body.__code__ and frame.f_globals is body.__globals__
        request = frame.f_locals["request"]
        assert (
            request._fixturedef is definition
            and request.node is self.item
            and request.fixturename == name
        )
        if yielding and label == "drain_fixture":
            fixtures = self.module("_pytest.fixtures")
            caller = frame.f_back
            assert caller.f_code is fixtures.call_fixture_func.__code__
            assert caller.f_locals["fixturefunc"] is body
            assert definition.func is body
            assert frame.f_locals["delegate"] is True
        if yielding and label == "retire_fixture":
            wrapper = definition.func
            assert vars(wrapper)["__wrapped__"] is body
            assert wrapper.__globals__ is vars(self.module("pytest_asyncio.plugin"))
            assert (
                wrapper.__code__.co_qualname
                == "_wrap_asyncgen_fixture.<locals>._asyncgen_fixture_wrapper"
            )
            closure = dict(
                zip(
                    wrapper.__code__.co_freevars,
                    (cell.cell_contents for cell in wrapper.__closure__),
                    strict=True,
                )
            )
            assert set(closure) == {"fixture_function", "runner", "request"}
            assert closure["fixture_function"] is body and closure["request"] is request
            self._captured_function(wrapper, closure)
        self.count(label + ("_yield" if yielding else "_return"))
        if not yielding and self.real_ui and label == "retire_fixture":
            assert request.node._test_app_native_workers_uncertain is False
            self.cleanup_order.append("retire_fixture")

    def yielded(self, frame, value, label, offset):
        assert frame.f_globals is self.code_globals[frame.f_code]
        assert label in self.yield_labels
        if offset != self.fixture_yield_offsets[frame.f_code]:
            return
        if label == "drain_fixture":
            assert value is None
        self.fixture_frame(frame, label, yielding=True)

    def started(self, frame, label):
        assert frame.f_globals is self.code_globals[frame.f_code]
        assert label in self.start_labels
        if self.real_ui:
            self.native_unchanged()
        if label == "copy":
            assert frame.f_locals["artifact"] is self.artifact
            self.copy_gate = frame.f_locals["publication_gate"]
            assert type(self.copy_gate) is self.class_binding(
                "tldw_chatbook.Video_Generation.video_store", "VideoPublicationGate"
            )
            owner = self.video if self.real_ui else self.harness
            assert (
                owner._pending_video_operation_cancels[self.artifact.message_id]
                is self.copy_gate
            )
        self.count(label)

    def returned(self, frame, value, label):
        assert frame.f_globals is self.code_globals[frame.f_code]
        if label in self.yield_labels:
            self.fixture_frame(frame, label, yielding=False)
            return
        if label == "factory":
            assert self.app is None and type(value) is self.class_binding(
                APP, "TldwCli"
            )
            self.app = value
            factory = self.module(FACTORY)
            assert factory.TldwCli is type(value) and factory._created_apps == [value]
            self.directories = tuple(factory._created_dirs)
            roles = json.loads((HERE / "finite-roles.json").read_text())
            bases = tuple(
                self.class_binding(module, name)
                for module, name in roles["app_direct_bases"]
            )
            assert type(value).__bases__ == bases
            app_class = self.class_binding("textual.app", "App")
            self.resolved(type(value), "run_test", app_class)
            self.resolved(type(value), "notify", app_class)
            self.resolved(type(value), "exit", app_class)
            lifecycle = self.class_binding(
                "tldw_chatbook.app_lifecycle", "LifecycleMixin"
            )
            self.resolved(type(value), "action_quit", lifecycle)
            self.resolved(type(value), "_run_approved_quit_cleanup", lifecycle)
        elif label == "harness":
            assert not self.real_ui and self.harness is None
            self.harness = frame.f_locals["self"]
            assert type(self.harness) is self.class_binding(
                CAPACITY_TEST, "_OutcomeHarness"
            )
        elif label == "cleanup_recorder":
            assert frame.f_locals["app"] is self.app
            assert frame.f_locals["cleanups"] is value
            recorder = vars(self.app)["_run_approved_quit_cleanup"]
            assert (
                recorder.__code__.co_qualname
                == "_recording_cleanup.<locals>._record_cleanup"
            )
            self._captured_function(recorder, {"cleanups": value})
        elif label == "quit_recorder":
            assert frame.f_locals["app"] is self.app
            assert (
                value.__code__.co_qualname
                == "_record_cleanup_then_exit.<locals>._cleanup"
            )
            self._captured_function(
                value, {"app": self.app, "cleanups": frame.f_locals["cleanups"]}
            )
        elif label == "artifact":
            assert self.artifact is None
            cls = self.class_binding(
                "tldw_chatbook.Chat.console_generate_video", "PendingVideoArtifact"
            )
            assert type(value) is cls
            assert type(value.stream) is self.class_binding(
                CAPACITY_TEST, "_TrackingStream"
            )
            self.artifact = value
        elif label == "mounted":
            assert frame.f_locals["app"] is self.app
            assert type(value) is self.class_binding(CHAT, "ChatScreen")
            assert value.app_instance is self.app
            base = self.class_binding(
                "tldw_chatbook.UI.Navigation.base_app_screen", "BaseAppScreen"
            )
            assert type(value).__bases__ == (base,)
            assert base.__bases__ == (self.class_binding("textual.screen", "Screen"),)
            self.console, self.video = value, value._video
            assert type(self.video) is self.class_binding(
                VIDEO, "ConsoleVideoController"
            )
            assert self.video.app_instance is self.app
            for attribute, keyword in VIDEO_CALLBACKS.items():
                self.video_capture(vars(self.video)[attribute], keyword)
        elif label == "worker":
            work = frame.f_locals["work"]
            resolver = vars(vars(sys.modules[VIDEO])["ConsoleVideoController"])[
                "_resolve_generated_video_outcome"
            ]
            if getattr(work, "cr_code", None) is not resolver.__code__:
                return
            assert frame.f_locals["self"] is self.console
            assert (
                work.cr_frame.f_locals["self"] is self.video
                and work.cr_frame.f_locals["outcome"] is self.artifact
            )
            assert type(value) is self.class_binding("textual.worker", "Worker")
            assert value._work is work and value._node is self.console
            assert self.worker is None
            self.worker = value
        elif label == "picker":
            assert type(value) is self.class_binding(
                "tldw_chatbook.Widgets.Console.console_video_save_screens",
                "GeneratedVideoFileSave",
            )
            assert type(value).__bases__ == (
                self.class_binding(
                    "tldw_chatbook.Widgets.enhanced_file_picker", "EnhancedFileSave"
                ),
            )
            enhanced = self.class_binding(
                "tldw_chatbook.Widgets.enhanced_file_picker", "EnhancedFileSave"
            )
            enhanced_dialog = self.class_binding(
                "tldw_chatbook.Widgets.enhanced_file_picker", "EnhancedFileDialog"
            )
            base_dialog = self.class_binding(
                "tldw_chatbook.Third_Party.textual_fspicker.file_dialog",
                "BaseFileDialog",
            )
            picker_screen = self.class_binding(
                "tldw_chatbook.Third_Party.textual_fspicker.base_dialog",
                "FileSystemPickerScreen",
            )
            safe = self.class_binding(
                "tldw_chatbook.Widgets.modal_dismissal", "SafeModalDismissMixin"
            )
            assert enhanced.__bases__ == (
                enhanced_dialog,
            ) and enhanced_dialog.__bases__ == (base_dialog,)
            assert (
                base_dialog.__bases__ == (picker_screen,)
                and picker_screen.__bases__[0] is safe
            )
            assert (
                value is self.app.screen and frame.f_locals["artifact"] is self.artifact
            )
        elif label == "notify":
            if frame.f_locals["self"] is not self.app or not frame.f_locals[
                "message"
            ].startswith("Could not save the generated video to "):
                return
            assert self.first and frame.f_locals["severity"] == "error"
        elif label == "save":
            assert frame.f_locals["self"] is (
                self.video if self.real_ui else self.harness
            )
            assert value is False or value is None
            self.save_returns.append(
                "retained" if value is False else "ownership-ended"
            )
        elif label == "until":
            if (
                frame.f_locals["what"]
                != "the unsupported save to show its error and return to the choice"
            ):
                return
            assert self.first
            assert self.video._pending_video_operation_cancels == {
                self.artifact.message_id: self.copy_gate
            }
            assert self.copy_gate._cancelled is False
            assert (
                not self.video._pending_video_active_operations
                and not self.video._pending_video_deferred_closes
            )
            assert (
                not self.artifact.stream.closed
                and self.artifact.stream.close_calls == 0
            )
            self.class_binding("textual.widgets._toast", "Toast")
            self.class_binding("textual.widgets._toast", "ToastRack")
            caller = frame.f_back
            assert caller is not None and caller.f_code is self.test_function.__code__
            predicate = frame.f_locals["predicate"]
            assert type(predicate) is FunctionType and predicate.__globals__ is vars(
                self.item.module
            )
            assert (
                predicate.__code__.co_qualname
                == self.test_function.__code__.co_qualname + ".<locals>.<lambda>"
            )
            record = self.gate.source(self.item.module)
            expected = nested(record[5], predicate.__code__)
            assert expected is not None and shape(expected) == shape(predicate.__code__)
            assert predicate.__defaults__ is None and predicate.__kwdefaults__ is None
            cells = tuple(
                zip(predicate.__code__.co_freevars, predicate.__closure__, strict=True)
            )
            assert {name for name, _ in cells} == {
                "app",
                "choice",
                "previous_toasts",
                "target",
            }
            assert all(
                cell.cell_contents is caller.f_locals[name] for name, cell in cells
            )
            self.gate.functions[id(predicate)] = (
                predicate,
                predicate.__code__,
                predicate.__globals__,
                None,
                None,
                (),
                predicate.__closure__,
                tuple((cell, cell.cell_contents) for _, cell in cells),
                vars(predicate).get("__wrapped__"),
            )
        elif label == "resolver":
            owner = frame.f_locals["self"]
            if not self.real_ui:
                assert type(owner) is self.class_binding(
                    CAPACITY_TEST, "_OutcomeHarness"
                )
                self.harness = owner
            else:
                assert (
                    owner is self.video and frame.f_locals["artifact"] is self.artifact
                )
        elif label == "runtimes":
            assert (
                frame.f_back.f_code
                is self.fixture_defs["retire_test_app_owners"][1].__code__
            )
            assert self.module(FACTORY)._created_apps == [self.app]
            self.cleanup_order.append("runtimes")
        elif label == "executor":
            caller = frame.f_back
            retire_code = self.fixture_defs["retire_test_app_owners"][1].__code__
            for _ in range(12):
                if caller is None or caller.f_code is retire_code:
                    break
                caller = caller.f_back
            if caller is None or caller.f_code is not retire_code:
                return
            assert type(frame.f_locals["self"].shutdown_default_executor) is MethodType
            assert frame.f_locals[
                "self"
            ].shutdown_default_executor.__func__ is self.function(
                "asyncio.base_events", "BaseEventLoop.shutdown_default_executor"
            )
            self.cleanup_order.append("executor")
        elif label == "directories":
            assert (
                frame.f_back.f_code
                is self.fixture_defs["retire_test_app_owners"][1].__code__
            )
            self.cleanup_order.append("directories")
            factory = self.module(FACTORY)
            assert not any(
                (
                    factory._created_apps,
                    factory._created_dirs,
                    factory._created_databases,
                    factory._created_instance_locks,
                    factory._active_service_patches,
                )
            )
            assert all(not directory.exists() for directory in self.directories)
        elif label == "test":
            assert frame.f_globals is vars(self.item.module)
            assert frame.f_locals["artifact"] is self.artifact
            if self.real_ui:
                assert (
                    frame.f_locals["app"] is self.app
                    and frame.f_locals["console"] is self.console
                )
                if self.first:
                    assert frame.f_locals["external_save_supported"] is False
                if (
                    self.item.name
                    == "test_discard_and_quit_over_the_picker_exits_without_reopening_the_choice"
                ):
                    original_wait = frame.f_locals["wait_for_screen"]
                    assert (
                        type(original_wait) is MethodType
                        and original_wait.__self__ is self.video
                    )
                    assert (
                        original_wait.__func__
                        is vars(vars(sys.modules[VIDEO])["ConsoleVideoController"])[
                            "_wait_for_console_screen_result"
                        ]
                    )
                    observer = frame.f_locals["recording_wait_for_screen"]
                    self._captured_function(
                        observer,
                        {
                            name: frame.f_locals[name]
                            for name in (
                                "wait_for_screen",
                                "quit_approved",
                                "choices_after_approval",
                            )
                        },
                    )
                assert (
                    self.artifact.stream.closed
                    and self.artifact.stream.close_calls == 1
                )
            else:
                assert frame.f_locals["harness"] is self.harness
        else:
            raise AssertionError("unexpected fixed event")
        self.count(label)

    def finish(self, call_passed):
        self.gate.loaded()
        self.gate.unchanged()
        self.native_unchanged()
        for definition, body in self.fixture_defs.values():
            assert definition.func is body and definition.scope == "function"
        main, path, data, wrapper, body, entry, wrapper_code, body_code, entry_code = (
            self.launcher
        )
        assert path.read_bytes() == data and vars(main)["main"] is entry
        assert vars(main)["user_fixture_default_owner"] is wrapper
        assert (
            wrapper.__code__ is wrapper_code
            and body.__code__ is body_code
            and entry.__code__ is entry_code
        )
        assert (
            wrapper.__closure__[0].cell_contents is body
            and vars(wrapper)["__wrapped__"] is body
        )
        assert wrapper.__globals__ is vars(sys.modules["contextlib"])
        assert body.__globals__ is vars(main) and entry.__globals__ is vars(main)
        assert wrapper.__defaults__ is None and wrapper.__kwdefaults__ is None
        assert (
            body.__defaults__ is None
            and body.__kwdefaults__ is None
            and body.__closure__ is None
        )
        assert (
            entry.__defaults__ is None
            and entry.__kwdefaults__ is None
            and entry.__closure__ is None
        )
        if call_passed:
            for label in (
                "test",
                "artifact",
                "drain_fixture_yield",
                "drain_fixture_return",
                "retire_fixture_yield",
                "retire_fixture_return",
            ):
                assert self.counts.get(label, 0) == 1, label
            if self.real_ui:
                for label in (
                    "factory",
                    "mounted",
                    "picker",
                    "worker",
                    "runtimes",
                    "directories",
                    "executor",
                ):
                    assert self.counts.get(label, 0) == 1, label
                assert self.counts.get("harness", 0) == 0
                for label in ("copy", "notify", "until"):
                    assert self.counts.get(label, 0) == int(self.first), label
                assert self.counts.get("capability", 0) == 2 * int(self.first)
                assert self.cleanup_order == [
                    "runtimes",
                    "executor",
                    "directories",
                    "retire_fixture",
                ]
                assert self.worker.is_finished
                assert self.worker._task is not None and self.worker._task.done()
                if self.first:
                    assert self.worker._error is None
                    assert (
                        self.counts.get("cleanup_recorder", 0) == 1
                        and self.counts.get("quit_recorder", 0) == 0
                    )
                    assert self.save_returns == ["retained"] * 3
                    assert self.counts.get("resolver", 0) == 1
                elif (
                    self.item.name
                    == "test_only_an_explicit_discard_throws_the_video_away"
                ):
                    assert self.save_returns == ["retained"]
                    assert self.worker._error is None
                    assert (
                        self.counts.get("cleanup_recorder", 0) == 1
                        and self.counts.get("quit_recorder", 0) == 0
                    )
                    assert self.counts.get("resolver", 0) == 1
                else:
                    assert self.save_returns in ([], ["ownership-ended"])
                    assert (
                        self.worker._error is None
                        or type(self.worker._error) is asyncio.CancelledError
                    )
                    assert (
                        self.counts.get("cleanup_recorder", 0) == 0
                        and self.counts.get("quit_recorder", 0) == 1
                    )
                    assert self.counts.get("resolver", 0) in (0, 1)
            else:
                for label in (
                    "factory",
                    "mounted",
                    "picker",
                    "worker",
                    "notify",
                    "runtimes",
                    "directories",
                    "executor",
                ):
                    assert self.counts.get(label, 0) == 0, label
                assert (
                    self.counts.get("capability", 0)
                    == self.counts.get("copy", 0)
                    == self.counts.get("save", 0)
                    == self.counts.get("resolver", 0)
                    == 1
                )
                assert self.save_returns == ["retained"]
                assert self.counts.get("harness", 0) == 1

    def receipt(self):
        return {
            "gate": self.gate.receipt(),
            "events": self.counts,
            "save_returns": self.save_returns,
            "cleanup_order": self.cleanup_order,
            "original_fixture_yield_offsets": {
                self.codes[code]: offset
                for code, offset in self.fixture_yield_offsets.items()
            },
            "route": "actual Windows App/picker"
            if self.real_ui
            else "controlled unsupported harness; no App claim",
            "actual_unsupported_branch": self.first and self.counts.get("test", 0) == 1,
            "launcher": {
                "spec_name": "Tests.windows_private_fixture_runner",
                "sha256": hashlib.sha256(self.launcher[2]).hexdigest(),
                "actual_main_stack_observed": True,
            },
            "scope": "Original Video3 plus controlled negative; no paid generation/OS paint/performance/full-platform claim",
        }
