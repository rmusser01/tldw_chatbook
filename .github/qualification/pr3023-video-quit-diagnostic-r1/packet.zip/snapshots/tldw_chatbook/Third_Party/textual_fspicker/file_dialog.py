"""Base file-oriented dialog."""

##############################################################################
# Backward compatibility.
from __future__ import annotations

##############################################################################
# Python imports.
import sys
from pathlib import Path

##############################################################################
# Textual imports.
from textual import on
from textual.app import ComposeResult
from textual.css.query import NoMatches
from textual.events import Mount, Resize
from textual.widgets import Button, Input, Label, Select

##############################################################################
# Local imports.
from .base_dialog import (
    ButtonLabel,
    FileSystemPickerScreen,
    InputBar,
    PathInput,
    resolve_typed_directory,
)
from .parts import DirectoryNavigation, DriveNavigation
from .path_filters import Filters
from .path_maker import MakePath


##############################################################################
class FileNameInput(PathInput):
    """The input bar's file-name/path field.

    Nothing of its own any more: both behaviours it was created for --
    `ctrl+a` selects the field (task-32229) and the focusing click selects
    the pre-fill (task-32251) -- now live on the shared `PathInput`, so
    every path field in every one of these dialogs gets them, not just
    this one. Kept as a name because the dialog's own docs and tests
    refer to it.
    """


##############################################################################
class FileFilter(Select[int]):
    """The file type filtering widget.

    This widget provides a file filter drop-down selection for all dialogs
    that inherit from
    [`BaseFileDialog`][textual_fspicker.file_dialog.BaseFileDialog].
    """


##############################################################################
class BaseFileDialog(FileSystemPickerScreen):
    """The base dialog for file-oriented picking dialogs."""

    DEFAULT_CSS = """
    BaseFileDialog InputBar {
        /* task-3304 (MI-15): the filename input carried no label at all --
           a bare box between the listing and the buttons. */
        #file-name-label {
            margin-right: 1;
            color: $text-muted;
        }
        Input {
            /* The filename field owns all of the row's flexible space; the
            file-type filter Select next to it gets a fixed width instead
            (see below) so it can't eat the Input's share (task-1479). */
            width: 1fr;
        }
        Select {
            /* Fixed, not `1fr`: a flexible Select would still starve the
            Input for width even without the app-bundle CSS-origin issue
            documented in components/_dialogs.tcss (that file pins this
            same width for FileSave/FileOpen so it also wins there, since
            no amount of specificity in *this* DEFAULT_CSS can beat a
            CSS_PATH-sourced bundle rule -- see that file's comment). */
            width: 24;
        }
    }
    """

    ERROR_A_FILE_MUST_BE_CHOSEN = "A file must be chosen"
    """An error to show the user when a file should be chosen."""

    def __init__(
        self,
        location: str | Path = ".",
        title: str = "Open",
        select_button: ButtonLabel = "",
        cancel_button: ButtonLabel = "",
        *,
        filters: Filters | None = None,
        default_file: str | Path | None = None,
        notes_context: str = "",
    ) -> None:
        """Initialise the base dialog.

        Args:
            location: Optional starting location.
            title: Optional title.
            select_button: The label for the select button.
            cancel_button: The label for the cancel button.
            filters: Optional filters to show in the dialog.
            default_file: The default filename to place in the input.
            notes_context: Which Library Notes folder door this is, if any;
                see `FileSystemPickerScreen.__init__` (task-32643).
        """
        super().__init__(
            location,
            title,
            select_button=select_button,
            cancel_button=cancel_button,
            notes_context=notes_context,
        )
        self._filters = filters
        """The filters for the dialog."""
        self._default_file = default_file
        """The default filename to put in the input field."""
        self._filter_select_changed_by_user = False
        """Whether ``_change_filter`` has seen a real, user-driven change yet.

        ``Select`` posts its own ``Changed`` message as a side effect of
        mounting with an explicit initial ``value=`` (not from anyone
        picking a filter) -- ``_change_filter`` must not treat that
        synthetic first event the same as a real one, or it steals focus
        away from wherever ``_focus_initial_widget()`` put it right after
        mount (task-1479).
        """
        self._select_folder_click_fill: str | None = None
        """The field value ``_select_file`` most recently click-filled,

        while the field still holds exactly that value (task-32122 round
        3). Lets ``FileSystemPickerScreen._resolve_select_folder_target``
        tell "a click on a file pre-filled this" (so ``Open`` still works)
        apart from "the user typed a folder path into the same field" --
        an earlier fix compared the field's value against whatever
        ``DirectoryNavigation`` happened to have highlighted instead, but
        ``_settle_highlight`` defaults ``highlighted`` to 0 on every
        repopulate (including the first load) and ".." is always option 0
        in a non-root directory, so a typed, never-clicked ".." was
        misread as a click echo and silently swallowed.

        Set only by ``_select_file`` (and only when ``_offer_select_
        folder`` is on -- other ``BaseFileDialog`` subclasses, e.g.
        ``FileSave``, never read this). Cleared by ``_update_field_label``
        the moment an ``Input.Changed`` delivers a value that no longer
        matches -- covers both genuine retyping and clicking a second,
        different file (which re-stamps it instead). The ``Input.Changed``
        message ``_select_file``'s own assignment posts is itself queued,
        not delivered synchronously, so comparing values (not just
        "was there a Changed event") is what keeps that self-echo from
        immediately clearing the flag it just set.
        """

    def on_resize(self, event: Resize) -> None:
        """Give the filename its own row when the footer needs compact layout."""
        self.set_class(event.size.width < 96 or event.size.height < 30, "-compact")

    def _input_bar(self) -> ComposeResult:
        """Provide any widgets for the input before, before the buttons."""
        # (task-3304, MI-15) Name the field: the bar's Input was unlabeled.
        # The label precedes the Input, so the task-1479 scoped lookup
        # (InputBar's first Input) still resolves the filename field.
        yield Label(
            self._field_label_text(self._default_file or ""), id="file-name-label"
        )
        yield FileNameInput(
            Path(self._default_file or "").name, placeholder="File name or path"
        )
        if self._filters:
            yield FileFilter(
                self._filters.selections,
                prompt="File filter",
                value=0,
                allow_blank=False,
            )

    def _field_label_text(self, value: str) -> str:
        """ "File name:", or "Folder path:" once the typed text is a folder.

        Only ``FileOpen(offer_select_folder=True)`` sets ``_offer_select_
        folder`` -- ``FileSave`` (also a ``BaseFileDialog``) never does, so
        this always returns "File name:" there (task-32122 AC#2: the field
        this swaps between is exactly the one "Select folder" now reads,
        so the label should say so precisely when that action would use
        it -- not for every keystroke of an ordinary filename).
        """
        if not getattr(self, "_offer_select_folder", False) or not value:
            return "File name:"
        try:
            candidate = MakePath.of(value).expanduser()
            if not candidate.is_absolute():
                candidate = self.query_one(DirectoryNavigation).location / candidate
            if candidate.is_dir():
                return "Folder path:"
        except (RuntimeError, OSError, ValueError):
            pass
        return "File name:"

    @on(Input.Changed)
    def _update_field_label(self, event: Input.Changed) -> None:
        """Keep the field label in step with what "Select folder" would use."""
        if not getattr(self, "_offer_select_folder", False):
            return
        try:
            bar_input = self.query_one(InputBar).query_one(Input)
        except Exception:
            return
        if event.input is not bar_input:
            # This screen also carries a hidden Ctrl+L path bar and a
            # search input (both Input widgets too); only the input bar's
            # own field selects a filename/folder.
            return
        if event.value != self._select_folder_click_fill:
            # A real edit (or this delivery is stale relative to a newer
            # click-fill) -- not the queued echo of the click-fill that
            # set it. See ``_select_folder_click_fill``'s docstring.
            self._select_folder_click_fill = None
        self._refresh_field_label(event.value)

    @on(Input.Changed)
    def _follow_typed_directory(self, event: Input.Changed) -> None:
        """Move the listing to a rooted directory path as it is typed.

        task-32229: this dialog made a terminal user click down from
        ``$HOME``; the only field that took typing was the file name, and
        it only resolved on Enter. Typing (or pasting) an absolute path --
        or one under ``~`` -- now walks the tree there straight away.

        Deliberately ROOTED paths only. A relative value is a file name in
        the directory being browsed, and one of them (a click on a folder
        row) is pre-filled by ``_select_file`` for "Select folder" to read:
        chasing those would move the ground under the value the user just
        picked.
        """
        try:
            bar_input = self.query_one(InputBar).query_one(Input)
        except NoMatches:
            return
        if event.input is not bar_input:
            # The screen's hidden Ctrl+L path bar and Ctrl+F search box are
            # `Input`s too -- see `_update_field_label`.
            return
        # Rooted-ness is decided on the stripped value; the RAW value is what
        # the resolver gets. Leading/trailing spaces are significant in a
        # POSIX directory name and `resolve_typed_directory` documents that
        # it takes the text exactly as typed (review round 1).
        typed = event.value.strip()
        try:
            rooted = typed.startswith("~") or MakePath.of(typed).is_absolute()
        except (OSError, ValueError):
            return
        if not rooted:
            return
        navigation = self.query_one(DirectoryNavigation)
        target = resolve_typed_directory(event.value, navigation.location)
        if isinstance(target, Path) and target != navigation.location:
            navigation.location = target

    @on(DirectoryNavigation.Changed)
    def _refresh_field_label_on_navigation(
        self, event: DirectoryNavigation.Changed
    ) -> None:
        """Keep the label in step with browsing too, not just typing.

        ``_field_label_text`` resolves a *relative* typed value against
        ``DirectoryNavigation.location`` -- so browsing elsewhere without
        touching the field again changes what "Select folder" would
        resolve it to, and the label must follow (Qodo review round 4:
        this handler used to exist only for ``Input.Changed``, so it went
        stale after pure navigation). This fires alongside
        ``FileSystemPickerScreen._on_directory_changed``'s own handler for
        the same message -- ``@on``-decorated handlers run for every class
        in the MRO, not just the most-derived one (see
        ``_focus_initial_widget``'s docstring in ``base_dialog.py``).
        """
        try:
            bar_input = self.query_one(InputBar).query_one(Input)
        except Exception:
            return
        self._refresh_field_label(bar_input.value)

    def _refresh_field_label(self, value: str) -> None:
        """Recompute and repaint ``#file-name-label`` for ``value``."""
        if not getattr(self, "_offer_select_folder", False):
            return
        try:
            label = self.query_one("#file-name-label", Label)
        except Exception:
            return
        label.update(self._field_label_text(value))

    @on(Mount)
    def _initial_filter(self) -> None:
        """Set the initial filter once the DOM is ready."""
        if self._filters:
            self.query_one(DirectoryNavigation).file_filter = self._filters[0]

    @on(DirectoryNavigation.Selected)
    def _select_file(self, event: DirectoryNavigation.Selected) -> None:
        """Handle a file being selected in the picker.

        Args:
            event: The event to handle.
        """
        # Scoped through InputBar, not a bare `self.query_one(Input)`: the
        # screen also carries a hidden `#path-input` (Ctrl+L) and a hidden
        # `#search-input` (Ctrl+F), both mounted before InputBar's own
        # filename Input in the compose tree, so an unscoped query_one(Input)
        # silently grabs one of those instead (task-1479).
        file_name = self.query_one(InputBar).query_one(Input)
        file_name.value = str(event.path.name)
        file_name.focus()
        if getattr(self, "_offer_select_folder", False):
            self._select_folder_click_fill = file_name.value

    @on(Input.Changed)
    def _clear_error(self) -> None:
        """Clear any error that might be showing."""
        super()._clear_error()

    @on(Select.Changed)
    def _change_filter(self, event: Select.Changed) -> None:
        """Handle a change in the filter.

        Args:
            event: The event to handle.
        """
        if event.select.id in {"listing-sort", "listing-direction"}:
            return
        if self._filters is not None and isinstance(event.value, int):
            self.query_one(DirectoryNavigation).file_filter = self._filters[event.value]
        else:
            self.query_one(DirectoryNavigation).file_filter = None
        if not self._filter_select_changed_by_user:
            # The first Changed event is Select's own mount-time side effect
            # (see `_filter_select_changed_by_user`'s docstring), not a user
            # picking a filter -- apply the filter above (matches
            # `_initial_filter`'s own mount-time assignment) but don't move
            # focus for it (task-1479).
            self._filter_select_changed_by_user = True
            return
        self.query_one(DirectoryNavigation).focus()

    def _should_return(self, candidate: Path) -> bool:
        """Final check on a picked file before returning it to the caller.

        Args:
            candidate: The file to check.

        Returns:
            `True` if the file should be returned, `False` if not.

        Note:
            This method is designed to be called as a final check; this is a
            good place to set up the display of an error before returning
            `False`, for example.
        """
        del candidate
        return True

    @on(Input.Submitted)
    @on(Button.Pressed, "#select")
    def _confirm_file(self, event: Input.Submitted | Button.Pressed) -> None:
        """Confirm the selection of the file in the input box.

        Args:
            event: The event to handle.
        """
        event.stop()
        # Scoped through InputBar -- see `_select_file` above for why a bare
        # `self.query_one(Input)` is ambiguous on this screen (task-1479).
        # Getting this wrong means the real filename Input is never read: a
        # keyboard user presses Enter on the (correctly focused, correctly
        # filled) filename field, but this handler reads back the empty
        # hidden `#path-input` instead and rejects with "A file must be
        # chosen" -- the dialog silently refuses to confirm at all.
        file_name = self.query_one(InputBar).query_one(Input)

        # Only even try and process this if there's some input.
        if not file_name.value:
            self._set_error(self.ERROR_A_FILE_MUST_BE_CHOSEN)
            return

        # If it looks like the user is typing in some sort of home
        # directory path... (does pathlib let me test for this, or at
        # least ask what the home character is? Docs don't mention this;
        # so for now I'm going to hard-code this).
        if file_name.value.startswith("~"):
            # ...let's simply expand and go with that.
            try:
                chosen = MakePath.of(file_name.value).expanduser()
            except RuntimeError as error:
                self._set_error(str(error))
                return
        else:
            # It's not a home directory path, so let's combine with the
            # location of the directory navigator widget.
            chosen = (
                self.query_one(DirectoryNavigation).location / file_name.value
            ).resolve()

        # If it's a directory, approach it like it's the user simply
        # doing a "cd".
        try:
            if chosen.is_dir():
                if sys.platform == "win32":
                    if drive_letter := MakePath.of(chosen).drive:
                        # Ensure DriveNavigation is present before querying
                        try:
                            drive_nav = self.query_one(DriveNavigation)
                            drive_nav.drive = drive_letter
                        except Exception:  # QueryError if not present
                            pass  # Silently ignore if DriveNavigation isn't there (e.g. non-Windows)
                self.query_one(DirectoryNavigation).location = chosen
                self.query_one(DirectoryNavigation).focus()
                self.query_one(InputBar).query_one(Input).value = ""
                return
        except PermissionError:
            self._set_error(self.ERROR_PERMISSION_ERROR)
            return

        # If the chosen file passes the final tests...
        if self._should_return(chosen):
            # ...return it.
            self.dismiss(result=chosen)


### file_dialog.py ends here
