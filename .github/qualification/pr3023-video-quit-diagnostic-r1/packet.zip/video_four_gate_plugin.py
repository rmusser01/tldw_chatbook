"""Four fixed original Windows Video bodies; observer failures never interrupt native cleanup."""

import hashlib
import json
import sys
import threading
from pathlib import Path

import pytest
from video_reader import VideoReader

HERE = Path(__file__).resolve().parent
TOOL_NAME = "video-four-fixed-fixtures"


def pytest_addoption(parser):
    parser.addoption("--video-four-installed-root", required=True)
    parser.addoption("--video-four-archive", required=True)


def pytest_collection_modifyitems(items):
    allowed = json.loads((HERE / "nodeids.json").read_text())["video_four"]
    assert [item.nodeid for item in items] == allowed, (
        "outside exact ordered Video4 collection"
    )


class Observation:
    def __init__(self, item):
        self.item = item
        root = Path(item.config.getoption("--video-four-installed-root")).resolve()
        archive = Path(item.config.getoption("--video-four-archive")).resolve()
        assert not archive.is_relative_to(root)
        self.output = archive / hashlib.sha256(item.nodeid.encode()).hexdigest()[:20]
        self.output.mkdir(parents=True, exist_ok=False)
        self.reader = VideoReader(root, item)
        self.errors = []
        self.overflow = False
        self.tool = None
        self.registered = {}
        self.masks = {}
        self.cleanup_safe = True
        self.closed = False
        self.call_passed = False
        self.primary = None
        self.profile = (
            sys.getprofile(),
            sys.gettrace(),
            threading.getprofile(),
            threading.gettrace(),
        )
        self.foreign = {}

    def error(self, event, error):
        if len(self.errors) < 32:
            row = {"event": event, "error": type(error).__name__}
            if event == "final-source-fixture-abi":
                try:
                    trace = error.__traceback__
                    while trace is not None and trace.tb_next is not None:
                        trace = trace.tb_next
                    if trace is not None:
                        row["failure_site"] = {
                            "file": Path(trace.tb_frame.f_code.co_filename).name,
                            "function": trace.tb_frame.f_code.co_name,
                            "line": trace.tb_lineno,
                        }
                    worker = self.reader.worker
                    task = worker._task
                    row["worker_endpoint"] = {
                        "is_finished": worker.is_finished,
                        "state": worker.state.name,
                        "error_module": type(worker._error).__module__,
                        "error_type": type(worker._error).__qualname__,
                        "task_present": task is not None,
                        "task_done": task.done() if task is not None else None,
                    }
                except BaseException as diagnostic:
                    row["diagnostic_error"] = type(diagnostic).__name__
            self.errors.append(row)
        else:
            self.overflow = True

    def frame(self, code):
        frame = sys._getframe(1)
        for _ in range(12):
            if frame is None:
                break
            if frame.f_code is code:
                return frame
            frame = frame.f_back
        raise AssertionError("fixed original frame absent")

    def start(self):
        self.reader.prepare()
        monitor = sys.monitoring
        for tool in range(6):
            self.foreign[tool] = (
                monitor.get_tool(tool),
                monitor.get_events(tool),
                {
                    code: monitor.get_local_events(tool, code)
                    for code in self.reader.codes
                },
            )
        for tool in range(5, 0, -1):
            if tool == monitor.DEBUGGER_ID or monitor.get_tool(tool) is not None:
                continue
            try:
                monitor.use_tool_id(tool, TOOL_NAME)
            except ValueError:
                continue
            self.tool = tool
            break
        assert self.tool is not None, "no unowned monitoring tool"
        assert monitor.get_events(self.tool) == 0
        for event, callback in (
            (monitor.events.PY_YIELD, self.yielded),
            (monitor.events.PY_RETURN, self.returned),
            (monitor.events.PY_START, self.started),
        ):
            previous = monitor.register_callback(self.tool, event, callback)
            if previous is not None:
                monitor.register_callback(self.tool, event, previous)
                self.cleanup_safe = False
                raise AssertionError("free tool has foreign callback")
            self.registered[event] = callback
        for code, label in self.reader.codes.items():
            assert monitor.get_local_events(self.tool, code) == 0
            mask = (
                monitor.events.PY_START
                if label in self.reader.start_labels
                else monitor.events.PY_RETURN
            )
            if label in self.reader.yield_labels:
                mask |= monitor.events.PY_YIELD
            self.masks[code] = mask
            monitor.set_local_events(self.tool, code, mask)
        assert monitor.get_events(self.tool) == 0

    def yielded(self, code, offset, value):
        try:
            self.reader.yielded(
                self.frame(code), value, self.reader.codes[code], offset
            )
        except BaseException as error:
            self.error("yield:" + self.reader.codes.get(code, "unknown"), error)

    def returned(self, code, offset, value):
        try:
            self.reader.returned(self.frame(code), value, self.reader.codes[code])
        except BaseException as error:
            self.error("return:" + self.reader.codes.get(code, "unknown"), error)

    def started(self, code, offset):
        try:
            self.reader.started(self.frame(code), self.reader.codes[code])
        except BaseException as error:
            self.error("start:" + self.reader.codes.get(code, "unknown"), error)

    def retire(self):
        if self.tool is None:
            return
        monitor, tool = sys.monitoring, self.tool
        if monitor.get_tool(tool) != TOOL_NAME:
            self.error("tool-owner-changed", AssertionError())
            self.cleanup_safe = False
            return
        try:
            assert monitor.get_events(tool) == 0
        except BaseException as error:
            self.error("global-mask-changed", error)
            self.cleanup_safe = False
        for code, expected in self.masks.items():
            try:
                assert monitor.get_local_events(tool, code) == expected
                monitor.set_local_events(tool, code, 0)
            except BaseException as error:
                self.error("disable-local", error)
                self.cleanup_safe = False
        for event, callback in self.registered.items():
            try:
                previous = monitor.register_callback(tool, event, None)
                if previous is not callback:
                    monitor.register_callback(tool, event, previous)
                    self.cleanup_safe = False
                    raise AssertionError("owned callback changed")
            except BaseException as error:
                self.error("unregister-local", error)
                self.cleanup_safe = False
        if self.cleanup_safe:
            try:
                assert monitor.get_tool(tool) == TOOL_NAME
                assert monitor.get_events(tool) == 0
                assert all(
                    monitor.get_local_events(tool, code) == 0 for code in self.masks
                )
                monitor.free_tool_id(tool)
                assert monitor.get_tool(tool) is None
                self.tool = None
            except BaseException as error:
                self.error("free-owned-tool", error)

    def close(self, teardown_passed):
        assert not self.closed
        self.closed = True
        self.retire()
        try:
            self.reader.finish(self.call_passed)
        except BaseException as error:
            self.error("final-source-fixture-abi", error)
        current = (
            sys.getprofile(),
            sys.gettrace(),
            threading.getprofile(),
            threading.gettrace(),
        )
        profile_unchanged = all(
            actual is expected
            for actual, expected in zip(current, self.profile, strict=True)
        )
        if not profile_unchanged:
            self.error("foreign-profile-trace-changed", AssertionError())
        try:
            monitor = sys.monitoring
            for tool, (owner, events, local) in self.foreign.items():
                assert (
                    monitor.get_tool(tool) == owner
                    and monitor.get_events(tool) == events
                )
                assert all(
                    monitor.get_local_events(tool, code) == mask
                    for code, mask in local.items()
                )
        except BaseException as error:
            self.error("foreign-monitor-state-changed", error)
        complete = (
            self.call_passed
            and teardown_passed
            and not self.errors
            and not self.overflow
            and self.tool is None
        )
        receipt = (
            self.reader.receipt()
            if self.reader.launcher is not None
            else {"gate": self.reader.gate.receipt()}
        )
        receipt.update(
            nodeid=self.item.nodeid,
            call_passed=self.call_passed,
            original_teardown_passed=teardown_passed,
            gate_complete=complete,
            observer_errors=self.errors,
            observer_error_overflow=self.overflow,
            owned_tool_retired=self.tool is None,
            profile_trace_unchanged=profile_unchanged,
        )
        with (self.output / "gate.json").open("x", encoding="utf-8") as stream:
            json.dump(receipt, stream, indent=2)
            stream.write("\n")
        return complete


@pytest.hookimpl(hookwrapper=True, tryfirst=True)
def pytest_runtest_setup(item):
    observation = Observation(item)
    item._video_four_observation = observation
    try:
        observation.start()
    except BaseException as primary:
        observation.primary = primary
        observation.error("setup", primary)
        raise
    yield


@pytest.hookimpl(hookwrapper=True)
def pytest_runtest_makereport(item, call):
    outcome = yield
    report = outcome.get_result()
    observation = getattr(item, "_video_four_observation", None)
    if observation is None:
        return
    if call.excinfo is not None and observation.primary is None:
        observation.primary = call.excinfo.value
    if report.when == "call":
        observation.call_passed = report.passed
    elif report.when == "teardown":
        # All original teardown hookwrappers, including config-consumer restore,
        # have returned before pytest creates this natural teardown report.
        try:
            complete = observation.close(report.passed)
        except BaseException as cleanup:
            complete = False
            observation.error("gate-archive-or-cleanup", cleanup)
            if observation.primary is not None:
                observation.primary.add_note(
                    "video_four_gate_cleanup:" + type(cleanup).__name__
                )
        if not complete:
            failures = getattr(item.config, "_video_four_gate_failures", None)
            if failures is None:
                failures = []
                item.config._video_four_gate_failures = failures
            failures.append(item.nodeid)


def pytest_sessionfinish(session, exitstatus):
    # Gate errors fail the command after native teardown, preserving raw reports.
    if exitstatus == 0 and getattr(session.config, "_video_four_gate_failures", ()):
        session.exitstatus = pytest.ExitCode.TESTS_FAILED
