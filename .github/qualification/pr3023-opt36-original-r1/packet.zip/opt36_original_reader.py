"""Finite original-helper bindings; no candidate adapter or native calls."""

import ctypes as C
import functools
import hashlib
import importlib.machinery
from importlib.metadata import version
import json
import os
import stat
import sys
import threading
from pathlib import Path
from types import FunctionType

from ac77_source_gate import Gate, HERE, nested, shape


R13 = "Tests.Backup_Recovery.test_windows_metadata_baseline_opt36_opt74"
NEW = "Tests.Backup_Recovery.test_user_data_directory_posture_adapter"
BASELINE = (
    "test_current_config_stamps_preserve_five_fields_order_duplicates_missing_empty",
    "test_current_config_custom_posture_affinity_arguments_and_oserror",
    "test_current_config_scalar_native_schedule",
    "test_current_scalar_and_batch_use_identical_requested_workload",
)
CAUSAL = "test_shipping_helper_uses_one_fresh_batch_after_equal_values_and_retirement"
MEMO = (
    "test_windows_memo_warm_reload_replacement_and_native_permissions",
    "test_windows_memo_refuses_public_ancestor_and_preserves_original_key_timing",
    "test_windows_bracketed_posture_drift",
)


class OriginalReader:
    def __init__(self, root, pytest_config):
        runtime = json.loads((HERE / "runtime-binding.json").read_text())
        assert os.name == "nt" and sys.platform == "win32" and C.sizeof(C.c_void_p) == 8
        assert sys.version_info[:3] == (3, 12, 10)
        assert sys.modules["pytest"].__version__ == runtime["pytest"]
        assert version("textual") == runtime["textual"]
        self.gate = Gate(root, runtime["sources"], pytest_config=pytest_config)
        self.callbacks, self.observers, self.caches = [], [], []
        self.caller = threading.get_ident()
        self.generator_code = None
        self.launcher = None
        self.prepared, self.child_mode = False, False
        self.wrapper_code, self.getter_code = None, None
        self.children, self.resolvers = {}, {}

    def prepare(self, item):
        self.item_nodeid = item.nodeid
        assert item.module.__name__ in {R13, NEW}
        assert item.originalname in ((*BASELINE, *MEMO) if item.module.__name__ == R13 else (CAUSAL,))
        assert not hasattr(item, "callspec")
        self.child_mode = os.environ.get("TLDW_TEST_PRIVATE_PROFILE_NODE") == item.nodeid
        assert not self.child_mode or item.originalname in MEMO
        if self.child_mode:
            assert sys.modules["__main__"].__spec__.name == "pytest.__main__"
        self.gate.loaded()
        from _pytest.assertion import rewrite
        for module, *_ in self.gate.sources.values():
            loader = module.__loader__
            assert type(loader) in (importlib.machinery.SourceFileLoader, rewrite.AssertionRewritingHook)
            if not module.__name__.startswith("Tests."):
                assert type(loader) is importlib.machinery.SourceFileLoader
        files = sys.modules["tldw_chatbook.Utils.windows_files"]
        storage = sys.modules["tldw_chatbook.Backup_Recovery.storage_admission"]
        platform_files = sys.modules["tldw_chatbook.Utils.platform_files"]
        assert type(storage.os) is files.WindowsOS and storage.os is platform_files.os
        assert platform_files.__all__ == ["fcntl", "os"]
        assert files.C is C and files.contextlib is sys.modules["contextlib"]
        assert files.functools is functools and files._stat is stat and files._os is os
        assert storage.stat is stat and storage._posture.__globals__ is vars(storage)
        for owner, name, capacity in ((files, "_native", 1), (files._Native, "_decoded_security", 128)):
            cache = vars(owner)[name]
            assert type(cache) is functools._lru_cache_wrapper
            body = vars(cache)["__wrapped__"]
            self.gate.pin(body)
            info = cache.cache_info
            assert info.__self__ is cache and info.__name__ == "cache_info"
            assert info().maxsize == capacity
            self.caches.append((owner, name, cache, body))
        for name in ("stat", "stat_for_admission", "stat_many_for_admission", "_stat_handle"):
            bound = vars(storage.os)[name]
            assert bound.__self__ is storage.os and bound.__func__ is vars(files.WindowsOS)[name]
        original = vars(sys.modules[R13]._native_returns)["__wrapped__"]
        self.gate.pin(original)
        self.generator_code = original.__code__
        assert original.__globals__ is vars(sys.modules[R13])
        self.gate.module(sys.modules["contextlib"])
        self.gate.pin(sys.modules["contextlib"].contextmanager)
        self.gate.pin(sys.modules["contextlib"]._GeneratorContextManager.__enter__)
        self.gate.pin(sys.modules["contextlib"]._GeneratorContextManager.__exit__)
        self.stock_resolver = vars(sys.modules["tldw_chatbook.config"])["_resolve_user_data_dir"]
        if item.originalname in MEMO:
            public = vars(sys.modules[R13])[item.originalname]
            assert vars(public)["_private_profile_test"] is True
            self.wrapper_code = public.__code__
            self.case_body = vars(public)["__wrapped__"]
            self.getter_code = vars(sys.modules["tldw_chatbook.config"].get_user_data_dir)["__wrapped__"].__code__
        if not self.child_mode:
            self._launcher()
        self.prepared = True

    def observe_wrapper(self, frame):
        assert frame.f_code is self.wrapper_code
        assert frame.f_globals is vars(sys.modules["Tests.private_profile"])
        assert threading.get_ident() == self.caller
        local = frame.f_locals
        assert local["request"].node.nodeid == self.item_nodeid
        assert local["function"] is self.case_body
        if self.child_mode:
            assert "process" not in local
            return
        process = local.get("process")
        if process is None:
            return
        assert type(process) is sys.modules["asyncio.subprocess"].Process
        assert type(process.pid) is int and process.pid > 0 and process.pid != os.getpid()
        self.children[process.pid] = (process, local["report"], local["log"], local["work"], local["profile"], local["timeout"])

    def observe_resolver(self, frame):
        assert frame.f_code is self.getter_code
        assert frame.f_globals is vars(sys.modules["tldw_chatbook.config"])
        function = frame.f_globals["_resolve_user_data_dir"]
        if function is self.stock_resolver:
            return
        assert self.child_mode and type(function) is FunctionType
        allowed = {"_warm.<locals>.resolve", MEMO[1] + ".<locals>.resolve", MEMO[2] + ".<locals>.changed"}
        assert function.__code__.co_qualname in allowed
        if self.resolvers.get(id(function)) is function:
            records = [record for record in self.callbacks if record[0] is function]
            assert len(records) == 1
            _function, code, namespace, closure, cells = records[0]
            assert function.__code__ is code and function.__globals__ is namespace
            assert function.__defaults__ is None and function.__kwdefaults__ is None
            assert function.__closure__ is closure
            assert all(cell.cell_contents is value for cell, value in cells)
            return
        parent = frame.f_back
        while parent is not None and all(parent.f_locals.get(name) is not function for name in ("resolve", "changed")):
            parent = parent.f_back
        assert parent is not None and parent.f_globals is vars(sys.modules[R13])
        self._callback(function, parent.f_locals)
        original = parent.f_locals["original"]
        assert original is self.stock_resolver or id(original) in self.resolvers
        self.resolvers[id(function)] = function

    def _launcher(self):
        # python -m naturally executes this actual installed module as __main__.
        # Keep that truthful relation; do not add an import alias or rerun it.
        main = sys.modules["__main__"]
        row = self.gate.rows["Tests.windows_private_fixture_runner"]
        path = self.gate.root / row["logical_path"]
        data = (HERE / row["snapshot_path"]).read_bytes()
        assert Path(main.__file__).resolve() == path and path.read_bytes() == data
        assert hashlib.sha256(data).hexdigest() == row["sha256"]
        assert main.__spec__.name == "Tests.windows_private_fixture_runner"
        assert Path(main.__spec__.origin).resolve() == path
        assert type(main.__loader__) is importlib.machinery.SourceFileLoader
        compiled = compile(data, str(path), "exec", dont_inherit=True)
        wrapper, entry = vars(main)["user_fixture_default_owner"], vars(main)["main"]
        body = vars(wrapper)["__wrapped__"]
        for function in (entry, body):
            assert type(function) is FunctionType and function.__globals__ is vars(main)
            expected = nested(compiled, function.__code__)
            assert expected is not None and shape(expected) == shape(function.__code__)
            assert function.__defaults__ is None and function.__kwdefaults__ is None and function.__closure__ is None
        contextlib = sys.modules["contextlib"]
        expected_wrapper = nested(self.gate.source(contextlib)[5], wrapper.__code__)
        assert expected_wrapper is not None and shape(expected_wrapper) == shape(wrapper.__code__)
        assert wrapper.__globals__ is vars(contextlib) and wrapper.__code__.co_freevars == ("func",)
        assert wrapper.__defaults__ is None and wrapper.__kwdefaults__ is None
        assert len(wrapper.__closure__) == 1
        assert wrapper.__closure__[0].cell_contents is body and vars(wrapper)["__wrapped__"] is body
        frame = sys._getframe()
        while frame is not None and frame.f_code is not entry.__code__:
            frame = frame.f_back
        assert frame is not None and frame.f_globals is vars(main)
        self.launcher = (main, path, data, wrapper, body, entry, wrapper.__code__, body.__code__, entry.__code__)

    def _callback(self, function, local):
        assert type(function) is FunctionType and function.__globals__ is vars(sys.modules[R13])
        assert function.__defaults__ is None and function.__kwdefaults__ is None
        compiled = self.gate.source(sys.modules[R13])[5]
        expected = nested(compiled, function.__code__)
        assert expected is not None and shape(expected) == shape(function.__code__)
        cells = tuple(zip(function.__code__.co_freevars, function.__closure__ or ()))
        assert all(cell.cell_contents is local[name] for name, cell in cells)
        self.callbacks.append((function, function.__code__, function.__globals__, function.__closure__,
                               tuple((cell, cell.cell_contents) for _name, cell in cells)))

    def observe_yield(self, frame, value):
        assert frame.f_code is self.generator_code and frame.f_globals is vars(sys.modules[R13])
        local, files = frame.f_locals, sys.modules["tldw_chatbook.Utils.windows_files"]
        assert threading.get_ident() == self.caller == local["caller"]
        win, native = local["win"], local["native"]
        assert type(win) is files.WindowsOS and type(native) is files._Native
        assert win is sys.modules["tldw_chatbook.Backup_Recovery.storage_admission"].os
        assert native.kernel is local["kernel"] and native.nt is local["nt"]
        assert type(native.user_sid) is str and native.user_sid == local["token_user_sid"]
        for name in ("opened", "closed", "started", "returned", "frame_for", "qualified_frame", "source_current"):
            self._callback(local[name], local)
        assert vars(native.nt)["NtCreateFile"] is local["opened"]
        assert vars(native.kernel)["CloseHandle"] is local["closed"]
        self._native_abi(files, native, local["real_open"], local["real_close"])
        monitor, slot = sys.monitoring, local["slot"]
        assert monitor.get_tool(slot) == "native-baseline-returns"
        assert monitor.get_events(slot) == 0
        for code, label in local["names"].items():
            assert monitor.get_local_events(slot, code) == monitor.events.PY_START | monitor.events.PY_RETURN
            assert label in {"open", "info", "ntfs", "security", "stat", "batch", "component"}
        assert type(value) is tuple and len(value) == 7
        expected = tuple(local[name] for name in ("counts", "ancestry", "births", "closes", "errors", "excluded", "security_observations"))
        assert all(a is b for a, b in zip(value, expected))
        self.observers.append((local, value, native, win))

    def _native_abi(self, files, native, real_open, real_close):
        assert native.kernel._name == "kernel32" and native.nt._name == "ntdll" and native.advapi._name == "advapi32"
        assert all(type(dll) is C.WinDLL for dll in (native.kernel, native.nt, native.advapi))
        assert (files._U32, files._I32, files._U16, files._P, files._HANDLE) == (C.c_uint32, C.c_int32, C.c_uint16, C.c_void_p, C.c_void_p)
        U, I, P, H = files._U32, files._I32, files._P, files._HANDLE
        fields = (
            (files._UnicodeString, [("Length", files._U16), ("MaximumLength", files._U16), ("Buffer", P)], 16),
            (files._ObjectAttributes, [("Length", U), ("RootDirectory", H), ("ObjectName", C.POINTER(files._UnicodeString)), ("Attributes", U), ("SecurityDescriptor", P), ("SecurityQualityOfService", P)], 48),
            (files._IOStatus, [("Status", P), ("Information", C.c_size_t)], 16),
            (files._FileInfo, [("attributes", U), ("created", U * 2), ("accessed", U * 2), ("written", U * 2), ("volume", U), ("size_high", U), ("size_low", U), ("links", U), ("index_high", U), ("index_low", U)], 52),
            (files._BasicInfo, [("created", C.c_int64), ("accessed", C.c_int64), ("written", C.c_int64), ("changed", C.c_int64), ("attributes", U)], 40),
        )
        for cls, expected, size in fields:
            assert cls.__bases__ == (C.Structure,) and cls.__module__ == files.__name__
            assert cls._fields_ == expected and C.sizeof(cls) == size and not vars(cls).get("_pack_")
        signatures = (
            (native.nt, "NtCreateFile", real_open, [C.POINTER(H), U, C.POINTER(files._ObjectAttributes), C.POINTER(files._IOStatus), P, U, U, U, U, P, U], I),
            (native.kernel, "CloseHandle", real_close, [H], I),
            (native.kernel, "GetFileInformationByHandle", None, [H, C.POINTER(files._FileInfo)], I),
            (native.kernel, "GetFileType", None, [H], U),
            (native.kernel, "GetVolumeInformationByHandleW", None, [H, P, U, P, P, P, P, U], I),
            (native.nt, "NtQueryVolumeInformationFile", None, [H, C.POINTER(files._IOStatus), P, U, U], I),
            (native.kernel, "GetFileInformationByHandleEx", None, [H, I, P, U], I),
            (native.kernel, "LocalFree", None, [P], P),
            (native.advapi, "GetSecurityInfo", None, [H, I, U, C.POINTER(P), P, C.POINTER(P), P, C.POINTER(P)], U),
            (native.advapi, "GetSecurityDescriptorLength", None, [P], U),
            (native.advapi, "GetSecurityDescriptorOwner", None, [P, C.POINTER(P), C.POINTER(I)], I),
            (native.advapi, "GetSecurityDescriptorDacl", None, [P, C.POINTER(I), C.POINTER(P), C.POINTER(I)], I),
            (native.advapi, "GetAce", None, [P, U, C.POINTER(P)], I),
            (native.advapi, "ConvertSidToStringSidW", None, [P, C.POINTER(P)], I),
            (native.nt, "RtlNtStatusToDosError", None, [I], U),
            (native.kernel, "GetCurrentProcess", None, [], H),
            (native.advapi, "OpenProcessToken", None, [H, U, C.POINTER(H)], I),
            (native.advapi, "GetTokenInformation", None, [H, I, P, U, C.POINTER(U)], I),
        )
        for dll, name, captured, arguments, result in signatures:
            function = captured if captured is not None else vars(dll)[name]
            assert type(function) is vars(dll)["_FuncPtr"] and function.__name__ == name
            assert function.argtypes == arguments and function.restype is result
            assert function._flags_ & C._FUNCFLAG_USE_LASTERROR

    def finish(self):
        self.gate.loaded()
        self.gate.unchanged()
        if self.launcher is not None:
            main, path, data, wrapper, body, entry, wrapper_code, body_code, entry_code = self.launcher
            assert path.read_bytes() == data and vars(main)["main"] is entry
            assert vars(main)["user_fixture_default_owner"] is wrapper
            assert wrapper.__code__ is wrapper_code and body.__code__ is body_code and entry.__code__ is entry_code
            assert wrapper.__closure__[0].cell_contents is body and vars(wrapper)["__wrapped__"] is body
            assert wrapper.__defaults__ is None and wrapper.__kwdefaults__ is None
            assert body.__globals__ is vars(main) and entry.__globals__ is vars(main)
            assert body.__defaults__ is None and entry.__defaults__ is None
            assert body.__kwdefaults__ is None and entry.__kwdefaults__ is None
        for owner, name, cache, body in self.caches:
            assert vars(owner)[name] is cache and vars(cache)["__wrapped__"] is body
        for function, code, namespace, closure, cells in self.callbacks:
            assert function.__code__ is code and function.__globals__ is namespace
            assert function.__defaults__ is None and function.__kwdefaults__ is None
            assert function.__closure__ is closure and all(cell.cell_contents is value for cell, value in cells)
        expected = 2 if self.item_name == BASELINE[3] else 1 if self.item_name in {BASELINE[2], CAUSAL} else 0
        assert len(self.observers) == expected
        if self.item_name in MEMO:
            if self.child_mode:
                assert not self.children and self.resolvers
            else:
                assert len(self.children) == 1
                assert all(process.returncode is not None for process, *_rest in self.children.values())
        for local, _value, native, _win in self.observers:
            assert not local["errors"] and not local["excluded"] and not local["current"]
            assert local["births"] and len(local["births"]) == len(local["closes"])
            assert {id(row) for row in local["births"]} == {id(row) for row in local["closes"]}
            assert all(row["closes"] == [(True, 0)] for row in local["births"])
            assert native.nt.NtCreateFile is local["real_open"] and native.kernel.CloseHandle is local["real_close"]
            assert sys.monitoring.get_tool(local["slot"]) is None

    def receipt(self):
        return {"gate": self.gate.receipt(), "caller": self.caller,
                "scope": "original helper baseline/count or unchanged memo behavior; no candidate mutation controls",
                "private_profile_child": self.child_mode,
                "memo_resolver_callbacks": [{"code_qualname": function.__code__.co_qualname,
                    "definer": function.__globals__["__name__"], "source_shape_and_actual_lexical_cells_equal": True}
                    for function in self.resolvers.values()],
                "private_profile_children": [{"pid": process.pid, "returncode": process.returncode,
                    "xml": str(report), "log": str(log), "work": str(work), "profile": str(profile), "original_timeout": timeout,
                    "ownership": "Actual original asyncio Process observed in original private_profile wrapper; unchanged helper awaits/kills+awaits. No independent poll/ECHILD receipt."}
                    for process, report, log, work, profile, timeout in self.children.values()],
                "launcher": {"natural_module_name": "__main__", "spec_name": "Tests.windows_private_fixture_runner",
                    "path": str(self.launcher[1]), "sha256": hashlib.sha256(self.launcher[2]).hexdigest(),
                    "actual_main_stack_observed": True,
                    "limit": "Original owner restoration checks execute after pytest returns; process exit must be archived. No captured owner SID/token-handle receipt."} if self.launcher is not None else {
                        "natural_module_name": "__main__", "spec_name": "pytest.__main__",
                        "scope": "Original private_profile child argv, actual PID and exact child marker; fixture launcher not rerun or aliased in child."},
                "native_observers": [{"births": [dict(ordinal=i, **row) for i, row in enumerate(local["births"])],
                    "close_birth_ordinals": [next(i for i, birth in enumerate(local["births"]) if birth is row) for row in local["closes"]],
                    "counts": dict(local["counts"]), "ancestry": dict(local["ancestry"]),
                    "errors": local["errors"], "excluded": local["excluded"],
                    "security": local["security_observations"], "pending_births": len(local["current"]),
                    "actual_monitor_retired": sys.monitoring.get_tool(local["slot"]) is None}
                    for local, _value, _native, _win in self.observers]}
