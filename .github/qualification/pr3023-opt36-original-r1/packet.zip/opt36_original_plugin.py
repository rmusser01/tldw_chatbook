"""Observe only original seven baseline nodes, their children, and one count node."""

import hashlib
import json
import os
import sys
from pathlib import Path

import pytest

from opt36_original_reader import OriginalReader


if sys.flags.optimize:
    raise RuntimeError("OPT36 qualification requires enabled original assertions")


def pytest_addoption(parser):
    group = parser.getgroup("opt36-original")
    group.addoption("--opt36-checkout-root", default=os.environ.get("TLDW_OPT36_CHECKOUT_ROOT"))
    group.addoption("--opt36-gate-dir", default=os.environ.get("TLDW_OPT36_GATE_DIR"))


class Observation:
    def __init__(self, item):
        self.item, self.reader = item, OriginalReader(item.config.getoption("opt36_checkout_root"), item.config)
        self.reader.item_name = item.originalname
        self.errors, self.reports, self.slot = [], [], None

    def yielded(self, code, offset, value):
        frame = None
        try:
            frame = sys._getframe(1)
            assert frame.f_code is code
            if code is self.reader.generator_code:
                self.reader.observe_yield(frame, value)
            else:
                assert code is self.reader.wrapper_code
                self.reader.observe_wrapper(frame)
        except BaseException as error:
            self.errors.append(type(error).__name__ + ":" + str(error))
        finally:
            frame = None

    def returned(self, code, offset, value):
        frame = None
        try:
            frame = sys._getframe(1)
            assert code is self.reader.wrapper_code and frame.f_code is code
            self.reader.observe_wrapper(frame)
        except BaseException as error:
            self.errors.append("profile-return:" + type(error).__name__ + ":" + str(error))
        finally:
            frame = None

    def unwound(self, code, offset, error):
        if code is not self.reader.wrapper_code:
            return
        frame = None
        try:
            frame = sys._getframe(1)
            assert frame.f_code is code
            self.reader.observe_wrapper(frame)
        except BaseException as observer_error:
            self.errors.append("profile-unwind:" + type(observer_error).__name__ + ":" + str(observer_error))
        finally:
            frame = None

    def started(self, code, offset):
        frame = None
        try:
            frame = sys._getframe(1)
            assert code is self.reader.getter_code and frame.f_code is code
            self.reader.observe_resolver(frame)
        except BaseException as error:
            self.errors.append("memo-dispatch:" + type(error).__name__ + ":" + str(error))
        finally:
            frame = None

    def start(self):
        self.reader.prepare(self.item)
        monitor = sys.monitoring
        slot = next(n for n in range(5, 0, -1) if n != monitor.DEBUGGER_ID and monitor.get_tool(n) is None)
        monitor.use_tool_id(slot, "opt36-original-observer-bindings")
        self.slot = slot
        for event, callback in ((monitor.events.PY_YIELD, self.yielded), (monitor.events.PY_RETURN, self.returned),
                                (monitor.events.PY_START, self.started), (monitor.events.PY_UNWIND, self.unwound)):
            assert monitor.register_callback(self.slot, event, callback) is None
        monitor.set_local_events(self.slot, self.reader.generator_code, monitor.events.PY_YIELD)
        if self.reader.wrapper_code is not None:
            monitor.set_local_events(self.slot, self.reader.wrapper_code, monitor.events.PY_YIELD | monitor.events.PY_RETURN)
            monitor.set_local_events(self.slot, self.reader.getter_code, monitor.events.PY_START)
            monitor.set_events(self.slot, monitor.events.PY_UNWIND)

    def close(self):
        if self.slot is not None:
            monitor = sys.monitoring
            # Each owned resource is attempted independently even after failure.
            codes = tuple(code for code in (self.reader.generator_code, self.reader.wrapper_code, self.reader.getter_code) if code is not None)
            operations = [lambda: monitor.set_events(self.slot, 0)]
            operations.extend(lambda code=code: monitor.set_local_events(self.slot, code, 0) for code in codes)
            operations.extend(lambda event=event: monitor.register_callback(self.slot, event, None)
                              for event in (monitor.events.PY_YIELD, monitor.events.PY_RETURN, monitor.events.PY_START, monitor.events.PY_UNWIND))
            operations.append(lambda: monitor.free_tool_id(self.slot))
            for operation in operations:
                try:
                    operation()
                except BaseException as error:
                    self.errors.append("monitor-cleanup:" + type(error).__name__ + ":" + str(error))
            if monitor.get_tool(self.slot) is not None:
                self.errors.append("observer-tool-not-retired")
        try:
            if self.reader.prepared:
                self.reader.finish()
        except BaseException as error:
            self.errors.append("binding-or-drain:" + type(error).__name__ + ":" + str(error))
        root = Path(self.item.config.getoption("opt36_gate_dir"))
        root.mkdir(parents=True, exist_ok=True)
        path = root / (str(os.getpid()) + "-" + hashlib.sha256(self.item.nodeid.encode()).hexdigest() + ".json")
        document = {"nodeid": self.item.nodeid, "pid": os.getpid(), "parent_pid": os.getppid(),
                    "private_profile_node_marker": os.environ.get("TLDW_TEST_PRIVATE_PROFILE_NODE"),
                    "reports_before_teardown_result": self.reports,
                    "observer_errors": self.errors, "observation": self.reader.receipt() if self.reader.prepared else None,
                    "scope": "original helper baseline/count or three unchanged private-profile memo cases",
                    "child_scope": "Actual original private_profile Process/PID/wait-source relation only; fixed icacls subprocess.run has no captured PID. Outer Root process receipts are separate."}
        with path.open("x", encoding="utf-8") as stream:
            json.dump(document, stream, indent=2)
            stream.write("\n")
        assert not self.errors, self.errors


@pytest.hookimpl(hookwrapper=True, tryfirst=True)
def pytest_runtest_setup(item):
    observed = Observation(item)
    item._opt36_original_observation = observed
    try:
        observed.start()
    except BaseException as primary:
        observed.errors.append("setup:" + type(primary).__name__ + ":" + str(primary))
        try:
            observed.close()
        except BaseException as cleanup:
            primary.add_note("OPT36 original reader cleanup: " + type(cleanup).__name__)
        item._opt36_original_observation = None
        raise
    yield


@pytest.hookimpl(hookwrapper=True)
def pytest_runtest_makereport(item, call):
    result = yield
    observed = getattr(item, "_opt36_original_observation", None)
    if observed is not None:
        report = result.get_result()
        observed.reports.append({"when": report.when, "outcome": report.outcome})


@pytest.hookimpl(hookwrapper=True, tryfirst=True)
def pytest_runtest_teardown(item, nextitem):
    yield
    observed = getattr(item, "_opt36_original_observation", None)
    if observed is not None:
        observed.close()
