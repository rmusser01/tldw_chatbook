# R2 minimum retained-resolver reader correction — unrun

This packet addresses only the Important observer compatibility finding in the
independent R1 review SHA 53b90645cc844101ae3d1ea4cd356f7ace500abe4813e89bd931d9245c3bb813. R1 remains immutable and is not clear to run. This R2 is proposed for distinct
review, not self-accepted or executed. No product adapter exists.

Only `OriginalReader.observe_resolver` changes: after the existing child/type and
three finite qualname checks, an exact function already present in
`self.resolvers` must have exactly one existing callback record. Its actual code,
globals namespace, original closure tuple and every original cell content must
still have the captured identities. Defaults and keyword defaults must still be
None, the exact singleton values required by the original first-capture proof.
The method then returns without asking an exited creator frame to reappear.
The existing retained function references prevent id reuse from qualifying a new
function. Mutable collection cells retain identity; their legitimate contents
are not frozen or altered.

For every new identity, the original live-creator stack search, R13 namespace,
frozen compiled nested code/shape, lexical cell equality and stock/already proved
original-resolver chain remain unchanged. No producer is invoked, no fake frame
or alias is introduced, and no generic record/cache/checker mechanism is added.
The existing callback-record layout, receipt, final metadata validation and all
other reader methods remain AST-identical. There are nine inserted lines in one
method. Both complete TEST files, original seven bodies/decorators, native
observer, plugin, Gate, source/runtime/fixture data and four-command plan remain
byte-exact. The new causal TEST still has its count assertion at63 and later
64/65 assertions unreached if63 fails.

Static preparation uses only the explicit project Python3.12.11 interpreter.
Every one of the 29 Python asset AST/compile metadata records and all59 declared
slot AST hashes is independently recomputed/validated as data. The unchanged
pure stdlib verifier validates all44 asset rows,15 source rows and3 runtime rows.
No packet/product/TEST/plugin/reader imports or tests/native/Git/network actions
occurred. Forty-one asset bodies remain byte-identical to R1; only this report,
the reader and its static metadata change (plus the enclosing manifest).
`root-opt36-shipping-posture-controls-r2-reader.patch` is outside the packet so
its external44-asset+manifest publication shape stays45 physical entries.

The operational workflow/outer is a separate unrun proposal. Root must bind and
independently review the concrete selected Goal snapshot/publication, R2 packet
ZIP/manifest and original Windows runtime/fixture/process/hidden child archives
before execution. All R1 scope/evidence limits below remain applicable. Native
original7 plus three real children must qualify before the single causal node;
there is no actual RED, source fix, elapsed saving or acceptance here.

---

# Task28 initial original-source TEST/reader packet

Prepared for distinct review and Root publication/execution. **Unrun: no actual RED, native qualification, adapter source or selection is claimed.** This packet stages two genuine TEST paths and changes no product file. The initial plan selects the seven unchanged current-body R13 baselines, then one new actual shipping-helper count case. The separate31-case candidate draft is outside this packet's staged source and commands.

## Current contract and composition

The current task is e89882ebdebaa46fdae0332184abd79132e31a2f74b07f5a700aeb795b599abe, current bounded ADR126 is467a0e2f12332cc13ee5193128f5c2c783255c9db5603cf0fa3479d4abffdd43, and accepted ADR230 isdf370ebbfb9cdeabdc6e2bebe98404ab3d269514bf182649f77bf9b7298cae0d. Their exact bytes are included. The accepted design review62b785 remains the design anchor. Historical earlier task notes are preserved as history; the appended current plan governs. No task checkbox/status or governance file was changed here.

The original helper is config096361's ordered scalar storage._posture loop, projecting five fields and broadly returningNone on OSError. The direct route still uses current selected storage1ea88 and platform9e985/Windows6b665; no _observe_stamps or sixth descriptor field is substituted. Selected R4 cpfa786/admissiond8fa/generation4e33 and Task22 raw30a79/privatef3d remain the composition anchors in dependencies.json/source-map-selected-r4.json. Their product bodies are not changed. OPT74 closure801 and Task35 candidates are not part of this baseline.

## Genuine TESTs and exact sequence

1. Install the unchanged R13 file at Tests/Backup_Recovery/test_windows_metadata_baseline_opt36_opt74.py, SHA b91128b2b25cf3f3bc8bad48135b73b5e321b5cb3be528fc35f004841e6452f1. Preserve the full file byte for byte, including its unselected prototype controls and all original assertions/native operations/fixture cleanup/deadlines. The selected seven are the current value/custom/scalar-count/matched-workload controls and three private-profile Windows memo/permission/replacement/ancestor/refusal/bracket controls, listed literally in control-inventory.json. No local proposed() adapter is selected.
2. Install the distinct new test_user_data_directory_posture_adapter.py at its natural Tests/Backup_Recovery path. Its sole case calls the actual config helper on an existing private root/branch/two-leaf tuple with an out-of-order duplicate. It uses the exact unchanged R13 native observer. Equality of original five-field values/order/duplicate, positive caller-owned Native births, same birth objects in close ledger, one successful original close per birth, and security observations precede the property and count assertion. R13 already queries physical invalidity after drain. The new case never calls a supplied batch implementation or patches a product callback.
3. Root executes separate original7 collection/test and causal1 collection/test processes. Baseline requires7 parent passes plus3 genuine child passes, zero failures/errors/skips, and10 clean gates. Only then run the causal test. Its potential optimization RED is precisely the schedule assertion at line63, after shipping_causal_before_schedule_assert and all prior value/security/retirement assertions. Exit1 or an earlier setup/source/observer/value failure is not that RED. Later ancestry/birth-count assertions are unreached if line63 fails and must be reported literally.

The case computes n from its actual unique full ancestor set and D from actual requested depths. Batch requirements are2n fresh opens,3n information reads,2n NTFS calls,n stat/security calls and the original full ancestor component validation sum. Original scalar observations should reflect D opens, D+len(paths) information reads and len(paths) stat/security calls, but no result has been fabricated. Historical126/20 or matched52/24 are not this fixture's constants. No elapsed or whole-Send saving is asserted.

Both TEST paths are absent in selected11c's scoped8479 map. Root must freshly verify actual absence and current composition before staging. With only those two additions and an external reader packet, expected scoped counts are8479→8481→8479. A remote publication that includes further Python files needs its own reviewed map/count reconciliation. The historical c504 original seven-case file5cb27 remains separately preserved and unselected.

## Finite source, runtime and native observer binding

The existing finite Gate is copied byte-exact2e24fa48, with no compiler/framework edits. expected-sources.json declares15 source rows/59 slots; runtime-binding.json enrolls only the three runtime files directly used by this reader: actual Windows contextliba53b, pytest fixtures41df and assertion rewritef231. These come from successful actual run38681628833/job116247255762 and its separately reviewed acquisition, not Darwin library substitutes. The full runtime acquisition was only file/path/spec/hash/version evidence; actual native/callable qualification remains pending this job.

The reader uses natural installed paths, canonical module/spec/loader relations, frozen source bytes, actual pytest assertion compiler/config, function code/default/keyword/default/cell/globals and fixed class/alias relations. It checks current cached Windows facade methods and the two genuine lru wrappers/bodies/capacities without invoking a producer. At the actual unchanged R13 generator yield it independently compiles/pins the seven concrete observer callbacks and compares each closure cell to the generator's own actual lexical locals, original Native/WindowsOS/caller/kernel/nt/API relations, monitor settings and the yielded ledger identities. It checks18 concrete native ABI signatures and five required ctypes layouts. It opens or closes no producer/native owner itself. The original observer owns counter instrumentation and its original native close/invalidity oracle.

After teardown, original source bindings and callback metadata must be restored, every direct observer birth must have one matching close record, no pending birth or observer error may remain, and the original Native API slots/tools must be retired. The serialized native ledger gives birth ordinals and matching close ordinals; numeric HANDLE reuse is not treated as independent ownership. There are three direct observer contexts in original7 and one in causal1. The memo cases do not gain a per-incarnation native ledger by association.

The actual nested Tests/Backup_Recovery/conftest.py78e810 is included and read: its sole helper_resource_root fixture is not autouse and is not requested by these nodes. The root conftest, profile/network/subprocess/consumer-restoration helpers, pyproject and exact actual fixture launcher are included. Full loaded finite sources are bound; absent optional modules are not forcibly imported to make the gate pass. Whole scoped source-map custody remains Root's separate before/staged/post/restored obligation.

## Original memo children and fixture scope

The exact private_profile helper is unchanged. PYTEST_PLUGINS and the two explicit TLDW_OPT36 gate-binding variables are inherited through its original environment copy; command CLI options select the same actual root/archive in the parent. Each parent and child emits a PID-prefixed gate. The passive reader watches only the original selected wrapper's actual yield/return/unwind and the current getter entry. It binds the three actual R13 custom resolver definitions to their frozen code/defaults/globals and current lexical closure cells, preserving direct dispatch. It records the original asyncio Process/pid/returned state, exact original timeout and child report/log/work/profile paths. Root must match each parent PID record to the actual child gate PID/parentPID/node marker and raw one-case XML/log, not merely trust the parent summary. Original child args,180-second bound, kill+await path and all assertions remain unchanged.

Top-level execution remains ordinary python -m Tests.windows_private_fixture_runner. Its natural __main__/spec/path/current main frame and actual contextlib wrapper/body are bound without an alias or rerunning the launcher in children. The original launcher changes/restores only ordinary fixture default owner, verifies both operations and closes its token after pytest returns. The final outer process exit must be archived. There is no captured original owner SID/token-handle receipt, independent inner Process.poll/ECHILD receipt or captured icacls PID; original helper await/subprocess.run ownership is the bounded evidence. These are not TokenOwner-policy/elevation or general child/native lifecycle acceptance claims.

Only one independently owned global PY_UNWIND event is used for the exact private-profile wrapper code; local events remain PY_YIELD/PY_RETURN/PY_START. Cleanup attempts global disable before callback removal/free, independently attempts each owned resource, and preserves observer errors literally. No native worker, fake root/platform/time or test deadline is introduced.

## Review and actual execution handoff

original-command-plan.json contains four structured argv arrays, literal node/XML expectations, environment/plugin propagation, separate archives and guard requirements. Reuse the existing manual Windows2022/setupPython3.12.10/dev+pytest8.4.2+Textual8.2.8 workflow/ordinary fixture mechanism and20-minute job bound. The successful runtime-capture headf6bb is not the selected product snapshot. Root must create/review the exact current selected source snapshot, actual HEAD/parent/changed-path and full scoped maps, preserve byte-exact LF sources (no silent CRLF normalization), bind fresh actual runtime/package metadata and own all staging/native/process/publication/restoration. Keep executable reader assets outside the checkout's Python census or explicitly review their added map roles. Upload the complete declared archive with include-hidden-files:true and preserve raw XML/logs/child work, all11 gate JSON files and actual process/restore receipts even on failure.

All29 Python source/runtime/helper/affected files parse and compile as data with the explicitly required project Python3.12.11. verify_static.py independently rederives every saved file/module/function AST digest and every59 declared-slot AST digest, validates exact source/runtime bytes, and can verify the final manifest. No product/TEST/gate/reader/plugin module was imported or executed; the pure-stdlib AST verifier alone was executed. These checks do not establish native API eligibility or runtime correctness of this unrun observer.

Distinct TEST/reader/command review and Root operational review remain required. All exact frozen bodies required by this initial packet are now present; remaining prerequisites are the real supported Windows snapshot/publication/runtime/fixture/process qualification. Product source authoring waits for the qualified original outcome and Root dispatch. The separate31-case candidate draft (e329d692) and invocation-latch seam are deferred; the initial job will not collect them. dependencies.json preserves the exact12 POSIX memo and11 direct bound affected inventory; their later child/reader/source command bindings remain separate work. No original122 sweep or historical seven-case replay is requested.
