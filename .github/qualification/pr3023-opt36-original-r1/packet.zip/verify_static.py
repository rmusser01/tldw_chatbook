"""Recompute this finite packet's saved AST metadata; never import its sources."""

import ast
import hashlib
import json
import sys
from pathlib import Path


def digest(data):
    return hashlib.sha256(data).hexdigest()


def inspect_source(path):
    data = path.read_bytes()
    tree = ast.parse(data, filename=str(path), feature_version=(3, 12))
    compile(data, str(path), "exec", dont_inherit=True)
    return {
        "sha256": digest(data), "bytes": len(data),
        "module_ast_sha256": digest(ast.dump(tree, include_attributes=False).encode()),
        "assert_count": sum(isinstance(node, ast.Assert) for node in ast.walk(tree)),
        "function_nodes": sorted([
            {"name": node.name, "line": node.lineno, "end_line": node.end_lineno,
             "ast_sha256": digest(ast.dump(node, include_attributes=False).encode())}
            for node in ast.walk(tree) if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef))
        ], key=lambda row: (row["line"], row["name"])),
    }


def main():
    root = Path(sys.argv[1]).resolve()
    if sys.version_info[:2] != (3, 12) or sys.flags.optimize:
        raise RuntimeError("Use unoptimized Python3.12 for exact saved AST metadata")
    expected = json.loads((root / "static-analysis.json").read_text())
    for row in expected["python_files"]:
        actual = inspect_source(root / row["path"])
        assert actual == {key: value for key, value in row.items() if key != "path"}, row["path"]
    rows = json.loads((root / "expected-sources.json").read_text())["sources"]
    by_module = {row["module"]: row for row in rows}
    for row in rows:
        assert digest((root / row["snapshot_path"]).read_bytes()) == row["sha256"]
    for row in expected["declared_slots"]:
        source = by_module[row["module"]]
        body = ast.parse((root / source["snapshot_path"]).read_bytes(), feature_version=(3, 12)).body
        target = None
        for name in row["slot"].removesuffix(".__wrapped__").split("."):
            matches = [node for node in body if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef, ast.ClassDef)) and node.name == name]
            assert len(matches) == 1, row
            target = matches[0]
            body = target.body
        assert digest(ast.dump(target, include_attributes=False).encode()) == row["function_ast_sha256"], row
    for row in json.loads((root / "runtime-binding.json").read_text())["sources"]:
        data = (root / row["snapshot_path"]).read_bytes()
        assert digest(data) == row["sha256"] and len(data) == row["bytes"]
    manifest = root / "manifest.json"
    if manifest.is_file():
        for row in json.loads(manifest.read_text())["assets"]:
            data = (root / row["path"]).read_bytes()
            assert digest(data) == row["sha256"] and len(data) == row["bytes"], row["path"]
    print(json.dumps({"status": "PASS static metadata/bytes only", "python": sys.version,
                      "executable": sys.executable, "python_files": len(expected["python_files"]),
                      "source_rows": len(rows), "runtime_rows": 3}))


if __name__ == "__main__":
    main()
