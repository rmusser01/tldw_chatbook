"""One original shipping-helper count control; no adapter implementation."""

from __future__ import annotations

import json
import os
import threading
from collections import Counter

import pytest

from Tests.Backup_Recovery.test_windows_metadata_baseline_opt36_opt74 import _native_returns

pytestmark = pytest.mark.skipif(os.name != "nt", reason="actual Windows shipping helper")


def _fixture_paths(tmp_path):
    from tldw_chatbook.Backup_Recovery import storage_admission as storage

    win = storage.os
    root, branch = tmp_path / "shipping-root", tmp_path / "shipping-root" / "branch"
    win.mkdir(root, 0o700)
    win.mkdir(branch, 0o700)
    first, second = branch / "first.bin", branch / "second.bin"
    for path in (first, second):
        fd = win.open(path, win.O_CREAT | win.O_EXCL | win.O_RDWR, 0o600)
        win.close(fd)
    return win, (second, branch, first, root, first)

def _retired(ledger):
    counts, ancestry, births, closes, errors, excluded, security = ledger
    assert not errors and not excluded and births
    assert len(births) == len(closes)
    assert Counter(map(id, births)) == Counter(map(id, closes))
    assert all(row["status"] >= 0 and row["thread"] == threading.get_ident() for row in births)
    assert all(row["closes"] == [(True, 0)] for row in births)
    assert security and all(owner and user for owner, user, _uid, _mode in security)
    return counts, ancestry, births

def test_shipping_helper_uses_one_fresh_batch_after_equal_values_and_retirement(tmp_path, record_property):
    """Original-source RED must be the final schedule assertion, after custody."""
    from tldw_chatbook import config
    from tldw_chatbook.Backup_Recovery import storage_admission as storage

    win, paths = _fixture_paths(tmp_path)
    expected = tuple(storage._posture(path) for path in paths)
    with _native_returns(win) as ledger:
        actual = config._user_data_dir_stamps(paths)
    counts, ancestry, births = _retired(ledger)
    assert actual == expected and all(len(value) == 5 for value in actual)
    assert actual[2] == actual[4]
    nodes = {node for path in paths for node in (*path.parents, path)}
    n, depth = len(nodes), sum(len(path.parts) for path in paths)
    batch = {"batch": 1, "component": sum(len(node.parts) - 1 for node in nodes),
             "open": 2 * n, "info": 3 * n, "ntfs": 2 * n, "stat": n, "security": n}
    record_property("shipping_causal_before_schedule_assert", json.dumps({
        "paths": [str(path) for path in paths], "nodes": n, "scalar_depth": depth,
        "five_field_values_equal": True, "same_order_duplicate": True,
        "counts": dict(counts), "ancestry": dict(ancestry), "births_retired_once": len(births),
        "observer_errors": ledger[4], "caller": threading.get_ident(),
        "expected_batch_counts": batch, "scope": "helper counts only; no elapsed acceptance",
    }, sort_keys=True))
    assert dict(counts) == batch
    assert dict(ancestry) == {"open": 2 * n, "stat": n}
    assert len(births) == 2 * n
