"""Finite Windows7 source/fixture/ABI reader; never invokes a producer."""

import ctypes as C
import functools
import gc
import hashlib
import importlib.machinery
import json
import os
import stat
import sys
import threading
from importlib.metadata import version
from pathlib import Path
from types import CodeType, FunctionType, MappingProxyType

from ac77_source_gate import HERE, Gate, nested, shape

ACL = "Tests.Backup_Recovery.test_windows_acl_fixture"
POSTURE = "Tests.Backup_Recovery.test_raw_lock_stream_parent_posture"
CONFIG_TEST = "Tests.Backup_Recovery.test_raw_pin_evidence_eligibility"
HOOK_TEST = "Tests.Backup_Recovery.test_task37_original_hook_pin"
PARTICIPANT = "Tests.Backup_Recovery.test_participant_lifetimes"
RETIREMENT = "Tests.Backup_Recovery.test_raw_native_retirement"
SUPPORT = "Tests.Backup_Recovery.config_test_support"
WINDOWS = "tldw_chatbook.Utils.windows_files"
CONFIG = "tldw_chatbook.config"

_PRIVATE = "tldw_chatbook.Utils.private_paths"
_CONFIG = "tldw_chatbook.config"
_HOOK = "tldw_chatbook.Agents.hook_permissions"
_FACTORY = "_make_lock_stream_selector.<locals>."
_SPECIAL = {
    (_CONFIG, "_bind_config_interprocess_lock.<locals>._config_interprocess_lock"),
    (_HOOK, "HookPermissions._bind_store_lock.<locals>._store_lock"),
    (_PRIVATE, _FACTORY + "current"),
    (_PRIVATE, _FACTORY + "_lock_stream_for_callbacks"),
    (_PRIVATE, _FACTORY + "_lock_stream_for_callbacks.<locals>.finish"),
}


def cells(function):
    return dict(
        zip(
            function.__code__.co_freevars,
            (cell.cell_contents for cell in function.__closure__ or ()),
            strict=True,
        )
    )


class LockReader(Gate):
    def pin(self, function):
        assert type(function) is FunctionType
        module_name = function.__globals__["__name__"]
        if (module_name, function.__code__.co_qualname) not in _SPECIAL:
            return super().pin(function)
        if id(function) in self.functions:
            return
        module = sys.modules[module_name]
        assert function.__globals__ is vars(module)
        _, path, _, _, _, compiled, _, _ = self.source(module)
        code = function.__code__
        assert Path(code.co_filename).resolve() == path
        expected = nested(compiled, code)
        assert expected is not None and shape(expected) == shape(code)
        assert function.__defaults__ is None and function.__kwdefaults__ is None
        assert not getattr(function, "__type_params__", ())
        values = tuple(
            (cell, cell.cell_contents) for cell in function.__closure__ or ()
        )
        self.functions[id(function)] = (
            function,
            code,
            function.__globals__,
            None,
            None,
            (),
            function.__closure__,
            values,
            vars(function).get("__wrapped__"),
        )
        closure = cells(function)
        private = sys.modules[_PRIVATE]
        selector = vars(private)["_lock_stream_for_callbacks"]
        if module_name in {_CONFIG, _HOOK}:
            assert set(closure) == {"definition"}
            definition = closure["definition"]
            assert definition is vars(module)["_LOCK_STREAM_SELECTOR_BINDING"]
            self.check_selector_record(definition, selector)
            assert vars(module)["_lock_stream_for_callbacks"] is selector
            self.pin(selector)
        elif code.co_qualname.endswith(".current"):
            assert set(closure) == {
                "_lock_stream_for_callbacks",
                "admitted",
                "admitted_code",
                "namespace",
                "original",
                "select_code",
            }
            assert closure["_lock_stream_for_callbacks"] is selector
            assert closure["select_code"] is selector.__code__
            assert closure["namespace"] is vars(private)
            assert closure["original"] is vars(private)["_LOCK_STREAM_BINDING"]
            assert closure["admitted"] is vars(private)["_admitted_stream"]
            assert closure["admitted_code"] is closure["admitted"].__code__
            self.pin(closure["admitted"])
        elif code.co_qualname.endswith("._lock_stream_for_callbacks"):
            assert function is selector
            assert set(closure) == {
                "admitted",
                "current",
                "current_cells",
                "current_code",
                "current_defaults",
                "current_keywords",
                "current_values",
                "namespace",
                "original",
            }
            assert closure["namespace"] is vars(private)
            assert closure["original"] is vars(private)["_LOCK_STREAM_BINDING"]
            assert closure["admitted"] is vars(private)["_admitted_stream"]
            self.pin(closure["admitted"])
            current = closure["current"]
            self.pin(current)
            assert closure["current_code"] is current.__code__
            assert closure["current_defaults"] is current.__defaults__ is None
            assert closure["current_keywords"] is current.__kwdefaults__ is None
            assert closure["current_cells"] is current.__closure__
            recorded = closure["current_values"]
            assert type(recorded) is tuple and len(recorded) == len(current.__closure__)
            assert all(
                pair[0] is cell and pair[1] is cell.cell_contents
                for pair, cell in zip(recorded, current.__closure__, strict=True)
            )
            original = closure["original"]
            assert type(original) is tuple and len(original) == 6
            for row in original:
                (
                    name,
                    callback,
                    callback_code,
                    defaults,
                    keywords,
                    captured,
                    namespace,
                ) = row
                public = vars(private)[name.split(".")[0]]
                actual = vars(public)["__wrapped__"] if "." in name else public
                assert callback is actual and callback.__code__ is callback_code
                assert callback.__globals__ is namespace is vars(private)
                assert callback.__defaults__ is defaults
                assert (
                    None
                    if callback.__kwdefaults__ is None
                    else tuple(callback.__kwdefaults__.items())
                ) == keywords
                now = (
                    None
                    if callback.__closure__ is None
                    else tuple(c.cell_contents for c in callback.__closure__)
                )
                assert (now is None and captured is None) or (
                    type(captured) is tuple
                    and len(now) == len(captured)
                    and all(a is b for a, b in zip(now, captured, strict=True))
                )
                self.pin(callback)
        else:
            assert code.co_qualname.endswith(".finish")
            expected_names = {
                "body",
                "caller",
                "caller_binding",
                "current",
                "current_cells",
                "current_code",
                "current_defaults",
                "current_keywords",
                "current_values",
                "namespace",
            }
            assert set(closure) == expected_names
            selected = cells(selector)
            for name in expected_names - {"body", "caller", "caller_binding"}:
                assert closure[name] is selected[name]
            assert closure["body"] is selected["original"][5][1]
            caller = next(
                candidate
                for name in (_CONFIG, _HOOK)
                if (candidate := sys.modules.get(name)) is not None
                and vars(candidate) is closure["caller"]
            )
            assert (
                closure["caller_binding"]
                is vars(caller)["_LOCK_STREAM_SELECTOR_BINDING"]
            )
            public = (
                vars(caller)["_config_interprocess_lock"]
                if caller.__name__ == _CONFIG
                else vars(vars(caller)["HookPermissions"])["_store_lock"]
            )
            body = vars(public)["__wrapped__"]
            self.pin(public)
            assert cells(body)["definition"] is closure["caller_binding"]
            self.check_selector_record(closure["caller_binding"], selector)

    def check_selector_record(self, record, selector):
        assert type(record) is tuple and len(record) == 4
        assert record[0] is selector and record[1] is selector.__code__
        assert record[2] is selector.__globals__ is vars(sys.modules[_PRIVATE])
        closure = selector.__closure__
        assert type(record[3]) is tuple and closure is not None
        assert len(record[3]) == len(closure)
        assert all(
            cell.cell_contents is value
            for cell, value in zip(closure, record[3], strict=True)
        )


RAW = "tldw_chatbook.Backup_Recovery.raw_participants"
PRIVATE = "tldw_chatbook.Utils.private_paths"
R = "_bind_parent_walk_source.<locals>."
P = "_bind_parent_walk.<locals>."
RAW_ROWS = (
    "_runtime_operation",
    "_check",
    "_check_parent_pins",
    "_source_custody_check",
    "_source_custody_check.__wrapped__",
    "_live_state",
    "_participant_identity",
    "_participant_state",
    "_owned_descriptor_retirement_state",
    "_close_descriptor",
)
PRIVATE_ROWS = (
    "_walk_verified_parent",
    "_open_directory_component",
    "_follow_trusted_symlink",
    "_native_open",
    "_native_close",
    "_allocate_native_descriptor",
    "_runtime_operation",
    "_visual_native_scope",
    "_voice_operation",
    "_posix_guards_available",
    "os.open",
)
STATIC = {
    (RAW, R + name)
    for name in (
        "source_current",
        "_parent_walk_operation",
        "_check_directory_allocation",
    )
} | {
    (PRIVATE, P + name)
    for name in ("source_current", "_prepared_parent_walk", "_open_verified_parent")
}
FINITE = {
    P + "_prepared_parent_walk.<locals>." + name
    for name in ("current", "directory_open", "owned_close", "finish")
}


def pairs_match(record, actual):
    assert type(record) is tuple and len(record) == len(actual or ())
    assert all(
        type(pair) is tuple
        and len(pair) == 2
        and pair[0] is cell
        and pair[1] is cell.cell_contents
        for pair, cell in zip(record, actual or (), strict=True)
    )


class FiniteGate(LockReader):
    def exact_function(self, function):
        assert type(function) is FunctionType
        module = sys.modules[function.__globals__["__name__"]]
        assert function.__globals__ is vars(module)
        _, path, _, _, _, compiled, tree, nodes = self.source(module)
        code = function.__code__
        assert Path(code.co_filename).resolve() == path
        expected = nested(compiled, code)
        assert expected is not None and shape(expected) == shape(code)
        node = nodes[code.co_qualname]
        expected_defaults = tuple(
            self.default(n, module, tree) for n in node.args.defaults
        )
        actual_defaults = function.__defaults__ or ()
        assert len(actual_defaults) == len(expected_defaults)
        assert all(
            type(a) is type(b) and a == b
            for a, b in zip(actual_defaults, expected_defaults, strict=True)
        )
        expected_kw = {
            arg.arg: self.default(value, module, tree)
            for arg, value in zip(
                node.args.kwonlyargs, node.args.kw_defaults, strict=True
            )
            if value is not None
        }
        actual_kw = function.__kwdefaults__ or {}
        assert actual_kw.keys() == expected_kw.keys()
        assert all(
            type(v) is type(expected_kw[k]) and v == expected_kw[k]
            for k, v in actual_kw.items()
        )
        assert not getattr(function, "__type_params__", ())
        return (
            function,
            code,
            function.__globals__,
            function.__defaults__,
            function.__kwdefaults__,
            tuple(actual_kw.items()),
            function.__closure__,
            tuple((cell, cell.cell_contents) for cell in function.__closure__ or ()),
            vars(function).get("__wrapped__"),
        )

    def keyword_record(self, recorded, function):
        actual = getattr(function, "__kwdefaults__", None)
        if recorded is None:
            assert actual is None
        else:
            assert (
                type(recorded) is tuple
                and type(actual) is dict
                and len(recorded) == len(actual)
            )
            assert all(k in actual and actual[k] is v for k, v in recorded)

    def definition_rows(self, record, module, names):
        assert record is vars(module)["_PARENT_WALK_SOURCE"]
        assert type(record) is tuple and tuple(row[0] for row in record) == names
        for row in record:
            assert type(row) is tuple and len(row) == 7
            name, callback, code, defaults, keywords, namespace, captured = row
            if name == "os.open":
                assert callback is module.os.open is module._ORIGINAL_NATIVE_OPEN
            else:
                public = vars(module)[name.split(".")[0]]
                actual = vars(public)["__wrapped__"] if "." in name else public
                assert callback is actual
            assert getattr(callback, "__code__", None) is code
            assert getattr(callback, "__defaults__", None) is defaults
            assert getattr(callback, "__globals__", None) is namespace
            self.keyword_record(keywords, callback)
            actual_cells = getattr(callback, "__closure__", None)
            if captured is None:
                assert actual_cells is None
            else:
                assert (
                    type(captured) is tuple
                    and actual_cells is not None
                    and len(actual_cells) == len(captured)
                )
                assert all(
                    c.cell_contents is v
                    for c, v in zip(actual_cells, captured, strict=True)
                )
            if type(callback) is FunctionType:
                self.pin(callback)

    def discovery_rows(self, record, raw):
        expected = (
            (
                "mcp_sources",
                "tldw_chatbook.Backup_Recovery.mcp_source_participants",
                "history_operation",
            ),
            (
                "config_files",
                "tldw_chatbook.Backup_Recovery.config_participants",
                "binding",
            ),
        )
        assert type(record) is tuple and len(record) == len(expected)
        for row, (alias, module_name, slot) in zip(record, expected, strict=True):
            assert type(row) is tuple and len(row) == 12
            (
                captured_alias,
                captured_name,
                owner,
                name,
                callback,
                code,
                defaults,
                keywords,
                items,
                namespace,
                captured_cells,
                values,
            ) = row
            assert type(captured_alias) is type(captured_name) is type(name) is str
            assert (
                captured_alias == alias
                and captured_name == module_name
                and name == slot
            )
            assert owner is sys.modules[module_name] and vars(raw)[alias] is owner
            assert vars(owner)["__name__"] == module_name
            assert callback is vars(owner)[slot] and type(callback) is FunctionType
            assert callback.__globals__ is namespace is vars(owner)
            assert callback.__code__ is code and callback.__defaults__ is defaults
            assert callback.__kwdefaults__ is keywords
            assert type(items) is tuple
            if keywords is None:
                assert items == ()
            else:
                assert all(
                    type(pair) is tuple and len(pair) == 2 and type(pair[0]) is str
                    for pair in items
                )
            self.keyword_record(None if keywords is None else items, callback)
            assert callback.__closure__ is captured_cells
            pairs_match(values, captured_cells)
            # Independent frozen definer/compiled shape, not callback self-consistency.
            self.pin(callback)

    def checker_capture(self, closure, module):
        checker = closure["source_current"]
        self.pin(checker)
        assert closure["namespace"] is vars(module)
        assert closure["current_code"] is checker.__code__
        assert closure["current_cells"] is checker.__closure__
        pairs_match(closure["current_values"], checker.__closure__)

    def pin(self, function):
        key = (function.__globals__["__name__"], function.__code__.co_qualname)
        if key not in STATIC:
            return super().pin(function)
        if id(function) in self.functions:
            return
        record = self.exact_function(function)
        self.functions[id(function)] = record
        closure = cells(function)
        module = sys.modules[key[0]]
        if key == (RAW, R + "source_current"):
            assert set(closure) == {"definition", "discovery", "namespace"}
            assert closure["namespace"] is vars(module)
            self.definition_rows(closure["definition"], module, RAW_ROWS)
            self.discovery_rows(closure["discovery"], module)
        elif key[0] == RAW:
            assert set(closure) == {
                "current_cells",
                "current_code",
                "current_values",
                "namespace",
                "source_current",
            }
            assert function is vars(module)[function.__code__.co_name]
            self.checker_capture(closure, module)
        elif key == (PRIVATE, P + "source_current"):
            assert set(closure) == {
                "definition",
                "directory_flags",
                "namespace",
                "native_os",
            }
            assert (
                closure["namespace"] is vars(module)
                and closure["native_os"] is module.os
            )
            assert type(closure["directory_flags"]) is int
            assert (
                closure["directory_flags"]
                == module._DIRECTORY_OPEN_FLAGS | module._NOFOLLOW
            )
            self.definition_rows(closure["definition"], module, PRIVATE_ROWS)
        elif key == (PRIVATE, P + "_prepared_parent_walk"):
            assert (
                function is vars(vars(module)["_prepared_parent_walk"])["__wrapped__"]
            )
            assert set(closure) == {
                "current_cells",
                "current_code",
                "current_values",
                "directory_flags",
                "namespace",
                "source_current",
            }
            self.checker_capture(closure, module)
            assert (
                closure["directory_flags"]
                is cells(closure["source_current"])["directory_flags"]
            )
        else:
            assert function is vars(module)["_open_verified_parent"]
            assert set(closure) == {"_prepared_parent_walk", "namespace", "preparation"}
            assert closure["namespace"] is vars(module)
            prepared = closure["_prepared_parent_walk"]
            assert prepared is vars(module)["_prepared_parent_walk"]
            self.pin(prepared)
            definition = closure["preparation"]
            assert type(definition) is tuple and len(definition) == 2
            for row, actual in zip(
                definition, (prepared, vars(prepared)["__wrapped__"]), strict=True
            ):
                assert type(row) is tuple and len(row) == 7
                (
                    callback,
                    code,
                    defaults,
                    keywords,
                    namespace,
                    captured_cells,
                    values,
                ) = row
                assert (
                    callback is actual
                    and code is actual.__code__
                    and defaults is actual.__defaults__
                )
                assert (
                    keywords is actual.__kwdefaults__
                    and namespace is actual.__globals__
                )
                assert captured_cells is actual.__closure__
                pairs_match(values, actual.__closure__)
                self.pin(actual)


class NativeSevenReader:
    def _captured_function(self, function, values):
        """Pin one of these fixed lexical functions against its actual capture."""
        assert type(function) is FunctionType
        module = sys.modules[function.__globals__["__name__"]]
        assert function.__globals__ is vars(module)
        record = self.gate.source(module)
        code = function.__code__
        assert Path(code.co_filename).resolve() == record[1]
        expected = nested(record[5], code)
        assert expected is not None and shape(expected) == shape(code)
        node = record[7][code.co_qualname]
        expected_defaults = tuple(
            self.gate.default(value, module, record[6]) for value in node.args.defaults
        )
        assert len(function.__defaults__ or ()) == len(expected_defaults)
        assert all(
            type(actual) is type(wanted) and actual == wanted
            for actual, wanted in zip(function.__defaults__ or (), expected_defaults)
        )
        expected_kw = {
            arg.arg: self.gate.default(value, module, record[6])
            for arg, value in zip(node.args.kwonlyargs, node.args.kw_defaults)
            if value is not None
        }
        assert (function.__kwdefaults__ or {}).keys() == expected_kw.keys()
        assert all(
            type(value) is type(expected_kw[name]) and value == expected_kw[name]
            for name, value in (function.__kwdefaults__ or {}).items()
        )
        assert not getattr(function, "__type_params__", ())
        cells = tuple(zip(code.co_freevars, function.__closure__ or ()))
        assert len(cells) == len(code.co_freevars)
        assert all(cell.cell_contents is values[name] for name, cell in cells)
        self.gate.functions[id(function)] = (
            function,
            code,
            function.__globals__,
            function.__defaults__,
            function.__kwdefaults__,
            tuple((function.__kwdefaults__ or {}).items()),
            function.__closure__,
            tuple((cell, cell.cell_contents) for _name, cell in cells),
            vars(function).get("__wrapped__"),
        )

    def _adapter_capture(self):
        # Read the installed helper; never invoke the deleted factory or checker.
        import inspect
        import pathlib
        from types import MethodType, ModuleType

        config = sys.modules["tldw_chatbook.config"]
        assert config.os is os and config.sys is sys and config.Path is pathlib.Path
        storage = sys.modules["tldw_chatbook.Backup_Recovery.storage_admission"]
        platform = sys.modules["tldw_chatbook.Utils.platform_files"]
        files = sys.modules["tldw_chatbook.Utils.windows_files"]
        helper = vars(config)["_user_data_dir_stamps"]
        assert "_bind_user_data_dir_stamps" not in vars(config)
        assert (
            helper.__code__.co_qualname
            == "_bind_user_data_dir_stamps.<locals>._user_data_dir_stamps"
        )
        cells = dict(zip(helper.__code__.co_freevars, helper.__closure__ or ()))
        assert set(cells) == {
            "WindowsPath",
            "batch",
            "close_errors",
            "projection",
            "source_current",
        }
        checker = cells["source_current"].cell_contents
        assert (
            checker.__code__.co_qualname
            == "_bind_user_data_dir_stamps.<locals>.source_current"
        )
        closed = {
            name: cell.cell_contents
            for name, cell in zip(
                checker.__code__.co_freevars, checker.__closure__ or ()
            )
        }
        facade, owner, native = platform.os, files.WindowsOS, files._Native
        close_error, posture = files._AdmissionMetadataCloseError, storage._posture
        projection = cells["projection"].cell_contents
        assert type(projection) is tuple and len(projection) == 2
        assert projection[0] is stat.S_IFMT and projection[1] is stat.S_IMODE
        close_errors = cells["close_errors"].cell_contents
        assert (
            type(close_errors) is tuple
            and len(close_errors) == 1
            and close_errors[0] is close_error
        )
        assert files.Path is pathlib.Path and files.ntpath is sys.modules["ntpath"]
        modules = closed["modules"]
        assert type(modules) is tuple and len(modules) == 3
        for row, module in zip(modules, (storage, platform, files)):
            assert type(row) is tuple and len(row) == 5
            assert row[0] is module and row[1] is vars(module)
            assert (
                row[2] == module.__file__
                and row[3] is module.__spec__
                and row[4] == module.__spec__.origin
            )
            self.gate.source(module)
        bindings = (
            (vars(storage), "_posture", posture),
            (vars(storage), "os", facade),
            (vars(storage), "stat", stat),
            (vars(platform), "os", facade),
            (vars(platform), "WindowsOS", owner),
            (vars(files), "WindowsOS", owner),
            (vars(files), "_Native", native),
            (vars(files), "_AdmissionMetadataCloseError", close_error),
            *(
                (vars(stat), name, value)
                for name, value in zip(("S_IFMT", "S_IMODE"), projection)
            ),
            *(
                (vars(files), name, vars(files)[name])
                for name in (
                    "_os",
                    "_stat",
                    "Path",
                    "ntpath",
                    "contextlib",
                    "functools",
                    "_parent",
                    "_component",
                    "_native",
                    "_acl_mode",
                    "_AdmissionMetadataHandle",
                )
            ),
            *(
                (vars(owner), name, vars(owner)[name])
                for name in (
                    "__getattr__",
                    "stat",
                    "_stat_handle",
                    "stat_many_for_admission",
                )
            ),
            *(
                (vars(native), name, vars(native)[name])
                for name in (
                    "__init__",
                    "_user_sid",
                    "reopen",
                    "open_handle",
                    "info",
                    "ntfs",
                    "security",
                    "_decoded_security",
                    "_decode_security",
                    "sid_string",
                    "check",
                    "ntcheck",
                )
            ),
            (vars(close_error), "__init__", close_error.__init__),
            (
                vars(files._AdmissionMetadataHandle),
                "__init__",
                files._AdmissionMetadataHandle.__init__,
            ),
        )
        actual_bindings = closed["bindings"]
        assert type(actual_bindings) is tuple and len(actual_bindings) == len(bindings)
        for actual, wanted in zip(actual_bindings, bindings):
            assert type(actual) is tuple and len(actual) == 3
            if type(wanted[0]) is MappingProxyType:
                # Class vars() returns fresh proxies; retain the exact live backing dict.
                assert type(actual[0]) is MappingProxyType
                actual_backing, wanted_backing = (
                    gc.get_referents(actual[0]),
                    gc.get_referents(wanted[0]),
                )
                assert len(actual_backing) == len(wanted_backing) == 1
                assert (
                    type(actual_backing[0]) is dict
                    and actual_backing[0] is wanted_backing[0]
                )
            else:
                assert actual[0] is wanted[0]
            assert actual[1] == wanted[1] and actual[2] is wanted[2]
        functions = (
            posture,
            owner.__getattr__,
            owner.stat,
            owner._stat_handle,
            owner.stat_many_for_admission,
            files._component,
            files._acl_mode,
            native.__init__,
            native._user_sid,
            native.open_handle,
            native.info,
            native.ntfs,
            native.security,
            native._decode_security,
            native.sid_string,
            native.check,
            native.ntcheck,
            close_error.__init__,
            files._AdmissionMetadataHandle.__init__,
            files._parent,
            files._parent.__wrapped__,
            files._native.__wrapped__,
            native.reopen,
            native.reopen.__wrapped__,
            native._decoded_security.__wrapped__,
        )
        records = closed["records"]
        assert type(records) is tuple and len(records) == len(functions) == 25
        for record, function in zip(records, functions):
            self.gate.pin(function)
            assert type(record) is tuple and len(record) == 9
            fn, code, namespace, defaults, kw, items, closure, saved_cells, body = (
                record
            )
            assert (
                fn is function
                and code is function.__code__
                and namespace is function.__globals__
            )
            assert defaults is function.__defaults__ and kw is function.__kwdefaults__
            assert type(items) is tuple and len(items) == len(kw or {})
            assert all(
                name == actual_name and value is actual_value
                for (name, value), (actual_name, actual_value) in zip(
                    items, (kw or {}).items()
                )
            )
            assert closure is function.__closure__ and type(saved_cells) is tuple
            assert len(saved_cells) == len(closure or ())
            assert all(
                saved is actual and value is actual.cell_contents
                for (saved, value), actual in zip(saved_cells, closure or ())
            )
            assert body is vars(function).get("__wrapped__")
        wrapped = closed["wrapped"]
        wrappers = (
            files._parent,
            files._native,
            native.reopen,
            native._decoded_security,
        )
        assert type(wrapped) is tuple and len(wrapped) == 4
        assert all(
            type(row) is tuple
            and len(row) == 2
            and row[0] is wrapper
            and row[1] is vars(wrapper)["__wrapped__"]
            for row, wrapper in zip(wrapped, wrappers)
        )
        lookup = closed["lookup"]
        expected_lookup = tuple(
            (cls, name, inspect.getattr_static(cls, name, None))
            for cls in (owner, native)
            for name in ("__getattribute__", "__getattr__", "__dict__")
        )
        assert type(lookup) is tuple and len(lookup) == len(expected_lookup)
        assert all(
            type(row) is tuple
            and len(row) == 3
            and row[0] is cls
            and row[1] == name
            and row[2] is value
            for row, (cls, name, value) in zip(lookup, expected_lookup)
        )
        cached = closed["cached"]
        assert type(cached) is tuple and len(cached) == 3
        for row, name in zip(
            cached, ("stat", "_stat_handle", "stat_many_for_admission")
        ):
            assert type(row) is tuple and len(row) == 3 and row[0] == name
            bound, function = row[1:]
            assert type(bound) is MethodType and vars(facade)[name] is bound
            assert (
                bound.__self__ is facade
                and bound.__func__ is function is vars(owner)[name]
            )
        assert cells["batch"].cell_contents is cached[-1][1]
        expected_closed = dict(
            FunctionType=FunctionType,
            MethodType=MethodType,
            ModuleType=ModuleType,
            bindings=actual_bindings,
            cached=cached,
            facade=facade,
            inspect=inspect,
            lookup=lookup,
            modules=modules,
            native=native,
            original_posture=posture,
            owner=owner,
            records=records,
            stat=stat,
            storage=storage,
            wrapped=wrapped,
        )
        assert set(closed) == set(expected_closed)
        assert all(closed[name] is value for name, value in expected_closed.items())
        self._captured_function(checker, expected_closed)
        self._captured_function(
            helper,
            dict(
                WindowsPath=pathlib.WindowsPath,
                batch=cached[-1][1],
                close_errors=close_errors,
                projection=projection,
                source_current=checker,
            ),
        )
        self.gate.slots.append((config, "_user_data_dir_stamps", helper))
        self.adapter = (helper, checker, records, actual_bindings, cached, modules)

    def _launcher(self):
        # python -m naturally executes this actual installed module as __main__.
        # Keep that truthful relation; do not add an import alias or rerun it.
        main = sys.modules["__main__"]
        row = self.gate.rows["Tests.windows_private_fixture_runner"]
        path = self.gate.root / row["logical_path"]
        data = (HERE / row["snapshot_path"]).read_bytes()
        assert Path(main.__file__).resolve() == path and path.read_bytes() == data
        assert hashlib.sha256(data).hexdigest() == row["sha256"]
        assert main.__spec__.name == "Tests.windows_private_fixture_runner"
        assert Path(main.__spec__.origin).resolve() == path
        assert type(main.__loader__) is importlib.machinery.SourceFileLoader
        compiled = compile(data, str(path), "exec", dont_inherit=True)
        wrapper, entry = vars(main)["user_fixture_default_owner"], vars(main)["main"]
        body = vars(wrapper)["__wrapped__"]
        for function in (entry, body):
            assert type(function) is FunctionType and function.__globals__ is vars(main)
            expected = nested(compiled, function.__code__)
            assert expected is not None and shape(expected) == shape(function.__code__)
            assert (
                function.__defaults__ is None
                and function.__kwdefaults__ is None
                and function.__closure__ is None
            )
        contextlib = sys.modules["contextlib"]
        expected_wrapper = nested(self.gate.source(contextlib)[5], wrapper.__code__)
        assert expected_wrapper is not None and shape(expected_wrapper) == shape(
            wrapper.__code__
        )
        assert wrapper.__globals__ is vars(
            contextlib
        ) and wrapper.__code__.co_freevars == ("func",)
        assert wrapper.__defaults__ is None and wrapper.__kwdefaults__ is None
        assert len(wrapper.__closure__) == 1
        assert (
            wrapper.__closure__[0].cell_contents is body
            and vars(wrapper)["__wrapped__"] is body
        )
        frame = sys._getframe()
        while frame is not None and frame.f_code is not entry.__code__:
            frame = frame.f_back
        assert frame is not None and frame.f_globals is vars(main)
        self.launcher = (
            main,
            path,
            data,
            wrapper,
            body,
            entry,
            wrapper.__code__,
            body.__code__,
            entry.__code__,
        )

    def _native_abi(self, files, native, real_open, real_close):
        assert (
            native.kernel._name == "kernel32"
            and native.nt._name == "ntdll"
            and native.advapi._name == "advapi32"
        )
        assert all(
            type(dll) is C.WinDLL for dll in (native.kernel, native.nt, native.advapi)
        )
        assert (files._U32, files._I32, files._U16, files._P, files._HANDLE) == (
            C.c_uint32,
            C.c_int32,
            C.c_uint16,
            C.c_void_p,
            C.c_void_p,
        )
        U, I, P, H = files._U32, files._I32, files._P, files._HANDLE
        fields = (
            (
                files._UnicodeString,
                [("Length", files._U16), ("MaximumLength", files._U16), ("Buffer", P)],
                16,
            ),
            (
                files._ObjectAttributes,
                [
                    ("Length", U),
                    ("RootDirectory", H),
                    ("ObjectName", C.POINTER(files._UnicodeString)),
                    ("Attributes", U),
                    ("SecurityDescriptor", P),
                    ("SecurityQualityOfService", P),
                ],
                48,
            ),
            (files._IOStatus, [("Status", P), ("Information", C.c_size_t)], 16),
            (
                files._FileInfo,
                [
                    ("attributes", U),
                    ("created", U * 2),
                    ("accessed", U * 2),
                    ("written", U * 2),
                    ("volume", U),
                    ("size_high", U),
                    ("size_low", U),
                    ("links", U),
                    ("index_high", U),
                    ("index_low", U),
                ],
                52,
            ),
            (
                files._FileIdDescriptor,
                [("size", U), ("kind", U), ("identifier", C.c_uint64 * 2)],
                24,
            ),
            (
                files._Overlapped,
                [
                    ("Internal", C.c_size_t),
                    ("InternalHigh", C.c_size_t),
                    ("Offset", U),
                    ("OffsetHigh", U),
                    ("hEvent", H),
                ],
                32,
            ),
            (
                files._BasicInfo,
                [
                    ("created", C.c_int64),
                    ("accessed", C.c_int64),
                    ("written", C.c_int64),
                    ("changed", C.c_int64),
                    ("attributes", U),
                ],
                40,
            ),
        )
        for cls, expected, size in fields:
            assert cls.__bases__ == (C.Structure,) and cls.__module__ == files.__name__
            assert (
                cls._fields_ == expected
                and C.sizeof(cls) == size
                and not vars(cls).get("_pack_")
            )
        signatures = (
            (
                native.kernel,
                "OpenFileById",
                None,
                [H, C.POINTER(files._FileIdDescriptor), U, U, P, U],
                H,
            ),
            (
                native.kernel,
                "LockFileEx",
                None,
                [H, U, U, U, U, C.POINTER(files._Overlapped)],
                I,
            ),
            (
                native.kernel,
                "UnlockFileEx",
                None,
                [H, U, U, U, C.POINTER(files._Overlapped)],
                I,
            ),
            (native.kernel, "FlushFileBuffers", None, [H], I),
            (
                native.nt,
                "NtFlushBuffersFileEx",
                None,
                [H, U, P, U, C.POINTER(files._IOStatus)],
                I,
            ),
            (
                native.nt,
                "NtCreateFile",
                real_open,
                [
                    C.POINTER(H),
                    U,
                    C.POINTER(files._ObjectAttributes),
                    C.POINTER(files._IOStatus),
                    P,
                    U,
                    U,
                    U,
                    U,
                    P,
                    U,
                ],
                I,
            ),
            (native.kernel, "CloseHandle", real_close, [H], I),
            (
                native.kernel,
                "GetFileInformationByHandle",
                None,
                [H, C.POINTER(files._FileInfo)],
                I,
            ),
            (native.kernel, "GetFileType", None, [H], U),
            (
                native.kernel,
                "GetVolumeInformationByHandleW",
                None,
                [H, P, U, P, P, P, P, U],
                I,
            ),
            (
                native.nt,
                "NtQueryVolumeInformationFile",
                None,
                [H, C.POINTER(files._IOStatus), P, U, U],
                I,
            ),
            (native.kernel, "GetFileInformationByHandleEx", None, [H, I, P, U], I),
            (native.kernel, "LocalFree", None, [P], P),
            (
                native.advapi,
                "GetSecurityInfo",
                None,
                [H, I, U, C.POINTER(P), P, C.POINTER(P), P, C.POINTER(P)],
                U,
            ),
            (native.advapi, "GetSecurityDescriptorLength", None, [P], U),
            (
                native.advapi,
                "GetSecurityDescriptorOwner",
                None,
                [P, C.POINTER(P), C.POINTER(I)],
                I,
            ),
            (
                native.advapi,
                "GetSecurityDescriptorDacl",
                None,
                [P, C.POINTER(I), C.POINTER(P), C.POINTER(I)],
                I,
            ),
            (native.advapi, "GetAce", None, [P, U, C.POINTER(P)], I),
            (native.advapi, "ConvertSidToStringSidW", None, [P, C.POINTER(P)], I),
            (native.nt, "RtlNtStatusToDosError", None, [I], U),
            (native.kernel, "GetCurrentProcess", None, [], H),
            (native.advapi, "OpenProcessToken", None, [H, U, C.POINTER(H)], I),
            (native.advapi, "GetTokenInformation", None, [H, I, P, U, C.POINTER(U)], I),
            (
                native.advapi,
                "ConvertStringSecurityDescriptorToSecurityDescriptorW",
                None,
                [C.c_wchar_p, U, C.POINTER(P), P],
                I,
            ),
            (native.advapi, "SetSecurityInfo", None, [H, I, U, P, P, P, P], U),
        )
        for dll, name, captured, arguments, result in signatures:
            function = captured if captured is not None else vars(dll)[name]
            assert type(function) is vars(dll)["_FuncPtr"] and function.__name__ == name
            assert function.argtypes == arguments and function.restype is result
            assert function._flags_ & C._FUNCFLAG_USE_LASTERROR

    def __init__(self, root, item):
        self.item = item
        runtime = json.loads((HERE / "runtime-binding.json").read_text())
        assert os.name == "nt" and sys.platform == "win32" and C.sizeof(C.c_void_p) == 8
        assert sys.version_info[:3] == (3, 12, 10)
        assert sys.modules["pytest"].__version__ == runtime["pytest"]
        assert version("textual") == runtime["textual"]
        self.gate = FiniteGate(root, runtime["sources"], pytest_config=item.config)
        self.allowed = json.loads((HERE / "nodeids.json").read_text())["native_seven"]
        assert item.nodeid in self.allowed
        self.native_case = item.module.__name__ == ACL
        self.caller = threading.get_ident()
        self.launcher = None
        self.adapters, self.caches, self.natives = [], [], []
        self.fixture_defs, self.codes = {}, {}
        self.local_root_yields = self.local_root_returns = 0
        self.native_acl_yields = self.native_acl_returns = 0
        self.configured_source_returns = self.fresh_config_returns = 0
        self.helper_yields = self.profile_yields = self.hook_yields = 0
        self.native_receipts = []
        self.native_fixture = None
        self.fixture_value = None
        self.native_pre_post_abi = []

    def prepare(self):
        assert self.item.module.__name__ in {ACL, POSTURE, CONFIG_TEST, HOOK_TEST}
        assert self.item.function is vars(self.item.module)[self.item.originalname]
        assert not vars(self.item.function).get("_private_profile_test", False)
        assert "__wrapped__" not in vars(self.item.function)
        assert "TLDW_TEST_PRIVATE_PROFILE_NODE" not in os.environ
        parameter = self.item.callspec.params if hasattr(self.item, "callspec") else {}
        if self.native_case:
            assert parameter == {} and not hasattr(self.item, "callspec")
        elif self.item.module.__name__ == POSTURE:
            assert parameter == {"race": self.item.nodeid.rsplit("[", 1)[1][:-1]}
            assert parameter["race"] in {"warm-parent", "cold-ancestor"}
        else:
            assert (
                parameter.keys() == {"reuse_enabled"}
                and parameter["reuse_enabled"] is True
            )
        self.gate.loaded()
        self.gate.pin(self.item.function)
        self._launcher()
        from _pytest import fixtures

        self.gate.module(fixtures)
        contextlib = sys.modules["contextlib"]
        for module, name in (
            (fixtures, "FixtureDef"),
            (contextlib, "_GeneratorContextManager"),
        ):
            cls = vars(module)[name]
            self.gate.classes.append((module, name, cls, cls.__bases__))
        for owner, name in (
            (fixtures, "call_fixture_func"),
            (fixtures, "_teardown_yield_fixture"),
            (fixtures, "pytest_fixture_setup"),
            (fixtures.FixtureDef, "execute"),
            (fixtures.FixtureDef, "finish"),
            (contextlib, "contextmanager"),
            (contextlib._GeneratorContextManager, "__enter__"),
            (contextlib._GeneratorContextManager, "__exit__"),
        ):
            function = vars(owner)[name]
            self.gate.slots.append((owner, name, function))
            self.gate.pin(function)
        from _pytest.assertion import rewrite

        for module, *_ in self.gate.sources.values():
            assert type(module.__loader__) in (
                importlib.machinery.SourceFileLoader,
                rewrite.AssertionRewritingHook,
            )
            if not module.__name__.startswith("Tests."):
                assert type(module.__loader__) is importlib.machinery.SourceFileLoader
        fixtures_by_case = (
            {"_native_acl_directory": (ACL, "_native_acl_directory")}
            if self.native_case
            else {"local_root": (PARTICIPANT, "local_root")}
        )
        if self.item.module.__name__ == POSTURE:
            fixtures_by_case["lock_case"] = (POSTURE, "lock_case")
        if self.item.module.__name__ == HOOK_TEST:
            fixtures_by_case["configured_source"] = (RETIREMENT, "configured_source")
        for name, (module_name, public_name) in fixtures_by_case.items():
            module = sys.modules[module_name]
            self.gate.module(module)
            public = vars(module)[public_name]
            assert type(public) is fixtures.FixtureFunctionDefinition
            body = vars(public)["__wrapped__"]
            assert vars(public)["_fixture_function"] is body
            definitions = self.item._fixtureinfo.name2fixturedefs[name]
            definition = definitions[-1]
            assert type(definition) is fixtures.FixtureDef
            assert definition.func is body and definition.argname == name
            assert definition.scope == "function"
            assert (
                tuple(definition.argnames)
                == body.__code__.co_varnames[: body.__code__.co_argcount]
            )
            self.fixture_defs[name] = (definition, body)
            self.codes[body.__code__] = name
        if not self.native_case:
            assert "_native_acl_directory" not in self.item.fixturenames
            assert ("configured_source" in self.item.fixturenames) is (
                self.item.module.__name__ == HOOK_TEST
            )
            support = sys.modules[SUPPORT]
            self.gate.module(support)
            self.codes[support.install_config_source.__code__] = "config_install"
            win = sys.modules[WINDOWS]
            self.codes[win._Native.info.__code__] = "native_info"
        else:
            assert not {"local_root", "configured_source"}.intersection(
                self.item.fixturenames
            )
            body = vars(vars(sys.modules[ACL])["_observe_native_acl_call"])[
                "__wrapped__"
            ]
            self.codes[body.__code__] = "acl_observer"
        if self.item.module.__name__ == POSTURE:
            body = vars(sys.modules[RETIREMENT]._original_tracked_closes)["__wrapped__"]
            self.codes[body.__code__] = "tracked_closes"
        if self.item.module.__name__ == HOOK_TEST:
            body = vars(sys.modules[HOOK_TEST]._original_hook_pin_work)["__wrapped__"]
            self.codes[body.__code__] = "hook_observer"
        self.codes[self.item.function.__code__] = "test_body"

    def fixture_frame(self, frame, name):
        definition, body = self.fixture_defs[name]
        assert frame.f_code is body.__code__ and frame.f_globals is body.__globals__
        from _pytest import fixtures

        caller = frame.f_back
        assert (
            caller is not None and caller.f_code is fixtures.call_fixture_func.__code__
        )
        assert caller.f_locals["fixturefunc"] is body
        request = caller.f_locals["request"]
        assert request._fixturedef is definition and request.node is self.item
        assert request.fixturename == name

    def capture(self, function, values, module_name, qualname):
        assert function.__globals__ is vars(sys.modules[module_name])
        assert function.__code__.co_qualname == qualname
        self._captured_function(function, values)

    def stock_native(self, native, phase, *, control=False):
        files = sys.modules[WINDOWS]
        platform = sys.modules["tldw_chatbook.Utils.platform_files"]
        facade = platform.os
        assert type(native) is files._Native and type(facade) is files.WindowsOS
        assert files.C is C and files._os is os and files._stat is stat
        assert (
            files.functools is functools
            and files.contextlib is sys.modules["contextlib"]
        )
        assert native.crt is sys.modules["msvcrt"]
        assert type(native.user_sid) is str and native.user_sid.startswith("S-1-")
        assert files._SYSTEM_SIDS == frozenset(
            {
                "S-1-5-18",
                "S-1-5-32-544",
                "S-1-5-80-956008885-3418522649-1831038044-1853292631-2271478464",
            }
        )
        assert files._OWNER_RIGHTS_SID == "S-1-3-4"
        assert (
            files._READ_CONTROL,
            files._WRITE_DAC,
            files._WRITE_THROUGH,
            files._SHARE_ALL,
            files._SYNCHRONIZE,
        ) == (0x20000, 0x40000, 2, 7, 0x100000)
        self._native_abi(
            files, native, native.nt.NtCreateFile, native.kernel.CloseHandle
        )
        if control or "GetSecurityDescriptorControl" in vars(native.advapi):
            function = vars(native.advapi)["GetSecurityDescriptorControl"]
            assert type(function) is vars(native.advapi)["_FuncPtr"]
            assert function.__name__ == "GetSecurityDescriptorControl"
            assert function.argtypes == [
                files._P,
                C.POINTER(files._U16),
                C.POINTER(files._U32),
            ]
            assert (
                function.restype is files._I32
                and function._flags_ & C._FUNCFLAG_USE_LASTERROR
            )
        for name in ("open", "fstat", "stat", "chmod", "fchmod", "fsync", "geteuid"):
            bound = vars(facade)[name]
            assert (
                bound.__self__ is facade
                and bound.__func__ is vars(files.WindowsOS)[name]
            )
        assert facade.close is os.close and "close" not in vars(facade)
        api = tuple(
            (
                dll,
                name,
                function,
                tuple(function.argtypes or ()),
                function.restype,
                function._flags_,
            )
            for dll in (native.kernel, native.advapi, native.nt)
            for name, function in vars(dll).items()
            if type(function) is vars(dll)["_FuncPtr"]
        )
        record = next((row for row in self.natives if row[0] is native), None)
        if record is None:
            self.natives.append(
                (
                    native,
                    native.kernel,
                    native.advapi,
                    native.nt,
                    facade,
                    tuple(
                        (name, vars(facade)[name])
                        for name in (
                            "open",
                            "fstat",
                            "stat",
                            "chmod",
                            "fchmod",
                            "fsync",
                            "geteuid",
                        )
                    ),
                    api,
                )
            )
        else:
            assert (
                native.kernel is record[1]
                and native.advapi is record[2]
                and native.nt is record[3]
            )
            assert facade is record[4]
            assert all(vars(facade)[name] is value for name, value in record[5])
            for dll, name, function, arguments, result, flags in record[6]:
                assert (
                    vars(dll)[name] is function
                    and tuple(function.argtypes or ()) == arguments
                )
                assert function.restype is result and function._flags_ == flags
        for owner, name, capacity in (
            (files, "_native", 1),
            (files._Native, "_decoded_security", 128),
        ):
            cache = vars(owner)[name]
            assert type(cache) is functools._lru_cache_wrapper
            body = vars(cache)["__wrapped__"]
            self.gate.pin(body)
            info = cache.cache_info
            assert (
                info.__self__ is cache
                and info.__name__ == "cache_info"
                and info().maxsize == capacity
            )
            if not any(row[0] is owner and row[1] == name for row in self.caches):
                self.caches.append((owner, name, cache, body))
        self.native_pre_post_abi.append(
            {
                "phase": phase,
                "original_WinDLL_and_facade": True,
                "native_control_signature": control
                or "GetSecurityDescriptorControl" in vars(native.advapi),
            }
        )

    def yielded(self, frame, value, label):
        local = frame.f_locals
        assert threading.get_ident() == self.caller
        if label == "local_root":
            self.fixture_frame(frame, label)
            assert self.local_root_yields == 0 and local["root"] is value
            bootstrap = sys.modules["tldw_chatbook.Backup_Recovery.bootstrap"]
            assert local["bootstrap"] is bootstrap
            callback = vars(bootstrap)["default_bootstrap_root"]
            self.gate.fixture_binding = (bootstrap, callback, value)
            self.gate.pin(callback)
            self.fixture_value = value
            self.local_root_yields += 1
        elif label == "_native_acl_directory":
            self.fixture_frame(frame, label)
            assert self.native_acl_yields == 0 and value.path is local["path"]
            assert value.native is local["native"] and value.facade is local["facade"]
            assert (
                value.helper
                is local["helper"]
                is sys.modules["Tests.Backup_Recovery.windows_acl_fixture"]
            )
            assert local["windows_files"] is sys.modules[WINDOWS]
            assert (
                local["platform_files"]
                is sys.modules["tldw_chatbook.Utils.platform_files"]
            )
            assert (
                local["pinned_directory"]
                is sys.modules[
                    "tldw_chatbook.Backup_Recovery.native_files"
                ].pinned_directory
            )
            self.native_fixture = value
            for name in ("handle_closed", "fd_closed", "identity", "security"):
                self.capture(
                    local[name], local, ACL, "_native_acl_directory.<locals>." + name
                )
            probe = local["probe"]
            files = sys.modules[WINDOWS]
            assert type(probe) is vars(local["native"].kernel)["_FuncPtr"]
            assert probe.__name__ == "GetHandleInformation"
            assert probe.argtypes == [files._HANDLE, C.POINTER(C.c_uint32)]
            assert (
                probe.restype is C.c_int32 and probe._flags_ & C._FUNCFLAG_USE_LASTERROR
            )
            self.gate.loaded()
            self.stock_native(value.native, "native-fixture-pre-helper", control=True)
            self.native_acl_yields += 1
        elif label == "acl_observer":
            assert (
                frame.f_globals is vars(sys.modules[ACL]) and value is local["receipt"]
            )
            assert self.helper_yields == 0 and local["case"] is self.native_fixture
            for name in (
                "address",
                "observe",
                "converting",
                "freeing",
                "opening",
                "closing",
                "reopening",
                "closing_handle",
                "setting",
            ):
                self.capture(
                    local[name], local, ACL, "_observe_native_acl_call.<locals>." + name
                )
            for cls in (local["Advapi"], local["Kernel"]):
                self.capture(
                    vars(cls)["__getattr__"],
                    local,
                    ACL,
                    "_observe_native_acl_call.<locals>."
                    + cls.__name__
                    + ".__getattr__",
                )
            assert type(local["native"].advapi) is local["Advapi"]
            assert type(local["native"].kernel) is local["Kernel"]
            assert (
                local["facade"].open is local["opening"]
                and local["facade"].close is local["closing"]
            )
            assert any(
                row[0] is local["native"]
                and row[1] is local["kernel"]
                and row[2] is local["advapi"]
                for row in self.natives
            )
            self.native_receipts.append(value)
            self.helper_yields += 1
        elif label == "tracked_closes":
            assert frame.f_globals is vars(sys.modules[RETIREMENT])
            assert self.profile_yields == 0 and sys.getprofile() is local["observe"]
            self.capture(
                local["observe"],
                local,
                RETIREMENT,
                "_original_tracked_closes.<locals>.observe",
            )
            assert type(value) is tuple and len(value) == 5
            assert all(
                a is local[name]
                for a, name in zip(
                    value,
                    ("counts", "closed", "removed", "active", "operations"),
                    strict=True,
                )
            )
            self.profile_yields += 1
        elif label == "hook_observer":
            assert frame.f_globals is vars(sys.modules[HOOK_TEST])
            assert self.hook_yields == 0 and value is local["observed"]
            for name in ("ancestry", "started", "returned"):
                self.capture(
                    local[name],
                    local,
                    HOOK_TEST,
                    "_original_hook_pin_work.<locals>." + name,
                )
            monitor, tool, witness = sys.monitoring, local["tool"], local["witness"]
            for function, argument_count in ((witness.counting, 0), (witness.bump, 1)):
                assert type(function) is FunctionType and function.__globals__ is vars(
                    sys.modules[HOOK_TEST]
                )
                assert (
                    function.__code__.co_qualname
                    == "_original_hook_pin_work.<locals>.<lambda>"
                )
                assert function.__code__.co_argcount == argument_count
                assert (
                    function.__defaults__ is None
                    and function.__kwdefaults__ is None
                    and function.__closure__ is None
                )
                compiled = self.gate.source(sys.modules[HOOK_TEST])[5]
                owners = [
                    code
                    for code in compiled.co_consts
                    if type(code) is CodeType
                    and code.co_qualname == "_original_hook_pin_work"
                ]
                assert len(owners) == 1
                candidates = [
                    code
                    for code in owners[0].co_consts
                    if type(code) is CodeType
                    and code.co_qualname == function.__code__.co_qualname
                    and code.co_firstlineno == function.__code__.co_firstlineno
                    and code.co_argcount == argument_count
                ]
                assert len(candidates) == 1
                assert shape(candidates[0]) == shape(function.__code__)
                self.gate.functions[id(function)] = (
                    function,
                    function.__code__,
                    function.__globals__,
                    None,
                    None,
                    (),
                    None,
                    (),
                    None,
                )
            assert monitor.get_tool(tool) == "original-hook-pin-evidence"
            assert monitor.get_events(tool) == 0 and witness.tool == tool
            for code in witness.codes:
                expected = monitor.events.PY_START | (
                    0 if code is local["native_code"] else monitor.events.PY_RETURN
                )
                assert monitor.get_local_events(tool, code) == expected
            self.hook_yields += 1
        elif label == "lock_case":
            self.fixture_frame(frame, label)
            assert value.source is local["source"] and value.config is local["config"]
        else:
            raise AssertionError("unexpected selected yield")

    def returned(self, frame, value, label):
        assert threading.get_ident() == self.caller
        if label == "config_install":
            assert frame.f_globals is vars(sys.modules[SUPPORT])
            assert (
                value
                is sys.modules[CONFIG]
                is vars(sys.modules["tldw_chatbook"])["config"]
            )
            assert value is frame.f_locals["module"]
            assert self.local_root_yields == 1
            self.gate.loaded()
            self._adapter_capture()
            self.adapters.append(self.adapter)
            self.fresh_config_returns += 1
        elif label == "configured_source":
            self.fixture_frame(frame, label)
            assert value is frame.f_locals["source"] is sys.modules[CONFIG]
            self.configured_source_returns += 1
        elif label == "local_root":
            assert value is None and self.local_root_yields == 1
            self.local_root_returns += 1
        elif label == "_native_acl_directory":
            assert value is None and self.native_acl_yields == 1
            self.stock_native(
                frame.f_locals["native"], "native-fixture-post-cleanup", control=True
            )
            self.native_acl_returns += 1
        elif label == "test_body":
            module_name = self.item.module.__name__
            local = frame.f_locals
            names = {
                POSTURE: ("mutate", "observe", "sync_then_mutate"),
                CONFIG_TEST: ("observe",),
            }.get(module_name, ())
            for name in names:
                self.capture(
                    local[name],
                    local,
                    module_name,
                    self.item.originalname + ".<locals>." + name,
                )
        elif label in {"acl_observer", "tracked_closes", "hook_observer", "lock_case"}:
            return
        else:
            raise AssertionError("unexpected selected return")

    def started(self, frame, label):
        if threading.get_ident() != self.caller:
            return
        assert label == "native_info" and not self.native_case
        assert frame.f_globals is vars(sys.modules[WINDOWS])
        native = frame.f_locals["self"]
        if not any(row[0] is native for row in self.natives):
            self.stock_native(native, "first-original-info-entry")

    def finish(self, call_passed):
        # Original pytest fixtures/monkeypatches/native owners have finished first.
        for definition, body in self.fixture_defs.values():
            assert definition.func is body and definition.scope == "function"
        self.gate.fixture_binding = None
        self.gate.loaded()
        self.gate.unchanged()
        raw, private = sys.modules.get(RAW), sys.modules.get(PRIVATE)
        if raw is not None:
            checker = cells(raw._parent_walk_operation)["source_current"]
            self.gate.definition_rows(cells(checker)["definition"], raw, RAW_ROWS)
            self.gate.discovery_rows(cells(checker)["discovery"], raw)
        if private is not None:
            checker = cells(vars(private._prepared_parent_walk)["__wrapped__"])[
                "source_current"
            ]
            self.gate.definition_rows(
                cells(checker)["definition"], private, PRIVATE_ROWS
            )
        for owner, name, cache, body in self.caches:
            assert vars(owner)[name] is cache and vars(cache)["__wrapped__"] is body
        for native, *_ in self.natives:
            self.stock_native(
                native, "final-after-original-fixtures", control=self.native_case
            )
        main, path, data, wrapper, body, entry, wrapper_code, body_code, entry_code = (
            self.launcher
        )
        assert path.read_bytes() == data and vars(main)["main"] is entry
        assert vars(main)["user_fixture_default_owner"] is wrapper
        assert (
            wrapper.__code__ is wrapper_code
            and body.__code__ is body_code
            and entry.__code__ is entry_code
        )
        assert (
            wrapper.__closure__[0].cell_contents is body
            and vars(wrapper)["__wrapped__"] is body
        )
        assert wrapper.__defaults__ is None and wrapper.__kwdefaults__ is None
        assert body.__globals__ is vars(main) and entry.__globals__ is vars(main)
        assert body.__defaults__ is None and entry.__defaults__ is None
        assert body.__kwdefaults__ is None and entry.__kwdefaults__ is None
        if call_passed:
            assert self.natives
            if self.native_case:
                assert (
                    self.native_acl_yields
                    == self.native_acl_returns
                    == self.helper_yields
                    == 1
                )
                assert self.local_root_yields == self.local_root_returns == 0
                assert self.fresh_config_returns == self.configured_source_returns == 0
                assert self.profile_yields == self.hook_yields == 0
                for receipt in self.native_receipts:
                    assert (
                        receipt["restored"]
                        and not receipt["errors"]
                        and not receipt["overflow"]
                    )
                    assert not receipt["live_fds"] and not receipt["live_handles"]
            else:
                assert (
                    self.local_root_yields
                    == self.local_root_returns
                    == self.fresh_config_returns
                    == 1
                )
                assert (
                    self.native_acl_yields
                    == self.native_acl_returns
                    == self.helper_yields
                    == 0
                )
                assert self.configured_source_returns == int(
                    self.item.module.__name__ == HOOK_TEST
                )
                assert self.profile_yields == int(self.item.module.__name__ == POSTURE)
                assert self.hook_yields == int(self.item.module.__name__ == HOOK_TEST)

    def receipt(self):
        return {
            "gate": self.gate.receipt(),
            "fresh_config_returns": self.fresh_config_returns,
            "configured_source_returns": self.configured_source_returns,
            "local_root_yields": self.local_root_yields,
            "local_root_returns": self.local_root_returns,
            "native_acl_yields": self.native_acl_yields,
            "native_acl_returns": self.native_acl_returns,
            "native_pre_post_abi": self.native_pre_post_abi,
            "helper_observer_yields": self.helper_yields,
            "posture_profile_yields": self.profile_yields,
            "hook_observer_yields": self.hook_yields,
            "launcher": {
                "natural_module_name": "__main__",
                "spec_name": "Tests.windows_private_fixture_runner",
                "sha256": hashlib.sha256(self.launcher[2]).hexdigest(),
                "actual_main_stack_observed": True,
                "limit": "Original launcher restores TokenOwner/closes token after pytest returns; process exit archived separately. No independent token-retirement receipt.",
            },
            "scope": "Four remaining ordinary Windows controls; no private-profile child or source staging, no whole-platform/general-native/performance qualification",
        }
