from __future__ import annotations

# ADR-126: fence recovery and enroll before any runtime/config imports.
from tldw_chatbook.Backup_Recovery.storage_admission import admit_startup

admit_startup()

# tldw_cli/config.py
# Description: Configuration management for the tldw_cli application.
#

# Imports
import copy
import difflib
import hashlib
import importlib.util
import json
import re
import shutil
import sys
from contextlib import ExitStack, closing, contextmanager
from dataclasses import dataclass, field
from datetime import datetime, timezone
from functools import lru_cache

if sys.version_info < (3, 11):
    import tomli as tomllib
else:
    import tomllib
import os
import time
from pathlib import Path
import toml
import portalocker
from typing import (
    Any,
    Collection,
    Callable,
    Dict,
    List,
    Literal,
    Mapping,
    NamedTuple,
    Optional,
    Sequence,
    TYPE_CHECKING,
    Iterator,
)

#
# Third-Party Imports
from loguru import logger
from pydantic import (
    BaseModel,
    ConfigDict,
    TypeAdapter,
    ValidationError,
    ValidationInfo,
    field_validator,
)


#
# Local Imports
from tldw_chatbook.Backup_Recovery import profile_paths
from tldw_chatbook.Backup_Recovery import config_participants as _config_participants
from tldw_chatbook.Backup_Recovery.bootstrap import RecoveryRequired
from tldw_chatbook.Constants import DEFAULT_SPLASH_DURATION_SECONDS
from tldw_chatbook.Canvas.limits import CanvasLimits
from tldw_chatbook.DB.ChaChaNotes_DB import CharactersRAGDB
from tldw_chatbook.DB.Client_Media_DB_v2 import MediaDatabase
from tldw_chatbook.DB.Prompts_DB import PromptsDatabase

if TYPE_CHECKING:
    from tldw_chatbook.Canvas.web_auth import WebAuthPolicy
    from tldw_chatbook.Chat.console_exchange_capture import CaptureDetail
    from tldw_chatbook.Chat.console_trace_maintenance import TraceCompactionPolicy
    from tldw_chatbook.Chat.console_trace_custom_pii import CustomPIIRuleset
from tldw_chatbook.provider_registry import ALL_RECORDS, CLOUD_PROVIDER_CONFIG_KEYS
from tldw_chatbook.Utils.adaptive_reader_state import (
    ITEMS_MAX_WIDTH,
    ITEMS_MIN_WIDTH,
    ITEMS_TARGET_WIDTH,
    normalize_adaptive_reader_preferences,
)
from tldw_chatbook.Utils.console_background_effects import (
    normalize_console_background_effects,
)
from tldw_chatbook.Utils.log_sanitizer import redact_user_paths
from tldw_chatbook.Utils.path_validation import validate_path_simple
from tldw_chatbook.Utils.startup_errors import private_path_repair_hint
from tldw_chatbook.Utils.private_paths import (
    PrivatePathError,
    PrivatePathResult,
    PrivatePathStatus,
    atomic_private_write_text,
    create_private_text,
    lexical_path,
    open_private_binary,
    open_private_text_append_stream,
    secure_private_directory,
    verify_trusted_directory,
)
from tldw_chatbook.Utils.sensitive_config_keys import (
    is_sensitive_config_key,
    validate_trace_privacy_config,
)

if TYPE_CHECKING:
    from tldw_chatbook.Chat.console_library_policy import ConsoleLibraryMigrationSeed
#
#######################################################################################################################
#
# Functions:

def _contains_literal_backslash_x(value: Any) -> bool:
    pending = [value]
    seen: set[int] = set()
    while pending:
        current = pending.pop()
        if type(current) is str:  # Inspect builtin values without custom coercion.
            if "\\x" in current:
                return True
        elif type(current) in (dict, list, tuple):
            identity = id(current)
            if identity in seen:
                continue
            seen.add(identity)
            # Only builtin containers enter this branch; custom mappings keep the legacy route.
            pending.extend(current.values() if type(current) is dict else current)
    return False


def dumps_cli_config(config_data: Mapping[str, Any]) -> str:
    """Retain the original codec and defer the exceptional literal encoder.

    Args:
        config_data: Original configuration mapping passed to the writer.

    Returns:
        TOML text using the existing ordinary or literal-backslash-x codec.
    """
    if not _contains_literal_backslash_x(config_data):
        return toml.dumps(config_data)
    from tldw_chatbook.Utils.toml_serialization import dumps_cli_config as special

    return special(config_data)


logger.debug("CRITICAL DEBUG: config.py module is being imported/executed NOW.")
# --- Constants ---
# Client ID used by the Server API itself when writing to sync logs


CanvasRemoteAccessStatus = Literal[
    "loopback",
    "authenticated_tls",
    "refused",
    "misconfigured",
    "insecure_development",
]


@dataclass(frozen=True, slots=True)
class CanvasConfigPolicy:
    """Effective Canvas execution and delivery policy without credentials."""

    enabled: bool
    auto_open_on_create: bool
    limits: CanvasLimits
    remote_access_status: CanvasRemoteAccessStatus
    remote_access_summary: str
    diagnostics: tuple[str, ...] = ()


_CANVAS_CONFIG_KEYS = frozenset({"enabled", "auto_open_on_create"})
_CANVAS_ENABLED_ENV = "TLDW_CANVAS_ENABLED"
_CANVAS_AUTO_OPEN_ENV = "TLDW_CANVAS_AUTO_OPEN_ON_CREATE"


def _strict_canvas_bool(
    section: Mapping[str, Any],
    key: str,
    *,
    default: bool,
    invalid_diagnostic: str,
    diagnostics: list[str],
) -> bool:
    """Read one exact Canvas boolean, failing closed on malformed values."""

    if key not in section:
        return default
    value = section.get(key)
    if type(value) is bool:
        return value
    diagnostics.append(invalid_diagnostic)
    return False


def _resolve_canvas_bool(
    section: Mapping[str, Any],
    key: str,
    *,
    environment_name: str,
    environ: Mapping[str, str],
    default: bool,
    invalid_config_diagnostic: str,
    invalid_environment_diagnostic: str,
    diagnostics: list[str],
) -> bool:
    """Resolve one strict environment-over-config Canvas preference."""

    raw_environment = environ.get(environment_name)
    if raw_environment is not None:
        if type(raw_environment) is not str:
            diagnostics.append(invalid_environment_diagnostic)
            return False
        normalized = raw_environment.strip().lower()
        if normalized:
            if normalized == "true":
                return True
            if normalized == "false":
                return False
            diagnostics.append(invalid_environment_diagnostic)
            return False
    return _strict_canvas_bool(
        section,
        key,
        default=default,
        invalid_diagnostic=invalid_config_diagnostic,
        diagnostics=diagnostics,
    )


def _normalize_canvas_execution(
    config: Mapping[str, Any] | None,
    *,
    environ: Mapping[str, str],
    diagnostics: list[str],
) -> tuple[Mapping[str, Any], bool, bool]:
    """Return the Canvas section, strict execution gate, and table validity."""

    values = config if isinstance(config, Mapping) else {}
    raw_canvas = values.get("canvas")
    if raw_canvas is None:
        canvas: Mapping[str, Any] = {}
        valid_table = True
    elif isinstance(raw_canvas, Mapping):
        canvas = raw_canvas
        valid_table = True
    else:
        canvas = {}
        valid_table = False
        diagnostics.append("canvas must be a table; Canvas is disabled")

    if not valid_table:
        return canvas, False, False
    enabled = _resolve_canvas_bool(
        canvas,
        "enabled",
        environment_name=_CANVAS_ENABLED_ENV,
        environ=environ,
        default=True,
        invalid_config_diagnostic=(
            "canvas.enabled must be a boolean; Canvas is disabled"
        ),
        invalid_environment_diagnostic=(
            "TLDW_CANVAS_ENABLED must be true or false; Canvas is disabled"
        ),
        diagnostics=diagnostics,
    )
    return canvas, enabled, True


def _summarize_canvas_web_auth_policy(
    policy: "WebAuthPolicy",
) -> tuple[CanvasRemoteAccessStatus, str]:
    """Return credential-free copy for one already-validated web policy."""

    if policy.automatic_local_login:
        return (
            "loopback",
            "Loopback only — browsers on this Chatbook host enter locally.",
        )
    if policy.insecure_remote_http:
        return (
            "insecure_development",
            "Insecure development mode — authenticated remote HTTP can be observed on the network.",
        )
    return (
        "authenticated_tls",
        "Authenticated TLS/proxy — dedicated browser admission is configured.",
    )


def _canvas_remote_access_status(
    web: Mapping[str, Any],
    *,
    environ: Mapping[str, str],
    keyring_get: Callable[[str, str], str | None] | None,
    web_auth_policy: "WebAuthPolicy | None",
) -> tuple[CanvasRemoteAccessStatus, str]:
    """Validate configured or effective served auth and return redacted copy."""

    from tldw_chatbook.Canvas.web_auth import (
        BindPolicyError,
        ResolvedCredential,
        build_web_auth_policy,
        is_loopback_host,
        resolve_web_access_token,
    )

    if web_auth_policy is not None:
        return _summarize_canvas_web_auth_policy(web_auth_policy)

    host = str(web.get("host") or "localhost").strip()
    public_url = str(web.get("public_url") or "").strip() or None
    port = web.get("port", 8000)
    if type(port) is not int or not 0 <= port <= 65535:
        return (
            "misconfigured",
            "Remote access misconfigured — review the configured served bind, origin, TLS, and proxy settings.",
        )
    certificate = web.get("tls_certificate")
    private_key = web.get("tls_private_key")
    if bool(certificate) != bool(private_key):
        return (
            "misconfigured",
            "Remote access misconfigured — review the configured served bind, origin, TLS, and proxy settings.",
        )

    remote_candidate = not is_loopback_host(host) or public_url is not None
    credential = (
        resolve_web_access_token(
            web.get("access_token"),
            environ=environ,
            keyring_get=keyring_get,
        )
        if remote_candidate
        else ResolvedCredential(None, "not_required")
    )
    proxies = web.get("trusted_proxy_addresses", ())
    if not isinstance(proxies, (list, tuple)):
        proxies = ("invalid-proxy-configuration",)
    try:
        policy = build_web_auth_policy(
            host=host,
            port=port,
            access_token=credential,
            public_url=public_url,
            allow_insecure_remote_http=(web.get("allow_insecure_remote_http") is True),
            trusted_proxy_addresses=tuple(str(value) for value in proxies),
            direct_tls=bool(certificate and private_key),
        )
    except BindPolicyError as exc:
        if credential.reveal() is None and "token" in str(exc).lower():
            return (
                "refused",
                "Remote access refused — configure the dedicated Chatbook web access token.",
            )
        return (
            "misconfigured",
            "Remote access misconfigured — review the configured served bind, origin, TLS, and proxy settings.",
        )
    return _summarize_canvas_web_auth_policy(policy)


def build_canvas_config_policy(
    config: Mapping[str, Any] | None,
    *,
    environ: Mapping[str, str] | None = None,
    keyring_get: Callable[[str, str], str | None] | None = None,
    web_auth_policy: "WebAuthPolicy | None" = None,
) -> CanvasConfigPolicy:
    """Build the sole normalized Canvas policy from untrusted configuration."""

    values = config if isinstance(config, Mapping) else {}
    diagnostics: list[str] = []
    effective_environment = os.environ if environ is None else environ
    canvas, enabled, valid_canvas_table = _normalize_canvas_execution(
        values,
        environ=effective_environment,
        diagnostics=diagnostics,
    )
    auto_open = (
        _resolve_canvas_bool(
            canvas,
            "auto_open_on_create",
            environment_name=_CANVAS_AUTO_OPEN_ENV,
            environ=effective_environment,
            default=True,
            invalid_config_diagnostic=(
                "canvas.auto_open_on_create must be a boolean; auto-open is disabled"
            ),
            invalid_environment_diagnostic=(
                "TLDW_CANVAS_AUTO_OPEN_ON_CREATE must be true or false; auto-open is disabled"
            ),
            diagnostics=diagnostics,
        )
        if valid_canvas_table
        else False
    )
    if any(key not in _CANVAS_CONFIG_KEYS for key in canvas):
        diagnostics.append(
            "Canvas quota overrides are unsupported; hard limits remain fixed"
        )

    raw_web = values.get("web_server")
    web = raw_web if isinstance(raw_web, Mapping) else {}
    remote_status, remote_summary = _canvas_remote_access_status(
        web,
        environ=effective_environment,
        keyring_get=keyring_get,
        web_auth_policy=web_auth_policy,
    )
    return CanvasConfigPolicy(
        enabled=enabled,
        auto_open_on_create=auto_open,
        limits=CanvasLimits(),
        remote_access_status=remote_status,
        remote_access_summary=remote_summary,
        diagnostics=tuple(diagnostics),
    )


def get_canvas_config_policy(
    *, web_auth_policy: "WebAuthPolicy | None" = None
) -> CanvasConfigPolicy:
    """Return the current effective Canvas policy from the shared config cache."""

    return build_canvas_config_policy(
        load_cli_config_and_ensure_existence(),
        web_auth_policy=web_auth_policy,
    )


def get_canvas_execution_enabled() -> bool:
    """Read only the global execution gate without resolving web credentials."""

    config = load_cli_config_and_ensure_existence()
    _canvas, enabled, _valid_table = _normalize_canvas_execution(
        config,
        environ=os.environ,
        diagnostics=[],
    )
    return enabled


# --- [console_ssh]: SSH ControlMaster lifecycle for remote bindings -------
# (spec 2026-09-24-ssh-remote-workspace-bindings, "ControlMaster lifecycle —
# explicit, and the executor owns its health"). `Tools/remote_workspace_transport.py`
# consumes `control_persist`, `enable_multiplexing` and `connect_timeout_s`;
# the executor's call cap consumes `max_concurrent_calls`; the per-run
# session worker (spec 2026-09-27-ssh-session-worker-and-bundle-cache)
# consumes `session_worker`, `session_idle_s` and `bundle_cache`.

DEFAULT_CONSOLE_SSH_CONTROL_PERSIST = "10m"
DEFAULT_CONSOLE_SSH_CONNECT_TIMEOUT_S = 3
DEFAULT_CONSOLE_SSH_MAX_CONCURRENT_CALLS = 8
DEFAULT_CONSOLE_SSH_SESSION_IDLE_S = 60


@dataclass(frozen=True, slots=True)
class ConsoleSshSettings:
    """Effective ``[console_ssh]`` settings, coerced to their use types.

    Attributes:
        control_persist: OpenSSH ControlPersist duration, passed VERBATIM
            as the ``ControlPersist=`` value on the ``ssh -MNf`` master
            command (never parsed locally; unusable values fall back to the
            default rather than shipping garbage on an argv).
        enable_multiplexing: False disables the whole ControlMaster
            machinery — per-call direct connections, no sockets, no
            masters. The Windows posture (ssh.exe lacks ControlMaster).
        connect_timeout_s: Ceiling on the master handshake and per-call
            connects, in seconds.
        max_concurrent_calls: Cap on in-flight per-binding ssh calls.
        session_worker: Kill switch for the per-run SSH session worker;
            False is pure one-shot (one ssh exchange per call).
        session_idle_s: Idle close for a session worker, in seconds (both
            the laptop registry and the host-side parent).
        bundle_cache: Whether the host loader may cache the worker bundle
            in ``$XDG_RUNTIME_DIR``.
    """

    control_persist: str = DEFAULT_CONSOLE_SSH_CONTROL_PERSIST
    enable_multiplexing: bool = True
    connect_timeout_s: int = DEFAULT_CONSOLE_SSH_CONNECT_TIMEOUT_S
    max_concurrent_calls: int = DEFAULT_CONSOLE_SSH_MAX_CONCURRENT_CALLS
    session_worker: bool = True
    session_idle_s: int = DEFAULT_CONSOLE_SSH_SESSION_IDLE_S
    bundle_cache: bool = True


def get_console_ssh_settings() -> ConsoleSshSettings:
    """Return the effective ``[console_ssh]`` settings.

    The default returned when the section is absent or unusable is always
    the shipped default (multiplexing ON), matching the fallback posture
    of the sibling section accessors: a malformed key must not silently
    degrade remote workspaces into per-call direct connections.

    Returns:
        The coerced settings; per-key fallbacks on invalid values.
    """

    raw_persist = get_cli_setting(
        "console_ssh", "control_persist", DEFAULT_CONSOLE_SSH_CONTROL_PERSIST
    )
    # ssh_config(5) ControlPersist grammar: yes/no, or a TIME FORMAT --
    # bare seconds or number+unit groups such as "10m" or "1h30m".
    control_persist = (
        raw_persist
        if isinstance(raw_persist, str)
        and re.fullmatch(r"yes|no|\d+|(?:\d+[sSmMhHdDwW])+", raw_persist)
        else DEFAULT_CONSOLE_SSH_CONTROL_PERSIST
    )
    # Strict bool (TOML delivers real booleans): a hand-edited non-boolean
    # falls back to the shipped default rather than coercing through the
    # truthy-string ladder, which turned "maybe" into OFF — a silent
    # multiplexing kill switch no user asked for.
    raw_enabled = get_cli_setting("console_ssh", "enable_multiplexing", True)
    enable_multiplexing = raw_enabled if type(raw_enabled) is bool else True
    raw_session = get_cli_setting("console_ssh", "session_worker", True)
    raw_cache = get_cli_setting("console_ssh", "bundle_cache", True)
    return ConsoleSshSettings(
        session_worker=raw_session if type(raw_session) is bool else True,
        session_idle_s=coerce_int_setting(
            get_cli_setting(
                "console_ssh", "session_idle_s", DEFAULT_CONSOLE_SSH_SESSION_IDLE_S
            ),
            DEFAULT_CONSOLE_SSH_SESSION_IDLE_S,
            minimum=1,
        ),
        bundle_cache=raw_cache if type(raw_cache) is bool else True,
        control_persist=control_persist,
        enable_multiplexing=enable_multiplexing,
        connect_timeout_s=coerce_int_setting(
            get_cli_setting(
                "console_ssh",
                "connect_timeout_s",
                DEFAULT_CONSOLE_SSH_CONNECT_TIMEOUT_S,
            ),
            DEFAULT_CONSOLE_SSH_CONNECT_TIMEOUT_S,
            minimum=1,
        ),
        max_concurrent_calls=coerce_int_setting(
            get_cli_setting(
                "console_ssh",
                "max_concurrent_calls",
                DEFAULT_CONSOLE_SSH_MAX_CONCURRENT_CALLS,
            ),
            DEFAULT_CONSOLE_SSH_MAX_CONCURRENT_CALLS,
            minimum=1,
        ),
    )


SERVER_CLIENT_ID = "SERVER_API_V1"
# Client ID for the CLI application instance for its local databases
from tldw_chatbook.Backup_Recovery.isolated_restore import installation_client_id

CLI_APP_CLIENT_ID = installation_client_id()

# --- Path to the CLI's configuration file ---
DEFAULT_CONFIG_PATH = profile_paths.default_config_path()


@lru_cache(maxsize=16)
def _resolve_effective_config_path(
    override: str | None,
    home: str | None,
    userprofile: str | None,
    cwd: str | None,
) -> Path:
    """Cache lexical selection for one environment and relative-path base."""
    del home, userprofile, cwd  # Key the environment read by expanduser/abspath.
    return profile_paths.lexical_path(override or DEFAULT_CONFIG_PATH)


def _get_effective_config_path() -> Path:
    """Return the lexical active CLI config path."""
    override = os.environ.get("TLDW_CONFIG_PATH")
    cwd = os.getcwd() if override and not os.path.isabs(override) else None
    return _resolve_effective_config_path(
        override,
        os.environ.get("HOME"),
        os.environ.get("USERPROFILE"),
        cwd,
    )


def get_cli_config_path() -> Path:
    """Return the effective config path, including any environment override."""

    return _get_effective_config_path()


def get_user_themes_dir() -> Path:
    """Directory holding the user's saved theme TOML files (active profile)."""

    return get_cli_config_path().parent / "themes"


def _optional_package_available(module_name: str) -> bool:
    """Return whether an optional top-level module is installed without importing it."""

    try:
        return importlib.util.find_spec(module_name) is not None
    except (AttributeError, ImportError, ValueError):
        return False


def _default_stt_provider_for_platform() -> str:
    """Return the speech-to-text provider this platform prefers, unconfigured.

    macOS prefers the Apple-Silicon-native engines when installed --
    parakeet-mlx first, then lightning-whisper-mlx -- and every other
    platform (and macOS with neither installed) falls back to
    faster-whisper. This is the single source of truth for that
    preference: `load_settings()` uses it for `STT_settings.default_stt_provider`,
    and `CONFIG_TOML_CONTENT` is interpolated with it so the
    `[transcription] default_provider` line a fresh install ships never
    contradicts what this function computes (task-867 -- the template used
    to hardcode "faster-whisper" unconditionally, so the darwin preference
    could never engage on a normal install).
    """
    if sys.platform == "darwin":
        if _optional_package_available("parakeet_mlx"):
            return "parakeet-mlx"
        if _optional_package_available("lightning_whisper_mlx"):
            return "lightning-whisper-mlx"
    return "faster-whisper"


def application_owned_config_directory(config_path: Path) -> Path | None:
    """Return the app-owned default config parent, never a custom parent."""

    if _config_participants.verified_companion_parent(
        sys.modules[__name__], config_path
    ):
        return None
    if os.environ.get("TLDW_CONFIG_PATH"):
        return None
    default_path = lexical_path(DEFAULT_CONFIG_PATH)
    return default_path.parent if lexical_path(config_path) == default_path else None


def _report_config_path_posture(
    result: PrivatePathResult,
    *,
    target_kind: str = "file",
) -> None:
    if result.status is PrivatePathStatus.UNVERIFIED_PLATFORM:
        logger.warning(
            f"Config {target_kind} permission posture is unverified on this platform."
        )
    elif result.status is PrivatePathStatus.HARDENED_PRIVATE:
        logger.info(
            f"Hardened the effective config {target_kind} to the private posture."
        )


# --- Encryption support ---


def _take_startup_unlock() -> tuple[Optional[str], bool]:
    """The startup unlock's outcome, if it is running (TASK-34100.4 round 2).

    `Backup_Recovery.launcher.startup_unlock` imports this module only after
    the master password was typed; taking it here, before the module-level
    load below, means that load decrypts instead of warning "no password is
    set" right after the right password. Read through ``sys.modules`` so
    config never imports the launcher itself.

    Returns:
        ``(password, pending)`` from ``launcher.take_startup_unlock()``, or
        ``(None, False)`` when no startup unlock is in progress.
    """
    launcher = sys.modules.get("tldw_chatbook.Backup_Recovery.launcher")
    take = getattr(launcher, "take_startup_unlock", None)
    if not callable(take):
        return None, False
    return take()


# Cached password for the session; True while a startup reset or re-key is
# about to finish the unlock (the locked import-time load is then expected).
_ENCRYPTION_PASSWORD, _STARTUP_UNLOCK_PENDING = _take_startup_unlock()
_ENCRYPTION_MODULE = None  # Lazily loaded encryption module
_CONFIG_GENERATION = 0
_CONFIG_PERSISTENCE_ERROR = None

#: Permission mode used the first time an encryption-related rewrite of the
#: config file creates it from scratch (no pre-existing file whose mode can
#: be preserved). The config file can hold plaintext API keys and the
#: encryption password verifier, so a freshly created one gets a
#: user-only-readable mode rather than ``atomic_write_text``'s generic
#: 0o644 default. Every encryption entry point passes this alongside
#: ``preserve_existing_mode=True`` so an already-existing file's mode
#: (e.g. a user-tightened 0o600) is never widened by the rewrite -- see
#: task-851 review finding 2.
CONFIG_SECRETS_FILE_MODE = 0o600

# --- Chunking Settings (Default, can be overridden by TOML) ---
global_default_chunk_language = "en"

# --- Default Fallback Configurations (if not found in TOML) ---
# These will be populated from TOML or use these hardcoded dicts as fallbacks.
DEFAULT_APP_TTS_CONFIG = {
    "OPENAI_API_KEY_fallback": "sk-...",  # Note: API keys should primarily come from [API] section or ENV
    "KOKORO_ONNX_MODEL_PATH_DEFAULT": "path/to/your/downloaded/kokoro-v0_19.onnx",
    "KOKORO_ONNX_VOICES_JSON_DEFAULT": "path/to/your/downloaded/voices.json",
    "KOKORO_DEVICE_DEFAULT": "cpu",  # or "cuda"
    "ELEVENLABS_API_KEY_fallback": "el-...",  # Note: API keys should primarily come from [API] section or ENV
    "local_kokoro_default_onnx": {"KOKORO_DEVICE": "cuda:0"},
    "global_tts_settings": {
        # shared settings
    },
}

DEFAULT_DATABASE_CONFIG = {}  # Example, can be populated if needed

DEFAULT_RAG_SEARCH_CONFIG = {
    # Legacy settings for backwards compatibility
    "fts_top_k": 10,
    "vector_top_k": 10,
    "web_vector_top_k": 10,
    "llm_context_document_limit": 10,
    # New comprehensive RAG settings
    "retriever": {
        "fts_top_k": 10,
        "vector_top_k": 10,
        # Hybrid fusion alpha (RRF blend): 0 = FTS only, 1 = vector only.
        # 0.7 matches the tldw_server default (vector-weighted).
        "hybrid_alpha": 0.7,
        "chunk_size": 512,
        "chunk_overlap": 128,
        "media_collection": "media_embeddings",
        "chat_collection": "chat_embeddings",
        "notes_collection": "notes_embeddings",
        "character_collection": "character_embeddings",
    },
    "search": {
        "default_search_mode": "semantic",
        "default_top_k": 10,
        "score_threshold": 0.0,
        "include_citations": True,
        "citation_style": "inline",
        "snippet_max_chars": 240,
        "max_context_size": 16000,
    },
    "processor": {
        "enable_reranking": True,
        "reranker_model": None,
        "reranker_top_k": 5,
        "deduplication_threshold": 0.85,
        "max_context_length": 4096,
        "combination_method": "weighted",
    },
    "generator": {
        "default_model": None,
        "default_temperature": 0.7,
        "max_tokens": 1024,
        "enable_streaming": True,
        "stream_chunk_size": 10,
    },
    "chroma": {
        "persist_directory": None,
        "collection_prefix": "tldw_rag",
        "embedding_model": "all-MiniLM-L6-v2",
        "embedding_dimension": 384,
        "distance_metric": "cosine",
    },
    "cache": {
        "enable_cache": True,
        "cache_ttl": 3600,
        "max_cache_size": 1000,
        "cache_embedding_results": True,
        "cache_search_results": True,
        "cache_llm_responses": False,
    },
    "service": {
        "profile": "hybrid_basic",  # Default profile: "bm25_only", "vector_only", "hybrid_basic", "hybrid_enhanced", "hybrid_full"
        # Available profiles:
        # - bm25_only: Pure keyword search
        # - vector_only: Pure semantic search
        # - hybrid_basic: Combined search without enhancements
        # - hybrid_enhanced: Hybrid with parent retrieval
        # - hybrid_full: All features enabled
        # - fast_search, high_accuracy, balanced, long_context, technical_docs, research_papers, code_search
        "custom_overrides": {
            # Optional: Override specific settings from the profile
            # "enable_parent_retrieval": True,
            # "enable_reranking": False,
            # "enable_parallel_processing": True,
            # "parent_size_multiplier": 3,
            # "expand_context_on_retrieval": True,
            # "clean_pdf_artifacts": True,
            #
            # There is NO "reranking_strategy" key here. One used to be
            # listed, and it read nothing -- no code anywhere loaded it, so
            # setting it selected exactly nothing (TASK-17600 F3). The
            # strategy lives on a RAG PROFILE, as
            # `reranking_config.strategy` in the profile's saved JSON under
            # <user data dir>/rag_profiles/: `ProfileConfig` serialises the
            # whole `RerankingConfig` and rebuilds it on load, so a saved or
            # cloned profile keeps its strategy across restarts (pinned by
            # Tests/RAG/test_config_profiles.py::
            # test_a_saved_profile_round_trips_its_reranking_strategy). The
            # Settings form edits that profile's provider/model/top-k but
            # not its strategy.
            #
            # Reranking strategies: "pointwise" | "pairwise" | "listwise"
            # (each bills an LLM provider per call) or "cross_encoder" (a
            # local model, no provider/credential/network). "cross_encoder"
            # is implemented and selectable but is NOT recommended: it is
            # the only strategy that has been measured here (TASK-16965)
            # and it came out net harmful on average [CAVEAT: that averaged row EXCLUDES `scoped` and `negative` (`UNAVERAGED_CATEGORIES`), and `scoped` is where this strategy WINS -- over all 53 ground-truthed queries hybrid REVERSES sign (MRR 0.731 -> 0.806, +0.075). TASK-16965 final review F1.] -- large gains where
            # retrieval is weak, losses where it is already good. See
            # Docs/superpowers/qa/2026-08-17-cross-encoder/report.md.
        },
    },
    "memory_management": {
        "max_total_size_mb": 1024.0,
        "max_collection_size_mb": 512.0,
        "max_documents_per_collection": 100000,
        "max_age_days": 90,
        "inactive_collection_days": 30,
        "enable_automatic_cleanup": True,
        "cleanup_interval_hours": 24,
        "cleanup_batch_size": 1000,
        "enable_lru_cache": True,
        "memory_limit_bytes": 2147483648,
        "min_documents_to_keep": 100,
        "cleanup_confirmation_required": False,
    },
}

DEFAULT_MEDIA_INGESTION_CONFIG = {
    "pdf": {
        "chunk_method": "semantic",
        "chunk_size": 500,
        "chunk_overlap": 200,
        "use_adaptive_chunking": False,
        "use_multi_level_chunking": False,
        "chunk_language": "",
        # OCR settings
        "enable_ocr": False,  # Default to disabled for performance
        "ocr_language": "en",  # Default OCR language
        "ocr_backend": "docling",  # Default OCR backend
        "ocr_confidence_threshold": 0.8,  # Minimum confidence score
    },
    "ebook": {
        "chunk_method": "ebook_chapters",
        "chunk_size": 1000,
        "chunk_overlap": 200,
        "use_adaptive_chunking": False,
        "use_multi_level_chunking": False,
        "chunk_language": "",
    },
    "document": {
        "chunk_method": "sentences",
        "chunk_size": 1500,
        "chunk_overlap": 100,
        "use_adaptive_chunking": False,
        "use_multi_level_chunking": False,
        "chunk_language": "",
        # OCR settings
        "enable_ocr": False,  # Default to disabled for performance
        "ocr_language": "en",  # Default OCR language
        "ocr_backend": "docling",  # Default OCR backend
        "ocr_confidence_threshold": 0.8,  # Minimum confidence score
    },
    "plaintext": {
        "chunk_method": "paragraphs",
        "chunk_size": 500,
        "chunk_overlap": 200,
        "use_adaptive_chunking": False,
        "use_multi_level_chunking": False,
        "chunk_language": "",
    },
    "web_article": {
        "chunk_method": "paragraphs",
        "chunk_size": 500,
        "chunk_overlap": 200,
        "use_adaptive_chunking": False,
        "use_multi_level_chunking": False,
        "chunk_language": "",
    },
    "audio": {
        "chunk_method": "sentences",
        "chunk_size": 500,
        "chunk_overlap": 200,
        "use_adaptive_chunking": False,
        "use_multi_level_chunking": False,
        "chunk_language": "",
        "transcription_model": "base",
        "transcription_language": "en",
        "vad_filter": False,
        "diarize": False,
    },
    "video": {
        "chunk_method": "sentences",
        "chunk_size": 500,
        "chunk_overlap": 200,
        "use_adaptive_chunking": False,
        "use_multi_level_chunking": False,
        "chunk_language": "",
        "transcription_model": "base",
        "transcription_language": "en",
        "vad_filter": False,
        "diarize": False,
        "extract_audio_only": True,
    },
    "image": {
        "chunk_method": "visual_blocks",
        "chunk_size": 1000,
        "chunk_overlap": 100,
        "use_adaptive_chunking": False,
        "use_multi_level_chunking": False,
        "chunk_language": "",
        # OCR settings
        "enable_ocr": True,  # Default to enabled for images
        "ocr_backend": "auto",  # Auto-select best available backend
        "ocr_language": "en",
        "ocr_confidence_threshold": 0.8,
        # Visual processing settings
        "extract_visual_features": True,
        "visual_feature_model": "basic",
        "image_preprocessing": True,
        "max_image_size": 4096,  # Max dimension in pixels
    },
}

# OCR Backend Configurations
DEFAULT_OCR_BACKEND_CONFIG = {
    "docext": {
        "mode": "api",  # "api", "model", or "openai"
        "api_url": "http://localhost:7860",
        "model_name": "nanonets/Nanonets-OCR-s",
        "username": "admin",
        "password": "admin",
        "max_new_tokens": 4096,
        # For OpenAI mode
        "openai_base_url": "http://localhost:8000/v1",
        "openai_api_key": "123",
    },
    "tesseract": {
        "config": "",  # Additional tesseract config options
        "lang": "eng",  # Default language
    },
    "easyocr": {"use_gpu": True, "languages": ["en"]},
    "paddleocr": {"use_gpu": True, "lang": "en"},
}

DEFAULT_DIARIZATION_CONFIG = {
    # Enable diarization by default
    "enabled": False,
    # VAD settings
    "vad_threshold": 0.5,
    "vad_min_speech_duration": 0.25,
    "vad_min_silence_duration": 0.25,
    # Segmentation settings
    "segment_duration": 2.0,
    "segment_overlap": 0.5,
    "min_segment_duration": 1.0,
    "max_segment_duration": 3.0,
    # Embedding model
    "embedding_model": "speechbrain/spkrec-ecapa-voxceleb",
    "embedding_device": "auto",  # auto, cuda, cpu
    # Clustering settings
    "clustering_method": "spectral",  # spectral, agglomerative
    "similarity_threshold": 0.85,
    "min_speakers": 1,
    "max_speakers": 10,
    # Post-processing
    "merge_threshold": 0.5,  # seconds between segments to merge
    "min_speaker_duration": 3.0,  # minimum total duration per speaker
}

_BUILT_IN_OPENAI_TTS_MAPPINGS = {
    "models": {
        "tts-1": "openai_official_tts-1",
        "tts-1-hd": "openai_official_tts-1-hd",
        "eleven_monolingual_v1": "elevenlabs_english_v1",
        "kokoro": "local_kokoro_default_onnx",
    },
    "voices": {
        "alloy": "alloy",
        "echo": "echo",
        "fable": "fable",
        "onyx": "onyx",
        "nova": "nova",
        "shimmer": "shimmer",
        "RachelEL": "21m00Tcm4TlvDq8ikWAM",
        "k_bella": "af_bella",
        "k_adam": "am_v0adam",
    },
}


def _validate_openai_tts_mappings(payload: object) -> Dict[str, Dict[str, str]]:
    """Return the bounded mapping schema or raise without payload details."""

    if not isinstance(payload, dict):
        raise ValueError("OpenAI TTS mapping schema is invalid")
    validated: Dict[str, Dict[str, str]] = {}
    for section_name in ("models", "voices"):
        section = payload.get(section_name)
        if not isinstance(section, dict) or any(
            type(key) is not str or type(value) is not str
            for key, value in section.items()
        ):
            raise ValueError("OpenAI TTS mapping schema is invalid")
        validated[section_name] = dict(section)
    return validated


def load_openai_mappings() -> Dict:
    """Load OpenAI TTS mappings from packaged resources.

    Load through importlib.resources so wheels and editable installs agree.
    """
    from importlib import resources as importlib_resources

    package = "tldw_chatbook.Config_Files"
    resource_name = "openai_tts_mappings.json"

    try:
        mapping_path = importlib_resources.files(package).joinpath(resource_name)
        with mapping_path.open("r", encoding="utf-8") as f:
            return _validate_openai_tts_mappings(json.load(f))
    except Exception:
        logger.info("OpenAI TTS mappings unavailable; using built-in defaults")
        return copy.deepcopy(_BUILT_IN_OPENAI_TTS_MAPPINGS)


_openai_mappings = load_openai_mappings()

openai_tts_mappings = copy.deepcopy(_BUILT_IN_OPENAI_TTS_MAPPINGS)
# Update openai_tts_mappings with values from _openai_mappings (JSON file takes precedence)
if _openai_mappings:
    openai_tts_mappings["models"].update(_openai_mappings.get("models", {}))
    openai_tts_mappings["voices"].update(_openai_mappings.get("voices", {}))


def deep_merge_dicts(base: Dict, update: Dict) -> Dict:
    """Recursively merges update_dict into base_dict."""
    merged = copy.deepcopy(base)
    for key, value in update.items():
        if isinstance(value, dict) and key in merged and isinstance(merged[key], dict):
            merged[key] = deep_merge_dicts(merged[key], value)
        else:
            merged[key] = value
    return merged


def get_encryption_module():
    """Lazily load and return the encryption module."""
    global _ENCRYPTION_MODULE
    if _ENCRYPTION_MODULE is None:
        from tldw_chatbook.Utils.config_encryption import config_encryption

        _ENCRYPTION_MODULE = config_encryption
    return _ENCRYPTION_MODULE


def set_encryption_password(password: str):
    """Set the encryption password for the current session.

    Also invalidates the settings/CLI config caches: any config loaded before the
    password was available (e.g. the module-level ``APP_CONFIG`` primed at import,
    before the startup unlock prompt) holds ciphertext, so it must be dropped and
    re-decrypted on the next load.
    """
    global _ENCRYPTION_PASSWORD, _SETTINGS_CACHE, _CONFIG_CACHE
    global _STARTUP_UNLOCK_PENDING
    _ENCRYPTION_PASSWORD = password
    _STARTUP_UNLOCK_PENDING = False
    _SETTINGS_CACHE = None
    _CONFIG_CACHE = None
    get_encryption_module().clear_derived_key_cache()
    logger.info("Encryption password set for current session")


def get_encryption_password() -> Optional[str]:
    """Get the encryption password for the current session."""
    return _ENCRYPTION_PASSWORD


def clear_encryption_password():
    """Clear the encryption password from memory."""
    global _ENCRYPTION_PASSWORD, _STARTUP_UNLOCK_PENDING
    _ENCRYPTION_PASSWORD = None
    _STARTUP_UNLOCK_PENDING = False
    get_encryption_module().clear_derived_key_cache()
    logger.info("Encryption password cleared from memory")


class _ConfigDecryptionResult(NamedTuple):
    config: Dict[str, Any]
    succeeded: bool


def _decrypt_config_section_with_status(
    config_data: Dict[str, Any],
    *,
    strict: bool = False,
) -> _ConfigDecryptionResult:
    encryption_config = config_data.get("encryption", {})
    if not encryption_config.get("enabled", False):
        return _ConfigDecryptionResult(config_data, True)

    password = get_encryption_password()
    if not password:
        if _STARTUP_UNLOCK_PENDING:
            # A startup reset or re-key installs its outcome right after this
            # import; a locked load now is expected, not a problem to report
            # under the prompt (TASK-34100.4 review round 2).
            logger.debug("Encrypted config loaded before the startup unlock finished.")
        else:
            logger.warning(
                "Encryption is enabled but no password is set. Cannot decrypt config."
            )
        return _ConfigDecryptionResult(config_data, True)

    try:
        enc_module = get_encryption_module()
        if strict:
            decrypted_config = enc_module.decrypt_config_strict(config_data, password)
        else:
            decrypted_config = enc_module.decrypt_config(config_data, password)
        return _ConfigDecryptionResult(decrypted_config, True)
    except Exception as e:
        logger.error(f"Failed to decrypt config: {e}")
        return _ConfigDecryptionResult(config_data, False)


def decrypt_config_section(config_data: Dict[str, Any]) -> Dict[str, Any]:
    """
    Decrypt encrypted values in the config if encryption is enabled.

    Args:
        config_data: The config dictionary potentially containing encrypted values

    Returns:
        Config dictionary with decrypted values
    """
    return _decrypt_config_section_with_status(config_data).config


def encrypt_api_keys_in_config(
    config_data: Dict[str, Any], password: str
) -> Dict[str, Any]:
    """
    Encrypt API keys in the config data.

    Args:
        config_data: The config dictionary
        password: The password to use for encryption

    Returns:
        Config dictionary with encrypted API keys
    """
    enc_module = get_encryption_module()
    encrypted_config = copy.deepcopy(config_data)

    # Set encryption metadata
    encryption_config = encrypted_config.get("encryption", {})
    encryption_config["enabled"] = True
    encryption_config["method"] = "AES-256-GCM-scrypt"
    encryption_config["version"] = 1  # New clean version
    # Create password verifier for authentication
    encryption_config["password_verifier"] = enc_module.create_password_verifier(
        password
    )
    encrypted_config["encryption"] = encryption_config

    # Encrypt all sensitive fields in all sections
    def encrypt_sensitive_fields(d: Dict[str, Any]) -> Dict[str, Any]:
        result = {}
        for key, value in d.items():
            # Skip the encryption section itself
            if key == "encryption":
                result[key] = value
                continue

            if isinstance(value, dict):
                # Recursively encrypt nested dictionaries
                result[key] = encrypt_sensitive_fields(value)
            elif isinstance(value, str) and value.strip():
                # Check if this is a sensitive field, using the same
                # predicate every other encryption/redaction/reporting path
                # in the app uses (see Utils/sensitive_config_keys.py for
                # why this used to disagree with itself).
                if is_sensitive_config_key(key):
                    # Skip if already encrypted or is a placeholder
                    if not (
                        enc_module.is_encrypted(value)
                        or (value.startswith("<") and value.endswith(">"))
                    ):
                        result[key] = enc_module.encrypt_value(value, password)
                    else:
                        result[key] = value
                else:
                    result[key] = value
            else:
                result[key] = value
        return result

    return encrypt_sensitive_fields(encrypted_config)


def _get_typed_value(
    data_dict: Dict, key: str, default: Any, target_type: type = str
) -> Any:
    """Helper to get value from dict and cast to type, with logging for type errors."""
    value = data_dict.get(key, default)
    if (
        value is default and default is not None
    ):  # if value is the default, it's already typed
        return value
    if value is None:  # If key is missing and default is None
        return None

    try:
        if target_type is bool:
            if isinstance(value, bool):
                return value
            # For bools from TOML strings (shouldn't happen if TOML is well-formed)
            return str(value).lower() in ["true", "1", "t", "y", "yes"]
        if target_type is Path:
            return Path(value) if value else default
        return target_type(value)
    except (ValueError, TypeError) as e:
        logger.warning(
            f"Config key '{key}' has value '{value}' which could not be converted to {target_type}. Using default: '{default}'. Error: {e}"
        )
        return default


def _get_int_timeout_value(data_dict: Dict, key: str, default: int) -> int:
    """Get an integer timeout value, rejecting booleans, non-positive values, and malformed strings.

    Args:
        data_dict: Configuration dictionary
        key: Configuration key to lookup
        default: Default timeout value in seconds

    Returns:
        Integer timeout value, or default if conversion fails, value is boolean, or value is non-positive.
    """
    value = data_dict.get(key, default)
    if value is default:  # Already the default
        return value
    if isinstance(value, bool):  # Reject booleans (int(True) == 1, which is wrong)
        logger.warning(
            f"Config key '{key}' has boolean value {value} which is not valid for timeout. Using default: {default}."
        )
        return default
    try:
        timeout_int = int(value)
        if timeout_int <= 0:
            logger.warning(
                f"Config key '{key}' has value '{value}' which is non-positive and not valid for timeout. Using default: {default}."
            )
            return default
        return timeout_int
    except (ValueError, TypeError) as e:
        logger.warning(
            f"Config key '{key}' has value '{value}' which could not be converted to int timeout. Using default: '{default}'. Error: {e}"
        )
        return default


DEFAULT_CONSOLE_PASTE_COLLAPSE_THRESHOLD = 50
MIN_CONSOLE_PASTE_COLLAPSE_THRESHOLD = 1
MAX_CONSOLE_PASTE_COLLAPSE_THRESHOLD = 100000
DEFAULT_CONSOLE_PROJECT_INSTRUCTIONS_MAX_BYTES = 32768
MIN_CONSOLE_PROJECT_INSTRUCTIONS_MAX_BYTES = 1
MAX_CONSOLE_PROJECT_INSTRUCTIONS_MAX_BYTES = 1024 * 1024

# TASK-870: the single, user-adjustable cap on how much of an agent tool
# result the Console *displays* -- replaces the scattered hardcoded caps
# that used to govern the live step summary (200), the transcript TOOL
# marker (160), and a resumed/persisted step's summary (200). Distinct from
# `Agents.agent_models.RunBudget.max_tool_result_chars` (default 16,000),
# which caps what the MODEL saw -- that value enters the model's own
# history, not the Console's UI, and stays out of this control's reach.
# Default (160) is the transcript TOOL marker's prior cap, kept as-is: the
# inline marker is the primary, always-visible reading surface (every user
# scrolling the transcript sees it), so a fresh install's TRANSCRIPT reads
# unchanged. The Agent rail's live-step and resumed/persisted step summaries
# were previously 200, not 160 -- unifying to one cap means those two
# secondary, optional-panel surfaces now trim 40 characters more than
# before. That is a real, if minor, behaviour change, not a no-op: chosen
# over raising the default to 200 (which would instead grow the marker and
# make the transcript itself noisier) because the transcript is what most
# users actually read, and "View full log" now exists as the full-fidelity
# escape hatch the rail's tighter preview can safely defer to.
# Maximum (2000) is not arbitrary: `agent_runtime.py` already caps a step's
# OWN recorded `result` field at 2000 characters before any of these three
# display paths ever see it -- raising the display cap past that ceiling
# could not reveal a single additional character, only mislead a user into
# thinking a higher setting shows more. Reading the full, untruncated
# result -- beyond what any display cap can reach -- is what the run log
# ("View full log") is for.
DEFAULT_CONSOLE_TOOL_RESULT_DISPLAY_CHARS = 160
MIN_CONSOLE_TOOL_RESULT_DISPLAY_CHARS = 20
MAX_CONSOLE_TOOL_RESULT_DISPLAY_CHARS = 2000

# TASK-18600: the Console agent's run budget, exposed in Settings ▸ Console
# Behavior and resolved per run by `console_agent_bridge.console_run_budget()`.
# `[agents] denial_circuit_breaker_limit` is resolved separately per run;
# default 3 stops after a fully settled denied tail, while 0 disables it.
# These override `Agents.agent_models.RunBudget`'s own dataclass defaults
# (8 steps / 240s / 30 turns / 0 tokens / 300s per tool call), which stay
# deliberately conservative for any non-Console caller.
#
# WHICH LIMIT ACTUALLY STOPS A RUN: the token ceiling, not the turn cap.
# `agent_service._make_call_model` re-sends the whole conversation every
# turn (`bound_history_for_send` is a no-op unless `[agents]
# run_log_evict_enabled` is on -- off by default, deliberately: see
# `run_log_eviction.py`), and `ModelTurn.tokens` counts that whole re-sent
# prompt. Spend is therefore QUADRATIC in turn count -- roughly
# `delta * N^2 / 2` for `delta` tokens added per round -- so at a typical
# 800-token round the 25M ceiling is reached around turn 250, and reaching
# turn 2000 would require a ~12-token round. The turn and step caps below
# are backstops that will essentially never bind; they are sized generously
# so they never become the surprise limiter, and the token ceiling is the
# real, intentional governor. Owner decision, 2026-08-18.
#: Provider turns (STEP_MODEL steps) per user message.
DEFAULT_CONSOLE_AGENT_MAX_MODEL_TURNS = 2000
MIN_CONSOLE_AGENT_MAX_MODEL_TURNS = 1
#: Step backstop. A fence tool round costs 3 steps (STEP_MODEL +
#: STEP_TOOL_CALL + STEP_TOOL_RESULT) and the wrap-up reply costs 1, so N
#: turns need `3*(N-1)+1` steps -- 5998 at N=2000. 25000 clears that with
#: room for native multi-call batches, which cost `1 + 2N` steps per turn.
DEFAULT_CONSOLE_AGENT_MAX_STEPS = 25000
MIN_CONSOLE_AGENT_MAX_STEPS = 1
# Mirrored by agent_models.MAX_RUN_CONTROL_STEPS; pinned by Console budget tests
# without importing Agents here (that would create a config import cycle).
MAX_CONSOLE_AGENT_MAX_STEPS = 199_999
#: Wall-clock ceiling for ONE agent run (one user message), in seconds.
#: 86400 = 24h, so a genuinely long-running operation is not cut off. This
#: is a backstop, not a target: Stop cancels at every step boundary and
#: every 0.5s inside the tool-call wrapper, and a hung provider connection
#: is bounded separately by the generation client's own 300s read timeout
#: (`console_provider_gateway.GENERATION_READ_TIMEOUT_SECONDS`).
DEFAULT_CONSOLE_AGENT_MAX_WALL_SECONDS = 86400.0
MIN_CONSOLE_AGENT_MAX_WALL_SECONDS = 1.0
#: Cumulative prompt+completion spend ceiling for ONE run -- see the
#: quadratic-spend note above for why this is the limit that actually
#: fires. PER RUN, not per conversation: `run_agent_loop`'s `total_tokens`
#: is a per-run local, and BOTH child-budget paths (`clamp_child_budget`
#: for turn-scoped/inline children, `contain_child_budget` for threaded
#: survivor candidates) pass this value to a sub-agent UNCHANGED rather
#: than dividing it, so one message's real worst-case aggregate is
#: ~(1 + max_subagents)x this number -- 3x at the shipped
#: `RunBudget.max_subagents = 2`. Note the wall-clock ceiling below does
#: NOT compose the same way: a threaded child's wall comes from
#: `[agents] child_max_wall_seconds` (default 1800), independent of this
#: run's own, so raising the wall here does not extend a child's.
#: 0 = unlimited, which is genuinely dangerous here: the cycle detector
#: keys on exact `(name, args)` repetition (`agent_runtime._detect_cycle`),
#: so a loop with any varying argument escapes it entirely and this ceiling
#: is the ONLY remaining runaway-spend backstop.
DEFAULT_CONSOLE_AGENT_MAX_TOTAL_TOKENS = 25_000_000
MIN_CONSOLE_AGENT_MAX_TOTAL_TOKENS = 0
#: Wall-clock ceiling for ONE tool call, in seconds. Raised from the engine
#: default (300) because a 24h run budget is useless if a single long
#: crawl, ingest, or build dies at five minutes. 0 = no ceiling: the Console
#: resolver translates it to a finite-but-unfireable deadline
#: (`console_agent_bridge.UNLIMITED_TOOL_CALL_DEADLINE_SECONDS`) rather than
#: passing the engine's literal 0, which would bypass the timeout wrapper --
#: the wrapper is also the only thing polling Stop (every 0.5s) while a
#: tool runs, so a literal 0 would silently disable Stop for the duration
#: of every unlimited tool call. Lowering the configured value below ~186s
#: risks the wrapper reporting "timed out" for an MCP call that later
#: really executes on its abandoned thread -- see
#: `RunBudget.max_tool_call_seconds`.
DEFAULT_CONSOLE_AGENT_MAX_TOOL_CALL_SECONDS = 3600.0
#: TASK-25901: transient model failures (429, 5xx, dropped connection) retried
#: inside the loop before a run gives up. Two rides out a brief blip without
#: keeping a user waiting on a provider that is genuinely down; 0 restores the
#: pre-retry behaviour of ending the run on the first failure. Terminal errors
#: (auth, bad request, config) are never retried at any setting.
DEFAULT_CONSOLE_AGENT_MAX_MODEL_RETRIES = 2
MIN_CONSOLE_AGENT_MAX_MODEL_RETRIES = 0

#: TASK-26001: fraction of any budget dimension at which the running agent is
#: told once to wrap up. Clamped to [0.0, 1.0]; 1.0 effectively disables the
#: warning (exhaustion arrives with it).
DEFAULT_CONSOLE_AGENT_BUDGET_WARNING_FRACTION = 0.8
MIN_CONSOLE_AGENT_BUDGET_WARNING_FRACTION = 0.0

MIN_CONSOLE_AGENT_MAX_TOOL_CALL_SECONDS = 0.0

# Ephemeral side chat (Console selection menu): the default prompt template
# for the "More Details" action. ``{selection}`` is the only placeholder the
# side-chat service substitutes (Task-3 renders it via replace, not format).
DEFAULT_CONSOLE_SIDECHAT_PROMPT_TEMPLATE = "Give me more details about: {selection}"


def coerce_bool_setting(value: Any, default: bool = True) -> bool:
    """Coerce config/app setting values with the same bool rules as load_settings.

    Args:
        value: Raw setting value to coerce.
        default: Fallback value when coercion cannot produce a boolean.

    Returns:
        Coerced boolean value.
    """
    # TASK-32808.4: _get_typed_value returns None unchanged for a None value
    # (other typed getters rely on that passthrough), which violated this
    # function's `-> bool` annotation and let a feature that ships ON read OFF
    # whenever the key was absent. Return the default here, as
    # coerce_int_setting already does.
    if value is None:
        return default
    return _get_typed_value({"value": value}, "value", default, bool)


def coerce_int_setting(
    value: Any,
    default: int,
    *,
    minimum: int | None = None,
    maximum: int | None = None,
) -> int:
    """Coerce integer config/app setting values with optional bounds.

    Args:
        value: Raw setting value to coerce.
        default: Fallback value when coercion fails or bounds reject the value.
        minimum: Optional inclusive lower bound.
        maximum: Optional inclusive upper bound.

    Returns:
        Coerced integer value, or the default when the value is invalid.
    """
    if isinstance(value, bool):
        return default
    # TASK-18600: two inputs used to escape this function as exceptions
    # rather than as the default, and both are reachable from a hand-edited
    # config.toml -- which means both could abort `load_settings` (app
    # startup), not merely mis-set one key.
    #   * `None`: `_get_typed_value` returns None unchanged for a None
    #     value, and the bounds comparison below then raised
    #     `TypeError: '<' not supported between 'NoneType' and 'int'`.
    #   * a non-finite float (`nan`/`inf`, both writable in TOML): `int()`
    #     raises `OverflowError`, which `_get_typed_value` does not catch
    #     (it catches ValueError/TypeError only).
    # Neither is a value any caller can act on, so both resolve to the
    # default like every other unusable input.
    if value is None:
        return default
    if isinstance(value, float) and (
        value != value or value in (float("inf"), float("-inf"))
    ):
        return default
    try:
        coerced = _get_typed_value({"value": value}, "value", default, int)
    except OverflowError:
        return default
    if coerced is None or isinstance(coerced, bool):
        return default
    if minimum is not None and coerced < minimum:
        return default
    if maximum is not None and coerced > maximum:
        return default
    return coerced


def coerce_float_setting(
    value: Any,
    default: float,
    *,
    minimum: float | None = None,
    maximum: float | None = None,
) -> float:
    """Coerce float config/app setting values with optional bounds.

    The float twin of ``coerce_int_setting``, added for the Console agent
    run budget's two duration settings (wall-clock and per-tool-call
    seconds), which are floats in ``RunBudget`` and must survive a TOML
    value written as either ``86400`` or ``86400.0``.

    Args:
        value: Raw setting value to coerce.
        default: Fallback value when coercion fails or bounds reject the value.
        minimum: Optional inclusive lower bound.
        maximum: Optional inclusive upper bound.

    Returns:
        Coerced float value, or the default when the value is invalid.
        ``bool`` is rejected outright (``True`` is not a duration), and a
        non-finite value (``nan``/``inf``) falls back to the default -- an
        ``inf`` wall budget would make the run's wall-clock check
        unfireable rather than merely generous.
    """
    if isinstance(value, bool):
        return default
    try:
        coerced = float(value)
    except (TypeError, ValueError):
        return default
    if coerced != coerced or coerced in (float("inf"), float("-inf")):
        return default
    if minimum is not None and coerced < minimum:
        return default
    if maximum is not None and coerced > maximum:
        return default
    return coerced


# Global cache for load_settings to avoid redundant file I/O
_SETTINGS_CACHE: Optional[Dict[str, Any]] = None
_SETTINGS_CACHE_SOURCE: Optional[Path] = None
#: PERF-06: the config path's identity (every component), stamped before the
#: cached settings were read; a warm hit requires it unchanged.
_SETTINGS_CACHE_POSTURE: Optional[tuple] = None
_SETTINGS_CACHE_LOCK = None  # Will be initialized when needed
#: Serializes the miss->rebuild->store sequence (task-3503).
#:
#: `_SETTINGS_CACHE_LOCK` guards only the cache *cells*; it is released for
#: the rebuild itself, so every thread arriving during a miss used to run
#: the whole rebuild -- re-reading and re-parsing the TOML, re-merging
#: defaults, re-ensuring directories. Measured at 32 bootstrap loads for 8
#: threads on ONE invalidation.
#:
#: REENTRANT on purpose: the rebuild reaches helpers that read configuration
#: again, so a plain Lock would deadlock the rebuilding thread against
#: itself. RLock keeps same-thread reentry behaving exactly as before while
#: admitting only one *thread* at a time.
#:
#: Lock order is ``_SETTINGS_REBUILD_LOCK`` -> ``_CONFIG_FILE_LOCK`` ->
#: ``_SETTINGS_CACHE_LOCK``. Config writes and runtime snapshots use that same
#: order, while warm settings-cache hits take only the cache lock.
_SETTINGS_REBUILD_LOCK = None  # Will be initialized when needed


def _settings_rebuild_lock():
    """Return the process-wide reentrant settings rebuild lock."""

    global _SETTINGS_REBUILD_LOCK
    if _SETTINGS_REBUILD_LOCK is None:
        import threading

        _SETTINGS_REBUILD_LOCK = threading.RLock()
    return _SETTINGS_REBUILD_LOCK


def resolve_tldw_api_config(app_config) -> Dict:
    """Return the [tldw_api] section from either config shape.

    Raw CLI config (load_cli_config_and_ensure_existence) carries [tldw_api]
    at the top level; the app's normalized config (load_settings) keeps the
    raw CLI config nested under COMPREHENSIVE_CONFIG_RAW. Every reader of the
    server endpoint/token must accept both shapes.
    """
    if not isinstance(app_config, dict) and not hasattr(app_config, "get"):
        return {}
    api_config = app_config.get("tldw_api", {}) or {}
    if not isinstance(api_config, dict) or not api_config:
        raw_config = app_config.get("COMPREHENSIVE_CONFIG_RAW", {}) or {}
        nested = raw_config.get("tldw_api", {}) if hasattr(raw_config, "get") else {}
        api_config = nested if isinstance(nested, dict) else {}
    if not isinstance(api_config, dict):
        return {}
    return dict(api_config)


# The [tldw_api] values CONFIG_TOML_CONTENT ships into a fresh profile's
# config file. NOT credentials: the pair exists so readers can recognize an
# untouched template binding (e.g. the Library ingest canvas suppresses its
# server-mode hint when the binding is still the placeholder). Single
# definition here, beside the template's owner module, so the literals never
# spread through the codebase.
TLDW_API_PLACEHOLDER_BASE_URL = "http://127.0.0.1:8000"
TLDW_API_PLACEHOLDER_AUTH_TOKEN = "default-secret-key-for-single-user"

#: Canonical "this is not a real credential" values for provider API keys --
#: PR-T2 Task 7. Shared by `_normalize_legacy_provider_api_key` below and
#: `Chat/provider_readiness.get_provider_readiness`, which imports these
#: three names FROM this module rather than the reverse.
#:
#: (Review round 2 finding: the first fix round had `config.py` import
#: `is_valid_provider_api_key` FROM `Chat/provider_readiness.py`, which
#: reproduced a real cycle -- `config` -> `Chat/__init__` -> `server_chat_
#: conversation_service` -> `runtime_policy.bootstrap` -> back into
#: `config` -- breaking standalone collection of `Tests/RuntimePolicy/`
#: even though the shipped app and the full-suite alphabetical collect
#: order happened to hide it. `config.py` is the dependency ROOT nearly
#: everything else in this app already imports directly (verified: none of
#: this module's own top-level imports -- the `DB.*`/`Utils.*` modules --
#: reach back into `Chat` or `runtime_policy`), so the shared definition
#: belongs here, with `Chat/provider_readiness.py` importing it -- not the
#: reverse. This keeps the actual property Task 7 exists for -- exactly
#: ONE definition of "valid key", consumed by both the credential bridge
#: and the readiness reader -- while fixing the layering.)
PROVIDER_API_KEY_PLACEHOLDERS = frozenset(
    {
        "",
        "<API_KEY_HERE>",
        "YOUR_KEY",
        "your_key",
        "your-api-key",
    }
)


#: The prefix `Utils/config_encryption.ConfigEncryption` writes on every
#: encrypted config value (pinned equal by
#: Tests/test_config_encryption_lifecycle.py). Kept as a literal here so the
#: key resolver below never imports the encryption engine.
ENCRYPTED_CONFIG_VALUE_PREFIX = "enc:"


def is_encrypted_config_value(value: object) -> bool:
    """Whether ``value`` is still-encrypted ``enc:`` config ciphertext.

    TASK-34100.4 (new-protect-summary-03): ciphertext is never a credential.
    A locked session (encryption on, no password) or a value that did not
    decrypt keeps its ``enc:`` form in the loaded config, so every code path
    that reads a key straight from config must treat it as unusable.
    """
    return isinstance(value, str) and value.strip().startswith(
        ENCRYPTED_CONFIG_VALUE_PREFIX
    )


def without_ciphertext(value: Any, absent: Any = None) -> Any:
    """Return ``value`` unchanged, or ``absent`` when it is ``enc:`` ciphertext.

    For key reads that must keep their own blank/placeholder semantics (the
    summarizers distinguish a configured-blank key from a missing one) but
    must never send ciphertext. Provider handlers use
    `resolve_provider_api_key` instead.
    """
    return absent if is_encrypted_config_value(value) else value


def resolve_provider_api_key(value: object) -> Optional[str]:
    """Return `value` stripped, or `None` if it is not a usable provider API
    key (not a string, blank, one of `PROVIDER_API_KEY_PLACEHOLDERS`, or
    still-encrypted `enc:` ciphertext).

    TASK-34100.4 (new-protect-summary-03): ciphertext reads as ABSENT. A
    locked session (encryption on, no password) or a value that did not
    decrypt keeps its `enc:` form in the loaded config; accepting it made
    readiness report Ready and sent the ciphertext as a bearer token.
    """
    if not isinstance(value, str):
        return None
    stripped = value.strip()
    if stripped in PROVIDER_API_KEY_PLACEHOLDERS:
        return None
    if is_encrypted_config_value(stripped):
        return None
    return stripped or None


def is_valid_provider_api_key(value: object) -> bool:
    """Return whether `value` is a usable provider API key."""
    return resolve_provider_api_key(value) is not None


def resolve_tldw_api_auth_token(value: object) -> Optional[str]:
    """Return `value` stripped, or None if blank/placeholder/synthesized.

    Reuses `resolve_provider_api_key`'s existing blank/placeholder screening
    rather than duplicating the rule; adds only the one extra rejected
    literal this credential's boot-rewrite is known to produce.

    Args:
        value: Raw `[tldw_api] auth_token` config value of any type.

    Returns:
        `value` stripped, or None if it is blank, a known provider-key
        placeholder, or `TLDW_API_PLACEHOLDER_AUTH_TOKEN` -- the value the
        app's own config load synthesizes into `[tldw_api]` when a
        profile's file omits `auth_token` (task-31417).
    """
    resolved = resolve_provider_api_key(value)
    if resolved is None or resolved == TLDW_API_PLACEHOLDER_AUTH_TOKEN:
        return None
    return resolved


def normalize_provider_config_key(provider: object) -> str:
    """Return the canonical lookup form used for provider config tables.

    Args:
        provider: Provider label or key to normalize.

    Returns:
        A stripped, lowercase provider key with spaces and hyphens replaced by
        underscores.
    """
    normalized = str(provider or "").strip().lower().replace(" ", "_").replace("-", "_")
    if normalized == "z.ai":
        return "zai"
    return _ENGINE_CONFIG_KEY_ALIASES.get(normalized, normalized)


#: An engine preset's display config key may not normalize to its registry
#: key ("OllamaCloud" -> "ollamacloud", not "ollama_cloud"), which made
#: readiness answer "Unknown provider" (TASK-33511). Derived from the
#: registry; identity for every other preset.
_ENGINE_CONFIG_KEY_ALIASES = {
    record.config_key.lower(): record.key
    for record in ALL_RECORDS
    if record.engine_driven and record.key != "custom-hosted"
}


class ProviderSettingsError(ValueError):
    """Raised when a selected provider's config table is not a mapping."""


def provider_settings_for_key(
    api_settings: object,
    provider_key: str,
) -> Mapping[str, object]:
    """Return provider settings without mutating the loaded configuration.

    QwenCloud historically accepts normalized aliases with the exact table
    taking precedence. Moonshot and Z.ai require one exact canonical table and
    reject normalized duplicates. Other providers retain the existing
    first-normalized-match behavior.

    Args:
        api_settings: Loaded ``api_settings`` value.
        provider_key: Canonical provider key to resolve.

    Returns:
        The resolved provider settings, or an empty mapping when none exist.

    Raises:
        ProviderSettingsError: If an authoritative table is malformed or a
            strict provider has ambiguous normalized tables.
    """
    if not isinstance(api_settings, Mapping):
        return {}

    if provider_key in {"moonshot", "zai"}:
        canonical_settings = api_settings.get(provider_key)
        aliases = tuple(
            configured_provider
            for configured_provider in api_settings
            if configured_provider != provider_key
            and normalize_provider_config_key(configured_provider) == provider_key
        )
        if provider_key in api_settings:
            if not isinstance(canonical_settings, Mapping) or aliases:
                raise ProviderSettingsError(
                    f"api_settings.{provider_key} must be one unambiguous configuration table."
                )
            return canonical_settings
        return {}

    if provider_key == "qwencloud":
        if provider_key in api_settings:
            canonical_settings = api_settings[provider_key]
            if not isinstance(canonical_settings, Mapping):
                raise ProviderSettingsError(
                    "api_settings.qwencloud must be a configuration table."
                )
            alias_settings: Mapping[str, object] = {}
            for configured_provider, configured_value in api_settings.items():
                configured_key = str(configured_provider)
                if configured_key == provider_key:
                    continue
                if normalize_provider_config_key(configured_key) != provider_key:
                    continue
                if isinstance(configured_value, Mapping):
                    alias_settings = configured_value
                break
            merged = dict(alias_settings)
            merged.update(canonical_settings)
            return merged

        for configured_provider, configured_value in api_settings.items():
            if normalize_provider_config_key(configured_provider) != provider_key:
                continue
            if not isinstance(configured_value, Mapping):
                raise ProviderSettingsError(
                    "api_settings.qwencloud must be a configuration table."
                )
            return configured_value
        return {}

    for configured_provider, configured_value in api_settings.items():
        if normalize_provider_config_key(configured_provider) != provider_key:
            continue
        if isinstance(configured_value, Mapping):
            return configured_value
        return {}

    return {}


#: Providers whose legacy `[API] <provider>_api_key` TOML key and
#: `<PROVIDER>_API_KEY` environment variable both follow the plain
#: `_normalize_legacy_provider_api_key` convention, keyed by the SAME
#: normalized provider key `Chat/provider_readiness.provider_config_key`
#: would derive (e.g. `"anthropic"`, not `"anthropic_api"`) -- this is what
#: lets the bridge below write into `api_settings.<provider_key>`, the
#: table `get_provider_readiness` actually reads.
#:
#: `mistral` IS included, deliberately, even though the shipped default
#: config's own decorative table is `[api_settings.mistralai]` (matching
#: `[providers]`'s `MistralAI` listing): `LLM_Calls/LLM_API_Calls.py`'s
#: `chat_with_mistral` (~4617-4621) reads `api_settings.mistral` -- NOT
#: `api_settings.mistralai` -- so `"mistral"` (what `provider_config_key
#: ("Mistral")` computes, and what this bridge writes into) IS the live
#: table the spend path already reads. An earlier revision of this comment
#: claimed bridging under `"mistral"` would create "a second, disconnected
#: table" -- that was backwards: `[api_settings.mistralai]` is the
#: disconnected one; `api_settings.mistral` was simply absent from the
#: shipped defaults, not wrong to write into. (Whether `MistralAI`-display
#: users should also read `[api_settings.mistralai]`, and whether that
#: default table should be renamed, is a separate, pre-existing question
#: out of scope for this task.)
_LEGACY_PROVIDER_API_KEY_BRIDGE: tuple[tuple[str, str, str], ...] = (
    ("openai", "openai_api_key", "OPENAI_API_KEY"),
    ("anthropic", "anthropic_api_key", "ANTHROPIC_API_KEY"),
    ("cohere", "cohere_api_key", "COHERE_API_KEY"),
    ("groq", "groq_api_key", "GROQ_API_KEY"),
    ("huggingface", "huggingface_api_key", "HUGGINGFACE_API_KEY"),
    ("openrouter", "openrouter_api_key", "OPENROUTER_API_KEY"),
    ("deepseek", "deepseek_api_key", "DEEPSEEK_API_KEY"),
    ("google", "google_api_key", "GOOGLE_API_KEY"),
    ("mistral", "mistral_api_key", "MISTRAL_API_KEY"),
)


def _normalize_legacy_provider_api_key(
    api_settings_section: Dict[str, Any],
    provider_key: str,
    *,
    raw_api_section: Dict[str, Any],
    toml_key: str,
    env_var: str,
) -> Optional[str]:
    """One normalized credential for `provider_key` -- PR-T2 Task 7.

    The harm this closes: a config with only `[API] anthropic_api_key` set
    spent real money through the Library path (`LLM_Calls/LLM_API_Calls.
    py`'s `chat_with_anthropic` reads the legacy `anthropic_api` dict built
    a few lines below this function's call sites, which DOES see that key)
    while Console's own readiness check (`Chat/provider_readiness.get_
    provider_readiness`, reading only `api_settings.<provider>.api_key`)
    showed a blocking "Connect a provider" wall for the identical config.
    Both the modern `api_settings` table and the legacy `<provider>_api`
    dict must be built from the SAME resolved value -- never two
    independent reads of `[API]` -- or the split just moves.

    Which of the two a handler reads varies by provider, and the bridge is
    only as true as the table the handler actually opens: `chat_with_
    anthropic` reads the legacy dict, `chat_with_mistral` reads
    `api_settings.mistral`, and `chat_with_google` reads `api_settings.
    google` -- the last only since PR-T2 review round 3 (finding I4), which
    found it reading `api_settings.google_api`, a table nothing in this app
    has ever produced. Google was therefore the one provider for which
    this docstring's claim was FALSE for a bridged `[API] google_api_key`:
    it could not reach the spend path at all while readiness reported
    ready. Pinned by `Tests/Chat/test_google_native_tools.py::test_google_
    api_key_comes_from_the_api_settings_google_table` (handler half) and
    `Tests/Chat/test_provider_readiness.py::test_legacy_only_google_key_
    lands_in_the_table_chat_with_google_reads` (config half).

    **Scope of the "both readers agree" guarantee: the two CONFIG sources
    only** -- the modern `api_settings.<provider>.api_key` table and the
    legacy `[API] <provider>_api_key`. It does NOT extend to the
    environment variable for every provider, and google is a known open
    case (PR-T2 review round 4, R1; pre-existing, filed separately, NOT
    closed here). With only `GOOGLE_API_KEY` set: readiness reports ready
    (it has its own env fallback), this bridge deliberately does not write
    env-sourced values into `api_settings` (see the paragraph above on
    `api_key_source` and prefill safety -- that behavior is pinned and
    correct), google's legacy dict is `google_generative_api` which the
    handler no longer reads, and `chat_with_google` has no env fallback of
    its own. A caller that passes no explicit `api_key` -- the Library RAG
    path among them -- is therefore gated OPEN and fails at the wire. Any
    claim that google is fully closed must say "config-sourced" or name
    this gap.

    Precedence: (1) an explicit, non-placeholder `api_settings.<provider_
    key>.api_key` always wins -- a value entered through the Settings
    screen (the modern location) was a deliberate choice; (2) the
    environment variable; (3) the legacy `[API] <toml_key>` value.

    **This precedence deliberately inverts the module docstring's general
    "env vars -> config.toml -> defaults" priority for this one credential
    lookup.** Before this task, `chat_with_openai` ALREADY overlaid a
    canonical `api_settings.openai` value onto the legacy dict for `api_
    key`/`api_base_url` (see its own call site, `LLM_API_Calls.py:561-580`)
    while every OTHER provider's `<provider>_api` dict resolved env-before-
    TOML with no `api_settings` input at all -- two silently different
    rules per provider. Extending "modern config wins" to all 9 bridged
    providers, rather than restoring env-first everywhere, is the choice
    that makes `get_provider_readiness` (which always shows the config
    value first) and the actual spend agree on which key was used -- the
    entire point of this task. A user who explicitly set `api_settings.
    <provider>.api_key` (e.g. via the Settings screen) now spends with that
    value even if a stale environment variable is also set; this is a
    real, user-visible behavior change and is intentional. See PR-T2 Task
    7's test `test_modern_api_settings_key_outranks_the_env_var_for_the_
    spending_path` (`Tests/Chat/test_provider_readiness.py`) and Task 8's
    docs pass, which should call this out explicitly.

    Only the (3) TOML-sourced fallback is ever written back into
    `api_settings_section` -- never an (2) env-sourced one. Writing an
    env-derived secret into `api_settings` would flip its reported
    `api_key_source` from `env:...` to `config:...`, and `provider_
    readiness.chat_api_key_field_state` treats a `config:` source as safe
    to prefill and persist in the inline Chat-Defaults API-key field --
    silently exposing a secret that was never typed into config. `get_
    provider_readiness`'s own environment fallback already reports the
    env-only case as ready without this rewrite, so nothing is lost by
    leaving `api_settings` untouched there.

    A provider table that does not yet exist is created only when there is
    an actual TOML-sourced value to write into it -- never eagerly, since
    several tests pin an untouched config's `api_settings` as exactly `{}`.

    "Non-placeholder" is delegated to THIS module's own `resolve_provider_
    api_key` (see its definition above, near `PROVIDER_API_KEY_
    PLACEHOLDERS`) -- the SAME function `Chat/provider_readiness.get_
    provider_readiness` runs each of ITS candidate sources through (it
    imports the name from here, aliased `_valid_api_key`), applied here to
    all three sources rather than per-branch, so neither reader can see a
    value the other rejects or a differently-trimmed form of it. An earlier
    revision of this function defined its own single-value placeholder
    check (`value != "<API_KEY_HERE>"`), which missed four of the five
    placeholders that function recognizes (`""`, `"YOUR_KEY"`, `"your_
    key"`, `"your-api-key"`). Concretely: `[api_settings.anthropic] api_key
    = "YOUR_KEY"` alongside a REAL `[API] anthropic_api_key` used to have
    the bridge treat `"YOUR_KEY"` as "explicit modern config wins" and
    write it into the legacy `anthropic_api` dict `chat_with_anthropic`
    spends through, while readiness (which DID recognize `"YOUR_KEY"`)
    correctly reported not-ready -- recreating, inside the very function
    meant to end it, the exact kind of two-readers-disagree split this
    task exists to close. A review round then found a second layering bug
    in the first fix for that: routing the import through `Chat/provider_
    readiness.py` (i.e. `config` importing FROM `Chat`) created a real
    cycle back through `Chat/__init__` -> `server_chat_conversation_
    service` -> `runtime_policy.bootstrap` -> `config`, breaking
    standalone collection of `Tests/RuntimePolicy/` (masked in the
    full-suite run only by alphabetical import ordering). The definition
    now lives here instead, with `provider_readiness.py` importing it --
    matching the rest of the codebase's dependency direction (nearly every
    other module already imports `config` directly; `config` importing
    from a submodule of `Chat` was the anomaly).

    Args:
        api_settings_section: The (already TOML-loaded) `api_settings`
            table, mutated in place only when a TOML-sourced fallback
            applies.
        provider_key: Normalized provider key, e.g. `"anthropic"` -- must
            match `Chat/provider_readiness.provider_config_key`'s output
            for this provider.
        raw_api_section: The raw `[API]` TOML section (legacy namespace).
        toml_key: The legacy key within `raw_api_section`, e.g.
            `"anthropic_api_key"`.
        env_var: The conventional environment variable, e.g.
            `"ANTHROPIC_API_KEY"`.

    Returns:
        The normalized credential (feeds the legacy `<provider>_api` dict
        built just below each call site), or `None` when no source
        resolves one.
    """
    provider_table = api_settings_section.get(provider_key)
    # EVERY source goes through `resolve_provider_api_key` -- the same
    # function `get_provider_readiness` runs each of its own candidates
    # through -- and what this function returns is that resolved (stripped,
    # non-placeholder) value, never the raw one (PR-T2 review round 3,
    # findings I5 + minor 2). Two ways the earlier per-branch handling
    # split the two readers back apart:
    #   * The env branch was a bare `os.getenv(env_var)` truth test, so
    #     `ANTHROPIC_API_KEY="YOUR_KEY"` landed verbatim in the legacy
    #     `anthropic_api` dict while readiness (which validates every
    #     source) said not-ready -- gated surfaces failed safe, but an
    #     ungated `chat_api_call` caller (Evals, briefings, agent runs)
    #     would send the placeholder as a credential.
    #   * The modern/legacy branches validated the STRIPPED form but
    #     returned the raw one, so `api_key = " sk-xyz "` showed
    #     `sk-xyz` in readiness and spent ` sk-xyz ` (a 401).
    modern_value = resolve_provider_api_key(
        provider_table.get("api_key") if isinstance(provider_table, dict) else None
    )
    if modern_value:
        return modern_value  # explicit modern config always wins

    env_value = resolve_provider_api_key(os.getenv(env_var))
    if env_value:
        return env_value

    legacy_value = resolve_provider_api_key(raw_api_section.get(toml_key))
    if legacy_value:
        if not isinstance(provider_table, dict):
            provider_table = {}
            api_settings_section[provider_key] = provider_table
        provider_table["api_key"] = legacy_value
        return legacy_value

    return None


def _config_file_posture(config_path: Path) -> tuple:
    """``lstat`` identity of every component from ``/`` down to the config file.

    Each entry is (dev, ino, type, mode, uid), plus nlink for the file itself,
    or ``None`` for a missing component. A replaced file, a new hard link, a
    symlink swap of the file, or a parent renamed and replaced by a symlink to
    itself all change it (Qodo, #2903). ``lstat`` only: nothing is opened or
    followed.
    """
    import stat as _stat

    posture = []
    for component in (*reversed(config_path.parents), config_path):
        try:
            info = os.lstat(component)
        except FileNotFoundError:
            posture.append(None)
            continue
        except OSError:
            posture.append(("unreadable",))
            continue
        entry = (
            info.st_dev,
            info.st_ino,
            _stat.S_IFMT(info.st_mode),
            _stat.S_IMODE(info.st_mode),
            info.st_uid,
        )
        posture.append(entry + (info.st_nlink,) if component == config_path else entry)
    return tuple(posture)


def _is_plain_owned_file(posture: tuple) -> bool:
    """Whether a posture's last entry is a regular file this user owns, linked once.

    Only that may stand in for the config file a load just created: the
    guarded member checks reject anything else, so a symlink or other object
    swapped in before the re-stamp keeps the stale stamp and the next read
    meets those checks (Qodo, #2903).

    Args:
        posture: A :func:`_config_file_posture` result.

    Returns:
        True for a plain, owned, singly linked file.
    """
    import stat as _stat

    leaf = posture[-1] if posture else None
    # Windows has no geteuid and reports no owner in st_uid; ownership is
    # only comparable where it exists (Qodo, #2903).
    geteuid = getattr(os, "geteuid", None)
    return (
        leaf is not None
        and len(leaf) == 6
        and leaf[2] == _stat.S_IFREG
        and (geteuid is None or leaf[4] == geteuid())
        and leaf[5] == 1
    )


def _settings_cache_hit(active_config_path: Path) -> dict | None:
    """Return the installed settings for ``active_config_path``, or None.

    One short lock and one ``lstat`` per path component. Shared by the
    unguarded warm paths and the guarded rebuild's re-check. The config
    path's identity must still be the one stamped before the cached settings
    were read: the guarded path rejected a replaced or symlinked config
    member, or a symlinked parent, on every read, and a warm hit must not
    hide one (Qodo, #2903), so any change is a miss.
    """
    global _SETTINGS_CACHE_LOCK

    if _SETTINGS_CACHE_LOCK is None:
        import threading

        _SETTINGS_CACHE_LOCK = threading.Lock()
    with _SETTINGS_CACHE_LOCK:
        cached = _SETTINGS_CACHE
        source = _SETTINGS_CACHE_SOURCE
        posture = _SETTINGS_CACHE_POSTURE
    if cached is None or source != active_config_path:
        return None
    if not _posture_unchanged(active_config_path, cached, posture):
        return None
    return cached


#: Per-thread record of the last UI-loop stretch that re-checked the posture.
_POSTURE_STRETCH = None


def _posture_unchanged(active_config_path: Path, cached: dict, posture: tuple) -> bool:
    """Whether the config path still has ``posture``; one check per loop stretch.

    TASK-33620.15: a warm hit ``lstat``s every path component, and one Console
    send made 114-243 warm hits on the UI loop (53-251 ms in the mounted
    harness; a 294 ms live stall in the 0.2 s sync tick, where each ``lstat``
    gives up the GIL to busy workers). On the thread running an event loop,
    one check now covers the callbacks the loop runs before its next batch,
    which no other code on that thread can interleave with; a rebuild or a
    write installs a new settings object, which is never matched. Every
    caller off a loop -- workers, tests, scripts -- still checks every hit.

    Args:
        active_config_path: The config path the warm hit is for.
        cached: The installed settings object that hit.
        posture: The identity stamped when ``cached`` was read.

    Returns:
        True while the path's identity is the stamped one.
    """
    global _POSTURE_STRETCH
    import asyncio

    loop = asyncio._get_running_loop()
    if loop is None:
        return _config_file_posture(active_config_path) == posture
    if _POSTURE_STRETCH is None:
        _POSTURE_STRETCH = _threading.local()
    stretch = _POSTURE_STRETCH
    seen = getattr(stretch, "seen", None)
    if (
        seen is not None
        and seen[0] is loop
        and seen[1] is cached
        and seen[2] is posture
        and seen[3] == active_config_path
    ):
        return True
    if _config_file_posture(active_config_path) != posture:
        return False
    stretch.seen = (loop, cached, posture, active_config_path)
    loop.call_soon(_end_posture_stretch, stretch)
    return True


def _end_posture_stretch(stretch: Any) -> None:
    """Make the next loop batch re-check the config path's identity."""
    stretch.seen = None


def load_settings(
    force_reload: bool = False,
    *,
    reload_bootstrap: bool | None = None,
) -> Dict:
    """Return the merged application settings, rebuilding at most once.

    PERF-06 (TASK-33265): a warm hit is served here, ahead of the ADR-126
    admission handshake. It is a pure in-memory read and paid ~650
    ``open()`` calls per call (the 4 Hz Console poll, every composer
    keystroke). A miss or forced reload runs the guarded
    :func:`_load_settings_guarded`, exactly as before; this mirrors
    TASK-32804.1's ``_warm_config_cache_hit`` for ``get_cli_setting``.

    Args:
        force_reload: Rebuild even on a cache hit.
        reload_bootstrap: Whether the rebuild also force-reloads the CLI
            bootstrap config from disk. ``None`` (default) follows
            ``force_reload``, preserving the historical behavior. TASK-21124:
            ``_publish_runtime_config_unlocked`` passes ``False`` because it
            has already installed a fresh bootstrap cache under the write
            lock -- re-reading and re-parsing the file it just wrote was one
            of the write path's redundant TOML parses.

    Returns:
        The merged settings mapping.
    """
    if not force_reload:
        # Lock-free by design, like TASK-21124's get_cli_setting fast path: a
        # write holds the config locks through fsyncs and TOML parses, and a
        # loop-side read must not stall behind it. A read overlapping a write
        # may return the pre-write settings; the writer invalidates the cache
        # before it returns, so a read after a completed write sees the new
        # value.
        cached = _settings_cache_hit(_get_effective_config_path())
        if cached is not None:
            return cached
    return _load_settings_guarded(
        force_reload=force_reload,
        reload_bootstrap=reload_bootstrap,
    )


@_config_participants.guarded
def _load_settings_guarded(
    force_reload: bool = False,
    *,
    reload_bootstrap: bool | None = None,
) -> dict:
    """Guarded body of :func:`load_settings`: serialize the cache-miss rebuild.

    Thin wrapper over :func:`_load_settings_uncached` that serializes the
    cache-miss rebuild (task-3503).

    Args:
        force_reload: Rebuild even on a cache hit.
        reload_bootstrap: Whether the rebuild also force-reloads the CLI
            bootstrap config from disk. ``None`` (default) follows
            ``force_reload``, preserving the historical behavior. TASK-21124:
            ``_publish_runtime_config_unlocked`` passes ``False`` because it
            has already installed a fresh bootstrap cache under the write
            lock -- re-reading and re-parsing the file it just wrote was one
            of the write path's redundant TOML parses.

    Returns:
        The merged settings mapping.
    """
    active_config_path = _get_effective_config_path()

    def _cache_hit():
        return _settings_cache_hit(active_config_path)

    if not force_reload:
        cached = _cache_hit()
        if cached is not None:
            return cached

    # Miss: serialize the rebuild. Whoever loses the race re-checks the cache
    # and returns the winner's freshly built settings rather than repeating
    # the entire rebuild.
    with _settings_rebuild_lock():
        if not force_reload:
            cached = _cache_hit()
            if cached is not None:
                logger.debug(
                    "load_settings: returning configuration rebuilt by another thread"
                )
                return cached
        return _load_settings_uncached(
            force_reload=force_reload,
            reload_bootstrap=reload_bootstrap,
        )


@_config_participants.guarded
def _load_settings_uncached(
    force_reload: bool = False,
    *,
    reload_bootstrap: bool | None = None,
) -> Dict:
    """
    Loads all settings from TOML config files, environment variables, or defaults into a dictionary.
    It first loads a base config (e.g., server-local), then attempts to load a user-specific
    CLI config which can override or extend the base settings.

    Args:
        force_reload: If True, bypasses the cache and reloads from disk.
        reload_bootstrap: Whether the CLI bootstrap config is also
            force-reloaded from disk; ``None`` follows ``force_reload``
            (see :func:`load_settings`, TASK-21124).

    Returns:
        Dictionary containing all configuration settings.
    """
    global _SETTINGS_CACHE, _SETTINGS_CACHE_SOURCE, _SETTINGS_CACHE_LOCK
    global _SETTINGS_CACHE_POSTURE
    active_config_path = _get_effective_config_path()
    # Stamped before anything is read: a file swapped mid-read leaves a stale
    # stamp, so the next warm read misses rather than trusting it.
    posture = _config_file_posture(active_config_path)

    # Initialize lock on first use to avoid import issues
    if _SETTINGS_CACHE_LOCK is None:
        import threading

        _SETTINGS_CACHE_LOCK = threading.Lock()

    # Thread-safe cache check
    with _SETTINGS_CACHE_LOCK:
        if (
            _SETTINGS_CACHE is not None
            and _SETTINGS_CACHE_SOURCE == active_config_path
            and _SETTINGS_CACHE_POSTURE == posture
            and not force_reload
        ):
            logger.debug("load_settings: Returning cached configuration (cache hit)")
            return _SETTINGS_CACHE
        _SETTINGS_CACHE = None
        _SETTINGS_CACHE_SOURCE = None

    current_file_path = Path(__file__).resolve()
    # config.py is in project_root/tldw_server_api/app/core/config.py
    ACTUAL_PROJECT_ROOT = current_file_path.parent  # /project_root/
    APP_COMPONENT_ROOT = current_file_path.parent  # /project_root/tldw_server_api/
    logger.info(
        f"Determined ACTUAL_PROJECT_ROOT for general paths: {ACTUAL_PROJECT_ROOT}"
    )
    logger.info(f"Determined APP_COMPONENT_ROOT for config files: {APP_COMPONENT_ROOT}")

    # --- Load Comprehensive Config from TOML ---
    # load_cli_config_and_ensure_existence() already deep-merges
    # DEFAULT_CONFIG_FROM_TOML with the user's CLI config file (creating the
    # file with defaults on first run) and decrypts the result; reuse that
    # single read+parse instead of re-opening the same file here a second
    # time. The historical "primary/server-component config" previously
    # probed at APP_COMPONENT_ROOT/Config_Files/config.toml never exists in
    # the packaged app (no installer/build step writes it, and pyproject.toml
    # only packages *.json/*.md from that directory) so merging it was always
    # a no-op; dropping the probe changes nothing observable.
    bootstrap = _load_cli_config_bootstrap(
        force_reload=(force_reload if reload_bootstrap is None else reload_bootstrap)
    )
    toml_config_data = copy.deepcopy(bootstrap.config)
    # Idempotent no-op when already decrypted (or encryption disabled) --
    # kept so a session password entered *after* the CLI cache above was
    # primed with ciphertext still yields plaintext here. Without this,
    # app.app_config (populated from load_settings) could carry `enc:`
    # ciphertext keys that the Chat send path passes to providers verbatim,
    # failing auth.
    toml_config_data = decrypt_config_section(toml_config_data)
    logger.debug(
        "load_settings: Configuration loaded from disk (cache miss or forced reload)"
    )
    # logger.debug(f"Final toml_config_data after potential merge: {toml_config_data}") # Optional: for verbose debugging

    # --- Extract settings from the (potentially merged) TOML, with fallbacks ---
    # Helper to get values from specific TOML sections within the final toml_config_data
    def get_toml_section(section_name: str, default_val: Optional[Dict] = None) -> Dict:
        return toml_config_data.get(
            section_name, default_val if default_val is not None else {}
        )

    api_section = get_toml_section("API")  # This will now check the merged config
    # If [API] exists in the user's CLI config, it would have merged with/overridden the CLI defaults' [API]
    # Same applies to all other sections retrieved below.

    paths_section = get_toml_section("Paths")
    logging_section_server = get_toml_section("Logging")
    processing_section = get_toml_section("Processing")
    chunking_section = get_toml_section("Chunking")
    embeddings_section = get_toml_section("Embeddings")
    embedding_config_section = get_toml_section(
        "embedding_config"
    )  # Get the [embedding_config] table
    chat_dicts_section = get_toml_section("ChatDictionaries")
    auto_save_section = get_toml_section("AutoSave")
    stt_settings_section = get_toml_section("STTSettings")
    tts_settings_section = get_toml_section("TTSSettings")
    search_engines_section = get_toml_section("SearchEngines")
    search_settings_section = get_toml_section("SearchSettings")
    web_scraper_section = get_toml_section("WebScraper")
    confluence_section = get_toml_section("Confluence")
    library_section = get_toml_section("library")

    final_api_settings = get_toml_section("api_settings")
    final_logging_settings = get_toml_section("logging")
    final_providers_settings = get_toml_section("providers")
    final_general_settings_cli = get_toml_section("general")
    final_database_settings_cli = get_toml_section("database")
    final_model_catalog_settings_cli = get_toml_section("model_catalog")
    final_chat_defaults_cli = copy.deepcopy(get_toml_section("chat_defaults"))
    if not isinstance(final_chat_defaults_cli, dict):
        final_chat_defaults_cli = {}
    final_character_defaults_cli = get_toml_section("character_defaults")
    final_notes_settings_cli = get_toml_section("notes")
    # (task 11, spec §9.1/AC 40) The [chunking] table -- the config tier of
    # the ingest template resolution order (``[chunking] default_template``).
    # Distinct from the legacy CamelCase "Chunking" server section above.
    final_chunking_settings_cli = get_toml_section("chunking")
    # (task-34389, ADR-229) The [sync] table -- the sync-journal retention
    # window the startup maintenance pass reads.
    final_sync_settings_cli = get_toml_section("sync")
    final_image_generation_settings_cli = get_toml_section("image_generation")
    final_video_generation_settings_cli = get_toml_section("video_generation")
    # F-E fix: the first-run wizard's own state (setup_started/setup_completed)
    # lives under [first_run] in the raw TOML and was never projected through
    # here -- every other section the app reads via app_config (chat_defaults,
    # notes, console, ...) is listed below, but first_run was simply absent,
    # so should_offer_wizard()/should_show_resume_toast() (which read
    # app_config, populated from THIS function's return value, not the raw
    # loader) never saw a completed/started run and the wizard re-offered on
    # every launch even after real completion.
    final_first_run_settings_cli = get_toml_section("first_run")
    # Console run hooks (spec 2026-09-11, Task 4): the RAW [hooks] table
    # passes through untouched. Same shape as the first_run projection
    # above -- a section only one consumer reads, and that consumer
    # (Agents/run_hooks.py load_hooks_config) re-validates on every fire,
    # so coercing here would only duplicate that logic. Without this
    # projection the runtime could not reach [hooks] at all: the dict
    # returned below is curated, not the parsed TOML.
    final_hooks_settings_cli = get_toml_section("hooks")
    final_console_settings_cli = copy.deepcopy(get_toml_section("console"))
    if not isinstance(final_console_settings_cli, dict):
        final_console_settings_cli = {}
    final_console_settings_cli["collapse_large_pastes"] = coerce_bool_setting(
        final_console_settings_cli.get("collapse_large_pastes", True),
        True,
    )
    final_console_settings_cli["stack_collapsed_rail_labels"] = coerce_bool_setting(
        final_console_settings_cli.get("stack_collapsed_rail_labels", False),
        False,
    )
    from tldw_chatbook.Utils.reasoning_config import resolve_console_reasoning_config

    reasoning_resolution = resolve_console_reasoning_config(final_console_settings_cli)
    for diagnostic in reasoning_resolution.diagnostics:
        logger.warning("Invalid Console reasoning configuration: {}", diagnostic)
    final_console_settings_cli.update(reasoning_resolution.settings.model_dump())
    _rail_layout_scope = final_console_settings_cli.get("rail_layout_scope")
    final_console_settings_cli["rail_layout_scope"] = (
        _rail_layout_scope.strip().lower()
        if isinstance(_rail_layout_scope, str)
        and _rail_layout_scope.strip().lower() in {"global", "workspace"}
        else "global"
    )
    # task-17652: status-row placement relative to the composer. Validation
    # lives in UI/Console_Modules/status_row.resolve_status_chips_position;
    # normalizing here keeps a typo from ever reaching compose order.
    _status_chips_position = final_console_settings_cli.get("status_chips_position")
    if not (
        isinstance(_status_chips_position, str)
        and _status_chips_position.strip().lower() in ("above", "below")
    ):
        _status_chips_position = "above"
    else:
        _status_chips_position = _status_chips_position.strip().lower()
    final_console_settings_cli["status_chips_position"] = _status_chips_position
    final_console_settings_cli["status_chips_collapsed"] = coerce_bool_setting(
        final_console_settings_cli.get("status_chips_collapsed", False),
        False,
    )
    final_console_settings_cli["paste_collapse_threshold"] = coerce_int_setting(
        final_console_settings_cli.get(
            "paste_collapse_threshold",
            DEFAULT_CONSOLE_PASTE_COLLAPSE_THRESHOLD,
        ),
        DEFAULT_CONSOLE_PASTE_COLLAPSE_THRESHOLD,
        minimum=MIN_CONSOLE_PASTE_COLLAPSE_THRESHOLD,
        maximum=MAX_CONSOLE_PASTE_COLLAPSE_THRESHOLD,
    )
    # TASK-870: same coercion shape as paste_collapse_threshold above.
    final_console_settings_cli["tool_result_display_chars"] = coerce_int_setting(
        final_console_settings_cli.get(
            "tool_result_display_chars",
            DEFAULT_CONSOLE_TOOL_RESULT_DISPLAY_CHARS,
        ),
        DEFAULT_CONSOLE_TOOL_RESULT_DISPLAY_CHARS,
        minimum=MIN_CONSOLE_TOOL_RESULT_DISPLAY_CHARS,
        maximum=MAX_CONSOLE_TOOL_RESULT_DISPLAY_CHARS,
    )
    # TASK-18600: the Console agent run budget. Same coercion shape as the
    # two settings above; the two duration keys go through the float twin.
    # Floors only, no ceilings -- these are deliberately user-owned
    # trade-offs (same call as `max_parallel_runs`), and an out-of-range or
    # unparsable value falls back to the shipped default rather than
    # silently clamping to a number the user never chose.
    final_console_settings_cli["agent_max_model_turns"] = coerce_int_setting(
        final_console_settings_cli.get(
            "agent_max_model_turns",
            DEFAULT_CONSOLE_AGENT_MAX_MODEL_TURNS,
        ),
        DEFAULT_CONSOLE_AGENT_MAX_MODEL_TURNS,
        minimum=MIN_CONSOLE_AGENT_MAX_MODEL_TURNS,
    )
    final_console_settings_cli["agent_max_steps"] = coerce_int_setting(
        final_console_settings_cli.get(
            "agent_max_steps",
            DEFAULT_CONSOLE_AGENT_MAX_STEPS,
        ),
        DEFAULT_CONSOLE_AGENT_MAX_STEPS,
        minimum=MIN_CONSOLE_AGENT_MAX_STEPS,
        maximum=MAX_CONSOLE_AGENT_MAX_STEPS,
    )
    final_console_settings_cli["agent_max_wall_seconds"] = coerce_float_setting(
        final_console_settings_cli.get(
            "agent_max_wall_seconds",
            DEFAULT_CONSOLE_AGENT_MAX_WALL_SECONDS,
        ),
        DEFAULT_CONSOLE_AGENT_MAX_WALL_SECONDS,
        minimum=MIN_CONSOLE_AGENT_MAX_WALL_SECONDS,
    )
    final_console_settings_cli["agent_max_total_tokens"] = coerce_int_setting(
        final_console_settings_cli.get(
            "agent_max_total_tokens",
            DEFAULT_CONSOLE_AGENT_MAX_TOTAL_TOKENS,
        ),
        DEFAULT_CONSOLE_AGENT_MAX_TOTAL_TOKENS,
        minimum=MIN_CONSOLE_AGENT_MAX_TOTAL_TOKENS,
    )
    final_console_settings_cli["agent_max_tool_call_seconds"] = coerce_float_setting(
        final_console_settings_cli.get(
            "agent_max_tool_call_seconds",
            DEFAULT_CONSOLE_AGENT_MAX_TOOL_CALL_SECONDS,
        ),
        DEFAULT_CONSOLE_AGENT_MAX_TOOL_CALL_SECONDS,
        minimum=MIN_CONSOLE_AGENT_MAX_TOOL_CALL_SECONDS,
    )
    final_console_settings_cli["local_tools_enabled"] = coerce_bool_setting(
        final_console_settings_cli.get("local_tools_enabled", True),
        True,
    )
    final_console_settings_cli["raw_cli_permitted"] = coerce_bool_setting(
        final_console_settings_cli.get("raw_cli_permitted", False),
        False,
    )
    for key in (
        "project_instructions_startup_max_bytes",
        "project_instructions_nested_max_bytes",
    ):
        final_console_settings_cli[key] = coerce_int_setting(
            final_console_settings_cli.get(
                key, DEFAULT_CONSOLE_PROJECT_INSTRUCTIONS_MAX_BYTES
            ),
            DEFAULT_CONSOLE_PROJECT_INSTRUCTIONS_MAX_BYTES,
            minimum=MIN_CONSOLE_PROJECT_INSTRUCTIONS_MAX_BYTES,
            maximum=MAX_CONSOLE_PROJECT_INSTRUCTIONS_MAX_BYTES,
        )
    workspace_root = final_console_settings_cli.get("workspace_root", "")
    if not isinstance(workspace_root, str):
        workspace_root = ""
    final_console_settings_cli["workspace_root"] = workspace_root.strip()
    # Ephemeral side chat (selection menu): strings need presence-validation
    # only -- non-strings fall back, mirroring workspace_root above.
    sidechat_model = final_console_settings_cli.get("sidechat_model", "")
    if not isinstance(sidechat_model, str):
        sidechat_model = ""
    final_console_settings_cli["sidechat_model"] = sidechat_model.strip()
    sidechat_prompt_template = final_console_settings_cli.get(
        "sidechat_prompt_template", DEFAULT_CONSOLE_SIDECHAT_PROMPT_TEMPLATE
    )
    if not isinstance(sidechat_prompt_template, str):
        sidechat_prompt_template = DEFAULT_CONSOLE_SIDECHAT_PROMPT_TEMPLATE
    final_console_settings_cli["sidechat_prompt_template"] = (
        sidechat_prompt_template.strip()
    )
    background_effects = final_console_settings_cli.get("background_effects")
    if not isinstance(background_effects, dict):
        background_effects = {}
    final_console_settings_cli["background_effects"] = (
        normalize_console_background_effects(background_effects).to_config()
    )

    # --- MCP Settings ---
    final_mcp_settings_cli = copy.deepcopy(get_toml_section("mcp"))
    if not isinstance(final_mcp_settings_cli, dict):
        final_mcp_settings_cli = {}
    for mcp_switch in ("expose_local_tools", "expose_character_tools"):
        final_mcp_settings_cli[mcp_switch] = coerce_bool_setting(
            final_mcp_settings_cli.get(mcp_switch, False),
            False,
        )

    # --- Application Mode ---
    single_user_mode_str = os.getenv(
        "APP_MODE", _get_typed_value(processing_section, "app_mode", "single")
    ).lower()
    single_user_mode = single_user_mode_str != "multi"

    # --- Single-User Settings ---
    single_user_fixed_id = int(
        os.getenv(
            "SINGLE_USER_FIXED_ID",
            _get_typed_value(processing_section, "single_user_fixed_id", "0", int),
        )
    )
    os.getenv(
        "API_KEY",
        _get_typed_value(
            api_section, "single_user_api_key", "default-secret-key-for-single-user"
        ),
    )

    # --- Paths ---
    api_section_legacy = get_toml_section(
        "API"
    )  # For legacy direct API key access if any
    paths_section_legacy = get_toml_section("Paths")
    get_toml_section("Processing")
    get_toml_section("Chunking")

    # --- User Name ---
    default_users_name_fallback = "default_user"
    users_name_from_toml_general = _get_typed_value(
        final_general_settings_cli, "users_name", default_users_name_fallback, str
    )
    users_name = os.getenv("USERS_NAME", users_name_from_toml_general)

    users_db_configured = (
        os.getenv(
            "USERS_DB_ENABLED",
            _get_typed_value(processing_section, "users_db_enabled", "false", str),
        ).lower()
        == "true"
    )
    log_level_env = os.getenv("LOG_LEVEL", "INFO").upper()
    _get_typed_value(logging_section_server, "log_level", log_level_env, str).upper()

    # --- Load specific configurations from TOML or use defaults ---
    app_tts_config = get_toml_section("AppTTSConfig")  # For APP_CONFIG related values
    app_database_config = get_toml_section("AppDatabaseConfig")  # For DATABASE_CONFIG
    app_rag_search_config = get_toml_section(
        "AppRAGSearchConfig"
    )  # For RAG_SEARCH_CONFIG

    # API Keys (Prioritize ENV, then TOML, then None)
    def get_api_key(
        toml_key: str, env_var: str, section: Dict = api_section_legacy
    ) -> Optional[str]:
        return os.getenv(env_var, section.get(toml_key))

    # PR-T2 Task 7: these 9 providers' legacy `[API] <provider>_api_key`
    # value and `api_settings.<provider>.api_key` are resolved together by
    # `_normalize_legacy_provider_api_key` -- ONE normalization -- so
    # `final_api_settings` (below, "api_settings" in config_dict, what
    # `get_provider_readiness` reads) and this same value (below, the
    # `<provider>_api` dicts `chat_with_<provider>` spends through) can
    # never disagree about the same config. `elevenlabs` is untouched: it
    # is a TTS credential, not a Chat provider `get_provider_readiness`
    # resolves.
    _bridged_provider_api_keys = {
        provider_key: _normalize_legacy_provider_api_key(
            final_api_settings,
            provider_key,
            raw_api_section=api_section_legacy,
            toml_key=toml_key,
            env_var=env_var,
        )
        for provider_key, toml_key, env_var in _LEGACY_PROVIDER_API_KEY_BRIDGE
    }
    openai_api_key = _bridged_provider_api_keys["openai"]
    anthropic_api_key = _bridged_provider_api_keys["anthropic"]
    cohere_api_key = _bridged_provider_api_keys["cohere"]
    groq_api_key = _bridged_provider_api_keys["groq"]
    huggingface_api_key = _bridged_provider_api_keys["huggingface"]
    openrouter_api_key = _bridged_provider_api_keys["openrouter"]
    deepseek_api_key = _bridged_provider_api_keys["deepseek"]
    google_api_key = _bridged_provider_api_keys["google"]
    mistral_api_key = _bridged_provider_api_keys["mistral"]
    elevenlabs_api_key = get_api_key("elevenlabs_api_key", "ELEVENLABS_API_KEY")

    # Determine platform-specific default STT provider
    default_stt_provider = _default_stt_provider_for_platform()
    if sys.platform == "darwin":
        logger.debug(
            f"Darwin platform-preferred STT provider resolved to: {default_stt_provider}"
        )

    # TASK-22223: `normalize_adaptive_reader_preferences` comes from the
    # stdlib-only leaf `Utils/adaptive_reader_state.py` (module-top import).
    # This function runs at config-module import (`load_settings()` at module
    # scope), so NOTHING here may import a feature package -- a previous
    # `Library.library_adaptive_reader_state` import claimed to be lazy but
    # executed the whole Library `__init__` service stack on every config
    # import and closed a live cycle through `runtime_policy.bootstrap`.
    # Guarded by `Tests/Packaging/test_config_import_closure.py`; share logic
    # with features through config-safe leaf modules only.
    legacy_media_reader = (
        library_section.get("media_reader", {})
        if isinstance(library_section.get("media_reader"), Mapping)
        else {}
    )
    raw_reader = (
        library_section.get("reader", {})
        if isinstance(library_section.get("reader"), Mapping)
        else {}
    )
    shared_raw = {
        key: os.getenv(
            f"TLDW_LIBRARY_READER_{key.upper()}",
            raw_reader.get(key, legacy_media_reader.get(key)),
        )
        for key in ("library_open", "custom_widths_enabled", "library_width")
    }
    shared_preferences = normalize_adaptive_reader_preferences(shared_raw)
    shared_width = normalize_adaptive_reader_preferences(
        {**shared_raw, "custom_widths_enabled": True}
    ).library_width
    normalized_reader = {
        **copy.deepcopy(raw_reader),
        "library_open": shared_preferences.library_open,
        "custom_widths_enabled": shared_preferences.custom_widths_enabled,
        "library_width": shared_width,
    }
    normalized_destination_readers: dict[str, dict[str, Any]] = {}
    for section_name in (
        "media_reader",
        "collections_reader",
        "conversations_reader",
        "notes_reader",
        "prompts_reader",
        "skills_reader",
        "artifacts_reader",
    ):
        raw_destination = (
            library_section.get(section_name, {})
            if isinstance(library_section.get(section_name), Mapping)
            else {}
        )
        destination_preferences = normalize_adaptive_reader_preferences(
            {
                "custom_widths_enabled": True,
                "items_open": os.getenv(
                    f"TLDW_LIBRARY_{section_name.upper()}_ITEMS_OPEN",
                    raw_destination.get("items_open"),
                ),
                "items_width": os.getenv(
                    f"TLDW_LIBRARY_{section_name.upper()}_ITEMS_WIDTH",
                    raw_destination.get("items_width"),
                ),
            }
        )
        normalized_destination_readers[section_name] = {
            **copy.deepcopy(raw_destination),
            "items_open": destination_preferences.items_open,
            "items_width": destination_preferences.items_width,
        }
        if section_name == "notes_reader":
            files_tree_width = os.getenv(
                "TLDW_LIBRARY_NOTES_READER_FILES_TREE_WIDTH",
                raw_destination.get("files_tree_width"),
            )
            try:
                parsed_files_tree_width = (
                    int(files_tree_width.strip())
                    if isinstance(files_tree_width, str)
                    else files_tree_width
                )
            except ValueError:
                parsed_files_tree_width = ITEMS_TARGET_WIDTH
            if (
                type(parsed_files_tree_width) is not int
                or not ITEMS_MIN_WIDTH <= parsed_files_tree_width <= ITEMS_MAX_WIDTH
            ):
                parsed_files_tree_width = ITEMS_TARGET_WIDTH
            files_tree_preferences = normalize_adaptive_reader_preferences(
                {
                    "custom_widths_enabled": True,
                    "items_open": os.getenv(
                        "TLDW_LIBRARY_NOTES_READER_FILES_TREE_OPEN",
                        raw_destination.get("files_tree_open"),
                    ),
                    "items_width": parsed_files_tree_width,
                }
            )
            normalized_destination_readers[section_name].update(
                {
                    "files_tree_open": files_tree_preferences.items_open,
                    "files_tree_width": files_tree_preferences.items_width,
                }
            )
    config_dict = {
        # General App
        "APP_MODE_STR": single_user_mode_str,
        "SINGLE_USER_MODE": single_user_mode,
        "LOG_LEVEL": final_logging_settings.get("file_log_level", "INFO").upper(),
        "PROJECT_ROOT": ACTUAL_PROJECT_ROOT,
        "API_COMPONENT_ROOT": APP_COMPONENT_ROOT,
        "USERS_NAME": users_name,
        # --- Pass through the full tables ---
        "general": final_general_settings_cli,  # For TUI settings like default_tab
        "logging": final_logging_settings,  # For TUI log settings like log_max_bytes
        "database": final_database_settings_cli,  # For TUI DB paths
        "api_settings": final_api_settings,  # CRUCIAL for local API calls
        "providers": final_providers_settings,  # For UI dropdowns
        "model_catalog": final_model_catalog_settings_cli,
        "chat_defaults": final_chat_defaults_cli,
        "character_defaults": final_character_defaults_cli,
        "appearance": copy.deepcopy(toml_config_data.get("appearance", {})),
        "notes": final_notes_settings_cli,  # For notes auto-save settings
        "chunking": final_chunking_settings_cli,  # Template default for ingest (§9.1)
        "sync": final_sync_settings_cli,  # Sync-journal retention (task-34389, ADR-229)
        "console": final_console_settings_cli,  # For Console behavior settings
        "first_run": final_first_run_settings_cli,  # Wizard setup_started/setup_completed flags
        "hooks": final_hooks_settings_cli,  # Raw [hooks] table for Agents/run_hooks.py (Console run hooks)
        "image_generation": final_image_generation_settings_cli,  # For Image_Generation/config.py loader
        "video_generation": final_video_generation_settings_cli,  # For Video_Generation/config.py loader
        "mcp": final_mcp_settings_cli,  # For MCP server settings
        "persona_buddy": copy.deepcopy(toml_config_data.get("persona_buddy", {})),
        **(
            {"buddy_interaction": copy.deepcopy(toml_config_data["buddy_interaction"])}
            if "buddy_interaction" in toml_config_data
            else {}
        ),
        # [skills] disabled_builtins is read from app_config on every skills
        # read (TASK-32954); without this a disabled built-in returned on restart.
        "skills": copy.deepcopy(toml_config_data.get("skills", {})),
        # [analysis_defaults] is the Library's analysis provider/model/call
        # shape: the Media reader's Generate, bulk Analyze and
        # Analyze-after-import all resolve it from app_config through
        # Library/ingest_analysis.py, and the Media viewer's analysis panel
        # seeds its inputs from it. It was never carried over, so analysis
        # reported "no provider configured" for every user (TASK-34000.5,
        # review finding L-02). Tests/test_config_load_settings_table_guard.py
        # fails on the next table a reader needs that this dict drops.
        "analysis_defaults": copy.deepcopy(
            toml_config_data.get("analysis_defaults", {})
        ),
        # Single User
        "SINGLE_USER_FIXED_ID": single_user_fixed_id,
        # Auth
        "SINGLE_USER_API_KEY": get_api_key(
            "single_user_api_key", "API_KEY", section=api_section_legacy
        )
        or "default-secret-key-for-single-user",
        "DATABASE_URL": os.getenv(
            "DATABASE_URL",
            paths_section_legacy.get(
                "database_url",
                f"sqlite:///{ACTUAL_PROJECT_ROOT / 'user_databases' / 'single_user' / 'tldw.db'}",
            ),
        ),
        "USERS_DB_CONFIGURED": users_db_configured,
        # --- Configurations migrated from load_and_log_configs ---
        "anthropic_api": {
            "api_key": anthropic_api_key,
            "model": api_section_legacy.get("anthropic_model", "claude-sonnet-5"),
            "streaming": api_section_legacy.get("anthropic_streaming", False),
            "temperature": api_section_legacy.get("anthropic_temperature", 0.7),
            "top_p": api_section_legacy.get("anthropic_top_p", 0.95),
            "top_k": api_section_legacy.get("anthropic_top_k", 100),
            "max_tokens": api_section_legacy.get("anthropic_max_tokens", 4096),
            "api_timeout": api_section_legacy.get("anthropic_api_timeout", 90),
            "api_retries": api_section_legacy.get(
                "anthropic_api_retry", 3
            ),  # Key name consistency
            "api_retry_delay": api_section_legacy.get("anthropic_api_retry_delay", 5),
        },
        "cohere_api": {
            "api_key": cohere_api_key,
            "model": api_section_legacy.get("cohere_model", "command-a-03-2025"),
            "streaming": api_section_legacy.get("cohere_streaming", False),
            "temperature": api_section_legacy.get("cohere_temperature", 0.7),
            "max_p": api_section_legacy.get(
                "cohere_max_p", 0.95
            ),  # Note: check param name, Cohere might use 'p' or 'top_p'
            "top_k": api_section_legacy.get("cohere_top_k", 100),
            "max_tokens": api_section_legacy.get("cohere_max_tokens", 4096),
            "api_timeout": api_section_legacy.get("cohere_api_timeout", 90),
            "api_retries": api_section_legacy.get("cohere_api_retry", 3),
            "api_retry_delay": api_section_legacy.get("cohere_api_retry_delay", 5),
        },
        "deepseek_api": {
            "api_key": deepseek_api_key,
            "model": api_section_legacy.get("deepseek_model", "deepseek-v4-flash"),
            "streaming": api_section_legacy.get("deepseek_streaming", False),
            "temperature": api_section_legacy.get("deepseek_temperature", 0.7),
            "top_p": api_section_legacy.get("deepseek_top_p", 0.95),
            "min_p": api_section_legacy.get("deepseek_min_p", 0.05),
            "max_tokens": api_section_legacy.get("deepseek_max_tokens", 4096),
            "api_timeout": api_section_legacy.get("deepseek_api_timeout", 90),
            "api_retries": api_section_legacy.get("deepseek_api_retry", 3),
            "api_retry_delay": api_section_legacy.get("deepseek_api_retry_delay", 5),
        },
        "google_generative_api": {  # Renamed to avoid confusion with Google Search API
            "api_key": google_api_key,
            "model": api_section_legacy.get("google_model", "gemini-2.5-flash"),
            "streaming": api_section_legacy.get("google_streaming", False),
            "temperature": api_section_legacy.get("google_temperature", 0.7),
            "top_p": api_section_legacy.get("google_top_p", 0.95),
            "min_p": api_section_legacy.get(
                "google_min_p", 0.05
            ),  # Check if 'min_p' is valid for Gemini
            "max_tokens": api_section_legacy.get("google_max_tokens", 4096),
            "api_timeout": api_section_legacy.get("google_api_timeout", 90),
            "api_retries": api_section_legacy.get("google_api_retry", 3),
            "api_retry_delay": api_section_legacy.get("google_api_retry_delay", 5),
        },
        "groq_api": {
            "api_key": groq_api_key,
            "model": api_section_legacy.get("groq_model", "llama-3.3-70b-versatile"),
            "streaming": api_section_legacy.get("groq_streaming", False),
            "temperature": api_section_legacy.get("groq_temperature", 0.7),
            "top_p": api_section_legacy.get("groq_top_p", 0.95),
            "max_tokens": api_section_legacy.get("groq_max_tokens", 4096),
            "api_timeout": api_section_legacy.get("groq_api_timeout", 90),
            "api_retries": api_section_legacy.get("groq_api_retry", 3),
            "api_retry_delay": api_section_legacy.get("groq_api_retry_delay", 5),
        },
        "huggingface_api": {
            "api_key": huggingface_api_key,
            "use_router_url_format": api_section_legacy.get(
                "huggingface_use_router_url_format", False
            ),
            "router_base_url": api_section_legacy.get(
                "huggingface_router_base_url",
                "https://router.huggingface.co/hf-inference",
            ),
            "api_base_url": api_section_legacy.get(
                "huggingface_api_base_url", "https://router.huggingface.co/v1"
            ),
            "api_chat_path": api_section_legacy.get(
                "huggingface_api_chat_path", "chat/completions"
            ),
            "model": api_section_legacy.get("huggingface_model", "openai/gpt-oss-120b"),
            "streaming": api_section_legacy.get("huggingface_streaming", False),
            "temperature": api_section_legacy.get("huggingface_temperature", 0.7),
            "top_p": api_section_legacy.get("huggingface_top_p", 0.95),
            "min_p": api_section_legacy.get("huggingface_min_p", 0.05),
            "max_tokens": api_section_legacy.get("huggingface_max_tokens", 4096),
            "api_timeout": api_section_legacy.get("huggingface_api_timeout", 90),
            "api_retries": api_section_legacy.get("huggingface_api_retry", 3),
            "api_retry_delay": api_section_legacy.get("huggingface_api_retry_delay", 5),
        },
        "mistral_api": {
            "api_key": mistral_api_key,
            "model": api_section_legacy.get("mistral_model", "mistral-large-latest"),
            "streaming": api_section_legacy.get("mistral_streaming", False),
            "temperature": api_section_legacy.get("mistral_temperature", 0.7),
            "top_p": api_section_legacy.get("mistral_top_p", 0.95),
            "max_tokens": api_section_legacy.get("mistral_max_tokens", 4096),
            "api_timeout": api_section_legacy.get("mistral_api_timeout", 90),
            "api_retries": api_section_legacy.get("mistral_api_retry", 3),
            "api_retry_delay": api_section_legacy.get("mistral_api_retry_delay", 5),
        },
        "openrouter_api": {
            "api_key": openrouter_api_key,
            "model": api_section_legacy.get(
                "openrouter_model", "microsoft/wizardlm-2-8x22b"
            ),
            "streaming": api_section_legacy.get("openrouter_streaming", False),
            "temperature": api_section_legacy.get("openrouter_temperature", 0.7),
            "top_p": api_section_legacy.get("openrouter_top_p", 0.95),
            "min_p": api_section_legacy.get("openrouter_min_p", 0.05),
            "top_k": api_section_legacy.get("openrouter_top_k", 100),
            "max_tokens": api_section_legacy.get("openrouter_max_tokens", 4096),
            "api_timeout": api_section_legacy.get("openrouter_api_timeout", 90),
            "api_retries": api_section_legacy.get("openrouter_api_retry", 3),
            "api_retry_delay": api_section_legacy.get("openrouter_api_retry_delay", 5),
        },
        "openai_api": {  # OpenAI specific model params, API key is separate
            "api_key": openai_api_key,  # This is now the primary OpenAI API key
            "model": api_section_legacy.get("openai_model", "gpt-5.6-terra"),
            "streaming": api_section_legacy.get("openai_streaming", False),
            "temperature": api_section_legacy.get("openai_temperature", 0.7),
            "top_p": api_section_legacy.get("openai_top_p", 0.95),
            "max_tokens": api_section_legacy.get("openai_max_tokens", 4096),
            "api_timeout": api_section_legacy.get("openai_api_timeout", 90),
            "api_retries": api_section_legacy.get("openai_api_retry", 3),
            "api_retry_delay": api_section_legacy.get("openai_api_retry_delay", 5),
        },
        "elevenlabs_api": {  # Primarily for the API key, other settings in TTS
            "api_key": elevenlabs_api_key,
        },
        # Local APIs from LocalAPI section
        "kobold_api": {
            "api_ip": api_section_legacy.get(
                "kobold_api_IP", "http://127.0.0.1:5000/api/v1/generate"
            ),
            "api_streaming_ip": api_section_legacy.get(
                "kobold_openai_api_IP", "http://127.0.0.1:5001/v1/chat/completions"
            ),
            "api_key": api_section_legacy.get("kobold_api_key", ""),
            "streaming": api_section_legacy.get("kobold_streaming", False),
            "temperature": api_section_legacy.get("kobold_temperature", 0.7),
            "top_p": api_section_legacy.get("kobold_top_p", 0.95),
            "top_k": api_section_legacy.get("kobold_top_k", 100),
            "max_tokens": api_section_legacy.get("kobold_max_tokens", 4096),
            "api_timeout": api_section_legacy.get("kobold_api_timeout", 90),
            "api_retries": api_section_legacy.get("kobold_api_retry", 3),
            "api_retry_delay": api_section_legacy.get("kobold_api_retry_delay", 5),
        },
        "llama_cpp_api": {  # Renamed for clarity, assuming llama.cpp server
            "api_ip": api_section_legacy.get(
                "llama_api_IP", "http://127.0.0.1:8080/v1/chat/completions"
            ),
            "api_key": api_section_legacy.get("llama_api_key", ""),
            "streaming": api_section_legacy.get("llama_streaming", False),
            "temperature": api_section_legacy.get("llama_temperature", 0.7),
            "top_p": api_section_legacy.get("llama_top_p", 0.95),
            "min_p": api_section_legacy.get("llama_min_p", 0.05),
            "top_k": api_section_legacy.get("llama_top_k", 100),
            "max_tokens": api_section_legacy.get("llama_max_tokens", 4096),
            "api_timeout": api_section_legacy.get("llama_api_timeout", 90),
            "api_retries": api_section_legacy.get("llama_api_retry", 3),
            "api_retry_delay": api_section_legacy.get("llama_api_retry_delay", 5),
        },
        "ooba_api": {
            "api_ip": api_section_legacy.get(
                "ooba_api_IP", "http://127.0.0.1:5000/v1/chat/completions"
            ),
            "api_key": api_section_legacy.get("ooba_api_key", ""),
            "streaming": api_section_legacy.get("ooba_streaming", False),
            "temperature": api_section_legacy.get("ooba_temperature", 0.7),
            "top_p": api_section_legacy.get("ooba_top_p", 0.95),
            "min_p": api_section_legacy.get("ooba_min_p", 0.05),
            "top_k": api_section_legacy.get("ooba_top_k", 100),
            "max_tokens": api_section_legacy.get("ooba_max_tokens", 4096),
            "api_timeout": api_section_legacy.get("ooba_api_timeout", 90),
            "api_retries": api_section_legacy.get("ooba_api_retry", 3),
            "api_retry_delay": api_section_legacy.get("ooba_api_retry_delay", 5),
        },
        "tabby_api": {
            "api_ip": api_section_legacy.get(
                "tabby_api_IP", "http://127.0.0.1:5000/api/v1/generate"
            ),
            "api_key": api_section_legacy.get("tabby_api_key", None),
            "model": api_section_legacy.get(
                "tabby_model", None
            ),  # Tabby model might be part of URL or configured in Tabby
            "streaming": api_section_legacy.get("tabby_streaming", False),
            "temperature": api_section_legacy.get("tabby_temperature", 0.7),
            "top_p": api_section_legacy.get("tabby_top_p", 0.95),
            "top_k": api_section_legacy.get("tabby_top_k", 100),
            "min_p": api_section_legacy.get("tabby_min_p", 0.05),
            "max_tokens": api_section_legacy.get("tabby_max_tokens", 4096),
            "api_timeout": api_section_legacy.get("tabby_api_timeout", 90),
            "api_retries": api_section_legacy.get("tabby_api_retry", 3),
            "api_retry_delay": api_section_legacy.get("tabby_api_retry_delay", 5),
        },
        "vllm_api": {
            "api_ip": api_section_legacy.get(
                "vllm_api_IP", "http://127.0.0.1:5000/v1/chat/completions"
            ),  # Corrected key
            "api_key": api_section_legacy.get("vllm_api_key", None),
            "model": api_section_legacy.get("vllm_model", None),
            "streaming": api_section_legacy.get("vllm_streaming", False),
            "temperature": api_section_legacy.get("vllm_temperature", 0.7),
            "top_p": api_section_legacy.get("vllm_top_p", 0.95),
            "top_k": api_section_legacy.get("vllm_top_k", 100),
            "min_p": api_section_legacy.get("vllm_min_p", 0.05),
            "max_tokens": api_section_legacy.get("vllm_max_tokens", 4096),
            "api_timeout": api_section_legacy.get("vllm_api_timeout", 90),
            "api_retries": api_section_legacy.get("vllm_api_retry", 3),
            "api_retry_delay": api_section_legacy.get("vllm_api_retry_delay", 5),
        },
        "ollama_api": {
            "api_url": api_section_legacy.get(
                "ollama_api_IP", "http://127.0.0.1:11434/api/generate"
            ),  # ollama_api_url or IP
            "api_key": api_section_legacy.get(
                "ollama_api_key", None
            ),  # Ollama doesn't typically use API keys
            "model": api_section_legacy.get("ollama_model", None),
            "streaming": api_section_legacy.get("ollama_streaming", False),
            "temperature": api_section_legacy.get("ollama_temperature", 0.7),
            "top_p": api_section_legacy.get("ollama_top_p", 0.95),
            "max_tokens": api_section_legacy.get(
                "ollama_max_tokens", 4096
            ),  # Ollama might handle max_tokens differently (num_predict)
            "api_timeout": api_section_legacy.get("ollama_api_timeout", 90),
            "api_retries": api_section_legacy.get("ollama_api_retry", 3),
            "api_retry_delay": api_section_legacy.get("ollama_api_retry_delay", 5),
        },
        "aphrodite_api": {
            "api_ip": api_section_legacy.get(
                "aphrodite_api_IP", "http://127.0.0.1:8080/v1/chat/completions"
            ),
            "api_key": api_section_legacy.get("aphrodite_api_key", ""),
            "model": api_section_legacy.get("aphrodite_model", ""),
            "max_tokens": api_section_legacy.get("aphrodite_max_tokens", 4096),
            "streaming": api_section_legacy.get("aphrodite_streaming", False),
            "api_timeout": api_section_legacy.get(
                "aphrodite_api_timeout", 90
            ),  # Original used llama_api_timeout
            "api_retries": api_section_legacy.get("aphrodite_api_retry", 3),
            "api_retry_delay": api_section_legacy.get("aphrodite_api_retry_delay", 5),
        },
        "custom_openai_api": {
            "api_ip": api_section_legacy.get(
                "custom_openai_api_ip", "http://127.0.0.1:5000/v1/chat/completions"
            ),
            "api_key": api_section_legacy.get("custom_openai_api_key", None),
            "model": api_section_legacy.get("custom_openai_api_model", None),
            "streaming": api_section_legacy.get("custom_openai_api_streaming", False),
            "temperature": api_section_legacy.get("custom_openai_api_temperature", 0.7),
            "top_p": api_section_legacy.get("custom_openai_api_top_p", 0.95),
            "min_p": api_section_legacy.get(
                "custom_openai_api_min_p", 0.05
            ),  # Original used top_k, ensure consistency
            "max_tokens": api_section_legacy.get("custom_openai_api_max_tokens", 4096),
            "api_timeout": api_section_legacy.get("custom_openai_api_timeout", 90),
            "api_retries": api_section_legacy.get("custom_openai_api_retry", 3),
            "api_retry_delay": api_section_legacy.get(
                "custom_openai_api_retry_delay", 5
            ),
        },
        "custom_openai_api_2": {  # Ensure key names are consistent e.g. custom_openai2_api_min_p
            "api_ip": api_section_legacy.get(
                "custom_openai2_api_ip", "http://127.0.0.1:5000/v1/chat/completions"
            ),
            "api_key": api_section_legacy.get("custom_openai2_api_key", None),
            "model": api_section_legacy.get("custom_openai2_api_model", None),
            "streaming": api_section_legacy.get("custom_openai2_api_streaming", False),
            "temperature": api_section_legacy.get(
                "custom_openai2_api_temperature", 0.7
            ),
            "top_p": api_section_legacy.get(
                "custom_openai2_api_top_p", 0.95
            ),  # original had custom_openai_api2_top_p
            "min_p": api_section_legacy.get(
                "custom_openai2_api_min_p", 0.05
            ),  # original had custom_openai_api2_top_k
            "max_tokens": api_section_legacy.get("custom_openai2_api_max_tokens", 4096),
            "api_timeout": api_section_legacy.get("custom_openai2_api_timeout", 90),
            "api_retries": api_section_legacy.get("custom_openai2_api_retry", 3),
            "api_retry_delay": api_section_legacy.get(
                "custom_openai2_api_retry_delay", 5
            ),
        },
        "llm_api_settings": {  # General LLM settings
            "default_api": api_section_legacy.get("default_api", "openai"),
            "local_api_timeout": api_section_legacy.get(
                "local_api_timeout", 90
            ),  # Note: this was also in Local-API Settings before
            "local_api_retries": api_section_legacy.get(
                "local_api_retry", 3
            ),  # Key name consistency
            "local_api_retry_delay": api_section_legacy.get("local_api_retry_delay", 5),
        },
        "output_path": _get_typed_value(paths_section, "output_path", "results", Path),
        "system_preferences": {
            "save_video_transcripts": _get_typed_value(
                paths_section, "save_video_transcripts", True, bool
            ),
        },
        "processing_choice": _get_typed_value(
            processing_section, "processing_choice", "cpu"
        ),
        "chat_dictionaries": {
            "enable_chat_dictionaries": _get_typed_value(
                chat_dicts_section, "enable_chat_dictionaries", False, bool
            ),
            "post_gen_replacement": _get_typed_value(
                chat_dicts_section, "post_gen_replacement", False, bool
            ),
            "post_gen_replacement_dict": _get_typed_value(
                chat_dicts_section, "post_gen_replacement_dict", ""
            ),
            "chat_dict_chat_prompts": _get_typed_value(
                chat_dicts_section, "chat_dictionary_chat_prompts", ""
            ),
            "chat_dict_RAG_prompts": _get_typed_value(
                chat_dicts_section, "chat_dictionary_RAG_prompts", ""
            ),
            "chat_dict_replacement_strategy": _get_typed_value(
                chat_dicts_section,
                "chat_dictionary_replacement_strategy",
                "character_lore_first",
            ),
            "chat_dict_max_tokens": _get_typed_value(
                chat_dicts_section, "chat_dictionary_max_tokens", 1000, int
            ),
            "default_rag_prompt": _get_typed_value(
                chat_dicts_section, "default_rag_prompt", ""
            ),
            "chat_dicts_folder": "",  # Will be set dynamically below
        },
        "chunking_config": {
            # Global defaults
            "chunking_method": _get_typed_value(
                chunking_section, "chunking_method", "words"
            ),
            "chunk_max_size": _get_typed_value(
                chunking_section, "chunk_max_size", 400, int
            ),
            "chunk_overlap": _get_typed_value(
                chunking_section, "chunk_overlap", 200, int
            ),
            "adaptive_chunking": _get_typed_value(
                chunking_section, "adaptive_chunking", False, bool
            ),
            "multi_level": _get_typed_value(
                chunking_section, "chunking_multi_level", False, bool
            ),
            "chunk_language": _get_typed_value(
                chunking_section, "chunk_language", global_default_chunk_language
            ),  # Use global default
            # Per-type overrides (example for article, repeat for others: audio, book, etc.)
            "article_chunking_method": _get_typed_value(
                chunking_section, "article_chunking_method", "words"
            ),
            "article_chunk_max_size": _get_typed_value(
                chunking_section, "article_chunk_max_size", 400, int
            ),
            "article_chunk_overlap": _get_typed_value(
                chunking_section, "article_chunk_overlap", 200, int
            ),
            "article_adaptive_chunking": _get_typed_value(
                chunking_section, "article_adaptive_chunking", False, bool
            ),
            "article_chunking_multi_level": _get_typed_value(
                chunking_section, "article_chunking_multi_level", False, bool
            ),
            "article_language": _get_typed_value(
                chunking_section, "article_language", "en"
            ),
            "audio_chunking_method": _get_typed_value(
                chunking_section, "audio_chunking_method", "words"
            ),
            "audio_chunk_max_size": _get_typed_value(
                chunking_section, "audio_chunk_max_size", 400, int
            ),
            "audio_chunk_overlap": _get_typed_value(
                chunking_section, "audio_chunk_overlap", 200, int
            ),
            "audio_adaptive_chunking": _get_typed_value(
                chunking_section, "audio_adaptive_chunking", False, bool
            ),
            "audio_chunking_multi_level": _get_typed_value(
                chunking_section, "audio_chunking_multi_level", False, bool
            ),
            "audio_language": _get_typed_value(
                chunking_section, "audio_language", "en"
            ),
            "book_chunking_method": _get_typed_value(
                chunking_section, "book_chunking_method", "ebook_chunk_by_chapter"
            ),
            "book_chunk_max_size": _get_typed_value(
                chunking_section, "book_chunk_max_size", 400, int
            ),
            "book_chunk_overlap": _get_typed_value(
                chunking_section, "book_chunk_overlap", 200, int
            ),
            "book_adaptive_chunking": _get_typed_value(
                chunking_section, "book_adaptive_chunking", False, bool
            ),
            "book_chunking_multi_level": _get_typed_value(
                chunking_section, "book_chunking_multi_level", False, bool
            ),
            "book_language": _get_typed_value(chunking_section, "book_language", "en"),
            "document_chunking_method": _get_typed_value(
                chunking_section, "document_chunking_method", "words"
            ),
            "document_chunk_max_size": _get_typed_value(
                chunking_section, "document_chunk_max_size", 400, int
            ),
            "document_chunk_overlap": _get_typed_value(
                chunking_section, "document_chunk_overlap", 200, int
            ),
            "document_adaptive_chunking": _get_typed_value(
                chunking_section, "document_adaptive_chunking", False, bool
            ),
            "document_chunking_multi_level": _get_typed_value(
                chunking_section, "document_chunking_multi_level", False, bool
            ),
            "document_language": _get_typed_value(
                chunking_section, "document_language", "en"
            ),
            "mediawiki_article_chunking_method": _get_typed_value(
                chunking_section, "mediawiki_article_chunking_method", "words"
            ),
            "mediawiki_article_chunk_max_size": _get_typed_value(
                chunking_section, "mediawiki_article_chunk_max_size", 400, int
            ),
            "mediawiki_article_chunk_overlap": _get_typed_value(
                chunking_section, "mediawiki_article_chunk_overlap", 200, int
            ),
            "mediawiki_article_adaptive_chunking": _get_typed_value(
                chunking_section, "mediawiki_article_adaptive_chunking", False, bool
            ),
            "mediawiki_article_chunking_multi_level": _get_typed_value(
                chunking_section, "mediawiki_article_chunking_multi_level", False, bool
            ),
            "mediawiki_article_language": _get_typed_value(
                chunking_section, "mediawiki_article_language", "en"
            ),
            "mediawiki_dump_chunking_method": _get_typed_value(
                chunking_section, "mediawiki_dump_chunking_method", "words"
            ),
            "mediawiki_dump_chunk_max_size": _get_typed_value(
                chunking_section, "mediawiki_dump_chunk_max_size", 400, int
            ),
            "mediawiki_dump_chunk_overlap": _get_typed_value(
                chunking_section, "mediawiki_dump_chunk_overlap", 200, int
            ),
            "mediawiki_dump_adaptive_chunking": _get_typed_value(
                chunking_section, "mediawiki_dump_adaptive_chunking", False, bool
            ),
            "mediawiki_dump_chunking_multi_level": _get_typed_value(
                chunking_section, "mediawiki_dump_chunking_multi_level", False, bool
            ),
            "mediawiki_dump_language": _get_typed_value(
                chunking_section, "mediawiki_dump_language", "en"
            ),
            "obsidian_note_chunking_method": _get_typed_value(
                chunking_section, "obsidian_note_chunking_method", "words"
            ),
            "obsidian_note_chunk_max_size": _get_typed_value(
                chunking_section, "obsidian_note_chunk_max_size", 400, int
            ),
            "obsidian_note_chunk_overlap": _get_typed_value(
                chunking_section, "obsidian_note_chunk_overlap", 200, int
            ),
            "obsidian_note_adaptive_chunking": _get_typed_value(
                chunking_section, "obsidian_note_adaptive_chunking", False, bool
            ),
            "obsidian_note_chunking_multi_level": _get_typed_value(
                chunking_section, "obsidian_note_chunking_multi_level", False, bool
            ),
            "obsidian_note_language": _get_typed_value(
                chunking_section, "obsidian_note_language", "en"
            ),
            "podcast_chunking_method": _get_typed_value(
                chunking_section, "podcast_chunking_method", "sentences"
            ),
            "podcast_chunk_max_size": _get_typed_value(
                chunking_section, "podcast_chunk_max_size", 300, int
            ),
            "podcast_chunk_overlap": _get_typed_value(
                chunking_section, "podcast_chunk_overlap", 30, int
            ),
            "podcast_adaptive_chunking": _get_typed_value(
                chunking_section, "podcast_adaptive_chunking", False, bool
            ),
            "podcast_chunking_multi_level": _get_typed_value(
                chunking_section, "podcast_chunking_multi_level", False, bool
            ),
            "podcast_language": _get_typed_value(
                chunking_section, "podcast_language", "en"
            ),
            "text_chunking_method": _get_typed_value(
                chunking_section, "text_chunking_method", "words"
            ),
            "text_chunk_max_size": _get_typed_value(
                chunking_section, "text_chunk_max_size", 400, int
            ),
            "text_chunk_overlap": _get_typed_value(
                chunking_section, "text_chunk_overlap", 200, int
            ),
            "text_adaptive_chunking": _get_typed_value(
                chunking_section, "text_adaptive_chunking", False, bool
            ),
            "text_chunking_multi_level": _get_typed_value(
                chunking_section, "text_chunking_multi_level", False, bool
            ),
            "text_language": _get_typed_value(chunking_section, "text_language", "en"),
            "video_chunking_method": _get_typed_value(
                chunking_section, "video_chunking_method", "words"
            ),
            "video_chunk_max_size": _get_typed_value(
                chunking_section, "video_chunk_max_size", 400, int
            ),
            "video_chunk_overlap": _get_typed_value(
                chunking_section, "video_chunk_overlap", 200, int
            ),
            "video_adaptive_chunking": _get_typed_value(
                chunking_section, "video_adaptive_chunking", False, bool
            ),
            "video_chunking_multi_level": _get_typed_value(
                chunking_section, "video_chunking_multi_level", False, bool
            ),
            "video_language": _get_typed_value(
                chunking_section, "video_language", "en"
            ),
        },
        "embedding_config": {
            "embedding_provider": _get_typed_value(
                embeddings_section, "embedding_provider", "openai"
            ),
            "embedding_model": _get_typed_value(
                embeddings_section, "embedding_model", "text-embedding-3-large"
            ),
            "onnx_model_path": _get_typed_value(
                embeddings_section,
                "onnx_model_path",
                "./Models/onnx_models/text-embedding-3-small.onnx",
                Path,
            ),
            "model_dir": _get_typed_value(
                embeddings_section, "model_dir", "./Models", Path
            ),
            "embedding_api_url": _get_typed_value(
                embeddings_section,
                "embedding_api_url",
                "http://localhost:8080/v1/embeddings",
            ),
            "embedding_api_key": _get_typed_value(
                embeddings_section, "embedding_api_key", ""
            ),
            "chunk_size": _get_typed_value(
                embeddings_section, "chunk_size", 400, int
            ),  # This was 'chunk_size' in old Embeddings, also in Chunking
            "chunk_overlap": _get_typed_value(
                embeddings_section, "overlap", 200, int
            ),  # This was 'overlap' in old Embeddings
            "models": embedding_config_section.get(
                "models", {}
            ),  # Include the models from the embedding_config section
        },
        "auto_save": {
            "save_character_chats": _get_typed_value(
                auto_save_section, "save_character_chats", False, bool
            ),
            "save_rag_chats": _get_typed_value(
                auto_save_section, "save_rag_chats", False, bool
            ),
        },
        "STT_settings": {  # Corrected key from STT-Settings
            "default_stt_provider": _get_typed_value(
                stt_settings_section, "default_stt_provider", default_stt_provider
            ),
        },
        "tts_settings": {
            "default_tts_provider": _get_typed_value(
                tts_settings_section, "default_tts_provider", "openai"
            ),
            "tts_voice": _get_typed_value(
                tts_settings_section, "default_tts_voice", "shimmer"
            ),  # General default voice
            "local_tts_device": _get_typed_value(
                tts_settings_section, "local_tts_device", "cpu"
            ),
            # OpenAI TTS
            "default_openai_tts_model": _get_typed_value(
                tts_settings_section, "default_openai_tts_model", "tts-1-hd"
            ),
            "default_openai_tts_voice": _get_typed_value(
                tts_settings_section, "default_openai_tts_voice", "shimmer"
            ),
            "default_openai_tts_speed": _get_typed_value(
                tts_settings_section, "default_openai_tts_speed", 1.0, float
            ),
            "default_openai_tts_output_format": _get_typed_value(
                tts_settings_section, "default_openai_tts_output_format", "mp3"
            ),
            "default_openai_tts_streaming": _get_typed_value(
                tts_settings_section, "default_openai_tts_streaming", False, bool
            ),
            # Google TTS
            "default_google_tts_model": _get_typed_value(
                tts_settings_section, "default_google_tts_model", "en"
            ),  # FIXME: Review defaults
            "default_google_tts_voice": _get_typed_value(
                tts_settings_section, "default_google_tts_voice", "en"
            ),  # FIXME: Review defaults
            "default_google_tts_speed": _get_typed_value(
                tts_settings_section, "default_google_tts_speed", 1.0, float
            ),  # FIXME: Review defaults
            # ElevenLabs TTS
            "default_eleven_tts_model": _get_typed_value(
                tts_settings_section,
                "default_eleven_tts_model",
                "eleven_multilingual_v2",
            ),  # FIXME: Placeholder
            "default_eleven_tts_voice": _get_typed_value(
                tts_settings_section, "default_eleven_tts_voice", "Rachel"
            ),  # FIXME: Placeholder
            "default_eleven_tts_language_code": _get_typed_value(
                tts_settings_section, "default_eleven_tts_language_code", "en-US"
            ),  # FIXME
            "default_eleven_tts_voice_stability": _get_typed_value(
                tts_settings_section, "default_eleven_tts_voice_stability", 0.5, float
            ),  # FIXME
            "default_eleven_tts_voice_similiarity_boost": _get_typed_value(
                tts_settings_section,
                "default_eleven_tts_voice_similiarity_boost",
                0.75,
                float,
            ),  # FIXME
            "default_eleven_tts_voice_style": _get_typed_value(
                tts_settings_section, "default_eleven_tts_voice_style", 0.0, float
            ),  # FIXME
            "default_eleven_tts_voice_use_speaker_boost": _get_typed_value(
                tts_settings_section,
                "default_eleven_tts_voice_use_speaker_boost",
                True,
                bool,
            ),  # FIXME
            "default_eleven_tts_output_format": _get_typed_value(
                tts_settings_section,
                "default_eleven_tts_output_format",
                "mp3_44100_192",
            ),
            # AllTalk TTS (from load_and_log_configs, now integrated)
            "alltalk_api_ip": _get_typed_value(
                tts_settings_section,
                "alltalk_api_ip",
                "http://127.0.0.1:7851/v1/audio/speech",
            ),
            "default_alltalk_tts_model": _get_typed_value(
                tts_settings_section, "default_alltalk_tts_model", "alltalk_model"
            ),
            "default_alltalk_tts_voice": _get_typed_value(
                tts_settings_section, "default_alltalk_tts_voice", "alloy"
            ),
            "default_alltalk_tts_speed": _get_typed_value(
                tts_settings_section, "default_alltalk_tts_speed", 1.0, float
            ),
            "default_alltalk_tts_output_format": _get_typed_value(
                tts_settings_section, "default_alltalk_tts_output_format", "mp3"
            ),
            # Kokoro TTS
            "kokoro_model_path": _get_typed_value(
                tts_settings_section,
                "kokoro_model_path",
                "Databases/kokoro_models",
                Path,
            ),
            "default_kokoro_tts_model": _get_typed_value(
                tts_settings_section, "default_kokoro_tts_model", "pht"
            ),
            "default_kokoro_tts_voice": _get_typed_value(
                tts_settings_section, "default_kokoro_tts_voice", "sky"
            ),
            "default_kokoro_tts_speed": _get_typed_value(
                tts_settings_section, "default_kokoro_tts_speed", 1.0, float
            ),
            "default_kokoro_tts_output_format": _get_typed_value(
                tts_settings_section, "default_kokoro_tts_output_format", "wav"
            ),
            # Self-hosted OpenAI API TTS
            "default_openai_api_tts_model": _get_typed_value(
                tts_settings_section, "default_openai_api_tts_model", "tts-1-hd"
            ),
            "default_openai_api_tts_voice": _get_typed_value(
                tts_settings_section, "default_openai_api_tts_voice", "shimmer"
            ),
            "default_openai_api_tts_speed": _get_typed_value(
                tts_settings_section, "default_openai_api_tts_speed", 1.0, float
            ),  # Was '1' string
            "default_openai_api_tts_output_format": _get_typed_value(
                tts_settings_section, "default_openai_api_tts_output_format", "mp3"
            ),  # key was default_openai_tts_api_output_format
            "default_openai_api_tts_streaming": _get_typed_value(
                tts_settings_section, "default_openai_api_tts_streaming", False, bool
            ),
        },
        "search_settings_general": {  # Renamed from 'search_settings' to avoid conflict with SearchEngines section for keys
            "default_search_provider": _get_typed_value(
                search_settings_section, "search_provider_default", "duckduckgo"
            ),
            "search_language_query": _get_typed_value(
                search_settings_section, "search_language_query", "en"
            ),
            "search_language_analysis": _get_typed_value(
                search_settings_section, "search_language_analysis", "en"
            ),
            "search_default_max_queries": _get_typed_value(
                search_settings_section, "search_default_max_queries", 5, int
            ),
            "search_enable_subquery": _get_typed_value(
                search_settings_section, "search_enable_subquery", False, bool
            ),
            "search_enable_subquery_count_max": _get_typed_value(
                search_settings_section, "search_enable_subquery_count_max", 3, int
            ),
            "search_result_rerank": _get_typed_value(
                search_settings_section, "search_result_rerank", False, bool
            ),
            "search_result_max": _get_typed_value(
                search_settings_section, "search_result_max", 10, int
            ),
            "search_result_max_per_query": _get_typed_value(
                search_settings_section, "search_result_max_per_query", 10, int
            ),
            "search_result_blacklist": _get_typed_value(
                search_settings_section, "search_result_blacklist", ""
            ),
            "search_result_display_type": _get_typed_value(
                search_settings_section, "search_result_display_type", "text"
            ),
            "search_result_display_metadata": _get_typed_value(
                search_settings_section, "search_result_display_metadata", True, bool
            ),
            "search_result_save_to_db": _get_typed_value(
                search_settings_section, "search_result_save_to_db", True, bool
            ),
            "search_result_analysis_tone": _get_typed_value(
                search_settings_section, "search_result_analysis_tone", "neutral"
            ),
            "relevance_analysis_llm": _get_typed_value(
                search_settings_section, "relevance_analysis_llm", "openai"
            ),
            "final_answer_llm": _get_typed_value(
                search_settings_section, "final_answer_llm", "openai"
            ),
            "relevance_llm_timeout_s": _get_int_timeout_value(
                search_settings_section, "relevance_llm_timeout_s", 30
            ),
            "relevance_scrape_timeout_s": _get_int_timeout_value(
                search_settings_section, "relevance_scrape_timeout_s", 30
            ),
            # 240 default (task-1356 review ruling). Fix round 1: this key
            # is NOT required to stay under the agent runtime's 300s
            # max_tool_call_seconds (Agents/agent_models.py RunBudget.
            # max_tool_call_seconds) -- the runtime automatically allots the
            # web_deep_search tool its own per-call timeout of this value
            # plus ~50s slack (wait_for grace + thread-join + scheduling
            # jitter) via LocalToolProvider.timeout_for, so a deadline-hit
            # deep search can still return its partial synthesis instead of
            # being killed by the outer tool-call ceiling first, for any
            # value an operator sets here.
            "deep_search_timeout_s": _get_int_timeout_value(
                search_settings_section, "deep_search_timeout_s", 240
            ),
        },
        "search_engine_specific_settings": {  # API Keys for various search engines from 'SearchEngines' TOML table
            "baidu_search_api_key": _get_typed_value(
                search_engines_section, "baidu_search_api_key", ""
            ),
            "bing_country_code": _get_typed_value(
                search_engines_section, "bing_country_code", ""
            ),
            "bing_search_api_url": _get_typed_value(
                search_engines_section, "bing_search_api_url", ""
            ),
            "brave_country_code": _get_typed_value(
                search_engines_section, "brave_country_code", ""
            ),
            "google_search_api_url": _get_typed_value(
                search_engines_section, "google_search_api_url", ""
            ),
            "google_search_engine_id": _get_typed_value(
                search_engines_section, "google_search_engine_id", ""
            ),
            "google_simp_trad_chinese": _get_typed_value(
                search_engines_section, "google_simp_trad_chinese", False, bool
            ),
            "limit_google_search_to_country": _get_typed_value(
                search_engines_section, "limit_google_search_to_country", False, bool
            ),
            "google_search_country": _get_typed_value(
                search_engines_section, "google_search_country", ""
            ),
            "google_search_country_code": _get_typed_value(
                search_engines_section, "google_search_country_code", ""
            ),
            "google_search_filter_setting": _get_typed_value(
                search_engines_section, "google_filter_setting", ""
            ),
            "google_user_geolocation": _get_typed_value(
                search_engines_section, "google_user_geolocation", False, bool
            ),
            "google_ui_language": _get_typed_value(
                search_engines_section, "google_ui_language", ""
            ),
            "google_limit_search_results_to_language": _get_typed_value(
                search_engines_section,
                "google_limit_search_results_to_language",
                False,
                bool,
            ),
            "google_site_search_include": _get_typed_value(
                search_engines_section, "google_site_search_include", ""
            ),
            "google_site_search_exclude": _get_typed_value(
                search_engines_section, "google_site_search_exclude", ""
            ),
            "google_sort_results_by": _get_typed_value(
                search_engines_section, "google_sort_results_by", ""
            ),
            "google_default_search_results": _get_typed_value(
                search_engines_section, "google_default_search_results", 10, int
            ),
            "google_safe_search": _get_typed_value(
                search_engines_section, "google_safe_search", False, bool
            ),
            "google_enable_site_search": _get_typed_value(
                search_engines_section, "google_enable_site_search", False, bool
            ),
            "yandex_search_engine_id": _get_typed_value(
                search_engines_section, "yandex_search_engine_id", ""
            ),
        },
        "search_engines_keys": {  # API Keys for various search engines from 'SearchEngines' TOML table
            "baidu_search_api_key": _get_typed_value(
                search_engines_section, "search_engine_api_key_baidu", ""
            ),
            "bing_search_api_key": _get_typed_value(
                search_engines_section, "bing_search_api_key", ""
            )
            or _get_typed_value(
                search_engines_section, "search_engine_api_key_bing", ""
            ),
            "brave_search_api_key": _get_typed_value(
                search_engines_section, "brave_search_api_key", ""
            ),
            "brave_search_ai_api_key": _get_typed_value(
                search_engines_section, "brave_search_ai_api_key", ""
            ),
            "duckduckgo_search_api_key": _get_typed_value(
                search_engines_section, "duckduckgo_search_api_key", ""
            ),
            "google_search_api_key": _get_typed_value(
                search_engines_section, "google_search_api_key", ""
            ),
            "kagi_search_api_key": _get_typed_value(
                search_engines_section, "kagi_search_api_key", ""
            ),
            "searx_search_api_url": _get_typed_value(
                search_engines_section, "searx_search_api_url", ""
            )
            or _get_typed_value(search_engines_section, "search_engine_searx_api", ""),
            "tavily_search_api_key": _get_typed_value(
                search_engines_section, "tavily_search_api_key", ""
            ),
            "serper_search_api_key": _get_typed_value(
                search_engines_section, "serper_search_api_key", ""
            ),
            "exa_search_api_key": _get_typed_value(
                search_engines_section, "exa_search_api_key", ""
            ),
            "yandex_search_api_key": _get_typed_value(
                search_engines_section, "yandex_search_api_key", ""
            ),
            "yandex_search_folder_id": _get_typed_value(
                search_engines_section, "yandex_search_folder_id", ""
            ),
        },
        # NOTE: the former "prompts_strings" loader was removed once the
        # Internal_Prompts registry took over these web-search prompts. Its
        # only consumer was the unused CONFIG_PROMPT_SITUATE_CHUNK_CONTEXT
        # constant. The [Prompts] TOML keys themselves remain — the registry
        # reads them as its legacy-override tier (via legacy_config_path).
        "web_scraper_settings": {
            "web_scraper_api_key": _get_typed_value(
                web_scraper_section, "web_scraper_api_key", ""
            ),
            "web_scraper_api_url": _get_typed_value(
                web_scraper_section, "web_scraper_api_url", ""
            ),
            # ... (all web scraper settings)
        },
        "confluence": {
            "base_url": _get_typed_value(
                confluence_section, "base_url", os.getenv("CONFLUENCE_BASE_URL", "")
            ),
            "auth_method": _get_typed_value(
                confluence_section,
                "auth_method",
                os.getenv("CONFLUENCE_AUTH_METHOD", "api_token"),
            ),
            "username": _get_typed_value(
                confluence_section, "username", os.getenv("CONFLUENCE_USERNAME", "")
            ),
            "api_token": _get_typed_value(
                confluence_section, "api_token", os.getenv("CONFLUENCE_API_TOKEN", "")
            ),
            "oauth_token": _get_typed_value(
                confluence_section,
                "oauth_token",
                os.getenv("CONFLUENCE_OAUTH_TOKEN", ""),
            ),
            "password": _get_typed_value(
                confluence_section, "password", os.getenv("CONFLUENCE_PASSWORD", "")
            ),
            "browser": _get_typed_value(confluence_section, "browser", "all"),
            "space_keys": _get_typed_value(confluence_section, "space_keys", [], list),
            "max_pages_per_space": _get_typed_value(
                confluence_section, "max_pages_per_space", 100, int
            ),
            "max_crawl_depth": _get_typed_value(
                confluence_section, "max_crawl_depth", 5, int
            ),
            "include_attachments": _get_typed_value(
                confluence_section, "include_attachments", False, bool
            ),
            "follow_links": _get_typed_value(
                confluence_section, "follow_links", False, bool
            ),
            "rate_limit_delay": _get_typed_value(
                confluence_section, "rate_limit_delay", 0.5, float
            ),
        },
        # Configurations from hardcoded dicts (now from TOML or fallback to Python dicts)
        "APP_TTS_CONFIG": {**DEFAULT_APP_TTS_CONFIG, **app_tts_config},
        "APP_DATABASE_CONFIG": {**DEFAULT_DATABASE_CONFIG, **app_database_config},
        "APP_RAG_SEARCH_CONFIG": {**DEFAULT_RAG_SEARCH_CONFIG, **app_rag_search_config},
        "acp": get_toml_section("acp"),
        "permission_summary": get_toml_section("permission_summary"),
        "library": {
            **copy.deepcopy(library_section),
            "ingest_directory_scan_limit": coerce_int_setting(
                library_section.get("ingest_directory_scan_limit", 1000),
                1000,
                minimum=1,
            ),
            # (TASK-19556) Opt-in, OFF by default: see the [library] block in
            # the default TOML below for why a link check is not free.
            "ingest_url_preflight_probe": coerce_bool_setting(
                library_section.get("ingest_url_preflight_probe", False),
                False,
            ),
            "ingest_options": library_section.get("ingest_options", {})
            if isinstance(library_section.get("ingest_options"), dict)
            else {},
            "reader": normalized_reader,
            **normalized_destination_readers,
        },
        "COMPREHENSIVE_CONFIG_RAW": toml_config_data,  # Store the raw TOML data if needed
        "OPENAI_API_KEY": openai_api_key,  # Top-level convenience access
    }

    # Bridge TTSSettings defaults into APP_TTS_CONFIG for runtime use
    # This ensures TTS event handlers can find the user's selected defaults
    if "default_provider" not in config_dict["APP_TTS_CONFIG"]:
        config_dict["APP_TTS_CONFIG"]["default_provider"] = config_dict[
            "tts_settings"
        ].get("default_tts_provider", "openai")
    if "default_voice" not in config_dict["APP_TTS_CONFIG"]:
        config_dict["APP_TTS_CONFIG"]["default_voice"] = config_dict[
            "tts_settings"
        ].get("default_tts_voice", "alloy")
    if "default_model" not in config_dict["APP_TTS_CONFIG"]:
        config_dict["APP_TTS_CONFIG"]["default_model"] = config_dict[
            "tts_settings"
        ].get("default_openai_tts_model", "tts-1")
    if "default_format" not in config_dict["APP_TTS_CONFIG"]:
        config_dict["APP_TTS_CONFIG"]["default_format"] = config_dict[
            "tts_settings"
        ].get("default_openai_tts_output_format", "mp3")
    if "default_speed" not in config_dict["APP_TTS_CONFIG"]:
        config_dict["APP_TTS_CONFIG"]["default_speed"] = config_dict[
            "tts_settings"
        ].get("default_openai_tts_speed", 1.0)

    # Populate the rest of chunking_config (tedious but necessary)
    chunking_types = [
        "audio",
        "book",
        "document",
        "mediawiki_article",
        "mediawiki_dump",
        "obsidian_note",
        "podcast",
        "text",
        "video",
    ]
    for ctype in chunking_types:
        # Use direct defaults from chunking_section or hardcoded fallbacks
        default_method = _get_typed_value(chunking_section, "chunking_method", "words")
        default_max_size = _get_typed_value(
            chunking_section, "chunk_max_size", 400, int
        )
        default_overlap = _get_typed_value(chunking_section, "chunk_overlap", 200, int)
        default_adaptive = _get_typed_value(
            chunking_section, "adaptive_chunking", False, bool
        )
        default_multi_level = _get_typed_value(
            chunking_section, "chunking_multi_level", False, bool
        )
        default_language = _get_typed_value(
            chunking_section, "chunk_language", global_default_chunk_language
        )

        # Only set if not already defined in lines 494-562
        if f"{ctype}_chunking_method" not in config_dict["chunking_config"]:
            config_dict["chunking_config"][f"{ctype}_chunking_method"] = (
                _get_typed_value(
                    chunking_section, f"{ctype}_chunking_method", default_method
                )
            )
        if f"{ctype}_chunk_max_size" not in config_dict["chunking_config"]:
            config_dict["chunking_config"][f"{ctype}_chunk_max_size"] = (
                _get_typed_value(
                    chunking_section, f"{ctype}_chunk_max_size", default_max_size, int
                )
            )
        if f"{ctype}_chunk_overlap" not in config_dict["chunking_config"]:
            config_dict["chunking_config"][f"{ctype}_chunk_overlap"] = _get_typed_value(
                chunking_section, f"{ctype}_chunk_overlap", default_overlap, int
            )
        if f"{ctype}_adaptive_chunking" not in config_dict["chunking_config"]:
            config_dict["chunking_config"][f"{ctype}_adaptive_chunking"] = (
                _get_typed_value(
                    chunking_section,
                    f"{ctype}_adaptive_chunking",
                    default_adaptive,
                    bool,
                )
            )
        if f"{ctype}_chunking_multi_level" not in config_dict["chunking_config"]:
            config_dict["chunking_config"][f"{ctype}_chunking_multi_level"] = (
                _get_typed_value(
                    chunking_section,
                    f"{ctype}_chunking_multi_level",
                    default_multi_level,
                    bool,
                )
            )
        if f"{ctype}_language" not in config_dict["chunking_config"]:
            config_dict["chunking_config"][f"{ctype}_language"] = _get_typed_value(
                chunking_section, f"{ctype}_language", default_language
            )

    # Set the chat dictionaries folder path dynamically
    from .Utils.paths import get_user_data_dir

    chat_dicts_folder = (
        get_user_data_dir()
        if bootstrap.succeeded
        else profile_paths.user_data_dir(toml_config_data)
    ) / "chat_dicts"
    config_dict["chat_dictionaries"]["chat_dicts_folder"] = str(chat_dicts_folder)

    # Create the chat dictionaries folder if it doesn't exist. task-32901:
    # a umask-derived mkdir lands 0775 on umask-002 machines and the very
    # next boot's admission check refuses it; the private lifecycle creates
    # 0700 and hardens an existing 0775 instance in place.
    try:
        if bootstrap.succeeded:
            with _config_participants.operation(
                sys.modules[__name__],
                route="config_chat_dicts",
                target=chat_dicts_folder,
            ):
                secure_private_directory(
                    chat_dicts_folder, create=True, application_owned=True
                )
        logger.debug(f"Ensured chat dictionaries folder exists: {chat_dicts_folder}")
    except RecoveryRequired:
        raise
    except PrivatePathError as e:
        # task-32901: a pre-existing shared-writable instance (pre-fix
        # umask-002 machines) is refused by the admission pre-check before
        # the hardened create above can repair it; name the exact repair,
        # reason-gated and shell-safe (see private_path_repair_hint).
        repair = private_path_repair_hint(e)
        suffix = f" Repair once with: {repair}" if repair else ""
        logger.error(
            f"Could not create chat dictionaries folder {chat_dicts_folder}: {e}.{suffix}"
        )
    except Exception as e:
        logger.error(
            f"Could not create chat dictionaries folder {chat_dicts_folder}: {e}"
        )

    if bootstrap.succeeded:
        if posture and posture[-1] is None:
            # The file was missing when stamped and this load's bootstrap
            # created it: stamp what now exists, or every fresh profile pays a
            # second rebuild. A file that existed keeps its pre-read stamp, so
            # a mid-read swap still misses (Qodo, #2903).
            created = _config_file_posture(active_config_path)
            if _is_plain_owned_file(created):
                posture = created
        with _SETTINGS_CACHE_LOCK:
            _SETTINGS_CACHE = config_dict
            _SETTINGS_CACHE_SOURCE = active_config_path
            _SETTINGS_CACHE_POSTURE = posture
            logger.debug("load_settings: Configuration cached for future use")

    return config_dict


# --- Define API Models (Combined Cloud & Local) ---
# (Keep your existing API_MODELS_BY_PROVIDER and LOCAL_PROVIDERS dictionaries)
API_MODELS_BY_PROVIDER = {
    "OpenAI": [
        "gpt-5.6-terra",
        "gpt-5.6-sol",
        "gpt-5.6-luna",
        "gpt-4.1-2025-04-14",
        "o4-mini-2025-04-16",
        "o3-2025-04-16",
        "o3-mini-2025-01-31",
        "o1-2024-12-17",
        "chatgpt-4o-latest",
        "gpt-4o-2024-11-20",
        "gpt-4o-2024-08-06",
        "gpt-4.1-mini-2025-04-14",
        "gpt-4.1-nano-2025-04-14",
        "gpt-4o-mini-2024-07-18",
    ],
    "Anthropic": [
        "claude-sonnet-5",
        "claude-opus-5",
        "claude-fable-5",
        "claude-haiku-4-5",
        "claude-opus-4-20250514",
        "claude-sonnet-4-20250514",
        "claude-3-7-sonnet-20250219",
        "claude-3-5-sonnet-20241022",
        "claude-3-5-haiku-20241022",
        "claude-3-5-sonnet-20240620",
        "claude-3-haiku-20240307",
        "claude-3-opus-20240229",
        "claude-3-sonnet-20240229",
        "claude-2.1",
        "claude-2.0",
    ],
    "Cohere": [
        "command-a-03-2025",
        "command-r7b-12-2024",
        "command-r-plus-04-2024",
        "command-r-plus",
        "command-r-08-2024",
        "command-r-03-2024",
        "command",
        "command-nightly",
        "command-light",
        "command-light-nightly",
    ],
    "DeepSeek": ["deepseek-v4-flash", "deepseek-v4-pro"],
    "Groq": [
        "gemma2-9b-it",
        "mmeta-llama/Llama-Guard-4-12B",
        "llama-3.3-70b-versatile",
        "llama-3.1-8b-instant",
        "llama3-70b-8192",
        "llama3-70b-8192",
        "llama3-8b-8192",
    ],
    "Google": [
        "gemini-2.5-flash",
        "gemini-2.5-flash-preview-05-20",
        "gemini-2.5-pro-preview-05-06",
        "gemini-2.0-flash",
        "gemini-2.0-flash-lite",
        "gemini-1.5-flash",
        "gemini-1.5-flash-8b",
        "gemini-1.5-pro",
    ],
    "HuggingFace": [
        "openai/gpt-oss-120b",
        "meta-llama/Meta-Llama-3.1-8B-Instruct",
        "meta-llama/Meta-Llama-3.1-70B-Instruct",
    ],
    "MistralAI": [
        "open-mistral-nemo",
        "mistral-medium-2505",
        "codestral-2501",
        "mistral-saba-2502",
        "mistral-large-2411",
        "ministral-3b-2410",
        "ministral-8b-2410",
        "mistral-moderation-2411",
        "devstral-small-2505",
        "mistral-small-2503",
    ],
    "OpenRouter": [
        "openai/gpt-4o-mini",
        "anthropic/claude-3.7-sonnet",
        "google/gemini-2.0-flash-001",
        "google/gemini-2.5-pro-preview",
        "google/gemini-2.5-flash-preview",
        "deepseek/deepseek-chat-v3-0324:free",
        "deepseek/deepseek-chat-v3-0324",
        "openai/gpt-4.1",
        "anthropic/claude-sonnet-4",
        "deepseek/deepseek-r1:free",
        "anthropic/claude-3.7-sonnet:thinking",
        "google/gemini-flash-1.5-8b",
        "mistralai/mistral-nemo",
        "google/gemini-2.5-flash-preview-05-20",
    ],
}
LOCAL_PROVIDERS = {
    "llama_cpp": ["None"],
    "Oobabooga": ["None"],
    "koboldcpp": ["None"],
    "Ollama": [
        "gemma3:12b",
        "gemma3:4b",
        "gemma3:27b",
        "qwen3:4b",
        "qwen3:8b",
        "qwen3:14b",
        "qwen3:30b",
        "qwen3:32b",
        "qwen3:235b",
        "devstral:24b",
        "deepseek-r1:671b",
    ],
    "vLLM": ["vllm-model-z", "vllm-model-x", "vllm-model-y", "vllm-model-a"],
    "TabbyAPI": ["tabby-model", "tabby-model-2", "tabby-model-3"],
    "Aphrodite": ["aphrodite-engine", "aphrodite-engine-2"],
    "Custom": ["custom-model-alpha", "custom-model-beta"],
    "Custom-2": ["custom-model-gamma", "custom-model-delta"],
}

#######################################################################################################################
# --- CLI User Configuration Section ---
#######################################################################################################################

# --- Configuration File Content (for reference or auto-creation for the CLI) ---
CONFIG_TOML_CONTENT = """
# Configuration for tldw-chatbook TUI App
# Located at: ~/.config/tldw_cli/config.toml
config_schema_version = 1  # TASK-26040: config schema version; migrated forward on load
[general]
default_tab = "chat"  # "chat", "character", "logs", "media", "search", "ingest", "stats"
focus_mode = false  # Start the Console chrome-free (no nav bar / workbench header; one-line status bar kept)
default_theme = "textual-dark"  # Default theme on startup ("textual-dark", "textual-light", or any theme name from themes.py)
palette_theme_limit = 1  # Maximum number of themes to show in command palette (0 = show all)
log_level = "INFO" # TUI Log Level: DEBUG, INFO, WARNING, ERROR, CRITICAL
users_name = "default_user" # Default user name for the TUI
# How long shutdown may take (Textual unmount + interpreter teardown) before a
# hard exit is forced. Clamped to 1-300 seconds. A quiet exit measures ~0.6s,
# so this deadline is never reached by a normal quit.
# NOTE: it is enforced against healthy work too. A background job still
# running when you quit -- media ingest, notes/character export, library
# export, an embedding batch -- runs on a thread that cannot be interrupted.
# If it is still going 120 seconds after you quit, the process is killed and
# that job's database write is abandoned (not rolled back to a clean earlier
# state -- simply lost). Raise this if you routinely quit while long jobs are
# running; lower it only if you would rather lose such a write than wait.
shutdown_grace_seconds = 120.0

[console]
collapse_large_pastes = true  # Display large pasted chunks compactly in Console composer
# Custom endpoints (ADR-146): execute the openai_compatible family through
# the strict hosted engine (custom-hosted execution key) instead of the
# legacy custom handlers. Set false to roll back to the legacy path
# (ADR-179 Phase 2 kill switch); identity, readiness, saved sessions, and
# the [api_settings.custom] fallbacks are identical either way.
custom_endpoints_use_engine = true
show_model_thinking = true  # Presentation only; capture and replay are unchanged
thinking_history_policy_default = "auto"  # auto, include, exclude for new conversations
# Environment overrides: TLDW_CONSOLE_REASONING_HISTORY (mode), and JSON maps in
# TLDW_CONSOLE_REASONING_HISTORY_OVERRIDES / TLDW_CONSOLE_REASONING_NATIVE_TOOL_OVERRIDES.
reasoning_history = "auto"  # local replay when a conversation uses Auto: auto, current, all, off
reasoning_history_overrides = {}  # normalized endpoint/model digest -> replay mode
reasoning_native_tool_overrides = {}  # normalized endpoint/model digest -> true
stack_collapsed_rail_labels = false  # Use compact stacked labels on collapsed Console rails
rail_layout_scope = "global"  # Share Console rail disclosure across workspaces; use "workspace" for per-workspace layouts
assistant_library_access_default = false  # New Console sessions block assistant Library access
paste_collapse_threshold = 50  # Collapse pasted/inserted chunks only when longer than this many characters
local_tools_enabled = true      # workspace, web, and Watchlists agent tools; every call still uses MCP Ask/Allow/Off permissions
interrupt_bell = true           # Ring the terminal bell when an agent blocks on you (approval, confirm, question) while Console is not the visible screen; the Console nav badge shows regardless. Environment override: TLDW_CONSOLE_INTERRUPT_BELL
# ask_user_timeout_seconds = 0  # ask_user question card auto-continue: 0 (default) waits for an answer indefinitely; e.g. 120 continues the run without an answer after 120s. Environment override: TLDW_CONSOLE_ASK_USER_TIMEOUT_SECONDS
raw_cli_permitted = false       # Persisted unlock only; every app launch still starts unarmed
# Root-source byte limit; allowed range is 1-1048576 (1 MiB).
project_instructions_startup_max_bytes = 32768
# Cumulative nested-source byte limit per dispatch; allowed range is 1-1048576 (1 MiB).
project_instructions_nested_max_bytes = 32768
# Conversation-memory defaults (ADR-052). Model capacity remains capability data,
# not a persisted policy value.
conversation_budget_mode = "automatic"  # automatic, custom
# conversation_budget_tokens = 32000     # required only when mode = custom
compaction_mode = "ask"                  # ask, automatic, off
compaction_representation = "text_summary"  # text_summary, visual_transcript, hybrid
compaction_trigger_ratio = 0.80
compaction_target_ratio = 0.55
compaction_summary_max_tokens = 1024
compaction_auxiliary_timeout_seconds = 120  # wall-clock bound on the summarizer call; invalid/<=0 falls back to 120
compaction_native_delegation = false     # TASK-26021: delegate compaction to a provider's server-side compact where the gateway advertises it (no bridged provider does yet); any failure falls back to the local summarizer call
micro_compaction_every_turns = 0         # TASK-25910: in AUTOMATIC mode, fold the oldest exchange into memory every N completed turns (0 = off; bounds prompt-cache breaks to 1/N of turns)
compaction_failure_behavior = "stop_and_ask"  # stop_and_ask, omit_older_context
compaction_carry_forward_mode = "memory_with_recent_turns"  # memory_with_recent_turns, memory_with_latest_exchange
# Root for local MCP serving and operator Hub tool tests. Blank uses that
# serving process's current working directory. This is NOT Console file
# authority: Console uses Chat scratch and admitted Workspace folders
# (ADR-082/102). Existing sensitive-path and permission checks still apply.
# workspace_root = ""

# Agent run budget (Settings > Console Behavior > Agent run budget).
# Applies to ONE run = one user message; sub-agents inherit turns/steps/tokens
# unchanged (their wall comes from [agents] child_max_wall_seconds instead).
# agent_max_total_tokens is the limit that actually stops a long run: the whole
# conversation is re-sent every turn, so spend grows quadratically and 25M is
# typically reached around turn 250. The turn and step caps are backstops.
agent_max_model_turns = 2000        # Provider turns (tool-calling rounds) per message
agent_max_steps = 25000             # Step backstop; a fence tool round costs 3 steps
agent_max_wall_seconds = 86400.0    # 24h ceiling on one run; Stop always works
agent_max_total_tokens = 25000000   # Per-run prompt+completion spend ceiling; 0 = unlimited
agent_max_tool_call_seconds = 3600.0  # Ceiling on ONE tool call; 0 = unlimited
# Ephemeral side chat (selection menu) — empty model = session model
sidechat_model = ""  # e.g. "openai/gpt-5-mini"; empty = follow the current session's model
sidechat_prompt_template = "Give me more details about: {selection}"  # {selection} = the quoted text
# Conversation Inspector: capture each provider exchange (request/response)
# locally per turn. Local-only; never synced. Set false to disable.
exchange_capture = true
# Independent rollout/rollback gates for the normalized semantic trace ledger.
# Environment overrides use TLDW_CONSOLE_TRACE_NORMALIZED_WRITES,
# TLDW_CONSOLE_TRACE_NORMALIZED_READS, and TLDW_CONSOLE_TRACE_LEGACY_WRITES.
trace_normalized_writes = true
trace_normalized_reads = true
trace_legacy_writes = false
# Same-file VACUUM is admitted only after successful trace GC and every gate.
trace_compaction_min_database_bytes = 67108864
trace_compaction_min_freelist_bytes = 16777216
trace_compaction_min_freelist_ratio = 0.20
trace_compaction_min_idle_seconds = 30.0
trace_compaction_retry_initial_seconds = 300.0
trace_compaction_retry_max_seconds = 3600.0
trace_compaction_quiesce_timeout_seconds = 5.0
trace_compaction_disk_safety_margin_bytes = 67108864
# Retired future-write detail retained only for legacy provenance/migration.
exchange_capture_detail = "safe"
# Optional capture-time PII masking is independent of capture and defaults Off.
exchange_capture_pii_redaction = false
# Safe/Full is a viewer disclosure choice over one trace, never storage detail.
trace_viewer_profile = "safe"
trace_viewer_profile_version = 1

[console.background_effects]
enabled = false  # Optional Console ambience. Off by default for readability.
effect = "none"  # none, snow, rain, matrix
scope = "transcript"  # transcript, workbench
intensity = "low"  # low, medium, high
fps = 6  # 1-12

[console_ssh]
# SSH ControlMaster lifecycle for remote workspace bindings (spec
# 2026-09-24-ssh-remote-workspace-bindings). `control_persist` rides the
# `ssh -MNf` master command verbatim (OpenSSH duration like "10m"/"45s"/"4h";
# it is the crash backstop that self-expires an orphaned master).
control_persist = "10m"
# Kill switch for connection multiplexing: false = per-call direct
# connections, no master, no ControlPath (also the Windows posture, where
# ssh.exe lacks ControlMaster).
enable_multiplexing = true
# Bounds both the master spawn handshake and per-call connects, in seconds.
connect_timeout_s = 3
# Cap on in-flight per-binding ssh calls (consumed by the transport executor).
max_concurrent_calls = 8
# Per-run SSH session worker: one long-lived channel per binding per Console
# run instead of one ssh exchange per call. false = pure one-shot.
session_worker = true
# Seconds a session worker may sit idle before it closes (both sides).
session_idle_s = 60
# Let the host cache the worker bundle in $XDG_RUNTIME_DIR (tmpfs, 0700,
# sha256-verified on every load; skipped when that directory is absent).
bundle_cache = true

[hooks]
enabled = true  # master switch for Console run hooks (external commands on session/run lifecycle events)
# [[hooks.hook]] entries: event / matcher / command / timeout_s
# event: UserPromptSubmit | PreToolUse | PostToolUse | ApprovalRequested | Stop | SubagentStop
# matcher: tool-name glob, valid only on PreToolUse/PostToolUse
# command: argv list, no shell — e.g. ["/usr/local/bin/guard.sh", "--strict"]
# timeout_s: per-hook ceiling in seconds (default 10); PreToolUse fails closed on timeout

# [[hooks.handler]] entries are explicit v2 declarations, independently validated.
# id/event/type/effects are required; command type uses argv, env and optional cwd.
# MCP type uses server, tool and optional typed input template. See ADR-163.

[skills]
# project_skills_prompt_enabled = true  # offer .SKILLS/ import at startup; spec 2026-08-17
# disabled_builtins = []  # built-in skills to hide, e.g. ["character-creator"]

[tamagotchi]
enabled = false  # opt-in virtual pet in the footer status bar; off unless you ask for it
# Write a TOML boolean. The gate is fail-closed: anything it cannot read as
# true/yes/1 (or their negatives) -- including "on" -- leaves the pet off.
# name = "Bit"  # 1-20 chars, letters/digits/space/-/_ only
# personality = "balanced"  # balanced, energetic, lazy, needy, independent, playful
# State lives in ~/.config/tldw_chatbook/tamagotchi_pets.json (backed up by the
# "tamagotchi.config" backup/recovery owner). Nothing is created while disabled.

[appearance]
character_expression_mode = "dynamic"  # Dynamic animates character expressions; Static changes poses without motion
density = "normal"  # compact, normal, or comfortable default control density
animations_enabled = true  # Enable optional UI animations where supported
smooth_scrolling = true  # Enable smooth scrolling where supported
reduce_motion = false  # Render animations as static frames (splash screen, Console setup backdrop)
ascii_glyphs = false  # Substitute ASCII status markers for unicode glyphs (narrow-font terminals)
console_transcript_style = "role_accents"  # neutral, role_accents, or immersive_rp

[acp.runtime]
# ACP owns runtime launch/setup. Leave command empty to keep ACP honestly blocked.
command = ""
args = []
cwd = ""
runtime_id = "local-acp-runtime"
runtime_label = "Local ACP Runtime"
runtime_version = ""
startup_timeout_seconds = 2.0

[tldw_api]
base_url = "http://127.0.0.1:8000" # Or your actual default remote endpoint
# Default auth token can be stored here, or leave empty if user must always provide
auth_token = "default-secret-key-for-single-user"

[library]
# Maximum files scanned when analysing a directory for Library ingestion.
ingest_directory_scan_limit = 1000
# Check a staged ingest URL by fetching its headers before the import runs.
# OFF by default (TASK-19556). A link check is not free: it contacts the host
# before you have asked for anything to be imported, and it used to run from
# the ingest field's typing debounce, which turned a pasted link into a probe
# of whatever the address pointed at -- including hosts on your own network.
# With this on, the check runs only from the deliberate triggers (leaving the
# field, pressing Enter, Browse..., the retry button), never while you type;
# it is routed through the [web_security] egress policy, follows no
# redirects, and reports one identical "could not be checked" note for every
# address the policy declines. A link that cannot actually be fetched is
# still reported by the import job itself, with a real reason.
ingest_url_preflight_probe = false
# Parallel ingest parse workers. Default: min(3, cpu-1). Uncomment to override.
# ingest_parse_workers = 3
# Max concurrent heavy (audio/video transcription) parses; document parses fan
# out past this cap to fill the remaining pool workers. Default: 1.
# ingest_heavy_lane_max_workers = 1

[library.reader]
# Shared Library-pane visibility and width are written here by Settings and
# Library pane toggles. Older configs may omit these keys; each missing key
# independently falls back to its legacy value under [library.media_reader].
# Environment overrides use TLDW_LIBRARY_READER_<KEY>.

[library.media_reader]
# Destination Items-pane preferences. The three shared keys below remain as
# read-only compatibility fallbacks for older config files.
# Items environment overrides use TLDW_LIBRARY_MEDIA_READER_<KEY>.
library_open = true
items_open = true
custom_widths_enabled = false
# Compatibility fallback for fresh profiles; matches LIBRARY_REFERENCE_WIDTH.
library_width = 36
items_width = 50

[library.collections_reader]
# Environment overrides use TLDW_LIBRARY_COLLECTIONS_READER_<KEY>.
items_open = true
items_width = 50

[library.conversations_reader]
# Environment overrides use TLDW_LIBRARY_CONVERSATIONS_READER_<KEY>.
items_open = true
items_width = 50

[library.notes_reader]
# Items environment overrides use TLDW_LIBRARY_NOTES_READER_ITEMS_<KEY>.
# Folder-tree overrides use TLDW_LIBRARY_NOTES_READER_FILES_TREE_<KEY>.
items_open = true
items_width = 50
files_tree_open = true
files_tree_width = 50

[library.prompts_reader]
# Environment overrides use TLDW_LIBRARY_PROMPTS_READER_<KEY>.
items_open = true
items_width = 50

[library.skills_reader]
# Environment overrides use TLDW_LIBRARY_SKILLS_READER_<KEY>.
items_open = true
items_width = 50

[library.artifacts_reader]
# Local artifacts share Library visibility; Items preferences belong here.
# Environment overrides use TLDW_LIBRARY_ARTIFACTS_READER_<KEY>.
items_open = true
items_width = 50

# Per-type ingestion options are persisted here by the Library ingest canvas.
[library.ingest_options]

[caching]
# Anthropic prompt caching (cache_control breakpoints on the system prompt and
# the tool list for every Anthropic call; plus one on the latest message for
# Console sends only, which are the multi-turn ones). Cache writes bill at
# 1.25x input and reads at ~0.1x, so multi-turn chat wins after two sends
# inside the 5-minute TTL.
# The loss condition: sends more than ~5 minutes apart never hit a live cache,
# so every send re-pays the 1.25x write premium on the conversation prefix
# with no reads at all -- the cost ticker will show it (writes in the
# breakdown, no cache-read line). Set false if that is your usage pattern.
# Set false to disable the cache_control breakpoints this client adds;
# caller-supplied native Anthropic tool dicts already carrying cache_control
# still pass through verbatim.
anthropic_enabled = true
# TASK-26014: cache TTL tier -- "5m" (default) or "1h". 1h keeps the prefix
# cached across a coffee break so a returning conversation is not re-billed
# the 1.25x write premium, but a 1h write bills ~2x vs 5m's 1.25x, so it
# wins only when gaps routinely exceed 5 minutes. Unsupported models and any
# unrecognized value fall back to 5m silently; the kill switch above
# disables this along with everything else.
cache_ttl = "5m"
# TASK-26015: send OpenAI/Codex a stable prompt_cache_key derived from the
# conversation's stable prefix (system prompt + tools) so the provider can
# route repeated prefixes to the same implicit-cache node. It is a digest,
# never content; unknown to providers that ignore it (harmless). OFF by
# default = today's request shape exactly.
openai_cache_key = false

[agents]
# Sub-agent fleet knobs. Every key here is COMMENTED OUT on purpose: the
# authoritative defaults live in `Agents/agent_service.py`
# (DEFAULT_MAX_LIVE_SUBAGENTS / DEFAULT_CHILD_MAX_WALL_SECONDS /
# DEFAULT_SUBAGENTS_OUTLIVE_TURN / DEFAULT_AUTOWAKE_ENABLED), and shipping a live copy here would give
# the same value two homes that can silently drift apart. Uncomment a line
# to override. See Docs/User_Guide/console/agent-runs-and-tools.md.
#
# How many sub-agents of ONE conversation may run at once, counting any
# still working from an earlier message. 1 disables the fleet (sub-agents
# run inline, one at a time). The conversation cap is also subject to the
# shared runtime cap below.
# max_live_subagents = 3
#
# Shared child execution slots across this Console runtime, including inline
# children and cleanup still running after a child is marked terminal.
# Automatic work may occupy four of six; manual/queued work can use all six.
# max_runtime_subagents = 6
# reserved_manual_subagents = 2
#
# Local tool workers shared across all conversations in this Console runtime.
# A timed-out worker keeps its slot until it really exits. Automatic wakes
# may occupy six of the default eight slots; two remain for manual work.
# Defaults are owned by Agents/execution_capacity.py. Read before admission;
# lowering a limit does not cancel already admitted work.
# max_runtime_tool_workers = 8
# reserved_manual_tool_workers = 2
#
# Whether a sub-agent may keep working after the reply that spawned it has
# finished. false settles every sub-agent at the end of its own turn.
# subagents_outlive_turn = true
#
# How long ONE background sub-agent may keep working, in seconds. Checked
# between the child's own steps, so it does not interrupt a provider call
# already in flight.
# child_max_wall_seconds = 1800.0
#
# Stop one run after a fully settled batch leaves this many consecutive
# authoritative tool denials. The default is 3; 0 disables the breaker.
# denial_circuit_breaker_limit = 3  # Consecutive denied calls; 0 disables.
# TLDW_AGENTS_DENIAL_CIRCUIT_BREAKER_LIMIT overrides this value for Console runs.
#
# TASK-25911: deterministic stale tool-result pruning on the agent send
# payload -- big old tool outputs shrink to a bounded head plus a note,
# with no LLM call. OFF by default; the thresholds below are the shipped
# defaults when enabled. min_reclaim keeps prompt-cache breaks episodic.
# prune_stale_tool_results = false
# prune_keep_recent_turns = 4   # counts ROUNDS at the agent seam (one model call + its results), not conversational turns
# prune_min_result_chars = 4000
# prune_head_chars = 1000
# prune_min_reclaim_chars = 8000
#
# TASK-25912: replace image payloads in OLDER turns of the agent send
# payload with text placeholders (~1600 tokens back per image). The
# stored conversation is untouched. OFF by default.
# retire_stale_images = false
# retire_images_keep_recent_turns = 4
#
# Whether a background sub-agent finishing after its turn WAKES its
# supervisor so it can act on the result (an injected, clearly machine-
# marked notice -- never user input, never approval). false still records
# every completion (toast, badge, durable mark); the wake turn just never
# fires.
# autowake_enabled = true
# Goal policy cannot replenish an existing immutable launch allowance.
# goal_runs_enabled = false
# max_goal_generations = 3
# max_goal_model_calls = 32
# max_goal_budget_tokens = 500000
# max_goal_output_tokens = 8192
# max_goal_wall_seconds = 900
#
# --- Sub-agent routing (ADR-147) ---
# Default provider/model for spawned sub-agents when neither the spawn call
# nor the named agent preset routes them. Empty = inherit the parent's.
# subagent_default_provider = ""
# subagent_default_model = ""
#
# Let the supervisor model pass ad-hoc provider/model args to
# spawn_subagent. Off by default: routing then comes only from presets and
# the default above. Ad-hoc args never carry URLs or sampling params.
# spawn_override_enabled = false
#
# Ad-hoc targets the supervisor may pick. One entry per list item: a
# provider id ("llama_cpp", "custom-ep:qwen-local") or "provider/model-glob"
# ("llama_cpp/qwen3.8-*"). Presets are user-authored and never gated.
# spawn_override_allowlist = []

[splash_screen]
# Splash screen configuration for startup animations
# See Docs/Examples/SPLASH_SCREENS_CATALOG.md for all available splash screens
enabled = true  # Enable/disable splash screen
duration = __DEFAULT_SPLASH_DURATION__  # Duration in seconds to display splash screen
skip_on_keypress = true  # Allow users to skip with any keypress

# Card selection mode:
# - "random": Randomly selects from active_cards list (default)
# - "sequential": Cycles through active_cards in order (not yet implemented)
# - "<card_name>": Always use a specific card (e.g., "matrix", "glitch", etc.)
card_selection = "random"

show_progress = true  # Show initialization progress bar

# List of splash cards to use when card_selection is "random"
# Full catalog of 40+ cards available - see documentation for descriptions
# Categories:
#   Static: default, classic, compact, minimal, blueprint
#   Classic Animated: matrix, glitch, retro, typewriter
#   Visual Effects: tech_pulse, code_scroll, arcade_high_score, digital_rain, loading_bar, starfield
#   Interactive: terminal_boot, glitch_reveal, ascii_morph, game_of_life, scrolling_credits, spotlight_reveal
#   Creative: sound_bars, raindrops_pond, pixel_zoom, text_explosion, old_film, maze_generator, dwarf_fortress
#   Tech-Themed: neural_network, quantum_particles, ascii_wave, binary_matrix, constellation_map, circuit_trace
#   More: typewriter_news, dna_sequence, plasma_field, ascii_fire, rubiks_cube, data_stream, fractal_zoom, 
#         ascii_spinner, hacker_terminal
active_cards = [
    "default", "matrix", "glitch", "retro", "classic", "compact", "minimal",
    "tech_pulse", "code_scroll", "minimal_fade", "blueprint", "arcade_high_score",
    "digital_rain", "loading_bar", "starfield", "terminal_boot", "glitch_reveal",
    "ascii_morph", "game_of_life", "scrolling_credits", "spotlight_reveal", "sound_bars",
    "spy_vs_spy", "phonebooths", "emoji_face",
    "ascii_aquarium", "bookshelf_browser", "train_journey", "clock_mechanism",
    "weather_system", "music_visualizer", "origami_folding", "ant_colony",
    "neon_sign_flicker", "zen_garden"
    # Note: "custom_image" is not included by default as it requires user configuration
]

[splash_screen.effects]
# Animation effect settings
fade_in_duration = 0.3  # Fade in time in seconds
fade_out_duration = 0.2  # Fade out time in seconds
animation_speed = 1.0  # Animation playback speed multiplier

custom_image_path = ""  # Set path to your image file for custom_image splash screen

[session_summary]
# Optional quit-time session usage summary (issue #365).
# After a confirmed quit (Ctrl+Q), briefly show total session tokens and
# elapsed session time before the app exits. Any key skips it.
enabled = false  # Show the summary on quit (default off)
duration_seconds = 3  # Auto-dismiss delay in seconds (clamped to 1..30)

[logging]
# Log file will be placed in the same directory as the chachanotes_db_path below.
log_filename = "tldw_cli_app.log"
file_log_level = "INFO" # File Log Level: DEBUG, INFO, WARNING, ERROR, CRITICAL
log_max_bytes = 10485760 # 10 MB
log_backup_count = 5

[metrics]
# Prometheus metrics listener. OFF by default: having the optional
# `prometheus_client` dependency installed (the `dev` and `debugging` extras
# both pull it in) is not consent to open a network socket.
# Metric collection itself is unaffected by this setting -- it only controls
# whether an HTTP endpoint is exposed for scraping.
enabled = false
# Bind address. Loopback by default; prometheus_client's own default is
# 0.0.0.0, which would expose the endpoint to your whole network.
bind_address = "127.0.0.1"
# 9090 is the Prometheus convention. 8000 is already taken by [web_server].
port = 9090

[database]
# scheduled_tasks_db_path = "/custom/path.db"  # optional override
# tts_profiles_db_path = "/custom/path.db"  # optional override
# Path to the ChaChaNotes (Character, Chat, Notes) database.
chachanotes_db_path = "~/.local/share/tldw_cli/tldw_chatbook_ChaChaNotes.db"
# Path to the Prompts database.
prompts_db_path = "~/.local/share/tldw_cli/tldw_cli_prompts.db"
# Path to the Media V2 database.
media_db_path = "~/.local/share/tldw_cli/tldw_cli_media_v2.db"
# Path to the local research sessions/runs database.
research_db_path = "~/.local/share/tldw_cli/tldw_chatbook_research.db"
# Path to the local writing suite database.
writing_db_path = "~/.local/share/tldw_cli/tldw_chatbook_writing.db"
# Path to the local Library Collections database.
library_collections_db_path = "~/.local/share/tldw_cli/tldw_chatbook_library_collections.db"
# Path to the local Workspaces database.
workspaces_db_path = "~/.local/share/tldw_cli/tldw_chatbook_workspaces.db"
# Path to the Evals database.
evals_db_path = "~/.local/share/tldw_cli/evals.db"
# Path to the RAG indexing-state database (rag_indexing.db; tracks
# incremental RAG indexing state -- it is not a vector store).
rag_indexing_db_path = "~/.local/share/tldw_cli/rag_indexing.db"
# Path to the Subscriptions database.
subscriptions_db_path = "~/.local/share/tldw_cli/tldw_chatbook_subscriptions.db"
USER_DB_BASE_DIR = "~/.local/share/tldw_cli/"

# Database integrity checking
check_integrity_on_startup = false  # Enable/disable automatic integrity checks on startup
integrity_check_timeout = 30  # Maximum seconds to wait for integrity check

[webhooks]
# TASK-26031: outbound signed webhooks for agent run lifecycle events. OFF by
# default -- with no url configured, no request is ever made. Payloads carry
# identifiers + an outcome category only (never message content, tool args, or
# credentials) and are signed X-Tldw-Signature: sha256=HMAC-SHA256(secret,body).
# The destination is subject to the SSRF egress policy ([web_security]): a
# localhost/LAN url (e.g. a local dashboard) is blocked by default and needs
# its host added to [web_security] allowed_hosts to be delivered to.
enabled = false
url = ""            # e.g. "https://your-dashboard.example/hooks/tldw"
secret = ""         # shared secret the receiver uses to verify the signature
# Which lifecycle events to POST. Omit to subscribe to all supported events.
events = ["completed", "failed"]
timeout_seconds = 5.0   # bounded; a slow/dead endpoint never delays the run

[scheduling]
# Background sync and scheduler defaults for the scheduling module.
sync_interval_seconds = 300
sync_retry_max_attempts = 10
sync_retry_max_delay_seconds = 300
sync_retry_jitter = true
scheduler_poll_interval_seconds = 30
# A dispatch more than this many seconds after its scheduled time counts as
# late and is recorded on the task (missed_at/missed_count, task-18937).
# Default is 2x the poll interval: an idle scheduler dispatches within one
# poll. Beyond 2x has several possible causes and the row cannot tell them
# apart (task-19562): the scheduler was not running at the scheduled time
# (app closed), the machine slept or the loop was starved while the app
# stayed open, or the scheduler was busy -- tick awaits every due handler
# serially, so a slow handler holds the loop and pushes the NEXT poll past
# the grace. The loop logs which it was and counts it as
# scheduler_dispatch_late with a cause label (away / stalled / busy). A
# task created mid-session reloads the queue immediately, so that case does
# not false-positive here.
missed_fire_grace_seconds = 60
# Handler execution timeout (task-18939): a scheduled-task handler still
# running after this many seconds is cancelled and its dispatch records
# "timed_out" -- the schedule advances, so a wedged handler (e.g. a hung
# watchlist URL check) can never wedge the whole scheduler. 0 or negative
# disables the bound; a reminder's own timeout_seconds column overrides
# this per task (same semantics: <=0 disables for that task).
handler_timeout_seconds = 300
reminder_catchup_hours = 24
# Feature flags for the watchlist-to-unified-scheduler migration (ADR-019).
# Both were staged for a shadow-mode dual-run against the legacy SubscriptionScheduler.
# That scheduler is gone, so shadow mode has nothing to compare against and leaving
# these at their staging values meant nothing ever checked a watchlist (TASK-1210).
watchlist_checks_enabled = true   # Run watchlist checks on their configured cadence
# Diagnostics only: fetch but DISCARD results, ignoring cadence. Shadow mode probes
# feed and url/url_list sources directly; it CANNOT probe sitemap or api sources,
# which need the execution path it exists to avoid, and reports those as
# "shadow_unsupported" rather than pretending they were checked (TASK-1383).
watchlist_checks_shadow = false
# Run each watchlist's own briefing on its configured cadence
# (`watchlists.briefing_cadence_seconds`, opt-in per watchlist, NULL/unset
# means never -- briefings phase 4, Locked Decision 4). Only fires while
# the app is open; a schedule spends the user's own LLM tokens unattended,
# so this is the one flag that turns that on at all.
briefing_schedules_enabled = true
# Dismiss the Watchlists "daily brief demo" banner permanently.
daily_report_demo_banner_dismissed = false

[media_cleanup]
# Media cleanup settings for automatic hard deletion of soft-deleted items
enabled = true  # Enable/disable automatic cleanup
cleanup_days = 30  # Number of days after soft deletion before hard deletion
cleanup_interval_hours = 24  # How often to run cleanup (in hours)
cleanup_on_startup = true  # Run cleanup check on application startup
max_items_per_cleanup = 100  # Maximum items to delete in one cleanup run
notify_before_cleanup = true  # Show notification before performing cleanup

[api_endpoints]
# Optional: Specify URLs for local/custom endpoints if they differ from library defaults
# These keys should match the provider names used in the app (adjust if needed)
llama_cpp = "http://localhost:8080" # Check if your API provider uses this address
koboldcpp = "http://localhost:5001/api" # Check if your API provider uses this address
Oobabooga = "http://localhost:5000/api" # Check if your API provider uses this address
Ollama = "http://localhost:11434"
vLLM = "http://localhost:8000" # Check if your API provider uses this address
Custom = "http://localhost:1234/v1"
Custom_2 = "http://localhost:5678/v1"
Custom_3 = "http://localhost:5678/v1"
Custom_4 = "http://localhost:5678/v1"
Custom_5 = "http://localhost:5678/v1"
Custom_6 = "http://localhost:5678/v1"

# Add other local URLs if needed

[providers]
# This section primarily lists providers and their *available* models for the UI dropdown.
# Actual default model/settings used for calls are defined in [api_settings.*] or [chat_defaults]/[character_defaults].
OpenAI = ["gpt-5.6-terra", "gpt-5.6-sol", "gpt-5.6-luna", "gpt-4.1-2025-04-14", "o4-mini-2025-04-16", "o3-2025-04-16", "o3-mini-2025-01-31", "o1-2024-12-17", "chatgpt-4o-latest", "gpt-4o-2024-11-20", "gpt-4o-2024-08-06", "gpt-4.1-mini-2025-04-14", "gpt-4.1-nano-2025-04-14", "gpt-4o-mini-2024-07-18", ]
Anthropic = ["claude-sonnet-5", "claude-opus-5", "claude-fable-5", "claude-haiku-4-5", "claude-opus-4-20250514", "claude-sonnet-4-20250514", "claude-3-7-sonnet-20250219", "claude-3-5-sonnet-20241022", "claude-3-5-haiku-20241022", "claude-3-5-sonnet-20240620", "claude-3-haiku-20240307", "claude-3-opus-20240229", "claude-3-sonnet-20240229", "claude-2.1", "claude-2.0"]
Cohere = ["command-a-03-2025", "command-r7b-12-2024", "command-r-plus-04-2024", "command-r-plus", "command-r-08-2024", "command-r-03-2024", "command", "command-nightly", "command-light", "command-light-nightly"]
DeepSeek = ["deepseek-v4-flash", "deepseek-v4-pro"]
Groq = ["gemma2-9b-it", "mmeta-llama/Llama-Guard-4-12B", "llama-3.3-70b-versatile", "llama-3.1-8b-instant", "llama3-70b-8192", "llama3-70b-8192", "llama3-8b-8192",]
Google = ["gemini-2.5-flash", "gemini-2.5-flash-preview-05-20", "gemini-2.5-pro-preview-05-06", "gemini-2.0-flash", "gemini-2.0-flash-lite", "gemini-1.5-flash", "gemini-1.5-flash-8b", "gemini-1.5-pro", ]
HuggingFace = ["openai/gpt-oss-120b", "meta-llama/Meta-Llama-3.1-8B-Instruct", "meta-llama/Meta-Llama-3.1-70B-Instruct",]
MistralAI = ["open-mistral-nemo", "mistral-medium-2505", "codestral-2501", "mistral-saba-2502", "mistral-large-2411", "ministral-3b-2410", "ministral-8b-2410", "mistral-moderation-2411", "devstral-small-2505", "mistral-small-2503", ]
Moonshot = ["kimi-k3", "kimi-latest", "kimi-thinking-preview", "moonshot-v1-auto", "moonshot-v1-8k", "moonshot-v1-32k", "moonshot-v1-128k", "moonshot-v1-8k-vision-preview", "moonshot-v1-32k-vision-preview", "moonshot-v1-128k-vision-preview", "kimi-k2-0711-preview"]
OpenRouter = ["openai/gpt-4o-mini", "anthropic/claude-3.7-sonnet", "google/gemini-2.0-flash-001", "google/gemini-2.5-pro-preview", "google/gemini-2.5-flash-preview", "deepseek/deepseek-chat-v3-0324:free", "deepseek/deepseek-chat-v3-0324", "openai/gpt-4.1", "anthropic/claude-sonnet-4", "deepseek/deepseek-r1:free", "anthropic/claude-3.7-sonnet:thinking", "google/gemini-flash-1.5-8b", "mistralai/mistral-nemo", "google/gemini-2.5-flash-preview-05-20", ]
QwenCloud = ["qwen3.8-max"]
ZAI = ["glm-5.2", "glm-4.6", "glm-4.5", "glm-4.5-air", "glm-4.5-flash", "glm-4.5v", "glm-4-32b-0414-128k"]
Databricks = [] # Empty: model availability is workspace-dependent; fills via discovery or manual seeding
# Inference clouds (ADR-179 Phase 2): engine presets with no per-provider
# module; empty model lists fill via discovery or manual seeding.
Together = [] # Inference cloud: fills via /v1/models discovery or manual seeding
Fireworks = [] # Inference cloud: fills via /inference/v1/models discovery or manual seeding
Cerebras = [] # Inference cloud: fills via /v1/models discovery or manual seeding
# Doc-derived inference clouds (TASK-33201); empty lists fill via discovery.
SambaNova = [] # fills via /v1/models discovery or manual seeding
NVIDIA = [] # fills via /v1/models discovery or manual seeding
DeepInfra = [] # fills via /v1/openai/models discovery or manual seeding
Nebius = [] # fills via /v1/models discovery or manual seeding
Novita = [] # fills via /openai/v1/models discovery or manual seeding
# MiniMax documents no /models route: seeded from the `model` enum at
# platform.minimax.io/docs/api-reference/text-chat-openai (2026-09-27).
MiniMax = ["MiniMax-M3", "MiniMax-M3.1-Flash-Preview", "MiniMax-M2.7", "MiniMax-M2.7-highspeed", "MiniMax-M2.5", "MiniMax-M2.5-highspeed", "MiniMax-M2.1", "MiniMax-M2.1-highspeed", "MiniMax-M2"]
# Top-15 OpenRouter model makers (TASK-33350). MiMo and BytePlus document no
# usable models route, so they ship seeded from their documented model IDs
# (any other ID can be entered as a custom model); the rest fill via discovery.
MiMo = ["mimo-v2.6-flash", "mimo-v2.6-pro", "mimo-v2.6-pro-ultraspeed", "mimo-v2.5-pro", "mimo-v2.5"]
TokenHub = [] # Tencent TokenHub: fills via /v1/models discovery (Hy4 is hy4-preview)
BytePlus = ["seed-2-0-lite-260228", "seed-1-8-251228"] # also accepts your own ep-... endpoint IDs
StepFun = [] # fills via /v1/models discovery or manual seeding
# Gateway/host presets from the Hermes / oh-my-pi comparison (TASK-33351).
# Upstage and Qianfan document no models route and ship seeded from their API
# references; the rest fill via discovery. Any other ID can be entered as a
# custom model.
Vercel = []
ZenMux = []
Kilo = []
SiliconFlow = []
Baseten = []
GMI = []
OllamaCloud = []
Upstage = ["solar-pro4", "solar-mini4", "solar-pro3", "solar-pro2", "solar-mini", "syn-pro"]
Arcee = []
Qianfan = ["ernie-5.1", "ernie-5.0", "ernie-5.0-thinking-latest", "ernie-4.5-turbo-128k", "ernie-4.5-turbo-32k", "ernie-3.5-8k"]
Nous = []
Venice = []
Meta = []
# Follow-up presets (TASK-33505..33509). Azure lists your DEPLOYMENT names
# (add them as custom models); W&B fills via discovery. Cloudflare has no
# models route, and OpenCode Zen / Command Code list models on several
# protocols, so they ship seeded with their Chat Completions models (read
# from each provider's model pages, 2026-09-29).
Azure = []
WandB = []
Cloudflare = ["@cf/moonshotai/kimi-k2.6", "@cf/zai-org/glm-5.3", "@cf/zai-org/glm-5.3-flash", "@cf/deepseek-ai/deepseek-v4-pro-0813", "@cf/deepseek-ai/deepseek-v4-flash-0731", "@cf/openai/gpt-oss-120b", "@cf/qwen/qwen3.8-27b", "@cf/google/gemma-4-26b-a4b-it", "@cf/meta/llama-4-scout-17b-16e-instruct", "@cf/meta/llama-3.3-70b-instruct-fp8-fast"]
OpenCodeZen = ["qwen3.8-max", "deepseek-v4.1-flash", "deepseek-v4-pro", "deepseek-v4-flash", "minimax-m3", "minimax-m2.7", "glm-5.3", "glm-5.3-flash", "glm-5.2", "kimi-k3", "kimi-k2.7-code", "kimi-k2.6", "big-pickle", "mimo-v2.6-flash-free", "nemotron-3-ultra-free"]
CommandCode = ["gpt-5.5", "deepseek/deepseek-v4-pro", "deepseek/deepseek-v4-flash", "deepseek/deepseek-v4.1-flash", "Qwen/Qwen3.7-Max", "Qwen/Qwen3.6-Plus", "moonshotai/Kimi-K3", "moonshotai/Kimi-K2.6", "zai-org/GLM-5.3", "zai-org/GLM-5.1", "MiniMaxAI/MiniMax-M3", "MiniMaxAI/MiniMax-M2.7", "stepfun/Step-3.5-Flash", "xiaomi/mimo-v2.5-pro", "google/gemini-3.5-flash"]
# Local Providers
Llama_cpp = ["None"]
koboldcpp = ["None"]
Oobabooga = ["None"]
Ollama = ["gemma3:12b", "gemma3:4b", "gemma3:27b", "qwen3:4b", "qwen3:8b", "qwen3:14b", "qwen3:30b", "qwen3:32b", "qwen3:235b", "devstral:24b", "deepseek-r1:671b"]
vLLM = ["vllm-model-z", "vllm-model-x", "vllm-model-y", "vllm-model-a"]
Custom = ["custom-model-alpha", "custom-model-beta"]
Custom_2 = ["custom-model-gamma", "custom-model-delta"]
TabbyAPI = ["tabby-model", "tabby-model-2", "tabby-model-3"]
Aphrodite = ["aphrodite-engine", "aphrodite-engine-2"]
local-llm = ["None"] # Add if you have a specific local-llm provider entry
local_llamacpp = ["None"]
local_llamafile = ["None"]
local_ollama = ["None"]
local_vllm = ["None"]
local_onnx = ["None"]
local_transformers = ["None"]
local_mlx_lm = ["None"]

[model_catalog]
# TASK-26023: use the upstream models.dev catalog as a LOWER-priority
# gap-fill for model context windows, vision flags, and pricing -- BENEATH
# your hand-maintained entries, so a local override always wins. Off by
# default (offline/today unchanged, no fabricated prices). When on, the
# lookup path never touches the network: fetching is explicit/background and
# disk-cached with a conditional (ETag) GET. A displayed models.dev figure
# is labeled with source "models.dev" so it is traceable.
use_models_dev = false
# Automatic model-list refresh for cloud providers (ADR-020).
auto_refresh_enabled = true
# The startup check is confirm-first: nothing is contacted online until the
# user answers the one-time consent dialog (which sets this to true).
refresh_consent_recorded = false
stale_after_hours = 24 # 0 = refetch every launch
auto_refresh_disabled = [] # exact [providers] keys to opt out, e.g. ["ZAI"]
write_to_config = [] # exact [providers] keys whose new models append to this file

[api_settings] # Parent section for all API provider specific settings

    # --- Cloud Providers ---
    [api_settings.openai]
    api_key_env_var = "OPENAI_API_KEY"
    # api_key = "" # Less secure fallback - use env var instead
    model = "gpt-5.6-terra" # Default model for direct calls (if not overridden)
    temperature = 0.7
    top_p = 1.0 # OpenAI uses top_p (represented as maxp sometimes in UI)
    max_tokens = 4096
    timeout = 60 # seconds
    retries = 3
    retry_delay = 5 # seconds (backoff factor)
    streaming = false

    [api_settings.anthropic]
    api_key_env_var = "ANTHROPIC_API_KEY"
    # api_key = "" # Less secure fallback - use env var instead
    # TASK-26022: how requests authenticate. "api_key" (default) uses the key
    # above. "claude_subscription" borrows the OAuth credential Claude Code
    # minted (~/.claude/.credentials.json) READ-ONLY, billing your Pro/Max
    # subscription instead of API rates. Explicit opt-in: a credential on disk
    # never changes billing by itself. Chatbook never refreshes the token --
    # when it expires, log in with Claude Code again. Whether subscription use
    # from a third-party client fits Anthropic's terms is YOUR call.
    # auth_source = "api_key"
    model = "claude-sonnet-5"
    temperature = 0.7
    top_p = 1.0 # Anthropic uses top_p (represented as topp in UI)
    top_k = 0 # Anthropic specific, 0 or -1 usually disables it
    max_tokens = 4096
    timeout = 90
    retries = 3
    retry_delay = 5
    streaming = false

    [api_settings.cohere]
    api_key_env_var = "COHERE_API_KEY"
    # api_key = "" # Less secure fallback - use env var instead
    model = "command-a-03-2025"
    temperature = 0.3
    top_p = 0.75 # Cohere uses 'p' (represented as topp in UI)
    top_k = 0 # Cohere uses 'k'
    max_tokens = 4096 # Cohere uses max_tokens
    timeout = 90
    retries = 3
    retry_delay = 5
    streaming = false

    [api_settings.deepseek]
    api_key_env_var = "DEEPSEEK_API_KEY"
    # api_key = "" # Less secure fallback - use env var instead
    model = "deepseek-v4-flash"
    temperature = 0.7
    top_p = 1.0 # Deepseek uses top_p (represented as topp in UI)
    max_tokens = 4096
    timeout = 60
    retries = 3
    retry_delay = 5
    streaming = false

    [api_settings.groq]
    api_key_env_var = "GROQ_API_KEY"
    # api_key = "" # Less secure fallback - use env var instead
    model = "llama-3.3-70b-versatile"
    temperature = 0.7
    top_p = 1.0 # Groq uses top_p (represented as maxp in UI)
    max_tokens = 8192
    timeout = 60
    retries = 3
    retry_delay = 5
    streaming = false

    [api_settings.google]
    api_key_env_var = "GOOGLE_API_KEY"
    api_key = "<API_KEY_HERE>"
    model = "gemini-2.5-flash"
    temperature = 0.7
    top_p = 0.9 # Google uses topP (represented as topp in UI)
    top_k = 100 # Google uses topK
    max_tokens = 8192 # Google uses maxOutputTokens
    timeout = 120
    retries = 3
    retry_delay = 5
    streaming = false

    [api_settings.huggingface]
    api_key_env_var = "HUGGINGFACE_API_KEY"
    # api_key = "" # Less secure fallback - use env var instead
    model = "openai/gpt-oss-120b"
    api_base_url = "https://router.huggingface.co/v1"
    api_chat_path = "chat/completions"
    temperature = 0.7
    top_p = 1.0 # HF Inference API uses top_p
    top_k = 50  # HF Inference API uses top_k
    max_tokens = 4096 # HF Inf API uses max_tokens / max_new_tokens
    timeout = 60
    retries = 3
    retry_delay = 5
    streaming = false

    [api_settings.mistralai] # Matches key in [providers]
    api_key_env_var = "MISTRAL_API_KEY"
    # api_key = "" # Less secure fallback - use env var instead
    model = "mistral-large-latest"
    temperature = 0.7
    top_p = 1.0 # Mistral uses top_p (represented as topp in UI)
    max_tokens = 4096
    timeout = 60
    retries = 3
    retry_delay = 5
    streaming = false

    [api_settings.openrouter]
    api_key_env_var = "OPENROUTER_API_KEY"
    # api_key = "" # Less secure fallback - use env var instead
    model = "meta-llama/Llama-3.1-8B-Instruct"
    temperature = 0.7
    top_p = 1.0 # OpenRouter uses top_p
    top_k = 0   # OpenRouter uses top_k
    min_p = 0.0 # OpenRouter uses min_p
    max_tokens = 4096
    timeout = 120
    retries = 3
    retry_delay = 5
    streaming = false

    [api_settings.moonshot]
    api_key_env_var = "MOONSHOT_API_KEY"
    # api_key = "" # Less secure fallback - use env var instead
    model = "kimi-k3"
    temperature = 0.7
    top_p = 0.95 # Moonshot uses top_p (OpenAI compatible)
    max_tokens = 4096
    api_region = "international" # "international" or "china"
    api_base_url = "https://api.moonshot.ai/v1" # Default for international; use https://api.moonshot.cn/v1 for China
    timeout = 90
    retries = 3
    retry_delay = 1.0
    streaming = true

    [api_settings.qwencloud]
    api_mode = "responses"
    api_key_env_var = "DASHSCOPE_API_KEY"
    api_base_url = "https://dashscope-intl.aliyuncs.com/compatible-mode/v1"
    model = "qwen3.8-max"
    timeout = 120
    retries = 3
    retry_delay = 1
    streaming = true

    [api_settings.zai] # Matches key in [providers]
    api_key_env_var = "ZAI_API_KEY"
    # api_key = "" # Less secure fallback - use env var instead
    model = "glm-5.2"
    temperature = 0.7
    top_p = 0.95
    max_tokens = 4096
    api_base_url = "https://api.z.ai/api/paas/v4"
    timeout = 90
    retries = 3
    retry_delay = 5
    streaming = true

    [api_settings.databricks] # Matches key in [providers]; values mirror provider_registry.DATABRICKS.settings_defaults (ADR-179)
    # Databricks Model Serving / AI Gateway. The workspace host is
    # per-account, so NO api_base_url ships here: the user configures their
    # workspace URL (the engine appends the /openai/v1 suffix). No `model`
    # key ships either: served models are workspace-configured and fill via
    # discovery/seeding — a PRESENT-but-blank value would be rejected by the
    # engine resolver (present-but-blank settings fail closed; only the
    # UNSET key resolves to the payload-gated ""), so the key stays absent.
    api_key_env_var = "DATABRICKS_TOKEN"
    timeout = 90
    retries = 3
    retry_delay = 5.0
    streaming = true

    # --- Inference clouds (ADR-179 Phase 2) ---
    # Engine presets (provider_registry.TOGETHER/FIREWORKS/CEREBRAS): no
    # per-provider handler module exists. Each table mirrors its record's
    # settings_defaults plus the default api_base_url (the record's
    # default_base_url). No `model` key ships (same blank-model lesson as
    # databricks): models fill via discovery or manual seeding, and the
    # UNSET key resolves to the payload-gated "".
    [api_settings.together] # Matches key in [providers]
    api_key_env_var = "TOGETHER_API_KEY"
    # api_key = "" # Less secure fallback - use env var instead
    api_base_url = "https://api.together.xyz/v1"
    timeout = 90
    retries = 3
    retry_delay = 5.0
    streaming = true

    [api_settings.fireworks] # Matches key in [providers]
    api_key_env_var = "FIREWORKS_API_KEY"
    # api_key = "" # Less secure fallback - use env var instead
    api_base_url = "https://api.fireworks.ai/inference/v1"
    timeout = 90
    retries = 3
    retry_delay = 5.0
    streaming = true

    [api_settings.cerebras] # Matches key in [providers]
    api_key_env_var = "CEREBRAS_API_KEY"
    # api_key = "" # Less secure fallback - use env var instead
    api_base_url = "https://api.cerebras.ai/v1"
    timeout = 90
    retries = 3
    retry_delay = 5.0
    streaming = true

    # Doc-derived inference clouds (TASK-33201): same shape as above.
    [api_settings.sambanova] # Matches key in [providers]
    api_key_env_var = "SAMBANOVA_API_KEY"
    # api_key = "" # Less secure fallback - use env var instead
    api_base_url = "https://api.sambanova.ai/v1"
    timeout = 90
    retries = 3
    retry_delay = 5.0
    streaming = true

    [api_settings.nvidia] # Matches key in [providers]
    api_key_env_var = "NVIDIA_API_KEY"
    # api_key = "" # Less secure fallback - use env var instead
    api_base_url = "https://integrate.api.nvidia.com/v1"
    timeout = 90
    retries = 3
    retry_delay = 5.0
    streaming = true

    [api_settings.deepinfra] # Matches key in [providers]
    api_key_env_var = "DEEPINFRA_API_KEY"
    # api_key = "" # Less secure fallback - use env var instead
    api_base_url = "https://api.deepinfra.com/v1/openai"
    timeout = 90
    retries = 3
    retry_delay = 5.0
    streaming = true

    [api_settings.nebius] # Matches key in [providers]
    api_key_env_var = "NEBIUS_API_KEY"
    # api_key = "" # Less secure fallback - use env var instead
    api_base_url = "https://api.tokenfactory.nebius.com/v1"
    timeout = 90
    retries = 3
    retry_delay = 5.0
    streaming = true

    [api_settings.novita] # Matches key in [providers]
    api_key_env_var = "NOVITA_API_KEY"
    # api_key = "" # Less secure fallback - use env var instead
    api_base_url = "https://api.novita.ai/openai/v1"
    timeout = 90
    retries = 3
    retry_delay = 5.0
    streaming = true

    [api_settings.minimax] # Matches key in [providers]
    api_key_env_var = "MINIMAX_API_KEY"
    # api_key = "" # Less secure fallback - use env var instead
    api_base_url = "https://api.minimax.io/v1"
    timeout = 90
    retries = 3
    retry_delay = 5.0
    streaming = true

    # Top-15 OpenRouter model makers (TASK-33350): same shape as above.
    [api_settings.mimo] # Matches key in [providers]
    api_key_env_var = "MIMO_API_KEY"
    # api_key = "" # Less secure fallback - use env var instead
    api_base_url = "https://api.xiaomimimo.com/v1" # sent as an api-key header, not Bearer
    timeout = 300 # MiMo can take minutes to send its first token
    retries = 3
    retry_delay = 5.0
    streaming = true

    [api_settings.tokenhub] # Matches key in [providers]
    api_key_env_var = "TOKENHUB_API_KEY"
    # api_key = "" # Less secure fallback - use env var instead
    api_base_url = "https://tokenhub-intl.tencentcloudmaas.com/v1" # US: tokenhub-us..., China: tokenhub.tencentcloudmaas.com
    timeout = 90
    retries = 3
    retry_delay = 5.0
    streaming = true

    [api_settings.byteplus] # Matches key in [providers]
    api_key_env_var = "ARK_API_KEY"
    # api_key = "" # Less secure fallback - use env var instead
    api_base_url = "https://ark.ap-southeast.bytepluses.com/api/v3" # China (Volcengine): https://ark.cn-beijing.volces.com/api/v3
    timeout = 90
    retries = 3
    retry_delay = 5.0
    streaming = true

    [api_settings.stepfun] # Matches key in [providers]
    api_key_env_var = "STEPFUN_API_KEY" # or "STEP_API_KEY", the name StepFun's own samples use
    # api_key = "" # Less secure fallback - use env var instead
    api_base_url = "https://api.stepfun.ai/v1" # China: https://api.stepfun.com/v1
    timeout = 90
    retries = 3
    retry_delay = 5.0
    streaming = true

    # Gateway/host presets (TASK-33351): same shape as above.
    [api_settings.vercel] # Matches key in [providers]
    api_key_env_var = "AI_GATEWAY_API_KEY"
    # api_key = "" # Less secure fallback - use env var instead
    api_base_url = "https://ai-gateway.vercel.sh/v1"
    timeout = 90
    retries = 3
    retry_delay = 5.0
    streaming = true

    [api_settings.zenmux] # Matches key in [providers]
    api_key_env_var = "ZENMUX_API_KEY"
    # api_key = "" # Less secure fallback - use env var instead
    api_base_url = "https://zenmux.ai/api/v1"
    timeout = 90
    retries = 3
    retry_delay = 5.0
    streaming = true

    [api_settings.kilo] # Matches key in [providers]
    api_key_env_var = "KILO_API_KEY"
    # api_key = "" # Less secure fallback - use env var instead
    api_base_url = "https://api.kilo.ai/api/gateway"
    timeout = 90
    retries = 3
    retry_delay = 5.0
    streaming = true

    [api_settings.siliconflow] # Matches key in [providers]
    api_key_env_var = "SILICONFLOW_API_KEY"
    # api_key = "" # Less secure fallback - use env var instead
    api_base_url = "https://api.siliconflow.com/v1" # China: https://api.siliconflow.cn/v1
    timeout = 90
    retries = 3
    retry_delay = 5.0
    streaming = true

    [api_settings.baseten] # Matches key in [providers]
    api_key_env_var = "BASETEN_API_KEY"
    # api_key = "" # Less secure fallback - use env var instead
    api_base_url = "https://inference.baseten.co/v1"
    timeout = 90
    retries = 3
    retry_delay = 5.0
    streaming = true

    [api_settings.gmi] # Matches key in [providers]
    api_key_env_var = "GMI_API_KEY"
    # api_key = "" # Less secure fallback - use env var instead
    api_base_url = "https://api.gmi-serving.com/v1"
    timeout = 90
    retries = 3
    retry_delay = 5.0
    streaming = true

    [api_settings.ollama_cloud] # Matches key in [providers]
    api_key_env_var = "OLLAMA_API_KEY"
    # api_key = "" # Less secure fallback - use env var instead
    api_base_url = "https://ollama.com/v1"
    timeout = 90
    retries = 3
    retry_delay = 5.0
    streaming = true

    [api_settings.upstage] # Matches key in [providers]
    api_key_env_var = "UPSTAGE_API_KEY"
    # api_key = "" # Less secure fallback - use env var instead
    api_base_url = "https://api.upstage.ai/v1"
    timeout = 90
    retries = 3
    retry_delay = 5.0
    streaming = true

    [api_settings.arcee] # Matches key in [providers]
    api_key_env_var = "ARCEE_API_KEY"
    # api_key = "" # Less secure fallback - use env var instead
    api_base_url = "https://api.arcee.ai/api/v1"
    timeout = 90
    retries = 3
    retry_delay = 5.0
    streaming = true

    [api_settings.qianfan] # Matches key in [providers]
    api_key_env_var = "QIANFAN_API_KEY"
    # api_key = "" # Less secure fallback - use env var instead
    api_base_url = "https://qianfan.baidubce.com/v2" # key is the whole bce-v3/ALTAK-... string
    timeout = 90
    retries = 3
    retry_delay = 5.0
    streaming = true

    [api_settings.nous] # Matches key in [providers]
    api_key_env_var = "NOUS_API_KEY"
    # api_key = "" # Less secure fallback - use env var instead
    api_base_url = "https://inference-api.nousresearch.com/v1"
    timeout = 90
    retries = 3
    retry_delay = 5.0
    streaming = true

    [api_settings.venice] # Matches key in [providers]
    api_key_env_var = "VENICE_API_KEY"
    # api_key = "" # Less secure fallback - use env var instead
    api_base_url = "https://api.venice.ai/api/v1"
    timeout = 90
    retries = 3
    retry_delay = 5.0
    streaming = true

    [api_settings.meta] # Matches key in [providers]
    api_key_env_var = "META_API_KEY" # or "MODEL_API_KEY", the name Meta's SDKs read
    # api_key = "" # Less secure fallback - use env var instead
    api_base_url = "https://api.meta.ai/v1"
    timeout = 90
    retries = 3
    retry_delay = 5.0
    streaming = true

    # Follow-up presets (TASK-33505..33509): same shape as above.
    [api_settings.azure] # Matches key in [providers]
    # Azure OpenAI v1 API. The resource host is per-account, so NO
    # api_base_url ships: set yours (e.g. "https://my-resource.openai.azure.com");
    # the /openai/v1 path is appended. Models are your deployment names.
    api_key_env_var = "AZURE_OPENAI_API_KEY"
    # api_key = "" # Less secure fallback - use env var instead
    timeout = 90
    retries = 3
    retry_delay = 5.0
    streaming = true

    [api_settings.wandb] # Matches key in [providers]
    api_key_env_var = "WANDB_API_KEY"
    # api_key = "" # Less secure fallback - use env var instead
    api_base_url = "https://api.inference.wandb.ai/v1"
    # project = "my-team/my-project" # optional: sent as the OpenAI-Project header
    timeout = 90
    retries = 3
    retry_delay = 5.0
    streaming = true

    [api_settings.cloudflare] # Matches key in [providers]
    # Workers AI REST API. The account id is part of the URL, so NO
    # api_base_url ships: set
    # "https://api.cloudflare.com/client/v4/accounts/<account-id>/ai/v1".
    api_key_env_var = "CLOUDFLARE_API_TOKEN"
    # api_key = "" # Less secure fallback - use env var instead
    # gateway_id = "my-gateway" # optional: sent as the cf-aig-gateway-id header
    timeout = 90
    retries = 3
    retry_delay = 5.0
    streaming = true

    [api_settings.opencode_zen] # Matches key in [providers]
    api_key_env_var = "OPENCODE_API_KEY"
    # api_key = "" # Less secure fallback - use env var instead
    api_base_url = "https://opencode.ai/zen/v1"
    timeout = 90
    retries = 3
    retry_delay = 5.0
    streaming = true

    [api_settings.commandcode] # Matches key in [providers]
    api_key_env_var = "COMMANDCODE_API_KEY"
    # api_key = "" # Less secure fallback - use env var instead
    api_base_url = "https://api.commandcode.ai/provider/v1"
    timeout = 90
    retries = 3
    retry_delay = 5.0
    streaming = true

    # --- Local Providers ---
    # Local providers default to streaming = true so slow generations render
    # incrementally instead of timing out on one long blocking completion.
    [api_settings.llama_cpp] # Matches key in [providers]
    api_key_env_var = "LLAMA_CPP_API_KEY" # If you set one on the server
    # api_key = ""
    api_url = "http://localhost:8080" # llama.cpp server root; the OpenAI-compatible /v1/chat/completions path is appended automatically
    model = "" # Often not needed if server serves one model
    temperature = 0.7
    top_p = 0.95
    top_k = 40
    min_p = 0.05
    max_tokens = 4096 # llama.cpp uses n_predict
    timeout = 300
    retries = 1
    retry_delay = 2
    streaming = true
    system_prompt = "You are a helpful AI assistant"

    [api_settings.oobabooga] # Matches key in [providers]
    api_key_env_var = "OOBABOOGA_API_KEY" # If API extension needs one
    api_url = "http://localhost:5000/v1/chat/completions" # Ooba OpenAI compatible endpoint
    model = "" # Model loaded in Ooba UI
    temperature = 0.7
    top_p = 0.9
    # top_k = 50 # Check Ooba endpoint docs for OpenAI compatibility params
    # min_p = 0.0
    max_tokens = 4096
    timeout = 300
    retries = 1
    retry_delay = 2
    streaming = true
    system_prompt = "You are a helpful AI assistant"

    [api_settings.koboldcpp] # Matches key in [providers]
    # api_key = "" # Kobold doesn't use keys
    api_url = "http://localhost:5001/api/v1/generate" # Kobold non-streaming API
    # api_streaming_url = "http://localhost:5001/api/v1/stream" # Kobold streaming API (different format)
    model = "" # Model loaded in Kobold UI
    temperature = 0.7
    top_p = 0.9
    top_k = 50
    max_tokens = 4096 # Kobold uses max_context_length / max_length
    timeout = 300
    retries = 1
    retry_delay = 2
    streaming = true # Kobold streaming is non-standard, handle carefully
    system_prompt = "You are a helpful AI assistant"

    [api_settings.ollama]
    # No API Key usually needed
    api_url = "http://localhost:11434/v1/chat/completions" # Default Ollama OpenAI endpoint
    model = "llama3:latest"
    temperature = 0.7
    top_p = 0.9
    top_k = 40 # Ollama supports top_k via OpenAI endpoint
    # min_p = 0.05 # Ollama OpenAI endpoint doesn't support min_p directly
    max_tokens = 4096
    timeout = 300 # Longer timeout for local models
    retries = 1
    retry_delay = 2
    streaming = true
    system_prompt = "You are a helpful AI assistant"

    [api_settings.vllm] # Matches key in [providers]
    api_key_env_var = "VLLM_API_KEY" # If served behind auth
    api_url = "http://localhost:8000/v1/chat/completions" # vLLM OpenAI compatible endpoint
    model = "" # Model specified when starting vLLM server
    temperature = 0.7
    top_p = 0.95
    top_k = 50
    min_p = 0.05
    max_tokens = 4096
    timeout = 300
    retries = 1
    retry_delay = 2
    streaming = true
    system_prompt = "You are a helpful AI assistant"

    [api_settings.aphrodite] # Matches key in [providers]
    api_key_env_var = "APHRODITE_API_KEY" # If served behind auth
    api_url = "http://localhost:2242/v1/chat/completions" # Default Aphrodite port
    model = "aphrodite-engine" # Model loaded in Aphrodite
    temperature = 0.7
    top_p = 0.95
    top_k = 50
    min_p = 0.05
    max_tokens = 4096
    timeout = 300
    retries = 1
    retry_delay = 2
    streaming = true
    system_prompt = "You are a helpful AI assistant"

    [api_settings.tabbyapi] # Matches key in [providers]
    api_key_env_var = "TABBYAPI_API_KEY"
    api_url = "http://localhost:8080/v1/chat/completions" # Check TabbyAPI docs for exact URL
    model = "tabby-model" # Model configured in TabbyAPI
    temperature = 0.7
    top_p = 0.95
    top_k = 50
    min_p = 0.05
    max_tokens = 4096
    timeout = 120
    retries = 2
    retry_delay = 3
    streaming = true
    system_prompt = "You are a helpful AI assistant"

    [api_settings.custom] # Matches key in [providers]
    api_key_env_var = "CUSTOM_API_KEY"
    api_url = "http://localhost:1234/v1/chat/completions"
    model = "custom-model-alpha"
    temperature = 0.7
    top_p = 1.0
    top_k = 0
    min_p = 0.0
    max_tokens = 4096
    timeout = 120
    retries = 2
    retry_delay = 5
    streaming = false
    system_prompt = "You are a helpful AI assistant"

    [api_settings.custom_2] # Matches key in [providers]
    api_key_env_var = "CUSTOM_2_API_KEY"
    api_url = "http://localhost:5678/v1/chat/completions"
    model = "custom-model-gamma"
    temperature = 0.7
    top_p = 1.0
    top_k = 0
    min_p = 0.0
    max_tokens = 4096
    timeout = 120
    retries = 2
    retry_delay = 5
    streaming = false
    system_prompt = "You are a helpful AI assistant"

    [api_settings.local-llm] # Matches key in [providers]
    api_url = "http://localhost:8000/v1/chat/completions"
    model = ""
    temperature = 0.7
    top_p = 1.0
    top_k = 0
    min_p = 0.0
    max_tokens = 4096
    timeout = 120
    retries = 2
    retry_delay = 5
    streaming = true
    system_prompt = "You are a helpful AI assistant"

    [api_settings.local_llamafile] # Matches key in [providers]
    api_url = "http://localhost:8001/v1/chat/completions"
    model = ""
    temperature = 0.7
    top_p = 1.0
    top_k = 0
    min_p = 0.0
    max_tokens = 4096
    timeout = 120
    retries = 2
    retry_delay = 5
    streaming = true
    system_prompt = "You are a helpful AI assistant"

    [api_settings.local_llamacpp] # Matches key in [providers]
    #api_key_env_var = "local_llamacpp_API_KEY"
    api_url = "http://localhost:8001/v1/chat/completions"
    model = "custom-model-gamma"
    temperature = 0.7
    top_p = 1.0
    top_k = 0
    min_p = 0.0
    max_tokens = 4096
    timeout = 120
    retries = 2
    retry_delay = 5
    streaming = true
    system_prompt = "You are a helpful AI assistant"

    [api_settings.local_vllm] # Matches key in [providers]
    #api_key_env_var = "local_vllm_API_KEY" # If served behind auth
    api_url = "http://localhost:8008/v1/chat/completions"
    model = "custom-model-gamma"
    temperature = 0.7
    top_p = 1.0
    top_k = 0
    min_p = 0.0
    max_tokens = 4096
    timeout = 120
    retries = 2
    retry_delay = 5
    streaming = true
    system_prompt = "You are a helpful AI assistant"

    [api_settings.local_ollama] # Matches key in [providers]
    api_key_env_var = "local_ollama_API_KEY" # If served behind auth
    api_url = "http://localhost:5678/v1/chat/completions"
    model = "custom-model-gamma"
    temperature = 0.7
    top_p = 1.0
    top_k = 0
    min_p = 0.0
    max_tokens = 4096
    timeout = 120
    retries = 2
    retry_delay = 5
    streaming = true
    system_prompt = "You are a helpful AI assistant"

    [api_settings.local_onnx] # Matches key in [providers]
    api_url = "http://localhost:8000/v1/chat/completions"
    model = ""
    temperature = 0.7
    top_p = 1.0
    top_k = 0
    min_p = 0.0
    max_tokens = 4096
    timeout = 120
    retries = 2
    retry_delay = 5
    streaming = true
    system_prompt = "You are a helpful AI assistant"

    [api_settings.local_transformers] # Matches key in [providers]
    api_url = "http://localhost:8000/v1/chat/completions"
    model = ""
    temperature = 0.7
    top_p = 1.0
    top_k = 0
    min_p = 0.0
    max_tokens = 4096
    timeout = 120
    retries = 2
    retry_delay = 5
    streaming = true
    system_prompt = "You are a helpful AI assistant"

    [api_settings.local_mlx_lm] # Matches key in [providers]
    api_url = "http://localhost:5678/v1/chat/completions"
    model = "custom-model-gamma"
    temperature = 0.7
    top_p = 1.0
    top_k = 0
    min_p = 0.0
    max_tokens = 4096
    timeout = 120
    retries = 2
    retry_delay = 5
    streaming = true
    system_prompt = "You are a helpful AI assistant"
    # ... etc ...

[chat_defaults]
rag_auto_retrieve_on_send = false  # New Console chats do not search Library automatically
# TASK-26024: route Console SIDE tasks (compaction/summarization -- titling
# here is deterministic, no model) to a cheaper auxiliary model. Both keys
# empty = today's behavior (side tasks use the main chat model). Model-only
# keeps the main provider; a cross-provider auxiliary must resolve ready or
# the side task silently falls back to the main model. The auxiliary NEVER
# handles a user-visible chat turn. (The auto-on-send compaction stays on
# the main model; this routes manual /rewind summarize, "compact now", and
# per-turn micro-compaction.)
# auxiliary_provider = ""
# auxiliary_model = ""
# TASK-26003: stream stall watchdog. A streamed turn producing no NEW content
# for this many seconds is terminated even while keep-alive/heartbeat bytes keep
# arriving (the transport read timeout never fires in that case). Keep-alives do
# not reset the clock; normal slow generation keeps emitting content and does
# not trip. Non-positive disables the watchdog. Default 90s. Env override:
# TLDW_STREAM_STALL_TIMEOUT_SECONDS (precedence: env -> this key -> default).
# stream_stall_timeout_seconds = 90
# TASK-34100.5: the wait for a reply's FIRST token. A large local model can
# take minutes to load; default 300 for self-hosted providers, the stall window
# above for cloud ones. Env override: TLDW_FIRST_TOKEN_TIMEOUT_SECONDS.
# first_token_timeout_seconds = 300
# Default settings specifically for the 'Chat' tab
user_display_name = "User"
provider = "OpenAI"
model = "gpt-5.6-terra"
system_prompt = "You are a helpful AI assistant."
temperature = 0.6
top_p = 0.95
min_p = 0.05
top_k = 50
strip_thinking_tags = true

# Console transcript view pruning: when the transcript's virtual height (in
# terminal rows) exceeds prune_high_watermark, the oldest message rows are
# dropped from the view until the remaining height fits under
# prune_low_watermark. Scroll position is preserved, the in-progress
# streaming row is never pruned, and the store keeps the full history
# (pruning is view-only). Set prune_high_watermark <= 0 to disable pruning.
prune_high_watermark = 20000
prune_low_watermark = 12000

# Console transcript load window: opening or switching to a conversation
# mounts only a tail of it, and scrolling to the top of that tail prepends
# more. Both values are FLOORS in terminal rows -- the effective budget is the
# larger of the floor and the mounted viewport (6x for the initial window, 4x
# per scrollback step). Set transcript_window_lines <= 0 to mount the whole
# history at load, as before. With windowing on and sane watermarks the
# window is two-sided (TASK-15777): sustained scroll-back keeps loading older
# history while trimming the newest end back out of the view (never a
# selected message, which pauses the sliding while pinned at that end), so
# the session stays reachable by scrolling at a bounded mounted size, and a
# jump to a far-away message mounts a fresh window around it instead of
# everything between it and the tail.
transcript_window_lines = 144
transcript_scrollback_lines = 96

# Render assistant replies as full markdown (code blocks, tables, lists,
# links) in the Console transcript. Set false to restore the lightweight
# span renderer, which keeps roleplay speech/action flavor colors.
assistant_markdown = true

# Image attachment settings for chat
[chat.images]
enabled = true
show_attach_button = true  # Show/hide the attach file button in chat
# show_character_avatar = true  # show the active character image; Character navigation remains available
# react_character_expressions = true  # swap the Console character avatar among idle/thinking/speaking/error as it generates a reply (requires per-state images on the character); set false to keep a static avatar
default_render_mode = "auto"  # auto, pixels, regular
max_size_mb = 10.0
auto_resize = true
resize_max_dimension = 2048
save_location = "~/Downloads"
supported_formats = [".png", ".jpg", ".jpeg", ".gif", ".webp", ".bmp", ".tiff", ".tif", ".svg"]

[chat.images.terminal_overrides]
kitty = "regular"
wezterm = "regular"
iterm2 = "regular"
default = "pixels"

[web_security]
# Egress guard (SSRF protection) for web scraping / ingestion / subscription
# fetches. When enabled, a URL must resolve to public IPs unless you typed it
# into the app (Watchlists New source / Add several, Library Capture, an
# ingest URL, a Confluence base_url); a redirect back to that URL's own host
# keeps its trust. Crawl discoveries, feed items, a redirect to any other
# host, and watch sources from an older version or an OPML/bundle import
# never count. allowed_hosts admits each listed host (exact name, no port,
# IPv6 without brackets) for every fetch, unchecked, cloud metadata
# endpoints included (otherwise always blocked).
enabled = true
allowed_hosts = []
# Default (connect, read) timeout applied by `Utils/egress.py`'s
# `create_default_session()` to any request through that session which does
# not pass its own `timeout=` (task-19830). Per-provider `api_timeout`
# settings under [api_settings.<provider>] still take precedence wherever
# they're read explicitly -- these are only the floor for call sites that
# don't set one.
# request_connect_timeout_seconds = 10
# request_read_timeout_seconds = 30

[network]
# TLS trust for outbound HTTP/HTTPS/WebSocket (LLM providers, content fetching).
#   true                verify against the default bundle (default)
#   false               DISABLE verification (insecure; only for TLS-inspecting
#                       corporate networks where you cannot obtain the CA)
#   "/path/to/ca.pem"   ALSO trust this CA bundle (corporate root CA) — additive.
# Windows paths: use a literal single-quoted string ('C:\\certs\\corp.pem').
ssl_verify = true

[image_generation]
# Backend-specific fields (model, base_url, timeout_seconds, api_key, ...) go
# ONLY under the matching [image_generation.<backend>] table below -- e.g.
# [image_generation.openrouter] default_model = "...". A flat key such as
# `openrouter_image_default_model` written directly in THIS [image_generation]
# table is NOT read; it logs a startup warning and is ignored (task-621).
default_backend = "swarmui"          # local SwarmUI instance is the friendliest zero-key default
enabled_backends = ["swarmui"]
max_width = 1024
max_height = 1024
max_pixels = 1048576
max_steps = 50
max_prompt_length = 1000
inline_max_bytes = 4000000
default_batch = 1
max_variants_per_message = 8

# `/generate-image` with no prompt text composes from conversation context.
# When context_llm_enabled, an LLM call (the session's active provider+
# model, same as a normal Console send) composes a richer prompt from the
# last context_llm_turns messages; ANY failure (kill-switch off, no ready
# provider, error, timeout, empty response) falls back to the built-in
# keyword extractor -- generation is never blocked by this.
context_llm_enabled = true
context_llm_turns = 10
context_llm_timeout_seconds = 15

[image_generation.stable_diffusion_cpp]
binary_path = ""                      # local `sd` CLI; empty = backend unusable
diffusion_model_path = ""             # OR model_path
model_path = ""
llm_path = ""
vae_path = ""
lora_paths = []
device = "auto"
default_steps = 25
default_cfg_scale = 7.5
default_sampler = "euler_a"
timeout_seconds = 120
allowed_extra_params = []

[image_generation.swarmui]
base_url = "http://127.0.0.1:7801"
default_model = ""
timeout_seconds = 120
allowed_extra_params = []
# swarm_token: secret, resolved via env/keyring precedence, not stored plaintext here

# ComfyUI H3 image editing is explicit opt-in: add "comfyui" to
# enabled_backends above after reviewing this server boundary. Saving a base_url
# in F4 Settings consents to sending the source image and instruction to that
# exact origin. ComfyUI retains uploaded inputs and saved outputs according to
# the server operator's policy.
# [image_generation.comfyui]
# base_url = "http://127.0.0.1:8188"
# request_timeout_seconds = 30
# connect_timeout_seconds = 5
# poll_interval_seconds = 1
# total_deadline_seconds = 1800
# default_seed = -1                # omit to use packaged workflow
# default_steps = 28               # omit to use packaged workflow
# default_sampler = "euler"        # omit to use packaged workflow

[image_generation.openrouter]
base_url = "https://openrouter.ai/api/v1"
default_model = "google/gemini-2.5-flash-image"  # task-620: "openai/gpt-image-1" was retired upstream and 404s
timeout_seconds = 120
allowed_extra_params = []
api_key = "<API_KEY_HERE>"

[image_generation.novita]
base_url = "https://api.novita.ai"
default_model = "sd_xl_base_1.0.safetensors"
timeout_seconds = 180
poll_interval_seconds = 2
allowed_extra_params = []
api_key = "<API_KEY_HERE>"

[image_generation.together]
base_url = "https://api.together.xyz/v1"
default_model = "black-forest-labs/FLUX.1-schnell-Free"
timeout_seconds = 120
allowed_extra_params = []
api_key = "<API_KEY_HERE>"

[image_generation.modelstudio]
base_url = ""                         # region-derived if empty
default_model = "qwen-image"
region = "sg"                         # sg|cn|us
mode = "auto"                         # sync|async|auto
poll_interval_seconds = 2
timeout_seconds = 180
allowed_extra_params = []
api_key = "<API_KEY_HERE>"

# fal.ai and Gemini backends -- uncomment and add enabled_backends/
# default_backend above to use.
# [image_generation.fal]
# base_url = "https://queue.fal.run"
# default_model = "fal-ai/flux/schnell"
# poll_interval_seconds = 2
# timeout_seconds = 120
# api_key = "<API_KEY_HERE>"          # or set FAL_KEY in the environment

# [image_generation.gemini]
# base_url = "https://generativelanguage.googleapis.com/v1beta"
# default_model = "gemini-2.5-flash-image"
# timeout_seconds = 120
# api_key = "<API_KEY_HERE>"          # or set GEMINI_API_KEY / GOOGLE_API_KEY

# User-defined `/generate-image` @style templates, layered over the 13
# built-ins (Media_Creation/generation_templates.py). A user template with
# the same id as a builtin overrides it; new ids extend the set. Fields
# mirror a builtin's shape: name/category/base_prompt are required,
# everything else optional. Uncomment and edit to add your own, or drop
# one *.toml file per template (same fields, no [image_generation.styles.*]
# wrapper) under <user data dir>/image_generation_styles/ instead -- see
# that module's docstring for the full precedence rule.
# [image_generation.styles.my_glow]
# name = "My Glow"
# category = "Custom"
# description = "Soft dreamy glow"
# base_prompt = "{{subject}}, soft glow lighting, dreamy atmosphere"
# negative_prompt = "harsh lighting, low quality"
# tags = ["custom", "glow"]
# [image_generation.styles.my_glow.default_params]
# width = 768
# height = 768
# steps = 28
# cfg_scale = 7.5
# [image_generation.styles.my_glow.context_mappings]
# subject = "last_message"

[character_defaults]
# Default settings specifically for the 'Character' tab
provider = "Anthropic"
model = "claude-haiku-4-5" # Make sure this exists in [providers.Anthropic]
system_prompt = "You are roleplaying as a witty pirate captain."
temperature = 0.8
top_p = 0.9
min_p = 0.0 # Check if API supports this
top_k = 100 # Check if API supports this

[analysis_defaults]
# Default settings specifically for the Media Analysis feature
provider = "OpenAI"
model = "gpt-4o"
temperature = 0.7
top_p = 0.95
min_p = 0.05
top_k = 50
system_prompt = "You are an AI assistant specialized in analyzing and summarizing media content. Provide comprehensive, insightful analysis with clear structure and key takeaways."
max_tokens = 4096
# Prompt search/filter defaults
default_prompt_search = ""
default_keyword_filter = ""
# Auto-save analysis after generation
auto_save = false
# Show analysis button in media viewer by default
show_analysis_button = true

[permission_summary]
# ADR-090: advisory summaries on Console approval cards.
# mode: off (default) | fallback (only when the model gave no rationale)
# | always (every approval round). Enabling sends a bounded tail of the
# conversation (user/assistant text only) to this provider.
mode = "off"
provider = ""
model = ""
# api_key = ""           # optional; else the provider's configured key
timeout_seconds = 4
max_tokens = 120
tail_max_chars = 4000
# system_prompt = ""     # optional override of the built-in neutral prompt

[llm_management]
# LLM Management settings
model_download_dir = "~/Downloads/tldw_models"  # Legacy read-only scan root for Installed models

[llamacpp_snapshots]
enabled = false
keep_count = 10

[notes]
# Device-private lasting-sync settings. Legacy sync keys are intentionally not
# emitted for fresh profiles; already-present keys remain migration input only.
recovery_capacity_bytes = 268435456  # Device-private lasting-sync recovery capacity (256 MiB)
# Lasting-sync change watcher: base poll interval, and the cap it backs off to
# while roots are quiet (backed-off sleeps are jittered by up to +/-50%).
sync_watcher_interval_seconds = 1.0
sync_watcher_max_interval_seconds = 30.0

# Auto-save settings
auto_save_enabled = true             # Enable auto-save feature
auto_save_delay_ms = 3000           # Delay in milliseconds before auto-saving (3 seconds)
auto_save_on_every_key = false      # If true, saves on every keystroke; if false, uses delay


# ==========================================================
# Default/Template Prompts
# ==========================================================
[Prompts]
# Default prompts used by various functions. These can be overridden by user settings.
sub_question_generation_prompt = "Based on the user query and chat history, generate up to 3 sub-questions to gather more specific information. Format as a numbered list."
search_result_relevance_eval_prompt = "Evaluate the relevance of the following search result snippet to the query. Score from 1 (not relevant) to 5 (highly relevant)."
analyze_search_results_prompt = "Analyze the provided search results and synthesize a comprehensive answer to the original query."
situate_chunk_context_prompt = "You are an AI assistant. Please follow the instructions provided in the input text carefully and accurately."

[prompts.document_generation.timeline]
prompt = "Create a detailed text-based timeline based on our conversation/materials being referenced. Include key dates, events, and their relationships in chronological order."
temperature = 0.3
max_tokens = 2000

[prompts.document_generation.study_guide]
prompt = "Create a detailed and well produced study guide based on the current focus of our conversation/materials in reference. Include key concepts, definitions, learning objectives, and potential exam questions."
temperature = 0.5
max_tokens = 3000

[prompts.document_generation.briefing]
prompt = "Create a detailed and well produced executive briefing document regarding this conversation and the subject material. Include key points, actionable insights, strategic implications, and recommendations."
temperature = 0.4
max_tokens = 2500


# ==========================================================
# Embedding Configuration
# ==========================================================
[embedding_config]
default_model_id = "e5-small-v2"
default_llm_for_contextualization = "gpt-3.5-turbo"
model_cache_dir = "~/.local/share/tldw_cli/models/embeddings"
auto_download = true
cache_size_limit_gb = 10.0

    # --- HuggingFace Models ---
    [embedding_config.models.e5-small-v2]
    provider = "huggingface"
    model_name_or_path = "intfloat/e5-small-v2"
    dimension = 384
    trust_remote_code = false
    max_length = 512

    [embedding_config.models.multilingual-e5-large-instruct]
    provider = "huggingface"
    model_name_or_path = "intfloat/multilingual-e5-large-instruct"
    dimension = 1024
    trust_remote_code = false
    max_length = 512

    [embedding_config.models.e5-base-v2]
    provider = "huggingface"
    model_name_or_path = "intfloat/e5-base-v2"
    dimension = 768
    trust_remote_code = false
    max_length = 512

    [embedding_config.models.e5-large-v2]
    provider = "huggingface"
    model_name_or_path = "intfloat/e5-large-v2"
    dimension = 1024
    trust_remote_code = false
    max_length = 512

    [embedding_config.models.all-MiniLM-L6-v2]
    provider = "huggingface"
    model_name_or_path = "sentence-transformers/all-MiniLM-L6-v2"
    dimension = 384
    trust_remote_code = false
    max_length = 256

    [embedding_config.models.all-mpnet-base-v2]
    provider = "huggingface"
    model_name_or_path = "sentence-transformers/all-mpnet-base-v2"
    dimension = 768
    trust_remote_code = false
    max_length = 384

    [embedding_config.models.bge-small-en-v1.5]
    provider = "huggingface"
    model_name_or_path = "BAAI/bge-small-en-v1.5"
    dimension = 384
    trust_remote_code = false
    max_length = 512

    [embedding_config.models.bge-base-en-v1.5]
    provider = "huggingface"
    model_name_or_path = "BAAI/bge-base-en-v1.5"
    dimension = 768
    trust_remote_code = false
    max_length = 512

    [embedding_config.models.gte-small]
    provider = "huggingface"
    model_name_or_path = "thenlper/gte-small"
    dimension = 384
    trust_remote_code = false
    max_length = 512

    # --- Official OpenAI Models ---
    [embedding_config.models.openai-ada-002]
    provider = "openai"
    model_name_or_path = "text-embedding-ada-002"
    dimension = 1536
    api_key = "YOUR_OPENAI_API_KEY_OR_LEAVE_BLANK_IF_ENV_VAR_SET" # User fills this or sets ENV

    [embedding_config.models.openai-text-embedding-3-small]
    provider = "openai"
    model_name_or_path = "text-embedding-3-small" # Common model name
    dimension = 3072 # Or 256,, 1536, 2048 3072 depending on how you use it
    api_key = "YOUR_OPENAI_API_KEY_OR_LEAVE_BLANK_IF_ENV_VAR_SET"

    [embedding_config.models.openai-text-embedding-3-large]
    provider = "openai"
    model_name_or_path = "text-embedding-3-large" # Common model name
    dimension = 1536 # Or 512, 1536 depending on how you use it
    api_key = "YOUR_OPENAI_API_KEY_OR_LEAVE_BLANK_IF_ENV_VAR_SET"

    # --- Placeholder for a Local OpenAI-Compatible Server ---
    # The user needs to edit this section for their specific local setup.
    # The 'key' (e.g., "my-local-nomic-model") is what will appear in the UI's model dropdown
    # when "Local OpenAI-Compliant Server" provider is selected.
    [embedding_config.models.my-local-nomic-model]
    provider = "openai" # CRITICAL: This tells EmbeddingFactory to use OpenAICfg
    model_name_or_path = "nomic-ai/nomic-embed-text-v1" # The actual model name the LOCAL SERVER uses/expects
    base_url = "http://localhost:8080/v1" # The base URL of THE LOCAL SERVER's OpenAI-compatible API
    dimension = 768 # CRITICAL: User MUST provide the correct dimension for this model
    # api_key can be omitted if the local server doesn't require one, or set to a dummy value.
    # api_key = "not-needed-for-local"

    # --- Another Local Example (e.g., for a Llama.cpp server with embeddings) ---
    [embedding_config.models.local-llama-cpp-embeddings]
    provider = "openai"
    model_name_or_path = "llama-2-7b-chat.Q4_K_M.gguf" # Or whatever model name the server endpoint expects
    base_url = "http://localhost:8000/v1" # Common port for Llama.cpp server's OpenAI API
    dimension = 4096 # Example dimension for Llama-2 base models
    # api_key = "sk-xxxxxxxxxxxxxxxxx" # If your Llama.cpp server is configured with an API key

# You can add more local model configurations following the pattern above.
# The key part is `provider = "openai"` and providing the correct `base_url` and `dimension`.


# ==========================================================
# RAG (Retrieval-Augmented Generation) Configuration
# ==========================================================
[rag_citations]
canonical_writes_enabled = false

[rag]
# Comprehensive configuration for the RAG system

    # --- Retrieval Settings ---
    [rag.retriever]
    fts_top_k = 10              # Number of results from full-text search
    vector_top_k = 10           # Number of results from vector search
    hybrid_alpha = 0.7          # Hybrid RRF fusion: vector-leg weight (0=FTS only, 1=vector only); 0.7 = tldw_server default
    chunk_size = 512            # Size of text chunks for indexing
    chunk_overlap = 128         # Overlap between chunks
    
    # Collection names for different data types
    media_collection = "media_embeddings"
    chat_collection = "chat_embeddings"
    notes_collection = "notes_embeddings"
    character_collection = "character_embeddings"
    
    # --- Processing Settings ---
    [rag.processor]
    enable_reranking = true         # Enable result reranking
    reranker_model = "cohere"       # Reranker model: "cohere", "flashrank", or null
    reranker_top_k = 5             # Number of results to rerank
    deduplication_threshold = 0.85  # Similarity threshold for deduplication
    max_context_length = 4096      # Maximum context length for LLM
    combination_method = "weighted" # "weighted", "round_robin", "score_based"
    
    # --- Generation Settings ---
    [rag.generator]
    default_model = ""             # Default LLM model (empty = use chat defaults)
    default_temperature = 0.7      # Default temperature for RAG responses
    max_tokens = 1024              # Maximum tokens for RAG responses
    enable_streaming = true        # Enable streaming responses
    stream_chunk_size = 10         # Tokens per stream chunk
    
    # --- ChromaDB Settings ---
    [rag.chroma]
    persist_directory = ""         # Directory for ChromaDB (empty = auto)
    collection_prefix = "tldw_rag" # Prefix for collection names
    embedding_model = "all-MiniLM-L6-v2"  # Default embedding model
    embedding_dimension = 384      # Embedding dimension
    distance_metric = "cosine"     # "cosine", "euclidean", "ip"
    
    # --- Caching Settings ---
    [rag.cache]
    enable_cache = true            # Enable result caching
    cache_ttl = 3600              # Cache TTL in seconds (1 hour)
    max_cache_size = 1000         # Maximum cached items
    cache_embedding_results = true # Cache embedding results
    cache_search_results = true   # Cache search results
    cache_llm_responses = false   # Cache LLM responses (usually want fresh)
    
    # --- Memory Management Settings ---
    [rag.memory_management]
    max_total_size_mb = 1024.0         # Maximum total ChromaDB size (MB)
    max_collection_size_mb = 512.0     # Maximum size per collection (MB)
    max_documents_per_collection = 100000  # Maximum documents per collection
    max_age_days = 90                  # Maximum age of documents (days)
    inactive_collection_days = 30      # Days before cleaning inactive collections
    enable_automatic_cleanup = true    # Enable automatic cleanup
    cleanup_interval_hours = 24        # Hours between cleanup runs
    cleanup_batch_size = 1000         # Documents to delete per batch
    enable_lru_cache = true           # Enable ChromaDB LRU cache
    memory_limit_bytes = 2147483648   # Memory limit for ChromaDB (2GB)
    min_documents_to_keep = 100       # Minimum documents to always keep
    cleanup_confirmation_required = false  # Require confirmation for cleanup
    
    # --- Performance Settings ---
    [rag.performance]
    lazy_load_embeddings = true        # Defer loading embeddings models until first use
    preload_models = false             # Preload embedding models on startup
    unload_models_after_idle = true    # Unload models after idle timeout
    model_idle_timeout_seconds = 900   # Idle timeout before unloading (15 minutes)
    eager_dependency_check = false     # Check all dependencies on startup

# Legacy RAG settings (for backwards compatibility)
[rag_search]
fts_top_k = 10
vector_top_k = 10
web_vector_top_k = 10
llm_context_document_limit = 10

# ==========================================================
# Chunking Template Configuration
# ==========================================================
[chunking]
# Default chunking template for imports that did not pick one in the
# Library ingest form. Empty (the default) means plain chunk options
# (method/size/overlap) -- exactly today's behavior. The name must match
# a live template row in the media DB (RAG Admin: chunking templates);
# an unresolvable name fails the import with a named error rather than
# silently falling back to different chunking.
default_template = ""


# ==========================================================
# Sync Journal Retention
# ==========================================================
[sync]
# Retention window, in days, for the local sync journals (`sync_log` in the
# ChaChaNotes and media databases). Every conversation/message/note/media
# mutation leaves a full-copy JSON event there, so without a bound the table
# grows with total mutations forever. A background pass after startup (and
# then once a day) deletes rows older than this many days; the number of
# pruned rows is logged. Rows within the window are never touched, so sync
# consumers reading by change_id cursor still see every unpruned change.
# Set 0 (or any negative number) to disable pruning entirely.
# (TASK-34389; ADR-229.)
sync_log_retention_days = 90


# --- Model Capabilities Configuration ---
[model_capabilities]
# This section defines which models have specific capabilities like vision support.
# Users can override or extend these patterns in their config file.

# Direct model-to-capability mappings (highest priority)
[model_capabilities.models]
# OpenAI models
"gpt-4-vision-preview" = { vision = true, max_images = 1 }
"gpt-4-turbo" = { vision = true, max_images = 10 }
"gpt-4-turbo-2024-04-09" = { vision = true, max_images = 10 }
"gpt-4o" = { vision = true, max_images = 10 }
"gpt-4o-mini" = { vision = true, max_images = 10 }
"gpt-5.6-terra" = { vision = true, max_images = 10 }

# Anthropic models
"claude-3-opus-20240229" = { vision = true, max_images = 5 }
"claude-3-sonnet-20240229" = { vision = true, max_images = 5 }
"claude-3-haiku-20240307" = { vision = true, max_images = 5 }
"claude-3-5-sonnet-20240620" = { vision = true, max_images = 5 }
"claude-3-5-sonnet-20241022" = { vision = true, max_images = 5 }
"claude-sonnet-5" = { vision = true, max_images = 5 }

# Google models
"gemini-pro-vision" = { vision = true, max_images = 1 }
"gemini-1.5-pro" = { vision = true, max_images = 10 }
"gemini-1.5-flash" = { vision = true, max_images = 10 }
"gemini-2.0-flash" = { vision = true, max_images = 10 }

# Pattern-based matching for model families (fallback if not in direct mappings)
[model_capabilities.patterns]
# OpenAI patterns
OpenAI = [
    { pattern = "^gpt-4.*vision", vision = true },
    { pattern = "^gpt-4[o0](?:-mini)?", vision = true },  # gpt-4o, gpt-40, gpt-4o-mini
    { pattern = "^gpt-4.*turbo", vision = true }
]

# Anthropic patterns
Anthropic = [
    { pattern = "^claude-3", vision = true },             # All Claude 3 models have vision
    { pattern = "^claude.*opus-4", vision = true },      # Claude Opus 4 series
    { pattern = "^claude.*sonnet-4", vision = true }     # Claude Sonnet 4 series
]

# Google patterns
Google = [
    { pattern = "gemini.*vision", vision = true },
    { pattern = "gemini-[0-9.]+-(pro|flash)", vision = true },  # Modern Gemini models
    { pattern = "gemini-2\\\\.", vision = true }                 # Gemini 2.x series
]

# OpenRouter patterns (uses provider/model format)
OpenRouter = [
    { pattern = "openai/gpt-4.*vision", vision = true },
    { pattern = "openai/gpt-4[o0]", vision = true },
    { pattern = "anthropic/claude-3", vision = true },
    { pattern = "google/gemini.*vision", vision = true },
    { pattern = "google/gemini-[0-9.]+-(pro|flash)", vision = true }
]

# Default behavior for unknown models
[model_capabilities.defaults]
unknown_models_vision = false  # Whether to assume unknown models have vision capabilities
log_unknown_models = true      # Whether to log when an unknown model is queried

# --- Sections below are placeholders based on config.txt, integrate as needed ---
# [tts_settings]
# default_provider = "kokoro"
# ...

# ==========================================================
# Deep-Search Configuration
# ==========================================================
[tools]
# web_deep_search_enabled = false    # Opt-in deep-search tool; the Console picks this up on its next agent run (each run rebuilds its tool catalog fresh, no app restart needed); external MCP clients only see it on their next client launch, and only when [mcp] expose_local_tools = true; each call makes ~2x-results+3 LLM calls plus page fetches (real money on paid providers)

[SearchSettings]
# Default search backend shared by basic web_search and web_deep_search.
# A per-call engine overrides this preference without changing it. Preference
# saves apply on the next call. If absent, DuckDuckGo is used (no API key;
# web-search dependencies and network access are still required).
# search_provider_default = "duckduckgo"
# Deep-search-only defaults below. Enable the deep-search tool with
# [tools] web_deep_search_enabled = true -- the Console picks this up on its
# next agent run (no app restart needed); external MCP clients only see it on
# their next client launch, and only when [mcp] expose_local_tools = true.
# Each call makes ~2x-results+3 LLM calls plus page fetches -- real money on
# paid providers.
# relevance_analysis_llm = "openai"
# final_answer_llm = "openai"
# search_enable_subquery = false   # generate sub-questions from the query and
#   search those too. Costs one LLM call plus up to search_default_max_queries-1
#   extra searches, each carrying its own per-result relevance calls. Qodo
#   (PR 1772): with BOTH lanes active each generated facet costs TWO provider
#   calls, not one -- a web search and an academic-provider search -- so the
#   worst case is 2 x (search_default_max_queries - 1) extra calls per round,
#   plus the per-result relevance and summarization calls each returned source
#   then needs. Since task-17372 the facets ALSO drive academic-provider
#   searches, so enabling this changes both what evidence is retrieved and how
#   it is judged
#   (the facets reach the relevance prompt either way). Before that fix it
#   changed only the judging, which is why the recorded gate measurement for
#   fan-out says nothing about retrieval -- see
#   Docs/Development/research-report-eval-baseline.md.
# search_default_max_queries = 5
# search_result_max = 10
# relevance_llm_timeout_s = 30   # per relevance/summarization LLM call. Measured
#   (task-17370): per-result summarization against a local 27B took 42-131s, so
#   30 guarantees the fallback-to-source-text path on local models. Raise it if
#   you want summarized evidence rather than raw page text.
# relevance_scrape_timeout_s = 30
# research_max_iterations = 2   # rounds a local research RUN performs when it
#   does not set its own limit: round 1 researches the question, later rounds
#   research the gaps the previous synthesis left open (task-16324). 2 is the
#   shipped default because a second round measurably improved evidence --
#   resolved citation markers 24 -> 39, citation density 0.77 -> 0.95
#   (task-17370). It costs one extra search per gap, each with its own
#   per-result relevance and summarization calls, plus another synthesis and gap
#   analysis per round: the measured arm went from 3 to 12 search calls across
#   three questions and roughly tripled wall-clock. Set to 1 for single-pass
#   runs; a run's own limits always override this.
# deep_search_timeout_s = 240   # the agent runtime automatically allots this tool its own per-call timeout of this value plus ~50s slack (wait_for grace + thread-join + scheduling jitter), via LocalToolProvider.timeout_for -- independent of max_tool_call_seconds, any value here is safe

[webfetch]
# Governs the web_fetch and web_crawl tools (task-2833). When true (the
# default), every hop -- web_fetch redirects, web_crawl pages, and sitemap
# fetches -- is checked against its host's robots.txt before being
# fetched; a disallowed web_fetch hop is refused, a disallowed web_crawl
# page/sitemap is skipped and counted, not fatal. A robots.txt that can't
# be fetched or parsed fails OPEN (no restrictions applied), so a robots
# outage never bricks fetching. Set to false to disable enforcement
# entirely (no robots.txt fetches are made).
# respect_robots_txt = true

# ==========================================================
# Search Engines Configuration
# ==========================================================
[SearchEngines]
# API Keys for various search engines
bing_search_api_key = ""
google_search_api_key = ""
brave_search_api_key = ""
brave_search_ai_api_key = ""
kagi_search_api_key = ""
tavily_search_api_key = ""
# Serper (google.serper.dev) API key
serper_search_api_key = ""
# Exa (exa.ai) API key
exa_search_api_key = ""
# Yandex Cloud Search API key
yandex_search_api_key = ""
# Yandex Cloud folder id for Search API v2
yandex_search_folder_id = ""

# API URLs
bing_search_api_url = "https://api.bing.microsoft.com/v7.0/search"
google_search_api_url = "https://www.googleapis.com/customsearch/v1"
# Set your own SearX / SearXNG instance; it must allow JSON output.
searx_search_api_url = ""

# General search settings
search_result_max = 10

# Country and language settings
bing_country_code = "US"
search_engine_country_code_brave = "US"
google_search_country = "US"
google_search_engine_id = ""

# Google-specific settings
google_simp_trad_chinese = false
limit_google_search_to_country = false
google_safe_search = false

# ============================================================================
# Media Processing Configuration
# ============================================================================

[media_processing]
# Maximum file sizes for processing
max_audio_file_size_mb = 500
max_video_file_size_mb = 2000
# Whole-file read ceiling for text-shaped sources (plaintext, HTML, and the
# MOBI basic-text fallback), which are read entirely into memory.
max_text_file_size_mb = 50

# FFmpeg path (optional - will try to find automatically if not set)
# ffmpeg_path = "/usr/bin/ffmpeg"

# Temporary file cleanup
cleanup_temp_files = true
temp_dir = ""  # Empty means use system temp

[meetings]
# Meetings screen: record a call (mic + system audio) or a room (mic only).
# STT provider for the live transcript; "auto" = the Console dictation choice.
provider = "auto"
# Model override for that provider; empty = the provider's default.
model = ""
# "auto" = native system audio (macOS 14.2+ tap, Linux parec/pw-record,
# Windows WASAPI loopback). Or name an input device such as "BlackHole 2ch".
system_source = "auto"
# Input device name for the mic; empty = system default.
mic_device = ""
# Where meeting folders go; empty = <data_dir>/meetings.
recordings_dir = ""
# Keep you.wav / others.wav after the Library ingest finishes (mixed.wav is always kept).
keep_raw_tracks = true
# Re-transcribe mixed.wav offline after the meeting (needed for speaker labels).
post_transcribe = true
# Ask that offline pass for speaker diarization (needs torch + speechbrain).
post_diarize = true
# Assign speaker ids while recording instead of only in the offline pass
# (feeds the live Speakers legend). Needs a diarizer engine -- the base
# install ships one; see diarizer_backend below for the choice.
live_diarization = false
# Which engine assigns the live speaker ids when live_diarization is on:
#   "auto"        - the first engine whose packages are installed, ONNX before
#                   SpeechBrain (default; "local" is the old name for it).
#                   ONNX ships with the base install, so "auto" means ONNX
#                   unless that package is broken.
#   "onnx"        - sherpa-onnx; ships with the base install, no torch needed
#   "speechbrain" - needs the "diarization" extra (torch, torchaudio,
#                   speechbrain, scikit-learn)
#   "server"      - reserved; not available yet
# ONNX measures better on accuracy, live purity and speed; SpeechBrain keeps a
# wider margin between one enrolled voice and everyone else's
# (Docs/STT_Evaluation/task-31827/report.md). The two produce different kinds
# of voiceprint vector, so switching engines means enrolling your voice again
# -- an existing SpeechBrain voiceprint reads "needs re-enrollment" until you do.
diarizer_backend = "auto"
# Which speaker embedder the "onnx" engine uses: titanet_small,
# wespeaker_resnet34, eres2net_en or campplus_en. Also part of the voiceprint
# identity -- changing it means enrolling again.
onnx_embedder = "titanet_small"
# Where the ONNX model files live; empty = <data_dir>/models/diarization/onnx,
# fetched from the sherpa-onnx GitHub releases on the first Start (~47 MB for
# titanet_small). Point it at a directory of pre-placed files for an
# air-gapped install: the files already there are hash-verified and never
# re-fetched, and only missing ones are downloaded.
onnx_models_dir = ""
# Upper bound the local live diarizer uses when clustering voices into
# speaker ids.
max_speakers = 8
# Hybrid rooms (a call where more than one person shares the mic): also
# diarize the mic ("you") and overlap ("both") channels in call mode instead
# of always pre-naming them as you. Off by default -- turning it on means a
# mic segment may render as a diarized speaker instead of your own name.
diarize_mic_channel = false
# Tag your own speech with your display name using an enrolled voiceprint
# ("Enroll my voice" on the Meetings screen). No effect until you enroll one,
# and never used in a plain call, where the mic channel is already you.
voice_match = true
# Cosine-distance ceiling for calling a cluster you. Lower = stricter. A
# starting value: raise it if you are never matched, lower it if someone else
# is matched as you.
voice_match_threshold = 0.2
# Seconds of your speech a cluster must accumulate before it can be matched
# at all, so one short window can never claim to be you.
voice_match_min_seconds = 4
# After a meeting that matched you cleanly, offer to learn from it and
# improve the stored voiceprint (at most one offer per meeting).
voice_learn_offer = true

[dictation]
# Speculative pipeline only. Safe range: 500-3000 milliseconds.
response_eagerness_ms = 700
# Troubleshooting-only false forces half duplex. Realtime voice is unaffected.
pipeline_aec_enabled = true

[transcription]
# Default transcription provider
# Options: "faster-whisper", "parakeet-onnx", "qwen2audio", "parakeet", "canary", "parakeet-mlx", "lightning-whisper-mlx", "remote-whisper"
# Resolved for this install when this file was first created: parakeet-mlx or
# lightning-whisper-mlx on macOS when installed, otherwise faster-whisper.
# Edit this line to pin a different provider yourself -- your choice always
# wins over the platform preference.
default_provider = "__DEFAULT_TRANSCRIPTION_PROVIDER__"

# Default model for transcription
# For faster-whisper: large-v1, large-v2, large-v3, large, distil-large-v2, distil-large-v3,
#                     distil-medium.en, distil-small.en, deepdml/faster-distil-whisper-large-v3.5,
#                     deepdml/faster-whisper-large-v3-turbo-ct2, nyrahealth/faster_CrisperWhisper
#   Note: faster-whisper supports translation to English for non-English audio
# For qwen2audio: Qwen2-Audio-7B-Instruct
# For parakeet: nvidia/parakeet-tdt-1.1b, nvidia/parakeet-rnnt-1.1b, nvidia/parakeet-ctc-1.1b,
#               nvidia/parakeet-tdt-0.6b, nvidia/parakeet-rnnt-0.6b, nvidia/parakeet-ctc-0.6b,
#               nvidia/parakeet-tdt-0.6b-v2
# For canary: nvidia/canary-1b-flash, nvidia/canary-1b
#   Note: Canary supports multilingual ASR and translation between en, de, es, fr
# For remote-whisper: Depends on your server (e.g., "whisper-1" for OpenAI)
default_model = "distil-large-v3"

# Default language for transcription (use "auto" for automatic detection)
# For source language in transcription
default_language = "en"

# Default source language (overrides default_language if specified)
# Used for explicitly setting the audio's language
default_source_language = ""

# Default target language for translation (leave empty for no translation)
# Supported by:
#   - faster-whisper: Only supports translation to English ("en")
#   - canary: Supports translation between en, de, es, fr
default_target_language = ""

# Device to use for transcription
# Options: "cpu", "cuda", "mps" (Apple Silicon)
device = "cpu"

# Compute type for faster-whisper
# Options: "int8", "float16", "float32"
compute_type = "int8"

# Explicit local directory containing the Parakeet v2 INT8 ONNX bundle.
# parakeet-onnx never downloads model files implicitly.
parakeet_onnx_model_dir = ""

# Exact v2/v3 × INT8/F32 external-source records. External files remain
# user-owned and are never copied or managed implicitly.
parakeet_external_sources = {}

# Voice Activity Detection
use_vad_by_default = false

# Speaker diarization (not yet fully implemented)
use_diarization_by_default = false

# Chunk length for long audio processing (in seconds)
# Used by Canary model for efficient processing of long audio files
chunk_length_seconds = 40.0

[diarization]
# Speaker diarization configuration
enabled = false  # Enable/disable diarization by default

# Voice Activity Detection (VAD) settings
vad_threshold = 0.5  # Sensitivity for speech detection (0.0-1.0)
vad_min_speech_duration = 0.25  # Minimum speech duration in seconds
vad_min_silence_duration = 0.25  # Minimum silence duration in seconds

# Segmentation settings for speaker analysis
segment_duration = 2.0  # Duration of analysis segments in seconds
segment_overlap = 0.5  # Overlap between segments in seconds
min_segment_duration = 1.0  # Minimum segment duration
max_segment_duration = 3.0  # Maximum segment duration

# Speaker embedding model
embedding_model = "speechbrain/spkrec-ecapa-voxceleb"  # Model for speaker embeddings
embedding_device = "auto"  # Device: "auto", "cuda", "cpu"

# Clustering settings
clustering_method = "spectral"  # Method: "spectral" or "agglomerative"
similarity_threshold = 0.85  # Threshold for speaker similarity (0.0-1.0)
min_speakers = 1  # Minimum expected speakers
max_speakers = 10  # Maximum expected speakers

# Post-processing
merge_threshold = 0.5  # Time gap in seconds to merge same-speaker segments
min_speaker_duration = 3.0  # Minimum total duration per speaker in seconds

[transcription.remote_whisper]
# Remote Whisper OpenAI API compatible transcription backend
# Enable this to use a custom transcription server instead of local models
enabled = false

# API endpoint URL
# Examples:
#   - OpenAI: "https://api.openai.com/v1/audio/transcriptions"
#   - Local server: "http://localhost:8000/v1/audio/transcriptions"
#   - Custom endpoint: "https://your-whisper-server.com/transcribe"
api_endpoint = "http://localhost:8000/v1/audio/transcriptions"

# API authentication (leave empty if not required)
api_key_env_var = "REMOTE_WHISPER_API_KEY"  # Environment variable name
# api_key = ""  # Direct API key (less secure - use env var instead)

# Model to use (e.g., "whisper-1" for OpenAI, or your custom model name)
model = "whisper-1"

# Request timeout in seconds
timeout = 300

# Response format: "json", "text", "srt", "verbose_json", "vtt"
response_format = "json"

# Optional parameters
temperature = 0.0  # Sampling temperature (0-1)
# prompt = ""  # Optional prompt to guide transcription style

# Additional custom parameters (will be passed as-is to the API)
# Format: key = "value"
# Example:
# [transcription.remote_whisper.additional_params]
# custom_param = "custom_value"

[local_ingestion]
# YouTube/URL download settings
enable_url_downloads = true
use_cookies_for_downloads = false
cookie_file_path = ""

# Audio extraction settings for videos
extract_audio_format = "mp3"
audio_bitrate = "192k"
audio_sample_rate = 44100

# Processing defaults
keep_original_files = false
auto_analyze_transcripts = true

# Parallel processing
max_concurrent_processes = 2

[mcp]
# Model Context Protocol (MCP) settings
enabled = false  # Enable MCP server functionality
server_name = "tldw_chatbook"
server_version = "0.1.0"
transport = "stdio"  # "stdio" for Claude Desktop, "http" for web-based clients
http_port = 3000  # Port for HTTP transport
allowed_clients = ["claude-desktop", "localhost"]  # List of allowed client identifiers

# Feature toggles
expose_tools = true  # Expose tools (chat, search, etc.)
expose_resources = true  # Expose resources (conversations, notes, etc.)
expose_prompts = true  # Expose prompt templates

# Security settings
require_auth = false  # Require authentication (not implemented yet)
rate_limit = 100  # Max requests per minute per client
max_concurrent_requests = 10  # Max concurrent requests
# approval_timeout_seconds = 0  # Human approval ceiling for Console cards and live MCP confirmations: 0 (default) waits indefinitely; e.g. 120 auto-denies undecided calls after 120s

# expose_local_tools = false   # expose workspace, web, and Watchlists agent tools (fs_*/git_*/web_*/watchlists_*) to external MCP clients; each tool remains permission-gated
# expose_character_tools = false   # expose character_search and character_get to external MCP clients (independent of expose_local_tools and [tools] character_tools_enabled); each tool remains permission-gated

# Tool-specific settings
[mcp.tools]
chat_default_provider = "openai"
chat_default_temperature = 0.7
chat_default_max_tokens = 4096
search_default_limit = 10
enable_media_ingestion = true  # Allow media ingestion via MCP

# Resource-specific settings
[mcp.resources]
max_list_limit = 100  # Maximum items to return in list operations
default_list_limit = 10  # Default items to return in list operations
enable_binary_resources = false  # Allow serving binary resources (images, etc.)

# Prompt-specific settings
[mcp.prompts]
enable_custom_prompts = true  # Allow custom prompt creation
max_prompt_length = 10000  # Maximum prompt length in characters

# Subscription system configuration
[subscriptions]
enabled = true
default_check_interval = 3600  # 1 hour in seconds
max_concurrent_checks = 10
check_timeout_seconds = 30
auto_pause_after_failures = 10  # Seeds auto_pause_threshold for NEW subscriptions only (task-1410); an explicit per-subscription value always overrides, and existing subscriptions keep their stored value
enable_background_checking = true
default_priority = 3  # 1-5, higher is more important

# Rate limiting
[subscriptions.rate_limiting]
global_requests_per_minute = 60
per_domain_requests_per_minute = 10
retry_after_rate_limit = true

# Performance settings
[subscriptions.performance]
use_connection_pooling = true
enable_response_caching = true
cache_ttl_seconds = 300
use_http2 = true
enable_compression = true

# Content processing
[subscriptions.content_processing]
default_analysis_prompt = "Summarize the key points and provide actionable insights."
auto_analyze_new_items = false
save_analysis_only = false
extract_keywords = true
max_keywords = 15

# Briefing/newsletter generation
[subscriptions.briefings]
enabled = true
default_format = "markdown"  # markdown, html, pdf
save_to_notes = true
email_notifications = false
morning_digest_time = "06:00"  # 24-hour format

# Default templates for common subscription types
[subscriptions.templates.tech_news]
name = "Tech News Feed"
type = "rss"
check_frequency = 1800  # 30 minutes
priority = 4
extraction_method = "auto"
auto_ingest = true
tags = ["tech", "news"]

[subscriptions.templates.documentation]
name = "Documentation Monitor"
type = "url"
check_frequency = 86400  # Daily
change_threshold = 0.05  # 5% change threshold
priority = 3
tags = ["docs", "reference"]

# GitHub configuration for repository browsing
[github]
# Personal access token for accessing private repositories
# Create a token at: https://github.com/settings/tokens
# Required scopes: repo (for private repos), public_repo (for public only)
api_token = ""  # Leave empty to only access public repositories
api_token_env_var = "GITHUB_API_TOKEN"  # Environment variable to check first

# Rate limiting settings
enable_rate_limit_handling = true  # Automatically handle rate limit responses
cache_ttl_seconds = 300  # Cache API responses for 5 minutes
max_retries = 3  # Maximum retries for failed requests

# Default behavior
default_branch = "main"  # Default branch to use if not specified
show_hidden_files = false  # Show files starting with . (except .gitignore)
respect_gitignore = true  # Respect .gitignore rules when displaying files

# Performance settings
lazy_load_tree = true  # Load repository tree on-demand
max_tree_depth = 10  # Maximum depth for recursive tree loading
batch_file_requests = true  # Batch multiple file content requests
max_concurrent_requests = 5  # Maximum concurrent API requests

# UI preferences
auto_expand_small_folders = true  # Auto-expand folders with < 5 items
highlight_binary_files = true  # Visually distinguish binary files
show_file_sizes = true  # Display file sizes in the tree
default_preview_language = "auto"  # Language for syntax highlighting

# Export settings
default_export_format = "compilation"  # Default format: compilation, zip, markdown
include_file_metadata = false  # Include metadata in exports
max_export_size_mb = 100  # Maximum size for exports in MB

# Selection profiles directory
profiles_directory = "~/.config/tldw_cli/github_profiles"  # Where to store selection profiles

[briefings_feed_server]
# Opt-in, session-only static file server for ONE exported briefings podcast
# feed directory at a time (task-1760). This is its own section on purpose --
# it is unrelated to [web_server] below: that runs the whole chatbook UI in a
# browser instead of a terminal (a separate, mutually exclusive process mode)
# and has no route that serves a directory you choose. Nothing here ever
# auto-starts anything -- these are only the defaults the Watchlists
# Artifacts pane's Serve action uses when you press it; serving always
# requires that explicit action. See Docs/User_Guide/watchlists.md's
# "Serving an exported feed" section for the full security posture
# (no authentication, localhost-only unless you widen bind, recursive
# file serving with directory listings disabled, so point this at a
# dedicated export folder rather than a general-purpose one like $HOME).
# A blank/invalid bind value here falls back to loopback rather than
# silently widening exposure.
bind = "127.0.0.1"  # Loopback only. Widen only if you understand the exposure -- there is no authentication.
port = 0  # 0 = pick any free port each time; set a fixed port to reuse the same URL

[canvas]
# Effective preference order is a non-empty environment override, then this
# saved TOML value, then the default. TLDW_CANVAS_ENABLED and
# TLDW_CANVAS_AUTO_OPEN_ON_CREATE accept only true or false (case-insensitive);
# malformed non-empty values fail closed. Hard quotas have no env overrides.
# One global execution/delivery/tool-advertisement kill switch. Turning this
# off preserves stored Canvas revisions and Chatbook export/import data.
enabled = true
# Successful assistant canvas_create operations open the preview automatically.
# Updates hot-reload an already-open preview but never force a new browser open.
auto_open_on_create = true

[web_server]
# Web server configuration for running tldw_chatbook in a browser
enabled = true  # Enable web server functionality
host = "localhost"  # Host address to bind to
port = 8000  # Port to bind to
title = "tldw chatbook"  # Title for the web page
font_size = 16  # Browser terminal font size in CSS pixels (16px is approximately 12pt)
debug = false  # Enable debug mode for development
# Remote access is denied unless a dedicated credential resolves in this order:
# TLDW_CHATBOOK_WEB_ACCESS_TOKEN, this access_token field, then the OS keyring
# service "tldw_chatbook_web" / account "access_token". Do not reuse an LLM,
# MCP, or tldw_api credential. Prefer environment or keyring over plaintext TOML.
access_token = ""
# Wildcard binds require the exact browser-facing origin. Use https:// here for
# either direct TLS or an explicitly trusted TLS-terminating reverse proxy.
public_url = ""
# Direct TLS: set both files or neither. The private key remains host-local.
tls_certificate = ""
tls_private_key = ""
# Reverse-proxy headers are ignored unless the immediate peer is one of these
# literal IP addresses. The proxy must terminate HTTPS and overwrite forwarded
# host, scheme, and client headers rather than appending untrusted values.
trusted_proxy_addresses = []
# Emergency development escape hatch only. This exposes terminal/chat/Canvas
# content and credentials to network observers and emits a prominent warning.
allow_insecure_remote_http = false
"""

# Resolve the `[transcription] default_provider` placeholder to this platform's
# preferred engine before the template is parsed or ever written to disk
# (task-867). `CONFIG_TOML_CONTENT` feeds both `DEFAULT_CONFIG_FROM_TOML`
# below -- the baseline every config load merges the user's file on top of --
# and the literal bytes a fresh install writes to `config.toml`, so this one
# substitution fixes both without any reader needing to special-case an
# absent key.
CONFIG_TOML_CONTENT = CONFIG_TOML_CONTENT.replace(
    "__DEFAULT_TRANSCRIPTION_PROVIDER__", _default_stt_provider_for_platform()
)
# Same single-substitution discipline for the splash duration (PR #2329):
# the placeholder keeps the literal out of the template and every reader --
# the widget, the app fallback, the Settings viewer -- shares the one
# constant from Constants.py.
CONFIG_TOML_CONTENT = CONFIG_TOML_CONTENT.replace(
    "__DEFAULT_SPLASH_DURATION__", str(DEFAULT_SPLASH_DURATION_SECONDS)
)

try:
    DEFAULT_CONFIG_FROM_TOML: Dict[str, Any] = tomllib.loads(CONFIG_TOML_CONTENT)
except tomllib.TOMLDecodeError as e:
    logger.critical(
        f"FATAL: Could not parse internal DEFAULT_CONFIG_TOML_CONTENT: {e}. Application cannot start correctly."
    )
    DEFAULT_CONFIG_FROM_TOML = {}  # Should not happen with valid TOML string


# --- Primary Configuration Loading Logic for the CLI ---
_CONFIG_CACHE: Optional[Dict[str, Any]] = None
_CONFIG_CACHE_SOURCE: Optional[Path] = None
#: TASK-26038: (mtime_ns, size) of the config file at its last successful
#: load, and the last monotonic time we statted it. A THROTTLED inline
#: metadata check on the read path picks up external edits without a
#: filesystem watcher or a polling thread, while keeping TASK-21124's
#: near-zero hot path (one stat per throttle window, not per read).
_CONFIG_FILE_STAMP: Optional[tuple[int, int]] = None
_CONFIG_STAT_CHECKED_MONOTONIC: float = 0.0
#: How often (seconds) the read path may re-stat the file. An external edit
#: is picked up on the next read after this window. Small enough to feel
#: immediate, large enough that a burst of ~400 get_cli_setting calls in one
#: render statts at most once.
_CONFIG_STAT_THROTTLE_SECONDS: float = 1.0
_FIRST_PROFILE_CREATED_THIS_SESSION = False


def first_profile_created_this_session() -> bool:
    """Return whether this process created the active profile config.

    Returns:
        ``True`` when this process created the active profile configuration;
        otherwise ``False``.
    """
    return _FIRST_PROFILE_CREATED_THIS_SESSION


# --- TASK-26039: advisory unknown/deprecated config-key validation ---

#: Dotted section prefixes whose sub-keys are legitimately user-defined, so
#: unknown-key reporting must stay silent under them (AC#6). Kept conservative
#: -- only genuinely dynamic-keyed sections -- so real typos elsewhere still
#: surface. Each entry is a tuple path prefix.
_FREEFORM_CONFIG_PREFIXES: tuple[tuple[str, ...], ...] = (
    ("agents",),  # deliberately EMPTY in the default shape: the
    # authoritative defaults live in
    # Agents/agent_service.py (two-homes drift),
    # so documented overrides here would all flag
    # as unknown (Qodo #13, PR #2301)
    ("console", "reasoning_history_overrides"),
    ("console", "reasoning_native_tool_overrides"),
    ("api_settings",),  # provider configs incl. user-added custom providers
    ("providers",),  # provider display sections + model lists
    ("model_capabilities", "models"),  # arbitrary model names
    ("model_capabilities", "patterns"),  # arbitrary model-name patterns
    ("SearchEngines",),  # per-engine configs
    ("Prompts",),  # user prompt content
    ("prompts",),
)

#: Keys/sections known to be renamed or removed, mapped to their replacement
#: dotted path (AC#3). A user path equal to a key here, or nested under it, is
#: reported as deprecated (naming the replacement) instead of unknown.
_DEPRECATED_CONFIG_KEYS: Dict[str, str] = {
    # Legacy provider keys: `[API] <provider>_api_key` was superseded by the
    # `[api_settings.<provider>] api_key` table (still honored as the lowest
    # -precedence fallback -- see _normalize_legacy_provider_api_key).
    "API": "api_settings",
}


@dataclass(frozen=True)
class ConfigKeyFinding:
    """One advisory config-key finding."""

    path: str  # dotted path, e.g. "general.focus_mdoe"
    kind: str  # "unknown" | "deprecated"
    suggestion: Optional[str] = None  # near-miss key or replacement path


def _is_freeform_config_path(path: tuple[str, ...]) -> bool:
    return any(
        len(path) >= len(prefix) and path[: len(prefix)] == prefix
        for prefix in _FREEFORM_CONFIG_PREFIXES
    )


def _deprecated_config_replacement(path: tuple[str, ...]) -> Optional[str]:
    """Return the replacement dotted path if ``path`` is (under) a deprecated key."""
    for i in range(1, len(path) + 1):
        prefix = ".".join(path[:i])
        replacement = _DEPRECATED_CONFIG_KEYS.get(prefix)
        if replacement is not None:
            tail = path[i:]
            return ".".join((replacement, *tail)) if tail else replacement
    return None


def validate_config_keys(
    user_config: Mapping[str, Any],
    reference: Optional[Mapping[str, Any]] = None,
) -> list[ConfigKeyFinding]:
    """Report keys present in ``user_config`` that no code reads (TASK-26039).

    Advisory only -- the caller never rejects the config. A key absent from the
    ``reference`` shape (the programmatic defaults) is ``unknown``; a near miss
    against a sibling reference key carries that suggestion (AC#2); a key known
    to be renamed is ``deprecated`` with its replacement (AC#3); nested tables
    are covered (AC#5); user-extensible sections are exempt (AC#6).
    """
    if reference is None:
        reference = DEFAULT_CONFIG_FROM_TOML
    findings: list[ConfigKeyFinding] = []

    def _walk(user: Mapping[str, Any], ref: Mapping[str, Any], path: tuple[str, ...]):
        for key, value in user.items():
            here = (*path, key)
            replacement = _deprecated_config_replacement(here)
            if replacement is not None:
                findings.append(
                    ConfigKeyFinding(".".join(here), "deprecated", replacement)
                )
                continue
            if key in ref:
                ref_value = ref[key]
                if isinstance(value, Mapping) and isinstance(ref_value, Mapping):
                    if not _is_freeform_config_path(here):
                        _walk(value, ref_value, here)
                continue
            if _is_freeform_config_path(here):
                continue
            siblings = [k for k in ref.keys() if isinstance(k, str)]
            match = difflib.get_close_matches(key, siblings, n=1, cutoff=0.8)
            suggestion = ".".join((*path, match[0])) if match else None
            findings.append(ConfigKeyFinding(".".join(here), "unknown", suggestion))

    _walk(user_config, reference, ())
    return findings


def format_config_key_report(findings: Sequence[ConfigKeyFinding]) -> str:
    """Render key findings as a short advisory block (empty string when none)."""
    if not findings:
        return ""
    lines: list[str] = []
    for f in findings:
        if f.kind == "deprecated":
            lines.append(f"deprecated key '{f.path}' -> use '{f.suggestion}'")
        elif f.suggestion:
            lines.append(f"unknown key '{f.path}' (did you mean '{f.suggestion}'?)")
        else:
            lines.append(f"unknown key '{f.path}' (no code reads it)")
    return "Advisory: " + "; ".join(lines)


#: TASK-26040: the config file's schema version. Bumped when a numbered
#: migration is added to ``_CONFIG_MIGRATIONS``; a fresh config is created
#: carrying this version. An unversioned (pre-existing) file is treated as
#: the baseline (0) and migrated forward, never rejected.
CONFIG_SCHEMA_VERSION_KEY = "config_schema_version"
_CURRENT_CONFIG_SCHEMA_VERSION = 1

#: Numbered stepwise migrations: ``{target_version: fn(config) -> config}``.
#: Each transforms a config AT (target-1) into (target). Empty today -- this
#: is the first versioned config -- but the runner is exercised by tests and
#: ready for the first key rename, mirroring the DB migration pattern.
_CONFIG_MIGRATIONS: Dict[int, Any] = {}


def migrate_config_forward(
    config: Dict[str, Any],
) -> tuple[Dict[str, Any], bool, Optional[str]]:
    """Run stepwise forward migrations on one config (TASK-26040).

    Returns ``(migrated, changed, conflict)``:
    * ``migrated`` -- the config transformed to the current version (or the
      input unchanged when already current, or when a conflict blocks it).
    * ``changed`` -- whether anything (including a first version stamp) changed.
    * ``conflict`` -- a human-readable reason when the config is from a NEWER
      version than this code understands (AC#5); the config is returned
      untouched rather than mangled.
    """
    version = config.get(CONFIG_SCHEMA_VERSION_KEY, 0)
    try:
        version = int(version)
    except (TypeError, ValueError):
        version = 0  # a junk version stamp is treated as the baseline
    if version > _CURRENT_CONFIG_SCHEMA_VERSION:
        return (
            config,
            False,
            (
                f"config schema version {version} is newer than this "
                f"application supports ({_CURRENT_CONFIG_SCHEMA_VERSION}); "
                "not migrating -- upgrade the application or restore an "
                "older config."
            ),
        )
    if version == _CURRENT_CONFIG_SCHEMA_VERSION:
        return config, False, None
    migrated = copy.deepcopy(config)
    for target in range(version + 1, _CURRENT_CONFIG_SCHEMA_VERSION + 1):
        migration = _CONFIG_MIGRATIONS.get(target)
        if migration is not None:
            migrated = migration(migrated)
    migrated[CONFIG_SCHEMA_VERSION_KEY] = _CURRENT_CONFIG_SCHEMA_VERSION
    return migrated, True, None


#: TASK-26040: set when the loaded config declares a schema version NEWER
#: than this application understands. The config is served untouched (never
#: mangled by a downgrade migration); this signal lets ``app.py`` surface a
#: loud, user-visible warning, mirroring ``ConfigLoadFailure``.
_CONFIG_SCHEMA_CONFLICT: Optional[str] = None


def get_config_schema_conflict() -> Optional[str]:
    """Return the newer-than-supported schema warning, if the last load hit one."""
    return _CONFIG_SCHEMA_CONFLICT


def _has_pending_config_migration(from_version: int) -> bool:
    """Whether any real migration FUNCTION exists between ``from_version`` and now.

    A bare version stamp (no function in range) is NOT worth a full-file
    rewrite -- it would strip the user's hand-written comments -- so the stamp
    rides the next natural save instead. Only an actual content transform
    forces the persist path.
    """
    return any(
        _CONFIG_MIGRATIONS.get(v) is not None
        for v in range(from_version + 1, _CURRENT_CONFIG_SCHEMA_VERSION + 1)
    )


def migrate_config_file_if_needed() -> Optional[Path]:
    """Persist a forward migration of the on-disk config (TASK-26040 AC#3/#4).

    Runs under the write lock. Reads the raw file, and only when an actual
    migration function must run does it back up the original and atomically
    rewrite the migrated result. A failed migration raises before any write,
    leaving the original file untouched. Returns the backup path when a
    migration was written, else ``None`` (no file, already current, bare
    stamp only, or a newer-than-supported version).
    """
    if not _CONFIG_MIGRATIONS:
        return None  # no real migration exists yet -- free no-op
    config_path = _get_effective_config_path()
    with _config_write_lock(config_path):
        current_serialized = _try_read_cli_config_serialized_unlocked(config_path)
        if current_serialized is None:
            return None  # no file yet -- creation stamps the version itself
        raw = tomllib.loads(current_serialized)
        raw_version = raw.get(CONFIG_SCHEMA_VERSION_KEY, 0)
        try:
            raw_version = int(raw_version)
        except (TypeError, ValueError):
            raw_version = 0
        if raw_version >= _CURRENT_CONFIG_SCHEMA_VERSION:
            return None
        if not _has_pending_config_migration(raw_version):
            return None
        migrated, changed, conflict = migrate_config_forward(raw)
        if conflict is not None or not changed:
            return None
        backup_path = _write_serialized_config_artifact_unlocked(
            _advanced_backup_path(config_path),
            current_serialized,
            config_path=config_path,
        )
        persisted = _config_data_for_persistence(migrated)
        raw_written = _write_raw_cli_config_unlocked(config_path, persisted)
        _publish_runtime_config_unlocked(
                raw_config=raw_written, config_path=config_path
            )
        return backup_path


#: (path, mtime_ns, size) of the corrupt file most recently preserved aside,
#: with the aside path. On a persistent parse failure the cache is never
#: populated, so every read re-enters this path; without this dedup a live TUI
#: would copy the same broken file and mint a new .corrupt-<stamp> on every
#: read (lane-7 review Important #2). Only a genuinely changed corrupt file
#: (the user edited it again, still broken) earns a fresh aside.
_LAST_PRESERVED_CORRUPT_KEY: Optional[tuple[str, int, int]] = None
_LAST_PRESERVED_CORRUPT_ASIDE: Optional[Path] = None


def _preserve_corrupt_config_aside(config_path: Path) -> Optional[Path]:
    """Copy an unparseable config file aside so the user's edits survive.

    TASK-26036 AC#2. Best-effort: a failure to copy must never break the
    fallback path (the whole point is resilience), so any error is logged
    and swallowed. Deduplicated by the corrupt file's (mtime_ns, size) so a
    persistently-broken file is preserved once, not on every read. Returns
    the aside path (freshly made or the prior one for an unchanged file).
    """
    global _LAST_PRESERVED_CORRUPT_KEY, _LAST_PRESERVED_CORRUPT_ASIDE
    try:
        source = Path(config_path)
        if not source.exists():
            return None
        stat = source.stat()
        key = (str(source), stat.st_mtime_ns, stat.st_size)
        if (
            key == _LAST_PRESERVED_CORRUPT_KEY
            and _LAST_PRESERVED_CORRUPT_ASIDE is not None
            and _LAST_PRESERVED_CORRUPT_ASIDE.exists()
        ):
            return _LAST_PRESERVED_CORRUPT_ASIDE
        stamp = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%S")
        aside = source.with_name(f"{source.name}.corrupt-{stamp}")
        shutil.copy2(source, aside)
        logger.warning(f"Preserved unparseable config {source} at {aside}")
        _LAST_PRESERVED_CORRUPT_KEY = key
        _LAST_PRESERVED_CORRUPT_ASIDE = aside
        return aside
    except Exception as exc:  # noqa: BLE001 -- resilience path never raises
        logger.warning(f"Could not preserve corrupt config aside: {exc!r}")
        return None


class ConfigLoadFailure(NamedTuple):
    """The most recent config parse failure -- TASK-13157.

    ``_load_cli_config_bootstrap_unlocked`` already logs a TOMLDecodeError
    via loguru, but both of its callers (``load_cli_config_and_ensure_
    existence`` and ``load_settings``) discard the ``_ConfigBootstrapResult.
    succeeded`` flag and hand back bare in-memory defaults with no signal a
    caller can act on. A live-verification incident found this produces a
    silent, user-invisible fallback to the ``default_user`` profile -- the
    loaded config simply has no ``[general] users_name`` because the file
    that would have carried it never parsed. This module-level record is the
    "user-visible path" half of the fix: ``app.py`` reads it once at boot
    (mirroring the existing ``_instance_lock_status``/``_maybe_warn_second_
    instance`` pattern) and surfaces a persistent notification naming the
    file and the parse error, instead of leaving the degradation invisible.
    """

    path: Path
    message: str


#: Set inside the TOMLDecodeError branch below, cleared on the next
#: successful bootstrap. See ``ConfigLoadFailure`` and ``get_config_load_
#: failure()``.
_LAST_CONFIG_LOAD_FAILURE: Optional[ConfigLoadFailure] = None


def get_config_load_failure() -> Optional[ConfigLoadFailure]:
    """Return the most recent CLI config TOML parse failure, if any.

    ``None`` means the last bootstrap attempt (or no attempt yet) did not
    hit a TOML parse error -- it says nothing about OTHER bootstrap failure
    modes (permission/posture errors, decryption failures), which already
    have their own handling and are out of scope for this signal.
    """

    return _LAST_CONFIG_LOAD_FAILURE


class _ConfigBootstrapResult(NamedTuple):
    config: Dict[str, Any]
    succeeded: bool


@_config_participants.guarded
def _load_cli_config_bootstrap_unlocked(
    force_reload: bool = False,
) -> _ConfigBootstrapResult:
    global _CONFIG_CACHE, _CONFIG_CACHE_SOURCE, _LAST_CONFIG_LOAD_FAILURE
    global _FIRST_PROFILE_CREATED_THIS_SESSION
    global _CONFIG_FILE_STAMP, _CONFIG_STAT_CHECKED_MONOTONIC
    global _CONFIG_SCHEMA_CONFLICT
    config_path = _get_effective_config_path()
    if (
        _CONFIG_CACHE is not None
        and _CONFIG_CACHE_SOURCE == config_path
        and not force_reload
    ):
        return _ConfigBootstrapResult(_CONFIG_CACHE, True)

    # TASK-26036: retain the last successfully loaded config for THIS path
    # before clearing the cache, so a parse failure on a force-reload can
    # serve it instead of reverting security-relevant settings to defaults.
    retained_good = (
        copy.deepcopy(_CONFIG_CACHE)
        if _CONFIG_CACHE is not None and _CONFIG_CACHE_SOURCE == config_path
        else None
    )
    _CONFIG_CACHE = None
    _CONFIG_CACHE_SOURCE = None
    # TASK-26040 (lane-7 review Minor): clear any prior schema conflict so a
    # later parse-failure load does not retain a stale "newer version" warning.
    _CONFIG_SCHEMA_CONFLICT = None

    # Start with the programmatic defaults defined in CONFIG_TOML_CONTENT
    loaded_config = copy.deepcopy(DEFAULT_CONFIG_FROM_TOML)
    bootstrap_succeeded = False
    application_directory = application_owned_config_directory(config_path)
    if application_directory is not None:
        directory_result = secure_private_directory(
            application_directory,
            create=True,
            application_owned=True,
        )
        _report_config_path_posture(directory_result, target_kind="directory")
    logger.info(f"Attempting to load CLI config from: {config_path}")
    try:
        with open_private_binary(config_path) as opened:
            _report_config_path_posture(opened.result)
            user_config_from_file = tomllib.load(opened.stream)
        # TASK-26040: migrate the RAW file forward before the default merge --
        # an unversioned file must be seen as the baseline (0), not inherit the
        # default's current version and skip its migrations. A newer-than-code
        # version is served untouched with a recorded conflict warning.
        user_config_from_file, _schema_changed, _schema_conflict = (
            migrate_config_forward(user_config_from_file)
        )
        from tldw_chatbook.Utils.reasoning_config import (
            migrate_legacy_reasoning_history,
        )

        migrate_legacy_reasoning_history(user_config_from_file)
        _CONFIG_SCHEMA_CONFLICT = _schema_conflict
        if _schema_conflict is not None:
            logger.warning(_schema_conflict)
        loaded_config = deep_merge_dicts(loaded_config, user_config_from_file)
        logger.info(f"Successfully loaded and merged CLI config from {config_path}")
        decryption = _decrypt_config_section_with_status(loaded_config, strict=True)
        if decryption.succeeded:
            loaded_config = decryption.config
            bootstrap_succeeded = True
        else:
            loaded_config = copy.deepcopy(DEFAULT_CONFIG_FROM_TOML)
    except FileNotFoundError:
        logger.info(
            f"CLI Config file not found at {config_path}. Creating with default values from CONFIG_TOML_CONTENT."
        )
        created = create_private_text(
            config_path,
            CONFIG_TOML_CONTENT,
            application_owned_directory=application_directory,
        )
        _report_config_path_posture(created)
        logger.info(f"Created default CLI config file at {config_path}")
        loaded_config["_first_run"] = True
        _FIRST_PROFILE_CREATED_THIS_SESSION = True
        bootstrap_succeeded = True
    except PrivatePathError as exc:
        if application_directory is not None and exc.result.reason == "missing_parent":
            logger.info(
                f"CLI Config file not found at {config_path}. Creating with default values from CONFIG_TOML_CONTENT."
            )
            created = create_private_text(
                config_path,
                CONFIG_TOML_CONTENT,
                application_owned_directory=application_directory,
            )
            _report_config_path_posture(created)
            logger.info(f"Created default CLI config file at {config_path}")
            loaded_config["_first_run"] = True
            _FIRST_PROFILE_CREATED_THIS_SESSION = True
            bootstrap_succeeded = True
        else:
            raise
    except RecoveryRequired:
        raise
    except tomllib.TOMLDecodeError as e:
        logger.opt(exception=True).error(
            f"Error decoding CLI TOML config file {config_path}: {e}. Using internal defaults + any previous successful load."
        )
        # TASK-13157: this except branch is the exact point a real user's
        # config parse failure previously vanished -- logged here, then
        # thrown away by every caller (`load_cli_config_and_ensure_
        # existence`/`load_settings` both return only `.config`, never
        # `.succeeded`). Recording it lets `app.py` surface a loud,
        # user-visible notification instead of a silent `default_user`
        # fallback (see `ConfigLoadFailure`/`get_config_load_failure`).
        # TASK-26036: preserve the unparseable file aside (never lose the
        # user's edits) and serve the LAST KNOWN GOOD config instead of
        # built-in defaults, so a mid-edit break can't silently revert
        # encryption/database/provider settings.
        aside = _preserve_corrupt_config_aside(config_path)
        in_effect = "built-in defaults"
        if retained_good is not None:
            loaded_config = copy.deepcopy(retained_good)
            in_effect = "the last successfully loaded configuration"
        _LAST_CONFIG_LOAD_FAILURE = ConfigLoadFailure(
            path=config_path,
            message=(
                f"{e} (now serving {in_effect}"
                + (f"; the unreadable file was kept at {aside.name}" if aside else "")
                + ")"
            ),
        )
    except Exception as e:
        logger.opt(exception=True).error(
            f"An unexpected error occurred while loading CLI config {config_path}: {e}. Using internal defaults + any previous successful load."
        )

    if bootstrap_succeeded:
        _CONFIG_CACHE = loaded_config
        _CONFIG_CACHE_SOURCE = config_path
        # TASK-26038: stamp the file we just loaded so a later external edit
        # is detected, and reset the throttle so the next read re-checks.
        _CONFIG_FILE_STAMP = _current_config_file_stamp(config_path)
        _CONFIG_STAT_CHECKED_MONOTONIC = time.monotonic()
        # A later successful load (e.g. the user or the app repaired the
        # file) retires any previously recorded parse failure.
        _LAST_CONFIG_LOAD_FAILURE = None
    # Log the keys of the configuration being returned to verify its structure
    logger.debug(
        f"load_cli_config_and_ensure_existence returning config with top-level keys: {list(loaded_config.keys())}"
    )
    if "api_settings" in loaded_config:
        logger.debug(
            f"  'api_settings' found with keys: {list(loaded_config.get('api_settings', {}).keys())}"
        )
    else:
        logger.warning(
            "  'api_settings' key NOT FOUND in the loaded configuration for load_cli_config_and_ensure_existence."
        )

    return _ConfigBootstrapResult(loaded_config, bootstrap_succeeded)


def _warm_config_cache_hit() -> Optional[Dict[str, Any]]:
    """Return the installed config on a warm hit, or None to fall through.

    TASK-32804.1: `get_cli_setting` has ~400 call sites, many on the Textual
    event loop, and each funnels into `_load_cli_config_bootstrap`, which is
    `@config_participants.guarded` -- so every read, even a warm cache hit,
    paid the ADR-126 admission handshake (`operation(...)`). Measured at
    ~4.8 ms per warm read, tens of ms per second of streaming on the paint
    loop. The handshake protects the file/build lifecycle, not a pure
    in-memory cache read, so a warm hit is resolved HERE, ahead of the
    guarded call, amortising the handshake to actual (re)derivations.

    This repeats the guarded fast path's exact lock-free check (all atomic
    global reads, plus the throttled external-edit stat), and returns None
    on any miss so the guarded bootstrap runs unchanged. The soundness
    reasoning is `_load_cli_config_bootstrap`'s (a brand-new dict per
    publish; a miss re-reads; the edit check only turns a hit into a
    forced re-read, never a false hit).
    """
    config_path = _get_effective_config_path()
    generation_before = _CONFIG_GENERATION
    cached_config = _CONFIG_CACHE
    cached_source = _CONFIG_CACHE_SOURCE
    if (
        cached_config is not None
        and cached_source == config_path
        and _CONFIG_CACHE is cached_config
        and _CONFIG_GENERATION == generation_before
        and not _external_edit_detected(config_path)
    ):
        return cached_config
    return None


def load_cli_config_and_ensure_existence(
    force_reload: bool = False,
) -> Dict[str, Any]:  # Renamed from load_cli_config
    """Load the merged CLI configuration, creating the file if absent.

    Reads ~/.config/tldw_cli/config.toml, creating it from
    CONFIG_TOML_CONTENT defaults on first run, and uses those programmatic
    defaults as the base for the merge. A warm cache hit is served without
    the ADR-126 admission handshake (TASK-32804.1).

    Args:
        force_reload: Rebuild from disk even on a warm cache hit, bypassing
            the fast path and re-running the guarded bootstrap.

    Returns:
        The installed configuration mapping (programmatic defaults merged
        with the on-disk config).
    """
    # TASK-32804.1: serve a warm read without entering the admission
    # handshake (see `_warm_config_cache_hit`). A miss or a forced reload
    # falls through to the guarded bootstrap exactly as before.
    if not force_reload:
        warm = _warm_config_cache_hit()
        if warm is not None:
            return warm
    return _load_cli_config_bootstrap(force_reload=force_reload).config


def _setting_value_for_log(key: Any, value: Any) -> str:
    """Return a safe representation of a config setting value for logs."""
    if is_sensitive_config_key(key):
        return repr("<redacted>")
    return repr(value)


def _maybe_encrypt_setting_value(
    config_data: Dict[str, Any], key: Any, value: Any
) -> Any:
    encryption_config = config_data.get("encryption", {})
    if not (
        isinstance(encryption_config, dict)
        and encryption_config.get("enabled", False)
        and is_sensitive_config_key(key)
        and isinstance(value, str)
        and value
        and not value.startswith("enc:")
        and not (value.startswith("<") and value.endswith(">"))
    ):
        return value

    password = get_encryption_password()
    if not password:
        return value
    try:
        enc_module = get_encryption_module()
        encrypted_value = enc_module.encrypt_value(value, password)
        logger.info(f"Encrypted {key} in config section")
        return encrypted_value
    except Exception as error:
        logger.error(
            "Failed to encrypt config value (key={}, exception_category={}).",
            key,
            type(error).__name__,
        )
        raise


def _target_config_section(config_data: Dict[str, Any], section: str) -> Dict[str, Any]:
    current_level = config_data
    for part in section.split("."):
        next_level = current_level.setdefault(part, {})
        if not isinstance(next_level, dict):
            raise TypeError(part)
        current_level = next_level
    return current_level


# Eagerly created at import (single-threaded), so every caller shares one
# lock. Lazy init would let the first two concurrent workers each build a
# separate lock and defeat serialization on the first write.
import threading as _threading  # noqa: E402

from tldw_chatbook.Utils.private_paths import (
    _lock_stream_for_callbacks,
    open_private_lock_stream,
)

_LOCK_STREAM_SELECTOR_BINDING = (
    _lock_stream_for_callbacks,
    _lock_stream_for_callbacks.__code__,
    _lock_stream_for_callbacks.__globals__,
    tuple(cell.cell_contents for cell in _lock_stream_for_callbacks.__closure__),
)


_CONFIG_FILE_LOCK = _threading.RLock()


def _config_file_lock():
    """Return the shared config-file read-modify-write lock.

    Returns:
        The process-wide lock serializing config file saves/deletes across
        Textual thread workers so concurrent cycles cannot drop updates.
    """
    return _CONFIG_FILE_LOCK


def _bind_config_interprocess_lock(definition):
    """Capture the original optional selector before caller-marker lookup."""
    @contextmanager
    def _config_interprocess_lock(config_path: Path) -> Iterator[None]:
        """Hold one OS-backed lock across a whole-file config transaction."""

        with _config_participants.operation(sys.modules[__name__], target=config_path):
            lock_path = config_path.with_name(f"{config_path.name}.lock")
            application_directory = application_owned_config_directory(config_path)
            lock_opener = None
            binding = globals().get("_LOCK_STREAM_SELECTOR_BINDING")
            if binding is definition:
                selector, selector_code, selector_globals, selector_closure = definition
                if (
                    globals().get("_lock_stream_for_callbacks") is selector
                    and selector.__code__ is selector_code
                    and selector.__globals__ is selector_globals
                    and selector.__defaults__ is None
                    and selector.__kwdefaults__ is None
                    and selector.__closure__ is not None
                    and len(selector.__closure__) == len(selector_closure)
                    and all(cell.cell_contents is value for cell, value in zip(selector.__closure__, selector_closure, strict=True))
                ):
                    lock_opener = selector(
                        create_private_text, open_private_text_append_stream, open_private_lock_stream, globals()
                    )
            if lock_opener is None:
                try:
                    create_private_text(
                        lock_path,
                        "",
                        application_owned_directory=application_directory,
                    )
                except FileExistsError:
                    pass
                stream = open_private_text_append_stream(
                    lock_path,
                    application_owned_directory=application_directory,
                )
            else:
                stream = lock_opener(
                    lock_path, application_owned_directory=application_directory
                )
            locked = False
            try:
                from tldw_chatbook.Backup_Recovery import raw_participants

                operation = raw_participants._runtime_operation(config_path)
                while True:
                    _config_participants.check_lock_wait(sys.modules[__name__], operation)
                    try:
                        portalocker.lock(
                            stream,
                            portalocker.LockFlags.EXCLUSIVE
                            | portalocker.LockFlags.NON_BLOCKING,
                        )
                        locked = True
                        break
                    except portalocker.exceptions.AlreadyLocked:
                        _threading.Event().wait(0.05)
                _config_participants.check_lock_wait(sys.modules[__name__], operation)
                yield
            finally:
                if locked:
                    try:
                        portalocker.unlock(stream)
                    except Exception as error:
                        logger.error(
                            "Configuration write lock release failed (error_type={}).",
                            type(error).__name__,
                        )
                try:
                    stream.close()
                except Exception as error:
                    logger.error(
                        "Configuration write lock close failed (error_type={}).",
                        type(error).__name__,
                    )

    return _config_interprocess_lock

_config_interprocess_lock = _bind_config_interprocess_lock(_LOCK_STREAM_SELECTOR_BINDING)
del _bind_config_interprocess_lock


@contextmanager
def _config_write_lock(config_path: Path) -> Iterator[None]:
    """Serialize one config write transaction within and across processes."""

    with _config_participants.operation(sys.modules[__name__], target=config_path):
        with (
            _settings_rebuild_lock(),
            _config_file_lock(),
            _config_interprocess_lock(config_path),
        ):
            yield


def _current_config_file_stamp(config_path: Path) -> Optional[tuple[int, int]]:
    """(mtime_ns, size) for the config file, or None when absent/unreadable."""
    try:
        st = os.stat(config_path)
        return (st.st_mtime_ns, st.st_size)
    except OSError:
        return None


def _external_edit_detected(config_path: Path) -> bool:
    """TASK-26038: THROTTLED check for an external edit since the last load.

    Returns True (invalidating the cache) at most once per external change,
    and stats at most once per ``_CONFIG_STAT_THROTTLE_SECONDS`` so the read
    hot path keeps its near-zero cost. No thread, no watcher.
    """
    global _CONFIG_STAT_CHECKED_MONOTONIC
    if _CONFIG_FILE_STAMP is None:
        return False
    now = time.monotonic()
    if now - _CONFIG_STAT_CHECKED_MONOTONIC < _CONFIG_STAT_THROTTLE_SECONDS:
        return False
    _CONFIG_STAT_CHECKED_MONOTONIC = now
    current = _current_config_file_stamp(config_path)
    return current is not None and current != _CONFIG_FILE_STAMP


@_config_participants.guarded
def _load_cli_config_bootstrap(
    force_reload: bool = False,
) -> _ConfigBootstrapResult:
    """Load or create the config while serializing the file/cache lifecycle.

    TASK-21124 -- LOCK-FREE FAST PATH. `get_cli_setting` has ~398 call
    sites, many on the Textual event loop, and every one funnels through
    here; taking `_config_file_lock()` before the cache check meant one
    config write (which holds that lock through two fsyncs and its TOML
    parses) stalled every loop-side read for the whole write. A warm cache
    hit now returns without touching the lock.

    Why the unlocked reads below are safe (CPython, GIL builds -- the only
    builds this app supports):

    * Each global read (`_CONFIG_GENERATION`, `_CONFIG_CACHE`,
      `_CONFIG_CACHE_SOURCE`) is a single atomic reference load; a reader
      can never see a partially-assigned cell.
    * Every publication installs a BRAND-NEW dict object (built via
      `copy.deepcopy(DEFAULT_CONFIG_FROM_TOML)` + `deep_merge_dicts`, both
      of which construct fresh objects) -- a previously published dict is
      never re-installed. Therefore the `_CONFIG_CACHE is cached_config`
      re-check proves no install happened between the two cache reads, so
      the (cache, source) pair read here belongs to one single install and
      cannot be torn across two different installs.
    * Writers store in the order: cache=None, source=None, <build>,
      cache=new, source=path, all under `_config_file_lock`. In
      `_load_cli_config_bootstrap_unlocked` and
      `_invalidate_config_caches` the pre-clear is explicit; for
      `_install_bootstrap_cache_from_raw` the coupling is IMPLICIT -- it
      does no pre-clear itself, and the invariant holds only because
      every `raw_config` it receives comes from
      `_write_raw_cli_config_unlocked`, whose `_invalidate_config_caches()`
      call performed the cache=None/source=None stores moments earlier
      under the same lock. Combined with the identity re-check, a hit
      therefore returns the config that IS the currently installed cache
      for the caller's path.
    * The `_CONFIG_GENERATION` sandwich (read, ..., re-read) is the
      double-check the task's AC names, but it is NOT what makes the read
      sound -- the identity re-check above carries the soundness on its
      own (review of TASK-21124 proved by mutation that reordering the
      publish-time bump relative to the cache install leaves every
      guarantee intact). The generation term adds conservatism only: when
      a publication lands between the two generation reads, the reader
      declines the hit and re-validates through the locked path instead.
    * A write's invalidate window (cache=None between file replace and
      republish) makes readers MISS and serialize through the lock below,
      which is the pre-existing behavior for every miss.

    The fast path deliberately returns the SAME shared mutable dict the
    locked cache-hit path has always returned (no defensive copy) -- the
    copy semantics of `load_cli_config_and_ensure_existence` are unchanged.
    """

    edit_detected = False
    if not force_reload:
        config_path = _get_effective_config_path()
        generation_before = _CONFIG_GENERATION
        cached_config = _CONFIG_CACHE
        cached_source = _CONFIG_CACHE_SOURCE
        base_hit = (
            cached_config is not None
            and cached_source == config_path
            and _CONFIG_CACHE is cached_config
            and _CONFIG_GENERATION == generation_before
        )
        # TASK-26038: only stat when we would otherwise hit -- a miss already
        # re-reads. The (throttled) check turns a hit into a forced re-read,
        # never a false hit, so the lock-free soundness reasoning is intact.
        if base_hit:
            edit_detected = _external_edit_detected(config_path)
            if not edit_detected:
                return _ConfigBootstrapResult(cached_config, True)

    with _config_file_lock():
        # An external edit forces the locked path past its own cache fast
        # path so the changed file is actually re-read (and re-stamped).
        return _load_cli_config_bootstrap_unlocked(
            force_reload=force_reload or edit_detected
        )


@_config_participants.guarded
def _prepare_config_parent(config_path: Path) -> Path | None:
    """Secure the default config directory or verify a custom parent."""

    application_directory = application_owned_config_directory(config_path)
    if application_directory is not None:
        result = secure_private_directory(
            application_directory,
            create=True,
            application_owned=True,
        )
        _report_config_path_posture(result, target_kind="directory")
    else:
        verify_trusted_directory(
            config_path.parent,
            allow_shared_sticky=False,
        )
    return application_directory


@_config_participants.guarded
def _read_raw_cli_config_unlocked(config_path: Path) -> Dict[str, Any]:
    """Read the on-disk config mapping while the config lock is held."""

    try:
        with open_private_binary(config_path) as opened:
            _report_config_path_posture(opened.result)
            loaded = tomllib.load(opened.stream)
    except FileNotFoundError:
        return {}
    if not isinstance(loaded, dict):
        raise TypeError("The CLI config must contain a top-level table")
    return loaded


def _invalidate_config_caches() -> None:
    """Drop config/settings caches after a successful whole-file write."""

    global _CONFIG_CACHE, _CONFIG_CACHE_SOURCE
    global _SETTINGS_CACHE, _SETTINGS_CACHE_SOURCE

    _CONFIG_CACHE = None
    _CONFIG_CACHE_SOURCE = None
    _SETTINGS_CACHE = None
    _SETTINGS_CACHE_SOURCE = None


class ConfigSerializationError(ValueError):
    """A config rewrite would have committed unparseable TOML -- TASK-13157.

    ``ValueError`` on purpose: ``replace_cli_config_serialized`` already uses
    a plain ``ValueError`` as its "config write rejected" signal (see
    ``_enforce_existing_encryption``), and ``persist_cli_config_for_
    shutdown`` already catches ``ValueError`` in its failure tuple -- making
    this a subclass means every existing call site's exception handling
    covers it without modification.
    """


@_config_participants.guarded
def _write_raw_cli_config_unlocked(
    config_path: Path,
    config_data: Mapping[str, Any],
) -> Dict[str, Any]:
    """Atomically write a private on-disk config while the lock is held.

    Returns:
        The verify parse-back of the exact serialized text committed to
        disk -- byte-for-byte what the next read of the file will produce.
        TASK-21124: callers hand this to
        ``_publish_runtime_config_unlocked(raw_config=...)`` so the publish
        step reuses this parse instead of re-reading and re-parsing the
        file it just wrote (twice: once for the bootstrap cache, once again
        inside ``load_settings(force_reload=True)``). The TASK-13157 guard
        below is therefore not a redundant extra parse anymore -- it IS the
        single serialization-side parse, and publishing its output is
        strictly more faithful than publishing the input mapping (it is
        the post-round-trip view the next boot would see).

    TASK-13157: every config-rewrite pass (settings-screen edits, the
    first-run wizard, and -- notably -- the full default+user re-merge every
    process shutdown persists via ``persist_cli_config_for_shutdown``) ends
    up here. The in-memory ``config_data`` is always a plain ``dict`` with
    inherently unique keys, so it cannot itself carry a duplicate key -- but
    ``toml.dumps`` (the third-party encoder) and ``tomllib`` (the stdlib
    reader the NEXT boot uses) are two independent implementations with no
    guaranteed round-trip contract between them. Before this fix, nothing
    verified the encoder's own output was still valid TOML before it was
    committed to disk; a bad serialization would sit there until the next
    boot's read failed, at which point the failure was ALSO silent (see
    ``ConfigLoadFailure``). Parsing the freshly serialized text back through
    the exact reader used on the next boot, before the atomic write, makes
    it categorically impossible for this function to leave behind a file its
    own next read cannot parse. That is the full extent of the guarantee:
    this guard proves PARSEABILITY, not fidelity -- it never compares the
    parsed-back value against ``config_data``, so an encoder-level mangling
    that still happens to produce valid TOML sails through unnoticed
    (measured: ``toml.dumps`` silently drops control characters such as
    ``\\x00``/``\\x1b`` from string values, and the mangled output still
    parses back cleanly). The write is NOT idempotent by construction and
    can change the on-disk result relative to what was requested; what is
    guaranteed is narrower -- it can never regress a config this function
    can write at all into a file the next read cannot parse.
    """

    application_directory = _prepare_config_parent(config_path)
    serialized = dumps_cli_config(dict(config_data))
    try:
        parsed_back = tomllib.loads(serialized)
    except tomllib.TOMLDecodeError as exc:
        logger.error(
            "Refusing to write CLI config: serialized TOML failed to parse back "
            "(error_type={})",
            type(exc).__name__,
        )
        raise ConfigSerializationError(
            f"Refusing to write {config_path}: the serialized configuration "
            f"does not parse back as valid TOML ({exc})"
        ) from exc
    _commit_serialized_cli_config_unlocked(
        config_path, serialized, application_directory
    )
    return parsed_back


def _commit_serialized_cli_config_unlocked(
    config_path: Path,
    serialized: str,
    application_directory: Path | None,
) -> None:
    """Atomically commit exact serialized config text while the lock is held.

    Shared by `_write_raw_cli_config_unlocked` and the encryption lifecycle's
    byte-exact rollback (TASK-34100.4), so a restore advances an owned
    recovery binding exactly like an ordinary write does. Not itself
    `_config_participants.guarded` (that allowlist is closed): every caller
    already runs inside `_config_write_lock`'s participant operation.
    """

    from .Backup_Recovery.config_binding import preserve_owned_binding

    with preserve_owned_binding(
        sys.modules[__name__], config_path, serialized
    ) as precondition:
        result = atomic_private_write_text(
            config_path,
            serialized,
            application_owned_directory=application_directory,
            target_precondition=precondition,
        )
    _report_config_path_posture(result)
    _invalidate_config_caches()


def _install_bootstrap_cache_from_raw(
    raw_config: Mapping[str, Any],
    config_path: Optional[Path] = None,
) -> Optional[Dict[str, Any]]:
    """Install the bootstrap cache from an already-parsed raw config mapping.

    TASK-21124: replicates exactly the success tail of
    `_load_cli_config_bootstrap_unlocked` (merge the programmatic defaults,
    decrypt strictly, publish cache + source, retire any recorded parse
    failure) without re-reading or re-parsing the file. Used by
    `_publish_runtime_config_unlocked` with the verify parse-back a write
    just produced. Must be called with `_config_file_lock` held.

    TASK-21235: ``config_path`` is the path the CALLER's read/write used.
    It used to be recomputed here via `_get_effective_config_path()` at
    publish time, so a ``TLDW_CONFIG_PATH`` flip between the caller's read
    and this publish would label path-A data as the path-B cache
    (``_CONFIG_CACHE_SOURCE`` is exactly what the fast path's cache
    identity re-check compares against). Callers that hold a path pass it;
    the fallback recompute covers only callers with no path of their own.

    Returns:
        The installed merged+decrypted config, or ``None`` when strict
        decryption failed -- the caller then falls back to the full locked
        reload, which reproduces the historical failure handling
        (cache left empty, in-memory defaults returned).
    """

    global _CONFIG_CACHE, _CONFIG_CACHE_SOURCE, _LAST_CONFIG_LOAD_FAILURE
    global _CONFIG_FILE_STAMP, _CONFIG_STAT_CHECKED_MONOTONIC

    if config_path is None:
        config_path = _get_effective_config_path()
    merged = deep_merge_dicts(DEFAULT_CONFIG_FROM_TOML, dict(raw_config))
    decryption = _decrypt_config_section_with_status(merged, strict=True)
    if not decryption.succeeded:
        return None
    loaded_config = decryption.config
    # Same store order as `_load_cli_config_bootstrap_unlocked` (cache, then
    # source); the fast path's identity re-check makes either order safe --
    # see `_load_cli_config_bootstrap`. NOTE an implicit coupling: this
    # function performs no cache=None/source=None pre-clear of its own; the
    # documented writer store order holds only because every caller's
    # `raw_config` comes from `_write_raw_cli_config_unlocked`, whose
    # `_invalidate_config_caches()` did that pre-clear moments earlier under
    # the same lock. A new caller sourcing `raw_config` elsewhere must
    # preserve that ordering.
    _CONFIG_CACHE = loaded_config
    _CONFIG_CACHE_SOURCE = config_path
    _LAST_CONFIG_LOAD_FAILURE = None
    # TASK-26038 (lane-7 review Important #1): stamp the file WE just wrote so a
    # read after the stat-throttle window does not mistake our own write for an
    # external edit and force a redundant locked re-read. This is the write-path
    # twin of the stamp refresh in `_load_cli_config_bootstrap_unlocked`;
    # refreshing only one twin left the TASK-21124 coalescing broken on the
    # first read after every write.
    _CONFIG_FILE_STAMP = _current_config_file_stamp(config_path)
    _CONFIG_STAT_CHECKED_MONOTONIC = time.monotonic()
    return loaded_config


@_config_participants.guarded
def _publish_runtime_config_unlocked(
    raw_config: Mapping[str, Any] | None = None,
    config_path: Optional[Path] = None,
) -> Dict[str, Any]:
    """Reload caches and publish one complete in-process config generation.

    Args:
        raw_config: Optional already-parsed raw on-disk mapping (the verify
            parse-back returned by `_write_raw_cli_config_unlocked`). When
            given and installable, the bootstrap cache is rebuilt from it
            without re-reading the file, and the settings rebuild reuses
            that just-primed cache (`reload_bootstrap=False`) -- TASK-21124
            takes one write from four TOML parses to two (the inherent
            read-modify-write read plus the TASK-13157 verify parse).
        config_path: TASK-21235: the path the caller's read/write used, so
            the bootstrap cache is published under the path its data was
            actually read from even if ``TLDW_CONFIG_PATH`` flips mid-write.
            Omitted by callers with no path of their own (the raw-less
            reload path recomputes it under the same lock).

    The `_CONFIG_GENERATION` bump is kept last for consistency, but the
    ordering is not load-bearing: the fast path's soundness rests on its
    cache-identity re-check, and the generation sandwich only adds
    conservatism (see `_load_cli_config_bootstrap` -- the TASK-21124
    review proved a bump-first mutant equivalent). Callers hold the write
    lock.
    """

    global settings, _CONFIG_GENERATION, _CONFIG_PERSISTENCE_ERROR

    loaded: Optional[Dict[str, Any]] = None
    if raw_config is not None:
        loaded = _install_bootstrap_cache_from_raw(
            raw_config, config_path=config_path
        )
    if loaded is None:
        bootstrap = _load_cli_config_bootstrap_unlocked(force_reload=True)
        if not bootstrap.succeeded:
            raise ValueError("Configuration runtime reload failed")
        loaded = bootstrap.config
    settings = load_settings(force_reload=True, reload_bootstrap=False)
    _CONFIG_GENERATION += 1
    _CONFIG_PERSISTENCE_ERROR = None
    return loaded


class RuntimeConfigSnapshot(NamedTuple):
    """A defensive normalized config view paired with its write generation."""

    generation: int
    values: Dict[str, Any]


class AtomicConfigSnapshot(NamedTuple):
    """A locked authoritative config view paired with its published generation."""

    generation: int
    values: Dict[str, Any]


@dataclass(frozen=True, slots=True)
class LiteralSettingsMutation:
    """Exact set/delete operations addressed by literal TOML mapping paths."""

    section_values: Mapping[tuple[str, ...], Mapping[str, object]]
    delete_keys: Mapping[tuple[str, ...], Collection[str]]


@dataclass(frozen=True, slots=True)
class AtomicLiteralMutationSnapshot:
    """Authoritative raw and effective config views held under the write lock."""

    generation: int
    raw_values: Mapping[str, object]
    effective_values: Mapping[str, object]
    config_path: Path | None = None


@dataclass(frozen=True, slots=True)
class LiteralConfigMutationResult:
    """Two-phase literal mutation outcome with an optional fresh settings view."""

    file_replaced: bool
    caches_reloaded: bool
    settings_view: Mapping[str, object] | None
    failure_phase: str | None


@dataclass(frozen=True, slots=True)
class HookConfigSnapshot:
    """Detached saved hook section paired with its actual file identity."""

    config_path: Path
    section_present: bool
    section: object = field(repr=False)
    section_stamp: str
    profile_data_dir: Path | None = field(default=None, repr=False)


def _hooks_config_snapshot(
    config_path: Path, raw: Mapping[str, object]
) -> HookConfigSnapshot:
    present = "hooks" in raw
    section = copy.deepcopy(raw.get("hooks"))
    stamp: dict[str, object] = {"present": present}
    if present:
        stamp["section"] = section
    encoded = toml.dumps(stamp).encode("utf-8")
    return HookConfigSnapshot(
        config_path.resolve(),
        present,
        section,
        hashlib.sha256(encoded).hexdigest(),
        profile_paths.user_data_dir(raw),
    )


@contextmanager
def locked_hooks_config_snapshot() -> Iterator[HookConfigSnapshot]:
    """Hold the config writer lock while reading and consuming hook authority."""
    config_path = validate_path_simple(
        _get_effective_config_path(),
        require_exists=False,
        probe_existing=False,
        reject_shell_metacharacters=False,
    )
    with _config_write_lock(config_path):
        if _get_effective_config_path().resolve() != config_path.resolve():
            raise ValueError("Hook configuration file changed; reload.")
        yield _hooks_config_snapshot(
            config_path, _read_raw_cli_config_unlocked(config_path)
        )


def read_hooks_config_snapshot() -> HookConfigSnapshot:
    """Read current saved hook definitions without consulting runtime caches."""
    with locked_hooks_config_snapshot() as snapshot:
        return snapshot


def replace_hooks_config_snapshot(
    expected: HookConfigSnapshot,
    replacement: Mapping[str, object],
) -> LiteralConfigMutationResult:
    """Replace the current hook section through the canonical guarded writer."""
    owned = copy.deepcopy(dict(replacement))

    def build(snapshot: AtomicLiteralMutationSnapshot) -> LiteralSettingsMutation:
        if snapshot.config_path is None:
            raise ValueError("Hook configuration file unavailable.")
        current = _hooks_config_snapshot(snapshot.config_path, snapshot.raw_values)
        if (
            current.config_path != expected.config_path
            or current.section_stamp != expected.section_stamp
            or current.profile_data_dir != expected.profile_data_dir
        ):
            raise ValueError("Hook configuration changed; reload before saving.")
        if current.section_present and not isinstance(current.section, Mapping):
            raise ValueError("Repair malformed Hooks section in Advanced Config.")
        old = current.section if isinstance(current.section, Mapping) else {}
        return LiteralSettingsMutation(
            section_values={
                ("hooks",): {
                    **{
                        key: value
                        for key, value in old.items()
                        if key not in {"enabled", "hook"}
                    },
                    **owned,
                }
            },
            delete_keys={
                ("hooks",): tuple(
                    key
                    for key in ("enabled", "hook")
                    if key in old and key not in owned
                )
            },
        )

    return apply_literal_settings_transaction_to_cli_config(build)


def _atomic_config_values_from_raw(
    config_data: Mapping[str, Any],
) -> Dict[str, Any]:
    """Merge and decrypt the exact raw mapping already read under the write lock."""

    merged = deep_merge_dicts(DEFAULT_CONFIG_FROM_TOML, dict(config_data))
    decryption = _decrypt_config_section_with_status(merged, strict=True)
    if not decryption.succeeded:
        raise ValueError("Authoritative configuration could not be decrypted")
    return decryption.config


def get_atomic_config_snapshot() -> AtomicConfigSnapshot:
    """Read the authoritative config through the same lock used by mutations."""

    config_path = _get_effective_config_path()
    with _config_write_lock(config_path):
        raw = _read_raw_cli_config_unlocked(config_path)
        return AtomicConfigSnapshot(
            generation=_CONFIG_GENERATION,
            values=_atomic_config_values_from_raw(raw),
        )


def get_runtime_config_generation() -> int:
    """Read the publication counter without locks, I/O, or copying config.

    This is a baseline, not an acceptance fence. Callers must finish with
    ``run_if_runtime_config_generation_current``; a concurrent publication
    conservatively invalidates the captured baseline.
    """
    return _CONFIG_GENERATION


def get_runtime_config_snapshot(
    *,
    force_reload: bool = False,
) -> RuntimeConfigSnapshot:
    """Return a defensive current runtime config view.

    PERF-06 (TASK-33265): a warm snapshot is served without the ADR-126
    admission handshake (a deep copy of the installed settings under the
    same two in-process locks). A miss or forced reload runs the guarded
    :func:`_get_runtime_config_snapshot_guarded`, exactly as before.

    Args:
        force_reload: Rebuild the settings from disk even when they are cached.

    Returns:
        A snapshot of the current config generation and a deep copy of the
        merged settings, safe for the caller to mutate.
    """

    if not force_reload:
        # Never block here: a held lock means a write is in flight, and the
        # guarded path waits for it pause-aware, so recovery can cancel the
        # wait (Qodo, #2903).
        rebuild, file_lock = _settings_rebuild_lock(), _config_file_lock()
        if rebuild.acquire(blocking=False):
            try:
                if file_lock.acquire(blocking=False):
                    try:
                        # Copy the hit that was checked: a second lookup could
                        # miss after a lock-free clear and rebuild under the
                        # locks, reversing admission-then-locks (Qodo, #2903).
                        cached = _settings_cache_hit(_get_effective_config_path())
                        if cached is not None:
                            return RuntimeConfigSnapshot(
                                generation=_CONFIG_GENERATION,
                                values=copy.deepcopy(cached),
                            )
                    finally:
                        file_lock.release()
            finally:
                rebuild.release()
    return _get_runtime_config_snapshot_guarded(force_reload=force_reload)


@_config_participants.guarded
def _get_runtime_config_snapshot_guarded(
    *,
    force_reload: bool = False,
) -> RuntimeConfigSnapshot:
    """Guarded body of :func:`get_runtime_config_snapshot` (miss or reload)."""

    with _settings_rebuild_lock(), _config_file_lock():
        values = load_settings(force_reload=force_reload)
        return RuntimeConfigSnapshot(
            generation=_CONFIG_GENERATION,
            values=copy.deepcopy(values),
        )


def _published_runtime_config_snapshot() -> RuntimeConfigSnapshot:
    """Read the already-published config generation without filesystem I/O."""

    with _settings_rebuild_lock(), _config_file_lock():
        return RuntimeConfigSnapshot(
            generation=_CONFIG_GENERATION,
            values=copy.deepcopy(settings),
        )


def run_if_runtime_config_generation_current(
    expected_generation: int,
    action: Callable[[], bool],
) -> bool:
    """Linearize a nonblocking action against runtime config publication.

    Lock order is always ``config -> action-owned lock``. The supplied action
    must be process-local and nonblocking; first-chat handoff acknowledgement
    uses this to acquire only the pending-handoff lock. Pending handoff stage,
    claim, and release paths never acquire the config lock, so there is no
    reverse ``handoff -> config`` edge.

    Args:
        expected_generation: Runtime generation the caller validated.
        action: Nonblocking action to execute while publication is fenced.

    Returns:
        ``True`` only when the generation matched and the action succeeded.
    """

    if type(expected_generation) is not int or expected_generation < 0:
        raise ValueError("Expected config generation must be nonnegative")
    if not callable(action):
        raise TypeError("Config generation action must be callable")
    with _config_file_lock():
        if _CONFIG_GENERATION != expected_generation:
            return False
        return action() is True


def _encryption_enabled(config_data: Mapping[str, Any]) -> bool:
    encryption = config_data.get("encryption", {})
    return isinstance(encryption, Mapping) and encryption.get("enabled", False) is True


def _enforce_existing_encryption(
    current_config: Mapping[str, Any],
    replacement: Mapping[str, Any],
) -> None:
    if _encryption_enabled(current_config) and not _encryption_enabled(replacement):
        raise ValueError(
            "Encrypted config replacement must keep encryption enabled; "
            "disable encryption explicitly"
        )


_REVISION_OWNED_CONFIG_SECTIONS = frozenset({"speech_studio"})


def _preserve_revision_owned_sections(
    current: Mapping[str, Any],
    replacement: Mapping[str, Any],
) -> Dict[str, Any]:
    """Keep dedicated revision-owned sections out of whole-config writers."""

    selected = copy.deepcopy(dict(replacement))
    for section in _REVISION_OWNED_CONFIG_SECTIONS:
        if section in current:
            selected[section] = copy.deepcopy(current[section])
        else:
            selected.pop(section, None)
    return selected


@_config_participants.guarded
def _try_read_cli_config_serialized_unlocked(config_path: Path) -> str | None:
    try:
        with open_private_binary(config_path) as opened:
            _report_config_path_posture(opened.result)
            return opened.stream.read().decode("utf-8")
    except FileNotFoundError:
        return None


@_config_participants.guarded
def _read_cli_config_serialized_unlocked(config_path: Path) -> str:
    serialized = _try_read_cli_config_serialized_unlocked(config_path)
    if serialized is None:
        _load_cli_config_bootstrap_unlocked(force_reload=True)
        with open_private_binary(config_path) as opened:
            _report_config_path_posture(opened.result)
            return opened.stream.read().decode("utf-8")
    return serialized


@_config_participants.guarded
def read_cli_config_serialized() -> str:
    """Return the effective config's exact serialized on-disk representation."""

    with _config_file_lock():
        return _read_cli_config_serialized_unlocked(get_cli_config_path())


@dataclass(frozen=True, repr=False)
class ConfigFileSnapshot:
    """Exact in-memory raw file/profile identity; absence differs from empty text."""

    path: Path
    serialized: str | None


class ConfigSnapshotConflictError(ValueError):
    """The raw editor's file/profile baseline no longer matches the current file."""

    def __init__(self) -> None:
        super().__init__("The config file or profile changed. Reload it before saving.")


class ConfigPostCommitError(RuntimeError):
    """Report a committed raw replacement whose snapshot or runtime refresh failed.

    Attributes:
        snapshot: Exact committed file snapshot, or None if its read failed.
        backup_path: Backup created before replacement, if a previous file existed.
    """

    def __init__(
        self, snapshot: ConfigFileSnapshot | None, backup_path: Path | None
    ) -> None:
        """Retain recovery state without exposing config text or the original error.

        Args:
            snapshot: Committed snapshot when its post-write read succeeded.
            backup_path: Existing config's backup, or None when none was created.
        """
        super().__init__("Config saved to disk, but post-save refresh failed.")
        self.snapshot = snapshot
        self.backup_path = backup_path


def read_cli_config_snapshot() -> ConfigFileSnapshot:
    """Read exact serialized config without parsing or creating a missing file."""

    with _config_participants.operation(sys.modules[__name__]):
        config_path = get_cli_config_path()
        with _config_write_lock(config_path):
            return ConfigFileSnapshot(
                config_path, _try_read_cli_config_serialized_unlocked(config_path)
            )


def _advanced_backup_path(config_path: Path) -> Path:
    return config_path.with_suffix(config_path.suffix + ".bak")


def _write_serialized_config_artifact_unlocked(
    path: Path,
    serialized: str,
    *,
    config_path: Path,
) -> Path:
    if path in (config_path, _advanced_backup_path(config_path)):
        route, target = "config", config_path
    else:
        prefix, suffix = "config_backup_", ".toml"
        if (
            path.parent != config_path.parent
            or not path.name.startswith(prefix)
            or not path.name.endswith(suffix)
        ):
            raise ValueError("invalid_config_snapshot_target")
        route, target = "config_snapshot", path.name[len(prefix) : -len(suffix)]
        if _config_snapshot_path(config_path, target) != path:
            raise ValueError("invalid_config_snapshot_target")
    with _config_participants.operation(
        sys.modules[__name__], route=route, target=target
    ):
        application_directory = _prepare_config_parent(config_path)
        result = atomic_private_write_text(
            path,
            serialized,
            application_owned_directory=application_directory,
        )
        _report_config_path_posture(result, target_kind="snapshot")
        return result.lexical_path


@_config_participants.guarded
def read_cli_config_backup_serialized() -> str:
    """Return the exact serialized advanced-editor backup."""

    with _config_file_lock():
        config_path = get_cli_config_path()
        backup_path = _advanced_backup_path(config_path)
        with open_private_binary(backup_path) as opened:
            _report_config_path_posture(opened.result, target_kind="snapshot")
            return opened.stream.read().decode("utf-8")


@_config_participants.guarded
def replace_cli_config_serialized(
    serialized: str,
    *,
    create_backup: bool = True,
) -> tuple[Dict[str, Any], Path | None]:
    """Validate and replace raw TOML without downgrading encryption.

    Raises:
        ConfigPostCommitError: Replacement succeeded but post-save refresh failed.
    """

    loaded, backup_path, _ = _replace_cli_config_serialized(
        serialized, create_backup=create_backup
    )
    return loaded, backup_path


def replace_cli_config_snapshot(
    serialized: str,
    expected_snapshot: ConfigFileSnapshot,
    *,
    create_backup: bool = True,
) -> tuple[Dict[str, Any], Path | None, ConfigFileSnapshot]:
    """Replace raw TOML only while its exact file/profile baseline still matches.

    The comparison, backup, replacement and returned on-disk snapshot share one
    write lock. A conflict leaves both config and backup unchanged.

    Raises:
        ConfigSnapshotConflictError: The current file or profile no longer matches.
        ConfigPostCommitError: The file was replaced but its snapshot or runtime
            refresh failed. The exception carries the committed snapshot when
            available; callers must not report this as a failed disk write.
    """

    if not isinstance(expected_snapshot, ConfigFileSnapshot):
        raise TypeError("A config file snapshot is required for guarded replacement")
    return _replace_cli_config_serialized(
        serialized,
        create_backup=create_backup,
        expected_snapshot=expected_snapshot,
    )


def _replace_cli_config_serialized(
    serialized: str,
    *,
    create_backup: bool,
    expected_snapshot: ConfigFileSnapshot | None = None,
) -> tuple[Dict[str, Any], Path | None, ConfigFileSnapshot]:
    """Own raw replacements, optionally guarded by an exact editor baseline."""

    replacement = tomllib.loads(serialized)
    if not isinstance(replacement, dict):
        raise TypeError("The CLI config must contain a top-level table")

    config_path = get_cli_config_path()
    with _config_write_lock(config_path):
        if expected_snapshot is not None and (
            expected_snapshot.path != config_path
            or config_path != get_cli_config_path()
        ):
            raise ConfigSnapshotConflictError()
        current_serialized = _try_read_cli_config_serialized_unlocked(config_path)
        if (
            expected_snapshot is not None
            and expected_snapshot.serialized != current_serialized
        ):
            raise ConfigSnapshotConflictError()
        if current_serialized is None:
            current_config: Dict[str, Any] = {}
        else:
            current_config = tomllib.loads(current_serialized)
        replacement = _preserve_revision_owned_sections(
            current_config,
            replacement,
        )
        _enforce_existing_encryption(current_config, replacement)
        persisted = _config_data_for_persistence(replacement)
        backup_path: Path | None = None
        if create_backup and current_serialized is not None:
            backup_path = _write_serialized_config_artifact_unlocked(
                _advanced_backup_path(config_path),
                current_serialized,
                config_path=config_path,
            )
        raw_written = _write_raw_cli_config_unlocked(config_path, persisted)
        saved_snapshot = None
        try:
            saved_serialized = _try_read_cli_config_serialized_unlocked(config_path)
            if saved_serialized is None:
                raise OSError("The committed config snapshot is unavailable.")
            saved_snapshot = ConfigFileSnapshot(config_path, saved_serialized)
            loaded = _publish_runtime_config_unlocked(
                raw_config=raw_written, config_path=config_path
            )
        except Exception:  # Post-commit errors must retain the successful disk outcome.
            raise ConfigPostCommitError(saved_snapshot, backup_path) from None
        return loaded, backup_path, saved_snapshot


def persist_cli_config_for_shutdown() -> bool:
    """Re-persist the effective config through the normal encrypted owner."""

    try:
        config_path = get_cli_config_path()
        with _config_write_lock(config_path):
            from .Backup_Recovery.profile_open import unchanged_selected_config

            # Settings writes already persist. A defaults-only rewrite would
            # invalidate the selected recovery generation's config fingerprint.
            if unchanged_selected_config(config_path):
                return True
            bootstrap = _load_cli_config_bootstrap_unlocked(force_reload=True)
            if not bootstrap.succeeded:
                logger.warning(
                    "Shutdown config persistence skipped because the current "
                    "file could not be loaded safely."
                )
                return False
            current = bootstrap.config
            persisted = _config_data_for_persistence(current)
            raw_written = _write_raw_cli_config_unlocked(config_path, persisted)
            _publish_runtime_config_unlocked(
                raw_config=raw_written, config_path=config_path
            )
        return True
    except (OSError, TypeError, ValueError, toml.TomlDecodeError) as exc:
        logger.warning(
            "Shutdown config persistence failed (error_type={}).",
            type(exc).__name__,
        )
        return False


def _contains_unencrypted_sensitive_value(config_data: Mapping[str, Any]) -> bool:
    """Return whether an encrypted config mapping contains plaintext secrets."""

    enc_module = get_encryption_module()
    for key, value in config_data.items():
        if key == "encryption":
            continue
        if isinstance(value, Mapping):
            if _contains_unencrypted_sensitive_value(value):
                return True
            continue
        if not (
            is_sensitive_config_key(key) and isinstance(value, str) and value.strip()
        ):
            continue
        if value.startswith("<") and value.endswith(">"):
            continue
        if not enc_module.is_encrypted(value):
            return True
    return False


def _config_data_for_persistence(
    config_data: Mapping[str, Any],
) -> Dict[str, Any]:
    """Preserve encryption-at-rest when persisting a decrypted config view."""

    selected = copy.deepcopy(dict(config_data))
    encryption = selected.get("encryption", {})
    if not (isinstance(encryption, Mapping) and encryption.get("enabled", False)):
        return selected

    password = get_encryption_password()
    if password:
        return encrypt_api_keys_in_config(selected, password)
    if _contains_unencrypted_sensitive_value(selected):
        raise ValueError(
            "Cannot persist plaintext secrets while config encryption is locked"
        )
    return selected


def replace_cli_config(config_data: Mapping[str, Any]) -> Dict[str, Any]:
    """Atomically replace the effective config and refresh all config caches."""

    config_path = get_cli_config_path()
    with _config_write_lock(config_path):
        current = _read_raw_cli_config_unlocked(config_path)
        replacement = _preserve_revision_owned_sections(current, config_data)
        _enforce_existing_encryption(current, replacement)
        persisted = _config_data_for_persistence(replacement)
        raw_written = _write_raw_cli_config_unlocked(config_path, persisted)
        return _publish_runtime_config_unlocked(
                raw_config=raw_written, config_path=config_path
            )


def _config_snapshot_path(config_path: Path, timestamp: str) -> Path:
    """Select one config-owned snapshot basename before any filesystem effect."""
    if (
        not isinstance(timestamp, str)
        or not timestamp
        or any(char in timestamp for char in ("/", "\\", "\x00"))
    ):
        raise ValueError("invalid_config_snapshot_target")
    return config_path.parent / f"config_backup_{timestamp}.toml"


def export_cli_config_snapshot(
    config_data: Mapping[str, Any] | None = None,
    *,
    timestamp: str | None = None,
) -> Path:
    """Create an owner-only snapshot beside the effective config file."""

    snapshot_timestamp = timestamp or datetime.now().strftime("%Y%m%d_%H%M%S")
    with (
        _config_participants.operation(
            sys.modules[__name__], route="config_snapshot", target=snapshot_timestamp
        ),
        _config_file_lock(),
    ):
        config_path = get_cli_config_path()
        snapshot_path = _config_snapshot_path(config_path, snapshot_timestamp)
        serialized = _try_read_cli_config_serialized_unlocked(config_path)
        if serialized is None:
            if config_data is None:
                raise FileNotFoundError(config_path)
            serialized = dumps_cli_config(_config_data_for_persistence(config_data))
        result_path = _write_serialized_config_artifact_unlocked(
            snapshot_path,
            serialized,
            config_path=config_path,
        )
    return result_path


@dataclass(frozen=True, slots=True)
class ConfigMutationResult:
    """Outcome of an atomic config file replacement and cache reload."""

    file_replaced: bool
    caches_reloaded: bool
    failure_phase: Literal["before_replace", "cache_reload"] | None
    conflict: bool = False
    conflict_reason: Literal["identity_changed"] | None = None

    @property
    def fully_applied(self) -> bool:
        """Return whether both persistence phases completed."""
        return self.file_replaced and self.caches_reloaded


def _valid_nonnegative_revision(value: object) -> int | None:
    """Return an exact nonnegative revision or ``None`` when malformed."""

    if type(value) is not int or value < 0:
        return None
    return value


def _without_revision(
    values: Mapping[str, Any],
    revision_key: str,
) -> Dict[str, Any]:
    """Return a defensive section copy without its concurrency revision."""

    comparable = copy.deepcopy(dict(values))
    comparable.pop(revision_key, None)
    return comparable


def replace_revisioned_settings_section_to_cli_config(
    section: str,
    values: Mapping[str, Any],
    *,
    expected_revision: int,
    revision_key: str = "revision",
) -> ConfigMutationResult:
    """Atomically replace one top-level revisioned configuration section.

    A missing or structurally malformed section has revision zero, allowing an
    explicit owner to recover only its own section. The comparison, whole
    section replacement, atomic file write, and cache publication all occur
    while the existing process lock and a stable private interprocess lock are
    held.

    Args:
        section: Exact top-level section owned by the caller.
        values: Complete replacement section, including its next revision.
        expected_revision: Revision observed by the caller.
        revision_key: Key carrying the persisted section revision.

    Returns:
        A mutation result with ``conflict=True`` when the observed revision is
        stale. Invalid transitions fail before replacement.
    """

    try:
        if type(section) is not str or not section or "." in section:
            raise ValueError("Revisioned section must be a top-level name")
        if not isinstance(values, Mapping):
            raise TypeError("Revisioned section values must be a mapping")
        if type(revision_key) is not str or not revision_key:
            raise ValueError("Revision key must be a non-empty string")
        validated_expected = _valid_nonnegative_revision(expected_revision)
        if validated_expected is None:
            raise ValueError("Expected revision must be a nonnegative integer")
        replacement = copy.deepcopy(dict(values))
        replacement_revision = _valid_nonnegative_revision(
            replacement.get(revision_key)
        )
        if replacement_revision != validated_expected + 1:
            raise ValueError("Replacement revision must advance by exactly one")
        config_path = _get_effective_config_path()
    except Exception as error:
        logger.error(
            "Revisioned configuration replacement failed "
            "(phase=validation, section={}, error_type={}).",
            section if isinstance(section, str) else "invalid",
            type(error).__name__,
        )
        return ConfigMutationResult(False, False, "before_replace")

    with ExitStack() as locks:
        try:
            locks.enter_context(_config_write_lock(config_path))
        except Exception as error:
            logger.error(
                "Revisioned configuration replacement failed "
                "(phase=lock, section={}, error_type={}).",
                section,
                type(error).__name__,
            )
            return ConfigMutationResult(False, False, "before_replace")
        try:
            config_data = _read_raw_cli_config_unlocked(config_path)
        except Exception as error:
            logger.error(
                "Revisioned configuration replacement failed "
                "(phase=read, section={}, error_type={}).",
                section,
                type(error).__name__,
            )
            return ConfigMutationResult(False, False, "before_replace")

        current = config_data.get(section)
        current_revision = 0
        current_revision_is_valid = False
        if isinstance(current, Mapping):
            parsed_revision = _valid_nonnegative_revision(current.get(revision_key))
            if parsed_revision is not None:
                current_revision = parsed_revision
                current_revision_is_valid = True
        if current_revision != validated_expected:
            logger.info(
                "Revisioned configuration replacement rejected stale writer: "
                "section={}, expected_revision={}, current_revision={}",
                section,
                validated_expected,
                current_revision,
            )
            return ConfigMutationResult(False, False, None, conflict=True)

        if (
            current_revision_is_valid
            and isinstance(current, Mapping)
            and _without_revision(
                current,
                revision_key,
            )
            == _without_revision(replacement, revision_key)
        ):
            return ConfigMutationResult(False, False, None)

        config_data[section] = replacement
        try:
            persisted = _config_data_for_persistence(config_data)
            raw_written = _write_raw_cli_config_unlocked(config_path, persisted)
        except Exception as error:
            logger.error(
                "Revisioned configuration replacement failed "
                "(phase=before_replace, section={}, error_type={}).",
                section,
                type(error).__name__,
            )
            return ConfigMutationResult(False, False, "before_replace")

        try:
            _publish_runtime_config_unlocked(
                raw_config=raw_written, config_path=config_path
            )
        except Exception as error:
            logger.error(
                "Revisioned configuration replacement failed "
                "(phase=cache_reload, section={}, error_type={}).",
                section,
                type(error).__name__,
            )
            return ConfigMutationResult(True, False, "cache_reload")

        return ConfigMutationResult(True, True, None)


def _delete_config_keys(
    config_data: Dict[str, Any],
    delete_keys: Mapping[str, Collection[str]],
) -> bool:
    """Delete exact keys and report whether the config changed."""
    return _delete_literal_config_keys(
        config_data,
        {tuple(section.split(".")): keys for section, keys in delete_keys.items()},
    )


def _literal_config_section(
    config_data: Dict[str, Any],
    path: tuple[str, ...],
    *,
    create: bool,
) -> Dict[str, Any] | None:
    """Resolve one literal mapping path without interpreting punctuation."""

    current_level: Any = config_data
    for part in path:
        if not isinstance(current_level, dict):
            raise TypeError(part)
        if part not in current_level:
            if not create:
                return None
            current_level[part] = {}
        current_level = current_level[part]
    if not isinstance(current_level, dict):
        raise TypeError(".".join(path))
    return current_level


def _delete_literal_config_keys(
    config_data: Dict[str, Any],
    delete_keys: Mapping[tuple[str, ...], Collection[str]],
) -> bool:
    """Delete exact keys beneath literal paths and report whether any existed."""

    changed = False
    missing = object()
    for path, keys in delete_keys.items():
        current_level = _literal_config_section(config_data, path, create=False)
        if current_level is None:
            continue
        for key in keys:
            if current_level.pop(key, missing) is not missing:
                changed = True
    return changed


def _validate_config_mutation_targets(
    section_values: Mapping[str, Mapping[Any, Any]],
    delete_keys: Mapping[str, Collection[str]],
) -> None:
    """Validate input shapes and reject overlapping set/delete targets."""
    if not isinstance(section_values, Mapping) or not isinstance(
        delete_keys,
        Mapping,
    ):
        raise TypeError("Configuration mutations must use mappings")

    set_targets: set[tuple[str, Any]] = set()
    for section, values in section_values.items():
        if not isinstance(section, str) or not section:
            raise TypeError("Configuration sections must be non-empty strings")
        if section.partition(".")[0] in _REVISION_OWNED_CONFIG_SECTIONS:
            raise ValueError(
                "Revision-owned configuration requires its dedicated writer"
            )
        if not isinstance(values, Mapping):
            raise TypeError("Configuration section values must be mappings")
        for key in values:
            set_targets.add((section, key))

    delete_targets: set[tuple[str, str]] = set()
    for section, keys in delete_keys.items():
        if not isinstance(section, str) or not section:
            raise TypeError("Configuration sections must be non-empty strings")
        if section.partition(".")[0] in _REVISION_OWNED_CONFIG_SECTIONS:
            raise ValueError(
                "Revision-owned configuration requires its dedicated writer"
            )
        if isinstance(keys, (str, bytes)) or not isinstance(keys, Collection):
            raise TypeError("Configuration delete keys must be collections")
        for key in keys:
            if not isinstance(key, str) or not key:
                raise TypeError("Configuration delete keys must be non-empty strings")
            delete_targets.add((section, key))

    if set_targets.intersection(delete_targets):
        raise ValueError("Configuration mutation cannot set and delete the same key")


def _validate_literal_config_mutation_targets(
    mutation: LiteralSettingsMutation,
) -> None:
    """Validate literal paths and reject overlapping exact set/delete targets."""

    if not isinstance(mutation, LiteralSettingsMutation):
        raise TypeError("Literal mutation builder returned an invalid result")
    if not isinstance(mutation.section_values, Mapping) or not isinstance(
        mutation.delete_keys,
        Mapping,
    ):
        raise TypeError("Literal configuration mutations must use mappings")

    set_targets: set[tuple[tuple[str, ...], str]] = set()
    for path, values in mutation.section_values.items():
        _validate_literal_config_path(path)
        if not isinstance(values, Mapping):
            raise TypeError("Literal configuration section values must be mappings")
        for key in values:
            if type(key) is not str or not key:
                raise TypeError("Literal configuration keys must be non-empty strings")
            set_targets.add((path, key))

    delete_targets: set[tuple[tuple[str, ...], str]] = set()
    for path, keys in mutation.delete_keys.items():
        _validate_literal_config_path(path)
        if isinstance(keys, (str, bytes)) or not isinstance(keys, Collection):
            raise TypeError("Literal configuration delete keys must be collections")
        for key in keys:
            if type(key) is not str or not key:
                raise TypeError(
                    "Literal configuration delete keys must be non-empty strings"
                )
            delete_targets.add((path, key))

    if set_targets.intersection(delete_targets):
        raise ValueError("Configuration mutation cannot set and delete the same key")


def _detach_literal_settings_mutation(
    mutation: LiteralSettingsMutation,
) -> LiteralSettingsMutation:
    """Copy a builder-owned mutation before validation or application."""

    if not isinstance(mutation, LiteralSettingsMutation):
        raise TypeError("Literal mutation builder returned an invalid result")
    if not isinstance(mutation.section_values, Mapping) or not isinstance(
        mutation.delete_keys,
        Mapping,
    ):
        raise TypeError("Literal configuration mutations must use mappings")

    section_values: dict[tuple[str, ...], dict[str, object]] = {}
    for path, values in mutation.section_values.items():
        if type(path) is not tuple:
            raise TypeError("Literal configuration paths must be tuples")
        if not isinstance(values, Mapping):
            raise TypeError("Literal configuration section values must be mappings")
        owned_path = tuple(part for part in path)
        section_values[owned_path] = copy.deepcopy(dict(values))

    delete_keys: dict[tuple[str, ...], tuple[str, ...]] = {}
    for path, keys in mutation.delete_keys.items():
        if type(path) is not tuple:
            raise TypeError("Literal configuration paths must be tuples")
        if isinstance(keys, (str, bytes)) or not isinstance(keys, Collection):
            raise TypeError("Literal configuration delete keys must be collections")
        owned_path = tuple(part for part in path)
        delete_keys[owned_path] = tuple(keys)

    return LiteralSettingsMutation(
        section_values=section_values,
        delete_keys=delete_keys,
    )


def _validate_literal_config_path(path: object) -> None:
    """Validate one exact TOML mapping path."""

    if (
        type(path) is not tuple
        or not path
        or any(type(part) is not str or not part for part in path)
    ):
        raise TypeError("Literal configuration paths must be non-empty string tuples")
    if path[0] in _REVISION_OWNED_CONFIG_SECTIONS:
        raise ValueError("Revision-owned configuration requires its dedicated writer")


def _literal_mutation_log_shape(
    mutation: LiteralSettingsMutation,
) -> tuple[dict[str, list[str]], dict[str, list[str]]]:
    """Return value-free path/key shapes suitable for diagnostic logging."""

    sets = {
        repr(path): list(values.keys())
        for path, values in mutation.section_values.items()
    }
    deletes = {repr(path): list(keys) for path, keys in mutation.delete_keys.items()}
    return sets, deletes


def _current_settings_view() -> Mapping[str, object]:
    """Return a detached copy of the freshly published normalized settings."""

    return copy.deepcopy(settings)


def _apply_literal_mutation_unlocked(
    config_data: Dict[str, Any],
    mutation: LiteralSettingsMutation,
) -> bool:
    """Apply one validated literal mutation to the authoritative raw mapping."""

    deleted_any = _delete_literal_config_keys(config_data, mutation.delete_keys)
    set_any = False
    for path, values in mutation.section_values.items():
        if not values:
            continue
        current_level = _literal_config_section(config_data, path, create=True)
        assert current_level is not None
        for key, value in values.items():
            current_level[key] = _maybe_encrypt_setting_value(config_data, key, value)
            set_any = True
    return set_any or deleted_any


def _apply_literal_settings_transaction_locked(
    mutation_builder: Callable[
        [AtomicLiteralMutationSnapshot], LiteralSettingsMutation
    ],
    *,
    mutation_precondition: Callable[[], bool] | None,
    locked_snapshot_precondition: Callable[[AtomicConfigSnapshot], bool] | None = None,
    publish_noop: bool,
    validate_literal_targets: bool,
    before_replace: Callable[[], None] | None = None,
    after_replace: Callable[[], None] | None = None,
) -> LiteralConfigMutationResult:
    """Run one authoritative read/build/replace/publication transaction."""
    try:
        if not callable(mutation_builder):
            raise TypeError("Literal configuration mutation builder must be callable")
        if mutation_precondition is not None and not callable(mutation_precondition):
            raise TypeError("Configuration mutation precondition must be callable")
        if locked_snapshot_precondition is not None and not callable(
            locked_snapshot_precondition
        ):
            raise TypeError("Locked configuration precondition must be callable")
        if before_replace is not None and not callable(before_replace):
            raise TypeError("Before-replace callback must be callable")
        if after_replace is not None and not callable(after_replace):
            raise TypeError("After-replace callback must be callable")
        config_path = _get_effective_config_path()
    except Exception as error:
        logger.error(
            "Configuration mutation failed "
            "(phase=resolve_path, config_path=unresolved, error_type={}).",
            type(error).__name__,
        )
        return LiteralConfigMutationResult(False, False, None, "before_replace")

    with ExitStack() as locks:
        try:
            locks.enter_context(_config_write_lock(config_path))
        except Exception as error:
            logger.error(
                "Configuration mutation failed "
                "(phase=lock, config_path={}, error_type={}).",
                config_path,
                type(error).__name__,
            )
            return LiteralConfigMutationResult(False, False, None, "before_replace")
        try:
            config_data = _read_raw_cli_config_unlocked(config_path)
        except Exception as error:
            logger.error(
                "Configuration mutation failed "
                "(phase=read, config_path={}, error_type={}).",
                config_path,
                type(error).__name__,
            )
            return LiteralConfigMutationResult(False, False, None, "before_replace")

        if mutation_precondition is not None:
            try:
                if mutation_precondition() is not True:
                    return LiteralConfigMutationResult(
                        False, False, None, "identity_changed"
                    )
            except Exception as error:
                logger.error(
                    "Configuration mutation failed "
                    "(phase=precondition, error_type={}).",
                    type(error).__name__,
                )
                return LiteralConfigMutationResult(False, False, None, "before_replace")

        try:
            effective_values = _atomic_config_values_from_raw(config_data)
            if locked_snapshot_precondition is not None:
                legacy_snapshot = AtomicConfigSnapshot(
                    generation=_CONFIG_GENERATION,
                    values=copy.deepcopy(effective_values),
                )
                if locked_snapshot_precondition(legacy_snapshot) is not True:
                    return LiteralConfigMutationResult(
                        False, False, None, "identity_changed"
                    )
            snapshot = AtomicLiteralMutationSnapshot(
                generation=_CONFIG_GENERATION,
                raw_values=copy.deepcopy(config_data),
                effective_values=copy.deepcopy(effective_values),
                config_path=config_path,
            )
            mutation = _detach_literal_settings_mutation(mutation_builder(snapshot))
            if validate_literal_targets:
                _validate_literal_config_mutation_targets(mutation)
            logged_sets, logged_deletes = _literal_mutation_log_shape(mutation)
            logger.info(
                "Attempting to apply literal settings mutation: sets={}, deletes={}",
                logged_sets,
                logged_deletes,
            )
            if before_replace is not None:
                before_replace()
            changed = _apply_literal_mutation_unlocked(config_data, mutation)
        except Exception as error:
            logger.error(
                "Configuration mutation failed "
                "(phase=before_replace, config_path={}, error_type={}).",
                config_path,
                type(error).__name__,
            )
            return LiteralConfigMutationResult(False, False, None, "before_replace")

        if not changed and not publish_noop:
            return LiteralConfigMutationResult(False, False, None, None)

        raw_written: Mapping[str, Any] | None = None
        if changed:
            persisted: Mapping[str, Any] | None = None
            expected_raw: Mapping[str, Any] | None = None
            try:
                persisted = _config_data_for_persistence(config_data)
                expected_raw = tomllib.loads(dumps_cli_config(dict(persisted)))
                raw_written = _write_raw_cli_config_unlocked(config_path, persisted)
            except Exception as error:
                committed_content_visible = False
                if expected_raw is not None:
                    try:
                        committed_content_visible = (
                            _read_raw_cli_config_unlocked(config_path) == expected_raw
                        )
                    except Exception:
                        committed_content_visible = False
                if committed_content_visible:
                    logger.error(
                        "Configuration mutation failed after the requested "
                        "content became visible "
                        "(phase=cache_reload, config_path={}, error_type={}).",
                        config_path,
                        type(error).__name__,
                    )
                    return LiteralConfigMutationResult(
                        True, False, None, "cache_reload"
                    )
                logger.error(
                    "Configuration mutation failed "
                    "(phase=before_replace, config_path={}, error_type={}).",
                    config_path,
                    type(error).__name__,
                )
                return LiteralConfigMutationResult(False, False, None, "before_replace")
            logger.success(f"Successfully replaced settings file at {config_path}")
        else:
            _invalidate_config_caches()
            raw_written = config_data

        if after_replace is not None:
            try:
                after_replace()
            except Exception as error:
                logger.error(
                    "Configuration mutation failed "
                    "(phase=after_replace_callback, error_type={}).",
                    type(error).__name__,
                )
                return LiteralConfigMutationResult(changed, False, None, "cache_reload")

        try:
            _publish_runtime_config_unlocked(
                raw_config=raw_written, config_path=config_path
            )
            settings_view = _current_settings_view()
        except Exception as error:
            logger.error(
                "Configuration mutation failed "
                "(phase=cache_reload, config_path={}, error_type={}).",
                config_path,
                type(error).__name__,
            )
            return LiteralConfigMutationResult(changed, False, None, "cache_reload")

        logger.info("Global configuration caches invalidated and reloaded.")
        return LiteralConfigMutationResult(changed, True, settings_view, None)


def apply_literal_settings_transaction_to_cli_config(
    mutation_builder: Callable[
        [AtomicLiteralMutationSnapshot], LiteralSettingsMutation
    ],
    *,
    mutation_precondition: Callable[[], bool] | None = None,
) -> LiteralConfigMutationResult:
    """Apply a builder-produced mutation whose tuple paths stay fully literal."""

    return _apply_literal_settings_transaction_locked(
        mutation_builder,
        mutation_precondition=mutation_precondition,
        publish_noop=True,
        validate_literal_targets=True,
    )


def refresh_runtime_config_from_cli_config() -> LiteralConfigMutationResult:
    """Republish the existing on-disk config without writing the file."""

    try:
        config_path = _get_effective_config_path()
    except Exception as error:
        logger.error(
            "Configuration refresh failed (phase=resolve_path, error_type={}).",
            type(error).__name__,
        )
        return LiteralConfigMutationResult(False, False, None, "cache_reload")

    try:
        with _config_write_lock(config_path):
            raw = _read_raw_cli_config_unlocked(config_path)
            _invalidate_config_caches()
            _publish_runtime_config_unlocked(raw_config=raw, config_path=config_path)
            return LiteralConfigMutationResult(
                False,
                True,
                _current_settings_view(),
                None,
            )
    except Exception as error:
        logger.error(
            "Configuration refresh failed "
            "(phase=cache_reload, config_path={}, error_type={}).",
            config_path,
            type(error).__name__,
        )
        return LiteralConfigMutationResult(False, False, None, "cache_reload")


def apply_settings_mutation_to_cli_config(
    section_values: Mapping[str, Mapping[Any, Any]],
    *,
    delete_keys: Mapping[str, Collection[str]] | None = None,
    mutation_precondition: Callable[[], bool] | None = None,
    locked_snapshot_precondition: Callable[[AtomicConfigSnapshot], bool] | None = None,
    before_replace: Callable[[], None] | None = None,
    after_replace: Callable[[], None] | None = None,
) -> ConfigMutationResult:
    """Atomically apply exact config sets/deletes, then refresh caches."""
    requested_deletes = {} if delete_keys is None else delete_keys
    try:
        if not isinstance(section_values, Mapping) or not isinstance(
            requested_deletes,
            Mapping,
        ):
            raise TypeError("Configuration mutations must use mappings")
        owned_section_values: dict[str, dict[Any, Any]] = {}
        for section, values in section_values.items():
            if not isinstance(values, Mapping):
                raise TypeError("Configuration section values must be mappings")
            owned_section_values[section] = copy.deepcopy(dict(values.items()))
        owned_delete_keys: dict[str, tuple[str, ...]] = {}
        for section, keys in requested_deletes.items():
            if isinstance(keys, (str, bytes)) or not isinstance(keys, Collection):
                raise TypeError("Configuration delete keys must be collections")
            owned_delete_keys[section] = tuple(keys)

        _validate_config_mutation_targets(owned_section_values, owned_delete_keys)
        literal = _detach_literal_settings_mutation(
            LiteralSettingsMutation(
                section_values={
                    tuple(section.split(".")): values
                    for section, values in owned_section_values.items()
                },
                delete_keys={
                    tuple(section.split(".")): keys
                    for section, keys in owned_delete_keys.items()
                },
            )
        )
    except Exception as error:
        logger.error(
            "Configuration mutation failed "
            "(phase=validation, config_path=unresolved, error_type={}).",
            type(error).__name__,
        )
        return ConfigMutationResult(False, False, "before_replace")
    result = _apply_literal_settings_transaction_locked(
        lambda _snapshot: literal,
        mutation_precondition=mutation_precondition,
        locked_snapshot_precondition=locked_snapshot_precondition,
        before_replace=before_replace,
        after_replace=after_replace,
        publish_noop=False,
        validate_literal_targets=False,
    )
    if result.failure_phase == "identity_changed":
        return ConfigMutationResult(
            False,
            False,
            None,
            conflict=True,
            conflict_reason="identity_changed",
        )
    return ConfigMutationResult(
        result.file_replaced,
        result.caches_reloaded,
        result.failure_phase,
    )


@dataclass(frozen=True, slots=True)
class RuntimeCapturePolicy:
    """Canonical process projection for future Console capture admission.

    Attributes:
        enabled: Whether future Console calls require durable trace capture.
        detail: Admission-frozen trace capture detail.
        generation: Monotonic policy publication generation.
        pii_redaction_enabled: Whether configured PII masking is active.
        viewer_profile: Default redacted viewer profile.
        normalized_writes_enabled: Whether new normalized calls may be written.
        normalized_reads_enabled: Whether normalized calls participate in reads.
        legacy_writes_enabled: Whether compatibility snapshots are also written.
    """

    enabled: bool
    detail: CaptureDetail
    generation: int
    pii_redaction_enabled: bool = False
    viewer_profile: str = "safe"
    normalized_writes_enabled: bool = True
    normalized_reads_enabled: bool = True
    legacy_writes_enabled: bool = False
    custom_pii_ruleset: CustomPIIRuleset | None = field(default=None, repr=False)


_TRACE_ROLLOUT_BOOLEAN_ADAPTER = TypeAdapter(bool)


class TraceRolloutSettings(BaseModel):
    """Validated effective gates for the semantic trace rollout.

    Attributes:
        normalized_writes_enabled: Whether normalized calls may be written.
        normalized_reads_enabled: Whether normalized calls participate in reads.
        legacy_writes_enabled: Whether compatibility snapshots are also written.
    """

    model_config = ConfigDict(extra="forbid", frozen=True)
    normalized_writes_enabled: bool = True
    normalized_reads_enabled: bool = True
    legacy_writes_enabled: bool = False

    @field_validator(
        "normalized_writes_enabled",
        "normalized_reads_enabled",
        "legacy_writes_enabled",
        mode="before",
    )
    @classmethod
    def _coerce_boolean(cls, value: object, info: ValidationInfo) -> bool:
        defaults = {
            "normalized_writes_enabled": True,
            "normalized_reads_enabled": True,
            "legacy_writes_enabled": False,
        }
        try:
            return _TRACE_ROLLOUT_BOOLEAN_ADAPTER.validate_python(value)
        except ValidationError:
            return defaults[info.field_name]


_RUNTIME_CAPTURE_POLICY_LOCK = _threading.RLock()
_RUNTIME_CAPTURE_POLICY: RuntimeCapturePolicy | None = None
_TRACE_ROLLOUT_ENV_NAMES = (
    "TLDW_CONSOLE_TRACE_NORMALIZED_WRITES",
    "TLDW_CONSOLE_TRACE_NORMALIZED_READS",
    "TLDW_CONSOLE_TRACE_LEGACY_WRITES",
)
_RUNTIME_CAPTURE_POLICY_ENV: tuple[str | None, ...] | None = None


def _trace_rollout_environment() -> tuple[str | None, ...]:
    """Return the three rollout overrides as one cache identity.

    Returns:
        Environment values aligned with ``_TRACE_ROLLOUT_ENV_NAMES``.
    """

    return tuple(os.environ.get(name) for name in _TRACE_ROLLOUT_ENV_NAMES)


def _trace_rollout_environment_mapping(
    values: tuple[str | None, ...],
) -> dict[str, str]:
    """Map one captured rollout environment identity back to present values."""

    return {
        name: value
        for name, value in zip(_TRACE_ROLLOUT_ENV_NAMES, values, strict=True)
        if value is not None
    }


def resolve_trace_rollout_settings(
    console: object,
    *,
    environ: Mapping[str, str] | None = None,
) -> TraceRolloutSettings:
    """Validate rollout gates with environment-first precedence.

    Args:
        console: Raw Console configuration mapping.
        environ: Optional environment mapping. Defaults to ``os.environ``.

    Returns:
        The validated effective rollout settings.
    """

    values = console if isinstance(console, Mapping) else {}
    environment = os.environ if environ is None else environ

    def selected(environment_name: str, config_name: str, default: bool) -> object:
        override = environment.get(environment_name)
        return values.get(config_name, default) if override in (None, "") else override

    return TraceRolloutSettings.model_validate(
        {
            "normalized_writes_enabled": selected(
                _TRACE_ROLLOUT_ENV_NAMES[0],
                "trace_normalized_writes",
                True,
            ),
            "normalized_reads_enabled": selected(
                _TRACE_ROLLOUT_ENV_NAMES[1],
                "trace_normalized_reads",
                True,
            ),
            "legacy_writes_enabled": selected(
                _TRACE_ROLLOUT_ENV_NAMES[2],
                "trace_legacy_writes",
                False,
            ),
        }
    )


def resolve_trace_compaction_policy(console: object) -> "TraceCompactionPolicy":
    """Resolve bounded physical trace-maintenance thresholds from Console config."""

    from tldw_chatbook.Chat.console_trace_maintenance import TraceCompactionPolicy

    values = console if isinstance(console, Mapping) else {}
    retry_initial = coerce_float_setting(
        values.get("trace_compaction_retry_initial_seconds"),
        300.0,
        minimum=0.0,
        maximum=3600.0,
    )
    retry_max = coerce_float_setting(
        values.get("trace_compaction_retry_max_seconds"),
        3600.0,
        minimum=retry_initial,
        maximum=86400.0,
    )
    return TraceCompactionPolicy(
        min_database_bytes=coerce_int_setting(
            values.get("trace_compaction_min_database_bytes"),
            64 * 1024 * 1024,
            minimum=0,
        ),
        min_freelist_bytes=coerce_int_setting(
            values.get("trace_compaction_min_freelist_bytes"),
            16 * 1024 * 1024,
            minimum=0,
        ),
        min_freelist_ratio=coerce_float_setting(
            values.get("trace_compaction_min_freelist_ratio"),
            0.20,
            minimum=0.0,
            maximum=1.0,
        ),
        min_idle_seconds=coerce_float_setting(
            values.get("trace_compaction_min_idle_seconds"),
            30.0,
            minimum=0.0,
            maximum=86400.0,
        ),
        retry_initial_seconds=retry_initial,
        retry_max_seconds=retry_max,
        quiesce_timeout_seconds=coerce_float_setting(
            values.get("trace_compaction_quiesce_timeout_seconds"),
            5.0,
            minimum=0.0,
            maximum=60.0,
        ),
        disk_safety_margin_bytes=coerce_int_setting(
            values.get("trace_compaction_disk_safety_margin_bytes"),
            64 * 1024 * 1024,
            minimum=0,
        ),
    )


def _register_runtime_custom_pii_ruleset(
    ruleset: CustomPIIRuleset | None,
) -> CustomPIIRuleset | None:
    """Register valid rules for future masks or disable a reused revision."""

    if ruleset is None or not ruleset.runnable_rules:
        return ruleset
    from tldw_chatbook.Chat.console_trace_custom_pii import (
        register_custom_pii_ruleset,
    )

    if register_custom_pii_ruleset(ruleset):
        return ruleset
    logger.warning("custom_pii_ruleset_revision_conflict")
    return None


def _publish_runtime_capture_policy(
    enabled: bool,
    detail: CaptureDetail,
    generation: int,
    pii_redaction_enabled: bool = False,
    viewer_profile: str = "safe",
    normalized_writes_enabled: bool = True,
    normalized_reads_enabled: bool = True,
    legacy_writes_enabled: bool = False,
    custom_pii_ruleset: CustomPIIRuleset | None = None,
) -> RuntimeCapturePolicy:
    """Publish one validated capture policy without touching general caches."""
    from tldw_chatbook.Chat.console_exchange_capture import CaptureDetail
    from tldw_chatbook.Chat.console_trace_custom_pii import CustomPIIRuleset

    if not isinstance(detail, CaptureDetail):
        raise TypeError("detail must be CaptureDetail")
    if viewer_profile not in {"safe", "full"}:
        raise ValueError("viewer_profile")
    if custom_pii_ruleset is not None and not isinstance(
        custom_pii_ruleset, CustomPIIRuleset
    ):
        raise TypeError("custom_pii_ruleset")
    custom_pii_ruleset = _register_runtime_custom_pii_ruleset(custom_pii_ruleset)
    rollout_environment = _trace_rollout_environment()
    rollout = resolve_trace_rollout_settings(
        {
            "trace_normalized_writes": normalized_writes_enabled,
            "trace_normalized_reads": normalized_reads_enabled,
            "trace_legacy_writes": legacy_writes_enabled,
        },
        environ=_trace_rollout_environment_mapping(rollout_environment),
    )
    policy = RuntimeCapturePolicy(
        bool(enabled),
        detail,
        generation,
        bool(pii_redaction_enabled),
        viewer_profile,
        rollout.normalized_writes_enabled,
        rollout.normalized_reads_enabled,
        rollout.legacy_writes_enabled,
        custom_pii_ruleset,
    )
    global _RUNTIME_CAPTURE_POLICY, _RUNTIME_CAPTURE_POLICY_ENV
    with _RUNTIME_CAPTURE_POLICY_LOCK:
        _RUNTIME_CAPTURE_POLICY = policy
        _RUNTIME_CAPTURE_POLICY_ENV = rollout_environment
    return policy


def runtime_capture_policy() -> RuntimeCapturePolicy:
    """Return the shared runtime capture policy, resolving invalid detail Safe.

    Returns:
        The canonical enabled/detail projection and its config generation.
    """
    from tldw_chatbook.Chat.console_exchange_capture import CaptureDetail

    rollout_environment = _trace_rollout_environment()
    global _RUNTIME_CAPTURE_POLICY, _RUNTIME_CAPTURE_POLICY_ENV
    with _RUNTIME_CAPTURE_POLICY_LOCK:
        current = _RUNTIME_CAPTURE_POLICY
        if (
            current is not None
            and current.generation == _CONFIG_GENERATION
            and _RUNTIME_CAPTURE_POLICY_ENV == rollout_environment
        ):
            return current
    snapshot = _published_runtime_config_snapshot()
    with _RUNTIME_CAPTURE_POLICY_LOCK:
        current = _RUNTIME_CAPTURE_POLICY
        if (
            current is not None
            and current.generation == snapshot.generation
            and _RUNTIME_CAPTURE_POLICY_ENV == rollout_environment
        ):
            return current
        console = snapshot.values.get("console", {})
        if not isinstance(console, Mapping):
            console = {}
        try:
            detail = CaptureDetail(console.get("exchange_capture_detail", "safe"))
        except (TypeError, ValueError):
            detail = CaptureDetail.SAFE
        privacy = validate_trace_privacy_config(console)
        pii_redaction_enabled = privacy.exchange_capture_pii_redaction
        viewer_profile = privacy.effective_viewer_profile
        from tldw_chatbook.Chat.console_trace_custom_pii import (
            validate_custom_pii_rules_config,
        )

        custom_pii_ruleset = validate_custom_pii_rules_config(
            console.get("trace_custom_pii_rules")
        ).ruleset
        custom_pii_ruleset = _register_runtime_custom_pii_ruleset(custom_pii_ruleset)
        rollout = resolve_trace_rollout_settings(
            console,
            environ=_trace_rollout_environment_mapping(rollout_environment),
        )
        current = RuntimeCapturePolicy(
            coerce_bool_setting(console.get("exchange_capture", True), True),
            detail,
            snapshot.generation,
            pii_redaction_enabled,
            viewer_profile,
            rollout.normalized_writes_enabled,
            rollout.normalized_reads_enabled,
            rollout.legacy_writes_enabled,
            custom_pii_ruleset,
        )
        _RUNTIME_CAPTURE_POLICY = current
        _RUNTIME_CAPTURE_POLICY_ENV = rollout_environment
        return current


def apply_console_capture_settings(
    *,
    enabled: bool,
    detail: CaptureDetail,
    expected_generation: int,
    pii_redaction_enabled: bool | None = None,
    viewer_profile: str | None = None,
) -> ConfigMutationResult:
    """Apply the kill switch/detail with privacy-safe publication ordering.

    Args:
        enabled: Future-capture kill-switch state.
        detail: Safe or Full global capture detail.
        expected_generation: Config generation observed by the caller.

    Returns:
        Structured replacement/cache-publication status, including conflicts
        and partial post-replacement cache failures.
    """
    from tldw_chatbook.Chat.console_exchange_capture import CaptureDetail

    if (
        type(enabled) is not bool
        or not isinstance(detail, CaptureDetail)
        or (
            pii_redaction_enabled is not None
            and type(pii_redaction_enabled) is not bool
        )
        or (viewer_profile is not None and viewer_profile not in {"safe", "full"})
    ):
        return ConfigMutationResult(False, False, "before_replace")
    current = runtime_capture_policy()
    resolved_pii = (
        current.pii_redaction_enabled
        if pii_redaction_enabled is None
        else pii_redaction_enabled
    )
    resolved_viewer = (
        current.viewer_profile if viewer_profile is None else viewer_profile
    )

    def generation_is_current(snapshot: AtomicConfigSnapshot) -> bool:
        return snapshot.generation == expected_generation

    def publish_before_replace() -> None:
        _publish_runtime_capture_policy(
            enabled,
            detail,
            expected_generation,
            resolved_pii,
            resolved_viewer,
            current.normalized_writes_enabled,
            current.normalized_reads_enabled,
            current.legacy_writes_enabled,
            current.custom_pii_ruleset,
        )

    def publish_after_replace() -> None:
        # The general config generation advances only after cache publication
        # succeeds. Publishing the committed capture owner at the still-current
        # generation keeps it authoritative if that later step fails; on
        # success, the generation bump makes the next read rebuild from the new
        # canonical snapshot. This callback runs while the config write lock is
        # still held, so a newer writer cannot be overwritten afterward.
        _publish_runtime_capture_policy(
            enabled,
            detail,
            expected_generation,
            resolved_pii,
            resolved_viewer,
            current.normalized_writes_enabled,
            current.normalized_reads_enabled,
            current.legacy_writes_enabled,
            current.custom_pii_ruleset,
        )

    more_revealing = (
        (enabled and not current.enabled)
        or (detail is CaptureDetail.FULL and current.detail is CaptureDetail.SAFE)
        or (not resolved_pii and current.pii_redaction_enabled)
        or (resolved_viewer == "full" and current.viewer_profile == "safe")
    )
    privacy_safe = not more_revealing
    result = apply_settings_mutation_to_cli_config(
        {
            "console": {
                "exchange_capture": enabled,
                "exchange_capture_detail": detail.value,
                "exchange_capture_pii_redaction": resolved_pii,
                "trace_viewer_profile": resolved_viewer,
                "trace_viewer_profile_version": 1,
            }
        },
        locked_snapshot_precondition=generation_is_current,
        before_replace=publish_before_replace if privacy_safe else None,
        after_replace=None if privacy_safe else publish_after_replace,
    )
    return result


def save_settings_to_cli_config(
    section_values: Mapping[str, Mapping[Any, Any]],
    *,
    delete_keys: Mapping[str, Collection[str]] | None = None,
) -> bool:
    """Persist multiple config values with one atomic mutation and cache reload."""
    result = apply_settings_mutation_to_cli_config(
        section_values,
        delete_keys=delete_keys,
    )
    if result.conflict:
        return False
    if result.failure_phase is None and not result.file_replaced:
        return True
    return result.fully_applied


def delete_settings_from_cli_config(section: str, keys: List[str]) -> bool:
    """Remove exact keys through the structured atomic mutation primitive.

    Args:
        section: Dotted config section path (e.g. ``"console.rail_state"``).
        keys: Keys to remove from that section.

    Returns:
        True on success, including when the file, section, or keys are absent.
    """
    config_path = _get_effective_config_path()
    if not config_path.exists():
        return True

    result = apply_settings_mutation_to_cli_config(
        {},
        delete_keys={section: tuple(keys)},
    )
    if result.failure_phase is None and not result.file_replaced:
        return True
    return result.fully_applied


def save_setting_to_cli_config(section: str, key: str, value: Any) -> bool:
    """
    Saves a specific setting to the user's CLI TOML configuration file.

    This function reads the current config, updates a specific key within a
    section (handling nested sections like 'api_settings.openai'), and writes
    the entire configuration back to the file. It then forces a reload of the
    config cache.

    Args:
        section: The name of the TOML section (e.g., "general", "api_settings.openai").
        key: The key within the section to update.
        value: The new value for the key.

    Returns:
        True if the setting was saved successfully, False otherwise.
    """
    logger.info(
        f"Attempting to save setting: [{section}].{key} = "
        f"{_setting_value_for_log(key, value)}"
    )
    return save_settings_to_cli_config({section: {key: value}})


# --- CLI Setting Getter ---
# Sentinel distinguishing "no default argument was supplied at all" from an
# explicitly-passed `None` -- see the dotted-form disambiguation below.
_CLI_SETTING_DEFAULT_UNSET = object()


def current_config_identity() -> tuple[int, str]:
    """Return a cheap key that changes whenever the effective config changes.

    Two independent things can change what `get_cli_setting` returns, and a
    memoisation key must track BOTH:

    * ``_CONFIG_GENERATION`` -- bumped by every mutation path, so it catches
      writes to the config currently in force.
    * the effective config PATH -- retargeting ``TLDW_CONFIG_PATH`` selects a
      different file, and the loader serves the new file's values WITHOUT
      advancing the generation. Verified empirically while reviewing
      task-24456: after a retarget, `get_cli_setting` returned the new file's
      value while the generation stayed at 1, so a generation-only key served
      stale data. Caught in review by Qodo on PR #2217.

    Both reads are cheap -- an atomic reference load and an env-var lookup plus
    a lexical path expansion. No lock, no file access, no copy, which is what
    makes this usable on a hot path. ``get_runtime_config_snapshot`` and
    ``get_atomic_config_snapshot`` expose the same generation but take locks
    and deep-copy the values, so they are not substitutes here.

    Intended use (task-24456): a caller that derives an expensive view from
    many `get_cli_setting` reads caches that view against this tuple and
    recomputes only when it moves.

    Returns:
        ``(configuration generation, effective config path)``.
    """
    return (_CONFIG_GENERATION, str(_get_effective_config_path()))


def get_cli_setting(
    section: str, key: str = None, default: Any = _CLI_SETTING_DEFAULT_UNSET
) -> Any:
    """Helper to get a specific setting from the loaded CLI configuration.

    Can be called in two ways:
    1. get_cli_setting("section", "key", default)  # Traditional format
    2. get_cli_setting("section.key", default)     # Dotted format

    Dotted sections/keys that miss the flat top-level lookup are resolved
    against the nested TOML tree (``[chat.images]`` loads as
    ``config["chat"]["images"]``); a flat top-level hit always wins.

    Disambiguating form 1 from form 2 when exactly two positional
    arguments are supplied and ``section`` contains a dot: an explicit
    third argument (even ``None``) always means "traditional form,
    honour this default". Without one, ``section`` is the complete
    dotted path and ``key`` is really the default -- for a default of
    *any* type, not just non-string ones. (TASK-1771: the previous
    heuristic keyed off ``isinstance(key, str)``, so a string default --
    the common case for provider/model/language/device names -- was
    misread as one more path segment to walk, which always missed and
    silently returned ``None`` instead of either the configured value or
    the caller's own fallback.)

    Args:
        section: Top-level section name, or a dotted path into nested tables.
        key: Setting key within the section; in the dotted call shape this
            positional slot may carry the default instead.
        default: Value returned when the setting cannot be resolved.

    Returns:
        The resolved setting value, or ``default`` when the section/key does
        not exist.
    """
    config = load_cli_config_and_ensure_existence()  # Ensures config is loaded

    default_was_given = default is not _CLI_SETTING_DEFAULT_UNSET
    resolved_default = default if default_was_given else None

    # Handle dotted notation when key is None (called with positional args)
    if key is None and "." in section:
        # Split on first dot only to handle nested keys
        parts = section.split(".", 1)
        section = parts[0]
        key = parts[1]
    elif key is None:
        # No dot found and no key provided - invalid call
        return resolved_default
    elif not default_was_given and "." in section:
        # Pure 2-arg dotted form: get_cli_setting("a.b[.c...]", default).
        # `key` is really the caller's default (whatever its type) --
        # reclaim it before re-splitting `section` the same way the
        # 1-arg branch above does.
        resolved_default = key
        parts = section.split(".", 1)
        section = parts[0]
        key = parts[1]
    elif not default_was_given and not isinstance(key, str):
        # 2-arg call on an UNDOTTED section whose second positional is a
        # default, not a key -- `get_cli_setting("database", {})`. Keys are
        # always strings, so a non-string here can only be a default. This
        # shape never resolved anything (it returned the default and ignored
        # config), and it must keep returning that default rather than
        # reaching `dict.get()` with an unhashable key, which would raise
        # TypeError -- turning a long-lived silent misread into a crash for
        # callers like Helper_Scripts/Mass-Ingestion (found reviewing the
        # TASK-1771 fix).
        logger.warning(
            "get_cli_setting({!r}, <{}>) has no key; returning the default. "
            "Use get_cli_setting(section, key, default).",
            section,
            type(key).__name__,
        )
        return key

    # Flat lookup first: preserves every previously-working shape bit-for-bit
    # (a literal dotted top-level key, while impossible from TOML, wins).
    section_data = config.get(section)
    if isinstance(section_data, dict) and isinstance(key, str) and key in section_data:
        return section_data[key]
    # Nested fallback: TOML `[chat.images]` loads as config["chat"]["images"],
    # never config["chat.images"], so dotted sections/keys that miss the flat
    # lookup are resolved by walking the real tree segment by segment.
    if (
        isinstance(section, str)
        and isinstance(key, str)
        and ("." in section or "." in key)
    ):
        node: Any = config
        for part in (*section.split("."), *key.split(".")):
            if not isinstance(node, dict) or part not in node:
                return resolved_default
            node = node[part]
        return node
    if isinstance(section_data, dict) and isinstance(key, str):
        return section_data.get(key, resolved_default)
    # A non-string `key` reaches here from a caller that passed a whole default
    # as the second positional argument while meaning "give me this section"
    # -- e.g. `get_cli_setting("database", {})`. That shape never worked (it
    # silently returned the default and ignored config), but it must not
    # CRASH: `dict.get()` on an unhashable key raises TypeError, which would
    # turn a long-standing silent misread into a hard failure in callers that
    # have lived with it for a long time (Helper_Scripts/Mass-Ingestion, found
    # in review of the TASK-1771 fix). Return the caller's default, exactly as
    # before, and let the misuse stay visible in the warning below.
    if not isinstance(key, str):
        logger.warning(
            "get_cli_setting({!r}, ...) was called with a non-string key ({}); "
            "returning the default. Use get_cli_setting(section, key, default).",
            section,
            type(key).__name__,
        )
    # If section is not a dict or not found, return default
    return resolved_default


def get_chat_defaults_streaming(default: bool = True) -> bool:
    """Return chat default streaming with canonical-first legacy fallback."""
    config = load_cli_config_and_ensure_existence()
    chat_defaults = config.get("chat_defaults")
    if not isinstance(chat_defaults, dict):
        return default
    if "streaming" in chat_defaults:
        return coerce_bool_setting(chat_defaults.get("streaming"), default)
    if "enable_streaming" in chat_defaults:
        return coerce_bool_setting(chat_defaults.get("enable_streaming"), default)
    return default


def get_chat_defaults_user_display_name(default: str = "User") -> str:
    """Return the validated global human-facing Console chat name.

    Args:
        default: Fallback used when ``chat_defaults.user_display_name`` is
            absent.

    Returns:
        The configured validated name, or the neutral ``"User"`` fallback
        when the configured/default value is invalid.
    """
    # Import lazily because ``tldw_chatbook.Chat.__init__`` reaches runtime
    # policy modules that import this configuration module during startup.
    from tldw_chatbook.Chat.console_roleplay_identity import (
        ChatDisplayNameError,
        normalize_chat_display_name,
    )

    config = load_cli_config_and_ensure_existence()
    chat_defaults = config.get("chat_defaults")
    raw_value = (
        chat_defaults.get("user_display_name", default)
        if isinstance(chat_defaults, dict)
        else default
    )
    try:
        return normalize_chat_display_name(raw_value, blank_means_none=False) or "User"
    except ChatDisplayNameError:
        logger.warning(
            "Invalid chat display name in [chat_defaults]; using the neutral default."
        )
        return "User"


def get_rag_citation_canonical_writes_enabled() -> bool:
    """Return the typed, fail-closed canonical citation write switch.

    Returns:
        ``True`` when canonical citation writes are explicitly enabled.
    """

    config = load_cli_config_and_ensure_existence()
    section = config.get("rag_citations")
    if not isinstance(section, dict):
        return False
    return coerce_bool_setting(section.get("canonical_writes_enabled"), False)


def get_media_ingestion_defaults(media_type: str) -> Dict[str, Any]:
    """
    Get default chunking settings for a specific media type.

    Args:
        media_type: Type of media ('pdf', 'ebook', 'document', 'plaintext', 'web_article')

    Returns:
        Dictionary containing chunking configuration for the media type
    """
    # First check if user has custom settings in config
    config = load_cli_config_and_ensure_existence()
    media_ingestion_config = config.get("media_ingestion", {})

    # Get media-specific config if it exists
    if media_type in media_ingestion_config and isinstance(
        media_ingestion_config[media_type], dict
    ):
        # Use deep merge to combine with defaults, allowing partial overrides
        return deep_merge_dicts(
            DEFAULT_MEDIA_INGESTION_CONFIG.get(media_type, {}),
            media_ingestion_config[media_type],
        )

    # Fall back to hardcoded defaults
    return DEFAULT_MEDIA_INGESTION_CONFIG.get(
        media_type,
        {
            "chunk_method": "paragraphs",
            "chunk_size": 500,
            "chunk_overlap": 200,
            "use_adaptive_chunking": False,
            "use_multi_level_chunking": False,
            "chunk_language": "",
        },
    )




def get_ocr_backend_config(backend_name: str) -> Dict[str, Any]:
    """
    Get configuration for a specific OCR backend.

    Args:
        backend_name: Name of the OCR backend (e.g., 'docext', 'tesseract')

    Returns:
        Dictionary containing backend configuration
    """
    # First check if user has custom settings in config
    config = load_cli_config_and_ensure_existence()
    ocr_backend_config = config.get("ocr_backends", {})

    # Get backend-specific config if it exists
    if backend_name in ocr_backend_config and isinstance(
        ocr_backend_config[backend_name], dict
    ):
        # Use deep merge to combine with defaults, allowing partial overrides
        return deep_merge_dicts(
            DEFAULT_OCR_BACKEND_CONFIG.get(backend_name, {}),
            ocr_backend_config[backend_name],
        )

    # Fall back to hardcoded defaults
    return DEFAULT_OCR_BACKEND_CONFIG.get(backend_name, {})


# --- CLI Providers and Models Getter ---
def get_cli_providers_and_models() -> Dict[str, List[str]]:
    config = load_settings()
    providers_data = config.get(
        "providers", {}
    )  # Default to empty dict if "providers" isn't there
    valid_providers: Dict[str, List[str]] = {}
    if isinstance(providers_data, dict):
        for provider, models in providers_data.items():
            if isinstance(models, list) and all(isinstance(m, str) for m in models):
                valid_providers[provider] = models
            else:
                logger.warning(
                    f"Invalid model list for provider '{provider}' in CLI config [providers]. Models: {models}. Skipping."
                )
    else:
        logger.error(
            f"CLI Config 'providers' section is not a dictionary. Found: {type(providers_data)}. No provider/model data available."
        )
    return valid_providers


def _normalize_provider_lookup_key(provider: Any) -> str:
    """Return the canonical lookup form used for provider key comparisons."""
    return normalize_provider_config_key(provider)


def resolve_provider_name(
    provider: Any,
    providers_models: Dict[str, List[str]],
) -> str:
    """Return the configured provider name as it appears in provider options.

    Config files commonly use API-setting keys such as ``llama_cpp`` while the
    selectable provider list may expose display keys such as ``Llama_cpp``.
    This keeps UI defaults from falling back to the first provider.
    """
    provider_name = str(provider or "").strip()
    if not provider_name:
        return provider_name
    if provider_name in providers_models:
        return provider_name

    normalized_provider = _normalize_provider_lookup_key(provider_name)
    for available_provider in providers_models:
        if _normalize_provider_lookup_key(available_provider) == normalized_provider:
            return available_provider
    return provider_name


def check_encryption_needed() -> bool:
    """
    Check if the config has API keys that should be encrypted.

    Returns:
        True if API keys are detected and encryption is not enabled
    """
    config = load_cli_config_and_ensure_existence()

    # Check if encryption is already enabled
    if config.get("encryption", {}).get("enabled", False):
        return False

    # Check for API keys
    enc_module = get_encryption_module()
    return enc_module.detect_api_keys(config)


def get_detected_api_providers() -> List[str]:
    """
    Get list of providers with detected API keys.

    Returns:
        List of provider names with API keys
    """
    config = load_cli_config_and_ensure_existence()
    providers = []

    # TASK-32811.3: a nested TOML load produces `config["api_settings"]` as a
    # nested table, never flat `"api_settings.<provider>"` top-level keys, so
    # the old iteration matched nothing and this always returned []. Read the
    # nested table, and screen each key through `resolve_provider_api_key`
    # (the shared validity rule) rather than the ad-hoc `<...>` check, so a
    # padded or otherwise-invalid key is not counted as configured.
    api_settings = config.get("api_settings")
    if isinstance(api_settings, Mapping):
        for provider_name, provider_config in api_settings.items():
            if not isinstance(provider_config, Mapping):
                continue
            if resolve_provider_api_key(provider_config.get("api_key")) is not None:
                providers.append(provider_name)

    return providers


# --- Config key-encryption lifecycle (TASK-34100.4) ---------------------------
#
# One owner for the four states (off / on / locked / unlocked). Every change
# below follows the same contract, because a mistake here locks people out of
# their own app (first-run review 2026-10-02, protect-summary-04):
#
# * validate BEFORE writing -- the replacement document must strict-decrypt
#   with the password the session will hold afterwards, and must not leave a
#   plaintext secret behind in an encrypted file;
# * if anything fails after the write (the runtime publish, a binding check),
#   restore the previous file bytes -- or remove a file this call created --
#   and the previous in-process password, so a failure never leaves the disk
#   changed while the caller is told nothing happened;
# * never decrypt non-strictly: a file whose keys do not match its verifier is
#   refused untouched instead of having its ciphertext written back as values.


def _set_session_encryption_password(password: Optional[str]) -> None:
    """Install (or clear) the in-process password and drop stale caches."""

    global _SETTINGS_CACHE, _CONFIG_CACHE
    if password is None:
        clear_encryption_password()
        _SETTINGS_CACHE = None
        _CONFIG_CACHE = None
        return
    set_encryption_password(password)


def _parse_raw_cli_config_text(serialized: Optional[str]) -> Dict[str, Any]:
    if serialized is None:
        return {}
    loaded = tomllib.loads(serialized)
    if not isinstance(loaded, dict):
        raise TypeError("The CLI config must contain a top-level table")
    return loaded


def _password_verifier(config_data: Mapping[str, Any]) -> Optional[str]:
    encryption = config_data.get("encryption", {})
    if not isinstance(encryption, Mapping):
        return None
    verifier = encryption.get("password_verifier")
    return verifier if isinstance(verifier, str) and verifier else None


def _validate_encrypted_document(
    document: Mapping[str, Any],
    password: str,
) -> None:
    """Raise unless ``document`` is a safe encrypted config for ``password``.

    The check mirrors what the next publish and the next startup do: the
    merged view must strict-decrypt, and no sensitive value may stay plain.
    """

    merged = deep_merge_dicts(DEFAULT_CONFIG_FROM_TOML, dict(document))
    get_encryption_module().decrypt_config_strict(merged, password)
    if _contains_unencrypted_sensitive_value(document):
        raise ValueError("An encrypted config would keep a plaintext secret")


def _strip_encrypted_values(config_data: Mapping[str, Any]) -> Dict[str, Any]:
    """Return a copy with every ``enc:`` string value removed, in every table.

    Arrays are walked too (Qodo round, PR #3000): an ``enc:`` element is
    dropped from its array and a table inside an array is stripped like any
    other, so a reset never leaves ciphertext behind in a TOML array.
    """

    stripped: Dict[str, Any] = {}
    for key, value in config_data.items():
        if is_encrypted_config_value(value):
            continue
        stripped[key] = _strip_encrypted_item(value)
    return stripped


def _strip_encrypted_item(value: Any) -> Any:
    """Strip ``enc:`` strings from one table or array value (copied)."""

    if isinstance(value, Mapping):
        return _strip_encrypted_values(value)
    if isinstance(value, list):
        return [
            _strip_encrypted_item(item)
            for item in value
            if not is_encrypted_config_value(item)
        ]
    return copy.deepcopy(value)


def _encrypted_value_paths(
    config_data: Mapping[str, Any], prefix: tuple[str, ...] = ()
) -> list[str]:
    """Dotted paths of every ``enc:`` value outside the ``[encryption]`` table."""

    paths: list[str] = []
    for key, value in config_data.items():
        if not prefix and key == "encryption":
            continue
        if isinstance(value, Mapping):
            paths.extend(_encrypted_value_paths(value, prefix + (str(key),)))
        elif is_encrypted_config_value(value):
            paths.append(".".join(prefix + (str(key),)))
    return paths


def _contains_encrypted_value(config_data: Mapping[str, Any]) -> bool:
    return bool(_encrypted_value_paths(config_data))


def _already_encrypted_with(config_data: Mapping[str, Any], password: str) -> bool:
    """Whether an encryption-on file is already exactly what enabling with
    ``password`` would produce: the verifier accepts it, every saved value
    strict-decrypts with it, and no sensitive value is left in plain text."""

    verifier = _password_verifier(config_data)
    if verifier is None:
        return False
    if not get_encryption_module().verify_password(password, verifier):
        return False
    try:
        _validate_encrypted_document(config_data, password)
    except ValueError:
        return False
    return True


def _restore_previous_config_unlocked(
    config_path: Path,
    previous_serialized: Optional[str],
) -> None:
    """Put the exact previous bytes back (or remove a file this call created).

    Args:
        config_path: The selected config file the failed change wrote.
        previous_serialized: The file's exact text before the change, or
            None when the change created the file.

    Raises:
        ValueError: The path fails ``validate_path_simple``; nothing is
            removed.
        OSError: Reading, removing or rewriting the file failed.
    """

    current = _try_read_cli_config_serialized_unlocked(config_path)
    if current == previous_serialized:
        return
    if previous_serialized is None:
        # The only raw filesystem call here; the restore write below goes
        # through the private atomic writer. Same validation as the hooks
        # snapshot's lock target: the path only reaches unlink(), never a
        # shell, and unlink() removes a link itself, not what it points to.
        removable = validate_path_simple(
            config_path,
            require_exists=False,
            probe_existing=False,
            reject_shell_metacharacters=False,
        )
        removable.unlink(missing_ok=True)
        _invalidate_config_caches()
        return
    _commit_serialized_cli_config_unlocked(
        config_path,
        previous_serialized,
        _prepare_config_parent(config_path),
    )


def _unlock_session_with_password_unlocked(config_path: Path, password: str) -> bool:
    """Install ``password`` for an unchanged file and republish settings.

    The same-password enable writes nothing, but a session that loaded the
    file without the password published its ciphertext in ``settings``;
    installing the password alone left every reader of that global on the
    locked view (Qodo round, PR #3000). Callers hold the write lock and have
    already checked that ``password`` reads the file.

    Args:
        config_path: The selected config file (used for log context only).
        password: The master password the file is encrypted under.

    Returns:
        True when the session holds ``password`` and the published settings
        are decrypted with it; False when the publish failed, in which case
        the previous session password is put back.
    """

    previous_password = get_encryption_password()
    _set_session_encryption_password(password)
    try:
        _publish_runtime_config_unlocked()
        return True
    except Exception as error:
        logger.error(
            "Publishing the unlocked config failed; the session was left as "
            "it was (action=enable, config_path={}, error_type={}).",
            redact_user_paths(str(config_path)),
            type(error).__name__,
        )
    _set_session_encryption_password(previous_password)
    return False


def _session_password_for_file(
    config_path: Path,
    previous_serialized: Optional[str],
    *,
    previous_password: Optional[str],
    written_password: Optional[str],
) -> Optional[str]:
    """The password that reads the file as it is after a rollback attempt."""

    try:
        current = _try_read_cli_config_serialized_unlocked(config_path)
    except Exception:
        return None
    if current == previous_serialized:
        return previous_password
    return written_password


def _commit_encryption_change_unlocked(
    config_path: Path,
    document: Mapping[str, Any],
    previous_serialized: Optional[str],
    *,
    session_password: Optional[str],
    action: str,
) -> bool:
    """Write ``document``, install ``session_password`` and publish -- or roll back.

    Callers hold the write lock and have already validated ``document``.
    """

    previous_password = get_encryption_password()
    try:
        raw_written = _write_raw_cli_config_unlocked(config_path, document)
        _set_session_encryption_password(session_password)
        _publish_runtime_config_unlocked(
                raw_config=raw_written, config_path=config_path
            )
        return True
    except Exception as error:
        logger.error(
            "Config encryption change failed; restoring the previous config "
            "(action={}, error_type={}).",
            action,
            type(error).__name__,
        )
    try:
        _restore_previous_config_unlocked(config_path, previous_serialized)
    except Exception as restore_error:
        logger.error(
            "Restoring the previous config after a failed encryption change "
            "failed (action={}, error_type={}).",
            action,
            type(restore_error).__name__,
        )
    # The session password must match what the file holds NOW (review round
    # 1, F7): the previous one after a restore, the new one when the restore
    # failed and the new document stayed. Reverting it then would encrypt the
    # next save under the old password beside the new verifier -- the
    # stranded state. An unreadable file locks the session rather than guess.
    _set_session_encryption_password(
        _session_password_for_file(
            config_path,
            previous_serialized,
            previous_password=previous_password,
            written_password=session_password,
        )
    )
    try:
        _publish_runtime_config_unlocked()
    except Exception as publish_error:
        logger.warning(
            "Republishing the restored config failed (action={}, error_type={}).",
            action,
            type(publish_error).__name__,
        )
    return False


def config_encryption_enabled_on_disk() -> Optional[bool]:
    """Whether the selected config file currently has encryption turned on.

    Returns:
        True or False from the file, or None when it could not be read (the
        caller keeps whatever state it already showed).
    """

    try:
        config_path = get_cli_config_path()
        with _config_write_lock(config_path):
            serialized = _try_read_cli_config_serialized_unlocked(config_path)
        return _encryption_enabled(_parse_raw_cli_config_text(serialized))
    except Exception as error:
        logger.warning(
            "Reading the config encryption state failed (error_type={}).",
            type(error).__name__,
        )
        return None


def encrypted_value_paths_on_disk() -> list[str]:
    """Dotted paths of the ``enc:`` values in the selected config file.

    Used to name a value that is still encrypted under an earlier password
    when encrypting is refused over it. Empty when there are none or the file
    cannot be read.
    """

    try:
        config_path = get_cli_config_path()
        with _config_write_lock(config_path):
            serialized = _try_read_cli_config_serialized_unlocked(config_path)
        return _encrypted_value_paths(_parse_raw_cli_config_text(serialized))
    except Exception as error:
        logger.warning(
            "Listing encrypted config values failed (error_type={}).",
            type(error).__name__,
        )
        return []


def verify_config_encryption_password(password: str) -> bool:
    """Whether ``password`` matches the saved master-password verifier.

    Returns False when encryption is off or the verifier is missing. Runs
    scrypt, so call it off the UI thread.
    """

    try:
        config_path = get_cli_config_path()
        with _config_write_lock(config_path):
            serialized = _try_read_cli_config_serialized_unlocked(config_path)
        config_data = _parse_raw_cli_config_text(serialized)
        verifier = _password_verifier(config_data)
        if not _encryption_enabled(config_data) or verifier is None:
            return False
        return bool(get_encryption_module().verify_password(password, verifier))
    except Exception as error:
        logger.warning(
            "Checking the master password failed (error_type={}).",
            type(error).__name__,
        )
        return False


def enable_config_encryption(password: str) -> bool:
    """
    Enable encryption for the config file and encrypt existing API keys.

    Refuses (returns False without writing) when encryption is already on
    with a different password: re-running enable used to rewrite the
    verifier over keys still encrypted under the first password. Use
    `change_encryption_password` to rotate. Enabling again with the SAME
    password, on a file that is already fully encrypted under it, writes
    nothing and returns True (review round 2, R2-F4); when this session did
    not hold that password it is installed and the runtime settings are
    republished, so a locked session is fully unlocked (Qodo round).

    Args:
        password: The master password to use for encryption

    Returns:
        True if encryption was enabled successfully, or already was with
        this password
    """
    try:
        config_path = get_cli_config_path()
        with _config_write_lock(config_path):
            previous = _try_read_cli_config_serialized_unlocked(config_path)
            config_data = _parse_raw_cli_config_text(previous)
            if _encryption_enabled(config_data):
                if _already_encrypted_with(config_data, password):
                    if get_encryption_password() != password and not (
                        _unlock_session_with_password_unlocked(config_path, password)
                    ):
                        return False
                    logger.info(
                        "Config encryption is already enabled with this "
                        "password; nothing was changed."
                    )
                    return True
                logger.warning(
                    "Config encryption is already enabled; refusing to enable "
                    "it again. Change the master password instead."
                )
                return False
            encrypted_config = encrypt_api_keys_in_config(config_data, password)
            _validate_encrypted_document(encrypted_config, password)
            if not _commit_encryption_change_unlocked(
                config_path,
                encrypted_config,
                previous,
                session_password=password,
                action="enable",
            ):
                return False

        logger.success("Config encryption enabled successfully")
        return True

    except Exception as e:
        logger.error(
            "Failed to enable config encryption (error_type={}).", type(e).__name__
        )
        return False


def disable_config_encryption(password: str) -> bool:
    """
    Disable encryption for the config file and decrypt all values.

    Every saved value must decrypt with ``password`` (strict); otherwise the
    file is left untouched and False is returned.

    Args:
        password: The master password to verify before disabling

    Returns:
        True if encryption was disabled successfully
    """
    try:
        config_path = get_cli_config_path()
        with _config_write_lock(config_path):
            previous = _try_read_cli_config_serialized_unlocked(config_path)
            config_data = _parse_raw_cli_config_text(previous)
            if _encryption_enabled(config_data):
                verifier = _password_verifier(config_data)
                if verifier is None:
                    logger.error("No password verifier found in encryption config")
                    return False
                enc_module = get_encryption_module()
                if not enc_module.verify_password(password, verifier):
                    logger.error("Invalid password provided")
                    return False
                try:
                    decrypted_config = enc_module.decrypt_config_strict(
                        config_data, password
                    )
                except ValueError:
                    logger.error(
                        "Some saved values do not decrypt with this password; "
                        "encryption was left on (action=disable, config_path={}).",
                        redact_user_paths(str(config_path)),
                    )
                    return False
            elif "encryption" in config_data:
                decrypted_config = copy.deepcopy(config_data)
            else:
                _set_session_encryption_password(None)
                logger.info("Config encryption is already disabled")
                return True
            decrypted_config.pop("encryption", None)
            if _contains_encrypted_value(decrypted_config):
                logger.error(
                    "Encrypted values would remain after disabling encryption; "
                    "encryption was left on (action=disable, config_path={}).",
                    redact_user_paths(str(config_path)),
                )
                return False
            if not _commit_encryption_change_unlocked(
                config_path,
                decrypted_config,
                previous,
                session_password=None,
                action="disable",
            ):
                return False

        logger.success("Config encryption disabled successfully")
        return True

    except Exception as e:
        logger.error(
            "Failed to disable config encryption (error_type={}).", type(e).__name__
        )
        return False


def change_encryption_password(old_password: str, new_password: str) -> bool:
    """
    Change the encryption password.

    Every saved value must decrypt with ``old_password`` (strict), and the
    re-encrypted document must decrypt with ``new_password`` before it is
    written; otherwise the file is left untouched.

    Args:
        old_password: The current password
        new_password: The new password to set

    Returns:
        True if password was changed successfully
    """
    try:
        config_path = get_cli_config_path()
        with _config_write_lock(config_path):
            previous = _try_read_cli_config_serialized_unlocked(config_path)
            config_data = _parse_raw_cli_config_text(previous)
            if not _encryption_enabled(config_data):
                logger.error("Encryption is not enabled")
                return False

            enc_module = get_encryption_module()
            verifier = _password_verifier(config_data)
            if verifier is None:
                logger.error("No password verifier found in encryption config")
                return False
            if not enc_module.verify_password(old_password, verifier):
                logger.error("Invalid current password provided")
                return False
            try:
                decrypted_config = enc_module.decrypt_config_strict(
                    config_data, old_password
                )
            except ValueError:
                logger.error(
                    "Some saved values do not decrypt with the current password; "
                    "the password was not changed (action=change, config_path={}).",
                    redact_user_paths(str(config_path)),
                )
                return False
            encrypted_config = encrypt_api_keys_in_config(
                decrypted_config,
                new_password,
            )
            _validate_encrypted_document(encrypted_config, new_password)
            if not _commit_encryption_change_unlocked(
                config_path,
                encrypted_config,
                previous,
                session_password=new_password,
                action="change",
            ):
                return False

        logger.success("Encryption password changed successfully")
        return True

    except Exception as e:
        logger.error(
            "Failed to change encryption password (error_type={}).",
            type(e).__name__,
        )
        return False


def rekey_encryption_verifier(password: str) -> bool:
    """Make ``password`` the master password again when it reads every key.

    For an encryption-on file whose verifier is missing, or was rewritten
    for another password while the keys stayed under this one (the stranded
    state an old second enable left behind). Without this the only way past
    either was a reset that deleted keys this password still reads (TASK-
    34100.4 review round 2, R2-F5). Every ``enc:`` value outside
    ``[encryption]`` must strict-decrypt with ``password``, and there must be
    at least one -- with none, any guess would "read every key". The file is
    re-encrypted under ``password`` with a new verifier, through the same
    validate-then-write and rollback as `change_encryption_password`.

    Args:
        password: The password the user typed at the startup prompt.

    Returns:
        True when the file now answers to ``password`` and the session holds
        it; False (file untouched) otherwise.
    """
    try:
        config_path = get_cli_config_path()
        with _config_write_lock(config_path):
            previous = _try_read_cli_config_serialized_unlocked(config_path)
            config_data = _parse_raw_cli_config_text(previous)
            if not _encryption_enabled(config_data):
                return False
            values = {
                key: value for key, value in config_data.items() if key != "encryption"
            }
            if not _contains_encrypted_value(values):
                return False
            try:
                decrypted_config = get_encryption_module().decrypt_config_strict(
                    values, password, log_failure=False
                )
            except ValueError:
                return False
            decrypted_config["encryption"] = copy.deepcopy(config_data["encryption"])
            encrypted_config = encrypt_api_keys_in_config(decrypted_config, password)
            _validate_encrypted_document(encrypted_config, password)
            if not _commit_encryption_change_unlocked(
                config_path,
                encrypted_config,
                previous,
                session_password=password,
                action="rekey",
            ):
                return False

        logger.success("The master-password check was repaired")
        return True

    except Exception as e:
        logger.error(
            "Repairing the master-password check failed (error_type={}).",
            type(e).__name__,
        )
        return False


def reset_encrypted_config_values() -> bool:
    """Forgot-password reset: drop every encrypted value and turn encryption off.

    Strips every ``enc:`` value from every table and array (sensitive or
    not -- none of them can be read without the password) and removes
    ``[encryption]``. Chats, notes, documents and every plain setting are
    untouched; the user re-enters API keys afterwards.

    Returns:
        True when the file now holds no encrypted value and encryption is off.
    """
    try:
        config_path = get_cli_config_path()
        with _config_write_lock(config_path):
            previous = _try_read_cli_config_serialized_unlocked(config_path)
            if previous is None:
                _set_session_encryption_password(None)
                return True
            config_data = _parse_raw_cli_config_text(previous)
            stripped = _strip_encrypted_values(config_data)
            stripped.pop("encryption", None)
            if not _commit_encryption_change_unlocked(
                config_path,
                stripped,
                previous,
                session_password=None,
                action="reset",
            ):
                return False

        logger.success("Encrypted config values were reset")
        return True

    except Exception as e:
        logger.error(
            "Resetting encrypted config values failed (error_type={}).",
            type(e).__name__,
        )
        return False


# --- CLI Database and Log File Path Getters ---
BASE_DATA_DIR_CLI = Path.home() / ".local" / "share" / "tldw_cli"  # Renamed for clarity
_DEFAULT_DATA_FALLBACK_DIRECTORY = ".tldw_cli-data"
# NOTE: BASE_DATA_DIR_CLI is a module-level constant frozen at IMPORT time
# (kept for backward compatibility -- some callers reference it directly).
# get_user_data_dir()'s fallback below does NOT use it; it resolves the
# default at CALL time via _default_base_data_dir() instead, so per-test
# HOME monkeypatches (applied well after this module is first imported) are
# actually honored. See task-519. (XDG_DATA_HOME is deliberately NOT
# consulted -- see _default_base_data_dir()'s docstring.)


def _default_base_data_dir() -> Path:
    """Default data dir resolved at CALL time (honors post-import HOME changes
    for test isolation; task-519). Deliberately does NOT honor XDG_DATA_HOME:
    the pre-existing default never did, and adding it would silently relocate
    an XDG user's data dir on upgrade with no migration (task-519 review).

    Uses os.environ["HOME"] explicitly (falling back to Path.home()) because
    Path.home() is not guaranteed to re-read a post-import HOME monkeypatch
    on every platform/Python version, whereas os.environ is always read live.
    """
    return profile_paths.default_base_data_dir()


def _data_root_entry_exists(path: Path) -> bool:
    """Count links as existing data; never interpret access errors as absence."""
    path = validate_path_simple(path, require_exists=False, probe_existing=False)
    try:
        path.lstat()
    except FileNotFoundError:
        return False
    return True


def _selected_default_base_data_dir() -> Path:
    """Read the durable default-root selection without creating directories."""
    conventional = _default_base_data_dir()
    fallback = conventional.parents[2] / _DEFAULT_DATA_FALLBACK_DIRECTORY
    if not _data_root_entry_exists(fallback):
        return conventional
    if _data_root_entry_exists(conventional):
        raise PrivatePathError(
            PrivatePathResult(
                conventional,
                PrivatePathStatus.OPERATION_FAILED,
                reason="ambiguous_default_data_roots",
            )
        )
    return fallback


@contextmanager
def _default_data_root_lock() -> Iterator[None]:
    """Serialize root selection and profile creation across starts (ADR-127)."""
    lock_path = validate_path_simple(
        _default_base_data_dir().parents[2] / profile_paths.DATA_ROOT_LOCK_NAME,
        require_exists=False,
        probe_existing=False,
    )
    with _config_participants.operation(
        sys.modules[__name__], route="config_data_lock", target=lock_path
    ) as operation:
        try:
            create_private_text(lock_path, "")
        except FileExistsError:
            pass
        # Keep this inode stable across releases and across config-file choices.
        with closing(open_private_text_append_stream(lock_path)) as stream:
            while True:
                _config_participants.check_lock_wait(sys.modules[__name__], operation)
                try:
                    portalocker.lock(
                        stream,
                        portalocker.LockFlags.EXCLUSIVE
                        | portalocker.LockFlags.NON_BLOCKING,
                    )
                    break
                except portalocker.exceptions.AlreadyLocked:
                    time.sleep(0.05)
            try:
                _config_participants.check_lock_wait(sys.modules[__name__], operation)
                yield
            finally:
                portalocker.unlock(stream)


def _secure_default_data_dir() -> Path:
    """Recover a fresh root while the caller holds _default_data_root_lock."""
    selected = _selected_default_base_data_dir()
    try:
        with _config_participants.operation(
            sys.modules[__name__], route="config_default_root", target=selected
        ):
            return secure_private_directory(
                selected, create=True, application_owned=True
            ).lexical_path
    except PrivatePathError as exc:
        conventional = _default_base_data_dir()
        if (
            selected != conventional
            or exc.result.status is not PrivatePathStatus.UNSAFE_PARENT
            or exc.result.reason != "shared_writable_parent"
            or _data_root_entry_exists(conventional)
        ):
            raise
        # Only a missing conventional root can select a new location. Existing
        # data, explicit overrides and unrelated failures must never be hidden.
        # The unchanged guard also refuses a shared/foreign/symlinked HOME.
        fallback = conventional.parents[2] / _DEFAULT_DATA_FALLBACK_DIRECTORY
        with _config_participants.operation(
            sys.modules[__name__], route="config_default_root", target=fallback
        ):
            return secure_private_directory(
                fallback, create=True, application_owned=True
            ).lexical_path


def get_api_key(api_name: str) -> Optional[str]:
    """
    Get API key for a given provider.

    Args:
        api_name: The API provider name (e.g., 'openai', 'anthropic', 'groq')

    Returns:
        A usable API key, or None.

        TASK-32806.1: every branch below is screened by
        ``resolve_provider_api_key``, the same rule the rest of the codebase
        uses, so this can no longer hand a caller a value that rule rejects.
        It previously screened one literal (``<API_KEY_HERE>``) on one branch
        and returned everything raw, so a configured ``YOUR_KEY``, a
        whitespace-padded key, or a blank string reached five live spend and
        readiness paths -- and the realtime pre-connect gate, which tested
        truthiness, passed the placeholder straight to the provider session.
        Screening here also strips, so a padded key now WORKS rather than
        being sent with its spaces.
    """
    # Normalize the API name
    api_name_lower = api_name.lower()

    # First try the newer api_settings.{provider} structure
    try:
        settings = load_settings()
        api_settings_key = f"api_settings.{api_name_lower}"

        # `load_settings()` returns a NESTED dict -- `{"api_settings":
        # {"openai": {...}}}` -- so the flat dotted membership test this
        # used to do (`api_settings_key in settings`) was False for every
        # real config, making this whole branch dead code. Consequence,
        # found at the realtime engine's live gate: a key entered through
        # the Settings screen (which writes exactly here, the correct
        # modern location) was invisible to every caller of this function,
        # and the realtime pre-connect check refused with "no OpenAI API
        # key is configured" against a config that had one. Same root
        # cause as TASK-229's `get_cli_setting` fix, one accessor over.
        #
        # The flat lookup is kept as a fallback: it costs one dict miss,
        # and some settings shapes elsewhere may yet be flattened.
        api_settings = None
        nested_api_settings = settings.get("api_settings")
        if isinstance(nested_api_settings, dict):
            api_settings = nested_api_settings.get(api_name_lower)
        if not isinstance(api_settings, dict):
            api_settings = settings.get(api_settings_key)

        if isinstance(api_settings, dict):
            # TASK-32806.2: the STORED key outranks the environment variable
            # here, matching `_normalize_legacy_provider_api_key` and the
            # rule CLAUDE.md already records ("except provider API keys,
            # where an explicit api_settings.<provider>.api_key now outranks
            # the matching environment variable"). This accessor resolved
            # env-first, so with both set the chat path spent the Settings
            # key while MCP tools and Console realtime spent the env key --
            # the same readiness-and-spend disagreement ADR-012 exists to
            # prevent, moved from two readers to two accessors.
            #
            # The env var is still read; it is simply the fallback, which is
            # what makes a key typed into Settings take effect without the
            # user having to find and unset a shell variable first.
            if (
                "api_key" in api_settings
                and api_settings["api_key"] != "<API_KEY_HERE>"
            ):
                resolved = resolve_provider_api_key(api_settings["api_key"])
                if resolved is not None:
                    return resolved

            if "api_key_env_var" in api_settings:
                env_var = api_settings["api_key_env_var"]
                resolved = resolve_provider_api_key(os.getenv(env_var))
                if resolved is not None:
                    return resolved
    except Exception as e:
        logger.debug(f"Error accessing api_settings for {api_name}: {e}")

    # Try the legacy approach used elsewhere in the codebase
    try:
        # This is the pattern used in other files like Summarization_General_Lib.py
        resolved = resolve_provider_api_key(
            get_cli_setting("API", f"{api_name_lower}_api_key", "")
        )
        if resolved is not None:
            return resolved
    except Exception as e:
        logger.debug(f"Error getting API key via get_cli_setting for {api_name}: {e}")

    # Try direct environment variable access with common patterns
    env_var_names = [f"{api_name_lower.upper()}_API_KEY", f"{api_name.upper()}_API_KEY"]

    for env_var in env_var_names:
        resolved = resolve_provider_api_key(os.getenv(env_var))
        if resolved is not None:
            return resolved

    # No API key found
    logger.debug(f"No API key found for provider: {api_name}")
    return None


def get_user_folder_name() -> str:
    """Get the current user folder name from configuration."""
    default_user = DEFAULT_CONFIG_FROM_TOML.get("general", {}).get(
        "users_name", "default_user"
    )
    user_name = get_cli_setting("general", "users_name", default_user)
    # Sanitize user name to make it safe for folder names
    # Replace spaces and special characters with underscores
    return profile_paths.user_folder_name(user_name)


#: PERF-07 (TASK-33266; ADR-126 amendment D2, 2026-09-29): the verified user
#: data directory, reused while its inputs and every stamped path component are
#: unchanged. ``(key, stamps, path)`` or None; guarded by the lock below.
_USER_DATA_DIR_MEMO: tuple | None = None
_USER_DATA_DIR_MEMO_LOCK = _threading.Lock()


def _user_data_dir_inputs() -> tuple[tuple, tuple[Path, ...]]:
    """The memo key and every path whose posture the resolution depends on.

    Returns:
        ``(key, stamped_paths)``. The key starts with the config cache object
        (compared by identity) and its generation, so any reload or write
        invalidates the memo; then the settings the resolution reads and the
        default data base, which follows HOME. The stamped paths are every
        component of each candidate user directory's chain plus the entries
        the default-root selection reads (conventional root, fallback root,
        root lock file).
    """
    from tldw_chatbook.Backup_Recovery.storage_admission import _chain

    user_folder = get_user_folder_name()
    configured_data_dir = get_cli_setting("paths", "data_dir", None)
    if configured_data_dir is None:
        configured_data_dir = get_cli_setting("Paths", "data_dir", None)
    if configured_data_dir:
        candidates = (lexical_path(configured_data_dir) / user_folder,)
        entries: tuple[Path, ...] = ()
        # Expanded, not as written: a relative value follows the working dir.
        base = str(candidates[0].parent)
    else:
        conventional = _default_base_data_dir()
        fallback = conventional.parents[2] / _DEFAULT_DATA_FALLBACK_DIRECTORY
        candidates = (conventional / user_folder, fallback / user_folder)
        entries = (
            conventional,
            fallback,
            conventional.parents[2] / profile_paths.DATA_ROOT_LOCK_NAME,
        )
        base = str(conventional)
    key = (_CONFIG_CACHE, _CONFIG_GENERATION, _CONFIG_CACHE_SOURCE, user_folder, base)
    paths = (*(p for c in candidates for p in _chain(c)), *entries)
    return key, tuple(dict.fromkeys(paths))


def _bind_user_data_dir_stamps():
    """Keep one finite optional Windows source capture; acquire no native state."""
    close_errors = ()
    batch = source_current = None
    if os.name == "nt":
        import inspect
        import stat
        from pathlib import WindowsPath
        from types import FunctionType, MethodType, ModuleType

        from tldw_chatbook.Backup_Recovery import storage_admission as storage
        from tldw_chatbook.Utils import platform_files, windows_files

        facade, owner = platform_files.os, windows_files.WindowsOS
        native = windows_files._Native
        close_error = windows_files._AdmissionMetadataCloseError
        close_errors = (close_error,)
        original_posture = storage._posture
        projection = (stat.S_IFMT, stat.S_IMODE)
        modules = tuple(
            (module, vars(module), module.__file__, module.__spec__, module.__spec__.origin)
            for module in (storage, platform_files, windows_files)
        )
        bindings = (
            (vars(storage), "_posture", original_posture),
            (vars(storage), "os", facade),
            (vars(storage), "stat", stat),
            (vars(platform_files), "os", facade),
            (vars(platform_files), "WindowsOS", owner),
            (vars(windows_files), "WindowsOS", owner),
            (vars(windows_files), "_Native", native),
            (vars(windows_files), "_AdmissionMetadataCloseError", close_error),
            *((vars(stat), name, value) for name, value in zip(("S_IFMT", "S_IMODE"), projection)),
            *((vars(windows_files), name, vars(windows_files)[name]) for name in (
                "_os", "_stat", "Path", "ntpath", "contextlib", "functools",
                "_parent", "_component", "_native", "_acl_mode", "_AdmissionMetadataHandle",
            )),
            *((vars(owner), name, vars(owner)[name]) for name in (
                "__getattr__", "stat", "_stat_handle", "stat_many_for_admission",
            )),
            *((vars(native), name, vars(native)[name]) for name in (
                "__init__", "_user_sid", "reopen", "open_handle", "info", "ntfs",
                "security", "_decoded_security", "_decode_security", "sid_string", "check", "ntcheck",
            )),
            (vars(close_error), "__init__", close_error.__init__),
            (vars(windows_files._AdmissionMetadataHandle), "__init__", windows_files._AdmissionMetadataHandle.__init__),
        )
        wrappers = (
            windows_files._parent, windows_files._native,
            native.reopen, native._decoded_security,
        )
        functions = (
            original_posture, owner.__getattr__, owner.stat, owner._stat_handle,
            owner.stat_many_for_admission, windows_files._component, windows_files._acl_mode,
            native.__init__, native._user_sid, native.open_handle, native.info, native.ntfs,
            native.security, native._decode_security, native.sid_string, native.check, native.ntcheck,
            close_error.__init__, windows_files._AdmissionMetadataHandle.__init__,
            windows_files._parent, windows_files._parent.__wrapped__,
            windows_files._native.__wrapped__, native.reopen, native.reopen.__wrapped__,
            native._decoded_security.__wrapped__,
        )
        records = tuple(
            (function, function.__code__, function.__globals__, function.__defaults__,
             function.__kwdefaults__, tuple((function.__kwdefaults__ or {}).items()),
             function.__closure__, tuple((cell, cell.cell_contents) for cell in function.__closure__ or ()),
             vars(function).get("__wrapped__"))
            for function in functions
        )
        wrapped = tuple((wrapper, vars(wrapper).get("__wrapped__")) for wrapper in wrappers)
        lookup = tuple((cls, name, inspect.getattr_static(cls, name, None))
                       for cls in (owner, native) for name in ("__getattribute__", "__getattr__", "__dict__"))
        cached = tuple((name, vars(facade).get(name), vars(owner)[name])
                       for name in ("stat", "_stat_handle", "stat_many_for_admission"))
        batch = cached[-1][1]

        def source_current(posture):
            # Direct custom slots decline before any facade lookup or producer.
            if posture is not original_posture or storage.os is not facade or storage.stat is not stat:
                return False
            if any(namespace.get(name) is not value for namespace, name, value in bindings):
                return False
            if (
                type(facade) is not owner or type(owner) is not type or type(native) is not type
                or owner.__bases__ != (object,) or native.__bases__ != (object,)
                or inspect.getattr_static(owner, "__getattribute__") is not object.__getattribute__
                or inspect.getattr_static(native, "__getattribute__") is not object.__getattribute__
                or any(inspect.getattr_static(cls, name, None) is not value for cls, name, value in lookup)
            ):
                return False
            for module, namespace, path, spec, origin in modules:
                if (type(module) is not ModuleType or sys.modules.get(namespace["__name__"]) is not module
                    or vars(module) is not namespace or namespace.get("__file__") != path
                    or namespace.get("__spec__") is not spec or spec.origin != origin):
                    return False
            fields = vars(facade)
            if any(type(bound) is not MethodType or fields.get(name) is not bound
                   or bound.__self__ is not facade or bound.__func__ is not function
                   for name, bound, function in cached):
                return False
            for function, code, namespace, defaults, keywords, items, closure, cells, body in records:
                if (type(function) is not FunctionType or function.__code__ is not code
                    or function.__globals__ is not namespace or function.__defaults__ is not defaults
                    or function.__kwdefaults__ is not keywords
                    or len(function.__kwdefaults__ or {}) != len(items)
                    or any((function.__kwdefaults__ or {}).get(key) is not value for key, value in items)
                    or function.__closure__ is not closure
                    or vars(function).get("__wrapped__") is not body):
                    return False
                try:
                    if any(cell.cell_contents is not value for cell, value in cells):
                        return False
                except ValueError:  # An emptied captured cell is nonstock too.
                    return False
            return all(vars(wrapper).get("__wrapped__") is body for wrapper, body in wrapped)

    def _user_data_dir_stamps(paths: tuple[Path, ...]) -> tuple | None:
        """Observe ordered five-field postures; preserve retained-close custody.

        The stock Windows route performs one fresh metadata batch. Customized
        sources retain the original scalar calls, and ordinary OSError leaves
        resolution to report the original private-path error.
        """
        from tldw_chatbook.Backup_Recovery.storage_admission import _posture

        try:
            if type(paths) is tuple and not paths:
                return ()
            if (source_current is not None and source_current(_posture)
                and type(paths) is tuple and all(type(path) is WindowsPath and path.is_absolute()
                    and len(path.drive) == 2 and path.drive[1] == ":" and path.drive[0].isalpha()
                    for path in paths) and source_current(_posture)):
                try:
                    observed = batch(paths)
                except close_errors:
                    raise
                except OSError as error:
                    # The call has unwound its native finally before selection.
                    current = source_current(_posture)
                    if not current or type(error) is not PermissionError or error.errno != 13 or error.strerror != "windows_admission_descriptor_unavailable":
                        return None
                else:
                    # Any observed drift discards the whole sample permanently.
                    current = source_current(_posture)
                    if not current or type(observed) is not dict:
                        return None
                    result = []
                    for path in paths:
                        value = observed[path]
                        if value is None:
                            result.append(None)
                        else:
                            info = value[0]
                            result.append((info.st_dev, info.st_ino, projection[0](info.st_mode),
                                           projection[1](info.st_mode), info.st_uid))
                    return tuple(result) if source_current(_posture) else None
            return tuple(_posture(path) for path in paths)
        except close_errors:
            raise
        except OSError:
            return None

    return _user_data_dir_stamps


_user_data_dir_stamps = _bind_user_data_dir_stamps()
del _bind_user_data_dir_stamps


@_config_participants.guarded
def get_user_data_dir() -> Path:
    """Return the secured lexical user-specific data directory.

    PERF-07: after the guarded handshake, a resolution is reused while the
    config generation, the settings it reads and the posture (identity, type,
    mode, owner) of every component from ``/`` to each candidate directory
    are unchanged, re-observed on every call. Anything else runs the
    unmodified resolution, the only place that creates, hardens or refuses.
    A result is kept only when stamps taken before and after that resolution
    are identical, so it describes exactly the state that was verified.

    Returns:
        The lexical (unresolved) user data directory, created if absent and
        hardened to owner-only permissions.

    Raises:
        PrivatePathError: A component of the path is unsafe (for example a
            group-writable ancestor); the resolution refuses it.
    """
    global _USER_DATA_DIR_MEMO
    verified = _config_participants.verified_user_data_directory(sys.modules[__name__])
    if verified is not None:
        return verified
    key, stamped = _user_data_dir_inputs()
    with _USER_DATA_DIR_MEMO_LOCK:
        memo = _USER_DATA_DIR_MEMO
    if (
        memo is not None
        and memo[0][0] is key[0]
        and memo[0][1:] == key[1:]
        and memo[1] == _user_data_dir_stamps(stamped)
    ):
        return memo[2]
    before = _user_data_dir_stamps(stamped)
    result = _resolve_user_data_dir()
    after = _user_data_dir_stamps(stamped)
    import stat

    from tldw_chatbook.Backup_Recovery.storage_admission import _chain

    walked = set(_chain(result))
    # The result must be one of the stamped candidates: a working directory
    # changed mid-resolution makes a relative data dir resolve elsewhere.
    if before is not None and before == after and walked <= set(stamped) and all(
        stamp is not None and not stat.S_ISLNK(stamp[2])
        for path, stamp in zip(stamped, after)
        if path in walked
    ):
        with _USER_DATA_DIR_MEMO_LOCK:
            _USER_DATA_DIR_MEMO = (key, after, result)
    return result


def _resolve_user_data_dir() -> Path:
    """The unmodified resolution: select, create, harden or refuse."""
    user_folder = get_user_folder_name()
    configured_data_dir = get_cli_setting("paths", "data_dir", None)
    if configured_data_dir is None:
        configured_data_dir = get_cli_setting("Paths", "data_dir", None)
    with ExitStack() as stack:
        if configured_data_dir:
            base_data_dir = lexical_path(configured_data_dir)
        else:
            stack.enter_context(_default_data_root_lock())
            base_data_dir = _secure_default_data_dir()
        user_dir = base_data_dir / user_folder
        with _config_participants.operation(
            sys.modules[__name__], route="config_data", target=user_dir
        ):
            if configured_data_dir:
                verify_trusted_directory(base_data_dir, allow_shared_sticky=False)
            return secure_private_directory(
                user_dir,
                create=True,
                application_owned=True,
            ).lexical_path


def _get_custom_database_path(
    setting_name: str,
    *,
    expand_before_validation: bool = True,
) -> Path | None:
    """Return a validated lexical custom DB path, if explicitly configured.

    This is a non-mutating selection boundary: it intentionally does not
    probe, create, resolve, or chmod the user-selected parent. The consuming
    private SQLite owner must verify that the parent already satisfies the
    trusted-namespace contract before opening the database. Keeping the
    lexical spelling here preserves symlink evidence for that no-follow check.
    """
    custom_path = get_cli_setting("database", setting_name, None)
    default_path = DEFAULT_CONFIG_FROM_TOML.get("database", {}).get(setting_name)
    selected_input = profile_paths.custom_database_input(
        custom_path, default_path, expand_before_validation=expand_before_validation
    )
    if selected_input is None:
        return None
    validated = validate_path_simple(
        selected_input,
        require_exists=False,
        # Preserve lexical evidence and defer filesystem authority to the
        # private SQLite owner; see ADR-029.
        probe_existing=False,
    )
    return lexical_path(validated)


def get_chachanotes_db_path(*, ignore_override: bool = False) -> Path:
    """Get the resolved path for the ChaChaNotes database.

    Args:
        ignore_override: When True, skip any explicitly-configured custom
            path and always return the profile-aware default. Used by the
            Settings "Reset" action, which must discard a user's
            customization rather than reflect it back (TASK-927 follow-up).

    Returns:
        The resolved database path -- either a configured custom path
        (unless ``ignore_override``) or the default filename under the
        current profile's user data directory.
    """
    if ignore_override:
        return get_user_data_dir() / profile_paths.database_leaf("chachanotes_db_path")
    return _get_custom_database_path(
        "chachanotes_db_path"
    ) or get_user_data_dir() / profile_paths.database_leaf("chachanotes_db_path")


def get_tts_profiles_db_path() -> Path:
    """Return the validated local TTS generation-profile database path."""

    custom_path = get_cli_setting("database", "tts_profiles_db_path", None)
    if custom_path:
        candidate = Path(str(custom_path))
        if ".." in candidate.parts:
            raise ValueError(
                "TTS profiles database path cannot contain parent traversal"
            )
        candidate = candidate.expanduser()
        return validate_path_simple(candidate, require_exists=False).resolve()
    return get_user_data_dir() / profile_paths.database_leaf("tts_profiles_db_path")


def get_notes_sync_state_db_path() -> Path:
    """Return the device-private Notes import/sync state database path.

    Returns:
        The profile-local path for Notes import receipts and sync state.
    """

    return get_user_data_dir() / "tldw_chatbook_notes_sync_state.db"


NOTES_SYNC_RECOVERY_CAPACITY_BYTES_DEFAULT = 256 * 1024 * 1024
_NOTES_SYNC_RECOVERY_CAPACITY_ENV = "TLDW_NOTES_SYNC_RECOVERY_CAPACITY_BYTES"


def get_notes_sync_recovery_capacity_bytes(
    config_data: Mapping[str, Any] | None = None,
) -> int:
    """Return the one bounded device-private sync recovery capacity."""

    selected = (
        load_cli_config_and_ensure_existence() if config_data is None else config_data
    )
    env_value = os.getenv(_NOTES_SYNC_RECOVERY_CAPACITY_ENV)
    notes = selected.get("notes")
    capacity: object
    if env_value is not None:
        try:
            capacity = int(env_value)
        except ValueError:
            raise ValueError(
                "notes.recovery_capacity_bytes must be a positive integer."
            ) from None
    elif isinstance(notes, Mapping):
        capacity = notes.get(
            "recovery_capacity_bytes",
            NOTES_SYNC_RECOVERY_CAPACITY_BYTES_DEFAULT,
        )
    else:
        capacity = NOTES_SYNC_RECOVERY_CAPACITY_BYTES_DEFAULT
    if type(capacity) is not int or not 1 <= capacity <= 2**63 - 1:
        raise ValueError("notes.recovery_capacity_bytes must be a positive integer.")
    return capacity


NOTES_SYNC_WATCHER_INTERVAL_SECONDS_DEFAULT = 1.0
NOTES_SYNC_WATCHER_MAX_INTERVAL_SECONDS_DEFAULT = 30.0
_NOTES_SYNC_WATCHER_INTERVAL_CEILING_SECONDS = 3600.0


def get_notes_sync_watcher_intervals(
    config_data: Mapping[str, Any] | None = None,
) -> tuple[float, float]:
    """Return the notes-sync watcher's (base, max) polling intervals.

    TASK-21112: the lasting-sync watcher polls at the base interval and backs
    off toward the max while roots are quiet. Read from
    ``[notes] sync_watcher_interval_seconds`` (default 1.0) and
    ``[notes] sync_watcher_max_interval_seconds`` (default 30.0; backed-off
    sleeps are jittered by up to +/-50 percent around it).

    Args:
        config_data: Optional pre-loaded settings mapping; loads the CLI
            config when omitted.

    Returns:
        A ``(interval_seconds, max_interval_seconds)`` pair.

    Raises:
        ValueError: If either configured value is not a positive number in
            range, or the max is below the base interval.
    """

    selected = (
        load_cli_config_and_ensure_existence() if config_data is None else config_data
    )
    notes = selected.get("notes") if isinstance(selected, Mapping) else None
    base: object = NOTES_SYNC_WATCHER_INTERVAL_SECONDS_DEFAULT
    peak: object = NOTES_SYNC_WATCHER_MAX_INTERVAL_SECONDS_DEFAULT
    if isinstance(notes, Mapping):
        base = notes.get("sync_watcher_interval_seconds", base)
        peak = notes.get("sync_watcher_max_interval_seconds", peak)
    for label, value in (
        ("notes.sync_watcher_interval_seconds", base),
        ("notes.sync_watcher_max_interval_seconds", peak),
    ):
        if (
            type(value) not in (int, float)
            or not 0.05 <= value <= _NOTES_SYNC_WATCHER_INTERVAL_CEILING_SECONDS
        ):
            raise ValueError(f"{label} must be a number between 0.05 and 3600 seconds.")
    if peak < base:
        raise ValueError(
            "notes.sync_watcher_max_interval_seconds must be at least "
            "notes.sync_watcher_interval_seconds."
        )
    return float(base), float(peak)


def load_console_library_migration_seed(
    app_config: Mapping[str, Any] | None = None,
) -> "ConsoleLibraryMigrationSeed":
    """Return the sanitized pre-upgrade automatic-retrieval migration seed.

    Args:
        app_config: Optional already-loaded application configuration.

    Returns:
        The strict typed seed required by a legacy database migration.
    """
    from tldw_chatbook.Chat.console_library_policy import ConsoleLibraryMigrationSeed

    selected = (
        load_cli_config_and_ensure_existence() if app_config is None else app_config
    )
    chat_defaults = (
        selected.get("chat_defaults") if isinstance(selected, Mapping) else None
    )
    raw_value = (
        chat_defaults.get("rag_auto_retrieve_on_send", False)
        if isinstance(chat_defaults, Mapping)
        else False
    )
    return ConsoleLibraryMigrationSeed(
        auto_retrieve_on_send=raw_value if type(raw_value) is bool else False
    )


def get_prompts_db_path(*, ignore_override: bool = False) -> Path:
    """Get the resolved path for the Prompts database.

    Args:
        ignore_override: When True, skip any explicitly-configured custom
            path and always return the profile-aware default. Used by the
            Settings "Reset" action, which must discard a user's
            customization rather than reflect it back (TASK-927 follow-up).

    Returns:
        The resolved database path -- either a configured custom path
        (unless ``ignore_override``) or the default filename under the
        current profile's user data directory.
    """
    if ignore_override:
        return get_user_data_dir() / profile_paths.database_leaf("prompts_db_path")
    return _get_custom_database_path(
        "prompts_db_path"
    ) or get_user_data_dir() / profile_paths.database_leaf("prompts_db_path")


def get_media_db_path(*, ignore_override: bool = False) -> Path:
    """Get the resolved path for the Media database.

    Args:
        ignore_override: When True, skip any explicitly-configured custom
            path and always return the profile-aware default. Used by the
            Settings "Reset" action, which must discard a user's
            customization rather than reflect it back (TASK-927 follow-up).

    Returns:
        The resolved database path -- either a configured custom path
        (unless ``ignore_override``) or the default filename under the
        current profile's user data directory.
    """
    if ignore_override:
        return get_user_data_dir() / profile_paths.database_leaf("media_db_path")
    return _get_custom_database_path(
        "media_db_path"
    ) or get_user_data_dir() / profile_paths.database_leaf("media_db_path")


def get_library_collections_db_path() -> Path:
    return _get_custom_database_path(
        "library_collections_db_path"
    ) or get_user_data_dir() / profile_paths.database_leaf(
        "library_collections_db_path"
    )


def get_dreams_db_path() -> Path:
    """Return the canonical path for the Dreams database (dreams phase 1)."""
    return (
        _get_custom_database_path("dreams_db_path")
        or get_user_data_dir() / "dreams.sqlite"
    )


def get_library_ingest_jobs_db_path() -> Path:
    return _get_custom_database_path(
        "library_ingest_jobs_db_path"
    ) or get_user_data_dir() / profile_paths.database_leaf(
        "library_ingest_jobs_db_path"
    )


def get_workspaces_db_path() -> Path:
    return _get_custom_database_path(
        "workspaces_db_path"
    ) or get_user_data_dir() / profile_paths.database_leaf("workspaces_db_path")


def get_subscriptions_db_path() -> Path:
    return _get_custom_database_path(
        "subscriptions_db_path"
    ) or get_user_data_dir() / profile_paths.database_leaf("subscriptions_db_path")


def get_evals_db_path() -> Path:
    """Return the canonical path for the Evals database."""
    return _get_custom_database_path(
        "evals_db_path"
    ) or get_user_data_dir() / profile_paths.database_leaf("evals_db_path")


def get_rag_indexing_db_path() -> Path:
    """Return the canonical path for the RAG indexing-state database."""
    return _get_custom_database_path(
        "rag_indexing_db_path"
    ) or get_user_data_dir() / profile_paths.database_leaf("rag_indexing_db_path")


def get_notifications_db_path() -> Path:
    return _get_custom_database_path(
        "notifications_db_path"
    ) or get_user_data_dir() / profile_paths.database_leaf("notifications_db_path")


def get_research_db_path() -> Path:
    return _get_custom_database_path(
        "research_db_path"
    ) or get_user_data_dir() / profile_paths.database_leaf("research_db_path")


def get_workflows_db_path() -> Path:
    """Return the local authoring store; called only on Workflows entry."""
    return (
        _get_custom_database_path("workflows_db_path")
        or get_user_data_dir() / "tldw_chatbook_workflows.db"
    )


def get_writing_db_path() -> Path:
    return _get_custom_database_path(
        "writing_db_path"
    ) or get_user_data_dir() / profile_paths.database_leaf("writing_db_path")


def get_scheduled_tasks_db_path() -> Path:
    return _get_custom_database_path(
        "scheduled_tasks_db_path",
        expand_before_validation=False,
    ) or get_user_data_dir() / profile_paths.database_leaf("scheduled_tasks_db_path")


def get_cli_log_file_path() -> Path:
    """Return the configured log file beneath the secured user data directory."""

    user_dir = get_user_data_dir()
    default_log_filename = DEFAULT_CONFIG_FROM_TOML.get("logging", {}).get(
        "log_filename", "tldw_cli_app.log"
    )
    log_filename = get_cli_setting("logging", "log_filename", default_log_filename)
    if (
        not isinstance(log_filename, str)
        or not log_filename.strip()
        or log_filename in {".", ".."}
        or "/" in log_filename
        or "\\" in log_filename
        or Path(log_filename).is_absolute()
        or Path(log_filename).name != log_filename
    ):
        raise ValueError("Configured log filename must be a non-empty basename")
    return user_dir / log_filename


def get_cli_data_dir() -> Path:
    """Get the CLI data directory for storing application data."""
    # Return user-specific directory
    return get_user_data_dir()


@_config_participants.guarded
def get_model_cache_dir() -> Path:
    """Get the user-specific model cache directory for embeddings."""
    # Check if a custom cache dir is configured
    default_cache_dir = DEFAULT_CONFIG_FROM_TOML.get("embedding_config", {}).get(
        "model_cache_dir", None
    )
    custom_cache_dir = get_cli_setting(
        "embedding_config", "model_cache_dir", default_cache_dir
    )

    cache_path: Path | None = None
    if custom_cache_dir and custom_cache_dir != default_cache_dir:
        # Use custom path if explicitly configured. task-32901: the
        # configured value is config input, so it goes through central
        # validation before any filesystem creation (probe off: the
        # no-follow boundary below owns link handling). An unusable value
        # refuses loudly: silently relocating the cache would diverge from
        # the config-participant binding for this route.
        cache_path = validate_path_simple(
            Path(custom_cache_dir).expanduser(),
            require_exists=False,
            probe_existing=False,
        )
        if not cache_path.is_absolute():
            raise ValueError(
                f"Configured model cache directory {custom_cache_dir!r} is not"
                " a usable path: it must be absolute"
            )
    if cache_path is None:
        # Use user-specific folder
        user_dir = get_user_data_dir()
        cache_path = user_dir / "models" / "embeddings"

    # Create directory if it doesn't exist. task-32901: umask-derived modes
    # land 0775 on umask-002 machines. The default data-root path uses the
    # private lifecycle (creates 0700, hardens an existing 0775 instance);
    # an explicitly configured custom directory stays under the user's
    # ownership policy, so only the creation mode is pinned there.
    try:
        with _config_participants.operation(
            sys.modules[__name__], route="config_models", target=cache_path
        ):
            if custom_cache_dir and custom_cache_dir != default_cache_dir:
                cache_path.mkdir(parents=True, exist_ok=True, mode=0o700)
            else:
                secure_private_directory(
                    cache_path, create=True, application_owned=True
                )
    except PrivatePathError as e:
        repair = private_path_repair_hint(e)
        suffix = f" Repair once with: {repair}" if repair else ""
        logger.error(
            f"Could not create model cache directory {cache_path}: {e}.{suffix}"
        )
    except OSError as e:
        logger.opt(exception=True).error(
            f"Could not create model cache directory {cache_path}: {e}"
        )

    return cache_path


# --- Global CLI Database Instances ---
chachanotes_db: Optional[CharactersRAGDB] = None
prompts_db: Optional[PromptsDatabase] = None
media_db: Optional[MediaDatabase] = None


def seed_builtin_content(db: CharactersRAGDB) -> CharactersRAGDB:
    """Seed restart-safe bundled profile content after database initialization.

    Args:
        db: Initialized profile-local character database.

    Returns:
        The same database instance after best-effort built-in seeding.
    """
    try:
        from tldw_chatbook.Character_Chat.visual_identity import ensure_builtin_samira

        ensure_builtin_samira(db)
    except Exception as exc:  # noqa: BLE001 - bundled content cannot prevent boot
        logger.warning("builtin_profile_seed_failed category={}", type(exc).__name__)
    try:
        from tldw_chatbook.Character_Chat.builtin_pixel_migu import (
            ensure_builtin_pixel_migu,
        )

        ensure_builtin_pixel_migu(db)
    except Exception as exc:  # noqa: BLE001 - bundled content cannot prevent boot
        logger.warning("pixel_migu_profile_seed_failed category={}", type(exc).__name__)
    return db


# --- Database Initialization Function (remains largely the same) ---
def initialize_all_databases():
    global chachanotes_db, prompts_db, media_db
    logger.debug("CRITICAL DEBUG: INSIDE initialize_all_databases() NOW.")
    logger.info("Initializing CLI databases...")
    # ChaChaNotes DB
    chachanotes_path = get_chachanotes_db_path()
    logger.info(f"Attempting to initialize ChaChaNotes_DB at: {chachanotes_path}")
    try:
        chachanotes_db = CharactersRAGDB(
            db_path=chachanotes_path,
            client_id=CLI_APP_CLIENT_ID,
            console_library_migration_seed=load_console_library_migration_seed(),
        )
        seed_builtin_content(chachanotes_db)
        logger.success(f"ChaChaNotes_DB initialized successfully at {chachanotes_path}")
    except Exception as e:
        logger.opt(exception=True).error(
            f"Failed to initialize ChaChaNotes_DB at {chachanotes_path}: {e}"
        )
        chachanotes_db = None
    # Prompts DB
    prompts_path = get_prompts_db_path()
    logger.info(f"Attempting to initialize Prompts_DB at: {prompts_path}")
    try:
        prompts_db = PromptsDatabase(db_path=prompts_path, client_id=CLI_APP_CLIENT_ID)
        logger.success(f"Prompts_DB initialized successfully at {prompts_path}")
    except Exception as e:
        logger.opt(exception=True).error(
            f"Failed to initialize Prompts_DB at {prompts_path}: {e}"
        )
        prompts_db = None
    # Media DB
    media_path = get_media_db_path()
    logger.info(f"Attempting to initialize Media_DB_v2 at: {media_path}")
    try:
        media_db = MediaDatabase(db_path=media_path, client_id=CLI_APP_CLIENT_ID)
        logger.success(f"Media_DB_v2 initialized successfully at {media_path}")
    except Exception as e:
        logger.opt(exception=True).error(
            f"Failed to initialize Media_DB_v2 at {media_path}: {e}"
        )
        media_db = None
    logger.info("CLI database initialization complete.")


# --- Lazy Database Getters ---
def get_chachanotes_db_lazy() -> Optional[CharactersRAGDB]:
    """Get the ChaChaNotes database instance, initializing it lazily if needed."""
    global chachanotes_db
    if chachanotes_db is None:
        chachanotes_path = get_chachanotes_db_path()
        logger.info(f"Lazy-initializing ChaChaNotes_DB at: {chachanotes_path}")
        try:
            # Get integrity check configuration
            config = load_settings()
            check_integrity = config.get("database", {}).get(
                "check_integrity_on_startup", False
            )

            chachanotes_db = CharactersRAGDB(
                db_path=chachanotes_path,
                client_id=CLI_APP_CLIENT_ID,
                check_integrity_on_startup=check_integrity,
                console_library_migration_seed=load_console_library_migration_seed(),
            )
            seed_builtin_content(chachanotes_db)
            logger.success(
                f"ChaChaNotes_DB lazy-initialized successfully at {chachanotes_path}"
            )
        except Exception as e:
            logger.opt(exception=True).error(
                f"Failed to lazy-initialize ChaChaNotes_DB at {chachanotes_path}: {e}"
            )
            if chachanotes_db is not None:
                # Seeding can fail after construction has acquired this worker's
                # connection. Retire it before discarding the lazy owner.
                chachanotes_db.close_connection()
            chachanotes_db = None
    return chachanotes_db


def get_prompts_db_lazy() -> Optional[PromptsDatabase]:
    """Get the Prompts database instance, initializing it lazily if needed."""
    global prompts_db
    if prompts_db is None:
        prompts_path = get_prompts_db_path()
        logger.info(f"Lazy-initializing Prompts_DB at: {prompts_path}")
        try:
            # Get integrity check configuration
            config = load_settings()
            check_integrity = config.get("database", {}).get(
                "check_integrity_on_startup", False
            )

            prompts_db = PromptsDatabase(
                db_path=prompts_path,
                client_id=CLI_APP_CLIENT_ID,
                check_integrity_on_startup=check_integrity,
            )
            logger.success(
                f"Prompts_DB lazy-initialized successfully at {prompts_path}"
            )
        except Exception as e:
            logger.opt(exception=True).error(
                f"Failed to lazy-initialize Prompts_DB at {prompts_path}: {e}"
            )
            prompts_db = None
    return prompts_db


def get_media_db_lazy() -> Optional[MediaDatabase]:
    """Get the Media database instance, initializing it lazily if needed."""
    global media_db
    if media_db is None:
        media_path = get_media_db_path()
        logger.info(f"Lazy-initializing Media_DB_v2 at: {media_path}")
        try:
            media_db = MediaDatabase(db_path=media_path, client_id=CLI_APP_CLIENT_ID)
            logger.success(f"Media_DB_v2 lazy-initialized successfully at {media_path}")
        except Exception as e:
            logger.opt(exception=True).error(
                f"Failed to lazy-initialize Media_DB_v2 at {media_path}: {e}"
            )
            media_db = None
    return media_db


# --- API Models (should be defined based on CONFIG_TOML_CONTENT or loaded from it) ---
# These can be loaded dynamically from the config or kept as fallback statics
# For simplicity, if CONFIG_TOML_CONTENT has [providers], use that.
# Reuse the [providers] table already parsed into DEFAULT_CONFIG_FROM_TOML
# above instead of re-parsing the entire embedded TOML string a second time.
# Deep-copied (not aliased) so the per-provider model lists stay independent
# of DEFAULT_CONFIG_FROM_TOML's own tree.
API_MODELS_BY_PROVIDER: Dict[str, List[str]] = {}
LOCAL_PROVIDERS: Dict[str, List[str]] = {}

_config_providers = copy.deepcopy(DEFAULT_CONFIG_FROM_TOML.get("providers", {}))
# ADR-179: cloud classification is derived from the provider registry
# (single source of truth) instead of a hand-typed list here, so a newly
# registered cloud provider is classified without touching this module.
_cloud_provider_keys = CLOUD_PROVIDER_CONFIG_KEYS

for provider_name, models_list in _config_providers.items():
    if isinstance(models_list, list):
        if (
            provider_name in _cloud_provider_keys
        ):  # Crude way to separate, adjust as needed
            API_MODELS_BY_PROVIDER[provider_name] = models_list
        else:
            LOCAL_PROVIDERS[provider_name] = models_list
    else:
        logger.warning(
            f"Models for provider '{provider_name}' in CONFIG_TOML_CONTENT is not a list. Skipping."
        )

if (
    not API_MODELS_BY_PROVIDER and not LOCAL_PROVIDERS
):  # Fallback if [providers] was empty or malformed
    logger.warning(
        "No providers found in CONFIG_TOML_CONTENT's [providers] section. Using hardcoded fallbacks for API_MODELS_BY_PROVIDER and LOCAL_PROVIDERS."
    )
    API_MODELS_BY_PROVIDER = {"OpenAI": ["gpt-5.6-terra"]}  # Minimal fallback
    LOCAL_PROVIDERS = {"Ollama": ["llama3"]}  # Minimal fallback


# --- Global default_api_endpoint (example of using the new settings) ---

# --- Global Settings Object ---
# task-32900: a private-path refusal here (e.g. a group-writable ~/.config on
# a fresh install) used to surface as a bare `unsafe_parent:
# shared_writable_parent` traceback. Emit the plain-language diagnostic once,
# then keep failing closed exactly as before (ADR-029/ADR-127 posture).
try:
    load_cli_config_and_ensure_existence()
except PrivatePathError as _private_path_startup_error:
    from tldw_chatbook.Utils.startup_errors import (
        emit_private_path_startup_error,
    )

    emit_private_path_startup_error(_private_path_startup_error)
    raise
settings = load_settings()
if _CONFIG_GENERATION == 0:
    _CONFIG_GENERATION = 1

try:
    # Accessing deeply nested key safely
    default_api_endpoint = settings.get("llm_api_settings", {}).get(
        "default_api", "openai"
    )
    logger.info(
        f"Default API Endpoint (from config.py global scope): {default_api_endpoint}"
    )
except Exception as e:
    logger.opt(exception=True).error(
        f"Critical error setting default_api_endpoint in config.py global scope: {str(e)}"
    )
    default_api_endpoint = "openai"  # Fallback

# --- Optional: Export individual variables if needed (generally prefer using settings dict) ---
# SINGLE_USER_MODE = settings["SINGLE_USER_MODE"]
# OPENAI_API_KEY = settings["OPENAI_API_KEY"]

# Make APP_CONFIG, DATABASE_CONFIG, RAG_SEARCH_CONFIG available globally if needed
# These are now loaded from TOML into the `settings` dictionary.
APP_CONFIG = settings.get(
    "APP_TTS_CONFIG", DEFAULT_APP_TTS_CONFIG
)  # Fallback if not in settings for some reason
DATABASE_CONFIG = settings.get("APP_DATABASE_CONFIG", DEFAULT_DATABASE_CONFIG)
RAG_SEARCH_CONFIG = settings.get("APP_RAG_SEARCH_CONFIG", DEFAULT_RAG_SEARCH_CONFIG)

# --- Load CLI Config and Initialize Databases on module import ---
# The `settings` global variable is now the result of the unified load_settings()
logger.debug(
    "CRITICAL DEBUG: Database initialization is now lazy - will initialize on first access"
)

# Databases will be initialized lazily on first access
# This significantly improves startup time by deferring expensive DB operations

# Make APP_CONFIG available globally if needed by other modules that import from config.py
# This will be the same as `settings` if `load_settings` is the sole config loader.
APP_CONFIG_GLOBAL = settings

#
# End of tldw_cli/config.py
#######################################################################################################################


def create_mcp_credential_service(data_root: Path | None = None):
    """Build the MCP-only keyring owner for the active data root.

    No arbitrary HTTP header values enter TOML or provider-account namespaces.
    Unsupported/insecure keyring backends fail closed on first credential use.
    """
    from tldw_chatbook.MCP.credential_bindings import (
        CredentialBindingService,
        KeyringCredentialBackend,
    )

    return CredentialBindingService(
        KeyringCredentialBackend(data_root or get_user_data_dir())
    )


# Definition-time originals for the finite stock run-log availability read.
_RUN_LOG_PROBE_SOURCE = (
    globals(),
    __file__,
    __spec__,
    getattr(__spec__, "origin", None),
    (
        *(
            (globals(), name, globals()[name])
            for name in (
                "get_workspaces_db_path",
                "_get_custom_database_path",
                "get_user_data_dir",
                "get_cli_setting",
            )
        ),
    ),
    tuple(
        (
            function,
            function.__code__,
            function.__globals__,
            function.__defaults__,
            function.__kwdefaults__,
            tuple((function.__kwdefaults__ or {}).items()),
            function.__closure__,
            tuple((cell, cell.cell_contents) for cell in function.__closure__ or ()),
            vars(function).get("__wrapped__"),
        )
        for _owner, _name, descriptor in (
            *(
                (globals(), name, globals()[name])
                for name in (
                    "get_workspaces_db_path",
                        "_get_custom_database_path",
                    "get_user_data_dir",
                    "get_cli_setting",
                )
            ),
        )
        if callable(descriptor) or isinstance(descriptor, (staticmethod, classmethod))
        for outer in (
            descriptor.__func__
            if isinstance(descriptor, (staticmethod, classmethod))
            else descriptor,
        )
        if hasattr(outer, "__code__")
        for function in (
            outer,
            *((outer.__wrapped__,) if hasattr(outer, "__wrapped__") else ()),
            *(
                (outer.__wrapped__.__wrapped__,)
                if hasattr(outer, "__wrapped__")
                and hasattr(outer.__wrapped__, "__wrapped__")
                else ()
            ),
        )
    ),
)


# Defining callbacks for checked stock Console preparation; no IO.
_COMPACT_MODEL_CONFIG_SOURCE = (
    globals(),
    __file__,
    __spec__,
    getattr(__spec__, "origin", None),
    tuple(
        (globals(), name, globals()[name])
        for name in (
            "get_cli_providers_and_models",
            "load_settings",
            "_load_settings_guarded",
            "_load_settings_uncached",
            "_settings_cache_hit",
            "_get_effective_config_path",
            "current_config_identity",
            "resolve_provider_name",
            "_normalize_provider_lookup_key",
            "normalize_provider_config_key",
            "_config_participants",
        )
    )
    + tuple(
        (vars(_config_participants), name, vars(_config_participants)[name])
        for name in ("operation",)
    )
    + ((sys.modules, _config_participants.__name__, _config_participants),),
    tuple(
        (
            namespace,
            name,
            function,
            function.__code__,
            function.__globals__,
            function.__defaults__,
            function.__kwdefaults__,
            tuple((function.__kwdefaults__ or {}).items()),
            function.__closure__,
            tuple((cell, cell.cell_contents) for cell in function.__closure__ or ()),
            vars(function).get("__wrapped__"),
        )
        for namespace, name, function in (
            *(
                (globals(), name, globals()[name])
                for name in (
                    "get_cli_providers_and_models",
                    "load_settings",
                    "_load_settings_guarded",
                    "_load_settings_uncached",
                    "_settings_cache_hit",
                    "_get_effective_config_path",
                    "current_config_identity",
                    "resolve_provider_name",
                    "_normalize_provider_lookup_key",
                    "normalize_provider_config_key",
                )
            ),
            *(
                (vars(function), "__wrapped__", function.__wrapped__)
                for function in (_load_settings_guarded, _load_settings_uncached)
            ),
            (vars(_config_participants), "operation", _config_participants.operation),
            (
                vars(_config_participants.operation),
                "__wrapped__",
                _config_participants.operation.__wrapped__,
            ),
        )
    ),
)


# Definition-time inputs for optional in-memory pending display.
_CONSOLE_PENDING_FACTS_IDENTITY_SOURCE = (
    current_config_identity,
    current_config_identity.__code__,
    current_config_identity.__globals__,
    current_config_identity.__defaults__,
    current_config_identity.__kwdefaults__,
    current_config_identity.__closure__,
)



# Original callbacks eligible for finite deferred Collections setup only.
def _record_collections_setup_source(entries):
    from types import FunctionType

    rows = []
    for owner, name in entries:
        original = owner[name] if type(owner) is dict else getattr(owner, name)  # exact stock compatibility boundary
        function = getattr(original, "__func__", original)
        records = []
        while type(function) is FunctionType:
            records.append(
                (
                    function,
                    function.__code__,
                    function.__globals__,
                    function.__defaults__,
                    function.__kwdefaults__,
                    tuple((function.__kwdefaults__ or {}).items()),
                    function.__closure__,
                    tuple(
                        (cell, cell.cell_contents)
                        for cell in function.__closure__ or ()
                    ),
                    vars(function).get("__wrapped__"),
                )
            )
            function = vars(function).get("__wrapped__")
        rows.append((owner, name, original, tuple(records)))
    return globals(), tuple(rows)


_COLLECTIONS_SETUP_SOURCE = _record_collections_setup_source(
    (
        (globals(), "current_config_identity"),
        (globals(), "get_library_collections_db_path"),
        (globals(), "get_user_data_dir"),
        (globals(), "_get_custom_database_path"),
        (globals(), "_get_effective_config_path"),
    )
)
del _record_collections_setup_source
