"""
Input validation utilities for secure user input handling.
"""

import ipaddress
import json
import math
import re
import time
import unicodedata
from collections.abc import Mapping
from functools import cache
from itertools import islice
from typing import Annotated, Any, Literal, NoReturn, Optional, TypeVar, Union
from urllib.parse import urlparse

import regex
from pydantic import (
    BaseModel,
    ConfigDict,
    Field,
    TypeAdapter,
    ValidationInfo,
    field_validator,
    model_validator,
)
from pydantic import (
    ValidationError as PydanticValidationError,
)

from ..Metrics.metrics_logger import log_counter, log_histogram
from .reasoning_config import REASONING_HISTORY_MODES

ConsoleHookEvent = Literal[
    "UserPromptSubmit",
    "PreToolUse",
    "PostToolUse",
    "ApprovalRequested",
    "Stop",
    "SubagentStop",
]
CONSOLE_HOOK_TOOL_EVENTS = frozenset({"PreToolUse", "PostToolUse"})
CONSOLE_HOOK_DEFAULT_TIMEOUT_S = 10.0
CONSOLE_HOOK_SWITCH_INPUT = TypeAdapter(bool, config=ConfigDict(strict=True))
CONSOLE_HOOK_ID_INPUT = TypeAdapter(
    Annotated[str, Field(min_length=1)], config=ConfigDict(strict=True)
)
CONSOLE_HOOK_ROWS_INPUT = TypeAdapter(list[object], config=ConfigDict(strict=True))
CONSOLE_HOOK_CONTAINER_INPUT = TypeAdapter(
    dict[str, object], config=ConfigDict(strict=True)
)


class ConsoleHookInput(BaseModel):
    """Strict execution fields; unknown saved fields remain outside this projection."""

    model_config = ConfigDict(extra="ignore", frozen=True, strict=True)

    event: ConsoleHookEvent
    command: list[str] = Field(min_length=1)
    matcher: str | None = None
    timeout_s: float = Field(
        default=CONSOLE_HOOK_DEFAULT_TIMEOUT_S, gt=0, allow_inf_nan=False
    )

    @field_validator("command")
    @classmethod
    def valid_command(cls, value: list[str]) -> list[str]:
        """Reject empty executable names and NUL bytes.

        Args:
            value: Strictly typed nonempty argv list.

        Returns:
            The unchanged argv list.

        Raises:
            ValueError: The executable is empty or an argument contains NUL.
        """
        if not value[0] or any("\x00" in arg for arg in value):
            raise ValueError(
                "Command must be a nonempty argv list of NUL-free strings."
            )
        return value

    @field_validator("matcher")
    @classmethod
    def valid_matcher(cls, value: str | None, info: ValidationInfo) -> str | None:
        """Restrict nonempty matchers to tool events.

        Args:
            value: Optional tool-name glob.
            info: Validated fields, including the selected event.

        Returns:
            The unchanged matcher.

        Raises:
            ValueError: The matcher is empty or belongs to a non-tool event.
        """
        if value is not None:
            if info.data.get("event") not in CONSOLE_HOOK_TOOL_EVENTS:
                raise ValueError("Matcher is only valid for PreToolUse or PostToolUse.")
            if not value:
                raise ValueError("Matcher must be a nonempty glob string.")
        return value


@cache
def _console_new_chat_input_model() -> type[BaseModel]:
    """Build the creation-only schema lazily, outside application startup."""
    from pydantic_core import PydanticCustomError

    from ..Agents.agent_models import CHAT_CREATE_PAYLOAD_MAX, CHAT_CREATE_TITLE_MAX

    class ConsoleNewChatInput(BaseModel):
        """Strict public fields; authority remains outside this projection."""

        model_config = ConfigDict(
            extra="ignore", frozen=True, strict=True, hide_input_in_errors=True
        )

        title: str = Field(default="", max_length=CHAT_CREATE_TITLE_MAX)
        opening_prompt: str = Field(
            default="", max_length=CHAT_CREATE_PAYLOAD_MAX, repr=False
        )
        instructions: str = Field(
            default="", max_length=CHAT_CREATE_PAYLOAD_MAX, repr=False
        )
        destination: Literal["same_workspace", "casual"] = "same_workspace"
        mode: Literal["draft", "start"] = "draft"
        provider: str = ""
        model: str = ""
        preset: str = ""

        @field_validator("destination", "mode", mode="before")
        @classmethod
        def _strict_choice_string(cls, value: object) -> str:
            if not isinstance(value, str):
                raise PydanticCustomError(
                    "string_type", "Input should be a valid string"
                )
            return value

        @field_validator("title")
        @classmethod
        def _trim_title(cls, value: str) -> str:
            # Field length validation has already checked the untrimmed input.
            return value.strip()

        @model_validator(mode="after")
        def _require_start_prompt(self) -> "ConsoleNewChatInput":
            if self.mode == "start" and not self.opening_prompt.strip():
                raise ValueError("start requires a nonblank opening_prompt")
            return self

    return ConsoleNewChatInput


def validate_console_new_chat_arguments(arguments: Mapping[str, Any]) -> dict[str, str]:
    """Validate public chat creation fields without retaining supplied authority.

    Args:
        arguments: Candidate title, opening_prompt, instructions, destination,
            mode, provider, model, and preset. Strings are required without
            coercion. Omitted fields default to empty strings, same_workspace,
            and draft; unknown fields are discarded.

    Returns:
        The eight validated fields. Title is trimmed after its length check;
        prompts, instructions, and routing strings retain their literal bytes.

    Raises:
        ValueError: With an input-free invalid_args or payload_too_large category
            for invalid types, limits, choices, or a blank start prompt.
    """
    from ..Agents.agent_models import CHAT_CREATE_PAYLOAD_MAX, CHAT_CREATE_TITLE_MAX

    try:
        return _console_new_chat_input_model().model_validate(arguments).model_dump()
    except PydanticValidationError as exc:
        errors = exc.errors(
            include_input=False, include_context=False, include_url=False
        )
        # Preserve the original type-first contract even when an earlier field
        # also exceeds a limit. Only known schema locations and error types
        # participate; raw inputs, messages, and exception context never do.
        for error in errors:
            if error["type"] == "string_type":
                raise ValueError(
                    f"invalid_args: {error['loc'][0]} must be a string"
                ) from None
        for error in errors:
            if error["type"] == "string_too_long":
                if error["loc"] == ("title",):
                    raise ValueError(
                        f"payload_too_large: title exceeds {CHAT_CREATE_TITLE_MAX} characters"
                    ) from None
                raise ValueError(
                    "payload_too_large: prompt/instructions exceed "
                    f"{CHAT_CREATE_PAYLOAD_MAX} characters"
                ) from None
        for field in ("destination", "mode"):
            if any(error["loc"] == (field,) for error in errors):
                raise ValueError(f"invalid_args: {field}") from None
        raise ValueError(
            "invalid_args: start requires a nonblank opening_prompt"
        ) from None


_BATCH_TRANSCRIPTION_PROVIDER = TypeAdapter(
    Literal["default", "faster-whisper", "parakeet-onnx", "transcribe-cpp"]
)
_TMUX_IDENTIFIER = TypeAdapter(
    Annotated[
        str,
        Field(strict=True, pattern=r"\A[A-Za-z0-9][A-Za-z0-9_-]{0,63}\z"),
    ]
)


def validate_tmux_identifier(value: object) -> str:
    """Validate a native QA socket or session name without coercion.

    Args:
        value: Candidate containing 1–64 ASCII letters, digits, underscores or
            hyphens, starting with a letter or digit.

    Returns:
        The exact validated name, without trimming or normalization.

    Raises:
        ValueError: The value is not a supported string identifier.
    """
    return _TMUX_IDENTIFIER.validate_python(value)


def validate_batch_transcription_provider(value: object) -> str:
    """Validate a Library transcription provider without coercion.

    Args:
        value: Provider restored from settings or supplied by an option event.

    Returns:
        The exact supported provider identifier.

    Raises:
        ValueError: The value is not a supported provider identifier.
    """
    return _BATCH_TRANSCRIPTION_PROVIDER.validate_python(value, strict=True)

PROVIDER_API_KEY_MAX_LENGTH = 4096
CONSOLE_DRAFT_MAX_LENGTH = 100_000
CONSOLE_FORK_TITLE_MAX_LENGTH = 60
CONSOLE_SWITCHER_QUERY_MAX_LENGTH = 512
CONSOLE_CHARACTER_QUERY_MAX_LENGTH = 200
WORKFLOW_SEARCH_MAX_LENGTH = 512
WORKFLOW_NAME_MAX_LENGTH = 256
WORKFLOW_MAX_PAGE_SIZE = 100
SQLITE_INTEGER_MAX = 2**63 - 1
RAW_CLI_COMMAND_MAX_BYTES = 16 * 1024
RAW_CLI_TIMEOUT_MAX_SECONDS = 300.0
_VLLM_DRAFT_INPUT_LIMITS = {
    "profile_name": 120,
    "python_environment": 4096,
    "hugging_face_model": 96,
    "local_model_directory": 4096,
    "bind_address": 255,
    "existing_server_url": 2048,
    "port": 5,
    "tensor_parallel_size": 10,
    "maximum_model_length": 10,
    "gpu_memory_utilization": 32,
}
TERMINAL_SESSION_NAME_MIN_DISPLAY_CHARACTERS = 1
TERMINAL_SESSION_NAME_MAX_DISPLAY_CHARACTERS = 64
TERMINAL_SESSION_NAME_MAX_CODEPOINTS = 1_024
_EXTENDED_GRAPHEME_PATTERN = regex.compile(r"\X", regex.VERSION1)


def validate_file_picker_sort_key(value: object) -> str:
    """Validate an exact file-picker sort key without coercion.

    Args:
        value: Candidate sort key from a selector event.

    Returns:
        The supported sort key unchanged.

    Raises:
        ValueError: The value is not a supported string sort key.
    """
    if not isinstance(value, str) or value not in (
        "folders",
        "discovery",
        "name",
        "modified",
        "accessed",
        "created",
        "size",
    ):
        raise ValueError("Invalid file picker sort key")
    return value


def validate_file_picker_sort_direction(value: object) -> str:
    """Validate an exact file-picker sort direction without coercion.

    Args:
        value: Candidate direction from a selector event.

    Returns:
        The supported ascending or descending value unchanged.

    Raises:
        ValueError: The value is not a supported string direction.
    """
    if not isinstance(value, str) or value not in ("ascending", "descending"):
        raise ValueError("Invalid file picker sort direction")
    return value


def validate_tts_inference_device(value: object) -> str:
    """Admit an exact device family for the opt-in TTS qualification runner.

    Args:
        value: Candidate device family, without coercion or ordinal expansion.

    Returns:
        The validated cpu, mps or cuda value.

    Raises:
        ValueError: The value is not a supported device family.
    """
    if not isinstance(value, str) or value not in ("cpu", "mps", "cuda"):
        raise ValueError("device must be cpu, mps, or cuda")
    return value


class ReasoningHistorySelectorInput(BaseModel):
    """Strict boundary for a Console reasoning-history selector event.

    Attributes:
        allow_inherit: Whether the per-target reset choice is accepted.
        value: Exact selector value received from the UI event.
    """

    model_config = ConfigDict(extra="forbid", frozen=True, strict=True)

    allow_inherit: bool = False
    value: str

    @field_validator("value")
    @classmethod
    def _validate_value(cls, value: str, info: ValidationInfo) -> str:
        allowed = set(REASONING_HISTORY_MODES)
        if info.data.get("allow_inherit") is True:
            allowed.add("inherit")
        if value not in allowed:
            raise ValueError("invalid reasoning history selector value")
        return value


def validate_reasoning_history_selector(
    value: object,
    *,
    allow_inherit: bool = False,
) -> str:
    """Validate one reasoning-history selector value without coercion.

    Args:
        value: Candidate Textual selector value.
        allow_inherit: Whether the per-target ``inherit`` choice is accepted.

    Returns:
        The exact validated selector value.

    Raises:
        ValueError: If the value has the wrong type or is not an allowed choice.
    """

    try:
        return ReasoningHistorySelectorInput.model_validate(
            {"value": value, "allow_inherit": allow_inherit}
        ).value
    except PydanticValidationError:
        raise ValueError("reasoning history selector value is invalid") from None


class ConversationResumeInput(BaseModel):
    """Strict exact identity accepted by Console resume navigation."""

    model_config = ConfigDict(extra="forbid", frozen=True, strict=True)
    conversation_id: str = Field(min_length=1, max_length=256)

    @field_validator("conversation_id", mode="before")
    @classmethod
    def _exact_identity(cls, value: object) -> str:
        if type(value) is not str or value != value.strip():
            raise ValueError("Console conversation identity is invalid")
        return value


def validate_conversation_resume_id(value: object) -> str:
    """Validate an exact persisted identity without normalizing its spelling.

    Args:
        value: Conversation identity received at a navigation boundary.

    Returns:
        The unchanged nonblank identity, at most 256 characters.

    Raises:
        ValueError: If the type, whitespace or length violates the contract.
    """
    try:
        return ConversationResumeInput.model_validate(
            {"conversation_id": value}
        ).conversation_id
    except PydanticValidationError:
        raise ValueError("Console conversation identity is invalid") from None


class ConversationArchiveScopeInput(BaseModel):
    """Strict shared scope for local conversation lifecycle queries."""

    model_config = ConfigDict(extra="forbid", frozen=True, strict=True)

    scope: Literal["active", "archived", "all"]


def validate_conversation_archive_scope(
    value: object,
) -> Literal["active", "archived", "all"]:
    """Return an exact supported conversation archive scope without coercion.

    Args:
        value: Candidate scope from UI controls, saved navigation, or storage calls.

    Returns:
        The validated active, archived, or all scope.

    Raises:
        ValueError: If the value is not an exact supported scope string.
    """
    try:
        return ConversationArchiveScopeInput.model_validate({"scope": value}).scope
    except PydanticValidationError:
        raise ValueError("archive_scope must be active, archived, or all.") from None


class WorkspaceNameInput(BaseModel):
    """WorkspaceRecord-compatible name: strict text, trimmed and nonblank.

    Workspace names are display text, not filesystem paths. Existing workspace
    policy does not impose a length limit or character blacklist.
    """

    model_config = ConfigDict(
        extra="forbid", frozen=True, strict=True, str_strip_whitespace=True
    )

    name: str = Field(min_length=1)


def validate_workspace_name(value: object) -> str:
    """Validate a workspace display name without changing existing naming policy.

    Args:
        value: Candidate user-facing workspace name.

    Returns:
        The trimmed, nonblank name.

    Raises:
        ValueError: If the name is blank or is not text.
    """
    try:
        return WorkspaceNameInput.model_validate({"name": value}).name
    except PydanticValidationError:
        raise ValueError("Workspace name must be non-blank text.") from None


class VllmDraftInputEvent(BaseModel):
    """Strict lexical boundary for one editable vLLM setup control."""

    model_config = ConfigDict(extra="forbid", frozen=True, strict=True)

    control_id: Literal[
        "profile_name",
        "python_environment",
        "hugging_face_model",
        "local_model_directory",
        "bind_address",
        "existing_server_url",
        "port",
        "tensor_parallel_size",
        "maximum_model_length",
        "gpu_memory_utilization",
    ]
    value: str

    @field_validator("value")
    @classmethod
    def _validate_value(cls, value: str, info: ValidationInfo) -> str:
        control_id = info.data.get("control_id")
        limit = _VLLM_DRAFT_INPUT_LIMITS.get(control_id)
        if limit is None or len(value) > limit:
            raise ValueError("invalid vLLM setup value")
        if any(unicodedata.category(character) == "Cc" for character in value):
            raise ValueError("invalid vLLM setup value")
        return value


def validate_vllm_draft_input(control_id: object, value: object) -> str:
    """Return one exact, bounded vLLM draft edit without semantic coercion.

    Args:
        control_id: Stable identifier for the editable setup control.
        value: Candidate Textual input value.

    Returns:
        The exact validated string, including syntactically partial edits.

    Raises:
        ValueError: If the identifier, type, length, or characters are invalid.
    """

    try:
        return VllmDraftInputEvent.model_validate(
            {"control_id": control_id, "value": value}
        ).value
    except PydanticValidationError:
        raise ValueError("vLLM setup value is invalid") from None


class WorktreeRecoveryActionInput(BaseModel):
    """A recovery operation selected by a tool or the Console picker."""

    model_config = ConfigDict(extra="forbid", frozen=True, strict=True)

    action: Literal["apply", "merge", "discard"]


class WorktreeRecoveryConfirmationInput(BaseModel):
    """Exact boolean consent from the host's current confirmation round.

    Additional host metadata is ignored; it never contributes authority.
    Numeric and string lookalikes cannot become an affirmative decision.
    """

    model_config = ConfigDict(extra="ignore", frozen=True, strict=True)

    allow: bool


class MCPToolResultInput(BaseModel):
    """Validate the MCP error flag without changing existing content payloads.

    Missing flags mean success; present flags must be actual JSON booleans.
    Content remains opaque for the client's existing result/error presentation.
    """

    model_config = ConfigDict(extra="ignore", frozen=True, strict=True)

    is_error: bool = Field(default=False, alias="isError")
    content: Any = Field(default_factory=list)


class MCPProgressInput(BaseModel):
    """Strict optional progress metadata; integer counters retain precision."""

    model_config = ConfigDict(
        extra="ignore", frozen=True, strict=True, allow_inf_nan=False
    )

    progress_token: str = Field(alias="progressToken")
    progress: int | float
    total: int | float | None = None
    message: str = ""

    @field_validator("progress", "total")
    @classmethod
    def _finite_number(cls, value: float | None) -> float | None:
        if value is not None:
            try:
                finite = math.isfinite(value)
            except OverflowError:
                raise ValueError("MCP progress must be finite") from None
            if not finite:
                raise ValueError("MCP progress must be finite")
        return value


class ToolArgumentsInput(BaseModel):
    """Strict shared boundary for an externally supplied tool argument object."""

    model_config = ConfigDict(extra="forbid", frozen=True, strict=True)

    arguments: dict[str, Any]

    @field_validator("arguments", mode="before")
    @classmethod
    def _validate_arguments(cls, value: object) -> dict[str, Any]:
        if type(value) is not dict:
            raise ValueError("tool arguments must be a JSON object")
        _validate_strict_json_value(value, path="$", active_containers=set())
        return value


def validate_tool_arguments(value: object) -> dict[str, Any]:
    """Validate one strict JSON-object tool payload through the shared model.

    Args:
        value: Candidate externally supplied tool arguments.

    Returns:
        The validated JSON object without scalar coercion.

    Raises:
        ValueError: If the payload is not a strict finite JSON object.
    """
    try:
        return ToolArgumentsInput.model_validate({"arguments": value}).arguments
    except PydanticValidationError as exc:
        first = exc.errors(include_url=False)[0]
        context_error = first.get("ctx", {}).get("error")
        message = str(context_error or first.get("msg") or "invalid tool arguments")
        if message.startswith("Value error, "):
            message = message.removeprefix("Value error, ")
        raise ValueError(message) from None


class CanvasGuideArgumentsInput(BaseModel):
    """Strict, closed arguments for the model-visible Canvas guide tool.

    Attributes:
        topic: Exact packaged documentation topic, without coercion.
    """

    model_config = ConfigDict(extra="forbid", frozen=True, strict=True)
    topic: Literal["basics", "controls", "mermaid", "repair"]

    @field_validator("topic", mode="before")
    @classmethod
    def _exact_topic(cls, value: object) -> str:
        if type(value) is not str:
            raise ValueError("invalid topic type")
        return value


def validate_canvas_guide_arguments(value: object) -> dict[str, str]:
    """Validate guide arguments without normalizing or echoing raw input.

    Args:
        value: Untrusted model-issued tool arguments.

    Returns:
        A new dictionary containing only the validated topic.

    Raises:
        ValueError: If arguments are not an exact dictionary with one valid topic.
    """
    if type(value) is not dict:
        raise ValueError("invalid Canvas guide arguments") from None
    try:
        return {"topic": CanvasGuideArgumentsInput.model_validate(value).topic}
    except PydanticValidationError:
        raise ValueError("invalid Canvas guide arguments") from None


class CanvasBridgeWireInput(BaseModel):
    """Strict source-private shape for one untrusted Canvas bridge envelope."""

    model_config = ConfigDict(extra="forbid", frozen=True, strict=True)

    version: str = Field(repr=False)
    request_id: str = Field(repr=False)
    kind: str = Field(repr=False)
    value: Any = Field(repr=False)


def validate_canvas_bridge_wire(value: object) -> CanvasBridgeWireInput:
    """Validate the closed Canvas bridge envelope without semantic coercion.

    Args:
        value: Candidate browser-to-shell request mapping.

    Returns:
        A frozen envelope containing the exact four supplied field values.

    Raises:
        ValueError: If the value is not a mapping or its closed field shape and
            scalar types are invalid.
    """

    if not isinstance(value, Mapping):
        # TRY004: this public wire adapter intentionally exposes ValueError to
        # callers (including the Canvas gateway) for every rejected payload.
        raise ValueError("Canvas bridge request must be an object")  # noqa: TRY004
    if len(value) > len(CanvasBridgeWireInput.model_fields):
        raise ValueError("Canvas bridge request contains unknown fields") from None
    try:
        return CanvasBridgeWireInput.model_validate(dict(value))
    except PydanticValidationError as exc:
        error_types = {
            error["type"]
            for error in exc.errors(
                include_url=False,
                include_context=False,
                include_input=False,
            )
        }
        if "extra_forbidden" in error_types:
            reason = "Canvas bridge request contains unknown fields"
        elif "missing" in error_types:
            reason = "Canvas bridge request is missing fields"
        else:
            reason = "Canvas bridge request fields are invalid"
        raise ValueError(reason) from None


#: Default structural caps for :func:`strict_json_loads`. Family A of the three
#: strict-JSON families the core review found (hosted_chat/qwencloud) used these.
STRICT_JSON_MAX_DEPTH = 128
STRICT_JSON_MAX_NODES = 1_000_000


class StrictJSONError(ValueError):
    """Raised by :func:`strict_json_loads` on any strict-JSON violation.

    A single exception type so every boundary can catch one thing; callers that
    need a boundary-specific error (a sentinel, ``_InvalidContinuation``, a
    protocol error) wrap this and translate it.
    """


def _strict_json_within_limits(value: object, *, max_depth: int, max_nodes: int) -> bool:
    """Iteratively enforce depth/node caps, str-only keys and finite floats.

    Mirrors the family-A shape check (hosted_chat ``_json_shape_is_safe``); kept
    iterative so a hostile document cannot blow the recursion limit here.
    """
    stack: list[tuple[object, int]] = [(value, 1)]
    scheduled_nodes = 1
    try:
        while stack:
            node, depth = stack.pop()
            if depth > max_depth:
                return False
            if type(node) is dict:
                for key, child in node.items():  # type: ignore[union-attr]
                    if not isinstance(key, str):
                        return False
                    scheduled_nodes += 1
                    if scheduled_nodes > max_nodes:
                        return False
                    stack.append((child, depth + 1))
                continue
            if type(node) is list:
                for child in node:  # type: ignore[union-attr]
                    scheduled_nodes += 1
                    if scheduled_nodes > max_nodes:
                        return False
                    stack.append((child, depth + 1))
                continue
            if node is None or isinstance(node, (str, bool)):
                continue
            if isinstance(node, int) and not isinstance(node, bool):
                continue
            if isinstance(node, float) and math.isfinite(node):
                continue
            return False
    except (RecursionError, TypeError, ValueError):
        return False
    return True


def strict_json_loads(
    text: str,
    *,
    max_depth: int = STRICT_JSON_MAX_DEPTH,
    max_nodes: int = STRICT_JSON_MAX_NODES,
    reject_duplicate_keys: bool = True,
) -> object:
    """Parse JSON under one strict contract for every wire and storage boundary.

    Rejects non-finite constants (``NaN``/``Infinity``), enforces a depth and
    node-count cap plus str-only object keys and finite floats, and -- by
    default -- rejects duplicate object keys. Any violation raises
    :class:`StrictJSONError`.

    This is the single home the core review (TASK-32805.5) names for the three
    drifted strict-JSON families. The wire family (hosted_chat/qwencloud) and the
    storage family (provider_continuation/thinking_blocks) both delegate here, so
    a tool-call argument accepted on the wire can no longer be refused when its
    continuation checkpoint is built: both now reject duplicate keys.

    Args:
        text: The raw JSON text.
        max_depth: Maximum nesting depth.
        max_nodes: Maximum total number of container children.
        reject_duplicate_keys: When True (default), a repeated object key is a
            violation rather than last-wins.

    Returns:
        The decoded JSON value.

    Raises:
        StrictJSONError: On malformed JSON, a non-finite constant, a duplicate
            key, a non-str key, a non-finite float, or a shape past the caps.
    """

    def _reject_constant(_value: str) -> "NoReturn":
        raise StrictJSONError("non-finite JSON constant")

    object_pairs_hook = None
    if reject_duplicate_keys:

        def object_pairs_hook(pairs: list[tuple[str, object]]) -> dict[str, object]:
            result: dict[str, object] = {}
            for key, item in pairs:
                if key in result:
                    raise StrictJSONError("duplicate JSON key")
                result[key] = item
            return result

    try:
        decoded = json.loads(
            text, parse_constant=_reject_constant, object_pairs_hook=object_pairs_hook
        )
    except StrictJSONError:
        raise
    except (RecursionError, TypeError, ValueError) as exc:
        raise StrictJSONError("invalid JSON") from exc
    if not _strict_json_within_limits(decoded, max_depth=max_depth, max_nodes=max_nodes):
        raise StrictJSONError("JSON shape exceeds strict limits")
    return decoded


def _validate_strict_json_value(
    value: object,
    *,
    path: str,
    active_containers: set[int],
) -> None:
    value_type = type(value)
    if value is None or value_type in (str, bool, int):
        return
    if value_type is float:
        if not math.isfinite(value):
            raise ValueError(f"JSON number at {path} must be finite")
        return
    if value_type is list:
        _validate_strict_json_container(
            value,
            path=path,
            active_containers=active_containers,
        )
        try:
            for index, item in enumerate(value):
                _validate_strict_json_value(
                    item,
                    path=f"{path}[{index}]",
                    active_containers=active_containers,
                )
        finally:
            active_containers.remove(id(value))
        return
    if value_type is dict:
        _validate_strict_json_container(
            value,
            path=path,
            active_containers=active_containers,
        )
        try:
            for key, item in value.items():
                if type(key) is not str:
                    raise ValueError(f"JSON object key at {path} must be a string")
                _validate_strict_json_value(
                    item,
                    path=f"{path}.{key}",
                    active_containers=active_containers,
                )
        finally:
            active_containers.remove(id(value))
        return
    raise ValueError(f"value at {path} is not a JSON value")


def _validate_strict_json_container(
    value: object,
    *,
    path: str,
    active_containers: set[int],
) -> None:
    marker = id(value)
    if marker in active_containers:
        raise ValueError(f"JSON value at {path} contains a circular reference")
    active_containers.add(marker)


def derive_console_session_title(draft: str, *, max_length: int) -> str:
    """Load the Console title helper lazily to keep validation imports acyclic."""
    from tldw_chatbook.Chat.console_chat_models import (
        derive_console_session_title as derive_title,
    )

    return derive_title(draft, max_length=max_length)


def validate_console_fork_title(value: object) -> str:
    """Return one normalized, bounded Console fork title.

    Args:
        value: Raw value received from the Console naming dialog.

    Returns:
        A nonblank title normalized by the shared Console title helper.

    Raises:
        ValueError: If ``value`` is not text or normalizes to blank.
    """

    if type(value) is not str:
        raise ValueError("Fork title must be text.")
    normalized = derive_console_session_title(
        value,
        max_length=CONSOLE_FORK_TITLE_MAX_LENGTH,
    )
    if not normalized:
        raise ValueError("Fork title cannot be blank.")
    return normalized


class ConsoleForkTitleInput(BaseModel):
    """Strict shared validation boundary for the Console fork naming dialog."""

    model_config = ConfigDict(extra="forbid", frozen=True, strict=True)

    title: str = Field(min_length=1, max_length=CONSOLE_FORK_TITLE_MAX_LENGTH)

    @field_validator("title", mode="before")
    @classmethod
    def _normalize_title(cls, value: object) -> str:
        return validate_console_fork_title(value)


class ConsoleSwitcherQueryInput(BaseModel):
    """Strict shared boundary for the local Ctrl+K search query."""

    model_config = ConfigDict(extra="forbid", frozen=True, strict=True)

    query: str = Field(max_length=CONSOLE_SWITCHER_QUERY_MAX_LENGTH)


class PromptDraftShelfInput(BaseModel):
    """Strict exact-text boundary for one locally persisted Prompt draft.

    Attributes:
        content: Nonblank, bounded, NUL-free Unicode text preserved verbatim.
    """

    model_config = ConfigDict(
        extra="forbid", frozen=True, strict=True, hide_input_in_errors=True
    )

    content: str

    @field_validator("content", mode="plain")
    @classmethod
    def _validate_exact_content(cls, value: object) -> str:
        if not isinstance(value, str):
            raise TypeError("Prompt draft content must be text")
        if len(value) > CONSOLE_DRAFT_MAX_LENGTH:
            raise ValueError(
                "Prompt draft content exceeds the Console draft length limit"
            )
        if not value.strip():
            raise ValueError("Prompt draft content must contain non-whitespace text")
        if "\x00" in value:
            raise ValueError("Prompt draft content must not contain NUL")
        try:
            value.encode("utf-8")
        except UnicodeEncodeError as exc:
            raise ValueError("Prompt draft content must be valid Unicode") from exc
        return value


def validate_prompt_draft_shelf_content(value: object) -> str:
    """Validate a shelf payload without trimming or rewriting its text.

    Args:
        value: Candidate unsent Prompt draft content.

    Returns:
        The exact validated content.

    Raises:
        ValueError: If content is non-text, blank, oversized, contains NUL, or
            cannot be encoded as UTF-8.
    """

    try:
        return PromptDraftShelfInput.model_validate({"content": value}).content
    except (PydanticValidationError, TypeError):
        raise ValueError(
            "Prompt draft content must be nonblank valid Unicode text without NUL, "
            f"at most {CONSOLE_DRAFT_MAX_LENGTH} characters."
        ) from None


class ConsoleCharacterQueryInput(ConsoleSwitcherQueryInput):
    """Character Keyword input constrained to the repository's raw query cap."""

    query: str = Field(max_length=CONSOLE_CHARACTER_QUERY_MAX_LENGTH)

    @field_validator("query")
    @classmethod
    def _reject_controls(cls, value: str) -> str:
        if any(unicodedata.category(character) == "Cc" for character in value):
            raise ValueError("Character search cannot contain control characters")
        return value


def validate_console_character_query(value: object) -> str:
    """Validate raw Character Keyword text before trimming or reading storage."""
    try:
        return ConsoleCharacterQueryInput.model_validate({"query": value}).query
    except PydanticValidationError:
        raise ValueError(
            "Character search: at most 200 characters, without control characters."
        ) from None


def validate_console_switcher_query(value: object) -> str:
    """Return one bounded Console switcher query without normalization.

    Args:
        value: Raw value supplied by the Textual search field.

    Returns:
        The exact validated query string.

    Raises:
        ValueError: If the value is not text or exceeds the query limit.
    """
    try:
        return ConsoleSwitcherQueryInput.model_validate({"query": value}).query
    except PydanticValidationError:
        raise ValueError(
            "Switcher search must be text containing at most "
            f"{CONSOLE_SWITCHER_QUERY_MAX_LENGTH} characters."
        ) from None


class WorkflowNameInput(BaseModel):
    """Bounded New workflow input, not a portable document-name restriction.

    Attributes:
        name: Nonempty trimmed Unicode text, from at most 256 raw characters.
    """

    model_config = ConfigDict(
        extra="forbid", frozen=True, strict=True, hide_input_in_errors=True
    )

    name: str

    @field_validator("name", mode="plain")
    @classmethod
    def _bounded_name(cls, value: object) -> str:
        if not isinstance(value, str):
            raise TypeError("Workflow name must be text")
        if len(value) > WORKFLOW_NAME_MAX_LENGTH:
            raise ValueError(
                f"Workflow name must contain at most {WORKFLOW_NAME_MAX_LENGTH} characters"
            )
        value.encode("utf-8")  # Server definition names are bound as database text.
        name = value.strip()
        if not name:
            raise ValueError("Name the workflow before creating it")
        return name


def validate_workflow_name(value: object) -> str:
    """Validate a New workflow name with concise, input-free error guidance.

    Args:
        value: Raw creation name, bounded before whitespace trimming.

    Returns:
        Nonempty trimmed, UTF-8-encodable text, without Unicode normalization.

    Raises:
        ValueError: The name is non-text, blank, malformed Unicode or too long.
    """
    try:
        return WorkflowNameInput(name=value).name
    except (PydanticValidationError, TypeError):
        raise ValueError(
            "Workflow name must be nonblank valid Unicode text, at most "
            f"{WORKFLOW_NAME_MAX_LENGTH} characters."
        ) from None


class WorkflowSearchInput(BaseModel):
    """Strict parameters for local workflow-library reads.

    Attributes:
        query: Unmodified substring, at most 512 Python characters.
        page_size: Number of results requested, from 1 to 100.
        offset: Nonnegative matching-result offset within SQLite's integer range.
    """

    model_config = ConfigDict(
        extra="forbid", frozen=True, strict=True, hide_input_in_errors=True
    )

    query: str
    page_size: int = Field(ge=1, le=WORKFLOW_MAX_PAGE_SIZE)
    offset: int = Field(ge=0, le=SQLITE_INTEGER_MAX)

    @field_validator("query", mode="plain")
    @classmethod
    def _bounded_query(cls, value: object) -> str:
        # Ordinary Pydantic str validation rejects lone surrogates already
        # admitted in saved JSON names. Validate without rewriting those names.
        if not isinstance(value, str):
            raise TypeError("Workflow search must be text")
        if len(value) > WORKFLOW_SEARCH_MAX_LENGTH:
            raise ValueError(
                f"Workflow search must contain at most {WORKFLOW_SEARCH_MAX_LENGTH} characters"
            )
        return value


class TerminalSessionNameInput(BaseModel):
    """Strict shared boundary for a persistent-terminal display name."""

    model_config = ConfigDict(extra="forbid", frozen=True, strict=True)

    name: str

    @field_validator("name", mode="before")
    @classmethod
    def _normalize_name(cls, value: object) -> str:
        if not isinstance(value, str):
            raise TypeError("terminal session name must be text")
        if len(value) > TERMINAL_SESSION_NAME_MAX_CODEPOINTS:
            raise ValueError(
                "terminal session name must contain at most "
                f"{TERMINAL_SESSION_NAME_MAX_CODEPOINTS} code points"
            )
        normalized = unicodedata.normalize("NFC", value.strip())
        if len(normalized) > TERMINAL_SESSION_NAME_MAX_CODEPOINTS:
            raise ValueError(
                "terminal session name must contain at most "
                f"{TERMINAL_SESSION_NAME_MAX_CODEPOINTS} code points"
            )
        grapheme_count = sum(
            1
            for _match in islice(
                _EXTENDED_GRAPHEME_PATTERN.finditer(normalized),
                TERMINAL_SESSION_NAME_MAX_DISPLAY_CHARACTERS + 1,
            )
        )
        if not (
            TERMINAL_SESSION_NAME_MIN_DISPLAY_CHARACTERS
            <= grapheme_count
            <= TERMINAL_SESSION_NAME_MAX_DISPLAY_CHARACTERS
        ):
            raise ValueError(
                "terminal session name must contain "
                f"{TERMINAL_SESSION_NAME_MIN_DISPLAY_CHARACTERS} to "
                f"{TERMINAL_SESSION_NAME_MAX_DISPLAY_CHARACTERS} characters"
            )
        if any(
            unicodedata.category(character) in {"Cc", "Cf", "Cs"}
            for character in normalized
        ):
            raise ValueError("terminal session name must not contain controls")
        if "[" in normalized or "]" in normalized:
            raise ValueError("terminal session name must not contain markup")
        return normalized


TerminalPasteViolation = Literal["too_large", "prohibited_control"]


class TerminalPasteInput(BaseModel):
    """Strict shared boundary for one terminal paste offer."""

    model_config = ConfigDict(extra="forbid", frozen=True, strict=True)

    text: str = Field(repr=False)
    bracketed: bool

    def classify(self) -> tuple[TerminalPasteViolation | None, bytes]:
        """Classify paste content and return its replacement-encoded payload.

        Returns:
            A content-free violation category and payload bytes. The payload is
            empty when a violation is present.
        """
        from ..Terminal.contracts import MAX_PASTE_BYTES

        if len(self.text) > MAX_PASTE_BYTES:
            return "too_large", b""
        for character in self.text:
            codepoint = ord(character)
            if codepoint < 0x20 and character not in "\t\n\r":
                return "prohibited_control", b""
            if 0x7F <= codepoint <= 0x9F:
                return "prohibited_control", b""
        payload = self.text.encode("utf-8", "replace")
        if len(payload) > MAX_PASTE_BYTES:
            return "too_large", b""
        return None, payload


class TerminalKeyInput(BaseModel):
    """Strict shared boundary for encoded terminal key bytes."""

    model_config = ConfigDict(extra="forbid", frozen=True, strict=True)

    data: bytes = Field(repr=False)


class TerminalReplyInput(BaseModel):
    """Strict shared boundary for code-owned terminal reply bytes."""

    model_config = ConfigDict(extra="forbid", frozen=True, strict=True)

    data: bytes = Field(repr=False)


class TerminalOutputInput(BaseModel):
    """Strict shared boundary for terminal backend output bytes."""

    model_config = ConfigDict(extra="forbid", frozen=True, strict=True)

    data: bytes = Field(repr=False)


class TerminalResizeInput(BaseModel):
    """Strict shared boundary for terminal resize dimensions."""

    model_config = ConfigDict(extra="forbid", frozen=True, strict=True)

    columns: int
    rows: int

    @field_validator("columns")
    @classmethod
    def _validate_columns(cls, value: int) -> int:
        from ..Terminal.contracts import MAX_COLUMNS, MIN_COLUMNS

        if not MIN_COLUMNS <= value <= MAX_COLUMNS:
            raise ValueError("terminal columns are outside contract")
        return value

    @field_validator("rows")
    @classmethod
    def _validate_rows(cls, value: int) -> int:
        from ..Terminal.contracts import MAX_ROWS, MIN_ROWS

        if not MIN_ROWS <= value <= MAX_ROWS:
            raise ValueError("terminal rows are outside contract")
        return value


_TerminalBytesInput = TypeVar(
    "_TerminalBytesInput",
    TerminalKeyInput,
    TerminalReplyInput,
    TerminalOutputInput,
)


def _validate_terminal_bytes_input(
    model_type: type[_TerminalBytesInput],
    data: object,
    *,
    label: str,
) -> _TerminalBytesInput:
    """Return one strict bytes model with a content-free type error."""
    try:
        return model_type.model_validate({"data": data})
    except PydanticValidationError:
        raise TypeError(f"terminal {label} data must be bytes") from None


def validate_terminal_key_input(data: object) -> TerminalKeyInput:
    """Validate encoded terminal key bytes through the shared model.

    Args:
        data: Candidate encoded key bytes.

    Returns:
        Strict validated key model.

    Raises:
        TypeError: If ``data`` is not immutable bytes.
    """
    return _validate_terminal_bytes_input(TerminalKeyInput, data, label="key")


def validate_terminal_paste_input(
    text: object, bracketed: object
) -> TerminalPasteInput:
    """Validate a terminal paste offer through the shared model.

    Args:
        text: Candidate paste text.
        bracketed: Candidate bracketed-paste mode flag.

    Returns:
        Strict validated paste model.

    Raises:
        TypeError: If either value has the wrong type.
    """
    try:
        return TerminalPasteInput.model_validate({"text": text, "bracketed": bracketed})
    except PydanticValidationError:
        raise TypeError("terminal paste values have invalid types") from None


def validate_terminal_reply_input(data: object) -> TerminalReplyInput:
    """Validate terminal reply bytes through the shared model.

    Args:
        data: Candidate terminal reply bytes.

    Returns:
        Strict validated reply model.

    Raises:
        TypeError: If ``data`` is not immutable bytes.
    """
    return _validate_terminal_bytes_input(TerminalReplyInput, data, label="reply")


def validate_terminal_output_input(data: object) -> TerminalOutputInput:
    """Validate terminal backend output through the shared model.

    Args:
        data: Candidate backend output bytes.

    Returns:
        Strict validated output model.

    Raises:
        TypeError: If ``data`` is not immutable bytes.
    """
    return _validate_terminal_bytes_input(TerminalOutputInput, data, label="output")


def validate_terminal_resize_input(
    columns: object, rows: object
) -> TerminalResizeInput:
    """Validate terminal dimensions through the shared model.

    Args:
        columns: Candidate terminal width.
        rows: Candidate terminal height.

    Returns:
        Strict validated resize model.

    Raises:
        TypeError: If either dimension is not an integer.
        ValueError: If either dimension is outside the terminal contract.
    """
    if type(columns) is not int or type(rows) is not int:
        raise TypeError("terminal dimensions must be integers")
    try:
        return TerminalResizeInput.model_validate({"columns": columns, "rows": rows})
    except PydanticValidationError:
        raise ValueError("terminal dimensions are outside contract") from None


class TerminalEnvironmentInput(BaseModel):
    """Strict shared boundary for persistent-terminal environment sources."""

    model_config = ConfigDict(extra="forbid", frozen=True, strict=True)

    platform_name: Literal["posix", "nt"]
    ambient: dict[str, str]
    account: dict[str, str]
    system: dict[str, str]


class RawShellExecInput(BaseModel):
    """Strict shared boundary for model-authored raw-shell arguments."""

    model_config = ConfigDict(extra="forbid", frozen=True, strict=True)

    command: str = Field(min_length=1)
    shell: Literal["auto", "bash", "powershell", "cmd"] = "auto"
    initial_directory: str | None = None
    timeout_seconds: float = Field(
        default=RAW_CLI_TIMEOUT_MAX_SECONDS,
        gt=0,
        le=RAW_CLI_TIMEOUT_MAX_SECONDS,
    )

    @field_validator("command")
    @classmethod
    def _validate_command(cls, value: str) -> str:
        return validate_raw_cli_command(value)

    @field_validator("initial_directory", mode="before")
    @classmethod
    def _reject_explicit_null_directory(cls, value: object) -> object:
        if value is None:
            raise ValueError("initial_directory must be a string when provided")
        return value


class SkillsListInput(BaseModel):
    """Strict shared boundary for exact local Skills-list requests."""

    model_config = ConfigDict(extra="forbid", frozen=True, strict=True)

    limit: int = Field(gt=0)
    offset: int = Field(ge=0)
    query: str = ""
    sort: Literal["name", "status"] = "name"

    @field_validator("sort", mode="before")
    @classmethod
    def _normalize_sort(cls, value: object) -> object:
        return value.strip().lower() if type(value) is str else value




def validate_env_var_reference(name: str) -> bool:
    """Validate an environment-variable reference name (credential lookup key).

    Covers user-entered ``api_key_env``-style references: a portable
    environment-variable name (POSIX ``[A-Za-z_][A-Za-z0-9_]*``) of at most
    128 characters. The value is only ever used as an ``os.environ`` lookup
    key, so shape validation exists to catch typos and stray punctuation,
    not to defuse an injection surface.

    Args:
        name: Candidate variable name (already stripped by the caller).

    Returns:
        ``True`` when ``name`` is a well-formed environment-variable name;
        ``False`` otherwise (never raises).
    """
    if not name or len(name) > 128:
        return False
    return bool(re.fullmatch(r"[A-Za-z_][A-Za-z0-9_]*", name))



def validate_bounded_integer(value: object, *, minimum: int, maximum: int) -> int:
    """Normalize an integer form value within inclusive bounds.

    Args:
        value: Integer or integer text, allowing signs and surrounding whitespace.
        minimum: Inclusive lower bound.
        maximum: Inclusive upper bound.

    Returns:
        The validated integer value.

    Raises:
        ValueError: If the value is not integer text or an integer, is a boolean,
            or falls outside the bounds.
    """
    if isinstance(value, bool) or not isinstance(value, (str, int)):
        raise ValueError("Value must be an integer")  # noqa: TRY004 - form validation uses ValueError
    try:
        number = int(value)
    except ValueError:
        raise ValueError("Value must be an integer") from None
    if not minimum <= number <= maximum:
        raise ValueError(f"Value must be between {minimum} and {maximum}")
    return number


def validate_sharing_clone_input(
    share_id: object, name: object
) -> tuple[int, str | None]:
    """Normalize a clone form before looking up its retained request identity.

    Args:
        share_id: Positive database identifier, supplied as integer or form text.
        name: Optional display name; blank text requests the server default name.

    Returns:
        The positive share ID and name with server-equivalent whitespace folding.

    Raises:
        ValueError: The identifier is invalid, or the name is not text or exceeds
            255 characters after whitespace normalization.
    """
    normalized_id = validate_bounded_integer(
        share_id, minimum=1, maximum=SQLITE_INTEGER_MAX
    )
    normalized_name = TypeAdapter(str | None).validate_python(name, strict=True)
    if normalized_name is not None:
        normalized_name = " ".join(normalized_name.split()) or None
    if normalized_name is not None and len(normalized_name) > 255:
        raise ValueError("Clone name must be at most 255 characters.")
    return normalized_id, normalized_name


class BuddyManagementInput(BaseModel):
    """Bound raw Buddy form values before resolving selected application identities."""

    model_config = ConfigDict(extra="forbid", frozen=True, strict=True)

    enabled: bool
    artwork: str = Field(max_length=256)
    archive: str = Field(max_length=4096)
    target: str = Field(max_length=512)
    persona: str = Field(max_length=256)
    motion: Literal["dynamic", "static"]
    speak_responses: bool
    width: int
    height: int

    @field_validator("width", "height", mode="before")
    @classmethod
    def _dimensions(cls, value: object, info: ValidationInfo) -> int:
        minimum, maximum = (8, 120) if info.field_name == "width" else (4, 60)
        return validate_bounded_integer(value, minimum=minimum, maximum=maximum)


class BuddyImportPathInput(BaseModel):
    """Strict raw input for a Buddy pack path before lexical normalization."""

    model_config = ConfigDict(extra="forbid", frozen=True, strict=True)

    path: str = Field(min_length=1, max_length=4096)


def validate_buddy_import_path(value: object) -> str:
    """Return a stable lexical pack path without probing files or resolving links.

    Args:
        value: Pasted absolute or current-home-relative path, optionally quoted.

    Returns:
        Validated absolute path text for both archive review and retry identity.

    Raises:
        ValueError: Input has an invalid type, length or unsafe path syntax, is a
            URL, or remains relative after expanding the current home shorthand.
    """
    import os
    from pathlib import Path

    from .path_validation import validate_path_simple

    invalid_path = "Check the path. Enter a local Buddy pack filename."
    try:
        entered = BuddyImportPathInput.model_validate({"path": value}).path
    except PydanticValidationError:
        raise ValueError(invalid_path) from None
    entered = entered.strip()
    if len(entered) >= 2 and entered[0] in {"'", '"'} and entered[-1] == entered[0]:
        entered = entered[1:-1]
    if entered.lower().startswith(("http://", "https://", "file://")):
        raise ValueError(
            "Download the pack first, then enter its local filesystem path."
        )
    # Concatenation preserves the home prefix even for ~// paths. Do not resolve
    # links or collapse parent components: the native reader owns file authority.
    if entered.startswith("~/") or (os.name == "nt" and entered.startswith("~\\")):
        entered = str(Path.home()) + entered[1:]
    try:
        path = validate_path_simple(entered, probe_existing=False)
    except ValueError:
        raise ValueError(invalid_path) from None
    if not path.is_absolute():
        raise ValueError(
            "Enter an absolute path or a path starting with ~/ to the downloaded pack."
        )
    return str(path)



def validate_request_endpoint_path(endpoint: object) -> str:
    """Refuse an API request path that an interpolated value has escaped.

    Clients build request paths with f-strings (``f"/api/v1/sharing/public/
    {token}"``); most of those segments are ``str``-annotated parameters that
    reach no ``quote()``. httpx resolves the path via ``base_url.join()``,
    which treats ``?``/``#`` as delimiters and normalises ``..`` -- so a
    pasted share token containing ``?`` appends attacker-chosen query
    parameters to an authenticated request, and one containing ``../`` walks
    out of the API namespace with the credential header still attached.

    Lives here rather than in the client so the delimiter and traversal
    policy cannot drift away from the repository's shared input boundary.
    Fails CLOSED: no endpoint in `tldw_api` carries a literal ``?``/``#``.
    It deliberately does not re-encode ``/`` -- per-segment quoting remains
    the complete fix.

    Args:
        endpoint: The request path assembled by the calling method.

    Returns:
        The endpoint, unchanged, when it is safe to send.

    Raises:
        ValueError: On a non-string, a query/fragment delimiter, or a ``..``
            segment. Callers translate this into their own error family.
    """
    if not isinstance(endpoint, str):
        raise ValueError("Refusing to send a non-string request path.")
    if "?" in endpoint or "#" in endpoint:
        raise ValueError(
            "Refusing to send a request path containing '?' or '#': a value "
            "interpolated into the endpoint escaped its path segment."
        )
    if ".." in endpoint.split("/"):
        raise ValueError(
            "Refusing to send a request path containing a '..' segment: a "
            "value interpolated into the endpoint escaped its path segment."
        )
    return endpoint


def validate_url(url: str) -> bool:
    """Validate an http/https URL by scheme and host.

    Uses ``urllib.parse`` (so long TLDs, IPv6 literals, IDN/Unicode hosts, IPs,
    and localhost all validate) but rejects inputs that ``urlparse`` is too
    lenient about: raw whitespace, backslashes (browsers normalise ``\\``→``/``,
    a parser-discrepancy SSRF vector), embedded credentials (``user:pass@host``,
    which would carry secrets into logged/forwarded URLs), and malformed hosts
    (leading/consecutive dots) or ports. Only ``http``/``https`` schemes pass.

    Args:
        url: The candidate URL string.

    Returns:
        ``True`` if ``url`` is a well-formed http/https URL with a valid host
        and no whitespace/backslashes/credentials/malformed host or port;
        ``False`` otherwise (never raises).
    """
    start_time = time.time()
    log_counter("input_validation_url_attempt")

    if not url or len(url) > 2000:
        log_counter(
            "input_validation_url_invalid",
            labels={"reason": "empty" if not url else "too_long"},
        )
        return False

    if any(c.isspace() for c in url) or "\\" in url:
        # A valid URL has no raw whitespace (spaces are %-encoded) and no
        # backslashes (which HTTP clients may normalise to "/", enabling
        # parser-discrepancy SSRF/open-redirect bypasses).
        result = False
    else:
        try:
            parsed = urlparse(url)
            _ = parsed.port  # raises ValueError on a malformed/out-of-range port
            hostname = parsed.hostname
            result = (
                parsed.scheme in ("http", "https")
                and bool(hostname)
                and not hostname.startswith(".")  # reject ".example.com" / ".."
                and ".." not in hostname  # reject "example..com"
                and parsed.username is None  # reject embedded credentials
                and parsed.password is None
            )
        except ValueError:
            result = False

    # Log result
    duration = time.time() - start_time
    log_histogram("input_validation_url_duration", duration)
    log_counter(
        "input_validation_url_result",
        labels={
            "valid": str(result),
            "scheme": "https"
            if result and url.startswith("https://")
            else "http"
            if result
            else "invalid",
        },
    )
    log_histogram("input_validation_url_length", len(url))

    return result


_GIT_ALLOWED_SCHEMES = frozenset({"https", "ssh"})
_GIT_REF_RE = re.compile(r"^[A-Za-z0-9._/-]+\Z")


def validate_git_repo_url(url: str) -> None:
    """Validate a git clone repo URL against a strict transport allowlist.

    Only explicit ``https://`` and ``ssh://`` schemes are accepted. scp-style
    shorthand (``user@host:path``) is rejected because its no-scheme,
    colon-before-slash shape is ambiguous with git's ``ext::``/``fd::`` custom
    transports and with leading-dash argument-injection payloads; use
    ``ssh://git@host/path`` instead. Rejects custom transports (``ext``,
    ``file``, ``fd``, ``git``, ...), whitespace/backslash/control characters,
    a leading ``-`` (git-option injection), and anything without a scheme.

    Args:
        url: The candidate repo URL.

    Raises:
        ValidationError: If ``url`` is not an allowlisted, well-formed git URL.
    """
    if not isinstance(url, str) or not url:
        raise ValidationError("repo_url must be a non-empty string")
    if url != url.strip() or any(c.isspace() for c in url):
        raise ValidationError("repo_url must not contain whitespace")
    if "\\" in url or any(ord(c) < 0x20 for c in url):
        raise ValidationError(
            "repo_url must not contain backslashes or control characters"
        )
    if not url.isprintable():
        raise ValidationError(
            "repo_url must not contain non-printable/zero-width characters"
        )
    if url.startswith("-"):
        raise ValidationError("repo_url must not start with '-' (git-option injection)")
    try:
        parsed = urlparse(url)
    except ValueError as exc:
        raise ValidationError(f"repo_url is not a parseable URL: {exc}")
    if parsed.scheme.lower() not in _GIT_ALLOWED_SCHEMES:
        raise ValidationError(
            f"repo_url scheme {parsed.scheme!r} is not allowed; "
            "only https:// and ssh:// git URLs are permitted"
        )
    if not parsed.hostname:
        raise ValidationError("repo_url must include a host")
    if (parsed.hostname or "").startswith("-") or (parsed.username or "").startswith(
        "-"
    ):
        raise ValidationError(
            "repo_url host/user must not start with '-' (ssh option injection)"
        )


def validate_git_ref(ref: str) -> None:
    """Validate a git branch/ref name for use as a ``--branch`` value.

    Rejects a leading ``-`` (git-option injection), whitespace/control chars,
    ``..``, and any character outside ``[A-Za-z0-9._/-]``.

    Args:
        ref: The candidate branch/ref name.

    Raises:
        ValidationError: If ``ref`` is unsafe or not a well-formed ref name.
    """
    if not isinstance(ref, str) or not ref:
        raise ValidationError("ref must be a non-empty string")
    if ref.startswith("-"):
        raise ValidationError("ref must not start with '-' (git-option injection)")
    if ".." in ref:
        raise ValidationError("ref must not contain '..'")
    if not _GIT_REF_RE.match(ref):
        raise ValidationError(
            "ref may only contain letters, digits, '.', '_', '/', '-'"
        )



def validate_text_input(
    text: str, max_length: int = 10000, allow_html: bool = False
) -> bool:
    """Validate general text input."""
    start_time = time.time()
    log_counter(
        "input_validation_text_attempt",
        labels={"max_length": str(max_length), "allow_html": str(allow_html)},
    )

    if text is None:
        log_counter(
            "input_validation_text_result", labels={"valid": "true", "type": "none"}
        )
        return True  # Allow None/empty

    if len(text) > max_length:
        log_counter("input_validation_text_invalid", labels={"reason": "too_long"})
        log_histogram("input_validation_text_oversized_length", len(text))
        return False

    if not allow_html:
        # Check for potential HTML/script injection
        dangerous_patterns = [
            "<script",
            "</script",
            "javascript:",
            "onclick=",
            "onerror=",
        ]
        text_lower = text.lower()
        for pattern in dangerous_patterns:
            if pattern in text_lower:
                log_counter(
                    "input_validation_text_invalid",
                    labels={"reason": "dangerous_pattern", "pattern": pattern},
                )
                return False

    # Log success
    duration = time.time() - start_time
    log_histogram("input_validation_text_duration", duration)
    log_histogram("input_validation_text_length", len(text))
    log_counter(
        "input_validation_text_result", labels={"valid": "true", "type": "text"}
    )

    return True


#: Bound for one user-typed Dreams phrase (a topic, a goal, the region):
#: this many code points that are NOT combining marks. The text is
#: embedded in the query-synthesis prompt and, on the deterministic
#: fallback, in an outbound search query.
#:
#: Marks are left out of the count because the count has to be the same
#: every time the text is read (review of #2921, round 5, F3): NFC writes
#: some single letters as a letter and a mark (the Devanagari nukta
#: letters) and some letter-and-mark pairs as one letter, so a measure in
#: plain code points depends on which form it is taken of -- and the
#: typed form is gone once the text is stored. Round 4 took the shorter
#: of the two, stored text that was longer than 200, and then refused
#: its own stored form.
DREAMS_PROFILE_TEXT_MAX_LENGTH = 200

#: Bound on the stored form as a whole, marks included: no phrase is
#: longer than this however its letters are decorated.
_DREAMS_TEXT_MAX_STORED_LENGTH = DREAMS_PROFILE_TEXT_MAX_LENGTH * 3

#: Raw input longer than this is refused before anything is done with
#: it: it only keeps a multi-megabyte paste from being copied, normalised
#: and scanned. Generous on purpose -- it runs BEFORE the invisible
#: characters are removed, and text that is short once they are gone is
#: not refused for them (round 5, N6: 800 zero width spaces and an "x"
#: were "longer than 200 characters").
_DREAMS_TEXT_RAW_LENGTH_CAP = 20_000

#: Text still longer than this once the invisible characters are removed
#: is refused before any per-character Unicode work. NFC composition can
#: shorten text, so the exact bound is applied after it; this one only
#: bounds the work.
_DREAMS_TEXT_PRECHECK_LENGTH = DREAMS_PROFILE_TEXT_MAX_LENGTH * 4

#: General categories that end a line or are raw controls: every C0/C1
#: control (which includes every ASCII line break) and Unicode's own line
#: and paragraph separators.
_DREAMS_TEXT_LINE_CATEGORIES = frozenset({"Cc", "Zl", "Zp"})

#: The bidirectional embedding, override and isolate controls: they make
#: text DISPLAY in another order than it is stored and sent.
_DREAMS_TEXT_DIRECTION_CONTROLS = frozenset(
    "\u202a\u202b\u202c\u202d\u202e\u2066\u2067\u2068\u2069")

#: The format characters (category Cf) real text needs or shows:
#:
#: * the two joiners (emoji sequences, Persian and Indic shaping), the
#:   three directional MARKS, and the Mongolian vowel separator (shaping);
#: * the VISIBLE ones -- Unicode's prepended concatenation marks: the
#:   Arabic number sign and its siblings, end of ayah, the Syriac
#:   abbreviation mark, the Kaithi number signs (round 4, C4: these were
#:   refused although people type them and they show).
#:
#: Every other Cf character is refused -- the direction controls above,
#: invisible operators, deprecated format characters, interlinear
#: annotation, tag characters outside a flag: all of them change what
#: the text IS without changing what the user sees. (Variation selectors
#: are category Mn, not Cf, and stay allowed.)
_DREAMS_TEXT_ALLOWED_FORMAT = frozenset(
    "\u200c\u200d\u200e\u200f\u061c\u180e"
    "\u0600\u0601\u0602\u0603\u0604\u0605\u06dd\u070f"
    "\u0890\u0891\u08e2\U000110bd\U000110cd")

#: Invisible characters that only hint at line breaks or ride along with
#: a paste. They are REMOVED from the text, not refused (round 4, C4):
#: Thai and Khmer are typed with zero width spaces between words, pasted
#: text carries soft hyphens and a leading byte order mark, and none of
#: them is part of what the user means. Zero width space, soft hyphen,
#: word joiner, byte order mark, object replacement character -- and the
#: invisible maths operators (function application, invisible times,
#: separator and plus) that pasted formulas carry (round 5, N6).
_DREAMS_TEXT_REMOVED = dict.fromkeys(
    map(ord, "\u200b\u00ad\u2060\ufeff\ufffc\u2061\u2062\u2063\u2064"))

#: Blanks that take up room: braille's own space and the Hangul fillers
#: people use as an "invisible letter". Written as a plain space, so
#: ``jazz<U+2800>guitar`` is stored as what it looks like (round 4, I3).
_DREAMS_TEXT_BLANK_AS_SPACE = dict.fromkeys(
    map(ord, "\u2800\u3164\uffa0"), " ")

#: Characters that render as nothing although Unicode files them under
#: letters or symbols, and that are left where they are because Hangul
#: jamo composition (and music notation) uses them structurally. They do
#: not count as readable text.
_DREAMS_TEXT_BLANK = frozenset("\u115f\u1160\U0001d159")

#: A well-formed emoji tag sequence -- a subdivision flag such as
#: England's: WAVING BLACK FLAG, tag letters/digits, CANCEL TAG. Tag
#: characters are legitimate inside one and nowhere else (round 4, C4).
_DREAMS_TEXT_FLAG_SEQUENCE_RE = re.compile(
    "\U0001f3f4[\U000e0030-\U000e0039\U000e0061-\U000e007a]+\U000e007f")

#: An emoji Unicode writes as punctuation or a maths sign with a selector
#: after it (round 5, N4): a keycap -- 0-9, ``#`` or ``*``, optionally
#: U+FE0F, then the combining enclosing keycap U+20E3 -- or one of the
#: few emoji presentation sequences on such a base (the double
#: exclamation and exclamation-question marks, the left-right arrow, the
#: medium and small squares, the curved arrows, the wavy dash, the part
#: alternation mark). Alone each base is not readable; the emoji is.
#:
#: Only the sequences Unicode DEFINES (round 6, G2). Round 5 accepted any
#: character in front of a selector, and so a zero width joiner, a
#: direction mark, a combining mark or a filler with U+FE0F after it was
#: a topic. ``+\ufe0f`` and ``-\u20e3`` are not emoji either: they are
#: what ``+`` and ``-`` are, maths signs, which alone are refused.
#:
#: The selector is OPTIONAL on these bases, and the five skin-tone
#: swatches (category Sk) count on their own too (round 7, H4): the
#: medium small squares and the swatches show as emoji by default, so an
#: emoji keyboard produces them without U+FE0F, and the rest are emoji
#: whichever way they were typed. Every entry of rich's emoji table is
#: readable with and without its selectors (pinned by a test).
_DREAMS_TEXT_EMOJI_PRESENTATION_RE = re.compile(
    "[#*0-9]\ufe0f?\u20e3"
    "|[\u203c\u2049\u2194\u25fb-\u25fe\u2934\u2935\u3030\u303d"
    "\U0001f3fb-\U0001f3ff]")

# One refusal per thing that can be wrong (round 4, C4): the caller shows
# it after "Topic not added: " / "Goal not added: " / "Region not saved: ".
_DREAMS_TEXT_TOO_LONG = (
    f"it is longer than {DREAMS_PROFILE_TEXT_MAX_LENGTH} characters.")
_DREAMS_TEXT_NOT_ONE_LINE = (
    "it has a line break or a control character in it; use a single line.")
_DREAMS_TEXT_NOTHING_READABLE = (
    "there is nothing readable in it; type a word, a number or an emoji.")
_DREAMS_TEXT_HIDDEN_DIRECTION = (
    "it has hidden text-direction characters in it, which make text show "
    "in another order than it is stored; type it again without them.")
_DREAMS_TEXT_HIDDEN_FORMAT = (
    "it has invisible formatting characters in it; type it again without "
    "them.")
_DREAMS_TEXT_NOT_TEXT = "it has a character in it that is not valid text."


def _is_noncharacter(char: str) -> bool:
    """Whether a code point is one of Unicode's 66 noncharacters."""
    code = ord(char)
    return 0xFDD0 <= code <= 0xFDEF or (code & 0xFFFE) == 0xFFFE


def validate_dreams_profile_text(value: object) -> str:
    """Validate one user-typed Dreams phrase and return the form to store.

    A topic, a goal and the region each end up embedded in the
    query-synthesis prompt and (on the deterministic fallback, and for
    the region in a tracked question) in an outbound search query. The
    rule is about what the text IS, not about what it mentions:

    * one line: no control character, no line or paragraph separator;
    * something to read: a letter or a number in any script, an emoji
      (including one written as punctuation or a sign with the emoji
      selector or the keycap, round 5, N4), or a symbol of the "other"
      or currency kind (heart, euro, copyright); punctuation, maths signs
      (+, infinity, arrows), modifier symbols, combining marks and
      characters that render as nothing alone are not a topic (round 4,
      I3);
    * nothing hidden that changes what the text is: no bidirectional
      embedding/override/isolate control, and no other invisible format
      character except the joiners, directional marks and visible format
      characters real text needs (``_DREAMS_TEXT_ALLOWED_FORMAT``), and
      tag characters inside a subdivision flag;
    * no noncharacter and no lone surrogate (which cannot even be written
      to SQLite or TOML);
    * at most ``DREAMS_PROFILE_TEXT_MAX_LENGTH`` Unicode code points that
      are not combining marks, and three times that in all -- measured on
      the stored form, in a way normalisation cannot change, so that the
      stored form always passes this rule again (round 5, F3). An emoji
      counts once per code point, an accent never counts apart from its
      letter, and a letter NFC writes as a letter and a mark counts once.

    Text people type is not refused for what this interpreter's Unicode
    tables happen to know (round 4, C4): private-use code points (the
    Apple logo) and code points "unassigned" in this Python's Unicode
    version (next year's emoji) are ordinary characters here. Invisible
    characters that are not part of what the user means are removed
    instead of refused -- zero width space, soft hyphen, word joiner,
    byte order mark -- and a blank that takes up room (braille's space,
    the Hangul filler) is stored as a space.

    There is deliberately NO script or markup rule (review of #2921,
    round 3, item 8). Nothing renders this text as HTML or script -- the
    TUI shows it literally (``markup=False`` / ``rich.text.Text``), prompts
    and searches carry it as plain strings -- so such a rule protected
    nothing, while it refused ordinary interests ("JavaScript: The Good
    Parts") and was trivially evaded anyway. Angle brackets, square
    brackets and braces are ordinary text here. The app-wide
    ``validate_text_input`` is therefore not consulted.

    "Shows it literally" is a statement about Dreams' OWN screens, and it
    stopped being the whole story once this text leaves them (round 4,
    C1): a watched query becomes an event reminder's title and a
    notification's title, a story's title an alert rule's and a source's
    name, and other features' screens DO read ``[...]`` as Rich markup.
    That is handled where the text leaves, not here:
    ``Dreams.track_service._label`` writes those copies with square
    brackets as parentheses, and the shared notification helper shows
    runtime text with markup off. This rule still accepts brackets.

    Args:
        value: The raw text from the input widget or the config.

    Returns:
        The text to store: trimmed, without the removable invisible
        characters, every run of spaces written as one space, in NFC --
        so a composed and a decomposed spelling, and two spacings, of the
        same phrase are one stored value.

    Raises:
        ValueError: If the value is not text, has nothing readable in it,
            or breaks one of the rules above. The message names the one
            thing that was wrong, is fixed copy fit for a notice, and
            never echoes the input.
    """
    typed = value.strip() if isinstance(value, str) else ""
    if not typed:
        raise ValueError(_DREAMS_TEXT_NOTHING_READABLE)
    # Length first: nothing below may run on an unbounded paste. The raw
    # bound is generous, the real one is taken once the characters that
    # are removed anyway are gone (round 5, N6).
    if len(typed) > _DREAMS_TEXT_RAW_LENGTH_CAP:
        raise ValueError(_DREAMS_TEXT_TOO_LONG)
    typed = typed.translate(_DREAMS_TEXT_REMOVED).translate(
        _DREAMS_TEXT_BLANK_AS_SPACE).strip()
    if not typed:
        raise ValueError(_DREAMS_TEXT_NOTHING_READABLE)
    if len(typed) > _DREAMS_TEXT_PRECHECK_LENGTH:
        raise ValueError(_DREAMS_TEXT_TOO_LONG)
    text = unicodedata.normalize("NFC", typed)
    # Tag characters count only inside a well-formed flag: scan the text
    # with every such flag reduced to its base emoji.
    scanned = _DREAMS_TEXT_FLAG_SEQUENCE_RE.sub("\U0001f3f4", text)
    readable = False
    for char in scanned:
        category = unicodedata.category(char)
        if category in _DREAMS_TEXT_LINE_CATEGORIES:
            raise ValueError(_DREAMS_TEXT_NOT_ONE_LINE)
        if category == "Cs" or _is_noncharacter(char):
            raise ValueError(_DREAMS_TEXT_NOT_TEXT)
        if char in _DREAMS_TEXT_DIRECTION_CONTROLS:
            raise ValueError(_DREAMS_TEXT_HIDDEN_DIRECTION)
        if category == "Cf":
            if char not in _DREAMS_TEXT_ALLOWED_FORMAT:
                raise ValueError(_DREAMS_TEXT_HIDDEN_FORMAT)
        elif char not in _DREAMS_TEXT_BLANK and (
            # A letter, a number, an emoji or symbol, a currency sign --
            # or a code point these tables do not know (Cn) or leave to
            # the font (Co): a newer Unicode's emoji must not be
            # "unreadable" on an older Python.
            category[0] in "LN" or category in ("So", "Sc", "Cn", "Co")
        ):
            readable = True
    if not readable and not _DREAMS_TEXT_EMOJI_PRESENTATION_RE.search(text):
        raise ValueError(_DREAMS_TEXT_NOTHING_READABLE)
    # One spacing, one topic (round 5, N5): every run of spaces -- a
    # no-break, ideographic or em space, or what is left where an
    # invisible character was removed -- is stored as ONE ASCII space;
    # "rust  tui" and "rust tui" were two topics under the exact key.
    # Safe here: line breaks and controls were refused above, so only
    # spaces are whitespace now.
    text = " ".join(text.split())
    letters = sum(
        1 for char in text if not unicodedata.category(char).startswith("M"))
    if (letters > DREAMS_PROFILE_TEXT_MAX_LENGTH
            or len(text) > _DREAMS_TEXT_MAX_STORED_LENGTH):
        raise ValueError(_DREAMS_TEXT_TOO_LONG)
    return text


def validate_navigation_context_text(
    value: object,
    *,
    name: str,
    max_length: int,
) -> str:
    """Validate one bounded, single-line navigation-context string.

    Args:
        value: External navigation value to validate.
        name: Safe field label used in validation errors.
        max_length: Maximum accepted number of characters.

    Returns:
        The exact validated string without coercion or whitespace changes.

    Raises:
        ValueError: If the value is blank, unsafe, padded, or out of bounds.
    """

    if (
        type(value) is not str
        or not value
        or value != value.strip()
        or not value.isprintable()
        or not validate_text_input(
            value,
            max_length=max_length,
            allow_html=False,
        )
    ):
        raise ValueError(f"{name} is invalid")
    return value


def validate_navigation_provider_key(value: object) -> str:
    """Normalize and validate one provider key from navigation context.

    Args:
        value: External provider label or key.

    Returns:
        The normalized provider configuration key.

    Raises:
        ValueError: If the provider cannot be represented by the key contract.
    """

    from tldw_chatbook.Chat.provider_readiness import provider_config_key

    raw_provider = validate_navigation_context_text(
        value,
        name="provider",
        max_length=128,
    )
    provider = provider_config_key(raw_provider)
    allowed = "abcdefghijklmnopqrstuvwxyz0123456789_"
    if (
        not provider
        or not provider[0].isalnum()
        or any(character not in allowed for character in provider)
    ):
        raise ValueError("provider is invalid")
    return provider


def provider_api_key_validation_error(
    api_key: object,
    max_length: int = PROVIDER_API_KEY_MAX_LENGTH,
) -> Optional[str]:
    """Return a validation error for a provider API key, or None when valid.

    Args:
        api_key: User-entered provider API key. Empty values are allowed so
            optional local-key fields can represent "not configured."
        max_length: Maximum allowed key length.

    Returns:
        A user-facing validation error, or None when the value is acceptable.
    """
    key = str(api_key or "")
    if not key:
        return None

    sanitized = sanitize_string(key, max_length=max_length)
    if (
        sanitized != key
        or any(char in key for char in "\r\n\t")
        or not validate_text_input(key, max_length=max_length, allow_html=False)
    ):
        return f"API key must be a single-line value under {max_length} characters."

    from tldw_chatbook.Chat.provider_readiness import is_valid_provider_api_key

    if not is_valid_provider_api_key(key):
        return "API key looks like a placeholder; paste a real key."
    return None


def validate_provider_api_key(
    api_key: object,
    max_length: int = PROVIDER_API_KEY_MAX_LENGTH,
) -> bool:
    """Validate provider API-key input without leaking the value.

    Args:
        api_key: User-entered provider API key.
        max_length: Maximum allowed key length.

    Returns:
        True when the value is empty or a usable single-line provider key.
    """
    return provider_api_key_validation_error(api_key, max_length=max_length) is None


def validate_number_range(
    value: Union[str, int, float],
    min_val: Optional[float] = None,
    max_val: Optional[float] = None,
) -> bool:
    """Validate numeric value within range."""
    log_counter(
        "input_validation_number_range_attempt",
        labels={
            "has_min": str(min_val is not None),
            "has_max": str(max_val is not None),
        },
    )

    try:
        num_val = float(value)

        if min_val is not None and num_val < min_val:
            log_counter(
                "input_validation_number_range_invalid", labels={"reason": "below_min"}
            )
            return False

        if max_val is not None and num_val > max_val:
            log_counter(
                "input_validation_number_range_invalid", labels={"reason": "above_max"}
            )
            return False

        log_counter("input_validation_number_range_result", labels={"valid": "true"})
        return True
    except (ValueError, TypeError, OverflowError):
        # OverflowError (PR #2624 review): float(10**400) is a valid int
        # whose float conversion overflows -- a several-hundred-digit
        # limit from a model caller must be "not numeric", not a crash.
        log_counter(
            "input_validation_number_range_invalid", labels={"reason": "not_numeric"}
        )
        return False


def sanitize_string(text: str, max_length: int = 1000) -> str:
    """Sanitize string input by removing dangerous characters."""
    log_counter("input_validation_sanitize_attempt")

    if not text:
        log_counter(
            "input_validation_sanitize_result", labels={"action": "empty_input"}
        )
        return ""

    original_length = len(text)

    # Truncate if too long
    if len(text) > max_length:
        text = text[:max_length]
        log_counter(
            "input_validation_sanitize_truncated",
            labels={
                "original_length": str(original_length),
                "max_length": str(max_length),
            },
        )

    # Remove null bytes and control characters (except common whitespace)
    removed_chars = 0
    sanitized = ""
    for char in text:
        if ord(char) >= 32 or char in "\t\n\r":
            sanitized += char
        else:
            removed_chars += 1

    log_histogram("input_validation_sanitize_removed_chars", removed_chars)
    log_counter(
        "input_validation_sanitize_result",
        labels={"action": "sanitized", "had_dangerous_chars": str(removed_chars > 0)},
    )

    return sanitized


def validate_console_draft(
    draft: object, *, allow_empty: bool = False
) -> tuple[str, str | None]:
    """Validate and sanitize a Console message draft before use.

    Args:
        draft: Candidate draft value to normalize as text.
        allow_empty: Whether a blank draft is valid.

    Returns:
        A pair containing the sanitized draft and an optional user-facing
        validation error. The draft is empty when validation fails.
    """
    raw_draft = str(draft or "")
    if not raw_draft.strip():
        if allow_empty:
            return "", None
        return "", "Type a message before sending."
    if not validate_text_input(
        raw_draft,
        max_length=CONSOLE_DRAFT_MAX_LENGTH,
        allow_html=False,
    ):
        return "", "Message blocked: remove unsafe markup or shorten your message."
    clean_draft = sanitize_string(raw_draft, max_length=CONSOLE_DRAFT_MAX_LENGTH)
    if not clean_draft.strip():
        if allow_empty:
            return "", None
        return "", "Type a message before sending."
    return clean_draft, None


def validate_raw_cli_command(
    command: object,
    *,
    max_bytes: int = RAW_CLI_COMMAND_MAX_BYTES,
) -> str:
    """Validate an exact user-authored command without sanitizing it.

    Raw CLI deliberately accepts shell syntax, so this boundary checks only
    the invariants required before process execution and returns the original
    text unchanged.
    """
    if type(command) is not str or not command.strip():
        raise ValueError("raw CLI command must not be empty or whitespace")
    if "\x00" in command:
        raise ValueError("raw CLI command must not contain NUL")
    try:
        command_bytes = len(command.encode("utf-8"))
    except UnicodeEncodeError as exc:
        raise ValueError("raw CLI command must be valid UTF-8") from exc
    if command_bytes > max_bytes:
        limit_kib = max_bytes // 1024
        raise ValueError(f"raw CLI command exceeds the {limit_kib} KiB UTF-8 limit")
    return command


def validate_json_size(json_str: str, max_size: int = 1024 * 1024) -> bool:
    """Validate JSON string size."""
    log_counter("input_validation_json_size_attempt")

    if not json_str:
        log_counter(
            "input_validation_json_size_result",
            labels={"valid": "true", "empty": "true"},
        )
        return True

    size_bytes = len(json_str.encode("utf-8"))
    result = size_bytes <= max_size

    log_histogram("input_validation_json_size_bytes", size_bytes)
    log_counter(
        "input_validation_json_size_result",
        labels={"valid": str(result), "empty": "false"},
    )

    if not result:
        log_histogram("input_validation_json_oversized_bytes", size_bytes)

    return result


class ValidationError(Exception):
    """Custom exception for validation errors."""

    pass

# --------------------------------------------------------------------------
# Markup escaping
#
# TASK-32802.1. ``rich.markup.escape`` -- and ``textual.markup.escape``,
# which shares its regex -- escape only tags matching ``\[[a-z#/@]...]``.
# Textual 8 renders a ``str`` handed to a widget through
# ``Content.from_markup``, which consumes ANY ``[...]`` token, so the two
# disagree on exactly the tokens users write in titles:
#
#     Content.from_markup(rich_escape("[TODO] Q3 plan")).plain -> " Q3 plan"
#     Content.from_markup(rich_escape("[IMPORTANT]")).plain    -> ""
#
# A note called ``[TODO] Q3 plan`` lost its tag and ``[IMPORTANT]`` rendered
# as an empty row, across roughly 40 surfaces. Escaping every bracket is the
# only escape that matches this parser, and it is equally correct for Rich's
# own parser -- ``\[`` is a literal ``[`` to both, so a Rich consumer renders
# byte-identically to what ``rich.markup.escape`` gave it.
#
# The one place this is NOT right is a markup-OFF sink: a plain ``Text(...)``,
# a log line, a ``Static(..., markup=False)``. There the backslash is shown
# literally -- but that was already true of ``rich.markup.escape`` for any
# lowercase tag, so such a site is a pre-existing double-escape bug (see
# TASK-32802.4), not a reason to keep the narrow escape.
#
# First written for the Schedules results pane, where live verification lost
# a literal ``[PR-6]`` out of a real result while that pane's escaping test
# passed -- the test used ``[bold]``, the one shape rich does escape. It
# lives in this module rather than its own because the ADR-097 ``_ui_ready``
# census has no headroom for a new module and this one is already resident;
# it is also where CLAUDE.md points for sanitizing text at a boundary.
# --------------------------------------------------------------------------


def escape_markup(value: object) -> str:
    """Escape EVERY ``[`` so a Textual or Rich surface renders text literally.

    Args:
        value: Text to render literally. Coerced via ``str()``, so a
            non-string stored-JSON value is safe to pass straight in.

    Returns:
        The same text with every ``[`` backslash-escaped.
    """
    return str(value).replace("[", "\\[")


MAX_APPROVAL_DENIAL_REASON_CHARS = 1000
_DENIAL_REASON_TRUNCATION = " [reason truncated]"


def normalize_approval_denial_reason(value: object) -> str:
    """Bound untrusted denial text and remove terminal and directional controls.

    Args:
        value: Optional user text; other input shapes carry no reason.

    Returns:
        At most 1,000 characters, with an explicit note when text was truncated.
    """
    if not isinstance(value, str):
        return ""
    # Bound work before inspecting individual characters of an external payload.
    truncated = len(value) > MAX_APPROVAL_DENIAL_REASON_CHARS
    text = sanitize_string(value, MAX_APPROVAL_DENIAL_REASON_CHARS)
    text = "".join(
        character
        for character in text
        if character in "\n\t"
        or unicodedata.category(character) not in {"Cc", "Cf", "Cs"}
    ).strip()
    if truncated and text:
        text = (
            text[: MAX_APPROVAL_DENIAL_REASON_CHARS - len(_DENIAL_REASON_TRUNCATION)]
            + _DENIAL_REASON_TRUNCATION
        )
    return text
