"""
Config file encryption utilities for protecting sensitive data like API keys.

Uses AES-256-GCM encryption with scrypt key derivation for maximum security.
Provides authenticated encryption to ensure both confidentiality and integrity.
"""

import base64
import os
import secrets
import sys
from functools import lru_cache
from typing import Dict, Any

from Cryptodome.Cipher import AES
from Cryptodome.Protocol.KDF import scrypt
from loguru import logger

from tldw_chatbook.Utils.sensitive_config_keys import is_sensitive_config_key


# scrypt is deliberately expensive, and decrypt re-derives the same per-value
# key on every config load/save cycle (the salt is embedded in the ciphertext
# and stable between saves). Memoize on the full derivation input; bounded so
# per-value random salts cannot grow it without limit.
@lru_cache(maxsize=128)
def _derive_key_cached(
    password: str, salt: bytes, n: int, key_len: int, r: int, p: int
) -> bytes:
    return scrypt(password.encode("utf-8"), salt, key_len=key_len, N=n, r=r, p=p)


def unlock_recovery_value(value: str) -> str:
    """Read an encrypted config value using only an already unlocked session.

    Recovery never imports configuration bootstrap, prompts for, persists, or
    exports the password. Missing unlock is an explicit coverage failure.
    """
    owner = sys.modules.get("tldw_chatbook.config")
    password = owner.get_encryption_password() if owner is not None else None
    if not password:
        raise ValueError("credential_unlock_required")
    try:
        return ConfigEncryption().decrypt_value(value, password)
    except (ValueError, TypeError):
        raise ValueError("credential_unlock_required") from None


class ConfigEncryption:
    """Handles encryption/decryption of configuration values with authenticated encryption."""

    # Constants
    VERSION = (
        2  # v2 lowers scrypt cost; v1 remains readable for existing config values.
    )
    LEGACY_VERSION = 1
    ENCRYPTION_PREFIX = "enc:"
    SALT_SIZE = 32  # 256 bits
    KEY_SIZE = 32  # 256 bits for AES-256
    NONCE_SIZE = 12  # 96 bits for GCM
    TAG_SIZE = 16  # 128 bits for GCM

    # scrypt parameters. v1 used 2^20, which made normal config saves unusably slow.
    SCRYPT_N = 16384  # CPU/memory cost
    LEGACY_SCRYPT_N = 1048576
    SCRYPT_R = 8  # Block size
    SCRYPT_P = 1  # Parallelization

    def __init__(self):
        """Initialize the encryption module."""
        pass

    def encrypt_value(self, plaintext: str, password: str) -> str:
        """
        Encrypt a string value using AES-256-GCM with scrypt key derivation.

        Format: Base64(VERSION || SALT || NONCE || CIPHERTEXT || TAG)

        Args:
            plaintext: The string to encrypt
            password: The password to use for encryption

        Returns:
            Encrypted string with prefix
        """
        # Generate random salt and nonce
        salt = os.urandom(self.SALT_SIZE)
        nonce = os.urandom(self.NONCE_SIZE)

        key = self._derive_key(password=password, salt=salt, version=self.VERSION)

        # Create cipher and encrypt
        cipher = AES.new(key, AES.MODE_GCM, nonce=nonce)
        ciphertext, tag = cipher.encrypt_and_digest(plaintext.encode("utf-8"))

        # Build complete message
        version_bytes = bytes([self.VERSION])
        combined = version_bytes + salt + nonce + ciphertext + tag

        # Encode to base64
        encrypted_b64 = base64.b64encode(combined).decode("utf-8")

        # Return with prefix
        return f"{self.ENCRYPTION_PREFIX}{encrypted_b64}"

    def decrypt_value(
        self, encrypted_value: str, password: str, *, log_failure: bool = True
    ) -> str:
        """
        Decrypt an encrypted string value with authentication.

        Args:
            encrypted_value: The encrypted string (with or without prefix)
            password: The password to use for decryption
            log_failure: Log a failed decrypt at ERROR. ``verify_password``
                passes False: a wrong password is an expected answer there,
                and the startup prompt must not print an error between tries
                (TASK-34100.4).

        Returns:
            The decrypted string

        Raises:
            ValueError: If decryption or authentication fails
        """
        # Remove prefix if present
        if encrypted_value.startswith(self.ENCRYPTION_PREFIX):
            encrypted_value = encrypted_value[len(self.ENCRYPTION_PREFIX) :]

        try:
            # Decode from base64
            combined = base64.b64decode(encrypted_value)

            # Check minimum length
            min_length = 1 + self.SALT_SIZE + self.NONCE_SIZE + self.TAG_SIZE
            if len(combined) < min_length:
                raise ValueError("Invalid encrypted data length")

            # Extract components
            version = combined[0]
            if version not in {self.LEGACY_VERSION, self.VERSION}:
                raise ValueError(f"Unsupported encryption version: {version}")

            offset = 1
            salt = combined[offset : offset + self.SALT_SIZE]
            offset += self.SALT_SIZE

            nonce = combined[offset : offset + self.NONCE_SIZE]
            offset += self.NONCE_SIZE

            # Ciphertext is everything except the last TAG_SIZE bytes
            ciphertext = combined[offset : -self.TAG_SIZE]
            tag = combined[-self.TAG_SIZE :]

            key = self._derive_key(password=password, salt=salt, version=version)

            # Create cipher and decrypt
            cipher = AES.new(key, AES.MODE_GCM, nonce=nonce)
            plaintext = cipher.decrypt_and_verify(ciphertext, tag)

            return plaintext.decode("utf-8")

        except Exception as e:
            if log_failure:
                logger.error(f"Decryption failed: {type(e).__name__}")
            raise ValueError(
                "Failed to decrypt value. Invalid password or corrupted data."
            )

    def _derive_key(self, *, password: str, salt: bytes, version: int) -> bytes:
        n = self.LEGACY_SCRYPT_N if version == self.LEGACY_VERSION else self.SCRYPT_N
        return _derive_key_cached(
            password,
            salt,
            n,
            self.KEY_SIZE,
            self.SCRYPT_R,
            self.SCRYPT_P,
        )

    @staticmethod
    def clear_derived_key_cache() -> None:
        """Drop memoized scrypt keys; call when the master password changes."""
        _derive_key_cached.cache_clear()

    def is_encrypted(self, value: str) -> bool:
        """Check if a value is encrypted based on its prefix."""
        return isinstance(value, str) and value.startswith(self.ENCRYPTION_PREFIX)

    def encrypt_config(self, config: Dict[str, Any], password: str) -> Dict[str, Any]:
        """
        Encrypt all string values in a configuration dictionary.

        Args:
            config: Dictionary of configuration values
            password: Password to use for encryption

        Returns:
            Dictionary with encrypted values
        """
        encrypted_config = {}

        for key, value in config.items():
            if isinstance(value, str) and value and not self.is_encrypted(value):
                # Encrypt non-empty strings that aren't already encrypted
                encrypted_config[key] = self.encrypt_value(value, password)
            elif isinstance(value, dict):
                # Recursively encrypt nested dictionaries
                encrypted_config[key] = self.encrypt_config(value, password)
            else:
                # Keep non-string values as-is
                encrypted_config[key] = value

        return encrypted_config

    def decrypt_config(self, config: Dict[str, Any], password: str) -> Dict[str, Any]:
        """
        Decrypt all encrypted values in a configuration dictionary.

        Args:
            config: Dictionary with potentially encrypted values
            password: Password to use for decryption

        Returns:
            Dictionary with decrypted values
        """
        return self._decrypt_config(config, password, strict=False)

    def decrypt_config_strict(
        self, config: Dict[str, Any], password: str, *, log_failure: bool = True
    ) -> Dict[str, Any]:
        """Decrypt a configuration dictionary, failing on any invalid value.

        Args:
            config: Dictionary with potentially encrypted values.
            password: Password to use for decryption.
            log_failure: Log a failed decrypt at ERROR. The startup unlock
                passes False: a value that does not decrypt is an answer it
                reports to the user, not an error to print between prompts
                (TASK-34100.4).

        Returns:
            Dictionary with decrypted values.

        Raises:
            ValueError: If any encrypted value cannot be decrypted.
        """
        return self._decrypt_config(
            config, password, strict=True, log_failure=log_failure
        )

    def _decrypt_config(
        self,
        config: Dict[str, Any],
        password: str,
        *,
        strict: bool,
        log_failure: bool = True,
    ) -> Dict[str, Any]:
        decrypted_config: Dict[str, Any] = {}

        for key, value in config.items():
            if self.is_encrypted(value):
                try:
                    decrypted_config[key] = self.decrypt_value(
                        value, password, log_failure=log_failure
                    )
                except ValueError:
                    if strict:
                        raise
                    logger.warning(f"Failed to decrypt value for key: {key}")
                    decrypted_config[key] = value  # Keep encrypted on failure
            elif isinstance(value, dict):
                # Recursively decrypt nested dictionaries
                decrypted_config[key] = self._decrypt_config(
                    value,
                    password,
                    strict=strict,
                    log_failure=log_failure,
                )
            else:
                # Keep non-encrypted values as-is
                decrypted_config[key] = value

        return decrypted_config

    def create_password_verifier(self, password: str) -> str:
        """
        Create an encrypted test value for password verification.

        Args:
            password: The password to verify later

        Returns:
            Encrypted verification token
        """
        # Use a known test string with timestamp for uniqueness
        test_value = f"PASSWORD_VERIFICATION_TOKEN_{secrets.token_hex(16)}"
        return self.encrypt_value(test_value, password)

    def verify_password(self, password: str, verifier: str) -> bool:
        """
        Verify a password by attempting to decrypt a verification token.

        Args:
            password: The password to verify
            verifier: The encrypted verification token

        Returns:
            True if password is correct, False otherwise
        """
        try:
            decrypted = self.decrypt_value(verifier, password, log_failure=False)
            # Check if it's a valid verification token
            return decrypted.startswith("PASSWORD_VERIFICATION_TOKEN_")
        except ValueError:
            return False

    def detect_api_keys(self, config: Dict[str, Any]) -> bool:
        """
        Detect if there are API keys in the configuration that should be encrypted.

        Uses the same sensitive-key predicate as every other
        encryption/redaction/reporting path in the app (see
        ``Utils/sensitive_config_keys.py``), so a config full of real
        provider keys (``openai_api_key``, ``bing_search_api_key``,
        ``OPENAI_API_KEY_fallback``, ...) is detected, not just configs using
        the six bare literal names this used to match exactly.

        Args:
            config: Configuration dictionary to check

        Returns:
            True if unencrypted API keys are found
        """

        def check_dict_for_keys(d: Dict[str, Any], parent_key: str = "") -> bool:
            for key, value in d.items():
                full_key = f"{parent_key}.{key}" if parent_key else key

                # Check for API key patterns
                if is_sensitive_config_key(key):
                    if (
                        isinstance(value, str)
                        and value.strip()
                        and not self.is_encrypted(value)
                    ):
                        # Skip placeholders
                        if not (value.startswith("<") and value.endswith(">")):
                            return True

                # Check nested dictionaries
                if isinstance(value, dict):
                    if check_dict_for_keys(value, full_key):
                        return True

            return False

        return check_dict_for_keys(config)


# Global instance for convenience
config_encryption = ConfigEncryption()
