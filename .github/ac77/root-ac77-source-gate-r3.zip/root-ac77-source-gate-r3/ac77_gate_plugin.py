"""Unexecuted finite reader around the six original AC77 TEST cases."""

import hashlib
import importlib
import json
import os
import sys
from pathlib import Path

import pytest

from ac77_source_gate import Gate, HERE


_MODULE = "Tests.Backup_Recovery.test_config_companion_missing_record_evidence"
_CASES = (
    "test_warm_missing_profile_skips_records_but_keeps_two_actual_leases",
    "test_pending_publication_refuses_without_body_or_new_leases",
    "test_real_profile_enrollment_waits_for_old_hold_then_uses_new_companion_guard",
    "test_valid_shaped_profile_insertion_after_first_acquire_keeps_scope_mismatch_refusal",
    "test_changed_records_callback_keeps_the_original_missing_profile_route[replacement]",
    "test_changed_records_callback_keeps_the_original_missing_profile_route[body]",
)


def pytest_collection_modifyitems(items):
    assert tuple(item.name for item in items) == _CASES
    assert all(item.module.__name__ == _MODULE for item in items)


def pytest_addoption(parser):
    parser.addoption("--ac77-installed-root", required=True)
    parser.addoption("--ac77-archive", required=True)
    parser.addoption("--ac77-runtime-binding", required=True)


def _write(path, value):
    with path.open("x", encoding="utf-8") as output:
        json.dump(value, output, indent=2)
        output.write("\n")


class Observation:
    def __init__(self, item):
        self.item = item
        archive = Path(item.config.getoption("--ac77-archive")).resolve()
        self.output = archive / hashlib.sha256(item.nodeid.encode()).hexdigest()[:20]
        self.output.mkdir(parents=True, exist_ok=False)
        runtime = json.loads(Path(item.config.getoption("--ac77-runtime-binding")).read_text())
        self.gate = Gate(item.config.getoption("--ac77-installed-root"), runtime, pytest_config=item.config)
        self.errors, self.reloads, self.reports = [], [], []
        self.codes, self.registered, self.holds, self.leases = {}, {}, {}, {}
        self.tool = None
        self.data = []

    def start(self):
        # The selected original module already imports these TEST helpers.
        support = importlib.import_module("Tests.Backup_Recovery.config_test_support")
        fixtures = importlib.import_module("Tests.Backup_Recovery.test_participant_lifetimes")
        self.gate.loaded()
        root_body = vars(fixtures.local_root)["__wrapped__"]
        assert id(root_body) in self.gate.functions
        storage = sys.modules["tldw_chatbook.Backup_Recovery.storage_admission"]
        self.codes = {
            support.install_config_source.__code__: "config",
            root_body.__code__: "fixture",
            storage._Hold.__init__.__code__: "hold",
            storage._Hold._run.__code__: "worker",
            storage.StorageLease.__init__.__code__: "lease",
            storage.StorageLease.close.__code__: "close",
        }
        document = json.loads((HERE / "expected-sources.json").read_text())
        for row in document["data_sources"]:
            path = self.gate.root / row["logical_path"]
            data = (HERE / row["snapshot_path"]).read_bytes()
            assert hashlib.sha256(data).hexdigest() == row["sha256"]
            assert path.read_bytes() == data
            self.data.append((path, data))
        monitor = sys.monitoring
        for number in range(5, 0, -1):
            if number == monitor.DEBUGGER_ID:
                continue
            try:
                monitor.use_tool_id(number, "ac77-source-reader")
            except ValueError:
                continue
            self.tool = number
            break
        assert self.tool is not None
        for event, callback in (
            (monitor.events.PY_RETURN, self.returned),
            (monitor.events.PY_YIELD, self.yielded),
            (monitor.events.PY_START, self.started),
            (monitor.events.PY_UNWIND, self.unwound),
        ):
            previous = monitor.register_callback(self.tool, event, callback)
            if previous is not None:
                monitor.register_callback(self.tool, event, previous)
                raise AssertionError("monitor callback already owned")
            self.registered[event] = callback
        assert monitor.get_events(self.tool) == 0
        for code, kind in self.codes.items():
            events = monitor.events.PY_YIELD if kind == "fixture" else monitor.events.PY_RETURN
            if kind == "worker":
                events |= monitor.events.PY_START
            monitor.set_local_events(self.tool, code, events)
        monitor.set_events(self.tool, monitor.events.PY_UNWIND)

    def frame(self, code):
        frame = sys._getframe(1)
        for _ in range(8):
            if frame is None:
                break
            if frame.f_code is code:
                return frame
            frame = frame.f_back
        raise AssertionError("original frame absent")

    def error(self, event, error):
        self.errors.append({"event": event, "type": type(error).__name__})

    def root_key(self):
        binding = self.gate.fixture_binding
        return None if binding is None else (os.getpid(), str(binding[2]))

    def hold(self, value):
        if value.key != self.root_key():
            return None
        if id(value) not in self.holds:
            assert len(self.holds) < 8
            self.holds[id(value)] = {
                "hold": value, "thread": value.thread, "authority": value.authority,
                "worker_started": False, "worker_returned": False, "worker_unwind": None,
            }
        row = self.holds[id(value)]
        assert row["thread"] is value.thread and row["authority"] is value.authority
        return row

    def yielded(self, code, offset, value):
        try:
            assert self.codes[code] == "fixture"
            frame = self.frame(code)
            assert frame.f_locals["root"] is value
            bootstrap = frame.f_locals["bootstrap"]
            assert bootstrap is sys.modules["tldw_chatbook.Backup_Recovery.bootstrap"]
            callback = vars(bootstrap)["default_bootstrap_root"]
            self.gate.fixture_binding = bootstrap, callback, value
            self.gate.pin(callback)
        except BaseException as error:
            self.error("fixture-yield", error)

    def started(self, code, offset):
        try:
            assert self.codes[code] == "worker"
            frame = self.frame(code)
            value = frame.f_locals["self"]
            row = self.hold(value)
            if row is not None:
                storage = sys.modules["tldw_chatbook.Backup_Recovery.storage_admission"]
                assert storage.threading.current_thread() is row["thread"]
                assert frame.f_locals["authority"] is row["authority"]
                row["worker_started"] = True
        except BaseException as error:
            self.error("worker-start", error)

    def returned(self, code, offset, value):
        try:
            kind = self.codes[code]
            if kind == "config":
                assert value is sys.modules["tldw_chatbook.config"] is vars(sys.modules["tldw_chatbook"])["config"]
                self.gate.loaded()
                self.reloads.append(self.gate.receipt())
                return
            frame = self.frame(code)
            owner = frame.f_locals["self"]
            if kind in {"worker", "hold"}:
                row = self.hold(owner)
                if row is not None and kind == "worker":
                    row["worker_returned"] = True
            elif kind == "lease" and self.root_key() is not None and owner._key == self.root_key():
                assert len(self.leases) < 256
                self.leases[id(owner)] = owner
            elif kind == "close" and id(owner) in self.leases:
                storage = sys.modules["tldw_chatbook.Backup_Recovery.storage_admission"]
                assert owner._key is None and owner not in storage._live_leases
        except BaseException as error:
            self.error("return", error)

    def unwound(self, code, offset, error):
        if self.codes.get(code) != "worker":
            return
        try:
            assert self.codes[code] == "worker"
            row = self.hold(self.frame(code).f_locals["self"])
            if row is not None:
                row["worker_unwind"] = type(error).__name__
        except BaseException as observer_error:
            self.error("worker-unwind", observer_error)

    def close(self):
        try:
            if self.tool is not None:
                monitor = sys.monitoring
                safe = True
                try:
                    monitor.set_events(self.tool, 0)
                except BaseException as error:
                    safe = False
                    self.error("disable-global", error)
                for code in self.codes:
                    try:
                        monitor.set_local_events(self.tool, code, 0)
                    except BaseException as error:
                        safe = False
                        self.error("disable", error)
                for event, callback in self.registered.items():
                    try:
                        previous = monitor.register_callback(self.tool, event, None)
                        if previous is not callback:
                            monitor.register_callback(self.tool, event, previous)
                            raise AssertionError("callback changed")
                    except BaseException as error:
                        safe = False
                        self.error("unregister", error)
                try:
                    assert safe and monitor.get_events(self.tool) == 0
                    assert monitor.get_tool(self.tool) == "ac77-source-reader"
                    monitor.free_tool_id(self.tool)
                    self.tool = None
                except BaseException as error:
                    self.error("free", error)
        finally:
            try:
                self.gate.unchanged()
                assert all(path.read_bytes() == data for path, data in self.data)
                if any(row["when"] == "setup" and row["outcome"] == "passed" for row in self.reports):
                    assert self.reloads and self.gate.fixture_binding is not None
                    assert self.holds and self.leases, "actual fixture owners were not observed"
                storage = sys.modules["tldw_chatbook.Backup_Recovery.storage_admission"]
                for row in self.holds.values():
                    hold, thread = row["hold"], row["thread"]
                    assert hold.stop.is_set() and not thread.is_alive()
                    assert storage._holds.get(hold.key) is not hold
                    assert hold not in storage._retiring_holds
                    assert row["worker_started"] and row["worker_returned"]
                    assert row["worker_unwind"] is None
                assert all(lease._key is None and lease not in storage._live_leases for lease in self.leases.values())
            except BaseException as error:
                self.error("final-source-and-owned-cleanup", error)
            _write(self.output / "gate.json", {
                "nodeid": self.item.nodeid, "gate": self.gate.receipt(),
                "fresh_config_returns": len(self.reloads), "reports": self.reports,
                "owned_holds": [
                    {"identity": id(row["hold"]), "thread_identity": id(row["thread"]),
                     "authority_identity": id(row["authority"]),
                     "worker_started": row["worker_started"], "worker_returned": row["worker_returned"],
                     "worker_unwind": row["worker_unwind"],
                     "stop_set": row["hold"].stop.is_set(), "thread_alive": row["thread"].is_alive()}
                    for row in self.holds.values()
                ],
                "owned_leases": [{"identity": id(value), "key_retired": value._key is None} for value in self.leases.values()],
                "children": [], "child_scope": "The six original cases create no subprocess; ROOT's external runner needs its own exit/reap receipt.",
                "observer_errors": self.errors,
                "native_closure_scope": "Original native assertions and exact fixture-owned holder return/join only; no borrowed/global owner claim.",
            })
        assert not self.errors, self.errors


@pytest.hookimpl(hookwrapper=True, tryfirst=True)
def pytest_runtest_setup(item):
    observed = Observation(item)
    item._ac77_observation = observed
    try:
        observed.start()
    except BaseException as primary:
        try:
            observed.close()
        except BaseException as cleanup:
            primary.add_note("AC77 reader cleanup: " + type(cleanup).__name__)
        item._ac77_observation = None
        raise
    yield


@pytest.hookimpl(hookwrapper=True)
def pytest_runtest_makereport(item, call):
    outcome = yield
    report = outcome.get_result()
    observed = getattr(item, "_ac77_observation", None)
    if observed is not None:
        observed.reports.append({"when": report.when, "outcome": report.outcome})


@pytest.hookimpl(hookwrapper=True, tryfirst=True)
def pytest_runtest_teardown(item, nextitem):
    yield
    observed = getattr(item, "_ac77_observation", None)
    if observed is not None:
        observed.close()
