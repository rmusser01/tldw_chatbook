"""Schema-versioned permission store for the MCP Hub (Permissions mode, Phase 4).

Persists chatbook's client-side tool-permission gate: a global kill switch, a
global default state, and per-server / per-tool overrides, keyed
``<source>:<server_id>`` for servers and ``<tool_name>`` within a server for
tools. See ``Docs/superpowers/specs/2026-07-13-mcp-hub-redesign-design.md``
§9 for the product model (precedence: tool override -> server default ->
global default; absence of a key = "Inherit").

Store shape (spec-verbatim)::

    {
      "schema_version": 1,
      "kill_switch": false,
      "profiles": {
        "default": {
          "global_default": "ask",
          "servers": {
            "<source>:<server_id>": {
              "default": "ask",
              "tools": {
                "<tool_name>": {"state": "allow|ask|deny", "definition_hash": "..."}
              }
            }
          }
        }
      }
    }

Atomic writes mirror ``LocalMCPStore.save()`` (``local_store.py``): a
``.tmp`` sibling file is written first (``json.dump(..., indent=2,
sort_keys=True)``) and then atomically renamed onto the real path via
``Path.replace()``; ``updated_at`` is stamped with an ISO-UTC timestamp on
every save.

Named permission profiles (workspace assistant defaults): the ``profiles``
dict carries any number of additional profiles alongside ``default``.
Every mutator and resolver takes a keyword ``profile_id`` (default
``"default"`` -- byte-identical to the single-profile behavior). Resolvers
walk the named profile's precedence levels first and fall through to the
default profile only for levels the named profile leaves unset, so a fresh
empty named profile (``{"servers": {}}``, no ``global_default`` key)
resolves exactly like the default profile alone. Kill switch and
``schema_version`` stay global; the shape change is additive, so
``SCHEMA_VERSION`` stays 1.

Corruption policy — deliberate divergence from ``LocalMCPStore``: local_store
raises ``LocalMCPStoreLoadError`` on an unreadable/corrupt file, forcing the
caller to handle it. Per spec §9 ("unknown schema version -> back up file and
start fresh, never crash"), this store never raises out of ``load()``: a
missing file returns a fresh default payload; a corrupt/non-JSON file, a
JSON payload that is not a dict, or one whose ``schema_version`` does not
match ``SCHEMA_VERSION`` is renamed to ``<name>.bak`` (replacing any prior
backup), a warning is logged, and a fresh default payload is returned. The
original path stays absent until the next ``save()``.

This module intentionally implements only the storage primitive (Task 1 of
the Phase 4 plan). Effective-state resolution (precedence walk, rug-pull
definition-hash comparison, cycle-safety) is Task 2 and lives in this same
module as pure functions layered on top of ``MCPPermissionStore`` — nothing
here should need to change to accommodate them.
"""

from __future__ import annotations

import errno
import hashlib
import fnmatch
import json
import sys
import os
import re
import tempfile
import threading
from contextlib import contextmanager
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path
from types import FunctionType, MappingProxyType
from typing import Any, Callable, Iterator, Literal, Mapping

from loguru import logger

from tldw_chatbook.Backup_Recovery import mcp_source_participants as mcp_sources

from tldw_chatbook.MCP.hub_tool_catalog import HubTool

SCHEMA_VERSION = 1
STORE_STATES: tuple[str, ...] = ("allow", "ask", "deny")
DEFAULT_GLOBAL = "ask"
#: Sentinel key set only by _fail_closed_payload() to mark a store whose
#: policy file could not be READ; raw getters deny on it (TASK-32806.3).
_UNREADABLE_MARKER = "__unreadable__"
HIGH_RISK_TAGS = frozenset({"mutates", "process"})
#: Risk tags that floor an INHERITED ``allow`` to ``ask`` for in-process
#: built-ins. A superset of ``HIGH_RISK_TAGS``: built-ins additionally
#: treat filesystem reads as prompt-worthy, because an agent reading
#: arbitrary sandbox files is a disclosure risk even though it mutates
#: nothing, and treat network egress as prompt-worthy too, because egress
#: is the exfiltration leg of a prompt-injection chain. MCP deliberately
#: keeps ``HIGH_RISK_TAGS``. TASK-845 asked whether ``network`` should move
#: to the shared set and resolved NO, on evidence rather than preference:
#: an MCP tool's tags are not ours, they are derived from the remote
#: server's own payload -- ``risk_class`` plus a free-form ``capabilities``
#: list, lowercased (``MCP.hub_tool_catalog._extra_tags``). "network" is an
#: ordinary word for a server to list among its capabilities, so widening
#: the shared set would not be the no-op it looks like: it would start
#: prompting on real servers because of a string they chose for unrelated
#: reasons. The built-in set is a vocabulary WE control and can reason
#: about; the shared set is partly server-supplied and should stay narrow.
BUILTIN_HIGH_RISK_TAGS = HIGH_RISK_TAGS | frozenset({"reads", "network"})
#: ``(server_key, tool_name)`` pairs floored to ``ask`` even under an
#: EXPLICIT tool-level ``allow`` -- every call raises an approval card.
#: TASK-32956: the Console's ``character_save`` rewrites a user's character
#: card, and the Character Creator promise is "every save asks" (TASK-32954
#: spec). Its Hub row exists so the two reads can be set to Allow; an Allow
#: on the save shows as floored Ask instead of silently skipping the card.
ALWAYS_ASK_TOOLS = frozenset({("local:__local__", "character_save")})

_DEFAULT_PROFILE_ID = "default"
_SHA256_RE = re.compile(r"[0-9a-f]{64}\Z")
_RECEIPT_ID_RE = re.compile(r"tp-[0-9a-f]{32}\Z")
_UTC_TIMESTAMP_RE = re.compile(
    r"\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}(?:\.\d+)?Z\Z"
)
_LIFECYCLE_SCHEMA = "tldw.tool-pack-lifecycle/v1"

ProfileLifecycleDisposition = Literal["legacy", "imported", "tombstone", "invalid"]

_PATH_LOCKS_GUARD = threading.Lock()
_PATH_LOCKS: dict[Path, threading.RLock] = {}
_UNSUPPORTED_DIRECTORY_FSYNC_ERRNOS = frozenset(
    {
        errno.EINVAL,
        errno.ENOSYS,
        getattr(errno, "ENOTSUP", errno.EINVAL),
        getattr(errno, "EOPNOTSUPP", errno.EINVAL),
    }
)


@dataclass(frozen=True)
class ProfileMutationResult:
    """Identity returned after one complete profile authority mutation."""

    profile_id: str
    revision: int
    policy_digest: str
    store_generation: str


class ProfileMutationError(ValueError):
    """A complete or profile-scoped policy mutation was rejected."""

    def __init__(self, category: str) -> None:
        super().__init__(category)
        self.category = category


def _canonical_json_value(value: Any) -> Any:
    """Copy frozen or ordinary JSON containers into canonicalizable values."""
    if isinstance(value, Mapping):
        return {key: _canonical_json_value(item) for key, item in value.items()}
    if isinstance(value, (list, tuple)):
        return [_canonical_json_value(item) for item in value]
    return value


def profile_policy_digest(profile: Mapping[str, Any]) -> str:
    """Hash canonical policy fields while excluding lifecycle metadata.

    The profile kind remains covered because it changes the runtime meaning of
    otherwise identical policy. Lifecycle revision/provenance and the store's
    top-level timestamp are deliberately outside this identity.
    """
    policy: dict[str, Any] = {
        "servers": _canonical_json_value(profile.get("servers", {})),
    }
    if "global_default" in profile:
        policy["global_default"] = _canonical_json_value(profile["global_default"])
    if "profile_kind" in profile:
        policy["profile_kind"] = _canonical_json_value(profile["profile_kind"])
    canonical = json.dumps(
        policy,
        ensure_ascii=False,
        sort_keys=True,
        separators=(",", ":"),
        allow_nan=False,
    ).encode("utf-8")
    return hashlib.sha256(canonical).hexdigest()


def _resolved_path_lock(path: Path) -> threading.RLock:
    """Return the one process-wide reentrant lock for ``path``."""
    resolved = path.expanduser().resolve(strict=False)
    with _PATH_LOCKS_GUARD:
        return _PATH_LOCKS.setdefault(resolved, threading.RLock())


def _fsync_parent_directory(path: Path) -> None:
    """Fsync ``path`` or tolerate only an explicitly unsupported operation."""
    if os.name == "nt":
        from tldw_chatbook.Utils.file_durability import flush_directory
        from tldw_chatbook.Utils.platform_files import os as native_os

        parent_fd = native_os.open(
            path, native_os.O_RDONLY | native_os.O_DIRECTORY | native_os.O_NOFOLLOW
        )
        try:
            flush_directory(parent_fd)
        finally:
            native_os.close(parent_fd)
        return
    try:
        parent_fd = os.open(path, os.O_RDONLY)
    except OSError as exc:
        if exc.errno in _UNSUPPORTED_DIRECTORY_FSYNC_ERRNOS:
            return
        raise
    try:
        try:
            os.fsync(parent_fd)
        except OSError as exc:
            if exc.errno not in _UNSUPPORTED_DIRECTORY_FSYNC_ERRNOS:
                raise
    finally:
        os.close(parent_fd)


@dataclass(frozen=True)
class PermissionStoreSnapshot:
    """Immutable permission-store bytes admitted by strict schema validation."""

    payload: Mapping[str, Any]
    generation: str
    file_exists: bool


class PermissionStoreSnapshotError(ValueError):
    """A strict permission-store snapshot could not be read safely."""

    def __init__(self, category: str) -> None:
        super().__init__(category)
        self.category = category


def _iso_utc_now() -> str:
    return datetime.now(timezone.utc).isoformat().replace("+00:00", "Z")


def _fresh_payload() -> dict[str, Any]:
    return {
        "schema_version": SCHEMA_VERSION,
        "kill_switch": False,
        "profiles": {
            _DEFAULT_PROFILE_ID: {
                "global_default": DEFAULT_GLOBAL,
                "servers": {},
            }
        },
    }


def _fail_closed_payload() -> dict[str, Any]:
    """The payload to show when the real one could not be READ.

    TASK-32806.3. Not ``_fresh_payload()``: that is the permissive
    first-run default (kill switch off, global default ``ask``), and
    returning it for an unreadable file tells the user the opposite of
    what their policy says. A read failure is an absence of knowledge, so
    this denies everything until the file can be read again. Nothing
    persists it -- only the raw display getters use it.
    """
    return {
        "schema_version": SCHEMA_VERSION,
        "kill_switch": True,
        # TASK-32806.3 / Qodo #3: an explicit "could not read" marker. The
        # raw display getters deny for ANY profile on this state, not just
        # the default one -- a named profile is absent from a static
        # fallback and would otherwise fall through to DEFAULT_GLOBAL ("ask").
        _UNREADABLE_MARKER: True,
        "profiles": {
            _DEFAULT_PROFILE_ID: {
                "global_default": "off",
                "servers": {},
            }
        },
    }


def _is_sha256(value: Any) -> bool:
    return isinstance(value, str) and _SHA256_RE.fullmatch(value) is not None


def _is_positive_int(value: Any) -> bool:
    return isinstance(value, int) and not isinstance(value, bool) and value > 0


def _is_nonnegative_int(value: Any) -> bool:
    return isinstance(value, int) and not isinstance(value, bool) and value >= 0


def _is_utc_timestamp(value: Any) -> bool:
    """Return whether ``value`` is a valid UTC ISO-8601 timestamp."""
    if not isinstance(value, str) or _UTC_TIMESTAMP_RE.fullmatch(value) is None:
        return False
    try:
        datetime.fromisoformat(value.removesuffix("Z") + "+00:00")
    except ValueError:
        return False
    return True


def _has_exact_keys(value: Mapping[str, Any], keys: frozenset[str]) -> bool:
    return set(value) == keys


def profile_lifecycle_disposition(
    profile: Mapping[str, Any],
) -> ProfileLifecycleDisposition:
    """Classify the authoritative lifecycle pair carried by ``profile``.

    Legacy profiles carry neither ``profile_kind`` nor ``tool_pack_lifecycle``.
    Either field alone, an unknown discriminator, or a malformed exact lifecycle
    variant is invalid rather than silently inheriting as a local profile.
    """
    has_kind = "profile_kind" in profile
    has_lifecycle = "tool_pack_lifecycle" in profile
    if not has_kind and not has_lifecycle:
        return "legacy"
    if not has_kind or not has_lifecycle:
        return "invalid"

    kind = profile.get("profile_kind")
    lifecycle = profile.get("tool_pack_lifecycle")
    if not isinstance(lifecycle, Mapping):
        return "invalid"

    common_keys = frozenset(
        {
            "schema",
            "origin",
            "pack_digest",
            "imported_at",
            "first_bind_confirmation_required",
            "receipt_id",
            "receipt_digest",
            "policy_digest",
            "revision",
        }
    )
    if kind == "tool_pack_imported":
        expected_keys = common_keys | {"counts"}
        if (
            not _has_exact_keys(lifecycle, expected_keys)
            or lifecycle.get("schema") != _LIFECYCLE_SCHEMA
            or lifecycle.get("origin") != "imported"
            or not _is_sha256(lifecycle.get("pack_digest"))
            or not _is_utc_timestamp(lifecycle.get("imported_at"))
            or not isinstance(lifecycle.get("first_bind_confirmation_required"), bool)
            or not isinstance(lifecycle.get("receipt_id"), str)
            or _RECEIPT_ID_RE.fullmatch(lifecycle["receipt_id"]) is None
            or not _is_sha256(lifecycle.get("receipt_digest"))
            or not _is_sha256(lifecycle.get("policy_digest"))
            or not _is_positive_int(lifecycle.get("revision"))
        ):
            return "invalid"
        counts = lifecycle.get("counts")
        if not isinstance(counts, Mapping) or not _has_exact_keys(
            counts, frozenset({"matched", "omitted", "pending_deny"})
        ):
            return "invalid"
        if not all(_is_nonnegative_int(counts[key]) for key in counts):
            return "invalid"
        return "imported"

    if kind == "tool_pack_tombstone":
        if (
            not _has_exact_keys(lifecycle, common_keys | {"removed_at"})
            or lifecycle.get("schema") != _LIFECYCLE_SCHEMA
            or lifecycle.get("origin") != "tombstone"
            or not _is_sha256(lifecycle.get("pack_digest"))
            or not _is_utc_timestamp(lifecycle.get("imported_at"))
            or not _is_utc_timestamp(lifecycle.get("removed_at"))
            or lifecycle.get("first_bind_confirmation_required") is not False
            or not isinstance(lifecycle.get("receipt_id"), str)
            or _RECEIPT_ID_RE.fullmatch(lifecycle["receipt_id"]) is None
            or not _is_sha256(lifecycle.get("receipt_digest"))
            or not _is_sha256(lifecycle.get("policy_digest"))
            or not _is_positive_int(lifecycle.get("revision"))
        ):
            return "invalid"
        return "tombstone"

    return "invalid"


def _freeze_snapshot(value: Any) -> Any:
    """Recursively freeze a JSON value without sharing mutable containers."""
    if isinstance(value, Mapping):
        return MappingProxyType({key: _freeze_snapshot(item) for key, item in value.items()})
    if isinstance(value, list):
        return tuple(_freeze_snapshot(item) for item in value)
    return value


def _thaw_snapshot(value: Any) -> Any:
    """Recursively copy a frozen snapshot into ordinary JSON containers."""
    if isinstance(value, Mapping):
        return {key: _thaw_snapshot(item) for key, item in value.items()}
    if isinstance(value, tuple):
        return [_thaw_snapshot(item) for item in value]
    return value


def _projected_store_size(payload: Mapping[str, Any]) -> int:
    """Return the bytes written by the canonical permission-store writer."""
    projected = _thaw_snapshot(payload)
    projected["updated_at"] = _iso_utc_now()
    return len(json.dumps(projected, indent=2, sort_keys=True).encode("utf-8"))


def _profile_has_permissive_policy(profile: Mapping[str, Any]) -> bool:
    """Return whether a tombstone candidate carries any Allow/Ask posture."""
    if profile.get("global_default") in {"allow", "ask"}:
        return True
    for server in _as_mapping(profile.get("servers")).values():
        if not isinstance(server, Mapping):
            continue
        if server.get("default") in {"allow", "ask"}:
            return True
        for tool in _as_mapping(server.get("tools")).values():
            if isinstance(tool, Mapping) and tool.get("state") in {"allow", "ask"}:
                return True
    return False


def _reject_duplicate_keys(pairs: list[tuple[str, Any]]) -> dict[str, Any]:
    """Build one JSON object, failing closed when a key appears twice."""
    result: dict[str, Any] = {}
    for key, value in pairs:
        if key in result:
            raise PermissionStoreSnapshotError("duplicate_key")
        result[key] = value
    return result


def _reject_json_constant(value: str) -> None:
    raise PermissionStoreSnapshotError("invalid_json")


def _validate_strict_profile(profile: Mapping[str, Any], *, is_default: bool) -> bool:
    allowed_keys = {"global_default", "servers", "profile_kind", "tool_pack_lifecycle"}
    if not set(profile).issubset(allowed_keys) or not isinstance(profile.get("servers"), Mapping):
        return False
    if is_default and "global_default" not in profile:
        return False
    if "global_default" in profile and profile["global_default"] not in STORE_STATES:
        return False
    if profile_lifecycle_disposition(profile) == "invalid":
        return False

    for server_key, server_entry in profile["servers"].items():
        if not isinstance(server_key, str) or not server_key or not isinstance(server_entry, Mapping):
            return False
        if not set(server_entry).issubset({"default", "tools"}):
            return False
        if "default" in server_entry and server_entry["default"] not in STORE_STATES:
            return False
        if "tools" not in server_entry:
            continue
        tools = server_entry["tools"]
        if not isinstance(tools, Mapping):
            return False
        for tool_name, tool_entry in tools.items():
            if not isinstance(tool_name, str) or not tool_name or not isinstance(tool_entry, Mapping):
                return False
            # task-32281: `arg_rules` (task-26012's `add_tool_arg_rule()`
            # writer) is a legitimate tool-entry key that carries no
            # `state` at all -- an exact-input allow rule with no
            # whole-tool override. Previously ANY such entry (every one
            # `add_tool_arg_rule()` has ever written on its own) failed
            # this check outright, since `"state"` used to be mandatory --
            # that silently invalidated the WHOLE profile for
            # `read_snapshot_strict()`/`read_profile_inventory_snapshot()`
            # callers (e.g. the Permissions-mode profile selector) the
            # moment a user ever used the "Always allow this exact input"
            # card option without also setting a whole-tool Allow/Ask/Off.
            if not set(tool_entry).issubset(
                {"state", "definition_hash", "config_changed", "arg_rules"}
            ):
                return False
            has_state = "state" in tool_entry
            if has_state and tool_entry["state"] not in STORE_STATES:
                return False
            if "arg_rules" in tool_entry and (
                not isinstance(tool_entry["arg_rules"], list)
                or not tool_entry["arg_rules"]
            ):
                return False
            if not has_state and "arg_rules" not in tool_entry:
                return False
            if "definition_hash" in tool_entry:
                if not has_state:
                    return False
                stored_hash = tool_entry["definition_hash"]
                legacy_hash_free_null = (
                    server_key in HASH_FREE_SERVER_KEYS
                    and tool_entry["state"] == "allow"
                    and stored_hash is None
                )
                if not legacy_hash_free_null and not _is_sha256(stored_hash):
                    return False
            if "config_changed" in tool_entry and (
                not has_state or not isinstance(tool_entry["config_changed"], bool)
            ):
                return False
            if (
                has_state
                and tool_entry["state"] == "allow"
                and server_key not in HASH_FREE_SERVER_KEYS
                and "definition_hash" not in tool_entry
            ):
                return False
    return True


def _validate_strict_payload(payload: Any) -> bool:
    if not isinstance(payload, Mapping) or set(payload) - {
        "schema_version", "kill_switch", "profiles", "updated_at"
    }:
        return False
    if type(payload.get("schema_version")) is not int or payload.get(
        "schema_version"
    ) != SCHEMA_VERSION:
        return False
    if not isinstance(payload.get("kill_switch"), bool) or not isinstance(payload.get("profiles"), Mapping):
        return False
    if "updated_at" in payload and not isinstance(payload["updated_at"], str):
        return False
    profiles = payload["profiles"]
    if _DEFAULT_PROFILE_ID not in profiles:
        return False
    return all(
        isinstance(profile_id, str)
        and bool(profile_id)
        and isinstance(profile, Mapping)
        and _validate_strict_profile(profile, is_default=profile_id == _DEFAULT_PROFILE_ID)
        for profile_id, profile in profiles.items()
    )


def _validate_profile_inventory_payload(payload: Any) -> bool:
    """Accept a strict store or one whose only invalidity is lifecycle data."""
    if not isinstance(payload, Mapping) or set(payload) - {
        "schema_version",
        "kill_switch",
        "profiles",
        "updated_at",
    }:
        return False
    if (
        type(payload.get("schema_version")) is not int
        or payload.get("schema_version") != SCHEMA_VERSION
    ):
        return False
    if not isinstance(payload.get("kill_switch"), bool) or not isinstance(
        payload.get("profiles"), Mapping
    ):
        return False
    if "updated_at" in payload and not isinstance(payload["updated_at"], str):
        return False

    profiles = payload["profiles"]
    default = profiles.get(_DEFAULT_PROFILE_ID)
    if not isinstance(default, Mapping) or not _validate_strict_profile(
        default, is_default=True
    ):
        return False
    for profile_id, profile in profiles.items():
        if (
            not isinstance(profile_id, str)
            or not profile_id
            or not isinstance(profile, Mapping)
        ):
            return False
        if profile_id == _DEFAULT_PROFILE_ID or _validate_strict_profile(
            profile, is_default=False
        ):
            continue
        if profile_lifecycle_disposition(profile) != "invalid":
            return False
        policy_only = dict(profile)
        policy_only.pop("profile_kind", None)
        policy_only.pop("tool_pack_lifecycle", None)
        if not _validate_strict_profile(policy_only, is_default=False):
            return False
    return True


def _validate_state(state: str) -> None:
    if state not in STORE_STATES:
        raise ValueError(
            f"Invalid permission state {state!r}; expected one of {STORE_STATES}"
        )


def _entry_is_empty(entry: dict[str, Any]) -> bool:
    return not entry.get("default") and not entry.get("tools")


def _as_mapping(value: Any) -> dict[str, Any]:
    """Coerce a payload value to a dict, tolerating hand-edited junk.

    Args:
        value: Any value pulled from a permission-store payload -- expected
            to be a dict, but a hand-edited ``mcp_permissions.json`` can
            carry ``null`` or some other JSON type at any nesting level
            instead.

    Returns:
        ``value`` unchanged when it is already a ``Mapping``; an empty
        dict otherwise. Applied at every traversal step in
        ``resolve_effective_state()``/``resolve_effective_state_by_key()``
        (and in ``MCPPermissionStore.load()``'s own normalization) so a
        malformed intermediate degrades to "nothing configured here"
        instead of raising ``AttributeError``.
    """
    return value if isinstance(value, Mapping) else {}


def _normalize_payload_shape(payload: dict[str, Any]) -> dict[str, Any]:
    """Coerce ``profiles`` / every profile / every profile's ``servers`` to dicts.

    A payload can pass ``load()``'s dict + ``schema_version`` check yet
    still carry ``null`` (or another non-mapping value) for one of these
    nested containers -- e.g. a user hand-editing ``mcp_permissions.json``.
    Every ``MCPPermissionStore`` method assumes they are dicts
    (``_profile()`` in particular ``.setdefault()``s into them), so
    normalizing once here means no store method has to guard against it
    separately. Mutates ``payload`` in place.

    Since named permission profiles (workspace assistant defaults), the
    every-profile ``servers`` coercion covers the named profiles too: the
    default profile keeps its exact legacy treatment (coerced as a whole,
    then its ``servers`` coerced), and each additional profile under
    ``profiles`` that is itself a mapping has its ``servers`` coerced the
    same way. A profile VALUE that is not a mapping is left untouched
    (junk stays junk; the resolvers' ``_as_mapping()`` traversal already
    tolerates it, and no store method reaches it without ``_profile()``'s
    own coercion).

    Args:
        payload: A payload dict that has already passed the dict +
            ``schema_version`` check in ``load()``.

    Returns:
        ``payload``, with ``profiles``, the default profile, and every
        mapping profile's ``servers`` coerced to dicts in place.
    """
    profiles = _as_mapping(payload.get("profiles"))
    payload["profiles"] = profiles
    profile = _as_mapping(profiles.get(_DEFAULT_PROFILE_ID))
    profiles[_DEFAULT_PROFILE_ID] = profile
    profile["servers"] = _as_mapping(profile.get("servers"))
    for named in profiles.values():
        if isinstance(named, Mapping):
            named["servers"] = _as_mapping(named.get("servers"))
    return payload


def _profile_chain_ids(payload: dict[str, Any], profile_id: str) -> list[str]:
    """The profile IDS ``_profile_chain`` resolves, most specific first.

    The chain's own membership rule, factored out (task-32281, Qodo #2597
    #1) so a reader that must REPORT which profile a resolved entry came
    from -- ``MCPPermissionStore.list_tool_arg_rules`` -- walks exactly
    the same profiles authorization does instead of a second, drifting
    copy of the rule.

    Args:
        payload: A permission-store payload dict (raw is fine).
        profile_id: The profile being resolved.

    Returns:
        Non-empty list of profile ids, most specific first; the default
        profile is always last.
    """
    profiles = _as_mapping(payload.get("profiles"))
    ids: list[str] = []
    if profile_id != _DEFAULT_PROFILE_ID and _as_mapping(profiles.get(profile_id)):
        ids.append(profile_id)
    ids.append(_DEFAULT_PROFILE_ID)
    return ids


def _profile_chain(payload: dict[str, Any], profile_id: str) -> list[dict[str, Any]]:
    """Return the profile-resolution chain for ``profile_id``.

    The chain is ``[named, default]`` when ``profile_id`` names a profile
    other than ``"default"`` and that profile exists (a non-mapping or
    absent named profile contributes nothing -- an unknown ``profile_id``
    resolves exactly like the default profile alone, which is what a
    deleted-but-still-referenced workspace profile must degrade to), and
    ``[default]`` otherwise. The default profile is always last: it is
    the inheritance fallback every named profile falls through to.

    Args:
        payload: A permission-store payload dict (raw is fine; every step
            is ``_as_mapping()``-coerced).
        profile_id: The profile being resolved.

    Returns:
        Non-empty list of profile dicts, most specific first.
    """
    profiles = _as_mapping(payload.get("profiles"))
    return [
        _as_mapping(profiles.get(chain_id))
        for chain_id in _profile_chain_ids(payload, profile_id)
    ]


def _lifecycle_resolution_block(
    payload: Mapping[str, Any], profile_id: str
) -> str | None:
    """Return a fail-closed resolver origin before profile inheritance.

    The selected named profile is authoritative: an invalid discriminator pair
    cannot fall through to ``default``, and a validated tombstone permanently
    denies. The inherited default profile is checked too whenever it may take
    part in the subsequent chain.
    """
    profiles = _as_mapping(payload.get("profiles"))
    profile_ids = [profile_id]
    if profile_id != _DEFAULT_PROFILE_ID:
        profile_ids.append(_DEFAULT_PROFILE_ID)
    for candidate_id in profile_ids:
        profile = profiles.get(candidate_id)
        if not isinstance(profile, Mapping):
            continue
        disposition = profile_lifecycle_disposition(profile)
        if disposition == "invalid":
            return "lifecycle_invalid"
        if disposition == "tombstone":
            return "tombstone"
    return None


class MCPPermissionStore:
    """Read-modify-write accessor over the on-disk permission-store JSON file.

    Every instance for the same resolved path shares one process-wide reentrant
    mutation fence. Mutators reload and durably replace the full payload while
    holding that fence, preventing in-process lost updates.
    """

    @mcp_sources.guarded
    def __init__(self, path: Path) -> None:
        self.path = Path(path)
        from .recovery_activation import select

        select(self)
        self._path_lock = _resolved_path_lock(self.path)
        self._mutation_lock = self._path_lock

    # -- raw load/save -----------------------------------------------------

    @mcp_sources.guarded
    def load(self) -> dict[str, Any]:
        """Return the full store payload, always valid.

        Missing file -> fresh default payload. Corrupt JSON, JSON that does
        not decode to a dict, or a dict whose ``schema_version`` is not
        ``SCHEMA_VERSION`` -> the existing file is backed up to
        ``<name>.bak`` (replacing any prior backup), a warning is logged,
        and a fresh default payload is returned. A schema-valid payload
        with a non-mapping ``profiles`` / default profile / ``servers``
        (e.g. hand-edited to ``null``) has those coerced to dicts in place
        rather than being treated as corrupt.

        Returns:
            The payload dict, always shaped so ``profiles["default"]`` and
            its ``servers`` key are dicts. Admission and uncertain native
            persistence failures propagate without resetting policy.
        """
        with self.mutation_fence():
            return self._load_locked()

    @mcp_sources.guarded
    def _load_locked(self) -> dict[str, Any]:
        """Load with legacy recovery while the resolved-path fence is held."""
        from .recovery_activation import readable

        if not readable(self, "mcp.permissions") or not self.path.exists():
            return _fresh_payload()

        try:
            with mcp_sources.reader(self) as handle:
                raw_text = handle.read()
            # task-32805.5 + TASK-32806.3: reject a duplicate `global_default`
            # or a non-finite constant (a tamper vector on a security file) so an
            # ambiguous policy is treated as corrupt and reset below; an OSError,
            # by contrast, is an UNCERTAIN persistence failure (permission bit,
            # full disk, mount blip) that must NOT reset policy -- it propagates
            # (the documented fail-closed path, rendered as gate_error/deny).
            payload = json.loads(
                raw_text,
                object_pairs_hook=_reject_duplicate_keys,
                parse_constant=_reject_json_constant,
            )
        except OSError as exc:
            logger.warning(
                f"MCP permission store at '{self.path}' could not be read "
                f"({type(exc).__name__}); policy is left untouched."
            )
            raise
        except (ValueError, json.JSONDecodeError) as exc:
            # A genuine parse failure: the bytes arrived and are not JSON.
            logger.warning(
                f"MCP permission store at '{self.path}' is corrupt ({exc}); "
                "backing it up and resetting to defaults."
            )
            self._backup_corrupt_file()
            return _fresh_payload()

        if (
            not isinstance(payload, dict)
            or payload.get("schema_version") != SCHEMA_VERSION
        ):
            logger.warning(
                f"MCP permission store at '{self.path}' has an unrecognized shape or "
                f"schema_version (expected {SCHEMA_VERSION}); backing it up and resetting to defaults."
            )
            self._backup_corrupt_file()
            return _fresh_payload()

        return _normalize_payload_shape(payload)

    @mcp_sources.guarded
    def read_snapshot_strict(self) -> PermissionStoreSnapshot:
        """Read schema 1 once without creating, renaming, normalizing, or saving.

        Unlike :meth:`load`, this authority seam never invokes legacy recovery.
        Callers can therefore use its immutable payload and generation token for
        review or concurrency checks without an inspection changing disk state.

        Raises:
            PermissionStoreSnapshotError: If the store cannot be read as an
                exact, schema-1 permission payload.
        """
        try:
            if mcp_sources.binding(self)[2]:
                with mcp_sources.reader(self) as handle:
                    raw_bytes = handle.buffer.read()
            else:
                raw_bytes = self.path.read_bytes()
        except FileNotFoundError:
            fresh = _fresh_payload()
            frozen = _freeze_snapshot(fresh)
            digest = hashlib.sha256(
                json.dumps(fresh, sort_keys=True, separators=(",", ":")).encode("utf-8")
            ).hexdigest()
            return PermissionStoreSnapshot(
                payload=frozen,
                generation=f"missing:{digest}",
                file_exists=False,
            )
        except OSError as exc:
            raise PermissionStoreSnapshotError("io_error") from exc

        try:
            payload = json.loads(
                raw_bytes.decode("utf-8"),
                object_pairs_hook=_reject_duplicate_keys,
                parse_constant=_reject_json_constant,
            )
        except PermissionStoreSnapshotError:
            raise
        except (UnicodeDecodeError, json.JSONDecodeError, RecursionError, ValueError) as exc:
            raise PermissionStoreSnapshotError("invalid_json") from exc

        if not _validate_strict_payload(payload):
            raise PermissionStoreSnapshotError("invalid_shape")

        return PermissionStoreSnapshot(
            payload=_freeze_snapshot(payload),
            generation=f"sha256:{hashlib.sha256(raw_bytes).hexdigest()}",
            file_exists=True,
        )

    @mcp_sources.guarded
    def read_profile_inventory_snapshot(self) -> PermissionStoreSnapshot:
        """Read profile rows without recovering globally corrupt authority.

        A named profile whose policy fields are valid but whose Tool Pack
        lifecycle metadata is invalid remains visible to callers so it can be
        rendered unavailable. Invalid JSON, duplicate keys, unknown schemas,
        malformed default policy, and unrelated shape errors remain hard
        failures and never synthesize an actionable default profile.

        Returns:
            An immutable snapshot suitable for profile-selector inventory.

        Raises:
            PermissionStoreSnapshotError: If corruption extends beyond one or
                more named profiles' lifecycle metadata.
        """
        try:
            return self.read_snapshot_strict()
        except PermissionStoreSnapshotError as exc:
            if exc.category != "invalid_shape":
                raise

        try:
            if mcp_sources.binding(self)[2]:
                with mcp_sources.reader(self) as handle:
                    raw_bytes = handle.buffer.read()
            else:
                raw_bytes = self.path.read_bytes()
            payload = json.loads(
                raw_bytes.decode("utf-8"),
                object_pairs_hook=_reject_duplicate_keys,
                parse_constant=_reject_json_constant,
            )
        except FileNotFoundError:
            return self.read_snapshot_strict()
        except PermissionStoreSnapshotError:
            raise
        except OSError as exc:
            raise PermissionStoreSnapshotError("io_error") from exc
        except (
            UnicodeDecodeError,
            json.JSONDecodeError,
            RecursionError,
            ValueError,
        ) as exc:
            raise PermissionStoreSnapshotError("invalid_json") from exc

        if not _validate_profile_inventory_payload(payload):
            raise PermissionStoreSnapshotError("invalid_shape")
        return PermissionStoreSnapshot(
            payload=_freeze_snapshot(payload),
            generation=f"sha256:{hashlib.sha256(raw_bytes).hexdigest()}",
            file_exists=True,
        )

    @mcp_sources.guarded
    def _load_for_raw_getter(self) -> dict[str, Any]:
        """Load a legacy-compatible payload without recovery side effects.

        Raw getters expose a best-effort view for UI inspection. They retain
        ``load()``'s permissive in-memory fallback but must never back up,
        create, normalize on disk, or otherwise alter a policy file.
        """
        try:
            with mcp_sources.reader(self) as handle:
                raw_text = handle.read()
            # task-32805.5: even the best-effort inspection view must not
            # present the last-wins reading of a duplicate-keyed policy file;
            # reject duplicates/non-finite constants (they fall to the corrupt
            # branch below), while OSError still fail-closes per TASK-32806.3.
            payload = json.loads(
                raw_text,
                object_pairs_hook=_reject_duplicate_keys,
                parse_constant=_reject_json_constant,
            )
        except FileNotFoundError:
            # No file yet is a KNOWN state, not an uncertain one: nothing
            # has been configured, so the permissive first-run default is
            # the honest answer. (``_load_locked`` says the same thing with
            # its ``self.path.exists()`` guard.)
            return _fresh_payload()
        except OSError:
            # TASK-32806.3: unreadable is not the same as unconfigured.
            # These getters feed display surfaces, so they must not raise
            # into a screen, but they must not report the permissive
            # first-run default for a policy nobody could read either.
            return _fail_closed_payload()
        except (UnicodeDecodeError, json.JSONDecodeError, RecursionError, ValueError):
            return _fresh_payload()

        if (
            not isinstance(payload, dict)
            or payload.get("schema_version") != SCHEMA_VERSION
        ):
            return _fresh_payload()
        return _normalize_payload_shape(payload)

    @contextmanager
    def mutation_fence(self) -> Iterator[None]:
        """Hold the process-wide reentrant lock for this resolved store path."""
        with self._path_lock:
            yield

    @mcp_sources.guarded
    def save(
        self,
        payload: dict[str, Any],
        *,
        expected_generation: str | None = None,
    ) -> None:
        """Atomically write ``payload`` to disk, stamping ``updated_at``.

        Args:
            payload: Full store payload to persist. Mutated in place to
                add/overwrite ``updated_at`` after successful publication and native close.
            expected_generation: Optional generation captured before deriving
                ``payload``. A changed store is rejected rather than replaced.
        """
        with self.mutation_fence():
            if expected_generation is not None:
                current = self.read_snapshot_strict()
                if current.generation != expected_generation:
                    raise ProfileMutationError("stale_store")
            self._save_locked(payload)

    @mcp_sources.guarded
    def _save_locked(self, payload: dict[str, Any]) -> None:
        """Durably replace the store while the caller holds the path fence."""
        from .recovery_activation import require_store_write

        require_store_write(self, "mcp.permissions")
        stamp = _iso_utc_now()
        persisted = dict(payload, updated_at=stamp)
        if mcp_sources.binding(self)[2]:
            mcp_sources.write_json(self, persisted)
            mcp_sources.stamp_payload(self, payload, stamp)
            return
        self.path.parent.mkdir(parents=True, exist_ok=True)
        # Hand-rolled rather than Utils.atomic_file_ops. The reason given by
        # task-32808.5 AC#3 -- that only this store fsynced BOTH the file and
        # the parent directory -- no longer holds: since task-32896 the shared
        # helper makes both guarantees, and also issues the Darwin F_FULLFSYNC
        # barrier that the bare os.fsync below does not. What still keeps this
        # path hand-rolled is the recovery-gated structure around it
        # (require_store_write / mcp_sources binding), not durability.
        temp_fd, raw_temp_path = tempfile.mkstemp(
            prefix=f".{self.path.name}.",
            suffix=".tmp",
            dir=self.path.parent,
        )
        temp_path = Path(raw_temp_path)
        try:
            handle = os.fdopen(temp_fd, "w", encoding="utf-8")
            temp_fd = -1
            with handle:
                json.dump(persisted, handle, indent=2, sort_keys=True)
                handle.flush()
                os.fsync(handle.fileno())
            os.replace(temp_path, self.path)
        except BaseException:
            if temp_fd >= 0:
                os.close(temp_fd)
            try:
                temp_path.unlink()
            except FileNotFoundError:
                pass
            raise

        _fsync_parent_directory(self.path.parent)
        payload["updated_at"] = stamp

    @mcp_sources.guarded
    def _mutate_locked(self, change: Callable[[dict[str, Any]], bool]) -> bool:
        """Load, mutate, and durably save once under the shared path fence."""
        with self.mutation_fence():
            payload = self.load()
            changed = change(payload)
            if changed:
                self._save_locked(payload)
            return changed

    @mcp_sources.guarded
    def _backup_corrupt_file(self) -> None:
        from .recovery_activation import require_store_write

        require_store_write(self, "mcp.permissions")
        try:
            mcp_sources.backup_corrupt(self)
        except OSError as exc:
            logger.warning(
                f"Failed to back up corrupt MCP permission store at '{self.path}': {exc}"
            )

    # -- profile helpers -----------------------------------------------------

    @staticmethod
    def _profile(
        payload: dict[str, Any], profile_id: str = _DEFAULT_PROFILE_ID
    ) -> dict[str, Any]:
        """Return (seeding as needed) the writable dict for one profile.

        For ``"default"`` the seeding is exactly the legacy behavior:
        ``global_default`` and ``servers`` are ``.setdefault()``ed. For a
        named profile only ``servers`` is seeded -- the named profile
        deliberately carries no ``global_default`` key, because at that
        precedence level *absence means inherit* from the default profile
        (see the resolvers' chain walk).

        Args:
            payload: A loaded (hence normalized) payload to mutate.
            profile_id: Profile to fetch; seeded as above when absent.

        Returns:
            The profile's dict, coerced to a dict even when a hand-edited
            payload carried junk at that key.
        """
        profiles = payload.setdefault("profiles", {})
        profile = profiles.setdefault(profile_id, {})
        if not isinstance(profile, dict):
            profile = {}
            profiles[profile_id] = profile
        if profile_id == _DEFAULT_PROFILE_ID:
            profile.setdefault("global_default", DEFAULT_GLOBAL)
        profile.setdefault("servers", {})
        return profile

    @staticmethod
    def _validate_profile_semantics(
        profile: Mapping[str, Any],
        *,
        expected_disposition: ProfileLifecycleDisposition | None = None,
    ) -> ProfileLifecycleDisposition:
        """Validate exact profile shape and its lifecycle policy identity."""
        disposition = profile_lifecycle_disposition(profile)
        if disposition == "invalid":
            raise ProfileMutationError("lifecycle_invalid")
        if expected_disposition is not None and disposition != expected_disposition:
            raise ProfileMutationError("lifecycle_invalid")
        if disposition in {"imported", "tombstone"}:
            if not _validate_strict_profile(profile, is_default=False):
                raise ProfileMutationError("lifecycle_invalid")
            lifecycle = profile["tool_pack_lifecycle"]
            if lifecycle["policy_digest"] != profile_policy_digest(profile):
                raise ProfileMutationError("policy_digest_mismatch")
        return disposition

    @mcp_sources.guarded
    def _mutate_profile_locked(
        self,
        profile_id: str,
        change: Callable[[dict[str, Any]], bool],
        *,
        expected_profile_digest: str | None,
        expected_revision: int | None,
    ) -> bool:
        """Apply one field edit with profile-scoped CAS and lifecycle upkeep."""
        with self.mutation_fence():
            payload = self.load()
            profiles = payload.setdefault("profiles", {})
            existing = profiles.get(profile_id)
            if isinstance(existing, Mapping):
                disposition = self._validate_profile_semantics(existing)
                if disposition == "tombstone":
                    raise ProfileMutationError("profile_tombstone")
                current_digest = profile_policy_digest(existing)
                if (
                    expected_profile_digest is not None
                    and current_digest != expected_profile_digest
                ):
                    raise ProfileMutationError("stale_profile")
                if expected_revision is not None:
                    current_revision = (
                        existing["tool_pack_lifecycle"]["revision"]
                        if disposition == "imported"
                        else None
                    )
                    if current_revision != expected_revision:
                        raise ProfileMutationError("stale_revision")
            else:
                if expected_profile_digest is not None:
                    raise ProfileMutationError("stale_profile")
                if expected_revision is not None:
                    raise ProfileMutationError("stale_revision")
                disposition = "legacy"

            profile = self._profile(payload, profile_id)
            changed = change(profile)
            if not changed:
                return False
            if disposition == "imported":
                lifecycle = profile["tool_pack_lifecycle"]
                lifecycle["revision"] += 1
                lifecycle["policy_digest"] = profile_policy_digest(profile)
                self._validate_profile_semantics(
                    profile, expected_disposition="imported"
                )
            self._save_locked(payload)
            return True

    @mcp_sources.guarded
    def install_profile_if_absent(
        self,
        profile_id: str,
        imported_profile: Mapping[str, Any],
        *,
        expected_generation: str,
        max_profiles: int,
        max_store_bytes: int,
    ) -> ProfileMutationResult:
        """Atomically install one reviewed imported profile if its id is free."""
        candidate = _thaw_snapshot(imported_profile)

        with self.mutation_fence():
            self._validate_profile_semantics(candidate, expected_disposition="imported")
            if candidate["tool_pack_lifecycle"]["revision"] != 1:
                raise ProfileMutationError("invalid_revision")
            if (
                candidate["tool_pack_lifecycle"][
                    "first_bind_confirmation_required"
                ]
                is not True
            ):
                raise ProfileMutationError("first_bind_required")
            snapshot = self.read_snapshot_strict()
            if snapshot.generation != expected_generation:
                raise ProfileMutationError("stale_store")
            payload = _thaw_snapshot(snapshot.payload)
            profiles = payload["profiles"]
            if profile_id in profiles:
                raise ProfileMutationError("profile_exists")
            folded = profile_id.casefold()
            if any(existing_id.casefold() == folded for existing_id in profiles):
                raise ProfileMutationError("profile_id_collision")
            if len(profiles) + 1 > max_profiles:
                raise ProfileMutationError("profile_limit")

            profiles[profile_id] = candidate
            if _projected_store_size(payload) > max_store_bytes:
                raise ProfileMutationError("store_bytes_limit")
            self._save_locked(payload)
            generation = self.read_snapshot_strict().generation

        lifecycle = candidate["tool_pack_lifecycle"]
        return ProfileMutationResult(
            profile_id=profile_id,
            revision=lifecycle["revision"],
            policy_digest=lifecycle["policy_digest"],
            store_generation=generation,
        )

    @mcp_sources.guarded
    def update_imported_profile(
        self,
        profile_id: str,
        replacement_profile: Mapping[str, Any],
        *,
        expected_revision: int,
        max_store_bytes: int,
        expected_generation: str | None = None,
        expected_profile_digest: str | None = None,
    ) -> ProfileMutationResult:
        """Atomically replace an imported profile's complete policy fields."""
        replacement = _thaw_snapshot(replacement_profile)

        with self.mutation_fence():
            self._validate_profile_semantics(
                replacement, expected_disposition="imported"
            )
            snapshot = self.read_snapshot_strict()
            if (
                expected_generation is not None
                and snapshot.generation != expected_generation
            ):
                raise ProfileMutationError("stale_store")
            payload = _thaw_snapshot(snapshot.payload)
            current = payload["profiles"].get(profile_id)
            if not isinstance(current, Mapping):
                raise ProfileMutationError("profile_missing")
            self._validate_profile_semantics(current, expected_disposition="imported")
            current_lifecycle = current["tool_pack_lifecycle"]
            if current_lifecycle["revision"] != expected_revision:
                raise ProfileMutationError("stale_revision")
            current_digest = profile_policy_digest(current)
            if (
                expected_profile_digest is not None
                and current_digest != expected_profile_digest
            ):
                raise ProfileMutationError("stale_profile")

            lifecycle = _thaw_snapshot(current_lifecycle)
            lifecycle["revision"] += 1
            replacement["tool_pack_lifecycle"] = lifecycle
            lifecycle["policy_digest"] = profile_policy_digest(replacement)
            self._validate_profile_semantics(
                replacement, expected_disposition="imported"
            )
            payload["profiles"][profile_id] = replacement
            if _projected_store_size(payload) > max_store_bytes:
                raise ProfileMutationError("store_bytes_limit")
            self._save_locked(payload)
            generation = self.read_snapshot_strict().generation

        return ProfileMutationResult(
            profile_id=profile_id,
            revision=lifecycle["revision"],
            policy_digest=lifecycle["policy_digest"],
            store_generation=generation,
        )

    @mcp_sources.guarded
    def replace_profile_with_tombstone(
        self,
        profile_id: str,
        tombstone_profile: Mapping[str, Any],
        *,
        expected_revision: int,
        max_store_bytes: int,
        expected_generation: str | None = None,
        expected_profile_digest: str | None = None,
    ) -> ProfileMutationResult:
        """Atomically replace a valid imported profile with a deny tombstone."""
        tombstone = _thaw_snapshot(tombstone_profile)

        with self.mutation_fence():
            self._validate_profile_semantics(
                tombstone, expected_disposition="tombstone"
            )
            builtin = _as_mapping(
                _as_mapping(tombstone.get("servers")).get(BUILTIN_TOOL_SERVER_KEY)
            )
            if (
                tombstone.get("global_default") != "deny"
                or builtin.get("default") != "deny"
                or _profile_has_permissive_policy(tombstone)
            ):
                raise ProfileMutationError("tombstone_permissive")
            snapshot = self.read_snapshot_strict()
            if (
                expected_generation is not None
                and snapshot.generation != expected_generation
            ):
                raise ProfileMutationError("stale_store")
            payload = _thaw_snapshot(snapshot.payload)
            current = payload["profiles"].get(profile_id)
            if not isinstance(current, Mapping):
                raise ProfileMutationError("profile_missing")
            self._validate_profile_semantics(current, expected_disposition="imported")
            current_lifecycle = current["tool_pack_lifecycle"]
            if current_lifecycle["revision"] != expected_revision:
                raise ProfileMutationError("stale_revision")
            current_digest = profile_policy_digest(current)
            if (
                expected_profile_digest is not None
                and current_digest != expected_profile_digest
            ):
                raise ProfileMutationError("stale_profile")
            lifecycle = tombstone["tool_pack_lifecycle"]
            if (
                lifecycle["pack_digest"] != current_lifecycle["pack_digest"]
                or lifecycle["imported_at"] != current_lifecycle["imported_at"]
            ):
                raise ProfileMutationError("lifecycle_provenance_mismatch")
            lifecycle["revision"] = current_lifecycle["revision"] + 1
            lifecycle["policy_digest"] = profile_policy_digest(tombstone)
            self._validate_profile_semantics(
                tombstone, expected_disposition="tombstone"
            )
            payload["profiles"][profile_id] = tombstone
            if _projected_store_size(payload) > max_store_bytes:
                raise ProfileMutationError("store_bytes_limit")
            self._save_locked(payload)
            generation = self.read_snapshot_strict().generation

        return ProfileMutationResult(
            profile_id=profile_id,
            revision=lifecycle["revision"],
            policy_digest=lifecycle["policy_digest"],
            store_generation=generation,
        )

    @mcp_sources.guarded
    def ensure_profile(self, profile_id: str) -> None:
        """Create the named profile if it does not exist.

        Seeded ``{"servers": {}}`` only -- no ``global_default`` key, so
        every unset level inherits from the ``default`` profile. A no-op
        for the default profile (it always exists) and for empty ids
        (not a valid profile reference).

        Args:
            profile_id: Profile to create; existing profiles are left
                untouched.
        """
        if profile_id == _DEFAULT_PROFILE_ID or not profile_id:
            return

        def change(payload: dict[str, Any]) -> bool:
            profiles = payload.setdefault("profiles", {})
            if profile_id in profiles:
                return False
            profiles[profile_id] = {"servers": {}}
            return True

        self._mutate_locked(change)

    @mcp_sources.guarded
    def list_profiles(self) -> list[str]:
        """Return every stored profile id, sorted.

        Returns:
            Sorted list of the keys under ``profiles`` (always includes
            ``"default"`` after any ``load()``).
        """
        return sorted(_as_mapping(self.load().get("profiles")).keys())

    @mcp_sources.guarded
    def catalog_fingerprint(self) -> tuple:
        """Identify exactly what :meth:`load` would return now, without parsing.

        TASK-33620.15.1: the Console reuses a run's composed MCP catalog while
        nothing it read has changed. This passes the same admission scope,
        path fence and recovery readability check as ``load()`` (a refusal
        raises as ``load()`` would) and hashes the bytes ``load()`` would parse.

        Returns:
            ``("fresh",)`` when ``load()`` returns the default payload without
            reading (an inactive store or no file); otherwise ``("file",
            sha256, stamp)``, ``stamp`` being the read file's ``(st_dev,
            st_ino, st_size, st_mtime_ns, st_ctime_ns)``.
        """
        from .recovery_activation import readable

        with self.mutation_fence():
            if not readable(self, "mcp.permissions") or not self.path.exists():
                return ("fresh",)
            with mcp_sources.reader(self) as handle:
                raw = handle.buffer.read()
                info = os.fstat(handle.fileno())
        stamp = (info.st_dev, info.st_ino, info.st_size, info.st_mtime_ns, info.st_ctime_ns)
        return ("file", hashlib.sha256(raw).hexdigest(), stamp)

    # -- kill switch -----------------------------------------------------

    @mcp_sources.guarded
    def get_kill_switch(self) -> bool:
        """Return whether the global kill switch is enabled.

        Returns:
            True when all tool execution should be blocked regardless of
            any other setting; False otherwise (including when the store
            file is missing).
        """
        return bool(self.load().get("kill_switch", False))

    @mcp_sources.guarded
    def set_kill_switch(self, value: bool) -> None:
        """Persist the global kill switch.

        Args:
            value: True to block all tool execution; False to re-enable
                normal precedence-based resolution.
        """

        def change(payload: dict[str, Any]) -> bool:
            normalized = bool(value)
            if payload.get("kill_switch") is normalized:
                return False
            payload["kill_switch"] = normalized
            return True

        self._mutate_locked(change)

    # -- global default -----------------------------------------------------

    @mcp_sources.guarded
    def get_global_default(self, *, profile_id: str = _DEFAULT_PROFILE_ID) -> str:
        """Return the profile's global default permission state.

        Args:
            profile_id: Profile to inspect without creating or normalizing it.

        Returns:
            One of ``STORE_STATES``, or ``DEFAULT_GLOBAL`` when unset.
        """
        payload = self._load_for_raw_getter()
        if payload.get(_UNREADABLE_MARKER):
            # Fail closed for EVERY profile, not only the default one.
            return "off"
        profiles = _as_mapping(payload.get("profiles"))
        profile = _as_mapping(profiles.get(profile_id))
        return profile.get("global_default", DEFAULT_GLOBAL)

    @mcp_sources.guarded
    def set_global_default(
        self,
        state: str,
        *,
        profile_id: str = _DEFAULT_PROFILE_ID,
        expected_profile_digest: str | None = None,
        expected_revision: int | None = None,
    ) -> None:
        """Persist a profile's global default permission state.

        Args:
            state: One of ``STORE_STATES``.
            profile_id: Profile to write; defaults to the ``default``
                profile (byte-identical to the pre-profiles behavior).

        Raises:
            ValueError: If ``state`` is not one of ``STORE_STATES``.
        """
        _validate_state(state)

        def change(profile: dict[str, Any]) -> bool:
            if profile.get("global_default") == state:
                return False
            profile["global_default"] = state
            return True

        self._mutate_profile_locked(
            profile_id,
            change,
            expected_profile_digest=expected_profile_digest,
            expected_revision=expected_revision,
        )

    # -- server default -----------------------------------------------------

    @mcp_sources.guarded
    def get_server_entry(
        self, server_key: str, *, profile_id: str = _DEFAULT_PROFILE_ID
    ) -> dict[str, Any] | None:
        """Return the raw stored entry for a server, if any.

        Args:
            server_key: Server's stable key (``<source>:<server_id>``).
            profile_id: Profile to inspect without creating or normalizing it.

        Returns:
            The server's entry dict (an optional ``"default"`` and/or
            ``"tools"`` key), or None when the server has no entry at all
            (fully "Inherit").
        """
        payload = self._load_for_raw_getter()
        profiles = _as_mapping(payload.get("profiles"))
        profile = _as_mapping(profiles.get(profile_id))
        servers = _as_mapping(profile.get("servers"))
        return servers.get(server_key)

    @mcp_sources.guarded
    def set_server_default(
        self,
        server_key: str,
        state: str | None,
        *,
        profile_id: str = _DEFAULT_PROFILE_ID,
        expected_profile_digest: str | None = None,
        expected_revision: int | None = None,
    ) -> None:
        """Set or clear a server-level default permission state.

        Args:
            server_key: Server's stable key (``<source>:<server_id>``).
            state: One of ``STORE_STATES`` to set an explicit default, or
                None to clear it (inherit from the global default). The
                server's entry is pruned entirely once it has neither a
                default nor any tool overrides left.
            profile_id: Profile to write; defaults to the ``default``
                profile (byte-identical to the pre-profiles behavior).

        Raises:
            ValueError: If ``state`` is not None and not one of
                ``STORE_STATES``.
        """
        if state is not None:
            _validate_state(state)

        def change(profile: dict[str, Any]) -> bool:
            servers = profile.setdefault("servers", {})
            if state is None:
                entry = servers.get(server_key)
                if entry is None or "default" not in entry:
                    return False
                entry.pop("default")
                if _entry_is_empty(entry):
                    servers.pop(server_key, None)
                return True

            entry = servers.setdefault(server_key, {})
            if entry.get("default") == state:
                return False
            entry["default"] = state
            return True

        self._mutate_profile_locked(
            profile_id,
            change,
            expected_profile_digest=expected_profile_digest,
            expected_revision=expected_revision,
        )

    # -- tool state -----------------------------------------------------

    @mcp_sources.guarded
    def get_tool_entry(
        self,
        server_key: str,
        tool_name: str,
        *,
        profile_id: str = _DEFAULT_PROFILE_ID,
    ) -> dict[str, Any] | None:
        """Return the raw stored entry for one tool, if any.

        Args:
            server_key: Owning server's stable key.
            tool_name: Tool name within that server.
            profile_id: Profile to inspect without creating or normalizing it.

        Returns:
            The tool's entry dict (``"state"`` guaranteed; ``"definition_hash"``
            and ``"config_changed"`` optional), or None when the tool has
            no explicit entry (inherits from the server/global default).
        """
        payload = self._load_for_raw_getter()
        profiles = _as_mapping(payload.get("profiles"))
        profile = _as_mapping(profiles.get(profile_id))
        servers = _as_mapping(profile.get("servers"))
        entry = _as_mapping(servers.get(server_key))
        tools = _as_mapping(entry.get("tools"))
        return tools.get(tool_name)

    @mcp_sources.guarded
    def set_tool_state(
        self,
        server_key: str,
        tool_name: str,
        state: str | None,
        *,
        definition_hash: str | None = None,
        profile_id: str = _DEFAULT_PROFILE_ID,
        expected_profile_digest: str | None = None,
        expected_revision: int | None = None,
    ) -> None:
        """Set or clear a tool-level permission override.

        Args:
            server_key: Owning server's stable key.
            tool_name: Tool name within that server.
            state: One of ``STORE_STATES`` to set an explicit override, or
                None to clear it (inherit from the server/global default).
                Setting replaces any existing entry wholesale, which is
                what clears a persisted ``config_changed`` marker.
            definition_hash: Required when ``state`` is ``"allow"`` -- the
                tool's current fingerprint (see ``definition_hash()``),
                stored alongside the allow for the rug-pull guard to
                compare against later. Must be a SHA-256 digest. Not
                required or stored for ``server_key`` values in
                ``HASH_FREE_SERVER_KEYS``.
            profile_id: Profile to write; defaults to the ``default``
                profile (byte-identical to the pre-profiles behavior).

        Raises:
            ValueError: If ``state`` is not None and not one of
                ``STORE_STATES``, or if ``state`` is ``"allow"`` without a
                SHA-256 ``definition_hash`` and ``server_key`` is not in
                ``HASH_FREE_SERVER_KEYS``.
        """
        if state is not None:
            _validate_state(state)
            if (
                state == "allow"
                and server_key not in HASH_FREE_SERVER_KEYS
                and not _is_sha256(definition_hash)
            ):
                raise ValueError(
                    "a SHA-256 definition_hash is required when state is 'allow'"
                )

        def change(profile: dict[str, Any]) -> bool:
            servers = profile.setdefault("servers", {})
            if state is None:
                entry = servers.get(server_key)
                if entry is None:
                    return False
                tools = entry.get("tools", {})
                if tool_name not in tools:
                    return False
                tools.pop(tool_name)
                if not tools:
                    entry.pop("tools", None)
                if _entry_is_empty(entry):
                    servers.pop(server_key, None)
                return True

            entry = servers.setdefault(server_key, {})
            tools = entry.setdefault("tools", {})
            tool_entry: dict[str, Any] = {"state": state}
            if (
                state == "allow"
                and server_key not in HASH_FREE_SERVER_KEYS
                and definition_hash is not None
            ):
                tool_entry["definition_hash"] = definition_hash
            if tools.get(tool_name) == tool_entry:
                return False
            tools[tool_name] = tool_entry
            return True

        self._mutate_profile_locked(
            profile_id,
            change,
            expected_profile_digest=expected_profile_digest,
            expected_revision=expected_revision,
        )


    @mcp_sources.guarded
    def add_tool_arg_rule(
        self,
        server_key: str,
        tool_name: str,
        *,
        args: Mapping[str, Any],
        definition_hash: str | None,
        profile_id: str = _DEFAULT_PROFILE_ID,
    ) -> None:
        """Persist one exact-arguments allow rule for a tool (TASK-26012).

        The rule stores the canonical JSON of the EXACT arguments the user
        was shown on the approval card (AC#3: no rule is created from text
        the user did not read); ``arg_rule_allows`` later matches a call
        only when its canonical arguments are identical. Hand-written
        ``{"field": ..., "pattern": ...}`` glob rules are also honored by
        the matcher, but this writer never creates them.

        Args:
            server_key: Owning server's stable key.
            tool_name: Tool name within that server.
            args: The exact arguments to allow, as displayed to the user.
            definition_hash: The tool's current fingerprint -- the rug-pull
                guard invalidates the rule when the definition changes
                (AC#4). May be None only for ``HASH_FREE_SERVER_KEYS``.
            profile_id: Profile to write into.
        """
        if definition_hash is None and server_key not in HASH_FREE_SERVER_KEYS:
            raise ValueError("definition_hash is required for an arg rule")

        def change(profile: dict[str, Any]) -> bool:
            entry = (
                profile.setdefault("servers", {})
                .setdefault(server_key, {})
                .setdefault("tools", {})
                .setdefault(tool_name, {})
            )
            rules = entry.setdefault("arg_rules", [])
            rule = {
                "args_json": _canonical_args_json(args),
                "definition_hash": definition_hash,
                "created_at": _iso_utc_now(),
            }
            if rule["args_json"] in {
                existing.get("args_json")
                for existing in rules
                if isinstance(existing, Mapping)
            }:
                return False
            rules.append(rule)
            return True

        # Qodo #2600 #13: fenced like `set_tool_state`, not a bare
        # load/mutate/save -- the old shape let a concurrent permission
        # write land between this method's own load and save and be
        # discarded by it. `_mutate_profile_locked` also seeds the profile
        # (what the removed `ensure_profile()` call did) INSIDE the fence.
        self._mutate_profile_locked(
            profile_id,
            change,
            expected_profile_digest=None,
            expected_revision=None,
        )

    @mcp_sources.guarded
    def list_tool_arg_rules(
        self,
        server_key: str,
        tool_name: str,
        *,
        profile_id: str = _DEFAULT_PROFILE_ID,
    ) -> list[dict[str, Any]]:
        """List the exact-input allow rules in force for one tool (task-32281).

        Walks the SAME ``_profile_chain`` ``arg_rule_allows`` authorizes
        against, and stops at the first profile carrying rules for this
        tool -- exactly that resolver's shadowing rule. Qodo #2597 #1: this
        used to read the selected profile ONLY, so a child profile
        inheriting a rule from ``default`` showed no rule and no Remove
        control while the rule kept quieting real calls. Every returned
        rule therefore names its OWNING profile, which is the profile
        ``remove_tool_arg_rule`` must be pointed at to actually delete it.

        Hand-written ``{"field": ..., "pattern": ...}`` glob rules are
        never returned: this surface is scoped to the exact-input rules
        the approval card creates (``args_json`` present).

        Args:
            server_key: Owning server's stable key.
            tool_name: Tool name within that server.
            profile_id: Profile being reviewed; its inheritance chain is
                walked, not just the profile itself.

        Returns:
            One dict per rule, oldest first, each carrying ``rule_id``
            (the rule's canonical ``args_json`` -- unique per tool by
            construction, see ``add_tool_arg_rule``'s own dedup, and the
            same string ``remove_tool_arg_rule`` matches against),
            ``args_json``, ``created_at``, and ``profile_id`` (the OWNING
            profile, which is ``profile_id`` for a rule stored here and an
            ancestor's id for an inherited one).
        """
        payload = self.load()
        profiles = payload.get("profiles", {})
        for owner_id in _profile_chain_ids(payload, profile_id):
            tool_entry = self._tool_entry(
                profiles.get(owner_id), server_key, tool_name
            )
            if tool_entry is None:
                continue
            rules = tool_entry.get("arg_rules")
            if not isinstance(rules, list) or not rules:
                continue
            # A profile carrying ANY rules for this tool ends the walk,
            # shadowing its ancestors -- `arg_rule_allows`'s own `return
            # False` after the first such profile. Listing an ancestor's
            # inert rules below it would advertise a rule that cannot fire.
            return [
                {
                    "rule_id": rule["args_json"],
                    "args_json": rule["args_json"],
                    "created_at": rule.get("created_at"),
                    "profile_id": owner_id,
                }
                for rule in rules
                if isinstance(rule, Mapping)
                and isinstance(rule.get("args_json"), str)
                and rule.get("args_json")
            ]
        return []

    @mcp_sources.guarded
    def remove_tool_arg_rule(
        self,
        server_key: str,
        tool_name: str,
        rule_id: str,
        *,
        profile_id: str = _DEFAULT_PROFILE_ID,
    ) -> bool:
        """Delete one exact-input allow rule (task-32281).

        Qodo #2600 #13: runs load -> remove -> validate -> save under
        ``_mutate_profile_locked``, the same guarded mutation fence
        ``set_tool_state`` uses (``add_tool_arg_rule`` now does too). The
        previous bare load/mutate/save could save a stale payload over a
        permission write that landed in between and silently discard it.

        ``rule_id`` is the rule's canonical ``args_json``, the same string
        ``list_tool_arg_rules`` returns as ``rule_id``. ``profile_id`` must
        be the rule's OWNING profile -- the ``profile_id`` that listing
        reports, which for an inherited rule is an ANCESTOR of the profile
        being reviewed, not the reviewed profile itself.

        Returns:
            True only when a rule was actually removed -- a stale or
            unknown ``rule_id`` is a no-op, not an error.
        """

        def change(profile: dict[str, Any]) -> bool:
            server_entry = _as_mapping(profile.get("servers")).get(server_key)
            if not isinstance(server_entry, Mapping):
                return False
            tools = server_entry.get("tools")
            if not isinstance(tools, Mapping):
                return False
            tool_entry = tools.get(tool_name)
            if not isinstance(tool_entry, Mapping):
                return False
            rules = tool_entry.get("arg_rules")
            if not isinstance(rules, list):
                return False
            remaining = [
                rule
                for rule in rules
                if not (isinstance(rule, Mapping) and rule.get("args_json") == rule_id)
            ]
            if len(remaining) == len(rules):
                return False
            if remaining:
                tool_entry["arg_rules"] = remaining
            else:
                tool_entry.pop("arg_rules", None)
                if not tool_entry:
                    # Review round 1 (Critical): a state-less tool entry
                    # (only ever had arg_rules, e.g. an "always allow this
                    # exact input" with no whole-tool override) left an
                    # empty `{}` behind, which `_validate_strict_profile()`
                    # rejects (it requires "state" OR "arg_rules") -- that
                    # invalidated the WHOLE profile for `read_snapshot_
                    # strict()`/`read_profile_inventory_snapshot()` callers
                    # the moment the LAST rule was removed. Drop only the
                    # empty tool entry itself -- never cascades to
                    # `tools`/`server_entry`, which may still carry sibling
                    # tools or a server-level default.
                    tools.pop(tool_name, None)
            return True

        return self._mutate_profile_locked(
            profile_id,
            change,
            expected_profile_digest=None,
            expected_revision=None,
        )

    @staticmethod
    def _tool_entry(
        profile: Any, server_key: str, tool_name: str
    ) -> dict[str, Any] | None:
        """One tool's raw stored entry within ``profile``, or None --
        ``list_tool_arg_rules``' traversal (task-32281).

        Deliberately NOT shared with ``remove_tool_arg_rule``, which walks
        the same path inline because it also needs the parent ``tools``
        mapping in hand to drop a tool entry its last rule emptied.
        """
        if not isinstance(profile, Mapping):
            return None
        server_entry = _as_mapping(profile.get("servers")).get(server_key)
        if not isinstance(server_entry, Mapping):
            return None
        tools = server_entry.get("tools")
        if not isinstance(tools, Mapping):
            return None
        tool_entry = tools.get(tool_name)
        return tool_entry if isinstance(tool_entry, Mapping) else None

    @mcp_sources.guarded
    def mark_config_changed(
        self,
        server_key: str,
        tool_name: str,
        *,
        profile_id: str = _DEFAULT_PROFILE_ID,
        expected_profile_digest: str | None = None,
        expected_revision: int | None = None,
    ) -> bool:
        """Set ``config_changed: true`` on a tool entry.

        Args:
            server_key: Owning server's stable key.
            tool_name: Tool name within that server.
            profile_id: Profile to write; defaults to the ``default``
                profile (byte-identical to the pre-profiles behavior).

        Returns:
            True only on the not-already-set -> set transition (the
            emit-once signal Task 4 uses to append a single audit entry).
            Returns False -- without writing to disk or creating any
            entry -- when the marker is already set, so a resolution pass
            over a tool that is already downgraded does not rewrite the
            store file on every call.
        """

        def change(profile: dict[str, Any]) -> bool:
            servers = profile.get("servers", {})
            entry = servers.get(server_key, {})
            tools = entry.get("tools", {})
            tool_entry = tools.get(tool_name, {})
            if bool(tool_entry.get("config_changed")):
                return False

            servers = profile.setdefault("servers", {})
            entry = servers.setdefault(server_key, {})
            tools = entry.setdefault("tools", {})
            tool_entry = tools.setdefault(tool_name, {})
            tool_entry["config_changed"] = True
            return True

        return self._mutate_profile_locked(
            profile_id,
            change,
            expected_profile_digest=expected_profile_digest,
            expected_revision=expected_revision,
        )


# -- effective-state resolution (pure; no store I/O) -------------------------
#
# Everything below operates on a plain payload dict (the shape `load()`
# returns) and a `HubTool`. Nothing here reads or writes disk -- callers
# fetch the payload once (e.g. via `MCPPermissionStore.load()`) and resolve
# as many tools against it as they like.


def definition_hash(description: str | None, input_schema: dict | None) -> str:
    """Fingerprint a tool's advertised shape for the rug-pull guard.

    Mirrors ``LocalControlService._approval_fingerprint``'s canonicalization
    (``local_control_service.py``): sorted-key, compact-separator JSON,
    sha256 hex digest.

    Args:
        description: The tool's advertised description, if any.
        input_schema: The tool's advertised JSON input schema, if any.

    Returns:
        A sha256 hex digest fingerprinting ``description``/``input_schema``.
    """
    canonical = json.dumps(
        {"description": description or "", "inputSchema": input_schema or {}},
        sort_keys=True,
        default=str,
        separators=(",", ":"),
    )
    return hashlib.sha256(canonical.encode("utf-8")).hexdigest()


#: Permission namespace for the agent runtime's in-process built-in tools.
#: Deliberately NOT ``builtin:tldw_chatbook`` -- that key belongs to the
#: built-in MCP *server* (see ``readiness.BUILTIN_SERVER_KEY``), and sharing
#: it would let one decision govern two different execution paths. No MCP
#: routing label (``local:``/``builtin:``/``server:``) claims ``agent:``.
BUILTIN_TOOL_SERVER_KEY = "agent:builtin"

#: Server keys whose tools carry no meaningful ``definition_hash``, so
#: ``set_tool_state(..., "allow")`` does not require one, and
#: ``resolve_effective_state()`` skips its hash-staleness comparison for
#: them entirely (see the ``tool.server_key not in HASH_FREE_SERVER_KEYS``
#: guard in that function).
#:
#: The hash is a RUG-PULL guard: it detects a *remote* server changing a
#: tool's description/schema after the user trusted it. ``agent:builtin``
#: tools are in-process code shipped with the app -- an attacker who can
#: change them already has code execution, so the check protects nothing,
#: while a stored hash would force a re-prompt on every release that edits
#: a docstring. ``resolve_builtin_state`` correspondingly never reads one.
#:
#: ``builtin:tldw_chatbook`` (RAG-48 part 2) is exempted for the identical
#: reason: it is the built-in MCP *server*'s namespace (see
#: ``readiness.BUILTIN_SERVER_KEY``) -- also in-process code that ships
#: with the app and changes only via an app update, not a live remote
#: connection. Without this exemption, RAG-48 part 1 synthesizing a real
#: ``inputSchema`` for these tools (previously always ``None``) would make
#: every already-stored "allow" decision's definition_hash go stale on the
#: very next resolve, silently downgrading it to "ask" with "Definition
#: changed since you allowed it" -- a rug-pull false positive against the
#: app's own code, not an attacker.
#:
#: Adding a REMOTE namespace here would silently disable the rug-pull guard
#: for it; the contents are pinned by test.
HASH_FREE_SERVER_KEYS = frozenset({BUILTIN_TOOL_SERVER_KEY, "builtin:tldw_chatbook"})

#: Fix Round C (PR-T3 review), Item 2. The subset of ``HASH_FREE_SERVER_KEYS``
#: for which ``resolve_effective_state_by_key()``'s by-key ``allow``
#: exemption (see that function) is actually SAFE. Deliberately narrower
#: than ``HASH_FREE_SERVER_KEYS`` -- ``BUILTIN_TOOL_SERVER_KEY``
#: (``"agent:builtin"``) is a member of that wider set (it is hash-free too,
#: for the rug-pull reasons documented above) but is EXCLUDED here:
#:
#: * It never reaches ``resolve_effective_state_by_key()`` in production.
#:   Agent-runtime built-ins resolve exclusively through
#:   ``resolve_builtin_state()`` (``Agents/builtin_tool_gate.py``); the
#:   Hub's by-key seam (``UnifiedMCPControlPlaneService.gate_tool_test_by_key()``)
#:   is only ever called with a key drawn from the Hub tool catalog
#:   (``mcp_workbench.py``'s ``_last_hub_tools``), which never contains an
#:   ``agent:builtin`` row -- built-in-tool rows are namespaced under
#:   ``BUILTIN_TOOL_SERVER_KEY`` in a SIBLING section the matrix never
#:   threads into ``_last_hub_tools`` (see ``_builtin_permission_matrix_rows()``'s
#:   own docstring, "Constraint 1/5").
#: * If it ever did reach this resolver -- a future caller bug, not a
#:   config a user can produce -- exempting it here would be actively
#:   UNSAFE, not merely redundant. This function has no ``HubTool.tags`` to
#:   floor on, so its only defense against an inherited-allow high-risk
#:   tool is the "any allow collapses to ask" rule it narrows for hash-free
#:   keys. Real ``agent:builtin`` tools ARE floored -- by
#:   ``resolve_builtin_state()``'s own ``BUILTIN_HIGH_RISK_TAGS`` check --
#:   so a stray call landing on this seam for that key and getting the
#:   exemption would silently skip a floor its production resolver
#:   enforces.
#:
#: Built-in MCP definitions remain hash-free. ADR-183 character writes have
#: code-owned tags resolved through the live resolver even on the by-key path;
#: every other built-in keeps its historical tag-free behavior.
BY_KEY_HASH_FREE_SERVER_KEYS = frozenset({"builtin:tldw_chatbook"})

#: Precedence floor for built-in tools: they inherit ``allow`` rather than
#: the MCP ``global_default``, so changing MCP's posture never starts
#: prompting for calculator/datetime. High-risk tags still floor it to ask.
BUILTIN_DEFAULT_STATE = "allow"


@dataclass(frozen=True)
class GatedToolRef:
    """The minimum a resolver needs to gate one in-process tool.

    Deliberately not ``HubTool``: that type models a *hub* tool (its
    ``source`` enum is ``local|builtin|server``, and its ``stale``/
    ``executable``/tag-cap fields are meaningless here), and borrowing it
    would import MCP's hub model into the tools layer.
    """

    server_key: str
    name: str
    description: str
    input_schema: dict | None
    tags: tuple[str, ...]


@dataclass(frozen=True)
class EffectiveToolState:
    """The resolved allow/ask/deny verdict for one tool, plus why.

    Attributes:
        state: One of ``STORE_STATES``.
        origin: Which precedence level produced ``state`` before any
            downgrade -- ``tool_override``, ``server_default``,
            ``global_default``, or (built-in tools only, via
            ``resolve_builtin_state``) ``builtin_default``, the allow
            floor applied when nothing more specific overrides it.
            One SYNTHETIC value exists outside the precedence walk:
            ``gate_error``, constructed by ``MCPWorkbench`` (paired
            unconditionally with ``state="deny"``) when per-tool
            resolution RAISES -- a fail-closed verdict, not a configured
            state, which is why ``ui_label`` renders it "Unknown"
            (task-2870) and every copy surface derives its explanation
            from ``PERMISSION_STATE_UNRESOLVED_CLAUSE`` rather than
            claiming "Off".
        config_changed: True when an explicit tool-level ``allow`` was
            downgraded to ``ask`` by the rug-pull guard (hash mismatch
            and/or a persisted ``config_changed`` marker).
        risk_floored: True when an *inherited* ``allow`` was downgraded to
            ``ask`` by the high-risk floor.
    """

    state: str
    origin: str
    config_changed: bool = False
    risk_floored: bool = False

    @property
    def ui_label(self) -> str:
        # task-2870: `origin == "gate_error"` is the synthesized
        # fail-closed verdict -- the permission RESOLVER raised, not a
        # configured Off (`MCPWorkbench._resolve_test_gate()`/
        # `_effective_for_display()` pair it unconditionally with
        # `state="deny"`). Mapping it to "Off" made every renderer of this
        # property (Permissions matrix State cells, Tools-mode State
        # column, the inspector's permission block) print a confident
        # configuration claim about a state that could not be read -- the
        # contradiction PR #1385's round J removed from the inspector one
        # surface at a time. Owned HERE so every renderer tells the same
        # truth; severity/color is deliberately NOT this property's job
        # (`tool_state_kind()` keeps the fail-closed deny in the "error"
        # bucket -- the blocked EFFECT is real, only the causal label
        # lied).
        if self.origin == "gate_error":
            return "Unknown"
        # I2: second layer of defense against a hand-edited/corrupted
        # `mcp_permissions.json` whose `global_default` is some non-store
        # value (e.g. "banana") -- `resolve_effective_state()` itself now
        # falls back to `DEFAULT_GLOBAL` for that case, but this property
        # must never `KeyError` on an unrecognized `state` regardless of
        # how it got here (a future caller constructing `EffectiveToolState`
        # directly, a store format this code hasn't seen yet, ...): render
        # the raw state capitalized, or "Ask" for a falsy/empty one, rather
        # than raising and panicking whatever worker/render pass called
        # this (mcp_workbench.py's `_sync_children`, in particular).
        known = {"allow": "Allow", "ask": "Ask", "deny": "Off"}
        if self.state in known:
            return known[self.state]
        return self.state.capitalize() if self.state else "Ask"


def resolve_effective_state(
    payload: dict[str, Any],
    tool: HubTool,
    *,
    profile_id: str = _DEFAULT_PROFILE_ID,
) -> EffectiveToolState:
    """Resolve ``tool``'s effective permission state from ``payload``.

    Precedence: an explicit tool-level entry (``tool_override``) beats the
    owning server's ``default`` (``server_default``), which beats the
    profile's ``global_default`` (``global_default``); absence at each level
    means "inherit from the next level down".

    Named profiles: with ``profile_id`` other than ``"default"``, that
    full precedence walk runs against the named profile FIRST, and the
    default profile is consulted only for levels the named profile leaves
    unset -- i.e. the chain is per-level across ``[named, default]``:
    tool override in named, then server default in named, then
    global_default in named, then the same three levels in default, then
    ``DEFAULT_GLOBAL``. A named profile that sets a server default
    therefore shadows a default-profile tool override for that server,
    and a fresh empty named profile (seeded with no ``global_default``)
    resolves exactly like the default profile alone.

    Two downgrades apply on top of precedence, in order:

    1. Rug-pull guard: an explicit tool-level ``allow`` is downgraded to
       ``ask`` (``config_changed=True``) when the live tool's current
       ``definition_hash`` no longer matches the one stored alongside the
       ``allow``, or when the entry carries a persisted ``config_changed``
       marker -- regardless of whether the hash happens to match again.
       Only a fresh ``set_tool_state`` (Task 1) clears the marker. Skipped
       entirely (never downgrades, ``config_changed`` stays False) when
       ``tool.server_key`` is in ``HASH_FREE_SERVER_KEYS`` -- those
       namespaces store no ``definition_hash`` to begin with (RAG-48 part
       2), so comparing would always "mismatch" a live tool's real schema
       against the stored ``None`` and rug-pull every stored allow the
       first time a schema is attached.
    2. High-risk floor: an *inherited* ``allow`` (origin ``server_default``
       or ``global_default``) is downgraded to ``ask``
       (``risk_floored=True``) when the tool's tags intersect
       ``HIGH_RISK_TAGS``. Explicit tool-level ``allow`` is never floored --
       the operator opted in with full knowledge of the specific tool --
       except for the code-owned ``ALWAYS_ASK_TOOLS`` pairs, which floor
       every ``allow`` (TASK-32956).

    Both downgrades run after the profile walk, regardless of which
    profile supplied the verdict.

    Every nested container this walks (``profiles``, each profile in the
    chain, ``servers``, a server entry, its ``tools``, a tool entry) is
    coerced via ``_as_mapping()`` before being read, so a hand-edited
    ``mcp_permissions.json`` with ``null`` (or other non-mapping junk) at
    any of those levels resolves the same as an absent one instead of
    raising ``AttributeError`` -- this function takes a raw payload and
    must be safe standalone, independent of ``MCPPermissionStore.load()``'s
    own normalization.

    Args:
        payload: A permission-store payload dict (the shape ``load()``
            returns, or any raw dict -- this function does not assume it
            has already been normalized).
        tool: The live tool to resolve, used for its ``server_key``,
            ``name``, ``description``/``input_schema`` (hash comparison),
            and ``tags`` (high-risk floor).
        profile_id: Profile to resolve against; ``"default"`` (the
            default) is byte-identical to the pre-profiles behavior.

    Returns:
        The resolved ``EffectiveToolState``.
    """
    lifecycle_block = _lifecycle_resolution_block(payload, profile_id)
    if lifecycle_block is not None:
        return EffectiveToolState(state="deny", origin=lifecycle_block)

    config_changed = False
    state: str | None = None
    origin = ""

    for profile in _profile_chain(payload, profile_id):
        servers = _as_mapping(profile.get("servers"))
        server_entry = _as_mapping(servers.get(tool.server_key))
        tools = _as_mapping(server_entry.get("tools"))
        tool_entry = tools.get(tool.name)
        if not isinstance(tool_entry, Mapping):
            tool_entry = None

        if tool_entry is not None and tool_entry.get("state") in STORE_STATES:
            origin = "tool_override"
            state = tool_entry["state"]
            if state == "allow" and tool.server_key not in HASH_FREE_SERVER_KEYS:
                current_hash = definition_hash(tool.description, tool.input_schema)
                stale_hash = tool_entry.get("definition_hash") != current_hash
                marked_changed = bool(tool_entry.get("config_changed"))
                if stale_hash or marked_changed:
                    state = "ask"
                    config_changed = True
            break

        server_default = server_entry.get("default")
        if server_default in STORE_STATES:
            origin = "server_default"
            state = server_default
            break

        global_default = profile.get("global_default")
        if global_default in STORE_STATES:
            origin = "global_default"
            state = global_default
            break
        # Nothing at any precedence level in this profile: inherit from
        # the next profile in the chain (named -> default).

    if state is None:
        # Chain exhausted with no valid verdict anywhere -- including the
        # I2 case of a hand-edited `mcp_permissions.json` carrying an
        # invalid `global_default` (e.g. "banana") in every profile that
        # passes `load()`'s corruption check. Fail safe to the same
        # default a missing key already gets, never the raw junk value
        # (which used to `KeyError` out of `ui_label` and panic the app).
        origin = "global_default"
        state = DEFAULT_GLOBAL

    risk_floored = False
    if state == "allow" and (
        (origin != "tool_override" and set(tool.tags) & HIGH_RISK_TAGS)
        or (tool.server_key, tool.name) in ALWAYS_ASK_TOOLS
    ):
        state = "ask"
        risk_floored = True

    return EffectiveToolState(
        state=state,
        origin=origin,
        config_changed=config_changed,
        risk_floored=risk_floored,
    )


def _canonical_args_json(args: Mapping[str, Any]) -> str:
    """One canonical rendering of a call's arguments for exact-match rules."""
    try:
        # default=str is effectively dead: tool args arrive as JSON from the
        # model and are always serializable. It exists only so a freak
        # unserializable value canonicalizes to *something* rather than
        # raising; two such values could collide, but neither reaches here
        # in practice and a collision only ever WIDENS to a re-prompt (the
        # rule is compared for equality, and the tool still executes).
        return json.dumps(dict(args), sort_keys=True, ensure_ascii=False, default=str)
    except Exception:  # noqa: BLE001 -- unserializable args never match a rule
        return ""


def arg_rule_allows(
    payload: dict[str, Any],
    tool: HubTool,
    args: Mapping[str, Any],
    *,
    profile_id: str = _DEFAULT_PROFILE_ID,
) -> bool:
    """Whether a stored argument-scoped rule allows this exact call.

    TASK-26012. Two rule shapes:

    * ``{"args_json": ...}`` -- exact canonical-arguments match, the only
      shape the approval card ever writes.
    * ``{"field": ..., "pattern": ...}`` -- an fnmatch glob against ONE
      string argument, for hand-written rules.

    Hard limits, in order: a tool whose tags intersect ``HIGH_RISK_TAGS``
    is NEVER quieted by an argument rule (AC#5 -- the floor beats the
    rule), and a rule whose ``definition_hash`` no longer matches the live
    tool is inert (AC#4 -- same rug-pull guard as tool-level allow;
    ``HASH_FREE_SERVER_KEYS`` namespaces skip the comparison).

    The profile chain walks like ``resolve_effective_state``: the first
    profile carrying rules for this tool decides.
    """
    if set(tool.tags) & HIGH_RISK_TAGS:
        return False
    current_hash = (
        None
        if tool.server_key in HASH_FREE_SERVER_KEYS
        else definition_hash(tool.description, tool.input_schema)
    )
    call_json = _canonical_args_json(args)
    for profile in _profile_chain(payload, profile_id):
        servers = _as_mapping(profile.get("servers"))
        server_entry = _as_mapping(servers.get(tool.server_key))
        tools = _as_mapping(server_entry.get("tools"))
        tool_entry = tools.get(tool.name)
        if not isinstance(tool_entry, Mapping):
            continue
        rules = tool_entry.get("arg_rules")
        if not isinstance(rules, list) or not rules:
            continue
        for rule in rules:
            if not isinstance(rule, Mapping):
                continue
            if (
                current_hash is not None
                and rule.get("definition_hash") != current_hash
            ):
                continue
            args_json = rule.get("args_json")
            if isinstance(args_json, str) and args_json and args_json == call_json:
                return True
            field = rule.get("field")
            pattern = rule.get("pattern")
            if (
                isinstance(field, str)
                and isinstance(pattern, str)
                and isinstance(args.get(field), str)
                and fnmatch.fnmatchcase(args[field], pattern)
            ):
                return True
        return False
    return False


def resolve_builtin_state(
    payload: dict[str, Any],
    tool: GatedToolRef,
    *,
    profile_id: str = _DEFAULT_PROFILE_ID,
) -> EffectiveToolState:
    """Resolve a built-in tool's effective permission state.

    Mirrors ``resolve_effective_state``'s precedence walk (including its
    named-profile chain: the named profile's tool/server levels shadow the
    default profile's, level by level) with two deliberate differences:

    * The final fallback is ``BUILTIN_DEFAULT_STATE`` (``allow``), not any
      profile's ``global_default`` -- the global level is skipped entirely
      in every profile. Built-ins are in-process code the user already
      installed; inheriting MCP's ``ask`` would prompt on every calculator
      call, and changing MCP's global posture (in any profile) must not
      silently change built-in behavior.
    * No ``definition_hash`` comparison. That guard exists for a REMOTE
      server mutating a tool after you trusted it; for in-process code an
      attacker who can change the tool already has code execution, so it
      buys nothing -- while any release editing a description or schema
      would flip ``config_changed`` and re-prompt every user at upgrade
      time. ``config_changed`` is therefore always False here.

    The high-risk floor: an INHERITED ``allow`` (not an explicit tool
    override) whose tags intersect ``BUILTIN_HIGH_RISK_TAGS`` is
    downgraded to ``ask`` with ``risk_floored=True``. That set is a
    superset of MCP's ``HIGH_RISK_TAGS`` -- built-ins additionally floor
    on ``"reads"`` and ``"network"``.

    Args:
        payload: A loaded permission-store payload (``{}`` is valid and
            resolves everything to the floor).
        tool: The built-in tool reference to resolve.
        profile_id: Profile to resolve against; ``"default"`` (the
            default) is byte-identical to the pre-profiles behavior.

    Returns:
        The resolved ``EffectiveToolState``.
    """
    lifecycle_block = _lifecycle_resolution_block(payload, profile_id)
    if lifecycle_block is not None:
        return EffectiveToolState(state="deny", origin=lifecycle_block)

    state: str | None = None
    origin = ""

    for profile in _profile_chain(payload, profile_id):
        servers = _as_mapping(profile.get("servers"))
        server_entry = _as_mapping(servers.get(tool.server_key))
        tools = _as_mapping(server_entry.get("tools"))
        tool_entry = tools.get(tool.name)
        if not isinstance(tool_entry, Mapping):
            tool_entry = None

        if tool_entry is not None and tool_entry.get("state") in STORE_STATES:
            origin = "tool_override"
            state = tool_entry["state"]
            break

        server_default = server_entry.get("default")
        if server_default in STORE_STATES:
            origin = "server_default"
            state = server_default
            break
        # Built-ins never read any profile's global_default (see the
        # docstring): this profile contributes nothing, inherit from the
        # next profile in the chain (named -> default).

    if state is None:
        origin = "builtin_default"
        state = BUILTIN_DEFAULT_STATE

    risk_floored = False
    if (
        origin != "tool_override"
        and state == "allow"
        and set(tool.tags) & BUILTIN_HIGH_RISK_TAGS
    ):
        state = "ask"
        risk_floored = True

    return EffectiveToolState(
        state=state,
        origin=origin,
        config_changed=False,
        risk_floored=risk_floored,
    )


def resolve_effective_state_by_key(
    payload: dict[str, Any],
    server_key: str,
    tool_name: str,
    *,
    profile_id: str = _DEFAULT_PROFILE_ID,
) -> EffectiveToolState:
    """Resolve ``(server_key, tool_name)``'s effective permission state
    from ``payload`` alone -- no live ``HubTool`` to fingerprint.

    I1: the Test Tool gate (``UnifiedMCPControlPlaneService.gate_tool_test()``)
    needs a live ``HubTool`` to hash-compare against a stored
    ``definition_hash`` (the rug-pull guard). When a tool has dropped out
    of the workbench's catalog snapshot since it was selected -- a stale
    selection, or a resync racing a rug-pull refresh -- there is no
    ``HubTool`` left to gate with, and ``test_hub_tool()``/
    ``execute_external_tool()`` need no ``HubTool`` either (they dispatch
    by ``server_key``/``tool_name`` alone against the live server). Falling
    through ungated in that gap would let a DENIED tool run just because
    it briefly vanished from the snapshot. This resolves the same
    precedence walk as ``resolve_effective_state`` (tool override -> server
    default -> global default, with the same global-default validation
    and the same named-profile chain: the named profile's levels shadow
    the default profile's, level by level) but skips the hash comparison
    entirely:

    - ``deny``/``ask`` verdicts (explicit or inherited) are trustworthy
      without a hash check -- there is nothing to downgrade a deny or ask
      to that would be safer -- so they resolve at full fidelity.
    - Any verdict that resolves to ``allow`` -- an explicit tool-level
      override, or an inherited server/global default -- cannot be
      confirmed fresh without the tool's current description/input_schema
      to hash-compare, so it resolves to ``ask`` instead
      (``config_changed=True``, reusing the rug-pull marker's "review
      before trusting this" UI treatment): safer than silently trusting a
      stale ``allow``. **Except** for ``server_key in
      BY_KEY_HASH_FREE_SERVER_KEYS`` -- today, just
      ``"builtin:tldw_chatbook"``, the built-in MCP server. This is
      DELIBERATELY NARROWER than ``HASH_FREE_SERVER_KEYS``: see that
      constant's own docstring for why ``BUILTIN_TOOL_SERVER_KEY``
      (``"agent:builtin"``, the OTHER hash-free key) is excluded from the
      exemption on THIS path even though it is hash-free too. For the keys
      that remain exempt: they're already exempt from the hash comparison
      in ``resolve_effective_state()`` for the reason documented on
      ``HASH_FREE_SERVER_KEYS`` -- they're app code, not a remote server,
      so there is no staleness to guard against -- and the rationale for
      THIS collapse ("cannot be confirmed fresh without a hash to compare")
      is void when there was never going to be a hash comparison in the
      first place. An explicit or inherited ``Allow`` for one of those keys
      resolves at full fidelity, same as ``resolve_effective_state()``
      would with a live ``HubTool``. Without this exemption, the SAME
      hash-free tool set to Allow would record ``decision="approved"``
      (asked-and-approved) when resolved here and ``decision="allowed"``
      when resolved via ``resolve_effective_state()`` -- a cross-surface
      split in the audit trail.

    ADR-183 character writes have trusted code-owned risk tags and delegate to
    the catalog-backed resolver even without a catalog snapshot. This preserves
    inherited-allow flooring and explicit overrides on both paths. Other
    hash-free built-ins retain their existing tag-free behavior.

    For every server key NOT in ``BY_KEY_HASH_FREE_SERVER_KEYS``, flooring
    genuinely is redundant to check separately: the "any allow downgrades
    to ask" rule above already collapses every such inherited allow before
    a tag comparison would ever matter, which is the strictly-more-
    conservative relationship the phrase originally described here --
    it just no longer describes ALL server keys.

    Like ``resolve_effective_state()``, every nested container this walks
    is coerced via ``_as_mapping()`` before being read, so a hand-edited
    ``mcp_permissions.json`` with ``null`` (or other non-mapping junk) at
    any level resolves the same as an absent one instead of raising
    ``AttributeError``.

    Args:
        payload: A permission-store payload dict (the shape ``load()``
            returns, or any raw dict -- this function does not assume it
            has already been normalized).
        server_key: Owning server's stable key.
        tool_name: Tool name within that server.
        profile_id: Profile to resolve against; ``"default"`` (the
            default) is byte-identical to the pre-profiles behavior.

    Returns:
        The resolved ``EffectiveToolState``.
    """
    from .builtin_tool_policy import BUILTIN_MCP_SERVER_KEY, builtin_tool_risk_tags

    trusted_tags = builtin_tool_risk_tags(tool_name)
    if server_key == BUILTIN_MCP_SERVER_KEY and trusted_tags:
        return resolve_effective_state(
            payload,
            GatedToolRef(server_key, tool_name, "", None, trusted_tags),
            profile_id=profile_id,
        )
    lifecycle_block = _lifecycle_resolution_block(payload, profile_id)
    if lifecycle_block is not None:
        return EffectiveToolState(state="deny", origin=lifecycle_block)

    state: str | None = None
    origin = ""

    for profile in _profile_chain(payload, profile_id):
        servers = _as_mapping(profile.get("servers"))
        server_entry = _as_mapping(servers.get(server_key))
        tools = _as_mapping(server_entry.get("tools"))
        tool_entry = tools.get(tool_name)
        if not isinstance(tool_entry, Mapping):
            tool_entry = None

        if tool_entry is not None and tool_entry.get("state") in STORE_STATES:
            origin = "tool_override"
            state = tool_entry["state"]
            break

        server_default = server_entry.get("default")
        if server_default in STORE_STATES:
            origin = "server_default"
            state = server_default
            break

        global_default = profile.get("global_default")
        if global_default in STORE_STATES:
            origin = "global_default"
            state = global_default
            break
        # Nothing at any precedence level in this profile: inherit from
        # the next profile in the chain (named -> default).

    if state is None:
        # Chain exhausted with no valid verdict anywhere -- same I2
        # hand-edited-junk fallback as resolve_effective_state().
        origin = "global_default"
        state = DEFAULT_GLOBAL

    if state == "allow" and server_key not in BY_KEY_HASH_FREE_SERVER_KEYS:
        return EffectiveToolState(state="ask", origin=origin, config_changed=True)
    return EffectiveToolState(state=state, origin=origin)


#: Wave B (2026-09-11 MCP Hub UX program): the ring starts at Ask, not
#: Allow -- the most permissive state must never be the first stop from
#: Inherit (the default posture), so a stray first Space press grants
#: nothing. `_CYCLE_GLOBAL_STATES` below needs no change: from the global
#: default ("ask") one press already goes to "deny", and Allow is only
#: reachable from "deny" -- Allow is never the first press from the
#: default posture there either.
_CYCLE_UI_STATES: dict[str | None, str | None] = {
    None: "ask",
    "ask": "allow",
    "allow": "deny",
    "deny": None,
}

_CYCLE_GLOBAL_STATES: dict[str, str] = {
    "allow": "ask",
    "ask": "deny",
    "deny": "allow",
}


def cycle_ui_state(current: str | None) -> str | None:
    """Advance a per-server/per-tool state one Space-press.

    Args:
        current: The current stored state, or None for "Inherit".

    Returns:
        The next state in the cycle: Inherit -> Ask -> Allow -> Off ->
        Inherit (None). Ask leads the ring (Wave B) so the most
        permissive state is never the first press from Inherit.
    """
    return _CYCLE_UI_STATES[current]


def cycle_global(current: str) -> str:
    """Advance the global default one Space-press (no Inherit option).

    Args:
        current: The current global default state, one of ``STORE_STATES``.

    Returns:
        The next state in the cycle: Allow -> Ask -> Off -> Allow.
    """
    return _CYCLE_GLOBAL_STATES[current]

# Callable provenance captured at definition time; no native authority is retained.
_CONSOLE_STANDARD_METHODS = (
    ("load", MCPPermissionStore.load),
    ("get_kill_switch", MCPPermissionStore.get_kill_switch),
    ("mark_config_changed", MCPPermissionStore.mark_config_changed),
)


# TASK-34561: only the two original guarded members used by the omitted getter.
# The known decorator's function cell is captured here, never lazily unwrapped.
_CONSOLE_CONTROLLER_PERMISSION_MODULE = sys.modules[__name__]
_CONSOLE_CONTROLLER_PERMISSION_CLASS = MCPPermissionStore


def _capture_controller_inputs(function):
    keyword_defaults = function.__kwdefaults__
    closure = function.__closure__
    return (
        function.__defaults__,
        keyword_defaults,
        tuple(dict.items(keyword_defaults)) if keyword_defaults is not None else (),
        closure,
        tuple((cell, cell.cell_contents) for cell in closure or ()),
    )


def _capture_controller_permission_member(name):
    wrapper = vars(MCPPermissionStore)[name]
    guard = mcp_sources.guarded
    if type(wrapper) is not FunctionType or type(guard) is not FunctionType:
        return name, wrapper, ()
    wrapper_codes = tuple(
        code
        for code in guard.__code__.co_consts
        if type(code) is type(guard.__code__) and code.co_name == "wrapped"  # exact original code
    )
    if (
        len(wrapper_codes) != 1
        or wrapper.__code__ is not wrapper_codes[0]
        or wrapper.__globals__ is not vars(mcp_sources)
        or wrapper.__closure__ is None
        or "function" not in wrapper.__code__.co_freevars
    ):
        return name, wrapper, ()
    try:
        body = wrapper.__closure__[
            wrapper.__code__.co_freevars.index("function")
        ].cell_contents
    except ValueError:
        return name, wrapper, ()
    if type(body) is not FunctionType or body.__globals__ is not globals():
        return name, wrapper, ()
    return (
        name,
        wrapper,
        tuple(
            (
                function,
                function.__code__,
                function.__globals__,
                sys.modules[function.__globals__["__name__"]],
                _capture_controller_inputs(function),
            )
            for function in (wrapper, body)
        ),
    )


_CONSOLE_CONTROLLER_PERMISSION_METHODS = tuple(
    _capture_controller_permission_member(name) for name in ("get_kill_switch", "load")
)


# The named Console read skips only these original forwarding/fence members.
_CONSOLE_OWNED_LOAD_MEMBERS = tuple(
    _capture_controller_permission_member(name) for name in ("load", "_load_locked")
) + (
    (
        "mutation_fence",
        MCPPermissionStore.mutation_fence,
        tuple(
            (
                function,
                function.__code__,
                function.__globals__,
                sys.modules[function.__globals__["__name__"]],
                _capture_controller_inputs(function),
            )
            for function in (
                MCPPermissionStore.mutation_fence,
                MCPPermissionStore.mutation_fence.__wrapped__,
            )
        ),
    ),
    _capture_controller_permission_member("_backup_corrupt_file"),
)


def _console_owned_load_current(source, captured) -> bool:
    """Check captured stock inputs without filesystem or permission reads."""
    from types import MethodType

    def inputs_current(function, inputs):
        defaults, keywords, items, closure, cells = inputs
        try:
            cells_current = all(cell.cell_contents is value for cell, value in cells)
        except ValueError:
            return False
        return (
            function.__defaults__ is defaults
            and function.__kwdefaults__ is keywords
            and function.__closure__ is closure
            and cells_current
            and (
                keywords is None
                or len(keywords) == len(items)
                and all(
                    key in keywords and keywords[key] is value for key, value in items
                )
            )
        )

    if (
        type(captured) is not tuple  # exact internal metadata tuple.
        or len(captured) != 4
        or captured[0] is not source
        or type(source) is not _CONSOLE_CONTROLLER_PERMISSION_CLASS
        or MCPPermissionStore is not _CONSOLE_CONTROLLER_PERMISSION_CLASS
        or sys.modules.get(__name__) is not _CONSOLE_CONTROLLER_PERMISSION_MODULE
        or vars(_CONSOLE_CONTROLLER_PERMISSION_MODULE) is not globals()
    ):
        return False
    for name, function, code, namespace, inputs in _CONSOLE_OWNED_LOAD_HELPERS:
        if (
            globals().get(name) is not function
            or function.__code__ is not code
            or function.__globals__ is not namespace
            or not inputs_current(function, inputs)
        ):
            return False
    for name, wrapper, bodies in _CONSOLE_OWNED_LOAD_MEMBERS:
        if (
            len(bodies) != 2
            or vars(MCPPermissionStore).get(name) is not wrapper
            or getattr(wrapper, "__wrapped__", None) is not bodies[1][0]
        ):
            return False
        callback = getattr(source, name, None)
        if (
            type(callback) is not MethodType  # exact bound method.
            or callback.__func__ is not wrapper
            or callback.__self__ is not source
        ):
            return False
        for function, code, namespace, module, inputs in bodies:
            if (
                function.__code__ is not code
                or function.__globals__ is not namespace
                or sys.modules.get(namespace["__name__"]) is not module
                or vars(module) is not namespace
                or not inputs_current(function, inputs)
            ):
                return False
    raw = sys.modules.get("tldw_chatbook.Backup_Recovery.raw_participants")
    package = sys.modules.get("tldw_chatbook.Backup_Recovery")
    if (
        raw is None
        or package is None
        or vars(package).get("raw_participants") is not raw
    ):
        return False
    guards = getattr(raw, "_CONSOLE_PERMISSION_LOAD_GUARDS", None)
    if guards is None:
        return False
    for name, callback, bodies in guards:
        if (
            vars(raw).get(name) is not callback
            or name == "_scope"
            and getattr(callback, "__wrapped__", None) is not bodies[1][0]
        ):
            return False
        for function, code, namespace, module, inputs in bodies:
            if (
                function.__code__ is not code
                or function.__globals__ is not namespace
                or sys.modules.get(namespace["__name__"]) is not module
                or vars(module) is not namespace
                or not inputs_current(function, inputs)
            ):
                return False
    _, binding, selected, lock = captured
    if (
        binding is None
        or mcp_sources._BINDINGS.get(source) is not binding
        or binding.source_type is not type(source)
        or type(selected) is not type(binding.selected)  # native immutable Path metadata.
        or binding.selected != selected
        or source.path is not selected
        or source._path_lock is not lock
        or source._mutation_lock is not lock
        or source._mcp_source_lock is not lock
    ):
        return False
    with _PATH_LOCKS_GUARD:
        return _PATH_LOCKS.get(selected) is lock


def _capture_console_owned_load(source) -> tuple[Any, ...] | None:
    """Capture original Console load metadata before its source scope is issued."""
    checker = _CONSOLE_OWNED_LOAD_HELPERS[1]
    if (
        globals().get(checker[0]) is not checker[1]
        or checker[1].__code__ is not checker[2]
    ):
        return None
    try:
        binding = mcp_sources._BINDINGS.get(source)
        if binding is None or type(source.path) is not type(binding.selected):  # custom path protocols retain ordinary calls.
            return None
        captured = (source, binding, source.path, source._path_lock)
        return captured if _console_owned_load_current(source, captured) else None
    except (AttributeError, TypeError, ValueError):
        return None


def _load_in_owned_scope(source, operation, captured) -> dict[str, Any]:
    """Read the original payload inside the named caller's checked source scope.

    The caller must retain its existing final native check and source receipt.
    This private helper grants no admission and never creates an operation.
    """
    from tldw_chatbook.Backup_Recovery import raw_participants as raw
    from tldw_chatbook.Backup_Recovery import storage_admission as storage

    state = None

    def checked_state():
        checker = _CONSOLE_OWNED_LOAD_HELPERS[1]
        if (
            globals().get(checker[0]) is not checker[1]
            or checker[1].__code__ is not checker[2]
            or not _console_owned_load_current(source, captured)
        ):
            raise mcp_sources.bootstrap.RecoveryRequired("mcp_source_selection_changed")
        with storage._lock:
            if getattr(raw._local, "operation", None) is not operation:
                raise mcp_sources.bootstrap.RecoveryRequired(
                    "raw_operation_provenance_invalid"
                )
            current = raw._live_state(operation, None, True)
            if (
                current.source is not source
                or current.route != mcp_sources.ROUTE
                or current.participant is None
                or current.selected != captured[2]
                or raw._participant_identity(current.participant).source() is not source
            ):
                raise mcp_sources.bootstrap.RecoveryRequired("mcp_source_not_installed")
            return current

    try:
        state = checked_state()
        fence = _CONSOLE_OWNED_LOAD_MEMBERS[2][1]
        body = _CONSOLE_OWNED_LOAD_MEMBERS[1][2][1][0]
        with fence(source):
            if checked_state() is not state:
                raise mcp_sources.bootstrap.RecoveryRequired(
                    "raw_operation_provenance_invalid"
                )
            result = body(source)
            if checked_state() is not state:
                raise mcp_sources.bootstrap.RecoveryRequired(
                    "raw_operation_provenance_invalid"
                )
            return result
    except BaseException:
        if state is not None and (state.mcp_effects or state.uncertain):
            source._mcp_persistence_error = "mcp_persistence_incomplete"
        raise


_CONSOLE_OWNED_LOAD_HELPERS = tuple(
    (
        name,
        function,
        function.__code__,
        function.__globals__,
        _capture_controller_inputs(function),
    )
    for name in (
        "_capture_console_owned_load",
        "_console_owned_load_current",
        "_load_in_owned_scope",
    )
    for function in (globals()[name],)
)
