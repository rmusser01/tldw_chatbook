from __future__ import annotations

import ipaddress
import json
import re
from collections.abc import Callable, Mapping
from dataclasses import dataclass, field

# ADR-097 boot ratchet: deferred off the boot path (loads on first use). (spawn_guard imports at the save-time check.)
from datetime import datetime, timezone
from pathlib import Path
from types import MappingProxyType, MethodType
from typing import Any, Literal
from urllib.parse import urlsplit
from uuid import uuid4

from tldw_chatbook.Backup_Recovery import mcp_source_participants as mcp_sources
from tldw_chatbook.Utils.datetime_codec import datetime_to_iso, iso_to_datetime

_LOCAL_MCP_STORE_FILENAME = "local_mcp_store.json"


def _default_local_mcp_store_path() -> Path:
    """Return this store's path when constructed with no explicit argument.

    Derives from ``config.get_user_data_dir()`` -- the same directory every
    real construction site (``app.py``) already passes explicitly -- rather
    than a stale, eagerly-computed module constant. Resolution happens
    lazily, at call time, because ``get_user_data_dir()`` reads the active
    profile/config: baking a value in at import time would freeze whichever
    profile happened to be active the first time this module loaded, which
    is exactly the kind of latent drift TASK-855 exists to close (see
    ``MCP.unified_control_plane_service``'s ``permission_store``/
    ``execution_log`` properties, which derive the permission store and
    execution log paths from this store's own ``.path`` via
    ``Path(store.path).with_name(...)`` -- a store built with no argument
    anywhere would silently place both outside
    ``Utils.sensitive_paths``' denylist coverage).

    Returns:
        ``get_user_data_dir() / "local_mcp_store.json"``.
    """
    from tldw_chatbook.config import get_user_data_dir

    return get_user_data_dir() / _LOCAL_MCP_STORE_FILENAME


_ENV_PLACEHOLDER_PATTERN = re.compile(
    r"^\$(?:\{[A-Za-z_][A-Za-z0-9_]*\}|[A-Za-z_][A-Za-z0-9_]*)$"
)
_SECRET_KEY_PATTERN = re.compile(
    r"(secret|token|password|passwd|api[_-]?key|access[_-]?key)", re.IGNORECASE
)
_SECRET_VALUE_PATTERNS = (
    re.compile(r"^sk-[A-Za-z0-9._-]{12,}$"),
    re.compile(r"^gh[pousr]_[A-Za-z0-9]{12,}$"),
    re.compile(r"^xox[baprs]-[A-Za-z0-9-]{12,}$"),
    re.compile(r"^eyJ[A-Za-z0-9_-]+\.[A-Za-z0-9._-]+\.[A-Za-z0-9._-]+$"),
)
_SAFE_LITERAL_VALUES = {
    "0",
    "1",
    "true",
    "false",
    "yes",
    "no",
    "on",
    "off",
    "enabled",
    "disabled",
    "debug",
    "info",
    "warning",
    "warn",
    "error",
    "critical",
    "trace",
}
_SAFE_INTEGER_PATTERN = re.compile(r"^[0-9]{1,5}$")
_SAFE_DECIMAL_PATTERN = re.compile(r"^[0-9]{1,4}\.[0-9]{1,2}$")
_SAFE_URL_LITERAL_PATTERN = re.compile(
    r"^https?://[A-Za-z0-9.-]+(?::[0-9]{1,5})?(?:/[^\s]*)?$", re.IGNORECASE
)
# A non-secret filesystem path (workspace root, config/db path) is a safe
# operational literal — the most common stdio-MCP-server env value. Mirrors
# _LEGACY_SAFE_PATH_PATTERN so the strict and legacy env paths agree; the
# secret guards (_is_secret_bearing_env_key / _looks_like_raw_secret_value)
# still run first, so a token that happens to be path-shaped is rejected.
_SAFE_PATH_LITERAL_PATTERN = re.compile(r"^(?:~|/)[A-Za-z0-9._/@:+-]{1,255}$")
# Token separators in paths / URLs / query strings — used to extract candidate
# secret segments from an otherwise-safe-looking literal.
_SECRET_SEGMENT_SPLIT = re.compile(r"[/?&=:@~]+")
_LEGACY_SAFE_URL_LITERAL_PATTERN = re.compile(
    r"^[A-Za-z][A-Za-z0-9+.-]*://[^\s]{1,255}$"
)
_LEGACY_SAFE_TOKEN_PATTERN = re.compile(r"^[A-Za-z0-9][A-Za-z0-9._:-]{0,127}$")
_LEGACY_SAFE_PATH_PATTERN = re.compile(r"^(?:~|/)[A-Za-z0-9._/@:+-]{1,255}$")


class LocalMCPStoreLoadError(RuntimeError):
    def __init__(self, path: Path, reason: Exception) -> None:
        self.path = Path(path)
        self.reason = reason
        super().__init__(f"Failed to load local MCP store from '{self.path}': {reason}")


def _require_non_empty_field(value: str, field_name: str, record_type: str) -> str:
    normalized = _text(value)
    if not normalized:
        raise ValueError(f"{record_type} requires non-empty {field_name}")
    return normalized


_PROFILE_ID_INVALID_CHARS_RE = re.compile(r"[:\s]")
_RESERVED_EXTERNAL_PROFILE_IDS = frozenset({"__local__", "__virtual_cli__"})


def _validate_profile_id(value: str) -> str:
    """Validate a local MCP profile id at the single save-time choke point.

    I3 (Phase 3 review, minimum scope -- the full tuple-identity refactor
    for HubTool routing is deferred to Phase 4): `HubTool.tool_id` packs
    `server_key` and tool name into one `"::"`-delimited string
    (`f"local:{profile_id}::{tool_name}"`), and callers partition it back
    apart on the first `"::"` (see `MCPWorkbench._run_tool_test()`). A
    profile id containing its own `":"` corrupts that partition -- e.g.
    profile_id `"a::b"` makes `tool_id` `"local:a::b::search"` split into
    server_key `"local:a"` / tool `"b::search"` instead of the intended
    profile `"a::b"` / tool `"search"`, silently executing against the
    wrong server. Colons (and, for the same "no legitimate use, only
    ambiguity" reason, embedded whitespace) have no legitimate use in a
    profile id here, so both are rejected outright rather than merely
    discouraged.
    """
    normalized = _require_non_empty_field(value, "profile_id", "Local MCP profile")
    if normalized in _RESERVED_EXTERNAL_PROFILE_IDS:
        raise ValueError("Local MCP profile profile_id is reserved")
    if _PROFILE_ID_INVALID_CHARS_RE.search(normalized):
        raise ValueError(
            "Local MCP profile profile_id must not contain ':' or whitespace"
        )
    return normalized


def _datetime_to_iso(value: datetime | None) -> str | None:
    return datetime_to_iso(value)


def _iso_to_datetime(value: Any) -> datetime | None:
    return iso_to_datetime(value)


def _text(value: Any) -> str:
    return str(value or "").strip()


def _coerce_mapping(value: Any) -> dict[str, Any]:
    if not isinstance(value, Mapping):
        return {}
    return {str(key): item for key, item in value.items()}


def _sanitize_env(env: Mapping[str, Any] | None) -> dict[str, str]:
    sanitized: dict[str, str] = {}
    for raw_key, raw_value in (env or {}).items():
        key = _text(raw_key)
        value = _text(raw_value)
        if not key or not value:
            continue
        if _ENV_PLACEHOLDER_PATTERN.fullmatch(value):
            sanitized[key] = value
            continue
        if _SECRET_KEY_PATTERN.search(key):
            raise ValueError(f"Secret-bearing env key '{key}' must use a placeholder")
        sanitized[key] = value
    return sanitized


def _is_secret_bearing_env_key(key: str) -> bool:
    return bool(_SECRET_KEY_PATTERN.search(key))


def _looks_like_raw_secret_value(value: str) -> bool:
    # Full-match the whole value AND every token segment, so a secret can't be
    # smuggled past the anchored patterns inside a path, URL, or query string
    # (e.g. "~/sk-live-…", "/foo/ghp_…", "https://h/p?key=sk-live-…") now that
    # paths and URLs are accepted literals. Split on the delimiters that
    # separate tokens in those forms.
    candidates = [value, *(seg for seg in _SECRET_SEGMENT_SPLIT.split(value) if seg)]
    return any(
        pattern.fullmatch(candidate)
        for candidate in candidates
        for pattern in _SECRET_VALUE_PATTERNS
    )


def _is_safe_literal_value(value: str) -> bool:
    normalized = value.strip().lower()
    if normalized in _SAFE_LITERAL_VALUES:
        return True
    if _SAFE_INTEGER_PATTERN.fullmatch(normalized):
        return True
    if _SAFE_DECIMAL_PATTERN.fullmatch(normalized):
        return True
    if _SAFE_URL_LITERAL_PATTERN.fullmatch(value.strip()):
        return True
    if _SAFE_PATH_LITERAL_PATTERN.fullmatch(value.strip()):
        return True
    return False


def _coerce_legacy_env(
    legacy_env: Mapping[str, Any] | None,
) -> tuple[dict[str, str], dict[str, str]]:
    placeholders: dict[str, str] = {}
    literals: dict[str, str] = {}
    for raw_key, raw_value in (legacy_env or {}).items():
        key = _text(raw_key)
        value = _text(raw_value)
        if not key or not value:
            continue
        if _ENV_PLACEHOLDER_PATTERN.fullmatch(value):
            placeholders[key] = value
            continue
        if _is_secret_bearing_env_key(key):
            continue
        if _looks_like_raw_secret_value(value):
            continue
        if _is_legacy_safe_literal_value(value):
            literals[key] = value
    return placeholders, literals


def _is_legacy_safe_literal_value(value: str) -> bool:
    stripped = value.strip()
    if _is_safe_literal_value(stripped):
        return True
    if _LEGACY_SAFE_URL_LITERAL_PATTERN.fullmatch(stripped):
        return True
    if _LEGACY_SAFE_PATH_PATTERN.fullmatch(stripped):
        return True
    if _LEGACY_SAFE_TOKEN_PATTERN.fullmatch(stripped):
        return True
    return False


def _sanitize_legacy_env_literals(env: Mapping[str, Any] | None) -> dict[str, str]:
    sanitized: dict[str, str] = {}
    for raw_key, raw_value in (env or {}).items():
        key = _text(raw_key)
        value = _text(raw_value)
        if not key or not value:
            continue
        if _is_secret_bearing_env_key(key):
            continue
        if _looks_like_raw_secret_value(value):
            continue
        if _is_legacy_safe_literal_value(value):
            sanitized[key] = value
    return sanitized


def _sanitize_env_placeholders(env: Mapping[str, Any] | None) -> dict[str, str]:
    sanitized: dict[str, str] = {}
    for raw_key, raw_value in (env or {}).items():
        key = _text(raw_key)
        value = _text(raw_value)
        if not key or not value:
            continue
        if not _ENV_PLACEHOLDER_PATTERN.fullmatch(value):
            raise ValueError(
                f"Env placeholder '{key}' must use $NAME or ${'{'}NAME{'}'} syntax"
            )
        sanitized[key] = value
    return sanitized


def _sanitize_env_literals(env: Mapping[str, Any] | None) -> dict[str, str]:
    sanitized: dict[str, str] = {}
    for raw_key, raw_value in (env or {}).items():
        key = _text(raw_key)
        value = _text(raw_value)
        if not key or not value:
            continue
        if _is_secret_bearing_env_key(key):
            raise ValueError(
                f"Secret-bearing env key '{key}' cannot be stored as a literal"
            )
        if _looks_like_raw_secret_value(value):
            raise ValueError(
                f"Literal env key '{key}' looks like a raw secret and cannot be persisted"
            )
        if not _is_safe_literal_value(value):
            raise ValueError(
                f"Literal env key '{key}' must be a safe non-secret value "
                f"(a filesystem path, boolean, number, log level, or URL). "
                f"For anything else, set it as a $NAME env placeholder and "
                f"export {key} in the environment that launches the app."
            )
        sanitized[key] = value
    return sanitized


@dataclass(frozen=True)
class TransportProfile:
    """Closed resolved launch record; literal argv/env values are never normalized.

    Secrets and variable resolution belong to the caller, not this transport.
    HTTP profiles carry only credential references and reviewed generations;
    the owning credential service resolves current values at dispatch.
    """

    profile_id: str
    transport: Literal["stdio", "streamable_http"] = "stdio"
    protocol_version: str = "2026-07-28"
    command: str = ""
    args: tuple[str, ...] = ()
    env: Mapping[str, str] | None = None
    cwd: str | None = None
    package_headers: Mapping[str, str] = field(default_factory=dict, repr=False)
    url: str = ""
    development_loopback: bool = False
    credential_reference: str | None = None
    credential_generation: int | None = None

    def __post_init__(self) -> None:
        from .protocol_profiles import protocol_profile

        _validate_credential_reference(vars(self))
        _validate_package_headers(self.package_headers)
        object.__setattr__(
            self, "package_headers", MappingProxyType(dict(self.package_headers))
        )
        _validate_profile_id(self.profile_id)
        protocol_profile(self.protocol_version)
        object.__setattr__(self, "args", tuple(self.args))
        if self.env is not None:
            object.__setattr__(self, "env", MappingProxyType(dict(self.env)))
        if self.transport not in {"stdio", "streamable_http"}:
            raise ValueError("mcp_transport_unsupported")
        if type(self.development_loopback) is not bool:
            raise ValueError("mcp_origin_invalid")
        if self.cwd is not None and (
            not isinstance(self.cwd, str)
            or not Path(self.cwd).is_absolute()
            or "\0" in self.cwd
        ):
            raise ValueError("mcp_cwd_invalid")
        if self.transport == "stdio":
            if (
                not isinstance(self.command, str)
                or not self.command
                or self.url
                or self.development_loopback
                or self.package_headers
            ):
                raise ValueError("mcp_profile_invalid")
            if any(not isinstance(arg, str) or "\0" in arg for arg in self.args):
                raise ValueError("mcp_profile_invalid")
            if self.env is not None and any(
                not isinstance(k, str) or not isinstance(v, str) or "\0" in k + v
                for k, v in self.env.items()
            ):
                raise ValueError("mcp_profile_invalid")
        else:
            if (
                self.command
                or self.args
                or self.env is not None
                or self.cwd is not None
            ):
                raise ValueError("mcp_profile_invalid")
            parsed = urlsplit(self.url)
            try:
                loopback = ipaddress.ip_address(parsed.hostname or "").is_loopback
            except ValueError:
                loopback = False
            if (
                not parsed.hostname
                or parsed.username is not None
                or parsed.password is not None
                or "#" in self.url
                or any(ord(c) < 33 for c in self.url)
                or parsed.scheme not in {"https", "http"}
                or (
                    parsed.scheme == "http"
                    and not (self.development_loopback and loopback)
                )
            ):
                raise ValueError("mcp_origin_invalid")
            _ = parsed.port


def _validate_credential_reference(data: Mapping[str, Any]) -> None:
    reference = data.get("credential_reference")
    generation = data.get("credential_generation")
    if reference is None and generation is None:
        return
    if (
        data.get("transport", "stdio") != "streamable_http"
        or not isinstance(reference, str)
        or not re.fullmatch(r"[A-Za-z0-9._-]{1,200}", reference)
        or type(generation) is not int
        or not 1 <= generation < 2**63
    ):
        raise ValueError("mcp_credential_reference_invalid")


def _validate_profile_transport_fields(data: Mapping[str, Any]) -> None:
    """Reject unsupported HTTP fields before legacy stdio coercion drops them."""
    _validate_credential_reference(data)
    if data.get("plugin_owner") is not None:
        args = data.get("args", ())
        if not isinstance(args, (list, tuple)) or any(
            not isinstance(arg, str) or "\0" in arg for arg in args
        ):
            raise ValueError("mcp_owned_profile_invalid")
        command = data.get("command", "")
        if not isinstance(command, str) or "\0" in command:
            raise ValueError("mcp_owned_profile_invalid")
        cwd = data.get("cwd")
        if cwd is not None and (
            not isinstance(cwd, str) or not Path(cwd).is_absolute() or "\0" in cwd
        ):
            raise ValueError("mcp_cwd_invalid")
    if any(key in data for key in ("headers", "auth", "credentials")):
        raise ValueError("mcp_authentication_unsupported")
    if data.get("transport", "stdio") != "streamable_http":
        return
    for key in ("env", "env_placeholders", "env_literals", "legacy_env_literals"):
        value = data.get(key)
        if value is not None and value != {}:
            raise ValueError("mcp_authentication_unsupported")
    if data.get("command") not in (None, "") or data.get("args") not in (None, [], ()):
        raise ValueError("mcp_profile_invalid")


def _validate_package_headers(headers):
    if not isinstance(headers, Mapping) or any(
        not isinstance(key, str) for key in headers
    ):
        raise ValueError("mcp_package_headers_invalid")
    if len({key.lower() for key in headers}) != len(headers):
        raise ValueError("mcp_package_headers_invalid")
    for key, value in headers.items():
        if (
            not re.fullmatch(r"[!#$%&'*+.^_`|~0-9A-Za-z-]+", key)
            or not isinstance(value, str)
            or value != value.strip(" \t")
            or any(
                (ord(char) < 32 and char != "\t") or ord(char) == 127 for char in value
            )
        ):
            raise ValueError("mcp_package_headers_invalid")


def _validate_owned_profile(owner):
    if owner is None:
        return
    if not isinstance(owner, dict) or set(owner) != {
        "installation_id",
        "revision_digest",
        "component_id",
        "definition_digest",
        "environment",
        "data_root",
        "session_isolation",
        "literal_headers",
    }:
        raise ValueError("mcp_owned_profile_invalid")
    if any(
        not isinstance(owner[key], str) or not owner[key]
        for key in (
            "installation_id",
            "revision_digest",
            "component_id",
            "definition_digest",
        )
    ):
        raise ValueError("mcp_owned_profile_invalid")
    _validate_package_headers(owner["literal_headers"])
    if owner["session_isolation"] not in {"separate", "request_independent"}:
        raise ValueError("mcp_isolation_invalid")
    if not isinstance(owner["environment"], dict) or any(
        not isinstance(k, str) or not isinstance(v, str) or "\0" in k + v
        for k, v in owner["environment"].items()
    ):
        raise ValueError("mcp_owned_profile_invalid")
    root = owner["data_root"]
    if root is not None and (
        not isinstance(root, dict)
        or set(root) != {"installation_id", "root_id", "generation", "path"}
        or type(root["generation"]) is not int
        or root["generation"] < 0
        or any(
            not isinstance(root[k], str) or not root[k]
            for k in ("installation_id", "root_id", "path")
        )
    ):
        raise ValueError("mcp_owned_profile_invalid")


@dataclass(frozen=True)
class LocalExternalMCPProfile:
    profile_id: str
    command: str = ""
    args: tuple[str, ...] = ()
    env_placeholders: dict[str, str] = field(default_factory=dict)
    env_literals: dict[str, str] = field(default_factory=dict)
    legacy_env_literals: dict[str, str] = field(default_factory=dict)
    created_at: datetime | None = None
    updated_at: datetime | None = None
    transport: str = "stdio"
    protocol_version: str = "2025-03-26"
    url: str = ""
    development_loopback: bool = False
    credential_reference: str | None = None
    credential_generation: int | None = None
    cwd: str | None = None
    plugin_owner: dict[str, Any] | None = field(default=None, repr=False)

    def __post_init__(self) -> None:
        _validate_profile_transport_fields(vars(self))
        _validate_owned_profile(self.plugin_owner)
        object.__setattr__(self, "profile_id", _text(self.profile_id))
        object.__setattr__(self, "command", _text(self.command))
        object.__setattr__(
            self,
            "args",
            (
                tuple(self.args)
                if self.plugin_owner is not None
                else tuple(_text(item) for item in self.args if _text(item))
            ),
        )
        env_placeholders = _sanitize_env_placeholders(self.env_placeholders)
        env_literals = _sanitize_env_literals(self.env_literals)
        legacy_env_literals = _sanitize_legacy_env_literals(self.legacy_env_literals)
        duplicate_keys = (
            (set(env_placeholders) & set(env_literals))
            | (set(env_placeholders) & set(legacy_env_literals))
            | (set(env_literals) & set(legacy_env_literals))
        )
        if duplicate_keys:
            raise ValueError(
                f"Duplicate env keys across placeholders and literals: {sorted(duplicate_keys)}"
            )
        object.__setattr__(self, "env_placeholders", env_placeholders)
        object.__setattr__(self, "env_literals", env_literals)
        object.__setattr__(self, "legacy_env_literals", legacy_env_literals)

    @property
    def env(self) -> dict[str, str]:
        merged = dict(self.legacy_env_literals)
        merged.update(self.env_literals)
        merged.update(self.env_placeholders)
        return merged

    def to_dict(self) -> dict[str, Any]:
        return {
            "profile_id": self.profile_id,
            "cwd": self.cwd,
            "plugin_owner": (
                {
                    key: value
                    for key, value in self.plugin_owner.items()
                    if key != "literal_headers"
                }
                if self.plugin_owner is not None
                else None
            ),
            "transport": self.transport,
            "protocol_version": self.protocol_version,
            "url": self.url,
            "development_loopback": self.development_loopback,
            "credential_reference": self.credential_reference,
            "credential_generation": self.credential_generation,
            "command": self.command,
            "args": list(self.args),
            "env": self.env,
            "env_placeholders": dict(self.env_placeholders),
            "env_literals": dict(self.env_literals),
            "legacy_env_literals": dict(self.legacy_env_literals),
            "created_at": _datetime_to_iso(self.created_at),
            "updated_at": _datetime_to_iso(self.updated_at),
        }

    def to_storage_dict(self) -> dict[str, Any]:
        return {
            "profile_id": self.profile_id,
            "cwd": self.cwd,
            "plugin_owner": self.plugin_owner,
            "transport": self.transport,
            "protocol_version": self.protocol_version,
            "url": self.url,
            "development_loopback": self.development_loopback,
            "credential_reference": self.credential_reference,
            "credential_generation": self.credential_generation,
            "command": self.command,
            "args": list(self.args),
            "env_placeholders": dict(self.env_placeholders),
            "env_literals": dict(self.env_literals),
            "legacy_env_literals": dict(self.legacy_env_literals),
            "created_at": _datetime_to_iso(self.created_at),
            "updated_at": _datetime_to_iso(self.updated_at),
        }

    def to_input_dict(self) -> dict[str, Any]:
        return {
            "profile_id": self.profile_id,
            "cwd": self.cwd,
            "plugin_owner": self.plugin_owner,
            "transport": self.transport,
            "protocol_version": self.protocol_version,
            "url": self.url,
            "development_loopback": self.development_loopback,
            "credential_reference": self.credential_reference,
            "credential_generation": self.credential_generation,
            "command": self.command,
            "args": list(self.args),
            "env_placeholders": dict(self.env_placeholders),
            "env_literals": dict(self.env_literals),
            "created_at": _datetime_to_iso(self.created_at),
            "updated_at": _datetime_to_iso(self.updated_at),
        }

    @classmethod
    def from_input_dict(cls, data: Any) -> "LocalExternalMCPProfile":
        if not isinstance(data, Mapping):
            return cls(profile_id="", command="")
        _validate_profile_transport_fields(data)
        raw_args = data.get("args")
        args = (
            tuple(raw_args or ())
            if data.get("plugin_owner") is not None
            else (
                tuple(str(item).strip() for item in raw_args)
                if isinstance(raw_args, list)
                else ()
            )
        )
        return cls(
            profile_id=_text(data.get("profile_id")),
            cwd=data.get("cwd"),
            plugin_owner=data.get("plugin_owner"),
            transport=data.get("transport", "stdio"),
            protocol_version=data.get("protocol_version", "2025-03-26"),
            url=data.get("url", ""),
            development_loopback=data.get("development_loopback", False),
            credential_reference=data.get("credential_reference"),
            credential_generation=data.get("credential_generation"),
            command=_text(data.get("command")),
            args=args,
            env_placeholders=_coerce_mapping(data.get("env_placeholders")),
            env_literals=_coerce_mapping(data.get("env_literals")),
            created_at=_iso_to_datetime(data.get("created_at")),
            updated_at=_iso_to_datetime(data.get("updated_at")),
        )

    @classmethod
    def from_storage_dict(cls, data: Any) -> "LocalExternalMCPProfile":
        if not isinstance(data, Mapping):
            return cls(profile_id="", command="")
        _validate_profile_transport_fields(data)
        raw_args = data.get("args")
        args = (
            tuple(raw_args or ())
            if data.get("plugin_owner") is not None
            else (
                tuple(str(item).strip() for item in raw_args)
                if isinstance(raw_args, list)
                else ()
            )
        )
        raw_env_placeholders = _coerce_mapping(data.get("env_placeholders"))
        raw_env_literals = _coerce_mapping(data.get("env_literals"))
        raw_legacy_env_literals = _coerce_mapping(data.get("legacy_env_literals"))
        legacy_env = _coerce_mapping(data.get("env"))
        if legacy_env:
            legacy_placeholders, legacy_literals = _coerce_legacy_env(legacy_env)
            for key, value in legacy_placeholders.items():
                raw_env_placeholders.setdefault(key, value)
            for key, value in legacy_literals.items():
                raw_legacy_env_literals.setdefault(key, value)
        return cls(
            profile_id=_text(data.get("profile_id")),
            cwd=data.get("cwd"),
            plugin_owner=data.get("plugin_owner"),
            transport=data.get("transport", "stdio"),
            protocol_version=data.get("protocol_version", "2025-03-26"),
            url=data.get("url", ""),
            development_loopback=data.get("development_loopback", False),
            credential_reference=data.get("credential_reference"),
            credential_generation=data.get("credential_generation"),
            command=_text(data.get("command")),
            args=args,
            env_placeholders=raw_env_placeholders,
            env_literals=raw_env_literals,
            legacy_env_literals=raw_legacy_env_literals,
            created_at=_iso_to_datetime(data.get("created_at")),
            updated_at=_iso_to_datetime(data.get("updated_at")),
        )

    @classmethod
    def from_dict(cls, data: Any) -> "LocalExternalMCPProfile":
        return cls.from_input_dict(data)


@dataclass(frozen=True)
class LocalGovernanceRule:
    rule_id: str
    capability_id: str
    decision: str
    notes: str | None = None
    updated_at: datetime | None = None

    def __post_init__(self) -> None:
        object.__setattr__(self, "rule_id", _text(self.rule_id))
        object.__setattr__(self, "capability_id", _text(self.capability_id))
        object.__setattr__(self, "decision", _text(self.decision))
        object.__setattr__(self, "notes", _text(self.notes) or None)

    def to_dict(self) -> dict[str, Any]:
        return {
            "rule_id": self.rule_id,
            "capability_id": self.capability_id,
            "decision": self.decision,
            "notes": self.notes,
            "updated_at": _datetime_to_iso(self.updated_at),
        }

    @classmethod
    def from_dict(cls, data: Any) -> "LocalGovernanceRule":
        if not isinstance(data, Mapping):
            return cls(rule_id="", capability_id="", decision="")
        return cls(
            rule_id=_text(data.get("rule_id")),
            capability_id=_text(data.get("capability_id")),
            decision=_text(data.get("decision")),
            notes=_text(data.get("notes")) or None,
            updated_at=_iso_to_datetime(data.get("updated_at")),
        )


@dataclass(frozen=True)
class LocalApprovalRequest:
    request_id: str
    action_name: str
    resolved_action_id: str
    registry_capability_id: str | None = None
    payload: dict[str, Any] = field(default_factory=dict)
    payload_fingerprint: str = ""
    status: str = "pending"
    matched_rule_id: str | None = None
    notes: str | None = None
    created_at: datetime | None = None
    updated_at: datetime | None = None
    resolved_at: datetime | None = None

    def __post_init__(self) -> None:
        object.__setattr__(self, "request_id", _text(self.request_id))
        object.__setattr__(self, "action_name", _text(self.action_name))
        object.__setattr__(self, "resolved_action_id", _text(self.resolved_action_id))
        object.__setattr__(
            self, "registry_capability_id", _text(self.registry_capability_id) or None
        )
        object.__setattr__(self, "payload", _coerce_mapping(self.payload))
        object.__setattr__(self, "payload_fingerprint", _text(self.payload_fingerprint))
        object.__setattr__(self, "status", _text(self.status))
        object.__setattr__(self, "matched_rule_id", _text(self.matched_rule_id) or None)
        object.__setattr__(self, "notes", _text(self.notes) or None)

    def to_dict(self) -> dict[str, Any]:
        return {
            "request_id": self.request_id,
            "action_name": self.action_name,
            "resolved_action_id": self.resolved_action_id,
            "registry_capability_id": self.registry_capability_id,
            "payload": dict(self.payload),
            "payload_fingerprint": self.payload_fingerprint,
            "status": self.status,
            "matched_rule_id": self.matched_rule_id,
            "notes": self.notes,
            "created_at": _datetime_to_iso(self.created_at),
            "updated_at": _datetime_to_iso(self.updated_at),
            "resolved_at": _datetime_to_iso(self.resolved_at),
        }

    @classmethod
    def from_dict(cls, data: Any) -> "LocalApprovalRequest":
        if not isinstance(data, Mapping):
            return cls(request_id="", action_name="", resolved_action_id="")
        return cls(
            request_id=_text(data.get("request_id")),
            action_name=_text(data.get("action_name")),
            resolved_action_id=_text(data.get("resolved_action_id")),
            registry_capability_id=_text(data.get("registry_capability_id")) or None,
            payload=_coerce_mapping(data.get("payload")),
            payload_fingerprint=_text(data.get("payload_fingerprint")),
            status=_text(data.get("status")) or "pending",
            matched_rule_id=_text(data.get("matched_rule_id")) or None,
            notes=_text(data.get("notes")) or None,
            created_at=_iso_to_datetime(data.get("created_at")),
            updated_at=_iso_to_datetime(data.get("updated_at")),
            resolved_at=_iso_to_datetime(data.get("resolved_at")),
        )


@dataclass(frozen=True)
class LocalRuntimeActivity:
    activity_id: str
    action_name: str
    target: str
    ok: bool
    blocked: bool = False
    error: str | None = None
    resolved_action_id: str | None = None
    decision: str | None = None
    matched_rule_id: str | None = None
    approval_request_id: str | None = None
    approval_status: str | None = None
    occurred_at: datetime | None = None

    def __post_init__(self) -> None:
        object.__setattr__(self, "activity_id", _text(self.activity_id))
        object.__setattr__(self, "action_name", _text(self.action_name))
        object.__setattr__(self, "target", _text(self.target))
        object.__setattr__(self, "ok", bool(self.ok))
        object.__setattr__(self, "blocked", bool(self.blocked))
        object.__setattr__(self, "error", _text(self.error) or None)
        object.__setattr__(
            self, "resolved_action_id", _text(self.resolved_action_id) or None
        )
        object.__setattr__(self, "decision", _text(self.decision) or None)
        object.__setattr__(self, "matched_rule_id", _text(self.matched_rule_id) or None)
        object.__setattr__(
            self, "approval_request_id", _text(self.approval_request_id) or None
        )
        object.__setattr__(self, "approval_status", _text(self.approval_status) or None)

    def to_dict(self) -> dict[str, Any]:
        return {
            "activity_id": self.activity_id,
            "action_name": self.action_name,
            "target": self.target,
            "ok": self.ok,
            "blocked": self.blocked,
            "error": self.error,
            "resolved_action_id": self.resolved_action_id,
            "decision": self.decision,
            "matched_rule_id": self.matched_rule_id,
            "approval_request_id": self.approval_request_id,
            "approval_status": self.approval_status,
            "occurred_at": _datetime_to_iso(self.occurred_at),
        }

    @classmethod
    def from_dict(cls, data: Any) -> "LocalRuntimeActivity":
        if not isinstance(data, Mapping):
            return cls(activity_id="", action_name="", target="", ok=False)
        return cls(
            activity_id=_text(data.get("activity_id")),
            action_name=_text(data.get("action_name")),
            target=_text(data.get("target")),
            ok=bool(data.get("ok")),
            blocked=bool(data.get("blocked")),
            error=_text(data.get("error")) or None,
            resolved_action_id=_text(data.get("resolved_action_id")) or None,
            decision=_text(data.get("decision")) or None,
            matched_rule_id=_text(data.get("matched_rule_id")) or None,
            approval_request_id=_text(data.get("approval_request_id")) or None,
            approval_status=_text(data.get("approval_status")) or None,
            occurred_at=_iso_to_datetime(data.get("occurred_at")),
        )


@dataclass(frozen=True)
class LocalMCPStoreState:
    profiles: tuple[LocalExternalMCPProfile, ...] = ()
    discovery_snapshots: dict[str, dict[str, Any]] = field(default_factory=dict)
    governance_rules: tuple[LocalGovernanceRule, ...] = ()
    approval_requests: tuple[LocalApprovalRequest, ...] = ()
    runtime_activity: tuple[LocalRuntimeActivity, ...] = ()
    profile_runtime_state: dict[str, dict[str, Any]] = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        return {
            "schema_version": 4,
            "profiles": [profile.to_storage_dict() for profile in self.profiles],
            "discovery_snapshots": {
                server_id: dict(snapshot)
                for server_id, snapshot in self.discovery_snapshots.items()
            },
            "governance_rules": [rule.to_dict() for rule in self.governance_rules],
            "approval_requests": [
                request.to_dict() for request in self.approval_requests
            ],
            "runtime_activity": [
                activity.to_dict() for activity in self.runtime_activity
            ],
            "profile_runtime_state": dict(self.profile_runtime_state),
        }

    @classmethod
    def from_dict(cls, data: Any) -> "LocalMCPStoreState":
        if not isinstance(data, Mapping):
            return cls()
        profiles_raw = data.get("profiles")
        governance_raw = data.get("governance_rules")
        approvals_raw = data.get("approval_requests")
        activity_raw = data.get("runtime_activity")
        snapshots_raw = data.get("discovery_snapshots")
        profiles = tuple(
            profile
            for profile in (
                LocalExternalMCPProfile.from_storage_dict(item)
                for item in (profiles_raw if isinstance(profiles_raw, list) else [])
            )
            if profile.profile_id
            and profile.profile_id not in _RESERVED_EXTERNAL_PROFILE_IDS
            and (profile.command or profile.transport != "stdio")
        )
        governance_rules = tuple(
            rule
            for rule in (
                LocalGovernanceRule.from_dict(item)
                for item in (governance_raw if isinstance(governance_raw, list) else [])
            )
            if rule.rule_id and rule.capability_id and rule.decision
        )
        approval_requests = tuple(
            request
            for request in (
                LocalApprovalRequest.from_dict(item)
                for item in (approvals_raw if isinstance(approvals_raw, list) else [])
            )
            if request.request_id
            and request.action_name
            and request.resolved_action_id
            and request.status
        )
        runtime_activity = tuple(
            activity
            for activity in (
                LocalRuntimeActivity.from_dict(item)
                for item in (activity_raw if isinstance(activity_raw, list) else [])
            )
            if activity.activity_id and activity.action_name
        )
        discovery_snapshots = (
            {
                str(server_id): dict(snapshot)
                for server_id, snapshot in snapshots_raw.items()
                if str(server_id).strip()
                and _text(server_id) not in _RESERVED_EXTERNAL_PROFILE_IDS
                and isinstance(snapshot, Mapping)
            }
            if isinstance(snapshots_raw, Mapping)
            else {}
        )
        runtime_state_raw = data.get("profile_runtime_state")
        profile_runtime_state = (
            {
                str(profile_id): dict(record)
                for profile_id, record in runtime_state_raw.items()
                if str(profile_id).strip()
                and _text(profile_id) not in _RESERVED_EXTERNAL_PROFILE_IDS
                and isinstance(record, Mapping)
            }
            if isinstance(runtime_state_raw, Mapping)
            else {}
        )
        return cls(
            profiles=profiles,
            discovery_snapshots=discovery_snapshots,
            governance_rules=governance_rules,
            approval_requests=approval_requests,
            runtime_activity=runtime_activity,
            profile_runtime_state=profile_runtime_state,
        )


class LocalMCPStore:
    @mcp_sources.guarded
    def __init__(self, path: str | Path | None = None) -> None:
        self.path = Path(path) if path else _default_local_mcp_store_path()
        from .recovery_activation import select

        select(self)

    @mcp_sources.guarded
    def load(self) -> LocalMCPStoreState:
        from .recovery_activation import readable

        if not readable(self, "mcp.local"):
            return LocalMCPStoreState()
        payload = self._read_payload()
        if not isinstance(payload, Mapping):
            raise LocalMCPStoreLoadError(self.path, ValueError("mcp_store_invalid"))
        version = payload.get("schema_version", 1)
        if type(version) is not int or version not in (1, 2, 3, 4):
            raise LocalMCPStoreLoadError(
                self.path, ValueError("mcp_store_schema_unsupported")
            )
        if not isinstance(payload.get("profiles", []), list):
            raise LocalMCPStoreLoadError(self.path, ValueError("mcp_store_invalid"))
        for key, expected in (
            ("profiles", list),
            ("governance_rules", list),
            ("approval_requests", list),
            ("runtime_activity", list),
            ("discovery_snapshots", dict),
            ("profile_runtime_state", dict),
        ):
            if key in payload and not isinstance(payload[key], expected):
                raise LocalMCPStoreLoadError(self.path, ValueError("mcp_store_invalid"))
        if version < 3 and any(
            isinstance(item, Mapping)
            and any(
                item.get(key) is not None
                for key in ("credential_reference", "credential_generation")
            )
            for item in payload.get("profiles", [])
        ):
            raise LocalMCPStoreLoadError(self.path, ValueError("mcp_store_invalid"))
        try:
            state = LocalMCPStoreState.from_dict(payload)
        except (TypeError, ValueError) as exc:
            raise LocalMCPStoreLoadError(
                self.path, ValueError("mcp_store_invalid")
            ) from exc
        if version < 4 and any(
            isinstance(item, Mapping)
            and (item.get("plugin_owner") is not None or item.get("cwd") is not None)
            for item in payload.get("profiles", [])
        ):
            raise LocalMCPStoreLoadError(self.path, ValueError("mcp_store_invalid"))
        if version < 4 and self.path.exists():
            # Migration rewrites every collection. Refuse source records that the
            # tolerant reader would discard, except the reserved-ID quarantine.
            if version == 1 and any(
                not isinstance(item, Mapping)
                or not item.get("profile_id")
                or not item.get("command")
                or item.get("transport", "stdio") != "stdio"
                for item in payload.get("profiles", [])
            ):
                raise LocalMCPStoreLoadError(self.path, ValueError("mcp_store_invalid"))
            for key, records in (
                ("profiles", state.profiles),
                ("governance_rules", state.governance_rules),
                ("approval_requests", state.approval_requests),
                ("runtime_activity", state.runtime_activity),
            ):
                source = payload.get(key, [])
                if any(not isinstance(item, Mapping) for item in source):
                    raise LocalMCPStoreLoadError(
                        self.path, ValueError("mcp_store_invalid")
                    )
                if key == "profiles":
                    source = [
                        item
                        for item in source
                        if _text(item.get("profile_id"))
                        not in _RESERVED_EXTERNAL_PROFILE_IDS
                    ]
                if len(source) != len(records):
                    raise LocalMCPStoreLoadError(
                        self.path, ValueError("mcp_store_invalid")
                    )
            for key, records in (
                ("discovery_snapshots", state.discovery_snapshots),
                ("profile_runtime_state", state.profile_runtime_state),
            ):
                source = {
                    name: record
                    for name, record in payload.get(key, {}).items()
                    if _text(name) not in _RESERVED_EXTERNAL_PROFILE_IDS
                }
                if source != records:
                    raise LocalMCPStoreLoadError(
                        self.path, ValueError("mcp_store_invalid")
                    )
            self._write_payload({**payload, **state.to_dict()})
        return state

    @mcp_sources.guarded
    def catalog_fingerprint(self) -> tuple:
        """Identify exactly what :meth:`load` would read now, without parsing.

        TASK-33620.15.1: the same admission scope and recovery readability
        check as ``load()`` (a refusal raises as ``load()`` would), then a hash
        of the bytes ``load()`` would parse.

        Returns:
            ``("inactive",)`` or ``("missing",)`` when ``load()`` reads no file;
            otherwise ``("file", sha256, stamp)``, ``stamp`` being the read
            file's ``(st_dev, st_ino, st_size, st_mtime_ns, st_ctime_ns)``.
        """
        import hashlib
        import os

        from .recovery_activation import readable

        if not readable(self, "mcp.local"):
            return ("inactive",)
        try:
            with mcp_sources.reader(self) as handle:
                raw = handle.buffer.read()
                info = os.fstat(handle.fileno())
        except FileNotFoundError:
            return ("missing",)
        stamp = (info.st_dev, info.st_ino, info.st_size, info.st_mtime_ns, info.st_ctime_ns)
        return ("file", hashlib.sha256(raw).hexdigest(), stamp)

    @mcp_sources.guarded
    def save(self, state: LocalMCPStoreState) -> None:
        self._write_payload(state.to_dict())

    @mcp_sources.guarded
    def _write_payload(self, payload: dict[str, Any]) -> None:
        from .recovery_activation import require_store_write

        require_store_write(self, "mcp.local")
        payload["updated_at"] = _datetime_to_iso(datetime.now(timezone.utc))
        mcp_sources.write_json(self, payload)

    @mcp_sources.guarded
    def list_profiles(self) -> list[LocalExternalMCPProfile]:
        return list(self.load().profiles)

    @mcp_sources.guarded
    def get_external_catalog(
        self,
    ) -> list[tuple[LocalExternalMCPProfile, dict[str, Any] | None]]:
        """Return every profile paired with its discovery snapshot, one load.

        task-236: ``get_external_servers`` used to call ``list_profiles``
        plus one ``get_discovery_snapshot`` PER profile — N+1 full state
        loads (each accessor re-reads and re-parses the store file). This
        joins both from a single ``load()`` with the exact per-profile key
        normalization ``get_discovery_snapshot`` uses.

        Returns:
            (profile, snapshot-or-None) pairs in ``list_profiles`` order.
        """
        state = self.load()
        snapshots = state.discovery_snapshots
        return [
            (profile, snapshots.get(_text(profile.profile_id)))
            for profile in state.profiles
        ]

    @mcp_sources.guarded
    def get_profile(self, profile_id: str) -> LocalExternalMCPProfile | None:
        normalized_profile_id = _text(profile_id)
        for profile in self.list_profiles():
            if profile.profile_id == normalized_profile_id:
                return profile
        return None

    @mcp_sources.guarded
    def save_profile(self, profile: LocalExternalMCPProfile) -> LocalExternalMCPProfile:
        current = self.load()
        now = datetime.now(timezone.utc)
        canonical_profile = LocalExternalMCPProfile.from_input_dict(
            profile.to_input_dict()
        )
        profile_id = _validate_profile_id(canonical_profile.profile_id)
        command = canonical_profile.command
        if canonical_profile.transport == "stdio":
            command = _require_non_empty_field(command, "command", "Local MCP profile")
        TransportProfile(
            profile_id=profile_id,
            cwd=canonical_profile.cwd,
            transport=canonical_profile.transport,
            protocol_version=canonical_profile.protocol_version,
            command=command,
            args=canonical_profile.args,
            url=canonical_profile.url,
            development_loopback=canonical_profile.development_loopback,
            credential_reference=canonical_profile.credential_reference,
            credential_generation=canonical_profile.credential_generation,
            env=(
                canonical_profile.env
                if canonical_profile.transport == "stdio"
                else None
            ),
        )
        if canonical_profile.transport == "streamable_http" and canonical_profile.env:
            raise ValueError("mcp_authentication_unsupported")
        # TASK-26013: refuse a dangerous command shape at save time, naming the
        # matched rule and leaving the stored list untouched.
        from tldw_chatbook.MCP.spawn_guard import (
            screen_spawn_command,  # ADR-097 boot ratchet: deferred off the boot path (loads on first use).
        )

        _spawn_verdict = (
            screen_spawn_command(command, canonical_profile.args)
            if canonical_profile.transport == "stdio"
            else None
        )
        if _spawn_verdict is not None:
            raise ValueError(
                f"Local MCP profile command refused: {_spawn_verdict.reason} "
                f"(rule: {_spawn_verdict.rule})"
            )
        existing_profile = next(
            (item for item in current.profiles if item.profile_id == profile_id),
            None,
        )
        saved_profile = LocalExternalMCPProfile(
            profile_id=profile_id,
            cwd=canonical_profile.cwd,
            plugin_owner=canonical_profile.plugin_owner,
            transport=canonical_profile.transport,
            protocol_version=canonical_profile.protocol_version,
            url=canonical_profile.url,
            development_loopback=canonical_profile.development_loopback,
            credential_reference=canonical_profile.credential_reference,
            credential_generation=canonical_profile.credential_generation,
            command=command,
            args=canonical_profile.args,
            env_placeholders=canonical_profile.env_placeholders,
            env_literals=canonical_profile.env_literals,
            legacy_env_literals={},
            created_at=canonical_profile.created_at
            or (existing_profile.created_at if existing_profile else now),
            updated_at=now,
        )
        profiles = [
            item
            for item in current.profiles
            if item.profile_id != saved_profile.profile_id
        ]
        profiles.append(saved_profile)
        discovery_snapshots = dict(current.discovery_snapshots)
        profile_runtime_state = dict(current.profile_runtime_state)
        if existing_profile and self._launch_config_changed(
            existing_profile, saved_profile
        ):
            discovery_snapshots.pop(saved_profile.profile_id, None)
            profile_runtime_state.pop(saved_profile.profile_id, None)
        self.save(
            LocalMCPStoreState(
                profiles=tuple(profiles),
                discovery_snapshots=discovery_snapshots,
                governance_rules=current.governance_rules,
                approval_requests=current.approval_requests,
                runtime_activity=current.runtime_activity,
                profile_runtime_state=profile_runtime_state,
            )
        )
        return saved_profile

    @mcp_sources.guarded
    def delete_profile(self, profile_id: str) -> bool:
        normalized_profile_id = _text(profile_id)
        current = self.load()
        profiles = [
            profile
            for profile in current.profiles
            if profile.profile_id != normalized_profile_id
        ]
        if len(profiles) == len(current.profiles):
            return False
        discovery_snapshots = dict(current.discovery_snapshots)
        discovery_snapshots.pop(normalized_profile_id, None)
        profile_runtime_state = dict(current.profile_runtime_state)
        profile_runtime_state.pop(normalized_profile_id, None)
        self.save(
            LocalMCPStoreState(
                profiles=tuple(profiles),
                discovery_snapshots=discovery_snapshots,
                governance_rules=current.governance_rules,
                approval_requests=current.approval_requests,
                runtime_activity=current.runtime_activity,
                profile_runtime_state=profile_runtime_state,
            )
        )
        return True

    @mcp_sources.guarded
    def save_discovery_snapshot(
        self, profile_id: str, snapshot: Mapping[str, Any]
    ) -> dict[str, Any]:
        normalized_profile_id = _require_non_empty_field(
            profile_id,
            "profile_id",
            "Local MCP discovery snapshot",
        )
        current = self.load()
        discovery_snapshots = dict(current.discovery_snapshots)
        discovery_snapshots[normalized_profile_id] = dict(snapshot)
        self.save(
            LocalMCPStoreState(
                profiles=current.profiles,
                discovery_snapshots=discovery_snapshots,
                governance_rules=current.governance_rules,
                approval_requests=current.approval_requests,
                runtime_activity=current.runtime_activity,
                profile_runtime_state=current.profile_runtime_state,
            )
        )
        return discovery_snapshots[normalized_profile_id]

    @mcp_sources.guarded
    def get_discovery_snapshot(self, profile_id: str) -> dict[str, Any] | None:
        return self.load().discovery_snapshots.get(_text(profile_id))

    @mcp_sources.guarded
    def get_profile_runtime_state(self, profile_id: str) -> dict[str, Any] | None:
        """Return the persisted lifecycle-attempt record for a profile.

        Args:
            profile_id: Stable local profile identifier.

        Returns:
            The stored record dict, or None if no attempt has been recorded.
        """
        state = self.load()
        record = state.profile_runtime_state.get(_text(profile_id))
        return dict(record) if record is not None else None

    @mcp_sources.guarded
    def save_profile_runtime_state(
        self, profile_id: str, record: Mapping[str, Any]
    ) -> dict[str, Any]:
        """Persist the lifecycle-attempt record for a profile (last-write-wins).

        Args:
            profile_id: Stable local profile identifier.
            record: Attempt record (see module convention: last_attempt_at,
                last_action, ok, last_ok_at, last_error).

        Returns:
            The stored record dict.
        """
        normalized_profile_id = _require_non_empty_field(
            profile_id,
            "profile_id",
            "Local MCP profile runtime state",
        )
        current = self.load()
        profile_runtime_state = dict(current.profile_runtime_state)
        profile_runtime_state[normalized_profile_id] = dict(record)
        self.save(
            LocalMCPStoreState(
                profiles=current.profiles,
                discovery_snapshots=current.discovery_snapshots,
                governance_rules=current.governance_rules,
                approval_requests=current.approval_requests,
                runtime_activity=current.runtime_activity,
                profile_runtime_state=profile_runtime_state,
            )
        )
        return profile_runtime_state[normalized_profile_id]

    @mcp_sources.guarded
    def get_catalog_bundle(
        self,
        *,
        _captured_load: Callable[[], LocalMCPStoreState] | None = None,
    ) -> dict[str, Any]:
        """Return the catalog-relevant state in one read.

        Batches the profile list, discovery snapshots, and lifecycle-attempt
        (runtime state) records that a full external-server catalog view
        needs. Callers that would otherwise issue one `load()` per profile
        for each of `get_discovery_snapshot()` and `get_profile_runtime_state()`
        (2N+1 total loads across N profiles) can use this single-`load()`
        accessor instead.

        Args:
            _captured_load: Private finite-worker input naming this exact
                receiver's original guarded load. Default calls retain dynamic
                load resolution; this reference supplies no native authority.

        Returns:
            Mapping with `profiles` (list of profile dicts via `to_dict()`),
            `discovery_snapshots` (profile_id -> snapshot dict), and
            `profile_runtime_state` (profile_id -> lifecycle record dict).
        """
        reader = self.load if _captured_load is None else _captured_load
        if _captured_load is not None and not (
            type(self) is LocalMCPStore
            and isinstance(reader, MethodType)
            and reader.__func__ is _CONSOLE_STANDARD_LOAD
            and reader.__self__ is self
        ):
            from tldw_chatbook.Backup_Recovery.bootstrap import RecoveryRequired

            raise RecoveryRequired("mcp_source_selection_changed")
        # Both this accessor and a captured reader retain their original guards.
        state = reader()
        return {
            "profiles": [profile.to_dict() for profile in state.profiles],
            "discovery_snapshots": dict(state.discovery_snapshots),
            "profile_runtime_state": dict(state.profile_runtime_state),
        }

    @mcp_sources.guarded
    def list_governance_rules(self) -> list[LocalGovernanceRule]:
        return list(self.load().governance_rules)

    @mcp_sources.guarded
    def save_governance_rule(self, rule: LocalGovernanceRule) -> LocalGovernanceRule:
        current = self.load()
        now = datetime.now(timezone.utc)
        rule_id = _require_non_empty_field(
            rule.rule_id, "rule_id", "Local MCP governance rule"
        )
        capability_id = _require_non_empty_field(
            rule.capability_id,
            "capability_id",
            "Local MCP governance rule",
        )
        decision = _require_non_empty_field(
            rule.decision, "decision", "Local MCP governance rule"
        )
        saved_rule = LocalGovernanceRule(
            rule_id=rule_id,
            capability_id=capability_id,
            decision=decision,
            notes=rule.notes,
            updated_at=now,
        )
        rules = [
            item
            for item in current.governance_rules
            if item.rule_id != saved_rule.rule_id
        ]
        rules.append(saved_rule)
        self.save(
            LocalMCPStoreState(
                profiles=current.profiles,
                discovery_snapshots=current.discovery_snapshots,
                governance_rules=tuple(rules),
                approval_requests=current.approval_requests,
                runtime_activity=current.runtime_activity,
                profile_runtime_state=current.profile_runtime_state,
            )
        )
        return saved_rule

    @mcp_sources.guarded
    def delete_governance_rule(self, rule_id: str) -> bool:
        current = self.load()
        normalized_rule_id = _text(rule_id)
        if not normalized_rule_id:
            return False
        rules = [
            item
            for item in current.governance_rules
            if item.rule_id != normalized_rule_id
        ]
        if len(rules) == len(current.governance_rules):
            return False
        self.save(
            LocalMCPStoreState(
                profiles=current.profiles,
                discovery_snapshots=current.discovery_snapshots,
                governance_rules=tuple(rules),
                approval_requests=current.approval_requests,
                runtime_activity=current.runtime_activity,
                profile_runtime_state=current.profile_runtime_state,
            )
        )
        return True

    @mcp_sources.guarded
    def list_approval_requests(self) -> list[LocalApprovalRequest]:
        return list(self.load().approval_requests)

    @mcp_sources.guarded
    def save_approval_request(
        self, request: LocalApprovalRequest
    ) -> LocalApprovalRequest:
        current = self.load()
        now = datetime.now(timezone.utc)
        request_id = _require_non_empty_field(
            request.request_id, "request_id", "Local MCP approval request"
        )
        action_name = _require_non_empty_field(
            request.action_name, "action_name", "Local MCP approval request"
        )
        resolved_action_id = _require_non_empty_field(
            request.resolved_action_id,
            "resolved_action_id",
            "Local MCP approval request",
        )
        payload_fingerprint = _require_non_empty_field(
            request.payload_fingerprint,
            "payload_fingerprint",
            "Local MCP approval request",
        )
        status = _require_non_empty_field(
            request.status, "status", "Local MCP approval request"
        )
        existing_request = next(
            (
                item
                for item in current.approval_requests
                if item.request_id == request_id
            ),
            None,
        )
        saved_request = LocalApprovalRequest(
            request_id=request_id,
            action_name=action_name,
            resolved_action_id=resolved_action_id,
            registry_capability_id=request.registry_capability_id,
            payload=request.payload,
            payload_fingerprint=payload_fingerprint,
            status=status,
            matched_rule_id=request.matched_rule_id,
            notes=request.notes,
            created_at=request.created_at
            or (existing_request.created_at if existing_request else now),
            updated_at=now,
            resolved_at=request.resolved_at
            or (existing_request.resolved_at if existing_request else None),
        )
        approval_requests = [
            item
            for item in current.approval_requests
            if item.request_id != saved_request.request_id
        ]
        approval_requests.append(saved_request)
        self.save(
            LocalMCPStoreState(
                profiles=current.profiles,
                discovery_snapshots=current.discovery_snapshots,
                governance_rules=current.governance_rules,
                approval_requests=tuple(approval_requests),
                runtime_activity=current.runtime_activity,
                profile_runtime_state=current.profile_runtime_state,
            )
        )
        return saved_request

    @mcp_sources.guarded
    def resolve_approval_request(
        self, request_id: str, status: str
    ) -> LocalApprovalRequest | None:
        normalized_request_id = _text(request_id)
        normalized_status = _text(status)
        if not normalized_request_id or not normalized_status:
            return None
        current = self.load()
        existing_request = next(
            (
                item
                for item in current.approval_requests
                if item.request_id == normalized_request_id
            ),
            None,
        )
        if existing_request is None:
            return None
        # Qodo #9 (PR #2313): only a PENDING request may be resolved. Without
        # this, an approval action raced against an elicitation timeout could
        # overwrite the terminal "expired" state with "approved" -- a false
        # audit record for a request nobody is waiting on.
        if existing_request.status != "pending":
            return None
        now = datetime.now(timezone.utc)
        resolved_request = LocalApprovalRequest(
            request_id=existing_request.request_id,
            action_name=existing_request.action_name,
            resolved_action_id=existing_request.resolved_action_id,
            registry_capability_id=existing_request.registry_capability_id,
            payload=existing_request.payload,
            payload_fingerprint=existing_request.payload_fingerprint,
            status=normalized_status,
            matched_rule_id=existing_request.matched_rule_id,
            notes=existing_request.notes,
            created_at=existing_request.created_at,
            updated_at=now,
            resolved_at=now,
        )
        approval_requests = [
            item if item.request_id != normalized_request_id else resolved_request
            for item in current.approval_requests
        ]
        self.save(
            LocalMCPStoreState(
                profiles=current.profiles,
                discovery_snapshots=current.discovery_snapshots,
                governance_rules=current.governance_rules,
                approval_requests=tuple(approval_requests),
                runtime_activity=current.runtime_activity,
                profile_runtime_state=current.profile_runtime_state,
            )
        )
        return resolved_request

    @mcp_sources.guarded
    def delete_approval_request(self, request_id: str) -> bool:
        normalized_request_id = _text(request_id)
        if not normalized_request_id:
            return False
        current = self.load()
        approval_requests = [
            item
            for item in current.approval_requests
            if item.request_id != normalized_request_id
        ]
        if len(approval_requests) == len(current.approval_requests):
            return False
        self.save(
            LocalMCPStoreState(
                profiles=current.profiles,
                discovery_snapshots=current.discovery_snapshots,
                governance_rules=current.governance_rules,
                approval_requests=tuple(approval_requests),
                runtime_activity=current.runtime_activity,
                profile_runtime_state=current.profile_runtime_state,
            )
        )
        return True

    @mcp_sources.guarded
    def list_runtime_activity(self, limit: int = 20) -> list[dict[str, Any]]:
        normalized_limit = max(1, int(limit or 20))
        return [
            activity.to_dict()
            for activity in reversed(self.load().runtime_activity[-normalized_limit:])
        ]

    @mcp_sources.guarded
    def record_runtime_activity(
        self,
        entry: Mapping[str, Any],
        limit: int = 50,
    ) -> dict[str, Any]:
        current = self.load()
        now = datetime.now(timezone.utc)
        normalized_limit = max(1, int(limit or 50))
        parsed_entry = LocalRuntimeActivity.from_dict(entry)
        action_name = _require_non_empty_field(
            parsed_entry.action_name,
            "action_name",
            "Local MCP runtime activity",
        )
        saved_entry = LocalRuntimeActivity(
            activity_id=parsed_entry.activity_id or f"activity-{uuid4().hex[:12]}",
            action_name=action_name,
            target=parsed_entry.target,
            ok=parsed_entry.ok,
            blocked=parsed_entry.blocked,
            error=parsed_entry.error,
            resolved_action_id=parsed_entry.resolved_action_id,
            decision=parsed_entry.decision,
            matched_rule_id=parsed_entry.matched_rule_id,
            approval_request_id=parsed_entry.approval_request_id,
            approval_status=parsed_entry.approval_status,
            occurred_at=parsed_entry.occurred_at or now,
        )
        runtime_activity = list(current.runtime_activity)
        runtime_activity.append(saved_entry)
        runtime_activity = runtime_activity[-normalized_limit:]
        self.save(
            LocalMCPStoreState(
                profiles=current.profiles,
                discovery_snapshots=current.discovery_snapshots,
                governance_rules=current.governance_rules,
                approval_requests=current.approval_requests,
                runtime_activity=tuple(runtime_activity),
                profile_runtime_state=current.profile_runtime_state,
            )
        )
        return saved_entry.to_dict()

    @mcp_sources.guarded
    def _read_payload(self) -> Any:
        try:
            with mcp_sources.reader(self) as handle:
                return json.load(handle)
        except FileNotFoundError:
            return {}
        except (OSError, TypeError, ValueError, json.JSONDecodeError) as exc:
            raise LocalMCPStoreLoadError(self.path, exc) from exc

    @mcp_sources.guarded
    def _launch_config_changed(
        self,
        existing_profile: LocalExternalMCPProfile,
        updated_profile: LocalExternalMCPProfile,
    ) -> bool:
        return self._launch_config_signature(
            existing_profile
        ) != self._launch_config_signature(updated_profile)

    @mcp_sources.guarded
    def _launch_config_signature(
        self,
        profile: LocalExternalMCPProfile,
    ) -> tuple[
        str,
        str,
        str,
        bool,
        str | None,
        int | None,
        str,
        tuple[str, ...],
        tuple[tuple[str, str], ...],
    ]:
        return (
            profile.cwd,
            json.dumps(profile.plugin_owner, sort_keys=True),
            profile.transport,
            profile.protocol_version,
            profile.url,
            profile.development_loopback,
            profile.credential_reference,
            profile.credential_generation,
            profile.command,
            profile.args,
            tuple(sorted(profile.env.items())),
        )

# Callable provenance captured at definition time; no native authority is retained.
_CONSOLE_STANDARD_LOAD = LocalMCPStore.load
_CONSOLE_STANDARD_METHODS = (
    ("load", _CONSOLE_STANDARD_LOAD),
    ("get_external_catalog", LocalMCPStore.get_external_catalog),
    ("get_catalog_bundle", LocalMCPStore.get_catalog_bundle),
)


# Pin only catalog callbacks whose bodies the joined Console reader consumes.
# Keep the original guarded body as well as its public wrapper.
_CONSOLE_STANDARD_BODY_BINDINGS = tuple(
    (
        name,
        callback,
        getattr(callback, "__wrapped__", None),
        tuple(
            (
                function,
                function.__code__,
                function.__globals__,
                (
                    function.__defaults__,
                    function.__kwdefaults__,
                    tuple((function.__kwdefaults__ or {}).items()),
                    function.__closure__,
                    tuple((cell, cell.cell_contents) for cell in function.__closure__ or ()),
                ),
            )
            for function in (callback,)
            + ((callback.__wrapped__,) if hasattr(callback, "__wrapped__") else ())
        ),
    )
    for name, callback in _CONSOLE_STANDARD_METHODS
)
