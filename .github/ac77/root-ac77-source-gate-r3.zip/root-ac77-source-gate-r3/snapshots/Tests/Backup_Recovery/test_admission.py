"""Behavioral evidence for native maintenance admission."""

from Tests.subprocess_pipes import pipe_ready, read_line as line


def test_publication_never_overwrites_existing_file(tmp_path):
    import pytest
    from tldw_chatbook.Backup_Recovery.native_files import publish_new

    staged, destination = tmp_path / "stage", tmp_path / "good"
    staged.write_bytes(b"new")
    destination.write_bytes(b"previous backup")
    with pytest.raises(FileExistsError):
        publish_new(staged, destination)
    assert destination.read_bytes() == b"previous backup"


import json
import os
import sqlite3
import subprocess
import sys
import threading
import time

import pytest

from tldw_chatbook.Backup_Recovery.admission import (
    Admission,
    AdmissionError,
    AdmissionCancelled,
    AdmissionTimeout,
    fcntl,
)

_CHILD = """
import json, sys, sqlite3
from pathlib import Path
from tldw_chatbook.Backup_Recovery.admission import Admission
root, action, names, extra = sys.argv[1:]
names = tuple(json.loads(names))
print("attempting", flush=True)
try:
    a = Admission(Path(root))
    if action == "remap":
        a.remap(names[0], (Path(extra),), 10)
        print("remapped", flush=True)
    else:
        ctx = a.maintenance(names, 10) if action == "maintenance" else getattr(a, action)(names)
        with ctx:
            connection = None
            if extra:
                connection = sqlite3.connect(extra)
                connection.execute("INSERT INTO records VALUES ('committed')")
            print("entered", flush=True)
            sys.stdin.readline()
            if connection:
                connection.commit()
                connection.close()
            print("retired", flush=True)
except Exception as error:
    print(type(error).__name__ + ":" + str(error), flush=True)
"""


@pytest.fixture
def launch():
    children = []

    def start(control, action, names=("a",), extra=""):
        child = subprocess.Popen(
            [
                sys.executable,
                "-u",
                "-c",
                _CHILD,
                str(control),
                action,
                json.dumps(names),
                str(extra),
            ],
            stdin=subprocess.PIPE,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            text=True,
            bufsize=1,
        )
        children.append(child)
        assert line(child) == "attempting"
        return child

    yield start
    for child in children:
        if child.poll() is None:
            child.kill()
        child.wait(timeout=10)
        child.stdin.close()
        child.stdout.close()
        child.stderr.close()


def release(child):
    child.stdin.write("retire\n")
    child.stdin.flush()
    assert line(child) == "retired"
    assert child.wait(timeout=10) == 0


@pytest.fixture
def registered(tmp_path):
    source = tmp_path / "source"
    source.write_bytes(b"original")
    admission = Admission(tmp_path / "control")
    admission.register("a", (source,))
    return admission, source


def test_maintenance_excludes_child_across_target_inode_replacement(registered, launch):
    admission, source = registered
    lock_inodes = {
        p.name: p.stat().st_ino for p in admission.control_root.glob("*.gate")
    }
    with admission.maintenance(("a",), 2):
        replacement = source.with_name("replacement")
        replacement.write_bytes(b"new")
        os.replace(replacement, source)
        child = launch(admission.control_root, "normal")
        assert not pipe_ready(child.stdout, 0.1)
    assert line(child) == "entered"
    release(child)
    assert source.read_bytes() == b"new"
    assert lock_inodes == {
        p.name: p.stat().st_ino for p in admission.control_root.glob("*.gate")
    }


@pytest.mark.parametrize(
    "kind",
    ["hardlink", "junction" if os.name == "nt" else "symlink", "same_path", "nested"],
)
def test_aliases_share_maintenance_boundary(tmp_path, launch, kind):
    source = tmp_path / "source"
    if kind in {"nested", "junction"}:
        source.mkdir()
        if kind == "nested":
            alias = source / "child"
            alias.write_bytes(b"data")
        else:
            alias = tmp_path / "alias"
            subprocess.run(
                ["cmd", "/c", "mklink", "/J", str(alias), str(source)],
                check=True,
                capture_output=True,
            )  # nosec B603 B607 -- fixed native junction command and owned paths.
    else:
        source.write_bytes(b"data")
        alias = tmp_path / "alias"
        if kind == "hardlink":
            os.link(source, alias)
        elif kind == "symlink":
            alias.symlink_to(source)
        else:
            alias = source
    admission = Admission(tmp_path / "control")
    admission.register("a", (source,))
    if kind == "junction":
        # Native Windows admission refuses reparse points rather than resolving
        # them. Verify that boundary without requiring symlink privileges.
        with pytest.raises(OSError, match="windows_reparse_point_refused"):
            admission.register("b", (alias,))
        assert "b" not in _registry_state(admission)["entries"]
        return
    admission.register("b", (alias,))
    with admission.maintenance(("a",), 2):
        child = launch(admission.control_root, "normal", ("b",))
        assert not pipe_ready(child.stdout, 0.1)
    assert line(child) == "entered"
    release(child)


def test_real_sqlite_transaction_and_connection_retire_before_capture(tmp_path, launch):
    database = tmp_path / "data.sqlite"
    with sqlite3.connect(database) as connection:
        connection.execute("CREATE TABLE records(value TEXT)")
    admission = Admission(tmp_path / "control")
    admission.register("a", (database,))
    writer = launch(admission.control_root, "normal", extra=database)
    assert line(writer) == "entered"
    capture = launch(admission.control_root, "maintenance")
    assert not pipe_ready(capture.stdout, 0.1)
    release(writer)
    assert line(capture) == "entered"
    with sqlite3.connect(database) as connection:
        assert connection.execute("SELECT * FROM records").fetchall() == [
            ("committed",)
        ]
    release(capture)


def test_timeout_and_cancel_leave_writer_and_draft_intact(registered, launch):
    admission, source = registered
    writer = launch(admission.control_root, "normal")
    assert line(writer) == "entered"
    with pytest.raises(AdmissionTimeout):
        with admission.maintenance(("a",), 0.1):
            pytest.fail("exclusive admission while writer active")
    cancel = threading.Event()
    timer = threading.Timer(0.1, cancel.set)
    timer.start()
    try:
        with pytest.raises(AdmissionCancelled):
            with admission.maintenance(("a",), 5, cancel=cancel):
                pytest.fail("cancelled acquisition entered")
    finally:
        timer.join()
    assert writer.poll() is None
    assert source.read_bytes() == b"original"
    release(writer)
    with admission.maintenance(("a",), 2):
        pass


def test_dead_holder_os_lock_releases_without_deleting_lock_evidence(
    registered, launch
):
    admission, source = registered
    writer = launch(admission.control_root, "normal")
    assert line(writer) == "entered"
    writer.kill()
    writer.wait(timeout=10)
    with admission.maintenance(("a",), 2):
        assert source.read_bytes() == b"original"
    assert len(list(admission.control_root.glob("*.lease"))) == 1


def test_known_incompatible_is_refused_until_os_lifetime_ends(registered, launch):
    admission, _ = registered
    client = launch(admission.control_root, "incompatible")
    assert line(client) == "entered"
    with pytest.raises(AdmissionError, match="known_incompatible_client"):
        with admission.maintenance(("a",), 2):
            pass
    client.kill()
    client.wait(timeout=10)
    # Windows releases a terminated process's byte locks asynchronously:
    # https://learn.microsoft.com/windows/win32/api/fileapi/nf-fileapi-lockfileex
    deadline = time.monotonic() + 2
    while True:
        try:
            with admission.maintenance(("a",), 2):
                break
        except AdmissionError as error:
            if os.name != "nt" or str(error) != "known_incompatible_client":
                raise
            assert (
                time.monotonic() < deadline
            ), "terminated client's lock did not retire"
            threading.Event().wait(0.01)


def _registry_state(admission):
    """Observe a settled native generation under its real registry lock."""
    with admission._directory() as parent:
        with admission._lock(parent, "registry.lock", fcntl.LOCK_SH):
            return admission._read(parent).model_dump()


def test_remap_reserves_old_and_new_aliases_without_blocking_retirement(
    registered, tmp_path, launch
):
    admission, source = registered
    target = tmp_path / "new"
    target.write_bytes(b"new")
    admission.register("b", (target,))
    old = launch(admission.control_root, "normal")
    new = launch(admission.control_root, "normal", ("b",))
    assert line(old) == line(new) == "entered"
    remap = launch(admission.control_root, "remap", extra=target)
    # A process-local read-only observation synchronizes the persisted reservation.
    for _ in range(200):
        state = _registry_state(admission)
        if state["entries"]["a"]["pending"]:
            break
        threading.Event().wait(0.01)
    assert state["entries"]["a"]["pending"]
    blocked = launch(admission.control_root, "normal", ("b",))
    assert line(blocked) == "AdmissionError:remap_recovery_required"
    release(old)
    assert not pipe_ready(remap.stdout, 0.1)
    release(new)
    assert line(remap) == "remapped"
    assert remap.wait(timeout=10) == 0
    with admission.maintenance(("a",), 2):
        child = launch(admission.control_root, "normal", ("b",))
        assert not pipe_ready(child.stdout, 0.1)
    assert line(child) == "entered"
    release(child)
    assert source.read_bytes() == b"original"


def test_interrupted_remap_preserves_pending_registry_and_both_generations(
    registered, tmp_path, launch
):
    admission, source = registered
    target = tmp_path / "new"
    target.write_bytes(b"candidate")
    writer = launch(admission.control_root, "normal")
    assert line(writer) == "entered"
    with pytest.raises(AdmissionTimeout):
        admission.remap("a", (target,), 0.1)
    state = (admission.control_root / "registry.json").read_bytes()
    assert json.loads(state)["entries"]["a"]["pending"]
    release(writer)
    reopened = Admission(admission.control_root)
    with pytest.raises(AdmissionError, match="remap_recovery_required"):
        with reopened.normal(("a",)):
            pass
    assert (admission.control_root / "registry.json").read_bytes() == state
    assert source.read_bytes() == b"original"
    assert target.read_bytes() == b"candidate"


def test_corrupt_or_missing_control_evidence_never_reinitializes(registered):
    admission, _ = registered
    registry = admission.control_root / "registry.json"
    registry.write_bytes(b"broken")
    with pytest.raises(AdmissionError, match="registry_invalid"):
        Admission(admission.control_root)
    assert registry.read_bytes() == b"broken"
    registry.unlink()
    with pytest.raises(FileNotFoundError):
        Admission(admission.control_root)
    assert not registry.exists()


def test_control_root_overlap_and_nested_admission_are_refused(registered):
    admission, source = registered
    for target in (admission.control_root, admission.control_root.parent):
        with pytest.raises(AdmissionError, match="control_root_overlaps_target"):
            admission.register("b", (target,))
    with admission.normal(("a",)):
        with pytest.raises(AdmissionError, match="nested_admission_forbidden"):
            with admission.maintenance(("a",), 0.1):
                pass


def test_missing_stable_lock_is_not_recreated(registered):
    admission, _ = registered
    next(admission.control_root.glob("*.gate")).unlink()
    with pytest.raises(FileNotFoundError):
        with admission.normal(("a",)):
            pass
    assert not list(admission.control_root.glob("*.gate"))


def test_crashed_remapping_process_keeps_fail_closed_reservation(
    registered, tmp_path, launch
):
    admission, source = registered
    target = tmp_path / "target"
    target.write_bytes(b"new")
    writer = launch(admission.control_root, "normal")
    assert line(writer) == "entered"
    remap = launch(admission.control_root, "remap", extra=target)
    for _ in range(200):
        state = _registry_state(admission)
        if state["entries"]["a"]["pending"]:
            break
        threading.Event().wait(0.01)
    assert state["entries"]["a"]["pending"]
    remap.kill()
    remap.wait(timeout=10)
    release(writer)
    child = launch(admission.control_root, "normal")
    assert line(child) in {
        "AdmissionError:remap_recovery_required",
        "AdmissionError:registry_publication_recovery_required",
    }  # Crash may precede durable local-intent retirement; both states stay fenced.
    assert source.read_bytes() == b"original"
    assert target.read_bytes() == b"new"


def test_opposing_namespace_orders_do_not_deadlock(registered, tmp_path, launch):
    admission, _ = registered
    target = tmp_path / "target"
    target.write_bytes(b"new")
    admission.register("b", (target,))
    first = launch(admission.control_root, "maintenance", ("b", "a"))
    assert line(first) == "entered"
    second = launch(admission.control_root, "maintenance", ("a", "b"))
    assert not pipe_ready(second.stdout, 0.1)
    release(first)
    assert line(second) == "entered"
    release(second)


def test_crashed_maintenance_holder_reopens_admission(registered, launch):
    admission, _ = registered
    maintenance = launch(admission.control_root, "maintenance")
    assert line(maintenance) == "entered"
    writer = launch(admission.control_root, "normal")
    assert not pipe_ready(writer.stdout, 0.1)
    maintenance.kill()
    maintenance.wait(timeout=10)
    assert line(writer) == "entered"
    release(writer)


@pytest.mark.parametrize("phase", ["reservation", "final_mapping"])
def test_failed_remap_metadata_barrier_preserves_authority_across_processes(
    registered, tmp_path, monkeypatch, phase
):
    import errno

    from tldw_chatbook.Backup_Recovery import admission as admission_module

    admission, source = registered
    target = tmp_path / "new"
    target.write_bytes(b"candidate")
    control_inode = admission_module.os.stat(admission.control_root).st_ino
    native_flush_directory = admission_module.flush_directory
    injected = []

    def fail_published_registry_barrier(fd):
        result = native_flush_directory(fd)
        if admission_module.os.fstat(fd).st_ino != control_inode:
            return result
        state = json.loads((admission.control_root / "registry.json").read_text())
        entry = state["entries"]["a"]
        matches = (
            bool(entry["pending"])
            if phase == "reservation"
            else entry["roots"] == [str(target)] and entry["pending"] is None
        )
        if matches and not injected:
            injected.append(True)
            raise OSError(errno.EIO, "injected_registry_barrier_failure")
        return result

    monkeypatch.setattr(
        admission_module, "flush_directory", fail_published_registry_barrier
    )
    with pytest.raises(OSError, match="injected_registry_barrier_failure"):
        admission.remap("a", (target,), 2)
    code = """
import sys
from pathlib import Path
from tldw_chatbook.Backup_Recovery.admission import Admission, AdmissionError
try:
    admission = Admission(Path(sys.argv[1]))
    with admission.normal(("a",)):
        print("admitted")
except AdmissionError as error:
    print(str(error))
"""
    child = subprocess.run(
        [sys.executable, "-c", code, str(admission.control_root)],
        capture_output=True,
        text=True,
        timeout=10,
    )
    assert child.returncode == 0, child.stderr
    assert child.stdout.strip() in {
        "remap_recovery_required",
        "registry_publication_recovery_required",
    }
    assert source.read_bytes() == b"original"
    assert target.read_bytes() == b"candidate"
    if phase == "final_mapping":
        intent = json.loads(
            (admission.control_root / "registry.pending.json").read_text()
        )
        assert intent["before"]["entries"]["a"]["pending"]
        assert intent["before"]["entries"]["a"]["roots"] == [str(source)]
        assert intent["after"]["entries"]["a"]["roots"] == [str(target)]


def _child_admission_result(control):
    code = """
import sys
from pathlib import Path
from tldw_chatbook.Backup_Recovery.admission import Admission, AdmissionError
try:
    admission = Admission(Path(sys.argv[1]))
    if sys.argv[2] == "normal":
        with admission.normal(("a",)):
            print("admitted")
    else:
        print("initialized")
except AdmissionError as error:
    print(str(error))
"""
    child = subprocess.run(
        [
            sys.executable,
            "-c",
            code,
            str(control),
            "normal" if (control / "registry.json").exists() else "initial",
        ],
        capture_output=True,
        text=True,
        timeout=10,
    )
    assert child.returncode == 0, child.stderr
    return child.stdout.strip()


def test_initial_registry_barrier_failure_retains_before_after_evidence(
    tmp_path, monkeypatch
):
    import errno

    from tldw_chatbook.Backup_Recovery import admission as admission_module

    control = tmp_path / "control"
    native_flush_directory = admission_module.flush_directory

    def fail_initial_barrier(fd):
        result = native_flush_directory(fd)
        if (control / "registry.json").exists() and admission_module.os.fstat(
            fd
        ).st_ino == admission_module.os.stat(control).st_ino:
            raise OSError(errno.EIO, "injected_initial_registry_barrier_failure")
        return result

    monkeypatch.setattr(admission_module, "flush_directory", fail_initial_barrier)
    with pytest.raises(OSError, match="injected_initial_registry_barrier_failure"):
        Admission(control)
    intent = json.loads((control / "registry.pending.json").read_text())
    assert intent["version"] == 1 and intent["before"] is None
    assert intent["after"] == {"version": 1, "entries": {}}
    assert _child_admission_result(control) == "registry_publication_recovery_required"


@pytest.mark.parametrize("failure", ["unlink", "cleanup_barrier"])
def test_remap_cleanup_failure_exposes_only_durably_committed_mapping(
    registered, tmp_path, monkeypatch, failure
):
    import errno

    from tldw_chatbook.Backup_Recovery import admission as admission_module

    admission, source = registered
    control = admission.control_root
    target = tmp_path / "new"
    target.write_bytes(b"candidate")
    native_flush_directory = admission_module.flush_directory
    native_unlink = admission_module.os.unlink
    final_mapping_barriers = []

    def final_state():
        entry = json.loads((control / "registry.json").read_text())["entries"]["a"]
        return entry["roots"] == [str(target)] and entry["pending"] is None

    def observe_or_fail(fd):
        result = native_flush_directory(fd)
        if (
            admission_module.os.fstat(fd).st_ino
            == admission_module.os.stat(control).st_ino
            and final_state()
        ):
            if (control / "registry.pending.json").exists():
                final_mapping_barriers.append(True)
            elif failure == "cleanup_barrier":
                assert final_mapping_barriers
                raise OSError(errno.EIO, "injected_intent_cleanup_failure")
        return result

    def fail_unlink(name, *args, **kwargs):
        if name == "registry.pending.json" and final_state() and failure == "unlink":
            assert final_mapping_barriers
            raise OSError(errno.EIO, "injected_intent_cleanup_failure")
        return native_unlink(name, *args, **kwargs)

    monkeypatch.setattr(admission_module, "flush_directory", observe_or_fail)
    monkeypatch.setattr(admission_module.os, "unlink", fail_unlink)
    with pytest.raises(OSError, match="injected_intent_cleanup_failure"):
        admission.remap("a", (target,), 2)
    assert final_mapping_barriers
    assert source.read_bytes() == b"original"
    assert target.read_bytes() == b"candidate"
    if failure == "unlink":
        assert (control / "registry.pending.json").exists()
        assert (
            _child_admission_result(control) == "registry_publication_recovery_required"
        )
    else:
        assert not (control / "registry.pending.json").exists()
        assert _child_admission_result(control) == "admitted"
        assert final_state()  # Mapping passed its full native barrier before cleanup.


@pytest.mark.parametrize(
    "kind",
    [
        "corrupt",
        "unsupported_version",
        "invalid_before",
        "invalid_after",
        "oversized",
        "mismatched",
    ],
)
def test_existing_write_intent_is_never_overwritten_or_cleared(registered, kind):
    admission, source = registered
    control = admission.control_root
    state = json.loads((control / "registry.json").read_text())
    record = {"version": 1, "write_id": "a" * 32, "before": state, "after": state}
    if kind == "unsupported_version":
        record["version"] = 999
    elif kind == "invalid_before":
        record["before"] = {"version": True, "entries": {}}
    elif kind == "invalid_after":
        record["after"] = {"entries": {}}
    elif kind == "mismatched":
        record["after"]["entries"] = {}
    raw = (
        b"broken"
        if kind == "corrupt"
        else b"x" * 2200000
        if kind == "oversized"
        else json.dumps(record).encode()
    )
    intent = control / "registry.pending.json"
    intent.write_bytes(raw)
    intent.chmod(0o600)
    assert _child_admission_result(control) == "registry_publication_recovery_required"
    with pytest.raises(AdmissionError, match="registry_publication_recovery_required"):
        admission.register("b", (source,))
    assert intent.read_bytes() == raw


@pytest.mark.parametrize("phase", ["intent_file", "intent_directory"])
def test_failed_intent_barrier_never_replaces_registry(
    registered, tmp_path, monkeypatch, phase
):
    import errno

    from tldw_chatbook.Backup_Recovery import admission as admission_module

    admission, source = registered
    control = admission.control_root
    original = (control / "registry.json").read_bytes()
    target = tmp_path / "new"
    target.write_bytes(b"candidate")
    native_flush = (
        admission_module.flush_file
        if phase == "intent_file"
        else admission_module.flush_directory
    )

    def fail_intent_barrier(fd):
        result = native_flush(fd)
        intent = control / "registry.pending.json"
        if intent.exists():
            expected_inode = (
                admission_module.os.stat(intent).st_ino
                if phase == "intent_file"
                else admission_module.os.stat(control).st_ino
            )
            if admission_module.os.fstat(fd).st_ino == expected_inode:
                raise OSError(errno.EIO, "injected_intent_barrier_failure")
        return result

    monkeypatch.setattr(
        admission_module,
        "flush_file" if phase == "intent_file" else "flush_directory",
        fail_intent_barrier,
    )
    with pytest.raises(OSError, match="injected_intent_barrier_failure"):
        admission.remap("a", (target,), 2)
    assert (control / "registry.json").read_bytes() == original
    assert (control / "registry.pending.json").exists()
    assert _child_admission_result(control) == "registry_publication_recovery_required"
    assert source.read_bytes() == b"original"
    assert target.read_bytes() == b"candidate"


def test_registry_write_cannot_reinitialize_a_disappeared_existing_generation(
    registered,
):
    from tldw_chatbook.Backup_Recovery.admission import _Registry
    from tldw_chatbook.Backup_Recovery.native_files import pinned_directory

    admission, _ = registered
    registry = admission.control_root / "registry.json"
    registry.unlink()
    with pinned_directory(admission.control_root) as parent:
        with pytest.raises(FileNotFoundError):
            admission._write(parent, _Registry(version=1))
    assert not registry.exists()
    assert not (admission.control_root / "registry.pending.json").exists()


@pytest.mark.parametrize("limit", ["_REGISTRY_LIMIT", "_INTENT_LIMIT"])
def test_register_preintent_limit_failure_removes_only_new_locks_and_allows_retry(
    registered, monkeypatch, limit
):
    from tldw_chatbook.Backup_Recovery import admission as admission_module

    admission, source = registered
    control = admission.control_root
    before = (control / "registry.json").read_bytes()
    established = {
        path.name: admission_module.os.stat(path).st_ino for path in control.iterdir()
    }
    with monkeypatch.context() as patch:
        patch.setattr(admission_module, limit, len(before) + 1)
        with pytest.raises(AdmissionError, match="registry_too_large"):
            admission.register("b", (source,))

    assert (control / "registry.json").read_bytes() == before
    assert {
        path.name: admission_module.os.stat(path).st_ino for path in control.iterdir()
    } == established
    fresh = Admission(control)
    fresh.register("b", (source,))
    with fresh.normal(("a", "b")):
        assert source.read_bytes() == b"original"


@pytest.mark.parametrize(
    "failure", ["second_open", "file_barrier", "directory_barrier"]
)
def test_register_partial_lock_failure_cleans_allocations_before_retry(
    registered, monkeypatch, failure
):
    import errno

    from tldw_chatbook.Backup_Recovery import admission as admission_module

    admission, source = registered
    control = admission.control_root
    before = (control / "registry.json").read_bytes()
    established = {path.name for path in control.iterdir()}
    lease_name = admission._key("b", "lease")
    native_open = admission_module.os.open
    native_flush_file = admission_module.flush_file
    native_flush_directory = admission_module.flush_directory
    injected = []

    def fail_second_open(name, flags, *args, **kwargs):
        if name == lease_name and flags & os.O_CREAT:
            injected.append(True)
            raise OSError(errno.EIO, "injected_lock_failure")
        return native_open(name, flags, *args, **kwargs)

    def fail_file_barrier(fd):
        result = native_flush_file(fd)
        lease = control / lease_name
        if (
            lease.exists()
            and admission_module.os.fstat(fd).st_ino
            == admission_module.os.stat(lease).st_ino
        ):
            injected.append(True)
            raise OSError(errno.EIO, "injected_lock_failure")
        return result

    def fail_directory_barrier(fd):
        result = native_flush_directory(fd)
        if (control / lease_name).exists() and not injected:
            injected.append(True)
            raise OSError(errno.EIO, "injected_lock_failure")
        return result

    with monkeypatch.context() as patch:
        if failure == "second_open":
            patch.setattr(admission_module.os, "open", fail_second_open)
        elif failure == "file_barrier":
            patch.setattr(admission_module, "flush_file", fail_file_barrier)
        else:
            patch.setattr(admission_module, "flush_directory", fail_directory_barrier)
        with pytest.raises(OSError, match="injected_lock_failure"):
            admission.register("b", (source,))

    assert injected
    assert (control / "registry.json").read_bytes() == before
    assert {path.name for path in control.iterdir()} == established
    fresh = Admission(control)
    fresh.register("b", (source,))
    with fresh.normal(("b",)):
        assert source.read_bytes() == b"original"


@pytest.mark.parametrize("foreign", ["preexisting", "replacement"])
def test_register_failed_attempt_never_removes_foreign_lock(
    registered, monkeypatch, foreign
):
    import errno

    from tldw_chatbook.Backup_Recovery import admission as admission_module

    admission, source = registered
    control = admission.control_root
    before = (control / "registry.json").read_bytes()
    lease = control / admission._key("b", "lease")
    replacement = control / "foreign"
    replacement.write_bytes(b"foreign lock evidence")
    replacement.chmod(0o600)
    foreign_inode = admission_module.os.stat(replacement).st_ino
    native_flush_file = admission_module.flush_file

    def swap_then_fail(fd):
        result = native_flush_file(fd)
        if (
            lease.exists()
            and admission_module.os.fstat(fd).st_ino
            == admission_module.os.stat(lease).st_ino
        ):
            # Move the still-held allocation aside before placing foreign data
            # at its name. Windows refuses replacing an open destination through
            # the legacy rename API; both native renames below keep object IDs.
            admission_module.os.rename(lease, control / "displaced-lease")
            admission_module.os.rename(replacement, lease)
            raise OSError(errno.EIO, "injected_replaced_lock")
        return result

    with monkeypatch.context() as patch:
        if foreign == "preexisting":
            admission_module.os.replace(replacement, lease)
            expected = FileExistsError
        else:
            patch.setattr(admission_module, "flush_file", swap_then_fail)
            expected = OSError
        with pytest.raises(
            expected,
            match="injected_replaced_lock" if foreign == "replacement" else None,
        ):
            admission.register("b", (source,))

    assert (control / "registry.json").read_bytes() == before
    assert lease.read_bytes() == b"foreign lock evidence"
    assert admission_module.os.stat(lease).st_ino == foreign_inode
    assert not (control / admission._key("b", "gate")).exists()
    assert not (control / admission._key("b", "incompatible")).exists()
    with pytest.raises(FileExistsError):
        Admission(control).register("b", (source,))
    assert lease.read_bytes() == b"foreign lock evidence"


@pytest.mark.parametrize(
    "failure", ["partial_intent", "intent_file", "intent_directory", "registry_barrier"]
)
def test_register_publication_failure_retains_locks_and_refuses_fresh_authority(
    registered, monkeypatch, failure
):
    import errno

    from tldw_chatbook.Backup_Recovery import admission as admission_module

    admission, source = registered
    control = admission.control_root
    before = (control / "registry.json").read_bytes()
    native_write = admission._write_new_record
    native_flush_file = admission_module.flush_file
    native_flush_directory = admission_module.flush_directory

    def fail_partial_intent(parent, name, data):
        if name == "registry.pending.json":
            native_write(parent, name, b"{")
            raise OSError(errno.EIO, "injected_publication_failure")
        return native_write(parent, name, data)

    def fail_file_barrier(fd):
        result = native_flush_file(fd)
        intent = control / "registry.pending.json"
        if (
            intent.exists()
            and admission_module.os.fstat(fd).st_ino
            == admission_module.os.stat(intent).st_ino
        ):
            raise OSError(errno.EIO, "injected_publication_failure")
        return result

    def fail_directory_barrier(fd):
        result = native_flush_directory(fd)
        if (control / "registry.pending.json").exists() and (
            failure == "intent_directory"
            or "b" in json.loads((control / "registry.json").read_text())["entries"]
        ):
            raise OSError(errno.EIO, "injected_publication_failure")
        return result

    if failure == "partial_intent":
        monkeypatch.setattr(admission, "_write_new_record", fail_partial_intent)
    elif failure == "intent_file":
        monkeypatch.setattr(admission_module, "flush_file", fail_file_barrier)
    else:
        monkeypatch.setattr(admission_module, "flush_directory", fail_directory_barrier)
    with pytest.raises(OSError, match="injected_publication_failure"):
        admission.register("b", (source,))

    assert all(
        (control / admission._key("b", kind)).is_file()
        for kind in ("gate", "lease", "incompatible")
    )
    assert (control / "registry.pending.json").exists()
    assert _child_admission_result(control) == "registry_publication_recovery_required"
    if failure == "registry_barrier":
        assert json.loads((control / "registry.json").read_text())["entries"]["b"][
            "roots"
        ] == [str(source)]
    else:
        assert (control / "registry.json").read_bytes() == before


@pytest.mark.parametrize("failure", ["unlink", "cleanup_barrier"])
def test_register_committed_cleanup_failure_retains_new_locks_and_mapping(
    registered, monkeypatch, failure
):
    import errno

    from tldw_chatbook.Backup_Recovery import admission as admission_module

    admission, source = registered
    control = admission.control_root
    native_flush_directory = admission_module.flush_directory
    native_unlink = admission_module.os.unlink
    committed_barriers = []

    def final_state():
        return "b" in json.loads((control / "registry.json").read_text())["entries"]

    def fail_cleanup_barrier(fd):
        result = native_flush_directory(fd)
        if final_state():
            if (control / "registry.pending.json").exists():
                committed_barriers.append(True)
            elif failure == "cleanup_barrier":
                assert committed_barriers
                raise OSError(errno.EIO, "injected_cleanup_failure")
        return result

    def fail_unlink(name, *args, **kwargs):
        if name == "registry.pending.json" and failure == "unlink":
            assert committed_barriers
            raise OSError(errno.EIO, "injected_cleanup_failure")
        return native_unlink(name, *args, **kwargs)

    with monkeypatch.context() as patch:
        patch.setattr(admission_module, "flush_directory", fail_cleanup_barrier)
        patch.setattr(admission_module.os, "unlink", fail_unlink)
        with pytest.raises(OSError, match="injected_cleanup_failure"):
            admission.register("b", (source,))

    assert committed_barriers and final_state()
    assert all(
        (control / admission._key("b", kind)).is_file()
        for kind in ("gate", "lease", "incompatible")
    )
    if failure == "unlink":
        assert (
            _child_admission_result(control) == "registry_publication_recovery_required"
        )
    else:
        fresh = Admission(control)
        fresh.register("b", (source,))
        with fresh.normal(("a", "b")):
            assert source.read_bytes() == b"original"
