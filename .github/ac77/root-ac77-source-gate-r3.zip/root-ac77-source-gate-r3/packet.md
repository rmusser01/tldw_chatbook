# R3 monitor configuration correction

**R2 was not run and is not clear to run:** its worker local-event mask incorrectly included Python3.12 `PY_UNWIND`. ROOT identified the already-proved API defect from the prior .37 R4/R5 work. R3 makes only the prescribed monitor configuration correction, using the existing .37 R8 owned-global-unwind pattern; no new runtime probe was performed.

Worker local events are `PY_START | PY_RETURN`; `PY_UNWIND` is enabled globally only for this reserved tool. The unwind callback returns immediately unless `self.codes.get(code) == "worker"`. Cleanup independently disables global events before local event removal, callback unregistering and tool release. Original six TEST bytes, every product/helper/runtime snapshot, reader/compiler, source inventory, ownership scope and bounds are unchanged. No native outcome or run approval follows; independent ROOT review and real qualification remain pending.

The exact delta is `r2-r3-monitor.patch`; `static-check.json` records the frozen hash/AST/compile-as-data checks. The prior complete preparation packet follows with the same command, source/runtime prerequisites and limits; use this R3 artifact as `ARTIFACT`.

---

# AC77 finite actual-source qualification preparation

**Unexecuted E-only package for independent ROOT review.** The reviewed R1 TEST candidate is unchanged: SHA256 `9ddcbb4be98af8f748acbb08a096388e1547940e3140d3447a5ffabca556f435`. Source binding, current Darwin baseline, original actual Linux qualification and every native outcome remain pending. AC77 is still unimplemented in the frozen caller. No product source or platform policy was changed.

## Included and preserved

`expected-sources.json` binds 30 exact source files, 144 selected function slots and the unchanged native qualification JSON. All defining module paths are genuine checkout-relative paths. All snapshot paths are artifact-relative passive byte references under `snapshots/`; they do not load or install product modules. The selected TEST, scope helper6175db8f, original configured-source fixturea8dd61b9 and current fixture/support chain are at their truthful `Tests/...` paths in that reference tree. ROOT stages any missing TEST/helper copies at those genuine paths; it must not use an import finder, alias, duplicate helper, forged code filename or copy product references into Goal to force a match.

The finite inventory includes bootstrap `_records`/`_control_records`/record reader/registry, config companion guard and operation, raw scope/check/retire and original source/parent guards, storage acquire plus selector/derived collectors/reuse/note and actual holder/lease bodies, fixed pending/enrollment writers, Admission directory/lock/read/write/native admit, private path/stream/close owners, native pinned-directory/writer/flush owners, actual Linux identity reader, and the original exact service control-root functions. Imported helper-only Hook/MCP rows receive source identity checks, with no claim that their unselected behavior ran. Product supported-path bodies currently have no identified missing snapshot; ROOT supplied native files, native platform and service storage independently and their immutable input manifests remain preserved.

`ac77_source_gate.py` reuses the reviewed .37 R8 Gate. `source-reader.patch` changes only its description, artifact-relative frozen-source path resolution, and the fixed config `_CLI_SETTING_DEFAULT_UNSET = object()` sentinel handling, by the existing raw `_UNCHECKED` pattern. No comparator, loader, native fallback or generic provenance framework was added. Existing source/actual spec-loader/default/global/closure checks and actual pytest assertion compiler handling remain. Darwin's three runtime snapshots are copied unchanged and are **reference anchors requiring fresh ROOT seals**. Linux runtime sources are deliberately missing rather than copied from Darwin.

`ac77_gate_plugin.py` limits collection to the original six names, in original order. It uses the existing source-return/fixture-yield monitoring pattern to bind the actual fixture lambda and fresh config source returned by the original installer. It additionally observes only source-pinned holder/lease code events for that fixture's exact non-None `(pid, original temporary bootstrap root)` key. Holder/worker/lease identities remain exact; unrelated owners and unqualified None-key leases receive no credit. It never sets a stop event, closes a lease, joins a worker, drains an owner, changes a timestamp, or alters a producer return/error.

Monitoring failures are deferred into the gate receipt so the original producer and cleanup continue. After original fixture teardown and monkeypatch restoration, it checks the original source bindings/data again, exact observed holder worker return and thread termination, and retirement of its observed leases. Those additional observer assertions preserve the six original bodies; native descriptor closure remains limited to their actual original assertions and the scoped native holder return/join. A registry set alone is not promoted to native closure. The source/fixture/worker count limits are explicit and errors fail qualification rather than being dropped.

The six themselves create no subprocess. `children: []` is an explicit scope statement, not a claim about ROOT's external runner. That runner/workflow still needs independent source, command, actual child exit/reap and archive custody evidence.

## ROOT commands and prerequisites

After independent review of this reader/plugin/manifest and fresh actual source guards, ROOT can stage the unchanged R1 selected TEST plus the exact original helpers at actual package paths and run this **targeted module only**. The command shape below uses the real existing Python >=3.12 interpreter, real checkout and a fresh empty receipt directory. It adds no test skips, fake platform, timeout or changed native qualification:

```sh
PYTHONPATH="$ARTIFACT:$CHECKOUT" "$PYTHON" -m pytest \
  -p ac77_gate_plugin \
  --ac77-installed-root="$CHECKOUT" \
  --ac77-archive="$RECEIPT/gates" \
  --ac77-runtime-binding="$ARTIFACT/runtime-sources.darwin.json" \
  Tests/Backup_Recovery/test_config_companion_missing_record_evidence.py \
  -q -rA --junitxml="$RECEIPT/junit.xml"
```

`ARTIFACT` is this extracted package, `CHECKOUT` is ROOT's actual native checkout, `PYTHON` is its real interpreter and `RECEIPT` is a new owned archive directory. Their actual absolute values and argv/cwd must be recorded. The artifact root contains only the TEST gate modules and passive snapshots; product modules must resolve to the actual checkout. Source checks will refuse conflicting imported copies. ROOT owns staging, any new Git/native snapshot/workflow, execution and publication.

Run Darwin as a current-source baseline, then run the unchanged original six on actual Linux **before any product correction**, using a separately frozen/reviewed `runtime-sources.linux.json`. `root-prerequisites.json` lists the precise missing Linux paths: `runtime/linux/contextlib.py`, `runtime/linux/_pytest/fixtures.py`, `runtime/linux/_pytest/assertion/rewrite.py`, with actual runtime paths and hashes pending. ROOT also needs fresh Darwin runtime/current-source seals after its active work settles; the frozen references are not moving-Goal attestation. Verify actual POSIX identity, native qualification, original fixture and six collected/executed cases. An ineligible native setup or Windows skip cannot qualify Linux. No primitive/platform/root substitution is permitted.

Archive the package digest, current HEAD/source/input/runtime seals before and after, actual runtime/native module origins and primitive identities, exact command/cwd/interpreter/platform, complete log/XML/exit, all six collection names, all per-case gate JSON and original user properties, setup/call/teardown outcomes, and external runner child exit/reap evidence. The reader records setup/call reports available before its post-teardown close; XML/outer runner retains final teardown status. Preserve failures as failures, separating setup/source-binding failures from causal assertions and cleanup failures. The external runner must retain originals and restore only its staged TEST copies after resources retire.

Original mutation cases still merely report `was_confirmed`; cold refusals remain cold refusals. The collector's fixed-intent None contradiction remains a source finding. This package supplies no actual RED, confirmed absence reuse, invalidation proof, authority bypass, 11-open current count, census success or Task34406 completion. A later product proposal still needs engaged invalidation/close/error/cancellation controls, original lock and both fallback leases, separately reviewed collector eligibility, the ADR126 clarification and unchanged Linux census.
