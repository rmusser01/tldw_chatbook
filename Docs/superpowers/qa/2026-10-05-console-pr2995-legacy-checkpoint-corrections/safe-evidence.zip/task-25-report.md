# Task 25 — incomplete legacy-checkpoint compatibility checkpoint

Status: NEEDS_CONTEXT. Root attributed the nine first-GREEN failures and requested a clean incomplete commit before tracking the test-only extension and ninth owner. No Task25 completion or independent source approval is claimed.

Original dispatch/review BASE: `1dc472f66ec376fa054797805b12e1105872f28b`. The eight owned tracked files have no edits after the first-GREEN phase. Commit subject: `WIP: preserve legacy checkpoint rows and split exact v77 catalogs`. The checkpoint commit SHA is reported in the clean handoff; it is created after this evidence freeze.

## Implemented within the original eight-owner scope

The installed unpublished77 migration changes only its queue CHECK to `CHECK (origin != 'agent_chat_start' OR queue_entry_id IS NULL),`. All17 INSERT SELECT predecessor fields, machine constraints, table/index/rename SQL and the shipped75→76 artifact remain exact. Primary and shared catalogs retain frozen strong native76/77 and separate repaired77; repaired shared catalogs admit inner77 only. The Canvas fixed catalog list explicitly retains old strong primary families. Runtime constructor/branch, repository writer/reader, recovery authorizer and trust/expiry/cleanup are untouched.

The historical native fixture embeds the exact frozen2718-byte SQL literal (SHA256 `423978f7c23189e36ce4c5172cfd6d2b887abcc1f6abc057f86f61e55ca17fa8`) and proves complete primary/shared membership before reopen. Existing fresh constructor capture asserts repaired77 independently. Populated shipped fixtures keep original valid rows and add otherwise valid canonical queued/NULL and manual/nonNULL owners, linked messages, explicit revisions/versions/timestamps and a note. New checks cover constructor76 twice, standalone installed76 SQL with explicit transaction/stamp update, constructor75 through immutable notes76, strict atomic new writes, machine SQLite constraints, repaired false76 refusal and exact catalog stamp admission. Reader quarantine checks correct only queue values in memory to prove all other owner fields validate.

ADR required: no new ADR; existing dated ADR219 amendment applies, with ADR158/208. The already committed ADR/spec/Backlog clarification was read and unchanged.

## Recorded verification

All test processes use shared Python3.12, explicit WT cwd/PYTHONPATH, a fresh canonical private HOME/USERPROFILE/config/data/basetemp, `-p no:randomly` and unchanged300s bound. Every phase receipt retains exact argv/environment/HEAD/source SHA256, raw stdout/stderr/JUnit/exit/closed-process status and source snapshots. See `task-25-safe-evidence/run.py`, `dispatch.py`, `selectors.json` and each named phase JSON.

- RED `red-constructor`: four isolated real shipped76 constructor failures, queued/NULL and manual/nonNULL × both dictionary variants. Each independently reaches installed INSERT SELECT and the original queue CHECK on unchanged five-product bytes. Exit1;4FAIL,0ERROR,0SKIP;5.06s process. Actual source/output/XML preserved.
- Collection `collect-final`: exactly111 parameterized cases from26 prescribed existing dependency selectors and8 new nodes. Exit0; source stable;1.40s process. Full collected IDs retained in stdout before GREEN.
- First GREEN `green-final`:102PASS,9FAIL,0ERROR,0SKIP; exit1;69.40s process/68.38s pytest; all eight owners and selected dependency sources stable; process closed. Four original RED cases pass. No warnings summary appeared; raw stdout/stderr remain authoritative. `outcomes-first-green.json` lists every actual JUnit parameter name/outcome.
- Added-hunk formatting `format` and `format-final`: AST-preserving formatter application, zero operations on each final iteration. These are mutating formatting phases (source_stable=false as correctly recorded), before final collection/GREEN. Whole-file inherited formatting debt remains. Dedicated nonmutating final ratchet, fatal Ruff and whitespace checks are pending continuation.
- Read-only `preservation`: exit1 at its final Canvas AST reversal. Its global text removal also removed a pre-existing native-catalog import outside the changed Canvas block, so that checker is too broad. The earlier12589 QA mode/blob/path SHA1 loop, complete unowned Git-diff assertions, single-SQL-CHECK assertion, frozen SQL hash, unaffected existing-test AST comparisons, historical replacement equality and recovery_core AST reversal were reached and passed before that false checker failure. No overall preservation success is claimed and no result JSON was emitted. Exact checker/argv/source/stdout/stderr/exit are preserved. Do not replace or rerun this receipt.

## Nine concrete failures and root attribution

1. `test_shipped76_archive_stages_v77_without_changing_source[False/True]`: both real no-snapshot archives stage repaired77 and reach every predecessor/message/index preservation assertion. My added raw `sqlite3.connect` quick_check then fails with missing `canvas_revision_payload_valid()` UDF. Root directed moving this added probe to the already existing post-staging native connection used for reader quarantine. Product staging gains no constructor or SQL authority. Final source/archive-byte/live-destination assertions after the failed probe have not yet run on these new bytes.
2. `test_populated_legacy_queue_paths_are_lossless[constructor76/standalone76/constructor75-initial/updated]`: all six paths reach receipt/message/index equality, then new note equality mixes raw SQLite timestamp strings with native datetime decoding. Root directed identical raw connection types before/after, preserving all note columns/data. These cases have not yet reached their later quick_check/catalog/reader assertions.
3. `test_schema_policy_matches_installed_store[chachanotes]`: its existing unowned exact-count assertion expects8 rows; required strong77 catalog support adds two exact catalogs, yielding10. Root will track a test-only ninth-owner extension: count8→10 plus assertion of the exact two strong77 rows. This is a catalog census, not an owner/resource cap.

No profile/marker/gate/cap/timeout change, suppression, install, suite run, old passing-cohort replay, normalization or semantic archive queue query occurred. No source correction or rerun happened after first GREEN. Root explicitly directed retaining five production hashes and102 passing cases at their source phase, and rerunning only the nine failed nodes after the tracked extension.

## Self-review and custody

Read the complete five-product diff and new/modified test flows. The storage/catalog repair is minimal; source guards and historical SQL remain unchanged. All nine unresolved findings are test/census problems above, with reached phases stated rather than claimed as complete. The attempted global Canvas reversal checker also needs a narrowly scoped correction in a new checker receipt. Current changed tracked paths are exactly the five product and three test owners in `owners.json`; no unowned edits, children, remote writes or active test process remain. No task is marked Done. Original QA and Task19–24 evidence is retained.

Report/brief/all current safe artifacts/source snapshots are frozen by `task-25-safe-evidence/manifest.json` before the incomplete source commit. Its schema explicitly defines path bases and excludes its own bytes to avoid self-reference. Custody returns clean to root after that commit; continuation requires the tracked test-only owner extension.


## Ruling106 continuation — completed implementation and clean handoff

Status: DONE for Task25 implementation and its scoped verification. Independent source review, safe publication, new-head Qodo/hosted gates and merge remain root work; no source approval or overall task/AC8 closure is claimed. Original review BASE remains `1dc472f66ec376fa054797805b12e1105872f28b`. The initial incomplete report above and all first-phase outputs remain unchanged in their immutable aliases.

Continuation dispatch: `bf7e235708b917562d335f9b9fbbc222daa44405`. Source commits: `1951f9dc7ce8f044ac27c2b027e850f83b599b25` (eight-owner compatibility checkpoint) and `f52c11b3d8d012bfe4d900e3e27d20f624f09ab9` (`test: correct legacy checkpoint probes and exact catalog census`, three test owners,12 insertions/8 deletions).

### Three test-only corrections

- `Tests/DB/test_chachanotes_v77_agent_chat_starts_migration.py`: note rows after upgrade use the identical raw SQLite connection type as the before snapshot, retaining every column/order and exact stored timestamp strings. No CAST or data normalization.
- `Tests/Backup_Recovery/test_restore_plan.py`: the newly added quick_check uses the already existing post-staging native connection, with its installed Canvas UDF. Raw FK, every predecessor/message/index equality, original source/archive-byte checks, absent destination and reader quarantine assertions all remain and now complete for both archive variants. Product staging gains no constructor or authority.
- `Tests/Backup_Recovery/test_core_owners.py`: exact schema census8→10, plus an explicit assertion that the last two entries are exactly the two strong native catalogs at77. Other owner branches, versions, actual first catalog and migration assertions remain exact. The whole-owner three-change AST reversal equals original BASE.

All five production hashes and the populated native76 compatibility test owner remain byte-exact to checkpoint1951 and first GREEN. No test passing in that first phase was replayed.

### Final scoped evidence

| Receipt | Actual result |
| --- | --- |
| `continuation-collect` | The exact nine failed parameter IDs only;9 collected; exit0, stable sources, closed;1.43s process. |
| `continuation-green` |9PASS,0FAIL/ERROR/SKIP;7.78s pytest/8.76s process; exit0, stable final test bytes, closed. |
| `fatal-ruff` |E9,F63,F7,F82 across all eight Python owners; exit0;0.065s; stable/closed. SQL is pinned by the exact-byte delta and whitespace proof. |
| `format-verify-final` |Nonmutating final changed-hunk ratchet across all eight Python owners;0 operations in changed hunks, whole AST exact; no whole-file formatter operations detected; exit0;0.278s; stable/closed. |
| `whitespace-final` |Exact `git diff --check` from original BASE across all nine current owners; exit0;0.052s; stable/closed. |
| `preservation-final` |Narrow additive AST/catalog/QA/source/case-phase proof; exit0;3.36s; stable/closed. The original failed checker remains untouched. |
| `commit-continuation` |Only the three tracked test owners committed; exit0;0.331s; nine source hashes stable; tracked checkout/index clean. |

Every receipt keeps exact argv/environment/HEAD/source snapshots/SHA256/stdout/stderr/exit/process closure; test receipts also keep JUnit. The same shared Python3.12/WT/private canonical profile/`-p no:randomly`/fresh basetemp/300s bound applies. No warnings summary appeared in the nine-case test output. Original failures and Git messages remain visible; the continuation commit retains auto-configured identity and existing auto-GC/unreachable-object warnings in raw stdout/stderr. No Git configuration, GC/prune/cleanup or warning suppression was performed.

### Qualification by source phase and preservation

Exactly111 distinct originally collected cases are qualified:102PASS from `green-final` plus9PASS from `continuation-green`. `qualified-final-cases.json` gives every actual JUnit case, originating phase and carry basis. This is phase-qualified111, not a whole111-case rerun on final file bytes. Unchanged product/fixture/dependency hashes and complete module AST comparison excluding only the three previously failed functions preserve every passing function/helper/import. The nine corrected case IDs exactly equal the original failed set.

`preservation-final-result.json` records exact old strong primary533-entry and shared584-entry catalogs, both dictionary variants, independently of repaired77 capture. Historical catalog/stamp declarations remain exact; repaired tuples differ only at the single trusted installed CHECK and shared repaired stamps admit77 only. Whole recovery policy/shared owner AST reversal and function-only Canvas import/fixed-tuple reversal equal original BASE. Primary AST outside the owned catalog block and historical replacement/metadata SQL declarations remain exact. The frozen2718-byte feature SQL hash and the installed single-CHECK delta remain exact.

One batch Git tree read plus stdlib Git-blob-SHA1/mode comparisons preserve all12,589 QA paths (original12,582 plus exact seven final-corrections publication paths) and8,092 unowned production/test paths. The only source/test/QA differences from review BASE are the nine declared owners; the continuation changed only its three declared test owners. Original141 artifact and5 context pins are verified through their explicit aliases; original `manifest.json` and the failed checker/output remain byte-exact.

### Final self-review, manifest and custody

Read the complete three-test diff after successful verification. It implements only Ruling106's exact corrections; no assertion/data/authority is weakened or removed. No unresolved implementation concern remains. No broad suite, install, new skip/marker/cap/timeout, passing-cohort replay, extra source writer, child agent or external mutation occurred. No new general lesson was added: these probe mistakes reuse the existing exact-SQL/UDF and connection-type lessons already read.

Final source HEAD: `f52c11b3d8d012bfe4d900e3e27d20f624f09ab9`. Final evidence is additive `task-25-safe-evidence/manifest-final.json` (schema/path bases declared in that file), including all original pins/aliases, new receipts/runners/snapshots and nine current owner hashes. Original `task-25-safe-evidence/manifest.json` is unchanged. Tracked checkout/index are clean, all recorded processes are closed, and sole-writer custody returns to root for the independent review over original BASE through final source.
