import ast,hashlib,json,os,stat,subprocess
from pathlib import Path
W=Path(__file__).resolve().parents[4];E=Path(__file__).resolve().parent
BASE='1dc472f66ec376fa054797805b12e1105872f28b'
owners=json.loads((E/'owners.json').read_text())
tree=subprocess.check_output(['git','ls-tree','-r','-z',BASE],cwd=W)
entries=[]
for part in tree.split(b'\0'):
 if not part:continue
 header,path=part.split(b'\t',1);mode,kind,blob=header.decode().split();entries.append(dict(mode=mode,kind=kind,blob=blob,path=os.fsdecode(path)))
qa=[r for r in entries if r['path'].startswith(('Docs/superpowers/qa/','qa/'))]
assert len(qa)==12589
mismatches=[]
for r in qa:
 p=W/r['path'];st=p.lstat()
 data=os.fsencode(os.readlink(p)) if stat.S_ISLNK(st.st_mode) else p.read_bytes()
 blob=hashlib.sha1(b'blob '+str(len(data)).encode()+b'\0'+data).hexdigest()
 mode='120000' if stat.S_ISLNK(st.st_mode) else '100755' if st.st_mode&stat.S_IXUSR else '100644'
 if blob!=r['blob'] or mode!=r['mode']:mismatches.append(r['path'])
assert not mismatches,mismatches
changed=subprocess.check_output(['git','diff','--name-only',BASE],cwd=W,text=True).splitlines()
assert set(changed)==set(owners),changed
index_changed=subprocess.check_output(['git','diff','--cached','--name-only',BASE],cwd=W,text=True).splitlines()
assert not index_changed,index_changed
# SQL differs at the single ruled CHECK only; copy/rename/index/machine clauses exact.
sql=owners[0];old=(E/('base-'+Path(sql).name)).read_text();new=(W/sql).read_text()
oldcheck="CHECK ((origin = 'queued' AND queue_entry_id IS NOT NULL)\n        OR (origin IN ('manual', 'agent_chat_start') AND queue_entry_id IS NULL))"
newcheck="CHECK (origin != 'agent_chat_start' OR queue_entry_id IS NULL)"
assert old.replace(oldcheck,newcheck)==new
p=owners[5];mod=ast.parse((W/p).read_text());frozen=next(n.value.value for n in mod.body if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='_FROZEN_NATIVE76_MIGRATION' for t in n.targets))
assert frozen.encode()==(E.parent/'task-25-frozen-native76-migration.sql').read_bytes()
assert hashlib.sha256(frozen.encode()).hexdigest()=='423978f7c23189e36ce4c5172cfd6d2b887abcc1f6abc057f86f61e55ca17fa8'
# Existing test AST is exact except the explicit changed fixture/capture/catalog/row-count dependencies.
changed_tests={owners[5]:{'_legacy_native76','test_legacy_native76_upgrade_preserves_exact_receipts','test_v77_constructor_catalog_matches_exact_native76_capture'},owners[6]:{'_shipped76','test_shipped76_staged_failure_rolls_back_checkpoint_rebuild'},owners[7]:{'test_shipped76_archive_stages_v77_without_changing_source'}}
ast_checks=[]
for p,allowed in changed_tests.items():
 before=ast.parse((E/('base-'+Path(p).name)).read_text());after=ast.parse((W/p).read_text());current={n.name:n for n in after.body if isinstance(n,(ast.FunctionDef,ast.ClassDef))}
 for n in before.body:
  if isinstance(n,(ast.FunctionDef,ast.ClassDef)) and n.name not in allowed:
   assert ast.dump(n)==ast.dump(current[n.name]),(p,n.name)
 ast_checks.append(dict(path=p,modified_existing_functions=sorted(allowed),other_existing_function_class_AST='exact'))
# Large catalog owners retain every preceding declaration and all historical replacement bytes.
for p,marker in [(owners[1],'CHACHANOTES_V75_SCHEMA = next('),(owners[3],'_SUBSCRIPTIONS_REPAIRED_RECEIPT_SCHEMAS = tuple(')]:
 before=(E/('base-'+Path(p).name)).read_text();after=(W/p).read_text()
 if p==owners[1]:assert ast.dump(ast.parse(before.split(marker)[0]))==ast.dump(ast.parse(after.split(marker)[0]))
 for name in ('_CHACHANOTES_V76_REPLACEMENTS','_SUBSCRIPTIONS_V76_REPLACEMENTS'):
  def find(src):
   return next((n for n in ast.parse(src).body if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id==name for t in n.targets)),None)
  a,b=find(before),find(after)
  if a is not None:assert ast.dump(a)==ast.dump(b),(p,name)
# Recover original product AST by removing only the two authorized policy/list insertions.
p=owners[2];s=(W/p).read_text().replace('            schemas += tuple((77, schema) for schema in CHACHANOTES_V76_NATIVE_SCHEMAS)\n','')
assert ast.dump(ast.parse(s))==ast.dump(ast.parse((E/('base-'+Path(p).name)).read_text()))
p=owners[4];s=(W/p).read_text().replace('        CHACHANOTES_V76_NATIVE_SCHEMAS,\n','').replace('        *CHACHANOTES_V76_NATIVE_SCHEMAS,\n','')
assert ast.dump(ast.parse(s))==ast.dump(ast.parse((E/('base-'+Path(p).name)).read_text()))
r=dict(base=BASE,qa_basis='git ls-tree BASE mode/blob/path versus current working bytes via stdlib Git blob SHA1; no per-path subprocess',qa_entries=qa,qa_count=len(qa),qa_mismatches=mismatches,changed_paths=changed,index_changed=index_changed,other_tracked_production_test_QA_and_Task19_to24_owners='unchanged by complete git diff names',test_AST_checks=ast_checks,installed_sql_exact_delta='one CHECK only',frozen_fixture_exact_sha256=hashlib.sha256(frozen.encode()).hexdigest())
(E/'preservation-result.json').write_text(json.dumps(r,indent=2));print(json.dumps({k:v for k,v in r.items() if k!='qa_entries'}))
