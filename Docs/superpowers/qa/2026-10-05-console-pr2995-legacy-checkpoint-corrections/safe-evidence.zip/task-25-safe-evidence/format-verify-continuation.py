import ast,difflib,json,subprocess,sys
from pathlib import Path
E=Path(__file__).resolve().parent;W=E.parents[3];rows=[]
for name in json.loads((E/'owners-continuation.json').read_text()):
 if not name.endswith('.py'):continue
 src=(W/name).read_text();base=(E/('base-'+Path(name).name)).read_text();lines=src.splitlines(True)
 changed=[(c,d) for tag,a,b,c,d in difflib.SequenceMatcher(a=base.splitlines(True),b=lines,autojunk=False).get_opcodes() if tag!='equal']
 argv=[sys.executable,'-m','ruff','format','--no-cache','--stdin-filename',name,'-']
 r=subprocess.run(argv,input=src,text=True,capture_output=True,check=True)
 (E/('format-verify-'+Path(name).name+'.stdout')).write_text(r.stdout);(E/('format-verify-'+Path(name).name+'.stderr')).write_text(r.stderr)
 assert ast.dump(ast.parse(src))==ast.dump(ast.parse(r.stdout)),name
 ops=[(a,b,c,d) for tag,a,b,c,d in difflib.SequenceMatcher(a=lines,b=r.stdout.splitlines(True),autojunk=False).get_opcodes() if tag!='equal']
 added=[op for op in ops if any(op[0]<=y and op[1]>=x for x,y in changed)]
 rows.append(dict(path=name,argv=argv,exit=r.returncode,added_hunk_operations=added,inherited_formatter_operations=[op for op in ops if op not in added],whole_file_AST='exact'))
 assert not added,(name,added)
(E/'format-verify-final-result.json').write_text(json.dumps(rows,indent=2));print(json.dumps(rows))
