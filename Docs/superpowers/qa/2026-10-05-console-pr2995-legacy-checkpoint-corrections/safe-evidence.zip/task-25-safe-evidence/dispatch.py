import json,subprocess,sys
from pathlib import Path
E=Path(__file__).resolve().parent
name,mode=sys.argv[1:]
selectors=json.loads((E/'selectors.json').read_text())
args=['-m','pytest','-q']+(['--collect-only'] if mode=='collect' else [])+selectors
sys.exit(subprocess.call([sys.executable,str(E/'run.py'),name,*args]))
