import json,subprocess,sys
from pathlib import Path
E=Path(__file__).resolve().parent;W=E.parents[3]
argv=['git','diff','--check','1dc472f66ec376fa054797805b12e1105872f28b','--',*json.loads((E/'owners-continuation.json').read_text())]
r=subprocess.run(argv,cwd=W,text=True,capture_output=True)
print(json.dumps(dict(argv=argv,exit=r.returncode,stdout=r.stdout,stderr=r.stderr)));sys.exit(r.returncode)
