import ast,copy,hashlib,json,os,stat,subprocess,xml.etree.ElementTree as X
from pathlib import Path
W=Path(__file__).resolve().parents[4];E=Path(__file__).resolve().parent;S=E.parent
BASE='1dc472f66ec376fa054797805b12e1105872f28b';DISPATCH='bf7e235708b917562d335f9b9fbbc222daa44405'
owners=json.loads((E/'owners-continuation.json').read_text());oldpins=json.loads((S/'task-25-manifest-incomplete.json').read_text())
def digest(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def ast_equal(a,b):return ast.dump(a)==ast.dump(b)
def parsed(src):return ast.parse(src)
def base_src(p):return (E/('base-'+Path(p).name)).read_text()
def current_src(p):return (W/p).read_text()
def declaration_name(n):
 if isinstance(n,ast.Assign):return ','.join(ast.unparse(t) for t in n.targets)
 if isinstance(n,ast.AugAssign):return ast.unparse(n.target)
 return ''
for row in oldpins['artifacts']:assert digest(E/row['path'])==row['sha256'],row['path']
for row in oldpins['context_documents']:
 alias={'task-25-report.md':'task-25-report-incomplete.md','task-25-brief.md':'task-25-brief-dispatched.md'}.get(row['path'],row['path'])
 assert digest(S/alias)==row['sha256'],alias
assert digest(E/'manifest.json')==digest(S/'task-25-manifest-incomplete.json')
for row in oldpins['current_owners'][:5]+[oldpins['current_owners'][6]]:assert digest(W/row['path'])==row['sha256'],row['path']
# Whole module dependency carry: only the three failed test functions may differ from first GREEN.
changed_functions={owners[5]:'test_populated_legacy_queue_paths_are_lossless',owners[7]:'test_shipped76_archive_stages_v77_without_changing_source',owners[8]:'test_schema_policy_matches_installed_store'}
first=json.loads((E/'green-final.json').read_text());carry=[]
for p,h in first['sources_sha256'].items():
 if p not in changed_functions:assert digest(W/p)==h,(p,'first GREEN dependency')
 else:
  old=parsed((E/'green-final-source'/p).read_text());new=parsed(current_src(p));name=changed_functions[p]
  old.body=[n for n in old.body if not isinstance(n,ast.FunctionDef) or n.name!=name]
  new.body=[n for n in new.body if not isinstance(n,ast.FunctionDef) or n.name!=name]
  assert ast_equal(old,new),(p,'unchanged functions/helpers/imports')
# Ninth owner: reverse exactly the census constant, new local import and two-catalog assertion.
p=owners[8];src=current_src(p)
assert src.count('10 if name == "chachanotes" else 2 if name == "prompts" else 1')==1
src=src.replace('10 if name == "chachanotes" else 2 if name == "prompts" else 1','8 if name == "chachanotes" else 2 if name == "prompts" else 1')
assert src.count('            CHACHANOTES_V76_NATIVE_SCHEMAS,\n')==1
src=src.replace('            CHACHANOTES_V76_NATIVE_SCHEMAS,\n','')
addition='        assert policy.schema_sql[-2:] == tuple(\n            (77, schema) for schema in CHACHANOTES_V76_NATIVE_SCHEMAS\n        )\n'
assert src.count(addition)==1;src=src.replace(addition,'');assert ast_equal(parsed(src),parsed(base_src(p)))
# Current existing test bodies outside original explicitly changed dependencies are exact to review BASE.
allowed={owners[5]:{'_legacy_native76','test_legacy_native76_upgrade_preserves_exact_receipts','test_v77_constructor_catalog_matches_exact_native76_capture'},owners[6]:{'_shipped76','test_shipped76_staged_failure_rolls_back_checkpoint_rebuild'},owners[7]:{'test_shipped76_archive_stages_v77_without_changing_source'},owners[8]:{'test_schema_policy_matches_installed_store'}}
for p,names in allowed.items():
 old=parsed(base_src(p));new=parsed(current_src(p));nodes={n.name:n for n in new.body if isinstance(n,(ast.FunctionDef,ast.ClassDef))}
 for n in old.body:
  if isinstance(n,(ast.FunctionDef,ast.ClassDef)) and n.name not in names:assert ast_equal(n,nodes[n.name]),(p,n.name)
# Recovery policy reversal is the sole added strong77 tuple line.
p=owners[2];src=current_src(p);addition='            schemas += tuple((77, schema) for schema in CHACHANOTES_V76_NATIVE_SCHEMAS)\n';assert src.count(addition)==1
assert ast_equal(parsed(src.replace(addition,'')),parsed(base_src(p)))
# Canvas reversal touches only _canvas_schema_access's import and fixed tuple.
p=owners[4];new=parsed(current_src(p));canvas=next(n for n in new.body if isinstance(n,ast.FunctionDef) and n.name=='_canvas_schema_access')
imp=next(n for n in canvas.body if isinstance(n,ast.ImportFrom) and n.module=='tldw_chatbook.DB.recovery_core_schema')
assert sum(n.name=='CHACHANOTES_V76_NATIVE_SCHEMAS' for n in imp.names)==1
imp.names=[n for n in imp.names if n.name!='CHACHANOTES_V76_NATIVE_SCHEMAS']
frozen=next(n for n in canvas.body if declaration_name(n)=='frozen')
assert sum(isinstance(n,ast.Starred) and isinstance(n.value,ast.Name) and n.value.id=='CHACHANOTES_V76_NATIVE_SCHEMAS' for n in frozen.value.elts)==1
frozen.value.elts=[n for n in frozen.value.elts if not (isinstance(n,ast.Starred) and isinstance(n.value,ast.Name) and n.value.id=='CHACHANOTES_V76_NATIVE_SCHEMAS')]
assert ast_equal(new,parsed(base_src(p)))
# Shared catalog owner reversal removes only repaired declarations/stamp pair/import/append operand.
p=owners[3];new=parsed(current_src(p));removed={'_SUBSCRIPTIONS_REPAIRED_RECEIPT_SCHEMAS','_SUBSCRIPTIONS_V77_SCHEMA'}
new.body=[n for n in new.body if declaration_name(n) not in removed]
for n in new.body:
 if isinstance(n,ast.ImportFrom) and n.module=='recovery_core_schema':n.names=[a for a in n.names if a.name!='_CHACHANOTES_V77_QUEUE_CHECK']
 if isinstance(n,ast.AugAssign) and declaration_name(n)=='_SUBSCRIPTIONS_SCHEMA':
  it=n.value.args[0].generators[0].iter
  assert isinstance(it.left,ast.BinOp) and ast.unparse(it.left.left)=='_SUBSCRIPTIONS_REPAIRED_RECEIPT_SCHEMAS'
  it.left=it.left.right
 if isinstance(n,ast.FunctionDef) and n.name=='_subscriptions_chachanotes_stamps':
  assert ast.unparse(n.body[1].test)=='schema in _SUBSCRIPTIONS_REPAIRED_RECEIPT_SCHEMAS'
  del n.body[1]
assert ast_equal(new,parsed(base_src(p)))
# Primary declarations before the exact catalog block, plus immutable historical replacements, are exact.
p=owners[1];old=parsed(base_src(p));new=parsed(current_src(p))
oldmark=next(i for i,n in enumerate(old.body) if declaration_name(n)=='CHACHANOTES_V75_SCHEMA')
newmark=next(i for i,n in enumerate(new.body) if declaration_name(n)=='CHACHANOTES_V75_SCHEMA')
assert ast_equal(ast.Module(body=old.body[:oldmark],type_ignores=[]),ast.Module(body=new.body[:newmark],type_ignores=[]))
for name in ['_CHACHANOTES_V76_REPLACEMENTS','CHACHANOTES_V76_SCHEMA','CHACHANOTES_NATIVE_V76_TO_V77_SQL']:
 assert ast_equal(next(n for n in old.body if declaration_name(n)==name),next(n for n in new.body if declaration_name(n)==name)),name
assert all(isinstance(n,ast.Assign) for n in old.body[oldmark:]+new.body[newmark:])
# Evaluate installed declarations only: no application imports, constructors or archive normalization.
old_primary={};new_primary={};exec(compile(old,'old primary declarations','exec'),old_primary);exec(compile(new,'current primary declarations','exec'),new_primary)
for name in ['CHACHANOTES_V76_NATIVE_SCHEMAS','CHACHANOTES_V76_SHIPPED_SCHEMAS']:
 assert old_primary[name]==new_primary[name],name
oldcheck=new_primary['_CHACHANOTES_V77_QUEUE_CHECK'];newcheck="CHECK (origin != 'agent_chat_start' OR queue_entry_id IS NULL)"
for strong,repaired in zip(new_primary['CHACHANOTES_V76_NATIVE_SCHEMAS'],[new_primary['CHACHANOTES_V77_SCHEMA'],new_primary['CHACHANOTES_DICTIONARY_UPDATE_SCHEMA']]):
 assert tuple(s.replace(oldcheck,newcheck) for s in strong)==repaired
 assert sum(a!=b for a,b in zip(strong,repaired))==1

def shared_declarations(src,primary):
 module=parsed(src);nodes=[n for n in module.body if declaration_name(n).startswith('_SUBSCRIPTIONS') or isinstance(n,ast.FunctionDef) and n.name=='_subscriptions_chachanotes_stamps']
 ns={k:v for k,v in primary.items() if k.startswith('_CHAT_DICTIONARIES') or k=='_CHACHANOTES_V77_QUEUE_CHECK'}
 exec(compile(ast.Module(body=nodes,type_ignores=[]),'shared catalog declarations','exec'),ns);return ns
old_shared=shared_declarations(base_src(owners[3]),old_primary);new_shared=shared_declarations(current_src(owners[3]),new_primary)
for name in ['_SUBSCRIPTIONS_NATIVE_RECEIPT_SCHEMAS','_SUBSCRIPTIONS_SHIPPED_CHACHANOTES_SCHEMAS']:
 assert old_shared[name]==new_shared[name],name
for schema in new_shared['_SUBSCRIPTIONS_NATIVE_RECEIPT_SCHEMAS']:assert new_shared['_subscriptions_chachanotes_stamps'](schema)==((76,),(77,))
for schema in new_shared['_SUBSCRIPTIONS_SHIPPED_CHACHANOTES_SCHEMAS']:assert new_shared['_subscriptions_chachanotes_stamps'](schema)==((75,),(76,))
for strong,repaired in zip(new_shared['_SUBSCRIPTIONS_NATIVE_RECEIPT_SCHEMAS'],new_shared['_SUBSCRIPTIONS_REPAIRED_RECEIPT_SCHEMAS']):
 assert tuple(s.replace(oldcheck,newcheck) for s in strong)==repaired
 assert sum(a!=b for a,b in zip(strong,repaired))==1
 assert new_shared['_subscriptions_chachanotes_stamps'](repaired)==((77,),)
# SQL and exact frozen feature fixture are bound independently of current capture.
assert base_src(owners[0]).replace(oldcheck,newcheck)==current_src(owners[0])
frozen_sql=next(n.value.value for n in parsed(current_src(owners[5])).body if declaration_name(n)=='_FROZEN_NATIVE76_MIGRATION')
assert frozen_sql.encode()==(S/'task-25-frozen-native76-migration.sql').read_bytes()
assert hashlib.sha256(frozen_sql.encode()).hexdigest()=='423978f7c23189e36ce4c5172cfd6d2b887abcc1f6abc057f86f61e55ca17fa8'
# Batch Git/object preservation: QA and every other production/test path are checked via stdlib blob SHA1.
raw=subprocess.check_output(['git','ls-tree','-r','-z',BASE],cwd=W);entries=[]
for item in raw.split(b'\0'):
 if not item:continue
 header,path=item.split(b'\t',1);mode,kind,blob=header.decode().split();entries.append(dict(mode=mode,kind=kind,blob=blob,path=os.fsdecode(path)))
qa=[r for r in entries if r['path'].startswith(('Docs/superpowers/qa/','qa/'))];assert len(qa)==12589
extra=[r for r in qa if r['path'].startswith('Docs/superpowers/qa/2026-10-05-console-pr2995-final-corrections/')];assert len(extra)==7
unowned=[r for r in entries if r['path'].startswith(('tldw_chatbook/','Tests/')) and r['path'] not in owners]
for r in qa+unowned:
 p=W/r['path'];st=p.lstat();data=os.fsencode(os.readlink(p)) if stat.S_ISLNK(st.st_mode) else p.read_bytes()
 blob=hashlib.sha1(b'blob '+str(len(data)).encode()+b'\0'+data).hexdigest();mode='120000' if stat.S_ISLNK(st.st_mode) else '100755' if st.st_mode&stat.S_IXUSR else '100644'
 assert (mode,blob)==(r['mode'],r['blob']),r['path']
changed=subprocess.check_output(['git','diff','--name-only',BASE,'--','tldw_chatbook','Tests','Docs/superpowers/qa','qa'],cwd=W,text=True).splitlines();assert set(changed)==set(owners),changed
working=subprocess.check_output(['git','diff','--name-only',DISPATCH],cwd=W,text=True).splitlines();assert set(working)==set(changed_functions),working
assert not subprocess.check_output(['git','diff','--cached','--name-only','HEAD'],cwd=W).strip()
# 102 successes carry from their exact phase; the nine corrections complete the same111 case set.
first_tests=list(X.parse(E/'green-final.xml').iter('testcase'));last_tests=list(X.parse(E/'continuation-green.xml').iter('testcase'))
def key(t):return t.attrib['classname']+'::'+t.attrib['name']
def passed(t):return all(t.find(n) is None for n in ['failure','error','skipped'])
first_pass=[t for t in first_tests if passed(t)];first_fail=[t for t in first_tests if not passed(t)]
assert len(first_tests)==111 and len(first_pass)==102 and len(first_fail)==9 and len(last_tests)==9 and all(passed(t) for t in last_tests)
assert {key(t) for t in first_fail}=={key(t) for t in last_tests}
for t in first_pass:
 paths=[p for p in first['sources_sha256'] if t.attrib['classname'].startswith(p[:-3].replace('/','.'))]
 p=max(paths,key=len);name=t.attrib['name'].split('[')[0]
 assert p not in changed_functions or name!=changed_functions[p]
 carry.append(dict(case=key(t),phase='green-final',file=p,source_sha256=first['sources_sha256'][p],proof='exact whole source' if p not in changed_functions else 'exact full module AST except the separate failed test function; helpers/imports unchanged',result='PASS'))
carry += [dict(case=key(t),phase='continuation-green',result='PASS') for t in last_tests]
assert len({r['case'] for r in carry})==111
catalog_pins={}
for label,schemas in [('old_primary_strong',old_primary['CHACHANOTES_V76_NATIVE_SCHEMAS']),('repaired_primary',[new_primary['CHACHANOTES_V77_SCHEMA'],new_primary['CHACHANOTES_DICTIONARY_UPDATE_SCHEMA']]),('old_shared_strong',old_shared['_SUBSCRIPTIONS_NATIVE_RECEIPT_SCHEMAS']),('repaired_shared',new_shared['_SUBSCRIPTIONS_REPAIRED_RECEIPT_SCHEMAS'])]:
 catalog_pins[label]=[dict(entries=len(s),sha256=hashlib.sha256(json.dumps(s).encode()).hexdigest()) for s in schemas]
(E/'qualified-final-cases.json').write_text(json.dumps(carry,indent=2))
r=dict(original_review_base=BASE,continuation_dispatch=DISPATCH,original141artifact_and5context_pins='exact via declared aliases',original_manifest='unchanged',unchanged_production_and_compatibility_hashes=[r for r in oldpins['current_owners'] if r['path'] in owners[:5]+[owners[6]]],qualified_cases=111,first_phase_carry=102,corrected_phase=9,passing_functions_helpers_imports_AST='exact',core_owner_three_changes_AST_reversal='exact original BASE',Canvas_function_only_import_and_tuple_reversal='exact original BASE',shared_catalog_reversal='exact original BASE',primary_unowned_AST_and_historical_replacements='exact',catalog_pins=catalog_pins,qa_basis='one Git ls-tree BASE and stdlib mode/Git-blob-SHA1 comparison of current files; no per-file subprocess',qa_count=len(qa),original_qa_count=len(qa)-len(extra),additional_published_qa=len(extra),qa_entries=qa,unowned_production_test_count=len(unowned),unowned_production_test_entries=unowned,changed_source_test_QA_paths=changed,working_changes_from_dispatch=working,frozen_native_fixture_sha256=hashlib.sha256(frozen_sql.encode()).hexdigest(),installed_SQL_delta='single machine-only CHECK; every other byte exact')
(E/'preservation-final-result.json').write_text(json.dumps(r,indent=2));print(json.dumps({k:v for k,v in r.items() if k not in ['qa_entries','unowned_production_test_entries']}))
