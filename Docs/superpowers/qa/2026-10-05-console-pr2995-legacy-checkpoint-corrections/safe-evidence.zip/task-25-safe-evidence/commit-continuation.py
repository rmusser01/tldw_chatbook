import hashlib,json,subprocess
from pathlib import Path
E=Path(__file__).resolve().parent;W=E.parents[3]
paths=['Tests/DB/test_chachanotes_v77_agent_chat_starts_migration.py','Tests/Backup_Recovery/test_restore_plan.py','Tests/Backup_Recovery/test_core_owners.py']
for phase in ['continuation-green','fatal-ruff','format-verify-final','whitespace-final','preservation-final']:
 r=json.loads((E/(phase+'.json')).read_text());assert r['exit']==0 and r['closed'] and r['source_stable'],phase
 for p,h in r['sources_sha256'].items():assert hashlib.sha256((W/p).read_bytes()).hexdigest()==h,(phase,p)
assert set(subprocess.check_output(['git','diff','--name-only'],cwd=W,text=True).splitlines())==set(paths)
subprocess.run(['git','add','--',*paths],cwd=W,check=True)
assert set(subprocess.check_output(['git','diff','--cached','--name-only'],cwd=W,text=True).splitlines())==set(paths)
subprocess.run(['git','commit','-m','test: correct legacy checkpoint probes and exact catalog census'],cwd=W,check=True)
assert not subprocess.check_output(['git','status','--porcelain'],cwd=W).strip()
print(subprocess.check_output(['git','log','-1','--format=%H %s'],cwd=W,text=True).strip())
print('Three test owners committed; production hashes stable; tracked checkout/index clean.')
