from __future__ import annotations
import ast, hashlib, json, os, subprocess, sys
from pathlib import Path
ROOT=Path.cwd(); BASE='bead15b446bb0c146b9ca5993382437a0eff4d78'
ART=Path('.superpowers/sdd/2026-10-03-console-pr2995-review-and-merge/task-24-safe-evidence')
OWNERS=['tldw_chatbook/Chat/console_chat_start.py','tldw_chatbook/Agents/tool_catalog.py']
NEW='Docs/superpowers/qa/2026-10-05-console-pr2995-final-corrections/'
def digest(b): return hashlib.sha256(b).hexdigest()
def blob_sha(data): return hashlib.sha1(b'blob '+str(len(data)).encode()+b'\0'+data).hexdigest()
def tree(rev):
 raw=subprocess.check_output(['git','ls-tree','-r','--full-tree','-z',rev],cwd=ROOT); out={}
 for row in raw.split(b'\0'):
  if row:
   meta,path=row.split(b'\t',1); mode,kind,oid=meta.decode().split(); out[os.fsdecode(path)]=(mode,oid)
 return out
def schema_desc(module):
 assign=next(n for n in module.body if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='NEW_CHAT_TOOL_SCHEMA' for t in n.targets))
 params=next(n.value for n in ast.walk(assign) if isinstance(n,ast.keyword) and n.arg=='parameters')
 def value(d,key): return next(v for k,v in zip(d.keys,d.values) if isinstance(k,ast.Constant) and k.value==key)
 return value(value(value(params,'properties'),'opening_prompt'),'description')
def current(path):
 f=Path(path)
 if not f.is_file(): return None
 data=f.read_bytes(); mode='100755' if f.stat().st_mode&0o111 else '100644'
 return mode,blob_sha(data)
def main():
 assert subprocess.check_output(['git','rev-parse','--show-object-format'],cwd=ROOT,text=True).strip()=='sha1'
 owner_proof={}
 for p in OWNERS:
  base_text=subprocess.check_output(['git','show',f'{BASE}:{p}'],cwd=ROOT,text=True); final_text=Path(p).read_text()
  base,final=ast.parse(base_text),ast.parse(final_text)
  if p.endswith('console_chat_start.py'):
   def start(m): return next(n for n in ast.walk(m) if isinstance(n,ast.AsyncFunctionDef) and n.name=='start')
   start(final).body[0].value=start(base).body[0].value
  else: schema_desc(final).value=schema_desc(base).value
  left,right=ast.dump(base,include_attributes=False),ast.dump(final,include_attributes=False)
  assert left==right, 'owner AST differs after reversal: '+p
  owner_proof[p]={'base_ast_sha256':digest(left.encode()),'reversed_ast_sha256':digest(right.encode()),'equal':True}
 baseline=tree(BASE); prefixes=('Docs/superpowers/qa/','qa/')
 qa={p:(m,b) for p,(m,b) in baseline.items() if p.startswith(prefixes) and m in ('100644','100755')}
 assert len(qa)==12589, len(qa)
 qa_bad=[p for p,v in qa.items() if current(p)!=v]
 added={p:v for p,v in qa.items() if p.startswith(NEW)}
 assert len(added)==7, sorted(added)
 old={p:v for p,v in qa.items() if p not in added}
 assert len(old)==12582 and sum(p.startswith('Docs/superpowers/qa/') for p in old)==10555 and sum(p.startswith('qa/') for p in old)==2027
 assert not qa_bad, qa_bad[:10]
 src={p:(m,b) for p,(m,b) in baseline.items() if p.startswith('tldw_chatbook/') and p not in OWNERS and m in ('100644','100755')}
 src_bad=[p for p,v in src.items() if current(p)!=v]
 assert not src_bad, src_bad[:10]
 return {'base':BASE,'python':sys.version,'git_object_format':'sha1','whole_owner_ast_reversal':{'owners':owner_proof,'all_equal':True},'qa_mode_blob_path_preservation':{'current_count':len(qa),'current_prefix_counts':{'Docs/superpowers/qa/':10562,'qa/':2027},'current_all_unchanged':True,'seven_post_task23_publication_paths':{p:{'mode':v[0],'blob':v[1]} for p,v in sorted(added.items())},'original_task23_set_count':len(old),'original_task23_prefix_counts':{'Docs/superpowers/qa/':10555,'qa/':2027},'original_task23_set_unchanged':True},'unowned_base_source':{'count':len(src),'mode_blob_path_matches':True},'pass':True}
result=main(); (ART/'ast-and-preservation-v4.json').write_text(json.dumps(result,indent=2)+'\n'); print(json.dumps(result,indent=2))
