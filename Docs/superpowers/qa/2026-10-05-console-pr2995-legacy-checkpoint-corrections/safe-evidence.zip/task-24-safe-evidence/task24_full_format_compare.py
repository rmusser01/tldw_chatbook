from __future__ import annotations
import hashlib, json, subprocess, tempfile
from pathlib import Path
root=Path.cwd(); base='bead15b446bb0c146b9ca5993382437a0eff4d78'; py='/Users/macbook-dev/Documents/GitHub/tldw_chatbook/.venv/bin/python3.12'
owners=['tldw_chatbook/Chat/console_chat_start.py','tldw_chatbook/Agents/tool_catalog.py']; art=Path('.superpowers/sdd/2026-10-03-console-pr2995-review-and-merge/task-24-safe-evidence')
def sha(b): return hashlib.sha256(b).hexdigest()
current_hashes={p:sha((root/p).read_bytes()) for p in owners}
results=[]
with tempfile.TemporaryDirectory(prefix='task24-base-format-') as td:
 for i,p in enumerate(owners):
  old=subprocess.check_output(['git','show',f'{base}:{p}'],cwd=root)
  snap=Path(td)/f'base-{i}.py';snap.write_bytes(old)
  for label,target,input_sha in [('base',str(snap),sha(old)),('current',p,current_hashes[p])]:
   argv=[py,'-m','ruff','format','--check',target]
   r=subprocess.run(argv,cwd=root,capture_output=True)
   name=f'whole-format-{i}-{label}'
   (art/f'{name}.stdout').write_bytes(r.stdout);(art/f'{name}.stderr').write_bytes(r.stderr)
   results.append({'name':name,'argv':argv,'exit':r.returncode,'input_sha256':input_sha,'owner':p,'stdout_sha256':sha(r.stdout),'stderr_sha256':sha(r.stderr)})
assert {p:sha((root/p).read_bytes()) for p in owners}==current_hashes
(art/'whole-format-comparison.json').write_text(json.dumps({'base':base,'current_source_sha256':current_hashes,'results':results},indent=2)+'\n')
print(json.dumps(results,indent=2))
