from __future__ import annotations
import hashlib,json,subprocess
from pathlib import Path
root=Path.cwd(); art=Path('.superpowers/sdd/2026-10-03-console-pr2995-review-and-merge/task-24-safe-evidence')
owners=['tldw_chatbook/Chat/console_chat_start.py','tldw_chatbook/Agents/tool_catalog.py']
def run(argv):
 r=subprocess.run(argv,cwd=root,capture_output=True,text=True)
 return {'argv':argv,'exit':r.returncode,'stdout':r.stdout,'stderr':r.stderr}
checks=[run(['git','rev-parse','HEAD']),run(['git','status','--short','--branch']),run(['git','diff-index','--quiet','HEAD','--']),run(['git','diff','--cached','--quiet']),run(['ps','-Ao','pid,ppid,command'])]
scan=checks[-1]['stdout']; leftovers=[line for line in scan.splitlines() if any(x in line for x in ('git gc','git repack','git pack-objects'))]
assert not leftovers, leftovers
assert checks[0]['exit']==0 and checks[1]['exit']==0 and checks[2]['exit']==0 and checks[3]['exit']==0
source={p:hashlib.sha256(Path(p).read_bytes()).hexdigest() for p in owners}
receipt={'head':checks[0]['stdout'].strip(),'checks':checks[:4],'process_scan':{'argv':checks[4]['argv'],'exit':checks[4]['exit'],'matching_git_maintenance_processes':leftovers},'source_sha256':source,'tracked_worktree_and_index_clean':True,'owned_processes_closed':True}
(art/'closure-receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
