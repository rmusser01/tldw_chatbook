from __future__ import annotations
import ast, hashlib, json, os, subprocess, sys
from pathlib import Path
ROOT=Path.cwd(); BASE='bead15b446bb0c146b9ca5993382437a0eff4d78'
ART=Path('.superpowers/sdd/2026-10-03-console-pr2995-review-and-merge/task-24-safe-evidence')
OWNERS=['tldw_chatbook/Chat/console_chat_start.py','tldw_chatbook/Agents/tool_catalog.py']
def digest(b): return hashlib.sha256(b).hexdigest()
def tree(rev):
 raw=subprocess.check_output(['git','ls-tree','-r','--full-tree','-z',rev],cwd=ROOT); out={}
 for row in raw.split(b'\0'):
  if row:
   meta,path=row.split(b'\t',1); mode,kind,oid=meta.decode().split(); out[os.fsdecode(path)]=(mode,oid)
 return out
def schema_desc(module):
 assign=next(n for n in module.body if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='NEW_CHAT_TOOL_SCHEMA' for t in n.targets))
 params=next(n.value for n in ast.walk(assign) if isinstance(n,ast.keyword) and n.arg=='parameters')
 def value(d,key): return next(v for k,v in zip(d.keys,d.values) if isinstance(k,ast.Constant) and k.value==key)
 return value(value(value(params,'properties'),'opening_prompt'),'description')
def proofs():
 owner_proof={}
 for p in OWNERS:
  base_text=subprocess.check_output(['git','show',f'{BASE}:{p}'],cwd=ROOT,text=True); final_text=Path(p).read_text()
  base,final=ast.parse(base_text),ast.parse(final_text)
  if p.endswith('console_chat_start.py'):
   def start(m): return next(n for n in ast.walk(m) if isinstance(n,ast.AsyncFunctionDef) and n.name=='start')
   base_doc=start(base).body[0].value; start(final).body[0].value=base_doc
  else: schema_desc(final).value=schema_desc(base).value
  left,right=ast.dump(base,include_attributes=False),ast.dump(final,include_attributes=False)
  assert left==right, 'owner AST differs after reversal: '+p
  owner_proof[p]={'base_ast_sha256':digest(left.encode()),'reversed_ast_sha256':digest(right.encode()),'equal':True}
 baseline=tree(BASE); prefixes=('Docs/superpowers/qa/','qa/')
 qa={p:(m,b) for p,(m,b) in baseline.items() if p.startswith(prefixes) and m in ('100644','100755')}
 assert len(qa)==12582, len(qa)
 def current(path):
  f=Path(path)
  if not f.is_file(): return None
  mode='100755' if f.stat().st_mode&0o111 else '100644'
  blob=subprocess.check_output(['git','hash-object','--',path],cwd=ROOT,text=True).strip()
  return mode,blob
 qa_bad=[p for p,v in qa.items() if current(p)!=v]
 src={p:(m,b) for p,(m,b) in baseline.items() if p.startswith('tldw_chatbook/') and p not in OWNERS and m in ('100644','100755')}
 src_bad=[p for p,v in src.items() if current(p)!=v]
 assert not qa_bad, qa_bad[:8]; assert not src_bad,src_bad[:8]
 return {'base':BASE,'python':sys.version,'whole_owner_ast_reversal':{'owners':owner_proof,'all_equal':True},'historical_qa':{'count':len(qa),'prefix_counts':{p:sum(x.startswith(p) for x in qa) for p in prefixes},'mode_blob_path_matches':True},'unowned_base_source':{'count':len(src),'mode_blob_path_matches':True},'pass':True}
result=proofs(); (ART/'ast-and-preservation-v2.json').write_text(json.dumps(result,indent=2)+'\n'); print(json.dumps(result,indent=2))
