from __future__ import annotations

import ast
import hashlib
import json
import os
import subprocess
import sys
from pathlib import Path

ROOT = Path.cwd()
BASE = "bead15b446bb0c146b9ca5993382437a0eff4d78"
PYTHON = "/Users/macbook-dev/Documents/GitHub/tldw_chatbook/.venv/bin/python3.12"
ART = Path(".superpowers/sdd/2026-10-03-console-pr2995-review-and-merge/task-24-safe-evidence")
OWNERS = ["tldw_chatbook/Chat/console_chat_start.py", "tldw_chatbook/Agents/tool_catalog.py"]

def sha(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()

def run(name: str, argv: list[str], source_paths: list[str]) -> dict:
    before = {p: sha((ROOT / p).read_bytes()) for p in source_paths}
    result = subprocess.run(argv, cwd=ROOT, capture_output=True)
    after = {p: sha((ROOT / p).read_bytes()) for p in source_paths}
    (ART / f"{name}.stdout").write_bytes(result.stdout)
    (ART / f"{name}.stderr").write_bytes(result.stderr)
    receipt = {"name": name, "argv": argv, "cwd": str(ROOT), "exit": result.returncode,
               "source_sha256_before": before, "source_sha256_after": after,
               "stdout_sha256": sha(result.stdout), "stderr_sha256": sha(result.stderr)}
    (ART / f"{name}.json").write_text(json.dumps(receipt, indent=2) + "\n")
    return receipt

def tree(revision: str) -> dict[str, tuple[str, str]]:
    raw = subprocess.check_output(["git", "ls-tree", "-r", "--full-tree", "-z", revision], cwd=ROOT)
    entries: dict[str, tuple[str, str]] = {}
    for row in raw.split(b"\0"):
        if not row:
            continue
        meta, path = row.split(b"\t", 1)
        mode, kind, oid = meta.decode().split()
        entries[os.fsdecode(path)] = (mode, oid)
    return entries

def ast_reversal() -> dict:
    sources = {}
    for path in OWNERS:
        base_text = subprocess.check_output(["git", "show", f"{BASE}:{path}"], cwd=ROOT, text=True)
        final_text = (ROOT / path).read_text()
        before, after = ast.parse(base_text), ast.parse(final_text)
        if path.endswith("console_chat_start.py"):
            def method(module):
                return next(n for n in ast.walk(module) if isinstance(n, ast.AsyncFunctionDef) and n.name == "start")
            base_node, final_node = method(before), method(after)
            assert isinstance(base_node.body[0], ast.Expr) and isinstance(base_node.body[0].value, ast.Constant)
            final_node.body[0].value.value = base_node.body[0].value.value
        else:
            def schema_desc(module):
                assign = next(n for n in module.body if isinstance(n, ast.Assign) and any(isinstance(t, ast.Name) and t.id == "NEW_CHAT_TOOL_SCHEMA" for t in n.targets))
                props = next(n.value for n in ast.walk(assign) if isinstance(n, ast.keyword) and n.arg == "parameters")
                properties = next(k.value for k in props.keys if isinstance(k, ast.Constant) and k.value == "properties")
                opening = next(k.value for k in properties.keys if isinstance(k, ast.Constant) and k.value == "opening_prompt")
                return next(k.value for k in opening.keys if isinstance(k, ast.Constant) and k.value == "description")
            schema_desc(after).value = schema_desc(before).value
        equal = ast.dump(before, include_attributes=False) == ast.dump(after, include_attributes=False)
        assert equal, f"whole-owner AST differs after reversal: {path}"
        sources[path] = {"base_ast_sha256": sha(ast.dump(ast.parse(base_text), include_attributes=False).encode()),
                         "reversed_ast_sha256": sha(ast.dump(after, include_attributes=False).encode()), "equal": equal}
    return {"python": sys.version, "base": BASE, "owners": sources, "pass": True}

def preservation() -> dict:
    baseline = tree(BASE)
    qa_prefixes = ("Docs/superpowers/qa/", "qa/")
    qa = {p: v for p, v in baseline.items() if p.startswith(qa_prefixes) and v[0] in ("100644", "100755")}
    assert len(qa) == 12582, len(qa)
    qa_diffs = []
    for path, (mode, blob) in qa.items():
        file = ROOT / path
        actual_mode = "100755" if file.stat().st_mode & 0o111 else "100644"
        actual_blob = subprocess.check_output(["git", "hash-object", "--", path], cwd=ROOT, text=True).strip()
        if (mode, blob) != (actual_mode, actual_blob):
            qa_diffs.append(path)
    source = {p: v for p, v in baseline.items() if p.startswith("tldw_chatbook/") and p not in OWNERS and v[0] in ("100644", "100755")}
    source_diffs = []
    for path, (mode, blob) in source.items():
        file = ROOT / path
        if not file.exists():
            source_diffs.append(path); continue
        actual_mode = "100755" if file.stat().st_mode & 0o111 else "100644"
        actual_blob = subprocess.check_output(["git", "hash-object", "--", path], cwd=ROOT, text=True).strip()
        if (mode, blob) != (actual_mode, actual_blob): source_diffs.append(path)
    assert not qa_diffs, qa_diffs[:10]
    assert not source_diffs, source_diffs[:10]
    return {"base": BASE, "historical_qa": {"count": len(qa), "prefix_counts": {p: sum(x.startswith(p) for x in qa) for p in qa_prefixes}, "mode_blob_path_matches": True},
            "unowned_base_source": {"count": len(source), "mode_blob_path_matches": True}, "pass": True}

if __name__ == "__main__":
    result = {
      "fatal_ruff": run("fatal-ruff", [PYTHON, "-m", "ruff", "check", *OWNERS, "--select", "E9,F63,F7,F82"], OWNERS),
      "format_start_hunk": run("format-start-hunk", [PYTHON, "-m", "ruff", "format", "--check", "--range", "290-306", OWNERS[0]], [OWNERS[0]]),
      "format_schema_hunk": run("format-schema-hunk", [PYTHON, "-m", "ruff", "format", "--check", "--range", "813-821", OWNERS[1]], [OWNERS[1]]),
      "whitespace": run("whitespace", ["git", "diff", "--check", "--", *OWNERS], OWNERS),
      "ast_reversal": ast_reversal(),
      "preservation": preservation(),
    }
    (ART / "proofs.json").write_text(json.dumps(result, indent=2) + "\n")
    for name, value in result.items():
        print(name, "PASS" if value.get("pass", value.get("exit") == 0) else "FAIL")
        if value.get("exit", 0): print((ART / f"{name}.stderr").read_text())
