# Task 24 — start method and opening prompt prose

Status: DONE. Commit `a87b5f2da51e1bd70393c3f6ac1e31b5a3cf30e4` (`docs(console): clarify new chat start prose`).

## Changes

- Expanded only `ConsoleChatStartCoordinator.start`’s docstring with its request fields, outcomes, and cancellation ownership contract.
- Replaced only `NEW_CHAT_TOOL_SCHEMA.parameters.properties.opening_prompt.description` with the specified draft/start behavior and literal-text guidance.
- Used existing contract [ADR-219](../../backlog/decisions/219-console-chat-destinations-and-bounded-starts.md); no ADR or behavior change was needed.

The start method’s refusal, cancellation, acceptance, receipt, settlement, and outcome-publication helpers support the supplied wording. The separate migration repair in Task 25 remains open.

## Evidence

- Fatal Ruff (`E9,F63,F7,F82`) passed on both owners. Added-hunk Ruff formatting passed on each changed range; whole-file formatting also passed for both BASE and final files. There is no inherited formatter debt in these owners. `git diff --check` passed.
- Whole-owner Python 3.12 AST reversal passed: restoring only the original method docstring and schema description reproduced both complete BASE owner ASTs.
- Preservation passed for all 12,589 BASE QA entries (10,562 under `Docs/superpowers/qa/`, 2,027 under `qa/`) by mode, Git blob, and path. The seven files under `Docs/superpowers/qa/2026-10-05-console-pr2995-final-corrections/` were published after Task 23. Removing those seven yields Task 23’s exact 12,582 set (10,555 plus 2,027), unchanged. All 3,062 other BASE `tldw_chatbook/` files also match mode and blob.
- No tests were replayed, as required for these prose-only changes.

## Self-review and execution notes

The source diff contains only the two specified prose replacements. The changed ranges are formatted and the final commit owns only those two source files.

The first combined evidence helper had an AST dictionary-navigation error after its four static checks had passed. Its initial QA census then exposed seven later-published QA files beyond Task 23’s frozen count; that failed receipt is preserved unchanged. After the scope was clarified, a per-file Git subprocess proof attempt produced no receipt output in 13.9 seconds. The final proof used in-process Git blob hashing, completed in 6.2 seconds, and passed; the earlier failures remain in `task-24-safe-evidence/` for traceability.

Commit output reported Git’s automatic background packing and an existing unreachable-object warning. No GC, prune, cleanup, or other maintenance command was issued. The final process scan found no Git packing process. The index and tracked worktree are clean at the recorded commit.

Full command streams, hashes, preservation details, failure provenance, and final custody receipt are pinned in `task-24-safe-evidence/manifest.json`.

## Evidence provenance correction

The preceding note that the v3 proof produced no receipt was an incorrect, premature observation. The already-existing `task-24-safe-evidence/ast-and-preservation-v3.json` and matching stdout contain a successful result (`pass: true`): whole-owner AST reversal passed; all 12,589 BASE QA mode/blob/path entries matched; the seven post-Task23 publication paths are identified; the remaining 12,582 entries match the frozen Task 23 set; and all 3,062 unowned BASE source files matched. V3 stderr is empty. The v3 files were present before this correction; no proof was rerun.

The exact v3 process exit status, elapsed time, and source-byte hashes at the moment it read the owners were not retained. The earlier 13.9-second observation therefore cannot be attributed confidently to v3 and should not be treated as its runtime. V4 remains a separate successful proof with its recorded 6.2-second observation. The original report text remains byte-for-byte available as `task-24-report-before-provenance-correction.md`; `manifest-final.json` maps the frozen original report pin through that alias and pins this corrected report and both brief copies.
