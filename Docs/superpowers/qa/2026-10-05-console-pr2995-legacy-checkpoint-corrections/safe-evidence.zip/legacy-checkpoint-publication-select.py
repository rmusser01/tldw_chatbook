"""Select exact reviewed Task24/25/26 evidence; no recursive export."""
import hashlib,json
from pathlib import Path
D=Path(__file__).resolve().parent
def main():
 selected={}
 def pin(path,row=None):
  p=Path(path);assert not p.is_absolute() and '..' not in p.parts
  b=(D/p).read_bytes();h=hashlib.sha256(b).hexdigest()
  if row is not None:
   assert h==row['sha256'],path
   if 'bytes' in row:assert len(b)==row['bytes'],path
  value={'path':path,'bytes':len(b),'sha256':h}
  if path in selected:assert selected[path]==value
  selected[path]=value
 def manifest(path):
  pin(path);return json.loads((D/path).read_text())
 m=manifest('task-24-safe-evidence/manifest-final.json')
 for path,row in m['original_artifact_pins'].items():
  if path==m['prior_report_pin_resolution']['original_path']:path=m['prior_report_pin_resolution']['frozen_alias_path']
  pin(path,row)
 for path,row in m['corrected_artifacts'].items():pin(path,row)
 for path in ('task-24-safe-evidence/manifest.json','task-24-manifest-before-provenance-correction.json','task-24-root-final-pin-verification.json','task-24-independent-review.md','review-bead15b446..a87b5f2da5.diff','task-24-initial-feedback.json'):pin(path)
 m=manifest('task-25-safe-evidence/manifest-final.json')
 for row in m['artifacts']:pin('task-25-safe-evidence/'+row['path'],row)
 for row in m['context_documents']:pin(row['path'],row)
 for path in ('task-25-root-final-handoff-verification.json','task-25-independent-review.md','review-1dc472f66e..f52c11b3d8.diff'):pin(path)
 m=manifest('task-26-root-verification.json')
 for path,row in m['files'].items():pin(path,row)
 pin('legacy-checkpoint-prepublication-remote-state.json')
 pin('legacy-checkpoint-publication-select.py')
 out={'status':'APPROVED_SAFE_SELECTION','selection':'Exact final manifest pins and named frozen aliases, scoped reviews/feedback/root proofs; no recursive workspace export. Requires approved Task24/25 reviews before execution.','entries':sorted(selected.values(),key=lambda r:r['path'])}
 (D/'legacy-checkpoint-publication-selection.json').write_text(json.dumps(out,indent=2)+'\n')
 print(json.dumps({'selected':len(selected)}))
if __name__=='__main__':main()
