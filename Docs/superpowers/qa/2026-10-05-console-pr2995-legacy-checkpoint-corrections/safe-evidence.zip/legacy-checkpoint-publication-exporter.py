"""Fresh explicit safe publication; preserve every earlier checkpoint."""
import ast,hashlib,json,os,re,subprocess,tomllib,zipfile
from pathlib import Path
W=Path('/Users/macbook-dev/.codex/worktrees/console-chat-starts/tldw_chatbook')
D=W/'.superpowers/sdd/2026-10-03-console-pr2995-review-and-merge'
OUT=W/'Docs/superpowers/qa/2026-10-05-console-pr2995-legacy-checkpoint-corrections'
TOP=['legacy-checkpoint-publication-selection.json', 'legacy-checkpoint-publication-exporter.py', 'legacy-checkpoint-corrections-publication.md', 'rulings-i-made-after-legacy-checkpoint-corrections.md', 'complete-ledger-after-legacy-checkpoint-corrections.md']
def sha(b):return hashlib.sha256(b).hexdigest()
def git(*a):return subprocess.check_output(['git',*a],cwd=W)
def main():
 assert git('status','--porcelain')==b'', 'clean source/metadata first'
 selected={};excluded=[]
 def pin(rel,row=None):
  p=Path(rel);assert not p.is_absolute() and '..' not in p.parts,rel
  f=D/p;assert f.is_file() and f.resolve().is_relative_to(D.resolve()),rel
  assert not any(q.is_symlink() for q in (f,*f.parents) if q.is_relative_to(D)),rel
  b=f.read_bytes();h=sha(b)
  if row is not None:
   expected=row if isinstance(row,str) else row['sha256'];assert h==expected,rel
   if isinstance(row,dict) and 'bytes' in row:assert len(b)==row['bytes'],rel
  if rel in selected:assert selected[rel]['sha256']==h
  selected[rel]={'path':rel,'bytes':len(b),'sha256':h}
  return b
 selection=json.loads((D/'legacy-checkpoint-publication-selection.json').read_text())
 assert selection['status']=='APPROVED_SAFE_SELECTION'
 for row in selection['entries']:pin(row['path'],row)
 for p in TOP:pin(p)
 # Keep credentials in memory; never write actual values to audit output.
 known=set()
 def collect(x,key=''):
  if isinstance(x,dict):
   for k,v in x.items():collect(v,k)
  elif isinstance(x,list):
   for v in x:collect(v,key)
  elif isinstance(x,str) and re.search(r'(api.?key|token|password|secret)',key,re.I) and not key.endswith(('_env_var','_env')) and len(x)>=12 and not re.search(r'(<.*>|YOUR_|HERE|example|placeholder)',x,re.I):known.add(x.encode())
 collect(tomllib.loads(Path('/Users/macbook-dev/.config/tldw_cli/config.toml').read_text()))
 for k,v in os.environ.items():
  if re.search(r'(api.?key|token|password|secret)',k,re.I) and len(v)>=12:known.add(v.encode())
 public=set();provenance=[]
 for p,name in [('tldw_chatbook/config.py','TLDW_API_PLACEHOLDER_AUTH_TOKEN'),('Tests/UI/test_settings_encryption_card.py','PLAINTEXT_KEY'),('Tests/test_config_encryption_lifecycle.py','PLAINTEXT_KEY')]:
  b=(W/p).read_bytes();values=[]
  for n in ast.walk(ast.parse(b)):
   if isinstance(n,(ast.Assign,ast.AnnAssign)):
    targets=n.targets if isinstance(n,ast.Assign) else [n.target]
    if any(isinstance(t,ast.Name) and t.id==name for t in targets):
     assert isinstance(n.value,ast.Constant) and isinstance(n.value.value,str);values.append(n.value.value)
  assert len(values)==1
  if name=='PLAINTEXT_KEY':assert 'plaintext' in values[0].lower()
  public.add(values[0].encode());provenance.append(dict(path=p,constant=name,source_sha256=sha(b),category='public placeholder or deterministic encryption fixture'))
 known.difference_update(public)
 patterns=[re.compile(rb'-----BEGIN (?:RSA |EC |OPENSSH |DSA )?PRIVATE KEY-----'),re.compile(rb'(?:ghp_|github_pat_)[A-Za-z0-9_]{30,}'),re.compile(rb'(?<![A-Za-z0-9_])sk-(?:proj-|ant-)?[A-Za-z0-9_-]{32,}'),re.compile(rb'AKIA[0-9A-Z]{16}')]
 findings=[]
 for p in selected:
  b=(D/p).read_bytes()
  if any(v in b for v in known):findings.append(dict(path=p,kind='known-local-credential'))
  if any(m.group() not in public for pat in patterns for m in pat.finditer(b)):findings.append(dict(path=p,kind='recognized-token-or-private-key'))
 assert not findings,json.dumps(findings)
 rows=sorted(selected.values(),key=lambda r:r['path'])
 head=git('rev-parse','HEAD').decode().strip();dev=git('rev-parse','origin/dev').decode().strip()
 prior=git('ls-tree','-rz',head,'Docs/superpowers/qa','qa')
 changed=git('diff','--name-only',dev,head).decode().splitlines()
 # ZIP plus six visible metadata/report files; ledger/rulings also stay directly readable.
 assert len(changed)+7<3000,len(changed)+7
 assert not OUT.exists(), 'Fresh additive destination only'
 OUT.mkdir(parents=True)
 archive=OUT/'safe-evidence.zip'
 with zipfile.ZipFile(archive,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as z:
  for row in rows:
   b=(D/row['path']).read_bytes();assert sha(b)==row['sha256'];z.writestr(row['path'],b)
 with zipfile.ZipFile(archive) as z:
  assert z.namelist()==[r['path'] for r in rows]
  for row in rows:
   b=z.read(row['path']);assert len(b)==row['bytes'] and sha(b)==row['sha256']
 assert archive.stat().st_size<100*1024*1024
 manifest={'publication_base':head,'selected_dev':dev,'selection':'Explicit final safe-manifest rows, historical aliases, scoped requirements/reviews/preservation receipts and complete ordered rulings/ledger. No recursive workspace export.','archive':{'path':archive.name,'bytes':archive.stat().st_size,'sha256':sha(archive.read_bytes())},'entries':rows,'excluded_pinned_payloads':excluded}
 (OUT/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
 audit={'entries':len(rows),'uncompressed_bytes':sum(r['bytes'] for r in rows),'known_local_credential_values_compared':len(known),'known_matches':0,'recognized_token_or_private_key_findings':0,'public_literal_classification':provenance,'private_profiles_config_databases_exported':False,'limit':'Exact known values and recognizable tokens over selected bytes; three provenance-pinned public project literals. Not a general security audit.'}
 (OUT/'publication-audit.json').write_text(json.dumps(audit,indent=2)+'\n')
 for name in ['legacy-checkpoint-corrections-publication.md','rulings-i-made-after-legacy-checkpoint-corrections.md','complete-ledger-after-legacy-checkpoint-corrections.md']:(OUT/name).write_bytes((D/name).read_bytes())
 assert git('ls-tree','-rz','HEAD','Docs/superpowers/qa','qa')==prior
 # Hash every previously tracked QA working-tree file against its Git blob, with batch cat-file.
 payload=b''.join(row.split(b'\t',1)[0].split()[2]+b'\n' for row in prior.split(b'\0') if row)
 proc=subprocess.run(['git','cat-file','--batch'],cwd=W,input=payload,capture_output=True,check=True)
 off=0;count=0
 for row in prior.split(b'\0'):
  if not row:continue
  header,path=row.split(b'\t',1);lineend=proc.stdout.index(b'\n',off);n=int(proc.stdout[off:lineend].split()[-1]);body=proc.stdout[lineend+1:lineend+1+n];off=lineend+1+n+1
  assert (W/path.decode()).read_bytes()==body,path;count+=1
 preservation={'publication_base':head,'prior_qa_files_verified':count,'prior_qa_tree_sha256':sha(prior),'prior_qa_blobs_modes_paths_unchanged':True,'zip_entries_verified':len(rows),'new_paths':7,'projected_changed_paths':len(changed)+7,'changed_path_limit':3000,'source_changed_by_export':False,'raw_recovery_bundle_retained_privately':True,'no_historical_checkpoints_rewritten':True}
 (OUT/'preservation.json').write_text(json.dumps(preservation,indent=2)+'\n')
 print(json.dumps({'entries':len(rows),'archive_bytes':archive.stat().st_size,'audit_findings':0,'prior_qa_verified':count,'projected_changed_paths':len(changed)+7,'out':str(OUT)}))
if __name__=='__main__':main()
