# Task 26 — Derived Mermaid preflight

Read-only preflight; no source, index, HEAD, workflow, hosted-CI, dependency, or manifest changes. Evidence writes are limited to this own SDD and checker-owned temporary files. Task 25 remains the sole source writer.

## Finding

The observed failure is a public-input acquisition failure, with a transient availability failure supported by the current successful reproduction. No deterministic source defect was demonstrated. In run 37275176697 / job 111669445256 for PR head `9d8ff59567b7f79d592bbccd7175ae09d325eb53`, the sole failing Derived step reported `declared input is unavailable: EastAsianWidth.txt` at `2026-10-05T08:37:25.7490114Z`, then exited 1. Its preserved log names hosted checkout merge `69327e19b6f11e365a34dde9f90184397d02fa5a`; that merge object is not available locally, so no independent merge-tree comparison is claimed. The log reports no underlying HTTP status or socket/TLS error; its coarse error cannot distinguish these causes retrospectively.

## Exact call chain and contract

`.github/workflows/derived-artifacts.yml:265-270` sets up pinned Python 3.12.11 and invokes `python scripts/check_canvas_mermaid_assets.py`. The local `scripts/preflight.sh:107-108` invokes that same entry point. Checker `main()` → `check_assets()` verifies both vendored digests, reads `inputs.json`, creates a private temporary directory, and calls `acquire_declared_inputs()` before `build()`. The downloader requests each exact declared public HTTPS URL with `_RejectRedirects`, a 30-second request timeout, bounded reads, and exact size/SHA-256 checks. Any download `OSError` (including HTTP errors) becomes the logged unavailable-input error. Thus this CI failure occurred before the offline build or generated-output comparison.

EastAsianWidth declaration: `https://www.unicode.org/Public/16.0.0/ucd/EastAsianWidth.txt`, 199042 bytes, SHA-256 `43adc76c0686a42cb370764eb8cfe2b2a45b10b855e5572a2db4a0eecce15d5b`. Build then independently authenticates inputs; enforces Python 3.12.11, archive inventory and selected-member hashes, size ceilings, and authored-source composition; checker compares the complete six-output inventory and its metadata with packaged bytes. All these contracts were kept.

## Current reproduction

Exactly one authorized checker run used `/Users/macbook-dev/Documents/GitHub/tldw_chatbook/.venv/bin/python3.12 scripts/check_canvas_mermaid_assets.py` with explicit WT cwd, `TLDW_CANVAS_MERMAID_INPUT_DIR` unset, bytecode disabled, and a private `TMPDIR`; no dependency installation or local input cache. It ran at `2026-10-05T08:48:10.983049+00:00`, exited `0` in `4.878` seconds, stdout `Canvas Mermaid assets reproduce: 6 outputs (4 derived from pinned inputs, 2 vendored digests verified)`, empty stderr. The 300-second supervisor did not fire; the child was reaped and its temporary directory removed. No second checker or URL probe was run because the first succeeded.

All 27 relevant paths — checker, both vendor modules, workflow, complete authored/declared Mermaid inputs, and packaged Canvas static closure — have matching SHA-256 in failed 9d8, `origin/dev` `3146bbd8da2f30eaa97d72bd0ab860de4c40de75`, and WT bytes. WT HEAD had advanced to `1dc472f66ec376fa054797805b12e1105872f28b` while Task 25 worked; this scoped closure was unchanged before and after the run. Full source hashes and exact argv/environment overrides/closure are preserved in `task-26-ci-safe-evidence/source-hashes.json` and `receipt.json`; full actual stdout/stderr are in the adjacent checker logs.

## Decision and remaining gate

No source repair plan or new source owner is justified by this evidence. Keep pins, closed inventories, redirects refusal, security ceilings, timeouts, retries, workflow, and packaged bytes unchanged. Root owns publication of the separately authorized Task 25 fix and verification of fresh CI at that published current head. This local pass does not clear the hosted current-head required check or establish GitHub-runner reachability; fresh current-head hosted CI remains the gate. No hosted rerun was requested here.

ADR required: no. ADR path: N/A. Reason: investigation only; existing boundaries and contracts are unchanged.
