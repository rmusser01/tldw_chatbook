# Task 25 — legacy checkpoint upgrade preflight

Date: 2026-10-05
Reviewed HEAD: `9d8ff59567b7f79d592bbccd7175ae09d325eb53`
Worktree: `/Users/macbook-dev/.codex/worktrees/console-chat-starts/tldw_chatbook`
Finding: Qodo comment `4181532131`, thread `PRRT_kwDOOcyyl86o76Im`, [Some older databases fail to upgrade](https://github.com/rmusser01/tldw_chatbook/pull/2995#discussion_r4181532131).
Scope: read-only source/architecture preflight; this document is the only write. No product imports, tests, runtime constructors, installation, index/HEAD changes, source edits, sibling SDD edits, or external mutations. The source implementer must reproduce the RED cases below before editing.

## Recommendation

Accept every checkpoint row allowed by the shipped v76 table when rebuilding it into the unpublished v77 table. Keep every predecessor field exact and add a NULL `agent_chat_start_attempt_id` for predecessor manual/queued rows. Do not invent queue IDs, clear existing queue IDs, change origins, drop checkpoints, or sanitize saved JSON.

The minimum SQL change is to replace the first origin/queue CHECK with:

```sql
CHECK (origin != 'agent_chat_start' OR queue_entry_id IS NULL),
```

Keep the origin enumeration, positive-version/state constraints, foreign keys, preparation uniqueness, machine-attempt uniqueness, and second machine-attempt CHECK unchanged. `ConsoleDispatchRepository._validate_acceptance` already rejects new queued writes without a valid nonempty queue ID and new manual/machine writes with any queue ID. `_checkpoint_from_row` already quarantines both legacy combinations when considered for Console recovery. Those checks must stay unchanged and receive focused preservation evidence.

Freeze the exact strong native v76 catalogs before deriving repaired fresh v77 catalogs. Current names are misleading: `CHACHANOTES_V76_SCHEMA` supplies both historical native76 qualification and fresh77. A blind replacement-string edit would redefine history and strand old native databases. Old native76 must still upgrade by stamp only, retaining its stronger table at77. Accept frozen strong catalogs at both76 and77; newly repaired catalogs belong at77 only.

ADR required: no new ADR; dated amendment to existing ADR219 required before implementation.
ADR path: `backlog/decisions/219-console-chat-destinations-and-bounded-starts.md`, referencing ADR158 and ADR208.
Reason: compatibility correction within existing receipt schema/recovery boundaries. Record the distinction between compatible stored legacy rows, validated new writes, recoverable Console owners, and the two exact77 catalog families. Keep shipped75→76 notes SQL immutable; correct the unpublished77 artifact. Do not rewrite historical ADR bodies.

## Root cause and actual owners

1. `DB/migrations/chachanotes_v47_to_v48_console_library_policy.sql:50` declares manual/queued origins and nullable queue ID without correlation. The predecessor full catalog at `DB/recovery_core_schema.py:234`, retained at778–804, has the same table. Shipped76 repairs notes FTS and does not add queue correlation.
2. `DB/migrations/chachanotes_v76_to_v77_agent_chat_starts.sql:29` adds stricter queue correlation. Lines36–37 copy all17 predecessor columns with INSERT SELECT. Queued/NULL and manual/non-NULL each fail that copy. The second machine-attempt CHECK accepts predecessor NULL machine IDs and is not the cause.
3. `CharactersRAGDB.__init__` at `DB/ChaChaNotes_DB.py:2827` calls `_initialize_schema` at2894. `_initialize_schema:8121` starts its existing immediate managed transaction, reads the stamp and executes the real migration chain; fresh0 starts with v4 and also reaches76→77. Registry entry8252 calls `_migrate_from_v76_to_v77:7776`; its ordinary branch executes installed SQL at7821. Failure aborts startup migration even when a legacy row would later be Console-quarantined.
4. Native branch `ChaChaNotes_DB.py:7785–7825` uses column presence only to select a branch; complete catalog membership supplies admission. Only frozen primary native76 catalogs, or separately qualified shared Subscription catalogs with outer stamp2, pass. The branch then updates only the version. Do not replace full membership with column-presence admission, rebuild native receipts, or admit repaired schemas falsely stamped76.
5. `Chat/console_chat_controller.py:12356` creates durable acceptance; `Chat/chat_persistence_service.py:1780` routes it to `ConsoleDispatchRepository.insert_with_messages:129`. That method calls `_validate_acceptance:1544` before its own writes. Lines1548–1549 preserve strict queue/origin new-write rules;1552–1579 preserve machine metadata/attempt, attachment and handoff rules;1590–1595 validate queue IDs. `_checkpoint_from_row:1700–1703` refuses both legacy combinations as `invalid_checkpoint_owner`;1705–1732 preserve machine provenance and identifiers. These source owners need no change.
6. `DB/recovery_core_schema.py:782–808` derives native76 and current77 from the same strong replacement strings, including table quotes and index whitespace. `CORE_SCHEMAS` and current dictionary variant must describe actual repaired fresh77 constructors; frozen native76 tuples must retain current strong bytes.
7. `DB/recovery_core.py:461–493` maps complete catalogs to permitted versions. Retain explicit77 membership for frozen strong native catalogs alongside repaired fresh77. Native migration SQL at `recovery_core_schema.py:810` remains metadata only. Otherwise native upgrade succeeds but backup/restore rejects that same resulting database.
8. `DB/recovery_operations.py:1356–1400` repeats the receipt delta for actual shared Subscription/ChaChaNotes files. `Subscriptions/site_config_manager.py:275` opens CharactersRAGDB on that file. Preserve frozen `_SUBSCRIPTIONS_NATIVE_RECEIPT_SCHEMAS` and outer2/inner76-or77 pairs. Add exact repaired combined catalogs to outer2 policy with inner77 only. Preserve standalone subscriptions and old shipped combined catalogs with existing inner75-or76 pairs. Primary policy must keep refusing Subscription catalogs.
9. `Backup_Recovery/sqlite_validation.py:493–555` bounds Canvas UDF/schema trust by an explicit complete-catalog list. Old native76 currently aliases current fresh77; splitting them requires explicitly retaining old primary native tuples in this fixed list. Otherwise recognized native candidates fail unsupported_schema. Preserve installed UDF, bounded trust scope, expiry and cleanup; no unrestricted connection or normalized admission.
10. `_check` at `sqlite_validation.py:650–705` compares complete catalog/version before reference metadata, FK, Canvas, quick_check and optional installed owner checker. `_validate_candidate:720–825` preserves shipped/native split: shipped76 executes installed77 SQL on the same restricted disposable connection; native76 executes only its version statement. The proposed CHECK retains identical tables/indexes/autoindexes/rename, so shipped authorizer146–219 needs no new permission or SQL authority.

## Storage compatibility versus recovery refusal

No separate existing archive validator checks checkpoint queue/origin semantics. `_CoreAdapter` has no `_validate_connection` implementation; `validate:251–303` uses exact schema/version, FK, Canvas and quick_check. `_check` uses those checks and an optional owner hook. Fresh77 quick_check currently enforces the stronger queue CHECK indirectly through the stored table definition. Neither an existing test nor ADR219 establishes a separate semantic queue query as required after relaxing that storage restriction.

The existing `_shipped76` archive fixture in `Tests/Backup_Recovery/test_chachanotes_native76_compatibility.py:24–67` inserts arbitrary saved JSON objects (`{"saved":"authority"}` etc.), rather than canonical Console payloads, and the real archive staging test accepts it. This demonstrates that schema/integrity-valid historical storage may be restored without becoming recoverable Console work. Its matching queue combinations do not cover this finding.

Do not add an unconditional final77 query refusing these predecessor-permitted combinations. It would let runtime migration finish but recreate whole-archive refusal after copying the same rows. Preserve existing FK, Canvas, version, catalog, budget/cancellation and authority refusals, and prove restored invalid Console owners remain quarantined by the unchanged repository reader without retry/replay authorization.

The amendment must disclose repaired77 storage permits manual/queued legacy combinations and raw SQL may create them, as shipped76 could. Strict application new-write validation remains authoritative. Old strong native76/77 files retain their SQL queue restriction. Restoring storage does not certify Console recoverability. If all raw new manual/queued inserts must also be rejected by SQLite while indistinguishable legacy rows must copy unchanged, those requirements conflict without new provenance/state or schema machinery; none is recommended here.

## Required focused RED evidence

Use real temporary SQLite files and genuine historical bootstrap, not a version-stamped miniature. Show both failing combinations separately before changing SQL, then preserve them together in one populated fixture:

- Bare constructor reopen from shipped76, both dictionary variants: currently copy failure; afterward stamp77 and second reopen succeed.
- Installed standalone76→77 SQL on genuine shipped76, within explicit transaction and guarded version update: demonstrates the actual shipped artifact.
- Existing constructor-from75 path through shipped75→76 notes FTS into77: preserves earlier migration behavior.

Seed queued/NULL and manual/non-NULL with distinct linked messages, nondefault positive schema/checkpoint/message versions, preparation/attempt IDs, state, exact JSON strings and distinct explicit timestamps. Snapshot all17 predecessor fields; assert every one unchanged and only added machine column NULL. Compare messages, exact required index definitions, FK results and notes/schema/version integrity. Separate parameter IDs keep one row's failure from masking the other.

Using existing repository `_insert` helpers, prove queued/NULL, queued/empty, manual/non-NULL and machine/non-NULL new writes fail atomically without inserted messages/checkpoint or changed prior rows; valid manual/queued/machine writes still pass. Raw SQLite machine controls must reject queue/non-NULL, missing/empty/overlong attempt, manual/queued non-NULL machine attempt and duplicate machine attempt. Preserve existing machine/hook/root-fork exclusivity/deduplication controls.

For otherwise valid Console owners containing each preserved legacy queue combination, prove `read_for_session` is QUARANTINED with `invalid_checkpoint_owner`, no checkpoint/replay authorization and unchanged rows. Unrelated malformed JSON/state would not isolate that guard.

Freeze old strong native fixture before SQL edit. `_legacy_native76` at `Tests/DB/test_chachanotes_v77_agent_chat_starts_migration.py:258` currently reads mutable installed77 SQL; after repair it would mislabel repaired schema76 and cease reproducing history. Use frozen exact old strong fixture SQL/catalog from this HEAD; assert full membership before reopen. Qualify both dictionary variants and primary/shared Subscription cases, prove stamp-only upgrade leaves strong catalog/rows/messages unchanged, and refuse repaired fresh77 falsely stamped76. Independently capture genuine fresh repaired77 and test allowed shared inner77 versus refused inner76/75.

Extend populated shipped76 helper and existing real archive staging control with both legacy combinations, retaining original valid case. For both dictionary variants, plan/stage a real archive with no local snapshot, preserve every source/archive byte and predecessor field, verify exact repaired77 candidate and leave live destination absent. Stored legacy rows should stage successfully and remain Console-quarantined when read. Retain reached-DDL/index failure, final validation failure and cancellation rollback controls with unchanged authority expectations.

## Exact existing dependency selectors

Recommended scoped selectors; these are not executed receipts. Use existing parameter IDs, plus the new isolated cases above. Do not replay previous cohorts or select unrelated long test files.

Runtime, artifact and fresh catalog:

- `Tests/DB/test_chachanotes_v77_agent_chat_starts_migration.py::test_v77_keeps_every_predecessor_checkpoint_column_and_indexes`
- `Tests/DB/test_chachanotes_v77_agent_chat_starts_migration.py::test_legacy_native76_upgrade_preserves_exact_receipts`
- `Tests/DB/test_chachanotes_v77_agent_chat_starts_migration.py::test_unknown_native76_catalog_refuses_without_rewriting`
- `Tests/DB/test_chachanotes_v77_agent_chat_starts_migration.py::test_v77_constructor_catalog_matches_exact_native76_capture` (compare fresh to repaired77 independently of frozen native76)
- `Tests/DB/test_chachanotes_v77_agent_chat_starts_migration.py::test_machine_request_and_checkpoint_share_exact_attempt`
- `Tests/DB/test_chachanotes_v77_agent_chat_starts_migration.py::test_duplicate_machine_receipt_refuses_changed_request`
- `Tests/DB/test_chachanotes_v77_agent_chat_starts_migration.py::test_incompatible_machine_and_root_fork_provenance_rolls_back`
- `Tests/DB/test_chachanotes_v77_agent_chat_starts_migration.py::test_mixed_hook_replay_keeps_native_receipt_and_messages_exact`
- `Tests/DB/test_chachanotes_console_library_policy_migration.py::test_real_v47_fixture_gains_exact_v48_local_schema_and_seed_rows` (existing downstream checkpoint catalog assertions)
- `Tests/DB/test_migration_file_sources.py::TestNoDecorativeMigrationFiles::test_chachanotes_files_are_all_runtime_executed`

Recovery native, shipped, catalog, authority and rollback:

- `Tests/Backup_Recovery/test_chachanotes_native76_compatibility.py::test_native76_staged_upgrade_preserves_machine_receipts`
- `Tests/Backup_Recovery/test_chachanotes_native76_compatibility.py::test_ordinary_older_schema_validates_but_staged_ddl_remains_refused`
- `Tests/Backup_Recovery/test_chachanotes_native76_compatibility.py::test_primary_staged_gate_rejects_hybrid_and_other_owner_catalogs`
- `Tests/Backup_Recovery/test_chachanotes_native76_compatibility.py::test_native76_staged_failure_rolls_back_stamp_and_receipts`
- `Tests/Backup_Recovery/test_chachanotes_native76_compatibility.py::test_native76_metadata_authority_is_exact`
- `Tests/Backup_Recovery/test_chachanotes_native76_compatibility.py::test_subscription_native_catalog_retains_exact_embedded_stamps`
- `Tests/Backup_Recovery/test_chachanotes_native76_compatibility.py::test_shipped76_staged_failure_rolls_back_checkpoint_rebuild`
- `Tests/Backup_Recovery/test_chachanotes_native76_compatibility.py::test_shipped76_migration_authority_is_exact`
- `Tests/Backup_Recovery/test_chachanotes_native76_compatibility.py::test_shipped76_callback_scope_is_exact`
- `Tests/Backup_Recovery/test_chachanotes_native76_compatibility.py::test_shipped76_malformed_catalog_refuses_before_writing`
- `Tests/Backup_Recovery/test_restore_plan.py::test_shipped76_archive_stages_v77_without_changing_source`
- `Tests/Backup_Recovery/test_core_owners.py::test_schema_policy_matches_installed_store[chachanotes]`
- `Tests/Backup_Recovery/test_core_owners.py::test_schema_valid_but_orphaned_domain_reference_is_rejected`
- `Tests/Backup_Recovery/test_core_dictionary_schema.py::test_native_dictionary_schema_is_exact` (eight bounded exact-catalog modes)

Reader preservation:

- `Tests/ChaChaNotesDB/test_console_dispatch_checkpoint_repository.py::test_insert_and_read_validate_roles_conversation_versions_and_state`
- `Tests/ChaChaNotesDB/test_console_dispatch_checkpoint_repository.py::test_read_quarantines_invalid_ownership`
- Add isolated legacy queue quarantine/new-write/machine SQL cases in existing test owners rather than a framework.

## Cross-owner contract and limits

Required source owners: installed77 SQL, primary catalog declarations, primary schema_policy, combined Subscription catalog/stamp declarations, and Canvas fixed exact-catalog list. Native runtime branching and recovery DDL authorizer need no behavioral expansion. Test owners: v77 migration/frozen legacy fixture, native76 compatibility, and bounded extension of real archive staging. Preserve old strong tuples/fixture bytes independently of fresh77 capture; do not update historical families to make current capture pass.

Governance: dated ADR219 amendment and owning TASK34215.2/Task25 implementation notes link ADR158/208 and document the choice before code. Lessons read: shipped allocation immutability, exact recovery catalog coupling, historical schema authenticity, exact SQLite SQL bytes and temporary-profile isolation.

Risks addressed: catalog alias edits dropping old native support; self-updating legacy fixture concealing that loss; shared stamp pairs admitting repaired76; Canvas list refusing recognized old native; storage acceptance confused with Console replay authority. No normalization, new migration framework, predecessor rewrite, unrestricted/trusted connection expansion, runtime constructor in staging, extra DDL permissions, semantic queue query, new flag, owner-cap change or prior QA replay. Tasks19–23 approvals and the reported686-entry public ZIP/12,582 retained historical QA records are outside this write scope and were not recertified.
