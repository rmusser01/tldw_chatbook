from pathlib import Path
import subprocess,re,ast,json,sys
root=Path.cwd();base=root/'.superpowers/sdd/2026-10-20-workspace-project-semantic-index';git=['git','-c','safe.directory='+root.as_posix()]
paths=subprocess.check_output([*git,'diff','--name-only','--','*.py']).decode().splitlines()
ruff='C:/Python312/Scripts/ruff.exe'
records=[]
for path in paths:
 diff=subprocess.check_output([*git,'diff','--unified=0','--',path]).decode('utf-8')
 spans=[(int(m[0]),int(m[1] or '1')) for m in re.findall(r'@@ -[0-9]+(?:,[0-9]+)? \+([0-9]+)(?:,([0-9]+))? @@',diff)]
 for start,count in reversed(spans):
  if count:
   argv=[ruff,'format','--no-cache','--range',str(start)+'-'+str(start+count),path]
   r=subprocess.run(argv,capture_output=True,text=True);records.append(dict(argv=argv,exit=r.returncode,stdout=r.stdout,stderr=r.stderr))
   if r.returncode:print(r.stdout+r.stderr);raise SystemExit(r.returncode)
 ast.parse((root/path).read_text(encoding='utf-8'),filename=path)
r=subprocess.run([ruff,'check','--no-cache',*paths],capture_output=True,text=True);records.append(dict(argv=r.args,exit=r.returncode,stdout=r.stdout,stderr=r.stderr));print(r.stdout+r.stderr,end='')
(base/'final-fix-static-receipt.json').write_text(json.dumps(records,indent=2),encoding='utf-8')
print('AST PASS',len(paths),'changed Python files; range formatting actual modified regions')
raise SystemExit(r.returncode)
