# Embeddings_Lib.py
#
from __future__ import annotations

#
"""Adaptive embedding factory for desktop / TUI apps – asynchronous‑ready, logging‑aware.

This version is a thread-safe, robust implementation that addresses race conditions
and resource management issues found in previous iterations.

Key Features & Fixes in this Version
────────────────────────────────────
• **Thread-Safe & Race-Condition-Free**: The core embedding logic is now
  fully thread-safe, preventing race conditions where a model could be
  evicted by one thread while being used by another (a per-record refcount
  since task-34398, which also lets the model forward pass run OUTSIDE the
  factory lock so concurrent embeds no longer serialize).
• **Correct Resource Management**: Eviction now occurs *before* loading a
  new model; the max_cached limit is only ever (transiently) exceeded when
  every cached model is currently checked out and thus not evictable.
• **Improved Typing**: The internal cache and Pydantic configurations use
  `TypedDict` and discriminated unions for better static analysis and maintainability.
• **Async Facade**: `await factory.async_embed(...)` uses `asyncio.to_thread`
  so the UI never blocks.
• **Structured Logging**: Provides insight into cache hits, loads, and evictions.
• **Pluggable & High-Quality Pooling**: Defaults to a proper masked mean pooling
  strategy with L2 normalization for superior embedding quality.
• **Prefetch / Warm‑up**: `factory.prefetch(...)` downloads weights on-demand.
"""
#
# Imports
import asyncio  # noqa: E402
import os  # noqa: E402
import random  # noqa: E402
import threading  # noqa: E402
import time  # noqa: E402
import sys  # noqa: E402
from collections import OrderedDict  # noqa: E402
from pathlib import Path  # noqa: E402
from typing import (  # noqa: E402
    Any,
    Annotated,
    Callable,
    Dict,
    List,
    Literal,
    Optional,
    Protocol,
    TypedDict,
    Union,
)

#
# Third-Party Libraries
import requests  # noqa: E402
from loguru import logger  # noqa: E402
from tldw_chatbook.RAG_Search.model_recovery import (  # noqa: E402
    model_operation,
    recovered_close,
    recovered_encode,
    recovered_load,
)
from pydantic import (  # noqa: E402
    BaseModel,
    Field,
    model_validator,
    HttpUrl,
    ValidationError,
)

# Optional dependencies with fallbacks
from ..Utils.optional_deps import get_safe_import  # noqa: E402

# torch/transformers/numpy are heavy optional dependencies (torch alone pulls
# in roughly a thousand transitive modules, transformers a few hundred more).
# They are NOT imported at module scope; each is imported lazily on first
# real use via the _ensure_*() helpers below, which are called at the top of
# every method that dereferences the corresponding name. This keeps
# `import tldw_chatbook.app` free of torch/transformers/numpy while
# preserving identical behavior (and identical error messages) once an
# embedding is actually created.
torch = None
transformers = None
numpy = None
AutoModel = None
AutoTokenizer = None


def _ensure_torch():
    """Import torch on first actual use.

    No-ops (leaves ``torch`` as ``None``) if torch isn't installed, matching
    the previous eager ``get_safe_import('torch')`` fallback semantics.
    """
    global torch
    if torch is not None:
        return torch
    torch = get_safe_import("torch")
    return torch


def _ensure_transformers():
    """Import transformers (and torch, which HF embedding code always needs)
    on first actual use."""
    global transformers, AutoModel, AutoTokenizer
    _ensure_torch()
    if transformers is not None:
        return transformers
    _transformers = get_safe_import("transformers")
    if _transformers is not None:
        # Bind the helper globals BEFORE the gate global (`transformers`), so a
        # racing thread that observes `transformers is not None` is guaranteed
        # to also see AutoModel/AutoTokenizer fully bound.
        AutoModel = _transformers.AutoModel
        AutoTokenizer = _transformers.AutoTokenizer
        transformers = _transformers
    return transformers


def _ensure_numpy():
    """Import numpy on first actual use."""
    global numpy, np
    if numpy is not None:
        return numpy
    _numpy = get_safe_import("numpy")
    if _numpy is not None:
        # Bind `np` BEFORE the gate global (`numpy`), so a racing thread that
        # observes `numpy is not None` never finds `np` still the placeholder.
        np = _numpy
        numpy = _numpy
    return numpy


def _embeddings_rag_available() -> bool:
    """Resolve real embeddings/RAG dependency availability, checking lazily.

    This constructor's gate is a genuine "first real use" of the
    embeddings/RAG optional dependencies, so it delegates to
    ``optional_deps.lazy_embeddings_rag_available()`` (task-657, lifted to a
    shared public seam in task-638 so ``UI/Views/RAGSearch/search_rag_window.py``
    can reuse the exact same re-probe-on-False semantics instead of reading
    ``DEPENDENCIES_AVAILABLE["embeddings_rag"]`` directly and getting stuck on
    a stale pristine-False default). Resolved via ``sys.modules`` rather than
    a static import so it keeps working across the module reloads some tests
    perform, and so tests that monkeypatch
    ``optional_deps.check_embeddings_rag_deps`` (which the shared helper
    calls internally) are honored.
    """
    optional_deps_module = sys.modules.get("tldw_chatbook.Utils.optional_deps")
    lazy_available_fn = getattr(
        optional_deps_module, "lazy_embeddings_rag_available", None
    )
    if not callable(lazy_available_fn):
        from ..Utils.optional_deps import (
            lazy_embeddings_rag_available as lazy_available_fn,
        )
    return bool(lazy_available_fn())


# `Tensor` is only used for type annotations (deferred at runtime by
# `from __future__ import annotations`, at the top of this module) and in the
# `PoolingFn` alias just below, so a plain `Any` placeholder is sufficient
# without importing torch. The real torch/transformers classes are resolved
# lazily by _ensure_torch()/_ensure_transformers() at the call sites that
# actually need them (see `_masked_mean` and `_HuggingFaceEmbedder`).
Tensor = Any


class _NumpyPlaceholder:
    """Stand-in for the `numpy` module until _ensure_numpy() resolves it.

    Also serves as the permanent placeholder when numpy genuinely isn't
    installed, matching the previous eager-import fallback behavior.
    """

    def __getattr__(self, name: str) -> Any:
        # Any attribute access (asarray, empty, float32, ndarray, ...) raises
        # the same clear ImportError, so a genuinely-missing numpy fails loudly
        # and consistently rather than with an incidental AttributeError.
        raise ImportError(
            "NumPy not available. Install with: pip install tldw_chatbook[embeddings_rag]"
        )


np = _NumpyPlaceholder()
#
# Local Imports
#
########################################################################################################################
#
__all__ = [
    "EmbeddingFactory",
    "EmbeddingConfigSchema",
    "get_default_embedding_config",
    "get_common_embedding_models",
    "create_embedding_factory_with_defaults",
]
#
# Configure logger with context
logger = logger.bind(module="Embeddings_Lib")
#
###############################################################################
# File Descriptor Protection for macOS subprocess issues
###############################################################################

# task-640: consolidated into tldw_chatbook.Utils.fd_protection (was
# duplicated verbatim here, in Local_Ingestion/transcription_service.py, and
# in TTS/backends/higgs.py). Re-exported under this name so existing
# `from tldw_chatbook.Embeddings.Embeddings_Lib import protect_file_descriptors`
# call sites (including tests) keep working unchanged.
from ..Utils.fd_protection import protect_file_descriptors  # noqa: E402,F401


###############################################################################
# Configuration schema (with Discriminated Union)
###############################################################################

PoolingFn = Callable[[Tensor, Tensor], Tensor]


class EmbeddingConfigSchema(BaseModel):
    default_model_id: Optional[str] = None
    models: Dict[str, "ModelCfg"]  # Forward reference for ModelCfg

    @model_validator(mode="after")
    def check_default_model_exists(self) -> "EmbeddingConfigSchema":
        """Ensures the default_model_id refers to a model defined in the models dict."""
        if self.default_model_id and self.default_model_id not in self.models:
            raise ValueError(
                f"default_model_id '{self.default_model_id}' is not a valid key in the 'models' dictionary. "
                f"Available models are: {list(self.models.keys())}"
            )
        return self


def _masked_mean(last_hidden: Tensor, attn: Tensor) -> Tensor:
    """Default pooling: mean of vectors where attention_mask is 1."""
    _ensure_torch()
    if torch is None:
        raise ImportError("torch is required for pooling operations")
    mask = attn.unsqueeze(-1).type_as(last_hidden)
    summed = (last_hidden * mask).sum(dim=1)
    lengths = mask.sum(dim=1).clamp(min=1e-9)
    avg = summed / lengths
    return torch.nn.functional.normalize(avg, p=2, dim=1)


class HFModelCfg(BaseModel):
    provider: Literal["huggingface"] = "huggingface"
    model_name_or_path: str
    trust_remote_code: bool = False
    local_files_only: bool = False
    max_length: int = 512
    device: Optional[str] = None
    batch_size: int = 32
    pooling: Optional[PoolingFn] = None  # default: masked mean
    dimension: Optional[int] = None
    cache_dir: Optional[str] = None  # Custom cache directory for model downloads
    revision: Optional[str] = None  # Git revision (commit/tag) for security pinning


class OpenAICfg(BaseModel):
    provider: Literal["openai"] = "openai"
    model_name_or_path: str = "text-embedding-3-small"
    api_key: Optional[str] = Field(default=None, repr=False)
    base_url: Optional[HttpUrl] = Field(
        default=None
    )  # CHANGED: Added base_url, made it HttpUrl for validation
    dimension: Optional[int] = None

    @model_validator(mode="after")
    def _default_api_key(self) -> "OpenAICfg":
        # base_url is validated only after the whole model has been parsed.
        if self.api_key:
            return self
        self.api_key = os.environ.get("OPENAI_API_KEY") or None
        # Catalog entries remain candidates without a credential. The actual
        # OpenAI endpoint is refused at construction/use until one is supplied.
        return self


# A discriminated union lets Pydantic and type checkers infer the correct model type
ModelCfg = Annotated[Union[HFModelCfg, OpenAICfg], Field(discriminator="provider")]

# Update the forward reference now that ModelCfg is fully defined
EmbeddingConfigSchema.model_rebuild()


###############################################################################
# Provider helpers
###############################################################################


class EmbedFn(Protocol):
    """A protocol defining a callable for embedding texts.

    This ensures that any function used as an embedding function adheres to this
    specific signature, including the keyword-only `as_list` argument.
    """

    def __call__(
        self, texts: List[str], *, as_list: bool = False
    ) -> Union[np.ndarray, List[List[float]]]: ...


class CacheRecord(TypedDict):
    """Strongly-typed structure for a cache entry.

    ``refs`` is the checkout count (task-34398): an entry with a positive
    refcount is in use by an in-flight ``embed`` call and is never evicted
    or closed until the count returns to 0.
    """

    embed: EmbedFn
    close: Optional[Callable[[], None]]
    last: float
    refs: int


def existing_local_hf_snapshot(cfg: HFModelCfg) -> Path:
    """Resolve a complete local HF snapshot without contacting the Hub."""
    configured = Path(cfg.model_name_or_path).expanduser()
    if configured.is_dir():
        snapshot = configured.resolve(strict=True)
    else:
        parts = cfg.model_name_or_path.split("/")
        if len(parts) != 2 or not all(parts):
            raise FileNotFoundError("local_embedding_snapshot_required")
        from huggingface_hub.constants import HF_HUB_CACHE

        model = Path(
            cfg.cache_dir or os.environ.get("HF_HUB_CACHE", HF_HUB_CACHE)
        ).expanduser() / ("models--" + "--".join(parts))
        snapshots = model / "snapshots"
        if cfg.revision:
            revision = cfg.revision
            ref = model / "refs" / revision
            if ref.is_file():
                revision = ref.read_text(encoding="utf-8").strip()
            if not revision or any(ch in revision for ch in ("/", "\\", ".")):
                raise FileNotFoundError("local_embedding_snapshot_required")
            snapshot = snapshots / revision
        else:
            available = (
                tuple(p for p in snapshots.iterdir() if p.is_dir())
                if snapshots.is_dir()
                else ()
            )
            if len(available) != 1:
                raise FileNotFoundError("local_embedding_snapshot_required")
            snapshot = available[0]
    files = {p.name for p in snapshot.iterdir()} if snapshot.is_dir() else set()
    if (
        "config.json" not in files
        or not files.intersection(("tokenizer.json", "vocab.txt", "spiece.model"))
        or not files.intersection(
            (
                "model.safetensors",
                "pytorch_model.bin",
                "model.safetensors.index.json",
                "pytorch_model.bin.index.json",
            )
        )
    ):
        raise FileNotFoundError("local_embedding_snapshot_required")
    from tldw_chatbook.RAG_Search.model_recovery import _closure

    try:
        _closure(snapshot)
    except (OSError, ValueError):
        raise FileNotFoundError("local_embedding_snapshot_required") from None
    return snapshot.resolve(strict=True)


class _HuggingFaceEmbedder:
    """Wraps HF model/tokenizer; exposes poolable, dtype/device-aware embedding."""

    @recovered_load
    def __init__(self, cfg: HFModelCfg):
        # Resolve torch/transformers on first real use. `_build()` already
        # gates construction of this class on both being available, but this
        # keeps the class safe to construct directly too.
        _ensure_torch()
        _ensure_transformers()
        if torch is None or transformers is None:
            raise ImportError(
                "HuggingFace embeddings require torch and transformers. "
                "Install with: pip install tldw_chatbook[embeddings_rag]"
            )
        if cfg.device == "auto" or cfg.device is None:
            if torch.cuda.is_available():
                self._device = torch.device("cuda")
                logger.info("Auto-selected CUDA device for embeddings")
            elif hasattr(torch.backends, "mps") and torch.backends.mps.is_available():
                self._device = torch.device("mps")
                logger.info("Auto-selected MPS device for embeddings")
            else:
                self._device = torch.device("cpu")
                logger.info("Auto-selected CPU device for embeddings")
        else:
            self._device = torch.device(cfg.device)
        try:
            # Use cache_dir if provided, otherwise HuggingFace will use default
            cache_dir = cfg.cache_dir if cfg.cache_dir else None
            if cache_dir:
                # Expand user home directory if present
                import os

                cache_dir = os.path.expanduser(cache_dir)
                logger.info(f"Using custom cache directory: {cache_dir}")

            # Log if we're using a pinned revision for security
            if cfg.revision:
                logger.info(
                    f"Loading model {cfg.model_name_or_path} at revision {cfg.revision} for security"
                )

            # Use context manager to protect file descriptors during model loading
            with protect_file_descriptors():
                self._tok = AutoTokenizer.from_pretrained(
                    cfg.model_name_or_path,
                    trust_remote_code=cfg.trust_remote_code,
                    local_files_only=cfg.local_files_only,
                    cache_dir=cache_dir,
                    revision=cfg.revision,  # Pin to specific revision if provided
                )
                dtype = torch.float16 if self._device.type == "cuda" else torch.float32
                self._dtype = dtype

                # Load model with low_cpu_mem_usage to avoid meta tensors
                self._model = AutoModel.from_pretrained(
                    cfg.model_name_or_path,
                    torch_dtype=dtype,
                    trust_remote_code=cfg.trust_remote_code,
                    local_files_only=cfg.local_files_only,
                    cache_dir=cache_dir,
                    revision=cfg.revision,  # Pin to specific revision if provided
                    low_cpu_mem_usage=False,  # Avoid meta tensors
                )
        # --- [FIX] Added robust error handling for model loading ---
        except (OSError, requests.exceptions.RequestException) as e:
            raise IOError(
                f"Failed to download or load model '{cfg.model_name_or_path}'. "
                "Check the model name and your network connection."
            ) from e

        # Try to move model to device, handling meta tensor issues
        try:
            # Check if model is on meta device first
            if hasattr(self._model, "device") and str(self._model.device) == "meta":
                logger.warning(
                    "Model is on meta device, reloading with proper initialization"
                )
                # Delete the meta model and reload properly
                del self._model

                # Force garbage collection to free memory
                import gc

                gc.collect()

                # Reload the model with explicit device placement
                self._model = AutoModel.from_pretrained(
                    cfg.model_name_or_path,
                    torch_dtype=self._dtype,
                    trust_remote_code=cfg.trust_remote_code,
                    local_files_only=cfg.local_files_only,
                    cache_dir=cache_dir,
                    revision=cfg.revision,
                    low_cpu_mem_usage=False,  # Avoid meta tensors
                    device_map=None,  # Disable device mapping
                    _fast_init=False,  # Force proper initialization
                )
                # Move to target device
                self._model = self._model.to(self._device)
            else:
                # Normal device transfer
                self._model = self._model.to(self._device)
        except RuntimeError as e:
            if "Cannot copy out of meta tensor" in str(e):
                logger.warning(
                    f"Caught meta tensor error: {e}. Reloading model properly."
                )
                # Delete the problematic model
                if hasattr(self, "_model"):
                    del self._model

                # Force garbage collection
                import gc

                gc.collect()

                # Reload with explicit settings to avoid meta tensors
                self._model = AutoModel.from_pretrained(
                    cfg.model_name_or_path,
                    torch_dtype=self._dtype,
                    trust_remote_code=cfg.trust_remote_code,
                    local_files_only=cfg.local_files_only,
                    cache_dir=cache_dir,
                    revision=cfg.revision,
                    low_cpu_mem_usage=False,
                    device_map=None,
                    _fast_init=False,
                ).to(self._device)
            else:
                raise

        self._model.eval()

        self._max_len = cfg.max_length
        self._batch_size = cfg.batch_size
        self._pool = cfg.pooling or _masked_mean

    def _forward(self, inp: Dict[str, Tensor]) -> Tensor:
        # Apply inference mode only if torch is available
        _ensure_torch()
        if torch is not None:
            with torch.inference_mode():
                out = self._model(**inp).last_hidden_state
                return self._pool(out, inp["attention_mask"])
        else:
            # This shouldn't happen since _HuggingFaceEmbedder requires torch
            out = self._model(**inp).last_hidden_state
            return self._pool(out, inp["attention_mask"])

    @recovered_encode
    def embed(
        self, texts: List[str], *, as_list: bool = False
    ) -> np.ndarray | List[List[float]]:
        vecs: List[Tensor] = []
        for i in range(0, len(texts), self._batch_size):
            batch = texts[i : i + self._batch_size]
            tok = self._tok(
                batch,
                return_tensors="pt",
                padding=True,
                truncation=True,
                max_length=self._max_len,
            )
            tok = {k: v.to(self._device) for k, v in tok.items()}
            # --- [FIX] Performance: keep tensors on GPU during loop ---
            vecs.append(self._forward(tok))

        # --- [FIX] Performance: concatenate on GPU, then move to CPU once ---
        _ensure_torch()
        if torch is None:
            raise ImportError("torch is required for HuggingFace embeddings")
        joined = torch.cat(vecs, dim=0).float().cpu().numpy()
        return joined.tolist() if as_list else joined

    @recovered_close
    def close(self) -> None:
        del self._model, self._tok
        _ensure_torch()
        if torch is not None and torch.cuda.is_available():
            torch.cuda.empty_cache()


# --------------------------------------------------------------------------

_BACKOFF: tuple[float, ...] = (1, 2, 4, 8)


def _openai_embedder(
    cfg: OpenAICfg,
) -> tuple[Callable[..., Any], Callable[[], None]]:
    if not cfg.api_key and cfg.base_url is None:
        raise ValueError("embedding_provider_setup_required")
    session = requests.Session()

    # CHANGED: Use cfg.api_key and handle its potential None value if base_url is set
    if cfg.api_key:
        session.headers.update(
            {
                "Authorization": f"Bearer {cfg.api_key}",
                "User-Agent": "EmbeddingsLib/4.0",
            }
        )
    else:
        # If no API key (e.g., for local server), just set User-Agent
        session.headers.update({"User-Agent": "EmbeddingsLib/4.0"})

    # CHANGED: Determine the endpoint URL
    endpoint_url_base = (
        str(cfg.base_url) if cfg.base_url else "https://api.openai.com/v1"
    )
    embeddings_endpoint = f"{endpoint_url_base.rstrip('/')}/embeddings"
    logger.info("OpenAI embedder configured")

    def _embed(
        texts: List[str], *, as_list: bool = False
    ) -> np.ndarray | List[List[float]]:
        _ensure_numpy()
        payload = {
            "input": texts,
            "model": cfg.model_name_or_path,
        }  # CHANGED: Use cfg.model_name_or_path
        for attempt, wait in enumerate(_BACKOFF, 1):
            t0 = time.perf_counter()
            try:
                resp = session.post(
                    embeddings_endpoint, json=payload, timeout=30
                )  # CHANGED: Use dynamic endpoint
                resp.raise_for_status()
                data = resp.json()["data"]
                arr = np.asarray([d["embedding"] for d in data], dtype=np.float32)
                latency = time.perf_counter() - t0
                logger.debug("openai_embed {} texts in {:.3f}s", len(texts), latency)
                return arr.tolist() if as_list else arr
            except requests.RequestException as exc:
                if attempt == len(_BACKOFF):
                    logger.error(
                        "openai_embed failed after {} attempts ({})",
                        attempt,
                        type(exc).__name__,
                    )
                    raise requests.RequestException("embedding_provider_request_failed") from None
                logger.warning(
                    "openai_embed retry {}/{} after {} ({})",
                    attempt,
                    len(_BACKOFF),
                    wait,
                    type(exc).__name__,
                )
                time.sleep(wait + random.random())
        raise RuntimeError("embedding_provider_request_failed")  # Unreachable

    return _embed, session.close


###############################################################################
# Factory
###############################################################################


class EmbeddingFactory:
    """Thread‑safe LRU/idle cache with sync & async embedding methods.

    Locking strategy (task-34398): ``self._lock`` -- shared with the
    ``self._cond`` Condition -- guards ONLY model-cache mutation (lookup,
    insert, LRU bookkeeping, eviction). The model forward pass runs outside
    it, so a background ingest batch no longer serializes interactive query
    embeddings. Use-after-free is prevented with a per-record refcount
    instead of lock-held-for-the-whole-call: eviction (idle and LRU) skips
    entries whose refcount is positive, so an in-use model can never be
    closed underneath a caller.

    Concurrent forward passes on the SAME model are allowed: the HF embedder
    below runs in eval mode under ``torch.inference_mode()`` and shares no
    mutable state across calls (each call tokenizes into fresh tensors), and
    the OpenAI embedder is a stateless HTTP client. Any custom ``embed_fn``
    handed to :meth:`_build` must uphold the same thread-safety guarantee;
    if a model is NOT safe for concurrent calls, wrap its forward pass in
    its own lock inside the embed_fn -- the factory-level ceiling is gone
    either way, because different models always run concurrently.
    """

    def __init__(
        self,
        cfg: Dict[str, Any] | EmbeddingConfigSchema,
        *,
        max_cached: int = 2,
        idle_seconds: int = 900,
        allow_dynamic_hf: bool = True,
        local_files_only: bool | None = None,
    ) -> None:
        # Check if embeddings/RAG dependencies are available (lazily checking
        # for real on first use if nothing has populated the registry yet --
        # see _embeddings_rag_available, task-657).
        if not _embeddings_rag_available():
            raise ImportError(
                "EmbeddingFactory requires embeddings/RAG dependencies. "
                "Install with: pip install tldw_chatbook[embeddings_rag]"
            )
        try:
            self._cfg = (
                cfg
                if isinstance(cfg, EmbeddingConfigSchema)
                else EmbeddingConfigSchema(**cfg)
            )
        except ValidationError:  # Never propagate credential-bearing config text.
            logger.critical("Invalid embedding configuration provided to EmbeddingFactory")
            raise ValueError("embedding_configuration_invalid") from None

        if local_files_only is not None:
            self._cfg = self._cfg.model_copy(
                update={
                    "models": {
                        name: spec.model_copy(update={"local_files_only": local_files_only})
                        if isinstance(spec, HFModelCfg)
                        else spec
                        for name, spec in self._cfg.models.items()
                    }
                }
            )

        self._max_cached = max_cached
        self._idle = idle_seconds
        self._allow_dynamic_hf = allow_dynamic_hf
        self._local_files_only = local_files_only
        self._cache: "OrderedDict[str, CacheRecord]" = OrderedDict()
        self._lock = threading.Lock()
        # Condition sharing ``self._lock``: ``with self._cond`` acquires the
        # very same lock, so both spellings interoperate. The Condition only
        # adds the wait/notify ``close()`` needs to drain in-flight embeds
        # before closing models (task-34398).
        self._cond = threading.Condition(self._lock)
        logger.debug(
            "factory initialised max_cached={} idle={}s", max_cached, idle_seconds
        )

    def _get_spec(self, model_id: str) -> ModelCfg:
        try:
            return self._cfg.models[model_id]
        except KeyError:
            if self._allow_dynamic_hf:
                logger.info(
                    "dynamic HF model {} (model_id used as model_name_or_path)",
                    model_id,
                )
                # This assumes any unknown model_id passed when allow_dynamic_hf is True
                # should be treated as a HuggingFace model path.
                return HFModelCfg(model_name_or_path=model_id, provider="huggingface")
            raise ValueError(
                f"Model ID '{model_id}' not found in configuration and dynamic HF loading is disabled."
            )

    @property
    def config(self) -> EmbeddingConfigSchema:
        return self._cfg

    def _build(self, model_id: str) -> CacheRecord:
        """
        Build and initialize a model for embedding.

        Args:
            model_id: The ID of the model to build

        Returns:
            CacheRecord containing the embedding function and cleanup function

        Raises:
            TypeError: If the model specification doesn't match the provider type
            ValueError: If the provider is not supported
        """
        logger.debug(f"_build: Building model {model_id}")

        spec = self._get_spec(model_id)
        logger.debug(
            f"_build: Got specification for model {model_id}, provider={spec.provider}"
        )

        t0 = time.perf_counter()
        if spec.provider == "huggingface":
            if self._local_files_only is True:
                spec = spec.model_copy(
                    update={
                        "model_name_or_path": str(existing_local_hf_snapshot(spec)),
                        "local_files_only": True,
                        "cache_dir": None,
                    }
                )
            # Check if torch and transformers are available (imports them on
            # first real use if they haven't been loaded yet)
            _ensure_torch()
            _ensure_transformers()
            if torch is None or transformers is None:
                raise ImportError(
                    "HuggingFace embeddings require torch and transformers. "
                    "Install with: pip install tldw_chatbook[embeddings_rag]"
                )

            # Ensure spec is correctly typed for HFModelCfg
            if not isinstance(spec, HFModelCfg):
                logger.error(
                    f"_build: Type mismatch for model {model_id} - expected HFModelCfg, got {type(spec)}"
                )
                raise TypeError(
                    f"Expected HFModelCfg for provider 'huggingface', got {type(spec)} for model_id '{model_id}'"
                )

            logger.info(
                f"_build: Initializing HuggingFace model {model_id} (path: {spec.model_name_or_path})"
            )
            try:
                hf = _HuggingFaceEmbedder(spec)
                rec = CacheRecord(
                    embed=hf.embed, close=hf.close, last=time.monotonic(), refs=0
                )
                logger.debug(
                    f"_build: Successfully created HuggingFace embedder for {model_id}"
                )
            except Exception as e:
                logger.opt(exception=True).error(
                    f"_build: Failed to initialize HuggingFace model {model_id}: {e}"
                )
                raise

        elif spec.provider == "openai":
            # Ensure spec is correctly typed for OpenAICfg
            if not isinstance(spec, OpenAICfg):
                logger.error(
                    f"_build: Type mismatch for model {model_id} - expected OpenAICfg, got {type(spec)}"
                )
                raise TypeError(
                    f"Expected OpenAICfg for provider 'openai', got {type(spec)} for model_id '{model_id}'"
                )

            logger.info(
                f"_build: Initializing OpenAI model {model_id} (model: {spec.model_name_or_path})"
            )
            try:
                fn, close = _openai_embedder(spec)
                rec = CacheRecord(
                    embed=fn, close=close, last=time.monotonic(), refs=0
                )
                logger.debug(
                    f"_build: Successfully created OpenAI embedder for {model_id}"
                )
            except Exception as e:
                logger.opt(exception=True).error(
                    f"_build: Failed to initialize OpenAI model {model_id}: {e}"
                )
                raise

        else:
            # This should ideally not be reached if Pydantic validation is working with discriminated unions
            # However, it's a good safeguard.
            logger.error(
                f"_build: Unsupported provider '{spec.provider}' for model {model_id}"
            )
            raise ValueError(
                f"Unsupported provider: {spec.provider} for model_id '{model_id}'"
            )

        build_time = time.perf_counter() - t0
        logger.info(f"_build: Loaded model {model_id} in {build_time:.2f}s")
        return rec

    @model_operation
    def embed(
        self, texts: List[str], *, model_id: Optional[str] = None, as_list: bool = False
    ):
        """
        Embed a list of texts using the specified model or the default model.

        The lock guards only the model-cache checkout below; the forward pass
        runs OUTSIDE it (task-34398), so concurrent callers -- including the
        same model -- never serialize behind one global lock. The refcount
        checked out here guarantees the model cannot be evicted or closed
        while this call is in flight.

        Args:
            texts: List of strings to embed
            model_id: Optional model ID to use (falls back to default_model_id)
            as_list: If True, return embeddings as list of lists instead of numpy array

        Returns:
            Embeddings as numpy array or list of lists
        """
        logger.debug(
            f"embed: Called with {len(texts)} texts, model_id={model_id}, as_list={as_list}"
        )

        model_id_to_use = model_id or self._cfg.default_model_id
        if not model_id_to_use:
            logger.error("embed: No model_id provided and no default_model_id is set")
            raise ValueError("No model_id provided and no default_model_id is set.")

        if not texts:
            logger.debug("embed: Empty texts list provided, returning empty result")
            _ensure_numpy()
            return [] if as_list else np.empty((0, 0), dtype=np.float32)

        # --- Cache checkout: mutate the cache under the lock, then release
        # it for the model work (task-34398). ---
        logger.debug(f"embed: Acquiring lock for cache checkout of {model_id_to_use}")
        with self._cond:
            # First, check for idle models to evict -- never one that is
            # still checked out (refcount > 0).
            now = time.monotonic()
            for mid, rec in list(self._cache.items()):
                if rec["refs"] == 0 and now - rec["last"] > self._idle:
                    logger.debug(
                        f"embed: Idle evicting model {mid} (unused for {now - rec['last']:.1f}s)"
                    )
                    if rec["close"]:
                        rec["close"]()
                    self._cache.pop(mid)

            # Now, get the model, building it if it doesn't exist.
            rec = self._cache.get(model_id_to_use)
            if rec is None:
                logger.info(
                    f"embed: Model {model_id_to_use} not in cache, will build it"
                )
                # If we need to load a model, make space for it *first* --
                # but only by evicting models that are NOT checked out. If
                # every cached model is currently in use, we transiently
                # exceed max_cached rather than evicting a live model (the
                # same trade-off prefetch already documents).
                while len(self._cache) >= self._max_cached:
                    lru_mid = next(
                        (mid for mid, r in self._cache.items() if r["refs"] == 0),
                        None,
                    )
                    if lru_mid is None:
                        logger.debug(
                            f"embed: all {len(self._cache)} cached models are in use; "
                            f"building {model_id_to_use} past max_cached"
                        )
                        break
                    lru_rec = self._cache[lru_mid]
                    logger.debug(
                        f"embed: LRU evicting model {lru_mid} to make space for {model_id_to_use}"
                    )
                    if lru_rec["close"]:
                        lru_rec["close"]()
                    self._cache.pop(lru_mid)
                logger.debug(f"embed: Building model {model_id_to_use}")
                rec = self._build(model_id_to_use)
                self._cache[model_id_to_use] = rec
                logger.info(
                    f"embed: Successfully built and cached model {model_id_to_use}"
                )
            else:
                logger.debug(f"embed: Using cached model {model_id_to_use}")

            # Mark as most recently used, check the model out (refcount), and
            # grab the function to call.
            rec["last"] = time.monotonic()
            rec["refs"] += 1
            self._cache.move_to_end(model_id_to_use)
            embed_fn = rec["embed"]

        # The embedding call itself runs OUTSIDE the lock (task-34398): the
        # refcount above, not lock-held-for-the-whole-call, now guarantees
        # the model cannot be evicted by another thread while it is in use.
        # See the class docstring for the concurrent-forward-pass safety
        # contract every embed_fn must uphold.
        try:
            logger.debug(
                f"embed: Starting embedding of {len(texts)} texts with model {model_id_to_use}"
            )
            t0 = time.perf_counter()
            result = embed_fn(texts, as_list=as_list)
            elapsed = time.perf_counter() - t0
            logger.debug(
                f"embed: Completed embedding {len(texts)} texts with model {model_id_to_use} in {elapsed:.3f}s"
            )

            # Log more details for larger batches or slower operations
            if len(texts) > 10 or elapsed > 1.0:
                logger.info(
                    f"embed: Embedded {len(texts)} texts with model {model_id_to_use} in {elapsed:.3f}s ({elapsed / len(texts):.3f}s per text)"
                )

            return result
        finally:
            # Check the model back in; wake close() if it is waiting for
            # in-flight embeds to drain.
            with self._cond:
                rec["refs"] -= 1
                self._cond.notify_all()

    async def async_embed(
        self, texts: List[str], *, model_id: Optional[str] = None, as_list: bool = False
    ):
        """Non-blocking version of `embed` for use in async contexts."""
        return await asyncio.to_thread(
            self.embed, texts, model_id=model_id, as_list=as_list
        )

    def embed_one(
        self, text: str, *, model_id: Optional[str] = None, as_list: bool = False
    ):
        vecs = self.embed([text], model_id=model_id, as_list=as_list)
        return vecs[0] if as_list else vecs.squeeze(0)

    async def async_embed_one(
        self, text: str, *, model_id: Optional[str] = None, as_list: bool = False
    ):
        vecs = await self.async_embed([text], model_id=model_id, as_list=as_list)
        return vecs[0] if as_list else vecs.squeeze(0)

    @model_operation
    def prefetch(self, model_ids: List[str]):
        """Download / load given model ids in advance (bypasses eviction)."""
        for mid in model_ids:
            with self._lock:
                if mid in self._cache:
                    continue
                # Note: This can temporarily exceed max_cached, which is acceptable for a startup operation.
                self._cache[mid] = self._build(mid)
            logger.info("prefetched {}", mid)

    def close(self) -> None:
        """Close all models and clear the cache.

        Waits for any in-flight ``embed`` calls to check their models back in
        first (task-34398): before the lock-scope reduction, ``close()``
        acquired the same lock the whole forward pass held, so it could never
        close a model mid-use; the refcount + Condition pair preserves that
        guarantee without serializing the embeds themselves.
        """
        with self._cond:
            while any(rec["refs"] > 0 for rec in self._cache.values()):
                self._cond.wait()
            for mid, rec in self._cache.items():
                if rec["close"]:
                    rec["close"]()
            self._cache.clear()
            logger.debug("factory closed")

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc, tb):
        self.close()


###############################################################################
# Default configuration helpers
###############################################################################


def get_default_embedding_config() -> EmbeddingConfigSchema:
    """
    Get a minimal default embedding configuration.

    This provides a working configuration with the mxbai-embed-large-v1 model,
    which offers high-quality embeddings with flexible dimension support.

    Returns:
        EmbeddingConfigSchema with default settings
    """
    return EmbeddingConfigSchema(
        default_model_id="mxbai-embed-large-v1",
        models={
            "mxbai-embed-large-v1": HFModelCfg(
                provider="huggingface",
                model_name_or_path="mixedbread-ai/mxbai-embed-large-v1",
                dimension=1024,  # Supports Matryoshka - can use 512 for speed/storage
                trust_remote_code=False,
                max_length=512,
                device=None,  # Will auto-detect best device
                batch_size=16,  # Reduced for larger model
            )
        },
    )


def get_common_embedding_models() -> Dict[str, ModelCfg]:
    """
    Get a dictionary of commonly used embedding models.

    Returns:
        Dictionary mapping model IDs to their configurations
    """
    return {
        # High-quality models with flexible dimensions
        "mxbai-embed-large-v1": HFModelCfg(
            provider="huggingface",
            model_name_or_path="mixedbread-ai/mxbai-embed-large-v1",
            dimension=1024,  # Supports 512, 256 via Matryoshka
            max_length=512,
            batch_size=16,
        ),
        # Small, fast models (good for development/testing)
        "e5-small-v2": HFModelCfg(
            provider="huggingface",
            model_name_or_path="intfloat/e5-small-v2",
            dimension=384,
            max_length=512,
        ),
        "all-MiniLM-L6-v2": HFModelCfg(
            provider="huggingface",
            model_name_or_path="sentence-transformers/all-MiniLM-L6-v2",
            dimension=384,
            max_length=256,
        ),
        "bge-small-en-v1.5": HFModelCfg(
            provider="huggingface",
            model_name_or_path="BAAI/bge-small-en-v1.5",
            dimension=384,
            max_length=512,
        ),
        # Medium models (good balance)
        "e5-base-v2": HFModelCfg(
            provider="huggingface",
            model_name_or_path="intfloat/e5-base-v2",
            dimension=768,
            max_length=512,
        ),
        "all-mpnet-base-v2": HFModelCfg(
            provider="huggingface",
            model_name_or_path="sentence-transformers/all-mpnet-base-v2",
            dimension=768,
            max_length=384,
        ),
        "bge-base-en-v1.5": HFModelCfg(
            provider="huggingface",
            model_name_or_path="BAAI/bge-base-en-v1.5",
            dimension=768,
            max_length=512,
        ),
        # Large models (best quality)
        "e5-large-v2": HFModelCfg(
            provider="huggingface",
            model_name_or_path="intfloat/e5-large-v2",
            dimension=1024,
            max_length=512,
        ),
        "multilingual-e5-large-instruct": HFModelCfg(
            provider="huggingface",
            model_name_or_path="intfloat/multilingual-e5-large-instruct",
            dimension=1024,
            max_length=512,
        ),
        # OpenAI models (require API key)
        "openai-ada-002": OpenAICfg(
            provider="openai",
            model_name_or_path="text-embedding-ada-002",
            dimension=1536,
        ),
        "openai-3-small": OpenAICfg(
            provider="openai",
            model_name_or_path="text-embedding-3-small",
            dimension=1536,
        ),
        "openai-3-large": OpenAICfg(
            provider="openai",
            model_name_or_path="text-embedding-3-large",
            dimension=3072,
        ),
        # State-of-the-art models (require trust_remote_code)
        "stella_en_1.5B_v5": HFModelCfg(
            provider="huggingface",
            model_name_or_path="NovaSearch/stella_en_1.5B_v5",
            dimension=1024,  # Supports 512-8192 via Matryoshka
            trust_remote_code=True,
            revision="4bbc0f1e9df5b9563d418e9b5663e98070713eb8",  # Pinned for security
            max_length=512,
            batch_size=8,
        ),
        "qwen3-embedding-4b": HFModelCfg(
            provider="huggingface",
            model_name_or_path="Qwen/Qwen3-Embedding-4B",
            dimension=4096,  # Flexible up to 4096
            # TASK-32901: this entry shipped trust_remote_code=True with no
            # revision, unlike the pinned sibling above. Qwen3 is a native
            # transformers architecture, so remote code is not required;
            # re-adding it needs a pinned commit, never a bare HEAD download.
            max_length=32768,  # 32k context
            batch_size=4,
        ),
    }


def create_embedding_factory_with_defaults(
    config: Optional[Union[Dict[str, Any], EmbeddingConfigSchema]] = None, **kwargs
) -> EmbeddingFactory:
    """
    Create an EmbeddingFactory with sensible defaults if no config provided.

    Args:
        config: Optional configuration dict or EmbeddingConfigSchema
        **kwargs: Additional arguments passed to EmbeddingFactory constructor

    Returns:
        Configured EmbeddingFactory instance
    """
    if config is None:
        logger.info("No embedding configuration provided, using defaults")
        config = get_default_embedding_config()

    return EmbeddingFactory(config, **kwargs)


#
# End of Embeddings_Lib.py
########################################################################################################################
