"""
Root conftest.py for shared test fixtures and configuration.
This file provides common fixtures used across the test suite.
"""

import importlib
import os
import shutil
import tempfile
from pathlib import Path

from Tests import real_profile_guard as _real_profile_guard

# TASK-33665: refuse writes to the real tldw profile before anything else runs.
# Environment redirection below is the first line; this guard is the backstop.
_real_profile_guard.install()

_TEST_CONFIG_ROOT_ENV = "TLDW_TEST_CONFIG_ROOT"
_TEST_CONFIG_OWNER_ENV = "TLDW_TEST_CONFIG_ROOT_OWNER"
_SANDBOXED_ENV_NAMES = (
    "HOME",
    "USERPROFILE",
    "XDG_DATA_HOME",
    "XDG_CONFIG_HOME",
    "TLDW_CONFIG_PATH",
    "PYTHON_KEYRING_BACKEND",
    "HF_HUB_OFFLINE",
    "TIKTOKEN_CACHE_DIR",
    _TEST_CONFIG_ROOT_ENV,
    _TEST_CONFIG_OWNER_ENV,
)
# The caller's values, for reading only: session end never restores them.
_PREVIOUS_TEST_ENV = {name: os.environ.get(name) for name in _SANDBOXED_ENV_NAMES}
_existing_test_config_root = os.environ.get(_TEST_CONFIG_ROOT_ENV)
# Under pytest-xdist the controller creates the sandbox root and workers
# inherit it via the env; give each worker its own subtree so concurrent
# workers never share a config/home/data dir (task-1453). The name guard keeps
# re-entrant loads (Tests/UI/conftest.py, subprocess children) from suffixing
# twice — the suffixed path is republished to the env below. The controller
# owns the unsuffixed root and its sessionfinish rmtree removes the worker
# subtrees with it.
# The worker id is only ever xdist's own "gw<N>"; the strict pattern makes the
# env-derived path join traversal-proof without pulling app-level path
# validation into this pre-sys.path bootstrap (an id that fails the pattern is
# ignored, falling back to the shared root).
_XDIST_WORKER = os.environ.get("PYTEST_XDIST_WORKER")
if _XDIST_WORKER and not __import__("re").fullmatch(r"[A-Za-z0-9_-]+", _XDIST_WORKER):
    _XDIST_WORKER = None
if _existing_test_config_root:
    _BOOTSTRAP_CONFIG_ROOT = Path(_existing_test_config_root)
    if _XDIST_WORKER and _BOOTSTRAP_CONFIG_ROOT.name != _XDIST_WORKER:
        _BOOTSTRAP_CONFIG_ROOT = _BOOTSTRAP_CONFIG_ROOT / _XDIST_WORKER
        _BOOTSTRAP_CONFIG_ROOT.mkdir(mode=0o700, parents=True, exist_ok=True)
    _OWNS_BOOTSTRAP_CONFIG_ROOT = False
else:
    _BOOTSTRAP_CONFIG_ROOT = Path(tempfile.mkdtemp(prefix="tldw_test_config_"))
    _OWNS_BOOTSTRAP_CONFIG_ROOT = True
_BOOTSTRAP_CONFIG_ROOT = _BOOTSTRAP_CONFIG_ROOT.resolve(strict=True)
os.environ[_TEST_CONFIG_ROOT_ENV] = str(_BOOTSTRAP_CONFIG_ROOT)
if _OWNS_BOOTSTRAP_CONFIG_ROOT:
    os.environ[_TEST_CONFIG_OWNER_ENV] = str(Path(__file__).resolve())
_BOOTSTRAP_DATA_HOME = _BOOTSTRAP_CONFIG_ROOT / "data"
_BOOTSTRAP_CONFIG_PATH = _BOOTSTRAP_CONFIG_ROOT / "config" / "config.toml"
_BOOTSTRAP_HOME = _BOOTSTRAP_CONFIG_ROOT / "home"
_BOOTSTRAP_DATA_HOME.mkdir(parents=True, mode=0o700, exist_ok=True)
_BOOTSTRAP_CONFIG_PATH.parent.mkdir(parents=True, mode=0o700, exist_ok=True)
_BOOTSTRAP_HOME.mkdir(parents=True, mode=0o700, exist_ok=True)
os.environ["HOME"] = str(_BOOTSTRAP_HOME)
os.environ["USERPROFILE"] = str(_BOOTSTRAP_HOME)
os.environ["XDG_DATA_HOME"] = str(_BOOTSTRAP_DATA_HOME)
os.environ["XDG_CONFIG_HOME"] = str(_BOOTSTRAP_CONFIG_PATH.parent)
os.environ["TLDW_CONFIG_PATH"] = str(_BOOTSTRAP_CONFIG_PATH)
# TASK-19570 finding A: every mounted-app test reaches the real OS credential
# subsystem. `TldwCli.__init__` calls `_wire_server_context_provider()` ->
# `build_default_server_credential_store()` -> `keyring.get_keyring()`
# (app.py:5811, runtime_policy/server_credentials.py:296-298), unconditionally
# and with no test seam -- `Tests/UI/app_factory.py` contains no `keyring`
# string at all. On macOS the first read can raise a Keychain consent dialog or
# block on a locked keychain, which under `timeout_method="thread"` kills the
# whole run rather than one test. The risk was already known here:
# `Tests/Packaging/` sets exactly this backend for the subprocesses it spawns,
# but the awareness never reached the shared in-process app-construction seam.
#
# Set unconditionally rather than only when unset: an ambient value pointing at
# a real backend is precisely the case this must override. No test needs a live
# backend -- the one suite that is *about* keyring
# (`Tests/Skills/test_skill_trust_keyring_autounlock.py`) injects its own
# `FakeSecureKeyring()`, and no test calls `keyring.get_password`/`set_password`
# unpatched. `TLDW_TEST_REAL_KEYRING=1` is the deliberate opt-out.
if os.environ.get("TLDW_TEST_REAL_KEYRING") != "1":
    os.environ["PYTHON_KEYRING_BACKEND"] = "keyring.backends.null.Keyring"

# TASK-21562: no test downloads a model. `huggingface_hub` freezes
# `constants.HF_HUB_OFFLINE` at ITS import time, so this has to be written here
# -- in the pre-import bootstrap -- to be read at all; an env var set from a
# fixture arrives far too late (the measurement is in
# `Tests/RAG_Eval/conftest.py`'s offline-latch comment).
#
# Why globally, when two sub-conftests already do it for their own scope: the
# HF cache resolves INTO this sandbox (`.../home/.cache/huggingface/hub`), which
# never exists, so any code path reaching the hub attempts a real download. That
# is invisible on a developer machine -- whatever triggers it locally is not
# triggered -- and very visible in CI, where one core shard alone recorded 188
# egress-blocked errors against `huggingface.co:443` and a CDN address, each one
# `huggingface_hub` retrying five times before the guard's record failed the
# test at teardown. Offline turns that into an immediate, deterministic, local
# failure instead of a slow CI-only one.
#
# `TLDW_TEST_ALLOW_HF_DOWNLOADS=1` opts out, for a test that genuinely needs a
# live fetch.
# Truthy, not `== "1"`. `Tests/RAG_Search/conftest.py` already reads this same
# flag as `.strip().lower() in {"1","true","yes","on"}`, so an exact-match test
# here meant `TLDW_TEST_ALLOW_HF_DOWNLOADS=true` opted out there and stayed
# offline here -- one flag, two answers (TASK-21562.1).
_HF_DOWNLOAD_TRUTHY = {"1", "true", "yes", "on"}


def _hf_downloads_allowed() -> bool:
    """Whether this session opted into real HuggingFace downloads."""
    raw = os.environ.get("TLDW_TEST_ALLOW_HF_DOWNLOADS", "")
    return raw.strip().lower() in _HF_DOWNLOAD_TRUTHY


if not _hf_downloads_allowed():
    os.environ["HF_HUB_OFFLINE"] = "1"

import asyncio  # noqa: E402
import gc  # noqa: E402
import sqlite3  # noqa: E402
import sys  # noqa: E402
import time  # noqa: E402
import warnings  # noqa: E402
from typing import Iterator  # noqa: E402

import pytest  # noqa: E402
import pytest_asyncio  # noqa: E402
from loguru import logger  # noqa: E402

# Add project root to Python path for consistent imports
PROJECT_ROOT = Path(__file__).parent.parent
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

# Network egress is denied for the whole session from this point on (task-15111).
# Installed at conftest IMPORT time, not from a fixture, so module import,
# collection, fixture teardown and worker threads that outlive a test are all
# covered. Opt in per test with @pytest.mark.allow_network; see
# Tests/network_guard.py for the incident that motivated it.
from Tests import network_guard  # noqa: E402

network_guard.install()

# TASK-32908: force the frozen-at-import config read in Chunk_Lib NOW, while
# the bootstrap profile above is still the selected config, and before any
# test's per-test env redirect.
#
# `Chunking/Chunk_Lib.py` snapshots `summarize_system_prompt` from the prompt
# registry at MODULE IMPORT time (deliberately -- the legacy frozen-at-import
# channel, pinned by Tests/Internal_Prompts/test_summarization_migration.py).
# That snapshot calls get_cli_setting, which goes through the config-participant
# admission (ADR-126).
#
# The module is imported LAZILY from inside the media-DB v6->v7 migration
# (DB/Client_Media_DB_v2.py::_apply_migration_v6_to_v7). So the first test that
# builds a media DB pays that import INSIDE an already-open raw-participant
# scope, under the per-test TLDW_CONFIG_PATH redirect -- the bound config
# selection no longer matches and admission fails closed with
# RecoveryRequired("raw_source_selection_changed"). The failure lands on
# whichever test happens to migrate first, and on every later test in the
# process, which is why it reads as a mass fixture-setup failure rather than as
# one broken test.
#
# Importing here costs ~0.26 s once per process and is NOT a behaviour change:
# it only fixes WHEN the snapshot is taken. Do not "optimize" this into a lazy
# import -- being eager is the entire point.
#
# NB: this must stay INSIDE the conftest, after the bootstrap env above. Doing
# the same import from a wrapper before pytest starts binds the participant to
# the developer's REAL ~/.config/tldw_cli/config.toml and then fails at
# collection instead.
importlib.import_module("tldw_chatbook.Chunking")

# TASK-33940.6: the same trap, second module. RAG_Search/simplified/rag_service.py
# calls load_settings() at import, and Utils.sensitive_paths imports it lazily
# (via RAG_Search.config_profiles) the first time a workspace folder is bound.
# A test that binds a folder first in its process therefore failed with
# RecoveryRequired("raw_source_selection_changed") -- on dev,
# Tests/Tools/test_file_tools_workspace_roots.py::test_read_allowed_in_bound_folder
# errored whenever it ran alone. ~0.45 s once per process.
importlib.import_module("tldw_chatbook.RAG_Search.config_profiles")

# TASK-33003.6: the app stylesheets reference the theme guard variables
# (themes.GUARD_VARIABLES: $tldw-boundary, $tldw-focus-fill and, since
# TASK-33641.1, $tldw-active-edge), which no tcss defines. Production gets
# them from TldwCli's ThemeVariableDefaultsMixin and from this module's
# import-time guard over Textual's BUILTIN_THEMES (app.py imports it before
# any App exists). A test harness App that loads the sheets gets neither
# unless something imported the module first, and then fails with
# UnresolvedVariableError -- 96 tests in 10 files did, whenever run on their
# own. Import it here, as production does.
importlib.import_module("tldw_chatbook.css.Themes.themes")

# tasks-32951/32953 (trace-surface port): the ModelCapabilities singleton
# initializes on FIRST CALL, not import -- when that first call happens inside
# a raw-participant scope under the per-test sandbox (is_vision_capable from
# the Console turn-configuration snapshot), the bound config selection no
# longer matches and admission fails closed with
# RecoveryRequired("raw_source_selection_changed"). Same class as the Chunking
# import above: initialize the singleton here, after the bootstrap env, so the
# first per-test call reads an already-bound snapshot.
importlib.import_module("tldw_chatbook.model_capabilities").get_model_capabilities()


# Hypothesis: no per-example deadline (TASK-1260).
#
# Several property tests do real work per example -- `test_safe_paths_always_validate`
# creates a TemporaryDirectory plus up to four directories, and the DB property
# suites open SQLite connections. Hypothesis' default deadline is 200ms per
# example, which a loaded machine crosses on work that is not actually slow:
# this repo routinely runs 10+ concurrent pytest processes from parallel agents.
#
# The resulting failure is indistinguishable from a real regression at the moment
# it appears, and attributing one instance cost five runs across two worktrees.
# A deadline that fails a property which *holds* is measuring the machine, not
# the code -- so it is disabled rather than merely raised. Do not "tighten this
# back up" as an apparent improvement; timing belongs in benchmarks, not in
# correctness properties.
try:  # pragma: no cover - hypothesis is a test-only dependency
    from hypothesis import HealthCheck
    from hypothesis import settings as _hypothesis_settings

    # Example counts are env-scaled (task-1452): 'dev' keeps routine runs fast,
    # CI sets TLDW_HYPOTHESIS_PROFILE=ci, and the scheduled deep run uses
    # 'thorough' so the reduced dev depth has a compensating control.
    # Hypothesis binds settings.default at DECORATION time, so this profile
    # must be active whenever a test module is imported. Property modules that
    # need extra health-check suppressions use local @settings decorators;
    # they must not register or load process-wide profiles. An import-time
    # load_profile() silently reconfigures every later-imported module's
    # unannotated @given tests (the pre-task-1452 state).
    _HYPOTHESIS_SCALES = {
        "dev": {"max_examples": 25, "stateful_step_count": 20},
        "ci": {"max_examples": 50, "stateful_step_count": 30},
        "thorough": {"max_examples": 300, "stateful_step_count": 100},
    }
    _pt_profile = os.environ.get("TLDW_HYPOTHESIS_PROFILE", "dev")
    if _pt_profile not in _HYPOTHESIS_SCALES:
        # A typo'd profile silently running at dev depth is exactly the kind of
        # quiet configuration rot this suite has been burned by — warn loudly
        # (pytest surfaces it in the warnings summary) but do not brick every
        # local run over it.
        warnings.warn(
            f"Unknown TLDW_HYPOTHESIS_PROFILE={_pt_profile!r}; expected one of "
            f"{sorted(_HYPOTHESIS_SCALES)} — falling back to 'dev' scale",
            UserWarning,
            stacklevel=1,
        )
        _pt_profile = "dev"
    _pt_scale = _HYPOTHESIS_SCALES[_pt_profile]

    _hypothesis_settings.register_profile(
        "tldw",
        deadline=None,
        # `too_slow` fires for the same reason the deadline does: machine load,
        # not a slow strategy.
        suppress_health_check=[HealthCheck.too_slow],
        **_pt_scale,
    )
    _hypothesis_settings.load_profile("tldw")
except ImportError:
    pass

# Protect against stdout/stderr being closed during testing
# This can happen with certain test runners or when tests manipulate file descriptors
if hasattr(sys.stdout, "fileno"):
    try:
        sys.stdout.fileno()
    except (ValueError, OSError):
        # stdout is closed or invalid, replace with a safe alternative
        import io

        sys.stdout = io.StringIO()

if hasattr(sys.stderr, "fileno"):
    try:
        sys.stderr.fileno()
    except (ValueError, OSError):
        # stderr is closed or invalid, replace with a safe alternative
        import io

        sys.stderr = io.StringIO()


@pytest.hookimpl(hookwrapper=True, tryfirst=True)
def pytest_runtest_teardown(
    item: pytest.Item, nextitem: pytest.Item | None
) -> Iterator[None]:
    """Finish config-source imports after normal fixture/resource cleanup.

    Args:
        item: Test whose owned fixtures and resources are being retired.
        nextitem: Next test, or None at session end, for pytest's fixture teardown.

    Yields:
        Control to pytest so resource and monkeypatch teardown finishes before
        selected-source consumer bindings are restored.
    """
    yield
    from Tests.Backup_Recovery.config_test_support import (
        restore_config_source_consumers,
    )

    restore_config_source_consumers()


# ========== Path and File System Fixtures ==========


@pytest.fixture
def isolated_temp_dir():
    """Create an isolated temporary directory that's always cleaned up."""
    temp_dir = tempfile.mkdtemp(prefix="tldw_test_")
    temp_path = Path(temp_dir)
    yield temp_path
    # Ensure cleanup even if test fails
    if temp_path.exists():
        shutil.rmtree(temp_dir, ignore_errors=True)


@pytest.fixture
def temp_file(isolated_temp_dir):
    """Create a temporary file within an isolated directory."""

    def _create_temp_file(name="test_file", suffix=".txt", content=""):
        file_path = isolated_temp_dir / f"{name}{suffix}"
        file_path.write_text(content)
        return file_path

    return _create_temp_file


# ========== Database Fixtures ==========


@pytest.fixture
def in_memory_db():
    """Create an in-memory SQLite database for testing."""
    conn = sqlite3.connect(":memory:")
    conn.row_factory = sqlite3.Row
    yield conn
    conn.close()


@pytest.fixture
def temp_db_path(isolated_temp_dir):
    """Provide a path for a temporary database file."""
    return isolated_temp_dir / "test_database.db"


# ========== Cleanup and Isolation Fixtures ==========


@pytest.fixture(scope="session")
def chachanotes_template_db(tmp_path_factory: pytest.TempPathFactory) -> Path:
    """Build the schema-complete CharactersRAGDB template once per session.

    CharactersRAGDB's full schema DDL costs ~137ms per construction; copying
    this template and reopening costs ~10.5ms (task-1460). Hosted here so any
    directory's fixtures can copy it (ChaChaNotesDB, Chatbooks — task-1462);
    the import is lazy, so sessions that never request the fixture never pay
    for it. client_id is per-row attribution: the empty template carries no
    identity to re-stamp.

    Args:
        tmp_path_factory: pytest's session-scoped temp directory factory.

    Returns:
        Path to a closed, WAL-checkpointed, sidecar-free template file.
    """
    from tldw_chatbook.DB.ChaChaNotes_DB import CharactersRAGDB

    template = tmp_path_factory.mktemp("chachanotes-template") / "template.sqlite"
    db = CharactersRAGDB(template, "template_builder")
    db.close_connection()
    leftovers = [s for s in ("-wal", "-shm") if Path(f"{template}{s}").exists()]
    assert not leftovers, f"template close left WAL sidecars: {leftovers}"
    return template


@pytest.fixture(autouse=True)
def install_css_parse_cache() -> "Iterator[None]":
    """Install the session-global CSS parse cache once Textual is imported.

    Lazy and conditional (task-1459): test modules import Textual at
    collection time, so by the first test's fixture setup the module is in
    ``sys.modules`` whenever this session will mount apps — and sessions that
    never touch Textual never import the cache. TLDW_TEST_CSS_CACHE=0
    disables it (the install() itself re-checks the env var).

    Yields:
        None. Installation (idempotent) happens in setup.
    """
    if "textual.css.stylesheet" in sys.modules:
        from Tests.UI import css_cache

        css_cache.install()
    yield


@pytest.fixture(autouse=True)
def reset_provider_session_registry() -> "Iterator[None]":
    """Drop the calling thread's provider HTTP sessions between tests.

    ADR-222 (TASK-34418): provider calls cache one ``requests.Session`` per
    ``(key, thread)``. Tests monkeypatch ``create_default_session`` per
    test, so without this reset a session built under test N's patched
    factory could be handed to test N+1 under the same registry key.
    """
    from tldw_chatbook.LLM_Calls.provider_sessions import (
        close_all_for_current_thread,
    )

    close_all_for_current_thread()
    yield
    close_all_for_current_thread()


@pytest.fixture(autouse=True)
def drain_test_app_user_data_dirs(request) -> "Iterator[None]":
    """Remove the user-data dirs and stop the service patches the shared app
    factory created during a test.

    ``Tests/UI/app_factory._build_test_app`` records every ``mkdtemp`` it
    makes; draining here (task-1458) stops the per-call leak that accumulated
    324k orphaned sandboxes (~285GB) on one dev machine. It also stops every
    still-running service patch the factory started (task-1631:
    ``get_subscriptions_db_path`` is patched OUTSIDE the factory's own
    ``ExitStack`` so it stays in effect for the whole test, not just
    ``TldwCli.__init__`` -- see that module for why), so it never leaks into
    the next test. The import is lazy and conditional so the ~18k tests that
    never build an app pay nothing.

    Yields:
        None. Draining happens in teardown.
    """
    delegate = (
        request.node.get_closest_marker("asyncio") is not None
        or "retire_test_app_owners" in request.fixturenames
    )
    if delegate:
        # Request before yield: this outer finalizer delegates all owner cleanup
        # to the async fixture, which must dispose runtime workers before DBs.
        request.getfixturevalue("retire_test_app_owners")
    yield
    if not delegate:
        attached = sys.modules.get("Tests.UI.test_console_fleet_wake_wiring")
        if attached is not None:
            attached.drain_attached_real_databases()
        factory = sys.modules.get("Tests.UI.app_factory")
        if factory is not None:
            factory.drain_active_service_patches()
            factory.drain_created_dirs()


@pytest_asyncio.fixture
async def retire_test_app_owners(isolate_test_environment, request) -> None:
    """Opt-in async owner retirement, without loops for unrelated sync tests."""
    yield
    factory = sys.modules.get("Tests.UI.app_factory")
    attached = sys.modules.get("Tests.UI.test_console_fleet_wake_wiring")
    owns_apps = bool(factory is not None and factory._created_apps) or bool(
        attached is not None and attached._attached_real_databases
    )
    if owns_apps:
        request.node._test_app_native_workers_uncertain = True
    if factory is not None:
        await factory.drain_created_runtimes()
    if attached is not None:
        await attached.drain_attached_real_runtimes()
    if owns_apps:
        from tldw_chatbook.app_lifecycle import WORKER_CANCELLATION_GRACE_SECONDS

        # Canceled Textual tasks may leave native callbacks running. Join them
        # before config reset or any DB drain; timeout is uncertain custody.
        with warnings.catch_warnings():
            warnings.simplefilter("error", RuntimeWarning)
            await asyncio.get_running_loop().shutdown_default_executor(
                timeout=WORKER_CANCELLATION_GRACE_SECONDS
            )
        request.node._test_app_native_workers_uncertain = False
    if attached is not None:
        attached.drain_attached_real_databases()
    if factory is not None:
        factory.drain_active_service_patches()
        factory.drain_created_dirs()


@pytest.fixture(autouse=True)
def required_doubles_are_called(request) -> "Iterator[None]":
    """Fail a test that never called a double it declared it must call.

    task-15270. A test whose subject is "X still works when Y fails" passes
    for the wrong reason the moment Y stops being reached -- which is exactly
    how `test_send_proceeds_when_auto_retrieve_fails` stayed green for two
    months without ever calling its exploding backend (task-15210). Doubles
    built through ``Tests.fixtures.required_doubles`` register themselves, so
    the check cannot be forgotten at the assertion site; see that module for
    why the detection of UNregistered ones is a separate, reporting-only
    audit.

    Yields:
        None. The check runs in teardown, after the test's own assertions.
    """
    from Tests.fixtures import required_doubles

    required_doubles.reset_required_doubles()
    yield
    unmet = required_doubles.uncalled_required_doubles()
    audited = required_doubles.audited_uncalled_doubles()
    required_doubles.write_audit_report(request.node.nodeid, audited)
    required_doubles.reset_required_doubles()
    if unmet:
        pytest.fail("\n".join(unmet), pytrace=False)


@pytest.fixture(autouse=True)
def restore_sys_path():
    """Automatically restore sys.path after each test."""
    original_path = sys.path.copy()
    yield
    sys.path[:] = original_path


@pytest.fixture(autouse=True)
def reset_remote_session_registry():
    """Drop the SSH session registry singleton after each test.

    An app test's on_unmount calls close_all_remote_sessions(), which shuts
    the singleton down for good; without this, later tests in the same
    process would get a one-shot-only registry. Also drops the SSH master
    manager singleton so straggler tests do not see a closed manager.
    Never imports the modules.
    """
    yield
    module = sys.modules.get("tldw_chatbook.Tools.remote_session_registry")
    if module is not None:
        module._REGISTRY = None
    transport = sys.modules.get("tldw_chatbook.Tools.remote_workspace_transport")
    if transport is not None:
        transport._MASTER_MANAGER = None


@pytest.fixture(autouse=True)
def cleanup_loguru_handlers():
    """Automatically cleanup loguru handlers after each test to prevent file descriptor leaks."""
    from loguru import logger

    # Store the initial handler IDs
    initial_handlers = list(logger._core.handlers.keys())

    yield

    # Remove any handlers added during the test
    current_handlers = list(logger._core.handlers.keys())
    for handler_id in current_handlers:
        if handler_id not in initial_handlers:
            try:
                logger.remove(handler_id)
            except (ValueError, KeyError):
                # Handler might already be removed
                pass


# Full gc passes after EVERY test cost real wall-clock at suite scale: the old
# version of this fixture ran TWO gc.collect() per test, ~23,000 full-heap
# collections per run with torch/transformers-sized heaps (2026-07-30 audit,
# driver #3). The FD-leak incidents that motivated it (loguru handlers, fds
# under Textual's redirected streams) are guarded by cleanup_loguru_handlers
# above and the fd_leak_sentinel below; periodic collection plus the
# requires_cleanup marker covers the rest. TLDW_TEST_GC_EVERY=1 restores
# per-test collection as an escape hatch.
def _env_int(name: str, default: int) -> int:
    """Parse an integer environment knob without letting a typo abort the run.

    Args:
        name: Environment variable name.
        default: Value used when the variable is unset or malformed.

    Returns:
        The parsed integer, or ``default`` (with a UserWarning) when the value
        is not a valid integer — a malformed escape-hatch value must degrade to
        the default, not kill conftest import for the whole suite.
    """
    raw = os.environ.get(name)
    if raw is None or not raw.strip():
        return default
    try:
        return int(raw)
    except ValueError:
        warnings.warn(
            f"{name}={raw!r} is not an integer; using default {default}",
            UserWarning,
            stacklevel=2,
        )
        return default


_GC_EVERY = max(1, _env_int("TLDW_TEST_GC_EVERY", 25))
_gc_test_counter = 0

# Directories whose tests mount Textual apps (run_test() call-site census from
# the 2026-07-30 audit). A Textual App is a reference CYCLE that only
# gc.collect() reclaims, and an uncollected app from the previous test
# interferes with the next app-mounting test — with periodic-only collection
# the victim rotates with heap state (task-1468: a 10-test batch failed a
# DIFFERENT UI test on consecutive runs, and passed 10/10 with
# TLDW_TEST_GC_EVERY=1). These dirs keep per-test collection; everything else
# stays periodic, which is where the task-1454 win lives.
_APP_MOUNTING_DIR_PARTS = (
    f"{os.sep}Tests{os.sep}UI{os.sep}",
    f"{os.sep}Tests{os.sep}Widgets{os.sep}",
    f"{os.sep}Tests{os.sep}Watchlists{os.sep}",
    f"{os.sep}Tests{os.sep}Skills{os.sep}",
    f"{os.sep}Tests{os.sep}Library{os.sep}",
    f"{os.sep}Tests{os.sep}Event_Handlers{os.sep}",
    f"{os.sep}Tests{os.sep}integration{os.sep}",
    f"{os.sep}Tests{os.sep}Chat{os.sep}",
)


@pytest.fixture(autouse=True)
def cleanup_file_descriptors(request: pytest.FixtureRequest) -> Iterator[None]:
    """Garbage-collect leaked file objects periodically (or per-test on request).

    Tests that genuinely need a collection pass right after they run (e.g. they
    open many files and assert on fd state) mark themselves
    ``@pytest.mark.requires_cleanup``. Tests in app-mounting directories
    (``_APP_MOUNTING_DIR_PARTS``) always collect, so a torn-down Textual app's
    reference cycle never lingers into the next app's lifetime.

    Args:
        request: The pytest fixture request, used to read the test's markers
            and path.

    Yields:
        None. Collection (if due) happens in teardown, after the test body.
    """
    yield

    # ADR-198: an app that reaches _ui_ready (or finishes screen pre-import)
    # calls gc.freeze() in THIS process, moving the test's own App cycle into
    # the permanent generation, where gc.collect() never reclaims it -- the
    # lingering-app interference described above. Unfreezing is a list splice.
    gc.unfreeze()
    global _gc_test_counter
    _gc_test_counter += 1
    _node_path = str(getattr(request.node, "path", "") or "")
    if (
        request.node.get_closest_marker("requires_cleanup")
        or any(part in _node_path for part in _APP_MOUNTING_DIR_PARTS)
        or _gc_test_counter % _GC_EVERY == 0
    ):
        # Suppress ResourceWarnings emitted for unclosed files reclaimed here.
        with warnings.catch_warnings():
            warnings.simplefilter("ignore", ResourceWarning)
            gc.collect()


@pytest.fixture(scope="session", autouse=True)
def fd_leak_sentinel() -> Iterator[None]:
    """Warn when the session's open-fd count grows past a leak threshold.

    Replacement leak detection for the per-test gc.collect() this file used to
    do: cheap (two directory listings per session), and unlike the gc pass it
    produces an actionable signal instead of silently papering over leaks.
    Warn-only for now; threshold via TLDW_TEST_FD_GROWTH_LIMIT. The signal is
    a UserWarning (never in default ignore filters, unlike ResourceWarning)
    plus a stderr line, so it survives any warning-filter configuration.

    Yields:
        None. The fd count comparison happens at session teardown.
    """
    fd_dir = "/dev/fd" if sys.platform == "darwin" else "/proc/self/fd"

    def _count_fds():
        try:
            return len(os.listdir(fd_dir))
        except OSError:
            return None

    limit = _env_int("TLDW_TEST_FD_GROWTH_LIMIT", 200)
    start = _count_fds()
    yield
    if start is None:
        return
    end = _count_fds()
    if end is not None and end - start > limit:
        message = (
            f"open file descriptors grew by {end - start} over the test session "
            f"(start={start}, end={end}, limit={limit}) — possible fd leak; "
            "bisect with TLDW_TEST_GC_EVERY=1 and mark offending tests "
            "@pytest.mark.requires_cleanup"
        )
        # UserWarning (not ResourceWarning): ResourceWarning sits in Python's
        # default ignore filters, so the sentinel's only signal could vanish
        # under filter configurations that don't re-enable it. The stderr echo
        # survives even -W ignore.
        warnings.warn(message, UserWarning, stacklevel=0)
        print(f"[fd_leak_sentinel] {message}", file=sys.stderr)


@pytest.fixture(autouse=True)
def _huggingface_hub_is_offline(monkeypatch: pytest.MonkeyPatch) -> Iterator[None]:
    """Close the other half of the offline latch (TASK-21562).

    The bootstrap above sets ``HF_HUB_OFFLINE`` before anything imports
    ``huggingface_hub``, which is the case that matters and the cheap one. This
    covers the case where the module was somehow imported first: its
    ``constants.HF_HUB_OFFLINE`` is frozen at import, so the env var would have
    been read before we wrote it, while ``is_offline_mode()`` consults the
    constant on every request and therefore still honours a write here.

    Looked up through ``sys.modules`` rather than imported. Importing
    ``huggingface_hub`` in every test session to assert a property of sessions
    that never touch it would cost more than the guard is worth, and would drag
    the whole hub stack into the import closure of the entire suite.

    ``monkeypatch.setattr`` rather than assignment, so a session that opted out
    per-test is restored -- the same reasoning as
    ``Tests/RAG_Eval/conftest.py``'s fixture, which does this for its own scope.

    TASK-21592: the latch is also re-asserted at teardown. It is the single
    condition standing between the suite and the failure class this fixture was
    written for -- a real hub fetch, five blocked retries on a worker thread,
    and teardown errors landing on unrelated passing tests. A test that turns
    the latch back off (directly, or by reloading ``huggingface_hub.constants``)
    would otherwise re-arm that class silently for everything that follows it in
    the process.

    Yields:
        None. The offline latch is re-asserted at teardown.
    """
    if _hf_downloads_allowed():
        yield
        return
    constants = sys.modules.get("huggingface_hub.constants")
    if constants is not None:
        monkeypatch.setattr(constants, "HF_HUB_OFFLINE", True, raising=False)
    yield
    # Looked up again rather than reusing `constants`: a test that imports the
    # hub for the first time is exactly the case where setup found nothing and
    # teardown is the only place the latch can be checked at all.
    still_loaded = sys.modules.get("huggingface_hub.constants")
    assert still_loaded is None or getattr(still_loaded, "HF_HUB_OFFLINE", False), (
        "huggingface_hub's offline latch was turned off during this test; the "
        "next test to reach the hub will make a real request, retry it five "
        "times on a worker thread, and fail an unrelated later test at teardown "
        "(TASK-21592). Set TLDW_TEST_ALLOW_HF_DOWNLOADS=1 to opt the session out."
    )


@pytest.fixture(autouse=True)
def _no_real_audio_device(
    request: pytest.FixtureRequest, monkeypatch: pytest.MonkeyPatch
) -> None:
    """No test opens real audio hardware unless it explicitly opts in.

    Task-4 streaming-pcm-sink review, merge-gate finding: `_generate_tts`
    (`Event_Handlers/TTS_Events/tts_events.py`) can construct a real
    `StreamingPcmSink` for an eligible pcm/wav response and, if nothing
    patches `StreamingPcmSink`/`sink_available`, `open()` lazily imports
    the real `sounddevice` and starts a real `OutputStream` against actual
    hardware -- reproduced: an unguarded eligible-wav test opened one and
    still PASSED, so this failure mode is silent to CI, review, and the
    suite itself. Neutralizes the single chokepoint every production
    device open passes through (`open()` can only build a stream via
    `_import_sounddevice()`); returning `None` drives the already-tested
    `_fail("audio output unavailable ...")` terminal path, so an
    accidental hazard degrades to the legacy path instead of hardware.
    Deliberately leaves `sink_available()` (the `find_spec` probe) alone,
    so no test's LOGICAL coverage changes, only its hardware access --
    measured: the full `Tests/TTS`/`Tests/TTS_Events`/`Tests/Audio` run is
    identical with and without this fixture. A test that genuinely needs a
    real device marks itself `@pytest.mark.real_audio_device` to opt out.
    This is the backstop; file-local guards (e.g.
    `Tests/TTS/test_console_audio_cpp_native.py`'s own
    `_sink_unavailable_by_default`) still document intent at their point
    of use and are not replaced by this. Since the meeting-transcription work
    it also stubs `AudioRecordingService._recording_loop` so no test opens
    a microphone.
    """
    if request.node.get_closest_marker("real_audio_device"):
        return
    import tldw_chatbook.Audio.streaming_sink as streaming_sink

    monkeypatch.setattr(streaming_sink, "_import_sounddevice", lambda: None)

    # Meeting transcription (2026-09-04): the same backstop for the INPUT
    # side. `AudioRecordingService.start_recording` only spawns a thread
    # running `_recording_loop`, which is where the backend opens the
    # device -- so stubbing the loop is the single chokepoint. Tests that
    # exercise `_pyaudio_recording_loop` / `_sounddevice_recording_loop`
    # directly with mocked backends are unaffected.
    import tldw_chatbook.Audio.recording_service as recording_service

    def _guarded_recording_loop(self) -> None:
        self.is_recording = False

    monkeypatch.setattr(
        recording_service.AudioRecordingService,
        "_recording_loop",
        _guarded_recording_loop,
    )


@pytest.fixture(autouse=True)
def _no_network_io(request: pytest.FixtureRequest) -> Iterator[None]:
    """No test reaches a live endpoint unless it explicitly opts in (task-15111).

    The socket patch itself is installed once at conftest import time and is
    denied by default; this fixture selects blocked, numeric-loopback-only, or
    unrestricted mode and turns a *swallowed* block into a failure.

    (b) is the load-bearing half. `BlockedNetworkAccess` is an `OSError`, so
    `local_server_discovery._get_models_payload`'s `except Exception` absorbs
    it and discovery simply reports "no models endpoint" -- exactly what a
    green run looks like today with nothing listening. Without the recorded
    attempts a future regression would reintroduce the escape silently, which
    is the whole defect. Failing on a non-empty record makes the guard
    unswallowable.

    Use `@pytest.mark.loopback_network` for an owned loopback listener or
    `@pytest.mark.allow_network` for unrestricted sockets. `live` (real paid
    external APIs, already gated behind `--run-live`) counts as unrestricted.

    Yields:
        None. The blocked-attempt record is asserted empty at teardown.
    """
    allow_all = bool(
        request.node.get_closest_marker("allow_network")
        or request.node.get_closest_marker("live")
    )
    loopback_only = bool(request.node.get_closest_marker("loopback_network"))
    try:
        mode = network_guard.resolve_mode(
            allow_all=allow_all,
            loopback_only=loopback_only,
        )
    except ValueError as exc:
        pytest.fail(f"conflicting network markers: {exc}", pytrace=False)
    network_guard.drain_blocked_attempts()  # also clears the thread record
    network_guard.set_mode(mode)
    try:
        yield
    finally:
        network_guard.set_mode(network_guard.NetworkMode.BLOCKED)
        # Threads first: draining the attempts clears both records.
        threads = network_guard.drain_blocked_attempt_threads()
        attempts = network_guard.drain_blocked_attempts()
    if attempts:
        raise AssertionError(
            "test attempted network egress (blocked): "
            + network_guard.describe_blocked_attempts(attempts, threads)
            + " — stub the client seam, use @pytest.mark.loopback_network for "
            "an owned numeric loopback listener, or use "
            "@pytest.mark.allow_network for unrestricted sockets."
        )


@pytest.fixture(autouse=True)
def _no_local_server_probes(
    request: pytest.FixtureRequest, monkeypatch: pytest.MonkeyPatch
) -> None:
    """Neutralize the local-server discovery probe's one network chokepoint.

    The mechanism behind task-15111: mounting the Console chat screen with an
    unconfigured provider blocks the setup card, which starts
    `_maybe_start_console_local_discovery` -> `discover_local_servers`. That
    candidate list ALWAYS leads with `http://127.0.0.1:8080` and
    `http://127.0.0.1:11434` regardless of config, and `probe_models_endpoint`
    builds a real `httpx.AsyncClient` when none is injected -- so every such
    test made two live TCP connections, and on a machine with a server on 8080
    the setup card grew a "detected server" affordance CI never sees.

    `_get_models_payload` is the single chokepoint: all three production
    import sites (`chat_screen`, `FirstRunSetupWizard`, `console_settings_modal`)
    funnel through `probe_models_endpoint`, which resolves it as a module
    global at call time, so patching it here covers callers that imported
    `probe_models_endpoint`/`discover_local_servers` by name. Returning the
    ordinary "no models endpoint" failure drives the already-tested
    nothing-listening path, so no test's LOGICAL coverage changes -- only its
    network access. `Tests/network_guard.py` is the backstop that proves it.

    A test that exercises the real probe implementation against an injected
    `httpx.MockTransport` client marks itself `@pytest.mark.local_server_probe`
    to opt out (see `Tests/Chat/test_local_server_discovery.py`).
    """
    if request.node.get_closest_marker("local_server_probe"):
        return
    from tldw_chatbook.Chat import local_server_discovery

    async def _no_endpoint(http_client, url, timeout, display):
        return None, f"No models endpoint at {display}."

    monkeypatch.setattr(local_server_discovery, "_get_models_payload", _no_endpoint)

    # task-15211 (sweep catch): the Models/Lab screen has its own parallel
    # chokepoint -- `llm_screen._probe_local_server`, a real TCP connect to
    # 127.0.0.1:11434, scheduled from a 3s interval AND a deferred-mount
    # one-shot. The one-shot flushes while `run_test` is tearing down, so
    # widget-lifetime cancellation cannot fully close it: seven Lab/LLM
    # tests hit the network guard AT TEARDOWN, and the probe (plus lab
    # status polling) is the prime suspect for a full-suite chunk whose
    # pytest printed its summary and then never exited. Same shape, same
    # remedy, same opt-out marker as `_get_models_payload` above. The
    # production caller resolves this at call time via a local import, so
    # the module-attribute patch covers it; the probe's own unit test
    # (`test_llm_screen_ollama_probe_nonblocking`) binds the real function
    # by name at import and is deliberately unaffected.
    from tldw_chatbook.UI.Screens import llm_screen

    async def _no_ollama(host="127.0.0.1", port=11434):
        return False

    monkeypatch.setattr(llm_screen, "_probe_local_server", _no_ollama)

    # TASK-33005.5: opening Switch model probes each keyless local server it
    # lists. The shipped default profile lists eight on localhost (llama.cpp,
    # Ollama, Aphrodite, TabbyAPI, the custom slots, ...), so every full-app
    # test that opens it -- Alt+M in Tests/UI, the palette in
    # Tests/ProductionApp -- made real loopback connects and failed the egress
    # guard at teardown (15 Tests/UI failures on first run). The probe goes
    # through `probe_settings_endpoint`, not `_get_models_payload` above, so it
    # gets its own chokepoint: `open_model_switcher` resolves this module
    # attribute at call time. The probe's own tests bind the real function by
    # name at import (`Tests/UI/test_console_switcher_local_probe.py`).
    from tldw_chatbook.UI.Console_Modules import connection_probe

    async def _no_switcher_probe(_targets, _settled) -> None:
        return None

    monkeypatch.setattr(
        connection_probe,
        "switcher_connection_prober",
        lambda _app, _app_config, **_gate: _no_switcher_probe,
    )


@pytest.fixture(autouse=True)
def _console_gateway_http_client_is_offline(
    request: pytest.FixtureRequest, monkeypatch: pytest.MonkeyPatch
) -> None:
    """The Console provider gateway never owns a network-capable client in tests.

    Sharper half of task-15111. `Tests/UI`'s send-path tests configure a
    "ready" llama.cpp Console at `http://127.0.0.1:9099`
    (`_configure_native_ready_console`) and then drive a REAL send through
    `ConsoleProviderGateway`. On CI nothing listens there, `_is_reachable`'s
    GET `/health` fails, and the send stops. Measured against a stand-in
    server bound to 9099,
    `test_console_command_popup::test_enter_with_popup_closed_sends_normally`
    went on to send **two POSTs to `/v1/chat/completions`** (streaming, then
    the non-streaming fallback) carrying the test's prompt. So the escape was
    never merely a stray GET: with a llama.cpp on that port a test run would
    have driven real inference on the developer's server.

    `_new_owned_http_client` is the single construction site for every client
    the gateway owns (`__init__` and the per-loop cache both call it), and
    injected clients set `_owns_http_client = False` and are left alone -- so
    MockTransport-based gateway tests are unaffected. Substituting a transport
    that raises `httpx.ConnectError` reproduces the CI "nothing is listening"
    outcome deterministically, on every machine, with no socket: `_is_reachable`
    and `resolve_llamacpp` already catch `httpx.HTTPError`.

    A test that is ABOUT the owned client itself (its timeouts, its per-loop
    cache) marks itself `@pytest.mark.owned_http_client` to opt out;
    `allow_network` and `loopback_network` imply the same, since either marker
    plainly requests the real owned client.
    """
    if (
        request.node.get_closest_marker("owned_http_client")
        or request.node.get_closest_marker("allow_network")
        or request.node.get_closest_marker("loopback_network")
    ):
        return
    import httpx

    from tldw_chatbook.Chat.console_provider_gateway import ConsoleProviderGateway

    def _refuse(http_request: "httpx.Request") -> "httpx.Response":
        raise httpx.ConnectError(
            "network access blocked in tests (Tests/conftest.py, task-15111)",
            request=http_request,
        )

    monkeypatch.setattr(
        ConsoleProviderGateway,
        "_new_owned_http_client",
        staticmethod(lambda: httpx.AsyncClient(transport=httpx.MockTransport(_refuse))),
    )


# ========== Async Cleanup Fixtures ==========


@pytest.fixture
def cleanup_async_tasks():
    """Cleanup any pending async tasks after async tests.

    Note: This fixture should be explicitly used by async tests that need cleanup,
    not applied automatically to all tests.
    """
    import sys

    yield

    # Only cleanup if we're in an async context with a running loop
    try:
        loop = asyncio.get_running_loop()
    except RuntimeError:
        # No running loop, nothing to clean up
        return

    # Get all tasks in the current loop
    if sys.version_info >= (3, 9):
        # Use current_task() to exclude the cleanup task itself
        current = asyncio.current_task(loop)
        tasks = [
            task
            for task in asyncio.all_tasks(loop)
            if task != current and not task.done()
        ]
    else:
        # Fallback for older Python versions
        try:
            current = (
                asyncio.current_task()
                if hasattr(asyncio, "current_task")
                else asyncio.Task.current_task()
            )
            tasks = [
                task
                for task in asyncio.all_tasks(loop)
                if task != current and not task.done()
            ]
        except RuntimeError:
            return

    # Cancel and cleanup tasks, specifically looking for RichLogProcessor
    for task in tasks:
        # Special handling for RichLogProcessor tasks
        if task.get_name() == "RichLogProcessor":
            task.cancel()
            try:
                loop.run_until_complete(task)
            except (asyncio.CancelledError, RuntimeError):
                pass
        else:
            task.cancel()

    # Don't wait for cancellation as it might cause issues
    # The event loop will handle cleanup when it shuts down


@pytest.fixture(scope="function")
def event_loop():
    """Create an instance of the default event loop for each test case.

    This fixture is recognized by pytest-asyncio and helps ensure
    each async test gets a fresh event loop.
    """
    loop = asyncio.new_event_loop()
    yield loop
    # Cleanup
    try:
        _cancel_all_tasks(loop)
        loop.run_until_complete(loop.shutdown_asyncgens())
        loop.close()
    except RuntimeError:
        pass


def _cancel_all_tasks(loop):
    """Cancel all tasks in the given event loop."""
    import sys

    # Get all tasks for this loop - API changed in Python 3.9
    if sys.version_info >= (3, 9):
        tasks = [task for task in asyncio.all_tasks(loop) if not task.done()]
    else:
        # For Python < 3.9
        tasks = [task for task in asyncio.Task.all_tasks(loop) if not task.done()]

    if not tasks:
        return

    for task in tasks:
        # Special handling for RichLogProcessor to ensure clean shutdown
        if hasattr(task, "get_name") and task.get_name() == "RichLogProcessor":
            task.cancel()
            try:
                loop.run_until_complete(task)
            except (asyncio.CancelledError, RuntimeError):
                pass
        else:
            task.cancel()

    # Give tasks a chance to cleanup
    try:
        loop.run_until_complete(asyncio.gather(*tasks, return_exceptions=True))
    except RuntimeError:
        # Loop might be closed
        pass


@pytest.fixture
def clean_environment():
    """Provide a clean environment and restore it after test."""
    original_env = os.environ.copy()
    yield os.environ
    os.environ.clear()
    os.environ.update(original_env)


# ========== Test Markers ==========


def pytest_configure(config):
    """Register custom test markers."""
    config.addinivalue_line(
        "markers", "unit: Unit tests that don't require external resources"
    )
    config.addinivalue_line(
        "markers", "integration: Integration tests that may use files/network"
    )
    config.addinivalue_line("markers", "slow: Tests that take more than 1 second")
    config.addinivalue_line(
        "markers",
        "bootstrap_profile: keep the collection-time profile instead of the per-test sandbox (config-participant admission)",
    )
    config.addinivalue_line(
        "markers", "requires_cleanup: Tests that need special cleanup"
    )
    config.addinivalue_line("markers", "asyncio: Async tests using asyncio")
    # Off unless TLDW_AUDIT_UNCALLED_DOUBLES names a report file (task-15270).
    from Tests.fixtures import required_doubles

    required_doubles.install_uncalled_double_audit()


@pytest.hookimpl(trylast=True)
def pytest_sessionfinish(session, exitstatus):
    """Fail the run on unclaimed real-profile refusals; remove an owned sandbox.

    The sandboxed environment (HOME, USERPROFILE, XDG_*, TLDW_CONFIG_PATH and
    the rest of ``_SANDBOXED_ENV_NAMES``) is deliberately NOT restored here
    (TASK-33665). The process keeps running after this hook: atexit handlers,
    ``pytest_unconfigure`` and threads the tests left behind still write. A
    restore points them at the caller's real profile. The writer from the
    2026-10-02 incident (ChatScreen's ``ui_state.toml``) opens its temporary
    with ``os.open(name, dir_fd=…)``, which the audit guard cannot place, so
    only the environment keeps such writers out. Left alone, they write into
    the dead sandbox instead. Nothing needs the restore: the process is about to
    exit, ``_PREVIOUS_TEST_ENV`` stays readable for code that needs the
    caller's values, and an in-process second ``pytest.main`` reuses this
    cached module, so it also stays in the sandbox. An xdist worker owns no
    sandbox and skips the cleanup.
    """
    _real_profile_guard.session_end_check(session)
    if _OWNS_BOOTSTRAP_CONFIG_ROOT and not _XDIST_WORKER:
        shutil.rmtree(_BOOTSTRAP_CONFIG_ROOT, ignore_errors=True)


@pytest.hookimpl(optionalhook=True)
def pytest_testnodedown(node, error):
    """Collect an xdist worker's session-end refusals on the controller."""
    _real_profile_guard.collect_worker_refusals(node)


# ========== Async Support ==========


@pytest.fixture
def anyio_backend():
    """Backend for anyio async tests."""
    return "asyncio"


# ========== Test Environment Isolation ==========


def _close_database_instance(db_instance):
    """Close every registered handle for a database cached by test config.

    ChaChaNotesDB owns thread-local connections created by Textual workers, so
    closing only the fixture teardown thread's handle leaves those worker-owned
    SQLite descriptors open. Its quiescence boundary drains and closes the full
    same-file registry; simpler database doubles keep the legacy ``close`` path.
    """
    quiesce_connections = getattr(db_instance, "quiesce_connections", None)
    if callable(quiesce_connections):
        try:
            with quiesce_connections(timeout_seconds=2.0):
                pass
            return
        except (RuntimeError, TimeoutError) as exc:
            logger.warning(
                "Failed to quiesce cached test database: "
                f"exception_type={type(exc).__name__}"
            )
    close_db = getattr(db_instance, "close", None)
    if not callable(close_db):
        return
    try:
        close_db()
    except Exception as exc:
        logger.warning(f"Failed to close cached test database: {exc}")


def _reset_config_database_instances(config_module):
    """Close and clear config.py's lazy database singletons."""
    for db_name in ("chachanotes_db", "prompts_db", "media_db"):
        _close_database_instance(getattr(config_module, db_name, None))
        setattr(config_module, db_name, None)


def _shutdown_prompts_interop_if_loaded():
    """Reset the prompt singleton without importing its module into every test."""
    prompts_interop = sys.modules.get("tldw_chatbook.Prompt_Management.Prompts_Interop")
    if prompts_interop is not None and prompts_interop.is_initialized():
        prompts_interop.shutdown_interop()


@pytest.fixture(autouse=True)
def refuse_real_profile_writes():
    """Fail a test whose code tried to write the real tldw profile (TASK-33665).

    The guard raises at the write, but production code often catches broad
    exceptions; the recorded refusal still fails the test here.
    """
    yield
    violations = _real_profile_guard.take_violations()
    if violations:
        pytest.fail(
            "Wrote to the real tldw profile (a refusal may come from an "
            "earlier test's late thread):\n" + "\n".join(violations),
            pytrace=False,
        )


@pytest.fixture(autouse=True)
def isolate_test_environment(monkeypatch, tmp_path, request):
    """Automatically isolate test environment to prevent production data access.

    This fixture:
    - Sets TLDW_TEST_MODE environment variable
    - Redirects all data directories to a temporary location
    - Prevents database initialization during import
    """
    # Set test mode
    monkeypatch.setenv("TLDW_TEST_MODE", "1")

    from Tests.private_profile import is_private_profile_child

    # Source-bound consumers retain the private profile selected at collection.
    # These MCP widget modules also use imported real config getters; their
    # per-case config fakes and database cleanup remain in the existing fixtures.
    # The hosted-chat/QwenCloud transport contract tests (TASK-19642.10) are in
    # the same class: owned_json_post/qwencloud build real sessions through
    # create_default_session(), whose default-timeout and TLS-trust reads go
    # through the config-participant admission (TASK-32628). Under the per-test
    # env redirect the bound config selection no longer matches and admission
    # fails closed with RecoveryRequired("raw_source_selection_changed"), so
    # 20 transport contract nodes went red the day that admission landed. They
    # fake the transport itself, not the config getters, so they keep the
    # bootstrap profile like the MCP widgets do. The summarization suites
    # (TASK-32853) are the same class: every summarize_with_* handler reads
    # provider settings through get_cli_setting on its hot path, and their
    # broad excepts turn the admission failure into an error STRING, so the
    # 119 pre-existing reds (91 diagnostic-privacy + 28 model-capabilities,
    # failing since TASK-32628 landed) are this exact signature swallowed.
    keep_bootstrap_profile = (
        is_private_profile_child(request)
        # TASK-33370/33373: these families exercise real source-bound config
        # consumers. Their databases remain tmp_path-owned and are closed by
        # their fixtures; redirecting the already imported config blinds the
        # DB/migration assertions, UI setup and benchmark Console controller.
        or request.node.path.parent.name in {"DB", "ChaChaNotesDB"}
        or (
            request.node.path.parent == Path(__file__).parent
            and request.node.path.name.startswith("test_config_")
        )
        or request.node.path.name
        in {
            "test_environment_isolation.py",
            "test_personas_lore.py",
            "test_rag_citation_provenance_benchmark.py",
        }
        # TASK-32873: per-NODE opt-in for suites that are MOSTLY sandbox
        # unit tests but contain real-app mounts (the runtime-ownership
        # suite): mark only the mounting tests.
        or request.node.get_closest_marker("bootstrap_profile") is not None
        # PR3045 qualification: these mounted harnesses import the real guarded
        # config readers (Personas' AppFooterStatus and Library's app_factory).
        # Three exact representative nodes fail on dev and the PR when the
        # per-test redirect changes their collection-bound config selection.
        # Retain that private bootstrap source, as traversal_t22207 does below.
        # The legacy-human cases explicitly reselect config in their fixture;
        # keep their distinct per-case isolation rather than sharing its writes.
        or (
            request.node.path.name
            in {"test_personas_workbench.py", "test_library_media_reader_flow.py"}
            and "legacy_human_config" not in request.fixturenames
        )
        or request.node.path.name
        in {
            "test_mcp_workbench.py",
            "test_mcp_tools_mode.py",
            "test_mcp_servers_mode.py",
            "test_hosted_chat.py",
            "test_qwencloud.py",
            "test_groq_openrouter_migration_characterization.py",


            # The sentinel redaction tests drive the real OpenAI adapter into
            # its ConnectionError branch; the adapter's session construction
            # goes through create_default_session -> get_config_value on the
            # guarded config loader (same admission signature as
            # test_hosted_chat.py above). They fake load_settings, not the
            # config getters, so they keep the bootstrap profile.
            "test_sensitive_llm_logging.py",


            # The mocked local-service connection test drives chat_api_call
            # for koboldcpp, whose handler reads settings through the guarded
            # config loader under the per-test redirect (same admission
            # signature as test_hosted_chat.py above).
            "test_chat_unit_mocked_APIs.py",


            # The catalog client-factory tests build real httpx clients
            # through the TLS-trust factory, whose trust/timeout reads go
            # through the guarded config loader under the per-test redirect
            # (same admission signature as test_hosted_chat.py above).
            "test_openai_compatible_model_discovery.py",
            "test_server_llm_provider_catalog_service.py",
            "test_summarization_diagnostic_privacy.py",
            "test_summarization_model_capabilities.py",


            # TASK-32853/32854: the analyze boundary and the local config
            # suites read provider settings through get_cli_setting on their
            # hot paths (same admission signature as the two above).
            "test_summarization_analyze.py",
            "test_llama_summarizer_config.py",
            "test_kobold_tabby_config.py",
            "test_custom_openai_credential_resolution.py",
            "test_summarization_request_timeouts.py",


            # TASK-32864: the Console/Library modal dismissal inventories
            # import every modal module under Widgets/Console and
            # UI/Library_Modules (real config participants on their import
            # path); same admission signature as the suites above.
            "test_console_modal_dismissal.py",
            "test_library_modal_dismissal.py",


            # TASK-32856 follow-up trial: media-generation suites import the
            # real app (config participants on the import path); same
            # admission signature as the suites above.
            "test_adapter_registry.py",
            "test_comfyui_image_adapter.py",
            "test_request_validation.py",
            "test_fal_adapter.py",
            "test_gemini_adapter.py",
            "test_loose_voice_finite_operations.py",
            "test_http_client.py",
            "test_worker.py",
            "test_video_store.py",
            "test_swarmui_adapter.py",
            "test_openrouter_adapter.py",
            "test_image_format_utils.py",
            "test_comfyui_adapter.py",
            "test_modelstudio_adapter.py",
            "test_together_adapter.py",
            "test_novita_adapter.py",
            "test_config_projection.py",
            "test_comfyui_workflow_distribution.py",


            # TASK-32873: the runtime-ownership and viewless suites mount
            # real apps end to end; same config-participant admission
            # signature as above. (The few pure-unit tests inside the
            # ownership suite were fixed to be profile-agnostic.)
            "test_console_runtime_ownership.py",
            "test_console_viewless_hooks.py",


            # TASK-32873: same signature, discovered while re-verifying --
            # install_skill dispatch drives scripted agent runs whose config
            # reads go through the config-participant admission.
            "test_install_skill_runtime_tool.py",
            "test_console_chat_create_integration.py",


            # ADR-179 Task 4: the engine resolution suite drives
            # resolve_hosted_request without app_config on its preset-rule
            # cases, which reads get_runtime_config_snapshot on the guarded
            # config loader (same admission signature as test_hosted_chat.py
            # above).
            "test_hosted_provider_engine_resolution.py",


            # ADR-179 Task 11: three pre-existing red suites with the same
            # admission signature -- the Kimi/Z.ai native-tool suite drives
            # the real hosted handlers (owned_json_post session construction
            # reads the guarded config loader), and the two console
            # continuation suites drive the real Console controller submit
            # path whose config reads go through the same admission. None of
            # them re-selects a config itself, so they keep the bootstrap
            # profile like the hosted-chat class above.
            "test_kimi_zai_native_tools.py",
            "test_console_continuation_review_fixes.py",
            "test_console_trace_transform_continuations.py",

            # TASK-19642.7 (ADR-179 class): the QwenCloud native-tool suite
            # and the Kimi/Z.ai provider-contract suite drive the same real
            # hosted handlers (owned_json_post session construction and the
            # streaming adapter read the guarded config loader); same
            # admission signature and same no-config-re-selection check as
            # test_kimi_zai_native_tools.py above.
            "test_qwencloud_native_tools.py",
            "test_kimi_zai_provider_contract.py",

            # TASK-19642.8.1/.8.5/.8.7/.8.8: the attachment save-toast,
            # diff-feedback delivery, provider-failure copy, and
            # stop-reliability suites drive the real Console controller /
            # image-command paths whose hot reads (hook-consent send gate,
            # user-templates dir via get_user_data_dir) go through the
            # guarded config loader -- the exact RecoveryRequired("raw_
            # source_selection_changed") signature TASK-19425 documented
            # for the local-citation suite. None re-selects a config.
            "test_console_attachment_riders.py",
            "test_console_diff_feedback_delivery.py",
            "test_console_provider_failure_copy.py",
            "test_console_stop_reliability.py",

            # TASK-19642.16: the MCP watchlists provider suites resolve the
            # real watchlists database through the guarded config/data-dir
            # readers; same admission signature as the MCP widget class
            # above. Neither file re-selects a config.
            "test_gateway_runtime_tools.py",
            "test_local_server_tools.py",

            # TASK-19642.18: the deferred startup reconciliation/migration
            # policy suites mount the real deferred-startup machinery whose
            # policy reads go through the guarded config loader; same
            # admission signature as the suites above, no config
            # re-selection in the file.
            "test_app_startup_performance.py",

            # TASK-19642.25: the websearch prompt-parity suite renders
            # through the internal-prompt resolver, whose override lookup
            # reads get_cli_setting on the guarded config loader; same
            # admission signature, no config re-selection.
            "test_websearch_prompt_parity.py",

            # TASK-19642.27: the project-skills import-modal suite drives
            # maybe_offer_project_skills_import, whose kill-switch/ledger
            # reads go through the guarded config loader; a predecessor
            # test's sandbox pins the selection and every later offer call
            # fails closed. Same admission signature, no config
            # re-selection (the ledger tests only redirect the module's
            # get_user_data_dir to tmp_path).
            "test_project_skills_import_modal.py",


            # TASK-592/609 (egress hardening arc): the three SSRF/egress
            # regression suites -- every guarded_fetch_* helper and
            # create_default_session reads get_cli_setting through the
            # guarded config loader (check_url_or_raise -> _config_enabled,
            # default_session_timeout, and GitHubAPIClient.__init__), so all
            # three files went red with RecoveryRequired("raw_source_
            # selection_changed") when TASK-32628's admission landed. None of
            # them re-selects a config itself (verified: no config.toml
            # writes, no load_cli_config calls); they pin redirect-credential
            # and host-classification policy and are not in the PR fast lane,
            # so the reds had gone unnoticed. The same signature and the same
            # "no config re-selection" check hold for the four caller suites
            # below (crawler sitemap, GitHub client, download caps wiring,
            # settings probe), enrolled for the same reason.
            "test_egress.py",
            "test_egress_cross_origin_header_allowlist.py",
            "test_skill_remote_fetch.py",
            "test_sitemap_crawl_trusted_origins.py",
            "test_github_api_client.py",
            "test_download_caps_wiring.py",
            "test_settings_probe_egress.py",


            # TASK-21233: the subscriptions FTS-backfill collision canary
            # drives the real SubscriptionsDB from a worker thread; the
            # thread-local connection created there resolves config through
            # the guarded loader, and under the per-test env redirect the
            # bound config selection no longer matches (same admission
            # signature as test_hosted_chat.py above). The file's other
            # tests are tmp_path DB-level tests that do not depend on the
            # redirect.
            "test_fts_backfill.py",


            # TASK-22302: the real-stack citation persistence suite drives the
            # real Console controller submit path, whose hook-consent admission
            # (`_hook_admission_reason` -> `read_hooks_config_snapshot`) reads
            # the guarded config loader. Under the per-test redirect that read
            # fails closed with RecoveryRequired("raw_source_selection_changed")
            # and the gate's broad except turns it into a send refusal
            # ("Hooks unavailable"), so the durable turn never starts and the
            # six-table assertions never run -- the same admission signature as
            # the two console continuation suites above, red since the
            # hook-consent gate landed (aed1b13501).
            "test_console_terminal_citation_persistence.py",


            # TASK-19425: the Console hook-consent send gate (aed1b13501)
            # reads the saved [hooks] section through the guarded config
            # loader on EVERY controller submit_draft/queue_prompt. Under
            # the per-test redirect that read raises RecoveryRequired
            # ("raw_source_selection_changed"), the gate's fail-closed
            # except denies the send ("Hooks unavailable; review or
            # disable hooks before sending."), and this suite's
            # controlled-gateway tests wait forever for provider events
            # that never arrive -- 87 reds, 17 of them pinned at the full
            # --timeout cap per run (the 300s hang class this task
            # measures). Same admission signature as the continuation
            # suites above; the suite never re-selects a config itself.
            "test_console_local_citation_boundary.py",


            # TASK-19642.19.2: the reranker system-prompt contract suite
            # constructs a real PointwiseReranker, whose __init__ resolves
            # the registry default through get_internal_prompt ->
            # get_cli_setting on the guarded config loader (same admission
            # signature as test_hosted_chat.py above). The file's fixture
            # fakes load_settings, not the config getters, so it keeps the
            # bootstrap profile.
            "test_reranker_system_prompt.py",

            # TASK-19642.21.1: the ported v2-chunker suite constructs the real
            # engine Chunker, whose ChunkerConfig reads chatbook's [Chunking]
            # TOML through the _shims/config.py guarded config loader under
            # the per-test redirect (same admission signature as
            # test_hosted_chat.py above). It never re-selects a config
            # itself, so it keeps the bootstrap profile.
            "test_chunker_v2.py",

            # TASK-19642.21.2: the golden-parity suite builds the same real
            # Chunker per corpus×method node; identical admission signature
            # and rationale as test_chunker_v2.py above.
            "test_golden_parity.py",

            # The token-fallback offsets property suite constructs the real
            # engine Chunker per max_size×overlap node, and the Chunk_Lib shim
            # contract suite drives improved_chunking_process/Chunker, whose
            # ChunkerConfig reads chatbook's [Chunking] TOML through the
            # _shims/config.py guarded config loader under the per-test
            # redirect (same admission signature as test_chunker_v2.py above:
            # RecoveryRequired("raw_source_selection_changed") before any
            # assertion runs). Neither suite re-selects a config itself, so
            # they keep the bootstrap profile.
            "test_tokens_fallback_offsets.py",
            "test_chunk_lib_shim.py",

            # TASK-19642.11: the managed model-artifact transfer suites drive
            # the real fetch hot path against loopback fixture servers
            # (stream_fetch -> check_url_or_raise_async -> egress
            # ._config_enabled -> get_cli_setting on the guarded config
            # loader); same admission signature as the hosted-chat class
            # above. They fake the HTTP transport, not the config getters,
            # so they keep the bootstrap profile.
            "test_stream_fetch.py",
            "test_provision_fetch.py",
            "test_source_map.py",
            "test_credentials_and_boundaries.py",

            # TASK-19642.12: the preflight/install/crash-recovery suites
            # drive the same real acquisition hot path (preflight probe and
            # install/finalize fetches reach egress._config_enabled ->
            # get_cli_setting on the guarded config loader); same admission
            # signature as the class above. They fake the HTTP transport,
            # not the config getters, so they keep the bootstrap profile.
            "test_preflight.py",
            "test_provision_install.py",
            "test_provision_crash_recovery.py",
            # TASK-32171: the Library media-reader traversal suite mounts
            # real production-CSS apps through _flow_app -> _build_test_app ->
            # load_settings on the guarded config loader, so the per-test env
            # redirect fails the config-participant admission closed with the
            # same RecoveryRequired signature as the suites above (observed
            # masking the whole file standalone at dev tip 2612fc56b2). None of
            # its cases re-selects a config itself and none writes durable
            # reader preferences, so the shared bootstrap profile is safe.
            # (The adaptive-reader closeout suite hits the same admission but
            # DOES write durable per-destination reader preferences its later
            # cases must not see; it uses @private_profile_test instead.)
            "test_library_media_reader_traversal_t22207.py",
            # TASK-21234: the fleet teardown notice suite builds real apps
            # through _build_test_app for its direct-seam staging and its
            # full-app superseded-navigation case; same admission signature
            # and same class as the console integration suites above.
            "test_fleet_teardown_notice.py",
            # TASK-19566 F9: the chatbook thinking round-trip suite drives the
            # real importer (which constructs CharactersRAGDB); under the
            # per-test env redirect the guarded config loader fails closed
            # with RecoveryRequired("raw_source_selection_changed") before any
            # assertion runs -- same admission signature as the suites above.
            "test_chatbook_thinking_round_trip.py",

            # TASK-33370 (2026-10-10, EXPERIMENT): the Library file-notes and
            # wave-4 Notes batteries -- every suite that mounts the production
            # TldwCli/LibraryScreen through _build_test_app -> load_settings,
            # or mounts LibraryFileNotesWorkspace whose empty-state surface
            # reads get_cli_setting("file_notes", ...) on the guarded loader.
            # All were authored before the ADR-126 config-participant
            # admission landed (b5251e9a6e, 2026-09-16) and none is in any
            # CI lane (test.yml has not run on dev since 2026-09-06; the
            # ui-fast-lane census excludes them), so ~123 nodes went red in
            # plain worktree runs unnoticed. Same admission signature as the
            # suites above.
            "test_library_file_notes_workspace.py",
            "test_library_file_notes_git.py",
            "test_library_file_notes_git_push.py",
            "test_library_notes_w4_file_notes.py",
            "test_library_notes_w4_sync_roots.py",
            "test_library_notes_w4_console_handoff.py",
            "test_library_notes_w4_data_truth.py",
            "test_library_notes_w4_editor.py",
            "test_library_notes_w4_import_keyboard.py",
            "test_library_notes_w4_layout.py",
            "test_library_notes_riders_r_file_notes.py",
            "test_library_notes_wave_file_notes.py",

            # task-34387 review: the provider call-defect and mocked-API
            # suites fake the transport (requests.Session.post / the session
            # factories), but the real handler prelude around those fakes
            # builds sessions via create_owned_default_session/
            # create_pooled_default_session, whose timeout/TLS reads go
            # through the guarded config loader under the per-test redirect
            # (same admission signature as test_hosted_chat.py above:
            # RecoveryRequired("raw_source_selection_changed") before any
            # assertion runs). None of the three re-selects a config itself,
            # so they keep the bootstrap profile.
            "test_anthropic_caching_degrade.py",
            "test_chat_mocked_apis.py",
            "test_provider_call_defects.py",
            # TASK-2760..2765 (Home dashboard cluster, 2026-10-11): the
            # three Home suites that mount the production app through
            # _build_test_app -> load_settings hit the same ADR-126
            # admission signature as the TASK-33370 Library batteries above
            # -- every node in them fails fixture setup with
            # RecoveryRequired("raw_source_selection_changed") in a plain
            # worktree run against origin/dev (69 reds observed at
            # 9f8533686c; pure-state suites like Tests/Home/ and the
            # non-mounting UI Home files stay green). None of them
            # re-selects a config itself, so they keep the bootstrap
            # profile like the suites above.
            "test_home_screen.py",
            "test_home_triage_rail.py",
            "test_home_dashboard_seams.py",
            # TASK-34991 (2026-10-14): the layout-cost A/B suite hit the same
            # admission signature -- its `_disable_model_catalog_refresh`
            # fixture (Tests/UI/conftest.py) monkeypatches
            # `tldw_chatbook.app.TldwCli`, which imports the app AFTER the
            # per-test redirect, and every node in the file errored in setup
            # with RecoveryRequired("raw_source_selection_changed") on a
            # clean tree. The suite never re-selects a config itself, and its
            # mounts DO read config (SplashScreen reads [splash_screen]), so
            # rebinding the module (install_config_source) breaks the splash
            # mounts instead -- keeping the bootstrap profile is the fit, as
            # for the Home cluster above.
            "test_timer_path_layout_cost.py",
        }
    )
    test_data_dir = (
        _BOOTSTRAP_CONFIG_ROOT if keep_bootstrap_profile else tmp_path / "test_data"
    )
    test_data_dir.mkdir(exist_ok=True)

    # Common paths that need isolation
    monkeypatch.setenv(
        "XDG_DATA_HOME",
        str(_BOOTSTRAP_DATA_HOME if keep_bootstrap_profile else test_data_dir),
    )
    test_config_dir = test_data_dir / "config"
    test_config_dir.mkdir(parents=True, mode=0o700, exist_ok=True)
    monkeypatch.setenv("XDG_CONFIG_HOME", str(test_config_dir))
    test_home_dir = test_data_dir / "home"
    test_home_dir.mkdir(mode=0o700, exist_ok=keep_bootstrap_profile)
    monkeypatch.setenv("HOME", str(test_home_dir))
    monkeypatch.setenv(
        "TLDW_CONFIG_PATH",
        str(test_config_dir / "config.toml"),
    )

    # Clear lazy database and prompt singletons before each test so no
    # connection survives after its per-test temporary directory is removed.
    # ``get_user_data_dir`` resolves HOME at call time, so the environment
    # patches above are the path-isolation authority.
    try:
        from tldw_chatbook import config

        _reset_config_database_instances(config)
        _shutdown_prompts_interop_if_loaded()
    except ImportError:
        config = None

    # NOTE (task-519): this used to also try to
    # `monkeypatch.setattr(config, "get_data_dir", ...)`, but `config` has no
    # `get_data_dir` attribute -- that patch was a silent no-op. It's removed
    # rather than fixed because it's no longer needed: `get_user_data_dir()`'s
    # default-dir fallback now resolves HOME/XDG_DATA_HOME at CALL time (see
    # `config._default_base_data_dir`), so the HOME/XDG_DATA_HOME env patches
    # above are sufficient on their own.

    # Pre-arm SP2b's first-run-import once-flag so the RAG ingestion module's
    # real (no-longer-pytest-gated, see task-519) first-run wiring never fires
    # organically inside an unrelated test and creates a real
    # "imported_settings" RAG profile under the (now-isolated, but still
    # real-filesystem) data dir. Tests that specifically want to exercise
    # `_maybe_run_first_run_import` reset this flag themselves (see
    # `Tests/RAG/test_first_run_import.py`).
    #
    # This must NOT `import tldw_chatbook.RAG_Search.ingestion_indexing` itself
    # (review finding on task-519/PR #845): that would drag the RAG stack into
    # every single test in the suite, autouse, even ones that never touch RAG.
    # Instead only arm the flag if the module is ALREADY in sys.modules (i.e.
    # some earlier-collected test already imported it) -- the first-run wiring
    # lives INSIDE that module, so if it isn't imported it cannot fire. If a
    # test imports it later in its own body, task-519's call-time HOME
    # resolution already isolates any first-run write under the HOME/
    # XDG_DATA_HOME patched above, so this pre-arm is belt-and-braces for
    # modules that happen to already be loaded, not a correctness requirement.
    ii = sys.modules.get("tldw_chatbook.RAG_Search.ingestion_indexing")
    if ii is not None:
        monkeypatch.setattr(ii, "_first_run_import_attempted", True, raising=False)

    # Pre-expand the Watchlists workbench's right rail (the Inspector) for
    # screen-level tests. task-2513 (reader-first Phase 1) changed the
    # first-run default so a genuinely new user's RIGHT_RAIL starts collapsed
    # (`region_layout_store._FIRST_RUN_DEFAULT`), and every watchlists screen
    # test written before that change mounts the screen with the per-test
    # sandbox's empty config -- i.e. as a "genuinely new user" -- while
    # asserting against panes (above all `#watchlists-entity-inspector`) that
    # a collapsed rail leaves unmounted. Those tests exercise inspector/tree/
    # pane behaviour, not the layout default, so the screen's loader symbol
    # is patched back to the old all-expanded default here. Same sys.modules
    # guard as the RAG flag above: the patch only applies when some
    # already-collected test imported the screen module, so this never drags
    # the screen stack into an unrelated run. Tests that DO care about the
    # loader monkeypatch this same symbol themselves (e.g.
    # test_persisted_layout_is_applied_on_mount, which overrides this patch),
    # and the default itself is pinned at the store level by
    # Tests/Watchlists/test_region_layout_store.py.
    wcs = sys.modules.get("tldw_chatbook.UI.Screens.watchlists_collections_screen")
    if wcs is not None:
        monkeypatch.setattr(wcs, "load_region_layout", lambda: wcs.RegionLayout())

    yield test_data_dir

    if getattr(request.node, "_test_app_native_workers_uncertain", False):
        raise RuntimeError(
            "Native app workers remain uncertain; config retirement refused"
        )
    if config is not None:
        _shutdown_prompts_interop_if_loaded()
        _reset_config_database_instances(config)


# ========== Test Data Fixtures ==========


@pytest.fixture
def sample_text_content():
    """Provide sample text content for testing."""
    return """
    This is a sample text for testing purposes.
    It contains multiple lines and paragraphs.
    
    This is the second paragraph with some **markdown** formatting.
    It also includes [links](http://example.com) and other elements.
    """


@pytest.fixture
def sample_json_data():
    """Provide sample JSON data for testing."""
    return {
        "title": "Test Document",
        "content": "Test content",
        "metadata": {
            "author": "Test Author",
            "date": "2025-01-01",
            "tags": ["test", "sample"],
        },
    }


# ========== App Cleanup Fixtures ==========


@pytest_asyncio.fixture
async def app_with_cleanup():
    """Create a TldwCli app instance with proper cleanup.

    This fixture ensures the RichLogHandler is properly stopped
    before the event loop closes, preventing the "Task was destroyed
    but it is pending!" error.
    """
    from tldw_chatbook.app import TldwCli

    app = TldwCli()

    yield app

    # Ensure proper cleanup
    try:
        # Stop RichLogHandler if it exists
        if hasattr(app, "_rich_log_handler") and app._rich_log_handler:
            await app._rich_log_handler.stop_processor()
            # Note: RichLogHandler still uses standard logging for Textual integration
            import logging

            logging.getLogger().removeHandler(app._rich_log_handler)
            app._rich_log_handler.close()

        # Call shutdown methods
        if hasattr(app, "on_shutdown_request"):
            await app.on_shutdown_request()

        if hasattr(app, "on_unmount"):
            await app.on_unmount()

    except Exception as e:
        # Log but don't fail the test
        logger.debug(f"Error during app cleanup: {e}")


# ========== Performance and Timing Fixtures ==========


@pytest.fixture
def benchmark_timer():
    """Simple timer for performance testing."""
    import time

    class Timer:
        def __init__(self):
            self.start_time = None
            self.elapsed = None

        def __enter__(self):
            self.start_time = time.time()
            return self

        def __exit__(self, *args):
            self.elapsed = time.time() - self.start_time

    return Timer


# ========== Skill Trust Service Fixtures ==========
#
# Promoted from ``Tests/Skills/conftest.py`` (task-7 of the skills-script-
# execution SDD plan): ``Tests/Library/test_skill_script_grant_panel.py``
# needs ``trust_service_with_skill`` too, and pytest fixture discovery only
# walks a test file's own directory and its ANCESTORS -- a sibling
# directory's ``conftest.py`` is never visible. Living here instead of being
# duplicated means both ``Tests/Skills/`` and ``Tests/Library/`` share the
# exact same fixture (and its future edits), rather than two copies quietly
# drifting apart.


@pytest.fixture
def make_trust_service(tmp_path):
    """Return a factory that builds `SkillTrustService` instances sharing one store.

    Args:
        tmp_path: Pytest-provided temporary directory fixture.

    Returns:
        A zero-argument callable that constructs a new `SkillTrustService`
        bound to the same on-disk `skills_dir`/`trust_dir`, so repeated calls
        simulate a fresh process re-reading persisted state.
    """
    from tldw_chatbook.Skills_Interop.local_skills_service import LocalSkillsService
    from tldw_chatbook.Skills_Interop.skill_trust_service import SkillTrustService
    from tldw_chatbook.Skills_Interop.skill_trust_store import (
        FileSkillTrustGenerationMarkerStore,
        SkillTrustStore,
        default_trust_store_dir,
    )

    # Derived from the real accessors/objects rather than re-spelled
    # "skills"/"trust" literals (TASK-866): `LocalSkillsService` computes
    # its own `skills_dir` from `_SKILLS_DIRNAME`, and
    # `default_trust_store_dir()` is the same function `app.py` calls to
    # build the live `SkillTrustStore`. If either constant's name ever
    # changed, a hardcoded literal here would silently keep matching
    # nothing -- the exact class of drift this task closes.
    skills_dir = LocalSkillsService(store_dir=tmp_path).skills_dir
    trust_dir = default_trust_store_dir(tmp_path)
    skills_dir.mkdir(exist_ok=True, parents=True)
    trust_dir.mkdir(exist_ok=True, parents=True)

    def _make() -> "SkillTrustService":
        marker_path = trust_dir / "marker.json"
        return SkillTrustService(
            skills_dir=skills_dir,
            trust_store=SkillTrustStore(
                store_dir=trust_dir,
                marker_store=FileSkillTrustGenerationMarkerStore(
                    marker_path, store_dir=marker_path.parent
                ),
            ),
        )

    return _make


@pytest.fixture
def trust_service_with_skill(make_trust_service):
    """Return a `SkillTrustService` with one on-disk demo skill (with a script).

    Args:
        make_trust_service: Factory fixture for building trust-service instances.

    Returns:
        A `(service, skill_name)` tuple where `skill_name` names a skill
        directory containing a `SKILL.md` and a `scripts/hello.py`.
    """
    service = make_trust_service()
    name = "demo-skill"
    skill_dir = service.skills_dir / name
    (skill_dir / "scripts").mkdir(parents=True)
    (skill_dir / "SKILL.md").write_text(
        "---\nname: demo-skill\ndescription: demo\n---\nbody\n", encoding="utf-8"
    )
    (skill_dir / "scripts" / "hello.py").write_text("print('hello')", encoding="utf-8")
    return service, name


# ========== Pytest Configuration ==========


def pytest_addoption(parser):
    """Add custom command line options."""
    parser.addoption(
        "--run-slow", action="store_true", default=False, help="Run slow tests"
    )
    parser.addoption(
        "--run-optional",
        action="store_true",
        default=False,
        help="Run tests requiring optional dependencies",
    )
    parser.addoption(
        "--run-live",
        action="store_true",
        default=False,
        help="Run tests that call real paid external APIs (requires key files + TLDW_LIVE_SEARCH_TESTS=1)",
    )


def pytest_collection_modifyitems(config, items):
    """Modify test collection based on markers and options."""
    if not config.getoption("--run-slow"):
        skip_slow = pytest.mark.skip(reason="Need --run-slow option to run")
        for item in items:
            if "slow" in item.keywords:
                item.add_marker(skip_slow)

    if not config.getoption("--run-optional"):
        # The marker actually used by the suite is `optional` (registered in
        # pyproject); the old gate keyed on `optional_deps`, which no test has
        # ever carried, so it selected nothing (task-1457).
        skip_optional = pytest.mark.skip(reason="Need --run-optional option to run")
        for item in items:
            if "optional" in item.keywords:
                item.add_marker(skip_optional)

    if not config.getoption("--run-live"):
        skip_live = pytest.mark.skip(reason="Need --run-live option to run")
        for item in items:
            if "live" in item.keywords:
                item.add_marker(skip_live)


@pytest.fixture(autouse=True)
def _fleet_chat_scripts_fully_consumed():
    """Fail any test that mis-scripted a `FleetChat` (PR2a Task 6.5 review).

    `Tests/Agents/test_agent_service.FleetChat` addresses provider replies
    per agent, and is the load-bearing harness for every suite that spawns
    a sub-agent. Two of its failure modes are otherwise SILENT:

    * a fault raised on a CHILD's thread is swallowed by `AgentService`'s
      `run_child` (BaseException by design) into `status=error`, so a test
      that does not assert the child's own result still passes;
    * a scripted turn nobody ever asks for -- e.g. after a task-text
      rename leaves the key stale -- simply goes unused, and the test
      passes while exercising nothing it claims to.

    Autouse and repo-wide on purpose: this must not be something a future
    test can forget to opt into. It is a no-op (one empty list check) for
    the thousands of tests that never touch `FleetChat`, and it never
    imports it -- the class registers its own instances.
    """
    # Looked up through sys.modules rather than imported: a test that
    # never pulled the harness in must not pay to import the whole agent
    # stack, nor gain its import side effects. No module -> nothing to check.
    module = sys.modules.get("Tests.Agents.test_agent_service")
    fleet_chat = getattr(module, "FleetChat", None) if module else None
    if fleet_chat is None:
        yield
        return

    fleet_chat._live_instances.clear()
    yield
    instances = list(fleet_chat._live_instances)
    fleet_chat._live_instances.clear()
    # PR3a-1 Task 2: a sub-agent now outlives the turn that spawned it by
    # default, so a child can still be on its way to its FIRST scripted
    # reply when the test body ends -- "unused turn" and "not used YET"
    # look identical at this instant. Wait for the difference rather than
    # guessing at it: a script that is merely late is consumed within
    # milliseconds, while a genuinely mis-keyed one costs this bounded
    # wait once, on a test that is failing anyway.
    deadline = time.monotonic() + 3.0
    while time.monotonic() < deadline and any(chat.unconsumed() for chat in instances):
        time.sleep(0.02)
    problems = []
    for chat in instances:
        problems.extend(chat.harness_errors)
        problems.extend(chat.unconsumed())
    assert not problems, "FleetChat scripting fault(s): " + "; ".join(problems)


@pytest.fixture(autouse=True)
def reset_visual_identity_decode_memos():
    """Clear the process-global visual-identity decode memos around each test.

    task-16/F13 memoizes image-inspection facts, retained shared decodes, and
    linked-portrait version tokens at module scope (they exist precisely to
    survive across production calls). Tests that monkeypatch decode limits or
    count decode passes must not observe -- or seed -- state from an earlier
    test in the same process, so the memos are cleared before and after every
    test. Looked up through sys.modules rather than imported so the thousands
    of tests that never touch these modules pay nothing and gain no import
    side effects.
    """
    resets = []
    for module_name, reset_name in (
        ("tldw_chatbook.Character_Chat.visual_identity", "_reset_inspection_memo"),
        (
            "tldw_chatbook.Chat.character_expression_playback",
            "_reset_shared_decode_state",
        ),
        (
            "tldw_chatbook.Character_Chat.persona_visual_identity",
            "_reset_portrait_memo",
        ),
    ):
        module = sys.modules.get(module_name)
        reset = getattr(module, reset_name, None) if module is not None else None
        if callable(reset):
            resets.append(reset)
    for reset in resets:
        reset()
    yield
    for reset in resets:
        reset()


@pytest.fixture
def qualified_project_semantic_sqlite():
    """Run native-positive semantic allocations only on their source envelope."""
    from contextlib import closing
    import sqlite3

    from tldw_chatbook.Workspaces.project_index.allocation import _SOURCE_ID

    with closing(sqlite3.connect(":memory:")) as conn:
        source = conn.execute("SELECT sqlite_source_id()").fetchone()[0]
        options = {row[0] for row in conn.execute("PRAGMA compile_options")}
    if (
        sqlite3.sqlite_version != "3.49.1"
        or source != _SOURCE_ID
        or not {"TEMP_STORE=1", "MAX_PAGE_SIZE=65536", "THREADSAFE=1"} <= options
    ):
        pytest.skip(
            "native-positive project semantics require SQLite 3.49.1 with the exact qualified source ID and TEMP_STORE=1/MAX_PAGE_SIZE=65536/THREADSAFE=1"
        )
