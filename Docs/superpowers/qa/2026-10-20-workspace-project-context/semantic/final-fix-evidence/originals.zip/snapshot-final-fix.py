from pathlib import Path
import hashlib,json,sys,subprocess
root=Path.cwd()
base=root/'.superpowers/sdd/2026-10-20-workspace-project-semantic-index'
dest=base/'final-fix-snapshots'/sys.argv[1]
dest.mkdir(parents=True,exist_ok=False)
paths=sorted(set([*root.glob('tldw_chatbook/Workspaces/project_index/*.py'),root/'tldw_chatbook/DB/Workspace_Project_Index_DB.py',root/'tldw_chatbook/RAG_Search/projection_scope.py',root/'tldw_chatbook/RAG_Search/simplified/embeddings_wrapper.py',root/'tldw_chatbook/Embeddings/Embeddings_Lib.py',root/'Tests/conftest.py',root/'Tests/Workspaces/project_index_support.py',*root.glob('Tests/Workspaces/test_project_semantic_*.py'),root/'Tests/RAG/test_project_projection_scope.py',root/'Tests/RAG/test_embeddings_lib_logging.py',root/'Tests/UI/test_project_semantic_consent.py']))
changed=subprocess.check_output(['git','-c','safe.directory='+root.as_posix(),'diff','--name-only']).decode().splitlines()
paths=sorted(set(paths+[root/p for p in changed if not p.startswith('backlog/tasks/')]))
rows=[]
for path in paths:
 data=path.read_bytes(); rel=path.relative_to(root).as_posix(); target=dest/rel;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(data);rows.append(dict(path=rel,bytes=len(data),sha256=hashlib.sha256(data).hexdigest()))
(dest/'manifest.json').write_text(json.dumps(rows,indent=2),encoding='utf-8')
print('EXACT SOURCE SNAPSHOT',sys.argv[1],len(rows))
