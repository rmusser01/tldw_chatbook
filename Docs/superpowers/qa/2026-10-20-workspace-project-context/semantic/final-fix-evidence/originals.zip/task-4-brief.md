## Task 4: S3 consent and release — TASK36423

**Consumes:** Stable service actions/state/resolver/jobs. **Files:** Consent/qualification row; new `Tests/UI/test_project_semantic_consent.py`, existing mounted project card tests; `Docs/Architecture/project-indexing.md`, `rag.md`, user guides, semantic QA.

- [ ] Read design-language/component patterns before UI. Write mounted REDs for independent controls/selectors, separate readiness, dirty drafts, stale semantic Disable after Clear/re-enable, no model work on compose/status, missing dependency and all saved Library combinations.
- [ ] Exercise cancellation of external disclosure (zero calls), approved destination hold/change/publication refusal and unchanged keyword/Library state. Implement existing-token controls with explicit provider/config refs and captured semantic revision; no generic query(Input) assumption about two processing fields.
- [ ] Qualify actual cached local model through real production factory/issued scope and app: paraphrase discovery, refresh, failed rebuild, restart, semantic disable and full Clear/detach. Candidate snapshot: already cached MiniLM c9745ed...; artifact presence is not loader/quality proof. Missing sentence-transformers requires an isolated dependency setup, never modifying the shared environment or silently downloading model files.
- [ ] Run one source-frozen semantic scale qualification on retained20k shapes, preserving corpora and analytical/native storage envelope; record model/config/dimension, bytes, throughput, memory, query latency and physical cancellation. Test keyword with missing embeddings independently. No favorable timing reruns or universal latency claim.
- [ ] Retain raw RED/GREEN/native/provider/visual receipts as they retire, exact hashes/limitations/rulings and documentation; self review, independent task review, then one whole-branch review/fix wave. Close tasks only on actual evidence. User has not authorized auto-merging a future semantic PR and PR3204 Qodo waiver does not carry.

- [ ] Gate critical semantic schema/settings/native/project-admission and current embeddings-free keyword regressions in a bounded required PR lane on an actually qualified SQLite runtime, with explicit UI census classification. Keep optional ML/20k work separate and existing lane caps/shards unchanged; update exact CI contracts and ADR103 before workflow changes. Parent owns external hosted qualification/PR actions.

## Canonical active task and implementation plan

---
id: TASK-36423
title: Offer per-folder semantic consent and qualify optional search
status: In Progress
assignee:
  - '@codex'
created_date: '2026-10-23 03:28'
updated_date: '2026-10-23 20:40'
labels: []
dependencies:
  - TASK-36422
references:
  - backlog/decisions/241-workspace-project-context-and-folder-bound-index.md
  - Docs/superpowers/plans/2026-10-20-workspace-project-semantic-index.md
  - backlog/decisions/103-fast-pr-lane-and-required-gate-aggregation.md
type: feature
---

## Description

<!-- SECTION:DESCRIPTION:BEGIN -->
Make optional semantic project discovery understandable and explicitly approved per folder while keeping keyword operation independent.
<!-- SECTION:DESCRIPTION:END -->

## Acceptance Criteria
<!-- AC:BEGIN -->
- [ ] #1 Mounted Settings provides per-binding model/destination choice, disclosure approval, separate keyword/semantic readiness and coverage, and preserved dirty/stale-action fences without model work during compose or status.
- [ ] #2 Cancelled external disclosure causes zero provider calls; destination changes pause old semantic work before approval and stale semantic actions after Clear cannot affect a newer binding state.
- [ ] #3 Saved Library policies/scopes and keyword readiness stay unchanged through semantic enable/disable, missing dependencies, provider failure, restart and chat-provider changes.
- [ ] #4 A selected real local embedding backend is qualified in the real app for paraphrase discovery, refresh, failed rebuild, restart, disable and Clear/detach; no implicit model download or unapproved external project-text transmission occurs.
- [ ] #5 Actual bounded scale, storage peak, memory, query latency and cancellation evidence plus all limitations, docs, ADR linkage and independent reviews are retained; deterministic vectors alone never certify semantic quality.
- [ ] #6 Critical new semantic schema/settings/native ownership and project-admission regressions plus current keyword-without-embeddings controls execute in a bounded required PR lane on the actually qualified runtime; the new mounted consent tests are classified in the governed UI census, without spoofed SQLite qualification or optional ML in the PR gate.
<!-- AC:END -->

## Implementation Plan

<!-- SECTION:PLAN:BEGIN -->
1. Read Task36423, focused Task4 brief, reviewed Task3 API/retirement handoff and needed Task2 producer seam; read complete design-language/component patterns, relevant live/testing lessons and ADR241/103. Preserve binding authority, saved Library choices and embeddings-free keyword operation.
2. Write mounted meaningful RED controls for perbinding model/destination consent, cancelled disclosure with zero provider work, destination pause before approval, independent keyword/semantic choices, dirty drafts, stale CAS afterClear, no model/vector import on compose/status and capturedowner pending Retrycleanup.
3. Extend existing project binding card and canonicalSettings using existing tokens; explicit setup resolution in workers, captured epoch/semanticrevision and actualservice/key cleanup. Separate readiness/coverage and previousindexavailable-refreshfailed; signal alone never means retired. No new settings destination or generic owner.
4. Add bounded required PR coverage for critical schema/settings/native/admission/missing-embedding keyword controls on pinned WindowsPython3.12.10. Print actual SQLite source/options and run positive real allocation contracts without spoof/skip. Preserve existing lane caps and13UIshards; update exact aggregation/target contract and newUIfile census intentionally, measuring added targets/headroom before final lane placement. Amend existing ADR103/241 before workflow/UX boundary changes; no optionalML in PRlane.
5. Qualify actual cached MiniLM through production realapp/factory/issuedscope for paraphrase, refresh, failedrebuild, restart, disable, Clear/detach and native closure with blocked network/no download. Independently qualify current keyword with optionalembeddings absent and savedLibrary matrix/chatproviderchanges.
6. Freeze production source once and run one semantic scale qualification on retained20k tree/single-directory corpora in place, no favorable repeats/reconstruction. Record model/artifact/config/dimension, wholebindingregularfile peak, RSS, throughput, query modelconstruction/querylatency, cancellation and explicit limits. Report adverse results honestly; propose measured minimum corrections before any additional run.
7. Retain sourcehashes/raw parent-child/visual/native/storage proof under tracked semanticQA without model/tempDB payloads; update architecture/userdocs/ADRs. Targeted tests/lint/format/guards only, selfreview and commit/report for independentTask4review, then one final wholebranchreview. Parent owns externalPR/CI actions and taskclosure; no fullsuite/semanticautomerge.
ADR required: yes, amend existingADR241 andADR103.
ADR paths: backlog/decisions/241-workspace-project-context-and-folder-bound-index.md; backlog/decisions/103-fast-pr-lane-and-required-gate-aggregation.md.
Reason: complete existing consent/retirement UI and requiredPRruntime/aggregation boundary; no newstorage, modelowner or dependencybackend.

## Task4 release refinements recorded before the affected source edits (2026-10-23)

- The mounted disclosure must derive its displayed provider/model/destination and the staged settings fingerprint from the same inspected catalog result. Refuse a changed staged/current fingerprint before showing the dialog; preserve service CAS/current-catalog checks. A focused mounted catalog-change RED has been retained.
- The existing Hugging Face producer selected CPU while loading float16 on this CUDA-capable host. Correct only the actual device-before-load/dtype choice: CPU float32, actual CUDA float16, auto behavior preserved. Record device-contract RED/GREEN and one blocked-network cached-model synthetic probe. This is numerical correctness; retained 20k throughput remains unqualified and no causality claim follows from dtype alone.
- The positive stage/cancel mounted node reaches real project SQLite allocation and therefore belongs in the approved pinned Windows3.12.10 project-index job. Move only that uncommitted local census entry from Ubuntu shard6 to the existing bounded job (ten targets become eleven), restore local floor603 and keep all13 shards; exact CI contract asserts Windows inclusion and Ubuntu absence. Hosted runtime/budget remains parent-owned.
- The one retained nested20k attempt was operator-stopped after 152 completed batch32 calls (4,864 chunks) at about1210s; it did not reach Ready, query or cancellation, and the session interruption produced no graceful native-retirement receipt. Wide was never run. Preserve raw/source hashes, investigate the roughly6s inter-batch gap using only an approved 128-tiny-chunk model-free stage diagnostic, and propose a minimum measured change before any service performance edit or second retained scale qualification.
- Prospective measured Task4 amendment overriding the earlier uniform32 source/provider choice: the actual short cached-model comparison separates roughly1.70s internal embedding body from roughly6.32s complete decorated wrapper call with repeated real-carrier admission. Only local Hugging Face source/provider work may batch <=128 contiguous chunks/<=1MiB source text; hosted/other providers, native append transactions and query vector pages remain <=32 rows/<=1MiB. The existing query rank keeps one outer `store.sql_unit()`/registry fence across its pages. Validate complete provider count and dimensions before any append and commit contiguous <=32-row/<=1MiB slices with fresh source/manifest/epoch/revision/consent/destination checks, advancing checkpoint only after each slice. Preserve <=4MiB queued source, <=1GiB binding/native formula, all physical ownership and original 3,600-second scale bound. Focused RED/GREEN and actual native retirement/memory evidence precede any second retained scale qualification; the synthetic diagnosis itself is not semantic quality or scale proof.
<!-- SECTION:PLAN:END -->


## Binding Global Constraints (verbatim)

- Semantic indexing is a further per-binding opt-in; enabling keyword indexing never implies semantic consent.
- Saved Library choices and item scopes remain unchanged. No shared Library RAG service, Library source tables, or globally searchable project collection.
- File text goes only to the explicitly selected embedding destination under index-specific consent. A destination change pauses semantic work until approved; credentials never enter identity, logs, or stored payloads.
- Missing optional dependencies, a missing local model, or embedding/provider failure leaves keyword search usable; no implicit model download or chat-generation analysis.
- Reuse the keyword file/chunk revisions, authority keys, exact exclusions, inclusion policy, epoch, quota and cleanup owner.
- Fence source pagination and ready publication to one committed keyword manifest revision; a changing source cannot produce a mixed Ready generation.
- <=1 GiB total per binding includes ready/staging vectors and temporary files; preserve <=4 MiB queued source text and all existing scanner bounds.
- Search still returns <=10 results and <=16 KiB, with live file/hash/permission validation before any disclosure.
- Only compatible ready generations are queried. Revocation precedes cleanup, and old workers cannot publish after Clear/detach or an epoch change.
- No embeddings/vector import or model construction on widget compose, ordinary keyword search, or index status projection.
- Targeted test selections only; real-provider qualification is distinct from deterministic test embeddings.
- Sequential implementation ownership: S1a, S1b, S2, S3. No shared-file parallel writers, installer/model download, source-text egress, or automatic semantic PR merge.

## Current producer and controller rulings

Task3 is independently reviewed clean and CLI Done. Read task-3-producer-handoff.md beside this brief for the exact service actions/CAS, separate semantic_state (there is no semantic_snapshot), compatibleReady/failedrefresh, current-artifact query preflight and knownpending same-owner retry. Read Task2 producer handoff only for a concrete embedding issue. Do not read the full plan/history or repeat completed foundation implementation. Report any new storage/model/owner/schema/authority boundary need before source edits; existing primitives first.

Use existing ProjectIndexBindingCard and canonical Settings. Explicit perbinding model key/config choice and destination disclosure must identify the actual safe provider/model/local or endpoint destination, not only an opaque fingerprint. Setup resolution is explicit and offUI; do not import Embeddings_Lib or construct a model on compose/status. Keyword and semantic controls/inputs/actions need separate selectors, dirty drafts and captured snapshots; existing generic query(Input)/query(Button) assumptions about two fields must be narrowed. Check keyword/semantic scope consistency rather than manufacturing a fresh action scope. Candidate external destination is staged Paused before approval; a cancelled or stale dialog grants nothing. Semantic disable never changes keyword policy/readiness or saved Library policy/item scopes. Show previous index available; refresh failed separately from successfulrefresh.

Retry cleanup must retain the exact actual service/key after failed shutdown, use in-memory semantic_close_pending and signal only existing owner via retry_semantic_close; runtime get_project_index_service refuses after app closure. A signal is not retirement; display pending until positive completion. No foreign-thread wrapperclose, new service cleanup, query pool, per-tool loop, modelidlecache or source-carrier impersonation. Existing worker/snapshot/requestvisit fencing and token-backed compact actions remain. Read complete design-language/component-patterns and applicable Impeccable skill before UI code; mounted keyboard/focus/readability at80x24/34column detail pane must be captured, not inferred from Python assertions.

ADR103/241 have been amended and activeTaskAC6/7-stepplan recorded BEFORE code. Recheck ci-coverage-preflight.md against source: derived-artifacts.yml and Tests/CI/test_ci_queue_pressure_contract.py still match hashes in preflight. New bounded project-index-contract job uses WindowsPython3.12.10, core/test dependencies only,20min ceiling, fail-closed aggregation into unchangedrequiredcontext. Existing19test runners become20,21withperf; keep13UIshards and existing caps. Runtime is a source-backed candidate until actual hosted qualified; print actualSQLiteversion/source/options and execute positive realadmission tests without spoof or skipallpositive. Actual paths include Tests/DB/test_project_semantic_schema.py, Workspaces/test_project_semantic_settings.py,test_project_index_allocation.py, RAG/test_project_projection_scope.py plus narrow currentmissingembeddingkeyword controls. Select bounded nonoverlapping critical nodes using actual timings; preserve one hung-test/setup/variance headroom, no blind wholemodule append or broadCIrewrite. Update exactCIcontract and newmounted UIfile census classification only intentionally. Report a concrete missingclassification/budget seam to root before increasing shards/caps or changing generalcensusbehavior. Root owns any push/draftPR/actualhostedqualification. NoMLinstall/20kbenchmark inPRlane.

Qualification and retention: use the actual cached localMiniLM production factory/issuer/wrapper, realTldwCli app and tool/binding lifecycle. Deterministicvectors cannot certify model relevance. Actual no-download/no unapprovedproject egress; blocked requests/httpx for local model must permit Windowsasyncio loopback, do not indiscriminately block all socket.connect. Main .venv deliberately lacks SentenceTransformers and is the independent missingdependency keyword control. Current Task3 actualcached async test is construction/retirement proof, not app quality; no redundant modelbootstrap.

One source-frozen semantic scale qualification uses retained .superpowers/k5-scale tree and single-directory20k corpora IN PLACE; no reconstruction, movement, favorable timing repeat or source mutation during the run. Obtain existingcorpus/cache paths from trackedkeywordQA/execution-notes and private qualification metadata, do not inventory privatevenv recursively. Measure actualmodel/config/artifact/dimension, wholebindingregularfile peak plus existinganalytic/sourceproof, RSS, indexing throughput, query modelconstruction/querylatency and nativecancellation. State exactruntime/source/VFS/machine limitations; sampledpeak alone is not analytic cap proof or OSquota. If measured failure needs sourcecorrection, report cause/proposedminimum and preserve fulladverse before any secondqualification.

Tracked delivery evidence belongs in Docs/superpowers/qa/2026-10-20-workspace-project-context/semantic/: copy the required actualrawlogs/XML/sourcehash/proof/visual receipts from privateSDD as they retire; no model binaries, tempSQLite/profile payloads or secretconfig. Task1 allocation proof/native and Task2/3 actualreceipt references must become reviewable tracked evidence before finalSDDcleanup. Preserve adverse and final source attribution; never reconstruct oldchildXML. Warnings have existingowners pyproject.toml unsetasyncio_default_fixture_loop_scope and TTS/audio_cpp_guided_config.py353 Field(exclude_if) onPydantic2.11; retainlimits, no blanket suppression/unrelatedTTSedit.

## Existing runtime and private test bootstrap

Worktree .venv/Scripts/python.exe isPython3.12.10 and missingST. Scoped Ruff is C:/Python312/Scripts/ruff.exe0.4.5. Model qualification uses this SDD/qualification-venv/Scripts/python.exe (ST3.4.1), readonlyshared C:/Users/GDesktop-1/Working/Github/tldw_tui/.venv/Lib/site-packages, Torch2.7.1+cu128/numpy2.2.6/transformers4.52.4/HFhub0.32.3/Chroma1.0.12. Existing cachedMiniLM snapshot C:/Users/GDesktop-1/.cache/huggingface/hub/models--sentence-transformers--all-MiniLM-L6-v2/snapshots/c9745ed1d9f207416be6d2e6f8de32d1f16199bf, safetensors90868376bytes, dimension384. No installer/sharedenvmutation/modeldownload/bootstraprediscovery. Reuse run-qualified-targeted.ps1 (qualificationONLY) which handles parent .pth and child inheritedpywin32/HFcache/offline; supplement pre-run hashes for newUI/CI/productionpaths and exactselectors. Existing outer300s and nativehelper45s unchanged; long scale run requires its own bounded, responsive owned execution, not larger unittestdeadlines.

Only exactprovided repair-sdd-test-trust.ps1 may remove the two already-verified explicitSDDsandboxModifyACEs, with before/after receipt and unchanged actualtrustchecker. Parent metadatawrites can reintroduce them. Run this exacthelper with uniqueRunName beforeprivateprofile tests; unexpected ACLshape/checkfailure stopandreportroot. Do not edit privateguard/generalizeACL/chmod. No private apply_patch. Use normaluserescalated exec asneeded for thisworktree/privatehelpers. Root will avoid privatewrites while your tests run; no source/modelparallelism. Retain actualchildlogs/XML outside numberedpytestrotation immediately. Only inspected taskownedPIDtree cleanup if a bound fires; no broadkills, forcedexit is not graceful native retirement.


## Final semantic review correction contract

ADR required: yes, amend existing ADR241.
ADR path: backlog/decisions/241-workspace-project-context-and-folder-bound-index.md.
Reason: clarify existing eligible-source, exact provider destination, independent consent and physical-owner contracts; no schema, backend or dependency change.

A Partial keyword cache may retain rows outside its current processing policy. Semantic source paging must apply the existing current policy and authoritative binding exclusions before reading text, using bounded keyset SQL. Append validation and final completeness count the same eligible set, with fresh service authority at each unit. Retained forbidden rows cannot reach a provider or prevent an otherwise complete eligible generation from becoming Ready.

Project OpenAI-compatible transport refuses HTTP redirects, including 307/308, before any resend; the explicit project factory option is set only by the issued project wrapper. Default Library transport retains its existing behavior. A redirect refusal is an unavailable provider outcome, never new destination consent.

New semantic work remains denied while any same-binding model close is pending. Already-admitted carriers retire independently: close verifies issued identity, live parent, original execution/thread, zero live children and only its own operation's pending model-close tokens. A peer's ordinary or failed close cannot poison physical retirement. Own failed close and unknown native closure remain retained.

Semantic ranking captures its independently consented compatible Ready generation. Candidate and final disclosure fences revalidate the captured semantic revision/settings and that exact compatible generation. A mismatch returns unavailable without stale semantically selected hits. Keyword scope/manifest alone cannot attest semantic consent.

Tests that perform native-positive semantic allocations explicitly require the production qualified SQLite source/version/options; unsupported runtimes skip only those positives with a precise reason. Portable keyword/refusal controls remain active. Required Windows preflight and positive assertions remain fail-closed.
