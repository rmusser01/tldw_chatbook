from pathlib import Path
import ast,hashlib,json,re,subprocess,xml.etree.ElementTree as ET
root=Path.cwd();b=root/'.superpowers/sdd/2026-10-20-workspace-project-semantic-index';git=['git','-c','safe.directory='+root.as_posix()]
paths=['.github/workflows/derived-artifacts.yml','Docs/Architecture/project-indexing.md','Docs/superpowers/plans/2026-10-20-workspace-project-semantic-index.md','Tests/CI/test_ci_queue_pressure_contract.py','Tests/CI/test_derived_artifacts_workflow.py','Tests/CI/test_ui_lane_shard_count_statements.py','Tests/RAG/test_project_projection_scope.py','backlog/decisions/103-fast-pr-lane-and-required-gate-aggregation.md','backlog/decisions/241-workspace-project-context-and-folder-bound-index.md','tldw_chatbook/Workspaces/project_index/service.py']
assert not (b/'integration-fix-final-static.json').exists()
records=[];py=[p for p in paths if p.endswith('.py')];ruff='C:/Python312/Scripts/ruff.exe'
def run(argv):
 r=subprocess.run(argv,capture_output=True,text=True);records.append(dict(argv=argv,exit_code=r.returncode,stdout=r.stdout,stderr=r.stderr));assert r.returncode==0,(argv,r.stdout,r.stderr)
for p in py:
 diff=subprocess.check_output([*git,'diff','--unified=0','--',p]).decode('utf-8')
 for start,count in re.findall(r'@@ -[0-9]+(?:,[0-9]+)? \+([0-9]+)(?:,([0-9]+))? @@',diff):
  start=int(start);count=int(count or '1')
  if count:run([ruff,'format','--check','--no-cache','--range',f'{start}-{start+count}',p])
 ast.parse((root/p).read_text(encoding='utf-8'),filename=p)
run([ruff,'check','--no-cache',*py]);run([*git,'diff','--check','--',*paths])
for phase in ('red','green'):
 pre=json.loads((b/f'integration-fix-snapshots/{phase}-pre/manifest.json').read_text());post=json.loads((b/f'integration-fix-snapshots/{phase}-post/manifest.json').read_text());assert pre==post
 if phase=='green':
  bypath={r['path']:r for r in post};assert set(paths)<=set(bypath)
  for row in post:
   data=(root/row['path']).read_bytes();assert len(data)==row['bytes'] and hashlib.sha256(data).hexdigest()==row['sha256']
logs=sorted((b/'task2-receipts').glob('integration-fix-green-01*log'))
text='\n'.join(p.read_text(encoding='utf-8-sig') for p in logs)
assert not re.search(r'PytestUnhandledThreadExceptionWarning|Task exception was never retrieved|executor.*(fail|timeout)|unretrieved exception',text,re.I)
xmls=[]
for p in sorted((b/'task2-receipts').glob('integration-fix-*01*xml')):
 suite=ET.parse(p).getroot().find('testsuite');xmls.append(dict(path=p.relative_to(b).as_posix(),**{k:suite.attrib[k] for k in ('tests','failures','errors','skipped','time')}))
receipt=dict(changed_paths=paths,python_ast_pass=py,source34_red_equal=True,source34_green_equal=True,source34_green_current_equal=True,xml=xmls,warning_scan_logs=[p.relative_to(b).as_posix() for p in logs],commands=records)
(b/'integration-fix-final-static.json').write_text(json.dumps(receipt,indent=2),encoding='utf-8')
(b/'integration-fix-changed-paths.json').write_text(json.dumps(paths,indent=2),encoding='utf-8')
(b/'integration-fix-delta.diff').write_bytes(subprocess.check_output([*git,'diff','--binary','--',*paths]))
print('SCOPED FORMAT/LINT/AST/DIFFCHECK PASS:',len(py),'Python;',len(paths),'explicit changed paths;',len(records),'literal command records')
print('SOURCE34 RED/GREEN/current exact equality; green thread/executor/unretrieved warning scan clear')
print(json.dumps(xmls,indent=2))
