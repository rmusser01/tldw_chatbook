from pathlib import Path
import json,hashlib,sys
root=Path.cwd();b=root/'.superpowers/sdd/2026-10-20-workspace-project-semantic-index'
paths=[r['path'] for r in json.loads((b/'final-fix-snapshots/core16-post/manifest.json').read_text())]+['Tests/CI/test_derived_artifacts_workflow.py','Tests/CI/test_ui_lane_shard_count_statements.py','Tests/private_profile.py','.superpowers/sdd/2026-10-20-workspace-project-semantic-index/run-task4-hosted-fixture-targets.ps1']
dest=b/'integration-fix-snapshots'/sys.argv[1];dest.mkdir(parents=True,exist_ok=False);rows=[]
for name in sorted(set(paths)):
 data=(root/name).read_bytes();p=dest/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(data);rows.append(dict(path=name,bytes=len(data),sha256=hashlib.sha256(data).hexdigest()))
(dest/'manifest.json').write_text(json.dumps(rows,indent=2),encoding='utf-8');print('EXACT INTEGRATION SOURCE SNAPSHOT',sys.argv[1],len(rows))
