from pathlib import Path
import hashlib,io,json,subprocess,sys,zipfile
root=Path.cwd();b=root/'.superpowers/sdd/2026-10-20-workspace-project-semantic-index';repo='Docs/superpowers/qa/2026-10-20-workspace-project-context/semantic/integration-fix-evidence';dest=root/repo;git=['git','-c','safe.directory='+root.as_posix()];whitelist=b/'integration-fix-commit-whitelist.json'
def sha(data):return hashlib.sha256(data).hexdigest()
def blob(rev,p):return subprocess.check_output([*git,'cat-file','blob',rev+':'+p])
if len(sys.argv)>1:
 rev='HEAD' if sys.argv[1]=='--verify-head' else '';paths=json.loads(whitelist.read_text());manifest=json.loads(blob(rev,repo+'/manifest.json'));archive=blob(rev,repo+'/originals.zip')
 with zipfile.ZipFile(io.BytesIO(archive)) as z:
  assert set(z.namelist())=={r['member'] for r in manifest['originals']}
  for row in manifest['originals']:
   data=z.read(row['member']);assert len(data)==row['bytes'] and sha(data)==row['sha256'] and data==(b/row['original']).read_bytes(),row['member']
 expected=json.loads((b/'integration-fix-index-expected.json').read_text()) if rev else None
 actual={}
 for p in paths:
  data=blob(rev,p);actual[p]=dict(bytes=len(data),sha256=sha(data))
  if p.startswith(repo+'/'):assert data==(root/p).read_bytes(),p
  if expected is not None:assert actual[p]==expected[p],p
 if rev:
  committed=subprocess.check_output([*git,'diff-tree','--no-commit-id','--name-only','-r','HEAD']).decode().splitlines();assert set(committed)==set(paths),set(committed)^set(paths)
 else:
  staged=subprocess.check_output([*git,'diff','--cached','--name-only']).decode().splitlines();assert set(staged)==set(paths),set(staged)^set(paths)
  (b/'integration-fix-index-expected.json').write_text(json.dumps(actual,indent=2),encoding='utf-8')
 print(('HEAD' if rev else 'INDEX')+' BLOB PASS:',len(paths),'explicit paths;',len(manifest['originals']),'exact original-byte ZIP members;',len(archive),'archive bytes; sha256',sha(archive));raise SystemExit()
assert not dest.exists();dest.mkdir(parents=True)
items=sorted((b/'task2-receipts').glob('integration-fix-*'))+sorted(p for p in (b/'integration-fix-snapshots').rglob('*') if p.is_file())
for pattern in ('integration-fix-*-permission-before.json','integration-fix-*-permission-after.json'):items.extend(sorted(b.glob(pattern)))
for name in ('integration-fix-report-precommit.md','integration-fix-static.json','integration-fix-final-static.json','integration-fix-changed-paths.json','integration-fix-delta.diff','integration-fix-green-01-process-retirement.json','task4-old-head-prfast-120758047078-failure-raw.log','repair-sdd-test-trust.ps1','run-task4-hosted-fixture-targets.ps1','snapshot-integration-fix.py','verify-integration-fix-static.py','retain-integration-fix-evidence.py'):items.append(b/name)
assert len(items)==len(set(items));rows=[]
with zipfile.ZipFile(dest/'originals.zip','w',compression=zipfile.ZIP_DEFLATED) as z:
 for p in items:
  assert p.is_file(),p
  rel=p.relative_to(b).as_posix();data=p.read_bytes();z.writestr(rel,data);rows.append(dict(member=rel,original=rel,bytes=len(data),sha256=sha(data)))
(dest/'.gitattributes').write_bytes(b'* -text whitespace=blank-at-eol,blank-at-eof,space-before-tab,cr-at-eol\n')
(dest/'report.md').write_bytes((b/'integration-fix-report-precommit.md').read_bytes())
(dest/'manifest.json').write_text(json.dumps(dict(base_head='441bb9aa898e946d1d57d095ce2e64e3d95d53ab',run_families=['integration-fix-red-01','integration-fix-green-01'],source_paths_per_snapshot=34,originals=rows),indent=2),encoding='utf-8')
(dest/'README.md').write_text('''# Scoped semantic integration correction evidence

This distinct group retains the final nested-operation ownership and current CI accounting correction before the one pending scoped review verdict. Read report.md for exact commands, covered nodes, actual source/native proof and limits. RED is6 failed/8 passed in66.94s; GREEN is19 passed/0 skipped in185.96s, with all5 private ownership children passing and positively retired. Both runs use actual pinned SQLite3.49.1/source/options without SentenceTransformers. Four source34 raw snapshot sets preserve RED/GREEN pre/post bytes; GREEN current equals post.

originals.zip retains only this new two-run family, exact source snapshots, trust/static/retirement/helper/delta records and the supplied original old-head hosted failure log. manifest.json lists every original byte count/SHA256. The scoped attribute preserves raw receipt line endings. The retention helper compares every actual staged/HEAD evidence blob and decoded archive member against originals, and all10 changed source/test/CI/doc blobs against captured index bytes. The later live report commit append is outside this immutable precommit report.

The approved same Windows job adds one nested critical target (17 selectors/45 cases), preserving all jobs, dependencies, caps, shards and aggregation. The45-case lane was not replayed here; final hosted new-head CI is pending. The prior real-model app pass belongs to441bb9 and is historical for this guard delta; no model/20k/Console/Settings replay occurred. Old final-fix/model/release evidence and root Task36423/semantic README/final-reviews remain untouched and excluded. No push/PR/merge/task closure is claimed.
''',encoding='utf-8',newline='\r\n')
paths=json.loads((b/'integration-fix-changed-paths.json').read_text());assert len(paths)==10
changed=set(subprocess.check_output([*git,'diff','--name-only']).decode().splitlines());assert changed==set(paths)|{'backlog/tasks/task-36423 - Offer-per-folder-semantic-consent-and-qualify-optional-search.md'},changed^set(paths)
paths += [p.relative_to(root).as_posix() for p in sorted(dest.iterdir())];whitelist.write_text(json.dumps(paths,indent=2),encoding='utf-8')
with zipfile.ZipFile(dest/'originals.zip') as z:
 for r in rows:assert z.read(r['member'])==(b/r['original']).read_bytes()
print('PREPARED',len(paths),'explicit paths;',len(rows),'exact original-byte ZIP members;', (dest/'originals.zip').stat().st_size,'archive bytes')
print('EXCLUDED root Task36423/semantic README/final-reviews; no previous QA/model evidence changed')
