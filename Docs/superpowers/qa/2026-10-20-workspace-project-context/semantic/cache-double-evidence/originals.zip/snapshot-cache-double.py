from pathlib import Path
import hashlib,json,sys
root=Path.cwd();b=root/'.superpowers/sdd/2026-10-20-workspace-project-semantic-index';paths=['Tests/RAG/test_embedding_cache_ownership_review.py','Tests/conftest.py','tldw_chatbook/Embeddings/Embeddings_Lib.py','tldw_chatbook/RAG_Search/simplified/embeddings_wrapper.py','tldw_chatbook/RAG_Search/activation.py','tldw_chatbook/DB/RAG_Indexing_DB.py','tldw_chatbook/DB/base_db.py','tldw_chatbook/Workspaces/project_index/allocation.py','tldw_chatbook/Workspaces/project_index/runtime.py','tldw_chatbook/Utils/private_paths.py','.superpowers/sdd/2026-10-20-workspace-project-semantic-index/run-task4-hosted-fixture-targets.ps1','.superpowers/sdd/2026-10-20-workspace-project-semantic-index/repair-sdd-test-trust.ps1']
dest=b/'cache-double-snapshots'/sys.argv[1];dest.mkdir(parents=True,exist_ok=False);rows=[]
for name in sorted(paths):
 data=(root/name).read_bytes();p=dest/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(data);rows.append(dict(path=name,bytes=len(data),sha256=hashlib.sha256(data).hexdigest()))
(dest/'manifest.json').write_text(json.dumps(rows,indent=2),encoding='utf-8');print('CACHE DOUBLE SOURCE SNAPSHOT',sys.argv[1],len(rows))
