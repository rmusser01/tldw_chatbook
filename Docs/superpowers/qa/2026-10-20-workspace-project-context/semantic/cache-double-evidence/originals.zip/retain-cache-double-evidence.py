from pathlib import Path
import hashlib,io,json,subprocess,sys,zipfile
root=Path.cwd();b=root/'.superpowers/sdd/2026-10-20-workspace-project-semantic-index';repo='Docs/superpowers/qa/2026-10-20-workspace-project-context/semantic/cache-double-evidence';dest=root/repo;git=['git','-c','safe.directory='+root.as_posix()];whitelist=b/'cache-double-commit-whitelist.json';test='Tests/RAG/test_embedding_cache_ownership_review.py'
def sha(data):return hashlib.sha256(data).hexdigest()
def blob(rev,p):return subprocess.check_output([*git,'cat-file','blob',rev+':'+p])
if len(sys.argv)>1:
 rev='HEAD' if sys.argv[1]=='--verify-head' else '';paths=json.loads(whitelist.read_text());manifest=json.loads(blob(rev,repo+'/manifest.json'));archive=blob(rev,repo+'/originals.zip')
 with zipfile.ZipFile(io.BytesIO(archive)) as z:
  assert set(z.namelist())=={r['member'] for r in manifest['originals']}
  for row in manifest['originals']:
   data=z.read(row['member']);assert len(data)==row['bytes'] and sha(data)==row['sha256'] and data==(b/row['original']).read_bytes(),row['member']
 expected=json.loads((b/'cache-double-index-expected.json').read_text()) if rev else None;actual={}
 for p in paths:
  data=blob(rev,p);actual[p]=dict(bytes=len(data),sha256=sha(data))
  if p.startswith(repo+'/'):assert data==(root/p).read_bytes(),p
  if expected is not None:assert actual[p]==expected[p],p
 argv=[*git,'diff-tree','--no-commit-id','--name-only','-r','HEAD'] if rev else [*git,'diff','--cached','--name-only'];assert set(subprocess.check_output(argv).decode().splitlines())==set(paths)
 if not rev:(b/'cache-double-index-expected.json').write_text(json.dumps(actual,indent=2),encoding='utf-8')
 print(('HEAD' if rev else 'INDEX')+' BLOB PASS:',len(paths),'explicit paths;',len(manifest['originals']),'exact original-byte ZIP members;',len(archive),'archive bytes; sha256',sha(archive));raise SystemExit()
assert not dest.exists();dest.mkdir(parents=True)
items=sorted((b/'task2-receipts').glob('cache-double-*'))+sorted(p for p in (b/'cache-double-snapshots').rglob('*') if p.is_file())
for pattern in ('cache-double-*-permission-before.json','cache-double-*-permission-after.json'):items.extend(sorted(b.glob(pattern)))
for name in ('cache-double-qualified-red-01','cache-double-qualified-green-01'):
 for phase in ('runtime-pre','runtime-post'):items.extend(sorted((b/(name+'-'+phase)).iterdir()))
 for suffix in ('environment.json','environment-restored.json','runtime.stdout.json','runtime.stderr.bin','post.json'):items.append(b/(name+'-'+suffix))
for name in ('cache-double-red-01-process-retirement.json','cache-double-environment-null-empty-probe.json','cache-double-static.json','cache-double-report-precommit.md','cache-double-delta.diff','snapshot-cache-double.py','retain-cache-double-evidence.py'):items.append(b/name)
assert len(items)==len(set(items));rows=[]
with zipfile.ZipFile(dest/'originals.zip','w',compression=zipfile.ZIP_DEFLATED) as z:
 for p in items:
  assert p.is_file(),p
  rel=p.relative_to(b).as_posix();data=p.read_bytes();z.writestr(rel,data);rows.append(dict(member=rel,original=rel,bytes=len(data),sha256=sha(data)))
(dest/'.gitattributes').write_bytes(b'* -text whitespace=blank-at-eol,blank-at-eof,space-before-tab,cr-at-eol\n');(dest/'report.md').write_bytes((b/'cache-double-report-precommit.md').read_bytes())
(dest/'manifest.json').write_text(json.dumps(dict(base_head='aa42cc0b51206adc0fbc7c8a4dd59317a2a97265',scope='one Library HTTP double test only',originals=rows),indent=2),encoding='utf-8')
(dest/'README.md').write_text('''# Library cache double compatibility evidence

One test-only callback signature correction accepts allow_redirects and asserts the Library default True. Real factory, endpoint-vector isolation, restarted cache, namespace privacy and teardown code are unchanged. Read report.md for actual commands and limitations.

Original attempts are preserved separately: core ADVERSE setup1failed4.95s (missing SentenceTransformers, before HTTP); intended qualified-runtime RED1failed9.26s (unexpected allow_redirects TypeError); exact GREEN1passed10.11s,0skips. All finite parents retired; no private child is expected for this bootstrap-only node. Source12 pre/post match per attempt; helper/runtime3 match for both qualified attempts. No local model construction or provider request occurred.

Raw environment restoration flags remain false: finally attempted prior=null restoration but Windows/.NET reports empty string; the harmless standalone probe documents this. Both finite shells exited and a fresh shell has PYTEST_ADDOPTS absent. No literal restoreTrue claim or rewritten original receipt. The RED XML path shlex quirk and unchanged raw relocation are recorded honestly.

The manifest enumerates every raw original/SHA256; scoped attributes preserve raw line endings. Archive members and actual index/HEAD blobs are verified. Earlier QA/model groups, root Task36423/semantic README/final-reviews remain untouched. No production/CI/docs/ADR/runtime change, extra test/model run, push/rebase/new review/task closure.
''',encoding='utf-8',newline='\r\n')
changed=set(subprocess.check_output([*git,'diff','--name-only']).decode().splitlines());assert changed=={test,'backlog/tasks/task-36423 - Offer-per-folder-semantic-consent-and-qualify-optional-search.md'},changed
paths=[test]+[p.relative_to(root).as_posix() for p in sorted(dest.iterdir())];whitelist.write_text(json.dumps(paths,indent=2),encoding='utf-8')
print('PREPARED',len(paths),'explicit test/evidence paths;',len(rows),'exact originals;', (dest/'originals.zip').stat().st_size,'archive bytes')
