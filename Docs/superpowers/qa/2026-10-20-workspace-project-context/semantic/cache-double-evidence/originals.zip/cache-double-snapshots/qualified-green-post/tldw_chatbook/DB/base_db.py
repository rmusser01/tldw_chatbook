# base_db.py
# Description: Base class for standardized database path handling
#
"""
base_db.py
----------

Base class that provides standardized path handling for all database modules.
This ensures consistent behavior across all DB classes for:
- Path type handling (str vs Path)
- Memory database special case (':memory:')
- Client ID handling
- Private file connection enforcement
"""

import asyncio
import functools
import sqlite3
import threading
import time
from abc import ABC, abstractmethod
from collections.abc import Callable, Collection, Iterator
from contextlib import contextmanager
from pathlib import Path
from typing import Any, Union
from weakref import WeakValueDictionary

from loguru import logger

from tldw_chatbook.Utils.private_paths import lexical_path

from .private_sqlite import connect_private_sqlite

SEMANTIC_MUTATION_GUARD_FUNCTION = "console_semantic_mutation_authorized"
TRACE_GC_DELETE_GUARD_FUNCTION = "console_trace_gc_delete_authorized"


@contextmanager
def operation_owned_connection(database: object) -> Iterator[None]:
    """Close only the thread-local handle opened by this synchronous operation.

    Inspect without acquiring a handle. A pre-existing registered connection,
    including its active transaction, remains owned by the caller unless retired
    during the operation; a newly acquired replacement is operation-owned.
    """
    local = getattr(database, "_local", None)
    registry = getattr(database, "_connection_quiescence", None)
    close = getattr(database, "close_connection", None)
    if local is None or registry is None or not callable(close):
        from .AgentRuns_DB import AgentRunsDB
        from .Client_Media_DB_v2 import MediaDatabase
        from .Library_Collections_DB import LibraryCollectionsDB
        from .Workspace_DB import WorkspaceDB

        owned_types = {AgentRunsDB, LibraryCollectionsDB, MediaDatabase, WorkspaceDB}
        if type(database).__module__ == "tldw_chatbook.DB.Dreams_DB":
            from .Dreams_DB import DreamsDB

            owned_types.add(DreamsDB)
        if type(database).__module__ == "tldw_chatbook.DB.Guardian_DB":
            from .Guardian_DB import GuardianDB

            owned_types.add(GuardianDB)
        if type(database) not in owned_types:
            from .RAG_Indexing_DB import RAGIndexingDB

            owned_types.add(RAGIndexingDB)
        if type(database) not in owned_types or database.is_memory_db:
            yield
            return
        from tldw_chatbook.Backup_Recovery.participants import _core_cached_connection

        # A raw close can leave a stale cache. Use the same native retirement
        # evidence as the getter; a still-live borrowed handle remains owned.
        local = database._local if type(database) is MediaDatabase else database._thread_local
        close = database.close
        previous = _core_cached_connection(database, getattr(local, "conn", None))
        borrowed = previous is not None
    else:
        previous = getattr(local, "conn", None)
        borrowed = previous is not None and registry.is_registered(previous)
    try:
        yield
    finally:
        current = getattr(local, "conn", None)
        if current is not None and (not borrowed or current is not previous):
            close()


async def run_owned_db_call[**_CallParameters, _CallResult](
    database: object,
    operation: Callable[_CallParameters, _CallResult],
    /,
    *args: _CallParameters.args,
    **kwargs: _CallParameters.kwargs,
) -> _CallResult:
    """Run a finite callback and retire only its newly opened worker handle.

    The complete callback owns one counted repository interval, which ends
    before its newly opened handle retires.
    Cancellation of the awaiting task does not close a handle still in use by
    its executor callback. Existing connections and memory/custom owners retain
    their original lifetimes.
    """
    def invoke() -> _CallResult:
        from .AgentRuns_DB import AgentRunsDB
        from .ChaChaNotes_DB import CharactersRAGDB
        from .Workspace_DB import WorkspaceDB

        owned_types = {AgentRunsDB, CharactersRAGDB, WorkspaceDB}
        if type(database).__module__ == "tldw_chatbook.DB.Dreams_DB":
            from .Dreams_DB import DreamsDB

            owned_types.add(DreamsDB)
        if type(database).__module__ == "tldw_chatbook.DB.Guardian_DB":
            from .Guardian_DB import GuardianDB

            owned_types.add(GuardianDB)
        if type(database) not in owned_types or database.is_memory_db:
            return operation(*args, **kwargs)
        from tldw_chatbook.Backup_Recovery.participants import _core_operation

        with operation_owned_connection(database), _core_operation(database):
            return operation(*args, **kwargs)

    return await asyncio.to_thread(invoke)


class SQLiteConnectionQuiescenceRegistry:
    """Coordinate an exclusive maintenance window over held SQLite handles.

    The registry is deliberately process-local. Durable exclusion remains the
    database maintenance lease; this class closes the gap between that lease and
    ``CharactersRAGDB``'s thread-local, long-lived connections.
    """

    def __init__(self) -> None:
        self._condition = threading.Condition(threading.RLock())
        self._connections: dict[int, sqlite3.Connection] = {}
        self._active_uses: set[object] = set()
        self._active_acquisitions = 0
        self._quiescence_token: object | None = None

    def begin_acquisition(self) -> None:
        """Reserve one connection lookup/create operation.

        Raises:
            RuntimeError: If exclusive maintenance is already active.
        """

        with self._condition:
            if self._quiescence_token is not None:
                raise RuntimeError("database_maintenance_in_progress")
            self._active_acquisitions += 1

    def finish_acquisition(self) -> None:
        """Release one lookup/create reservation.

        Raises:
            RuntimeError: If no matching acquisition is active.
        """

        with self._condition:
            if self._active_acquisitions <= 0:
                raise RuntimeError("connection_acquisition_identity")
            self._active_acquisitions -= 1
            self._condition.notify_all()

    def register(self, connection: sqlite3.Connection) -> None:
        """Register a newly opened thread-owned connection.

        Args:
            connection: Native handle opened under an acquisition reservation.

        Raises:
            RuntimeError: If maintenance is active without a reserved opener.
        """

        with self._condition:
            # An acquisition reserved before quiescence may finish opening its
            # handle; the barrier is already waiting for that reservation and
            # will close the newly registered handle before it returns.
            if self._quiescence_token is not None and self._active_acquisitions <= 0:
                raise RuntimeError("database_maintenance_in_progress")
            self._connections[id(connection)] = connection

    def unregister(self, connection: sqlite3.Connection) -> None:
        """Forget an explicitly closed connection.

        Args:
            connection: Exact registered native handle to forget.
        """

        with self._condition:
            current = self._connections.get(id(connection))
            if current is connection:
                self._connections.pop(id(connection), None)
            self._condition.notify_all()

    def is_registered(self, connection: sqlite3.Connection) -> bool:
        """Return whether a handle remains registered.

        Args:
            connection: Exact native handle identity to inspect.

        Returns:
            Whether the registry still owns that handle identity.
        """

        with self._condition:
            return self._connections.get(id(connection)) is connection

    def begin_use(self) -> object:
        """Reserve one managed transaction or cursor across a barrier.

        Returns:
            An opaque exact-use token.

        Raises:
            RuntimeError: If exclusive maintenance is already active.
        """

        with self._condition:
            if self._quiescence_token is not None:
                raise RuntimeError("database_maintenance_in_progress")
            token = object()
            self._active_uses.add(token)
            return token

    def end_use(self, token: object) -> None:
        """Release the exact managed-transaction or cursor reservation.

        Args:
            token: Exact opaque token returned by :meth:`begin_use`.

        Raises:
            RuntimeError: If the token is unknown or already released.
        """

        with self._condition:
            if token not in self._active_uses:
                raise RuntimeError("connection_use_identity")
            self._active_uses.remove(token)
            self._condition.notify_all()

    def begin_quiescence(self, *, timeout_seconds: float) -> object:
        """Reject new work and wait for acquisitions and SQL use to drain.

        Args:
            timeout_seconds: Maximum non-negative drain duration.

        Returns:
            The exact opaque token controlling the admitted barrier.

        Raises:
            ValueError: If ``timeout_seconds`` is invalid.
            RuntimeError: If another barrier is already active.
            TimeoutError: If active work does not drain before the deadline.
        """

        if type(timeout_seconds) not in {int, float} or float(timeout_seconds) < 0:
            raise ValueError("timeout_seconds")
        deadline = time.monotonic() + float(timeout_seconds)
        with self._condition:
            if self._quiescence_token is not None:
                raise RuntimeError("connection_quiescence_already_active")
            token = object()
            self._quiescence_token = token
            while self._active_uses or self._active_acquisitions:
                remaining = deadline - time.monotonic()
                if remaining <= 0:
                    self._quiescence_token = None
                    self._condition.notify_all()
                    raise TimeoutError("connection_quiescence_timeout")
                self._condition.wait(remaining)
            return token

    def close_registered(self, token: object) -> None:
        """Close every registered handle while the exact barrier is held.

        Args:
            token: Exact opaque token returned by :meth:`begin_quiescence`.

        Raises:
            RuntimeError: If the barrier identity is wrong or a native
                transaction remains active after tracked work drained.
        """

        with self._condition:
            if self._quiescence_token is not token:
                raise RuntimeError("connection_quiescence_identity")
            connections = tuple(self._connections.values())
        for connection in connections:
            try:
                in_transaction = connection.in_transaction
            except sqlite3.ProgrammingError:
                self.unregister(connection)
                continue
            if in_transaction:
                raise RuntimeError("connection_transaction_remained_active")
            connection.close()
            self.unregister(connection)

    def end_quiescence(self, token: object) -> None:
        """Resume ordinary acquisition after the exact maintenance window.

        Args:
            token: Exact opaque token returned by :meth:`begin_quiescence`.

        Raises:
            RuntimeError: If the barrier identity is wrong or stale.
        """

        with self._condition:
            if self._quiescence_token is not token:
                raise RuntimeError("connection_quiescence_identity")
            self._quiescence_token = None
            self._condition.notify_all()

    def connection_count(self) -> int:
        """Return the bounded count of registered handles.

        Returns:
            Number of live handles across every same-file database instance.
        """

        with self._condition:
            return len(self._connections)


_QUIESCENCE_REGISTRIES: WeakValueDictionary[
    str, SQLiteConnectionQuiescenceRegistry
] = WeakValueDictionary()
_QUIESCENCE_REGISTRIES_LOCK = threading.Lock()


def sqlite_connection_quiescence_registry(
    database_identity: str | None,
) -> SQLiteConnectionQuiescenceRegistry:
    """Return one process-local barrier for a canonical SQLite identity.

    Args:
        database_identity: Canonical file identity, or ``None`` for an isolated
            in-memory database.

    Returns:
        The shared live registry for a file, or a fresh isolated registry.
    """

    if database_identity is None:
        return SQLiteConnectionQuiescenceRegistry()
    with _QUIESCENCE_REGISTRIES_LOCK:
        registry = _QUIESCENCE_REGISTRIES.get(database_identity)
        if registry is None:
            registry = SQLiteConnectionQuiescenceRegistry()
            _QUIESCENCE_REGISTRIES[database_identity] = registry
        return registry


class _QuiescentSQLiteConnection(sqlite3.Connection):
    """SQLite connection whose cursors hold quiescence-use reservations."""

    def __init__(self, *args: object, **kwargs: object) -> None:
        super().__init__(*args, **kwargs)
        self._quiescence_registry: SQLiteConnectionQuiescenceRegistry | None = None
        self._quiescence_tokens: set[object] = set()
        self._quiescence_tokens_lock = threading.RLock()
        # PERF-04 (TASK-33263): transaction-boundary observation for the
        # semantic mutation guard, replacing a trace callback whose expanded
        # SQL rendered every bound BLOB as hex on each statement.
        self._transaction_boundary_listener: Callable[[], None] | None = None
        self._observed_in_transaction = False

    def set_transaction_boundary_listener(self, listener: Callable[[], None]) -> None:
        """Call ``listener`` whenever this connection's transaction may have changed.

        Every statement runs through a quiescent cursor, which compares
        ``in_transaction`` before and after it. The comparison before a
        statement also catches a transaction ended outside Python (C-level
        ``commit()`` from ``with connection:``). ``executescript`` always
        reports a boundary, since one script can COMMIT and BEGIN again
        without changing ``in_transaction``.

        Args:
            listener: Zero-argument callback; must not execute SQL.
        """

        self._transaction_boundary_listener = listener
        self._observed_in_transaction = self.in_transaction

    def _observe_transaction_state(self, *, boundary: bool = False) -> None:
        listener = self._transaction_boundary_listener
        try:
            in_transaction = self.in_transaction
        except sqlite3.ProgrammingError:
            # Closed: no transaction survives, so an open one reads as ended
            # (a boundary, which fails closed) and the caller's own error wins.
            in_transaction = False
        if listener is not None and (
            boundary or in_transaction != self._observed_in_transaction
        ):
            listener()
        self._observed_in_transaction = in_transaction

    def commit(self) -> None:
        """Commit, then report the transaction boundary to the listener."""

        try:
            super().commit()
        finally:
            self._observe_transaction_state()

    def rollback(self) -> None:
        """Roll back, then report the transaction boundary to the listener."""

        try:
            super().rollback()
        finally:
            self._observe_transaction_state()

    def attach_quiescence_registry(
        self, registry: SQLiteConnectionQuiescenceRegistry
    ) -> None:
        """Attach the registry before exposing this connection to callers.

        Args:
            registry: Shared barrier for the connection's database identity.
        """

        with self._quiescence_tokens_lock:
            if (
                self._quiescence_registry is not None
                and self._quiescence_registry is not registry
            ):
                raise RuntimeError("connection_quiescence_registry_identity")
            self._quiescence_registry = registry

    def _begin_cursor_use(self) -> object | None:
        registry = self._quiescence_registry
        if registry is None:
            return None
        token = registry.begin_use()
        with self._quiescence_tokens_lock:
            self._quiescence_tokens.add(token)
        return token

    def _end_cursor_use(self, token: object | None) -> None:
        if token is None:
            return
        with self._quiescence_tokens_lock:
            if token not in self._quiescence_tokens:
                return
            self._quiescence_tokens.remove(token)
            registry = self._quiescence_registry
        if registry is not None:
            registry.end_use(token)

    def cursor(  # type: ignore[override]
        self,
        factory: type[sqlite3.Cursor] | None = None,
    ) -> sqlite3.Cursor:
        """Create a cursor that tracks its complete execute/fetch lifetime.

        A caller's own cursor type is kept but always combined with the
        tracked cursor: an untracked cursor could BEGIN a transaction the
        mutation guard never sees (Qodo, #2894).

        Args:
            factory: Optional ``sqlite3.Cursor`` subclass to create.

        Returns:
            A cursor that is an instance of ``factory`` and is tracked.

        Raises:
            TypeError: ``factory`` is not a ``sqlite3.Cursor`` subclass.
        """

        return super().cursor(_tracked_cursor_type(factory or _QuiescentSQLiteCursor))

    def execute(  # type: ignore[override]
        self,
        sql: str,
        parameters: object = (),
    ) -> sqlite3.Cursor:
        """Execute SQL through a tracked cursor."""

        return self.cursor().execute(sql, parameters)

    def executemany(  # type: ignore[override]
        self,
        sql: str,
        seq_of_parameters: object,
    ) -> sqlite3.Cursor:
        """Execute repeated SQL through a tracked cursor."""

        return self.cursor().executemany(sql, seq_of_parameters)

    def executescript(self, sql_script: str) -> sqlite3.Cursor:  # type: ignore[override]
        """Execute a script through a tracked cursor."""

        return self.cursor().executescript(sql_script)

    def backup(  # type: ignore[override]
        self,
        target: sqlite3.Connection,
        *,
        pages: int = -1,
        progress: Callable[[int, int, int], None] | None = None,
        name: str = "main",
        sleep: float = 0.250,
    ) -> None:
        """Keep a reservation for the complete synchronous backup."""

        token = self._begin_cursor_use()
        try:
            super().backup(
                target,
                pages=pages,
                progress=progress,
                name=name,
                sleep=sleep,
            )
        finally:
            self._end_cursor_use(token)

    def close(self) -> None:
        """Release any cursor reservations before closing the native handle."""

        with self._quiescence_tokens_lock:
            tokens = tuple(self._quiescence_tokens)
        for token in tokens:
            self._end_cursor_use(token)
        super().close()


def _is_transaction_statement(sql: object) -> bool:
    """Whether ``sql`` starts with BEGIN, COMMIT or ROLLBACK.

    The trace callback's own rule: ``ROLLBACK TO <savepoint>`` keeps
    ``in_transaction`` True yet ends the guarded work, so it is a boundary too
    (Qodo, #2894). RELEASE never was one.

    Args:
        sql: The statement text a cursor was asked to run.

    Returns:
        True when the statement's first keyword is BEGIN, COMMIT or ROLLBACK.
    """

    if not isinstance(sql, str):
        return False
    words = sql.lstrip().split(None, 1)
    return bool(words) and words[0].upper() in {"BEGIN", "COMMIT", "ROLLBACK"}


class _QuiescentSQLiteCursor(sqlite3.Cursor):
    """Cursor that keeps a read reservation until results are consumed."""

    def __init__(self, connection: _QuiescentSQLiteConnection) -> None:
        # Set before the next initializer: a composed caller cursor may run a
        # statement from its own __init__ (Qodo, #2894).
        self._quiescent_connection = connection
        self._quiescence_token: object | None = None
        super().__init__(connection)

    def _begin_use(self) -> None:
        self._release_use()
        self._quiescence_token = self._quiescent_connection._begin_cursor_use()

    def _release_use(self) -> None:
        token = self._quiescence_token
        self._quiescence_token = None
        self._quiescent_connection._end_cursor_use(token)

    def _release_if_no_results(self) -> None:
        if self.description is None:
            self._release_use()

    def _tracked(
        self,
        run: Callable[..., sqlite3.Cursor],
        *args: object,
        boundary: bool = False,
        boundary_if_run: bool = False,
    ) -> sqlite3.Cursor:
        """Run one statement call holding a use reservation, observing boundaries.

        Both observations sit inside the handler that releases the reservation,
        so a failure in either (a cursor kept past its connection's close) can
        never leave the quiescence registry pinned.

        ``boundary`` is reported even when the call fails (a script may have
        committed and begun again before failing). ``boundary_if_run`` unless
        the authorizer refused the statement (SQLITE_AUTH): a refused COMMIT
        never ran, and the trace callback never reported one either. Any other
        failure may have come after the statement ran (a caller cursor that
        raises after ROLLBACK TO), so it is still a boundary: fail closed.
        """

        self._begin_use()
        connection = self._quiescent_connection
        try:
            connection._observe_transaction_state()
            refused = False
            try:
                result = run(*args)
            except sqlite3.DatabaseError as error:
                refused = getattr(error, "sqlite_errorcode", None) == sqlite3.SQLITE_AUTH
                raise
            finally:
                connection._observe_transaction_state(
                    boundary=boundary or (boundary_if_run and not refused)
                )
        except BaseException:
            self._release_use()
            raise
        self._release_if_no_results()
        return result

    def execute(self, sql: str, parameters: object = ()) -> sqlite3.Cursor:
        """Hold one use reservation through result consumption."""

        return self._tracked(
            super().execute,
            sql,
            parameters,
            boundary_if_run=_is_transaction_statement(sql),
        )

    def executemany(self, sql: str, seq_of_parameters: object) -> sqlite3.Cursor:
        """Hold one use reservation through repeated execution."""

        return self._tracked(
            super().executemany,
            sql,
            seq_of_parameters,
            boundary_if_run=_is_transaction_statement(sql),
        )

    def executescript(self, sql_script: str) -> sqlite3.Cursor:
        """Hold one use reservation through script execution.

        A script always reports a boundary: it can COMMIT and BEGIN again
        without changing ``in_transaction``.
        """

        return self._tracked(super().executescript, sql_script, boundary=True)

    def fetchone(self) -> sqlite3.Row | tuple[object, ...] | None:
        """Release the reservation after the result set is exhausted."""

        try:
            row = super().fetchone()
        except BaseException:
            self._release_use()
            raise
        if row is None:
            self._release_use()
        return row

    def fetchmany(self, size: int | None = None) -> list[object]:
        """Release the reservation when a batch proves exhaustion."""

        requested = self.arraysize if size is None else size
        try:
            rows = super().fetchmany(requested)
        except BaseException:
            self._release_use()
            raise
        if not rows or (requested > 0 and len(rows) < requested):
            self._release_use()
        return rows

    def fetchall(self) -> list[object]:
        """Release the reservation after consuming every remaining row."""

        try:
            return super().fetchall()
        finally:
            self._release_use()

    def __next__(self) -> object:
        try:
            return super().__next__()
        except StopIteration:
            self._release_use()
            raise
        except BaseException:
            self._release_use()
            raise

    def close(self) -> None:
        """Release the reservation even if native close reports an error."""

        try:
            super().close()
        finally:
            self._release_use()

    def __del__(self) -> None:
        connection = getattr(self, "_quiescent_connection", None)
        token = getattr(self, "_quiescence_token", None)
        try:
            if connection is not None:
                self._quiescence_token = None
                connection._end_cursor_use(token)
        finally:
            # A caller's composed cursor type comes after this one in the MRO
            # and may have its own cleanup (Qodo, #2894).
            finalize = getattr(super(), "__del__", None)
            if finalize is not None:
                finalize()


@functools.lru_cache(maxsize=64)
def _tracked_cursor_type(factory: type[sqlite3.Cursor]) -> type[sqlite3.Cursor]:
    """Return ``factory`` combined with ``_QuiescentSQLiteCursor``.

    Args:
        factory: The cursor type a caller asked for.

    Returns:
        ``factory`` itself when it is already tracked, the tracked cursor for
        a plain ``sqlite3.Cursor``, otherwise a subclass of both with the
        tracked cursor first, so its statement methods bracket the caller's
        overrides even when those skip ``super()``.

    Raises:
        TypeError: ``factory`` is not a ``sqlite3.Cursor`` subclass, or it is
            a tracked subclass that replaces a statement method (the tracked
            cursor cannot be put ahead of its own subclass). Either cannot be
            made tracked, so refusing fails closed.
    """

    if not (isinstance(factory, type) and issubclass(factory, sqlite3.Cursor)):
        raise TypeError("cursor factory must be a sqlite3.Cursor subclass")
    if issubclass(factory, _QuiescentSQLiteCursor):
        if any(
            getattr(factory, name) is not getattr(_QuiescentSQLiteCursor, name)
            for name in ("execute", "executemany", "executescript")
        ):
            raise TypeError(
                "a tracked cursor subclass may not replace execute, "
                "executemany or executescript"
            )
        return factory
    if issubclass(_QuiescentSQLiteCursor, factory):
        return _QuiescentSQLiteCursor
    return type(f"_Quiescent{factory.__name__}", (_QuiescentSQLiteCursor, factory), {})

class _SemanticMutationAuthorization:
    """Connection-local authorization read by SQLite mutation triggers.

    The registered SQLite callback consults only this Python object. It never
    executes SQL, avoiding recursive use of a connection from within a trigger.
    """

    def __init__(self, connection: sqlite3.Connection) -> None:
        self._connection = connection
        self._message_id: str | None = None
        self._operations: frozenset[str] = frozenset()
        self._transaction_generation = 0
        self._authorized_generation: int | None = None
        self._trace_gc_lease_id: str | None = None
        self._trace_gc_marked_epoch: int | None = None
        self._trace_gc_generation: int | None = None

    def trace_transaction(self, statement: str) -> None:
        """Advance connection-local identity at transaction boundaries.

        Fallback for connections that cannot report boundaries themselves;
        managed connections use :meth:`observe_transaction_boundary`.
        """

        operation = statement.lstrip().split(None, 1)[0].upper()
        if operation in {"BEGIN", "COMMIT", "ROLLBACK"}:
            self._transaction_generation += 1

    def observe_transaction_boundary(self) -> None:
        """Advance connection-local identity: the transaction may have changed."""

        self._transaction_generation += 1

    def sqlite_authorizer(
        self,
        action: int,
        argument1: str | None,
        argument2: str | None,
        database: str | None,
        trigger: str | None,
    ) -> int:
        """Deny transaction escape while a mutation scope is active."""

        del argument2, database, trigger
        if (self._message_id is not None or self._trace_gc_lease_id is not None) and (
            (
                action == sqlite3.SQLITE_TRANSACTION
                and (argument1 or "").upper() in {"COMMIT", "ROLLBACK"}
            )
            or (
                action == sqlite3.SQLITE_SAVEPOINT
                and (argument1 or "").upper() in {"RELEASE", "ROLLBACK"}
            )
        ):
            return sqlite3.SQLITE_DENY
        return sqlite3.SQLITE_OK

    @contextmanager
    def _authorize(
        self,
        *,
        message_id: str,
        operations: Collection[str],
    ) -> Iterator[None]:
        """Authorize one coordinator-owned mutation scope on this connection."""

        if not self._connection.in_transaction:
            raise RuntimeError("caller_transaction_required")
        if self._message_id is not None:
            raise RuntimeError("semantic_mutation_authorization_already_active")
        if type(message_id) is not str or not message_id:
            raise ValueError("message_id")
        normalized = frozenset(operations)
        if not normalized or any(
            type(item) is not str or not item for item in normalized
        ):
            raise ValueError("operations")
        self._message_id = message_id
        self._operations = normalized
        self._authorized_generation = self._transaction_generation
        try:
            yield
        finally:
            self._clear()

    def _clear(self) -> None:
        """Clear authorization without retaining mutation identity."""

        self._message_id = None
        self._operations = frozenset()
        self._authorized_generation = None

    def _sqlite_authorized(self, message_id: object, operation: object) -> int:
        """Return one only for the active message and allowlisted operation."""

        return int(
            type(message_id) is str
            and type(operation) is str
            and message_id == self._message_id
            and operation in self._operations
            and self._connection.in_transaction
            and self._authorized_generation == self._transaction_generation
        )

    def _assert_current_transaction(self) -> None:
        """Reject a callback that escaped the authorized transaction."""

        if (
            not self._connection.in_transaction
            or self._authorized_generation != self._transaction_generation
        ):
            raise RuntimeError("semantic_mutation_transaction_changed")

    @contextmanager
    def _authorize_trace_gc_deletion(
        self,
        cursor: sqlite3.Cursor,
        *,
        lease_id: str,
        marked_epoch: int,
    ) -> Iterator[None]:
        """Grant deletion only to the exact validated sweep transaction."""

        if cursor.connection is not self._connection:
            raise RuntimeError("trace_gc_connection_mismatch")
        if not self._connection.in_transaction:
            raise RuntimeError("caller_transaction_required")
        if self._trace_gc_lease_id is not None or self._message_id is not None:
            raise RuntimeError("trace_gc_authorization_already_active")
        if type(lease_id) is not str or not lease_id:
            raise ValueError("lease_id")
        if type(marked_epoch) is not int or marked_epoch < 0:
            raise ValueError("marked_epoch")
        row = cursor.execute(
            """SELECT maintenance.state, maintenance.lease_id,
                      maintenance.marked_epoch, epoch.epoch,
                      julianday(maintenance.lease_expires_at) > julianday('now')
                 FROM console_trace_maintenance_state AS maintenance
                 JOIN console_trace_graph_epoch AS epoch
                   ON epoch.singleton_id = maintenance.singleton_id
                WHERE maintenance.singleton_id = 1"""
        ).fetchone()
        if row is None or tuple(row) != (
            "sweeping",
            lease_id,
            marked_epoch,
            marked_epoch,
            1,
        ):
            raise RuntimeError("trace_gc_epoch_or_lease_mismatch")
        self._trace_gc_lease_id = lease_id
        self._trace_gc_marked_epoch = marked_epoch
        self._trace_gc_generation = self._transaction_generation
        try:
            yield
        finally:
            self._trace_gc_lease_id = None
            self._trace_gc_marked_epoch = None
            self._trace_gc_generation = None

    def _sqlite_trace_gc_delete_authorized(self, entity_kind: object) -> int:
        """Return one only inside the exact collector-owned sweep scope."""

        return int(
            type(entity_kind) is str
            and bool(entity_kind)
            and self._trace_gc_lease_id is not None
            and self._trace_gc_marked_epoch is not None
            and self._connection.in_transaction
            and self._trace_gc_generation == self._transaction_generation
        )


def register_semantic_mutation_guard(
    connection: sqlite3.Connection,
) -> _SemanticMutationAuthorization:
    """Register the fail-closed semantic mutation guard on one connection."""

    authorization = _SemanticMutationAuthorization(connection)
    connection.create_function(
        SEMANTIC_MUTATION_GUARD_FUNCTION,
        2,
        authorization._sqlite_authorized,
    )
    connection.create_function(
        TRACE_GC_DELETE_GUARD_FUNCTION,
        1,
        authorization._sqlite_trace_gc_delete_authorized,
    )
    if isinstance(connection, _QuiescentSQLiteConnection):
        # PERF-04 (TASK-33263): no trace callback. On Python 3.12 it receives
        # the expanded SQL, so SQLite hex-rendered every bound BLOB per
        # statement and trigger step (a 3 MiB image insert took ~1.2 s).
        connection.set_transaction_boundary_listener(
            authorization.observe_transaction_boundary
        )
    else:
        connection.set_trace_callback(authorization.trace_transaction)
    connection.set_authorizer(authorization.sqlite_authorizer)
    return authorization


class BaseDB(ABC):
    """
    Base class for all database modules providing standardized path handling.

    This class ensures consistent handling of:
    - Union[str, Path] type for db_path
    - Special ':memory:' case for in-memory databases
    - Client ID for multi-client support
    - Private file connection enforcement
    """

    def __init__(
        self,
        db_path: Union[str, Path],
        client_id: str = "default",
        check_integrity_on_startup: bool = False,
        *,
        initialize_schema: bool = True,
    ):
        """
        Initialize the base database with standardized path handling.

        Args:
            db_path: Path to the SQLite database file or ':memory:'
            client_id: Client identifier for multi-client support
            check_integrity_on_startup: Whether to run integrity check on startup
            initialize_schema: Whether to initialize the subclass schema
        """
        # Standardized path handling
        if isinstance(db_path, Path):
            self.is_memory_db = False
            self.db_path = lexical_path(db_path)
        else:
            self.is_memory_db = db_path == ":memory:"
            if self.is_memory_db:
                self.db_path = Path(":memory:")  # Symbolic Path for consistency
            else:
                self.db_path = lexical_path(db_path)

        # Store string representation for SQLite connection
        self.db_path_str = ":memory:" if self.is_memory_db else str(self.db_path)

        # Store client ID
        self.client_id = client_id

        # Initialize schema (implemented by subclasses)
        if initialize_schema:
            self._initialize_schema()

        # Run integrity check if requested
        if initialize_schema and check_integrity_on_startup and not self.is_memory_db:
            logger.info(
                f"Running startup integrity check for {self.__class__.__name__}"
            )
            if not self.check_integrity():
                logger.warning(
                    f"Database integrity check failed for {self.db_path_str}. "
                    "Consider running repairs or restoring from backup."
                )
                # Note: We don't raise an exception here to allow the app to continue
                # with potentially degraded functionality. Subclasses can override
                # this behavior if they need stricter integrity enforcement.

        logger.info(
            f"{self.__class__.__name__} initialized with path: {self.db_path_str} [Client: {self.client_id}]"
        )

    @abstractmethod
    def _initialize_schema(self):
        """
        Initialize the database schema.
        Must be implemented by subclasses.
        """
        pass

    def _get_connection(self, **connect_kwargs: Any) -> sqlite3.Connection:
        """
        Get a database connection with row factory.
        Can be overridden by subclasses for custom connection handling.

        Args:
            **connect_kwargs: Passed through to ``sqlite3.connect`` by the
                private connector (a subclass that holds one connection
                per thread and must be able to close them all asks for
                ``check_same_thread=False``). The connection is still
                opened HERE, under this module's ``db.base`` owner.
        """
        conn = connect_private_sqlite(
            "db.base", self.db_path_str, **connect_kwargs)
        conn.row_factory = sqlite3.Row
        return conn

    def close(self):
        """
        Close database connections if needed.
        Can be overridden by subclasses.
        """
        pass

    def vacuum(self):
        """
        Vacuum the database to reclaim unused space and optimize performance.
        """
        if self.is_memory_db:
            logger.debug("Skipping vacuum for in-memory database")
            return

        try:
            conn = self._get_connection()
            conn.execute("VACUUM")
            conn.close()
            logger.info(f"Successfully vacuumed database: {self.db_path_str}")
        except Exception as e:
            logger.error(f"Failed to vacuum database: {e}")
            raise

    def check_integrity(self) -> bool:
        """
        Check the integrity of the database.

        Returns:
            bool: True if integrity check passes, False otherwise
        """
        try:
            conn = self._get_connection()
            cursor = conn.cursor()
            cursor.execute("PRAGMA integrity_check")
            result = cursor.fetchone()
            conn.close()

            is_ok = result and result[0] == "ok"
            if is_ok:
                logger.info(f"Database integrity check passed: {self.db_path_str}")
            else:
                logger.error(f"Database integrity check failed: {self.db_path_str}")

            return is_ok
        except Exception as e:
            logger.error(f"Failed to check database integrity: {e}")
            return False


# Defining callbacks consumed by the optional finite Character display only.
_CHARACTER_REFRESH_READERS = tuple(
    (
        None,
        name,
        descriptor,
        function,
        function.__code__,
        function.__globals__,
        function.__defaults__,
        function.__kwdefaults__,
        tuple((function.__kwdefaults__ or {}).items()),
        function.__closure__,
        tuple((cell, cell.cell_contents) for cell in function.__closure__ or ()),
        __file__,
        __spec__,
        getattr(__spec__, "origin", None),
    )
    for name in ("run_owned_db_call",)
    for descriptor in (globals()[name],)
    for function in (
        descriptor.__func__ if isinstance(descriptor, staticmethod) else descriptor,
    )
)
