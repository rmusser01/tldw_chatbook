import difflib
import hashlib
import json
from pathlib import Path
import subprocess
repo=Path('/Users/macbook-dev/.codex/worktrees/agent-recovery-error/tldw_chatbook')
python='/Users/macbook-dev/Documents/GitHub/tldw_chatbook/.venv/bin/python'
base='6feb84c1d2203bc3c6d0eecd2823f4e2409b4b4e'
files=['tldw_chatbook/Backup_Recovery/'+n+'.py' for n in ['admission','config_participants','generation_witnesses','raw_participants','storage_admission']]
result={'base':base,'cwd':str(repo),'production':{},'new_files':{},'qualification':'Difference-aware static control; repository pre-existing diagnostics are not repaired or certified.'}
for name in files:
    old=subprocess.run(['git','show',base+':'+name],cwd=repo,check=True,capture_output=True).stdout
    current=(repo/name).read_bytes()
    rows={}
    for label,data in [('baseline',old),('final',current)]:
        r=subprocess.run([python,'-m','ruff','check','--no-cache','--output-format','json','--stdin-filename',str(repo/name),'-'],cwd=repo,input=data,capture_output=True)
        rows[label]={'exit_code':r.returncode,'source_sha256':hashlib.sha256(data).hexdigest(),'diagnostics':json.loads(r.stdout)}
    def normalized(row,data):
        lines=data.decode().splitlines()
        return sorted((d['code'],d['message'],lines[d['location']['row']-1].strip()) for d in row['diagnostics'])
    rows['unchanged_diagnostics']=normalized(rows['baseline'],old)==normalized(rows['final'],current)
    assert rows['unchanged_diagnostics'], name
    result['production'][name]=rows
for name in ['Tests/Backup_Recovery/test_guarded_raw_evidence_reuse.py','Docs/superpowers/qa/2026-10-06-task33560-raw-evidence/boot_idle_probe.py']:
    rows={}
    for label,args in [('lint',['check','--output-format','json']),('format',['format','--check'])]:
        r=subprocess.run([python,'-m','ruff',*args,'--no-cache',str(repo/name)],cwd=repo,capture_output=True,text=True)
        rows[label]={'exit_code':r.returncode,'stdout':r.stdout,'stderr':r.stderr}
        assert r.returncode==0, (name,label,r.stdout)
    result['new_files'][name]=rows
r=subprocess.run(['git','diff','--check'],cwd=repo,capture_output=True,text=True)
assert r.returncode==0
result['diff_check']={'exit_code':r.returncode,'stdout':r.stdout,'stderr':r.stderr}
result['production_range_format']='All changed function ranges formatted with ruff; whole production files retain prior formatting outside those ranges.'
Path('/private/tmp/task33560-final-static-receipt.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({'baseline_diagnostics':sum(len(v['baseline']['diagnostics']) for v in result['production'].values()),'final_diagnostics':sum(len(v['final']['diagnostics']) for v in result['production'].values()),'unchanged':True,'new_file_lint_format':'pass','diff_check':'pass'}))
