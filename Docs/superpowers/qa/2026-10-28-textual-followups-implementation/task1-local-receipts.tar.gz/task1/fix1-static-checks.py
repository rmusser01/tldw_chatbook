import ast
import hashlib
import json
import subprocess
import sys
from collections import Counter
from pathlib import Path

root = Path.cwd()
base = 'fe84f97f1dc5db73e532b6bdcad2c5b8379d55f3'
owned = ['tldw_chatbook/UI/Evals/character_bench_editor.py',
         'tldw_chatbook/UI/Screens/evals_screen.py',
         'Tests/UI/test_evals_character_bench_save_publication.py',
         'Docs/Architecture/evals.md']
commands = [[sys.executable,'-m','ruff','check',*owned[:3]],
            [sys.executable,'-m','ruff','format','--check',*owned[:3]],
            ['git','diff','--check','--',*owned],
            ['git','diff','--exit-code',base,'--',owned[1],
             'tldw_chatbook/UI/Evals/bench_editor.py',
             'Tests/UI/test_component_pattern_governance.py','tldw_chatbook/css']]
results = []
for args in commands:
    p = subprocess.run(args,capture_output=True,text=True,encoding='utf-8')
    results.append(dict(args=args,returncode=p.returncode,stdout=p.stdout,stderr=p.stderr))
sources = [dict(path=name,sha256=hashlib.sha256((root/name).read_bytes()).hexdigest(),
                lines=len((root/name).read_text(encoding='utf-8').splitlines())) for name in owned]
pins = json.loads((root/'.test-tmp/textual-37266-37268/task1/fix1-final-sources.json').read_text(encoding='utf-8-sig'))
assert all(p['sha256'].lower() == s['sha256'] for p,s in zip(pins,sources))
tested = json.loads((root/'.test-tmp/textual-37266-37268/task1/fix1-green-sources.json').read_text(encoding='utf-8-sig'))
assert all(p['sha256'].lower() == s['sha256'] for p,s in zip(tested[:3],sources[:3]))
def classes(source):
    return Counter(n.value.value for n in ast.walk(ast.parse(source)) if isinstance(n,ast.keyword)
                   and n.arg == 'classes' and isinstance(n.value,ast.Constant) and isinstance(n.value.value,str))
class_changes = []
for name in owned[:2]:
    previous = subprocess.run(['git','show',base+':'+name],capture_output=True,check=True).stdout.decode('utf-8')
    additions = dict(classes((root/name).read_text(encoding='utf-8'))-classes(previous))
    class_changes.append(dict(path=name,added_class_literals=additions))
data = dict(fix_base=base,commands=results,sources=sources,added_classes=class_changes,
            runtime_python_sources_match_executed_green=True,
            documentation_only_clarification_after_green='No private watcher list is edited directly; public watch registration remains used.')
out = root/'.test-tmp/textual-37266-37268/task1/fix1-static-checks.json'
out.write_text(json.dumps(data,indent=2),encoding='utf-8')
print(json.dumps(data,indent=2))
assert not any(c['added_class_literals'] for c in class_changes)
assert sources[1]['lines'] == 4211
assert all(r['returncode'] == 0 for r in results)
