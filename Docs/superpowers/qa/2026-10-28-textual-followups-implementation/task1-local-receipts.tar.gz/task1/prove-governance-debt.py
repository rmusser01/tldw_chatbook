import ast
import hashlib
import json
import subprocess
from collections import Counter
from pathlib import Path

root = Path.cwd()
base = 'cc18b42ee8a8bea3d43c77e602eabdb245932f49'
files = [
    'Tests/UI/test_component_pattern_governance.py',
    'tldw_chatbook/css/patterns.json',
    'tldw_chatbook/css/components/_forms.tcss',
]
proof = []
for name in files:
    blob = subprocess.run(['git', 'show', f'{base}:{name}'], capture_output=True, check=True)
    result = subprocess.run(['git', 'cat-file', '--filters', f'{base}:{name}'], capture_output=True, check=True)
    current = (root/name).read_bytes()
    proof.append(dict(path=name, base_blob_sha256=hashlib.sha256(blob.stdout).hexdigest(),
                      base_windows_checkout_sha256=hashlib.sha256(result.stdout).hexdigest(),
                      current_sha256=hashlib.sha256(current).hexdigest(),
                      exact_bytes_unchanged=current == result.stdout))
diff_args = ['git', 'diff', '--exit-code', base, '--', files[0], 'tldw_chatbook/css']
diff = subprocess.run(diff_args, capture_output=True, text=True)
registry = json.loads((root/files[1]).read_text(encoding='utf-8'))
forms = next(f for f in registry['families'].values() if 'form-label' in f['classes'])
owner = forms['classes']['form-label'].get('owning_sheet', forms['owning_sheet'])
css_root = root/'tldw_chatbook/css'
actual = str((css_root/owner).relative_to(css_root))

def class_literals(source):
    return Counter(node.value.value for node in ast.walk(ast.parse(source))
                   if isinstance(node, ast.keyword) and node.arg == 'classes'
                   and isinstance(node.value, ast.Constant) and isinstance(node.value.value, str))

class_changes = []
for name in ['tldw_chatbook/UI/Evals/character_bench_editor.py', 'tldw_chatbook/UI/Screens/evals_screen.py']:
    before = subprocess.run(['git', 'show', f'{base}:{name}'], capture_output=True, check=True).stdout.decode('utf-8')
    after = (root/name).read_text(encoding='utf-8')
    class_changes.append(dict(path=name, added_class_keyword_literals=dict(class_literals(after)-class_literals(before))))
data = dict(base=base, exact_input_proof=proof,
            whole_test_and_css_diff=dict(args=diff_args, exit_code=diff.returncode, stdout=diff.stdout, stderr=diff.stderr),
            path_comparison=dict(registry_owner=owner, actual_sheet_source_key=actual,
                                 direct_equality=actual == owner,
                                 same_owner_with_posix_separators=actual.replace('\\', '/') == owner),
            owned_class_literal_changes=class_changes)
out = root/'.test-tmp/textual-37266-37268/task1/governance-debt-proof.json'
out.write_text(json.dumps(data, indent=2), encoding='utf-8')
print(json.dumps(data, indent=2))
assert all(p['exact_bytes_unchanged'] for p in proof)
assert diff.returncode == 0
assert actual != owner and actual.replace('\\', '/') == owner
assert all(not c['added_class_keyword_literals'] for c in class_changes)
