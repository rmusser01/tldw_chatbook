import hashlib
import json
from pathlib import Path

root = Path.cwd()
evidence = root/'.test-tmp/textual-37266-37268/task1'
def read(run):
    return json.loads((evidence/run/'inspection.json').read_text(encoding='utf-8'))
new_run = read('UNIQUE-task1-final-01')
controls = read('UNIQUE-task1-controls-01')
probe = read('UNIQUE-task1-control-probe-01')
new = [c for c in new_run['reports'][0]['cases']
       if c['classname'] == 'Tests.UI.test_evals_character_bench_save_publication']
governance = [c for c in controls['reports'][0]['cases']
              if c['classname'] in {'Tests.Architecture.test_module_size_ratchet',
                                    'Tests.UI.test_design_token_governance',
                                    'Tests.UI.test_component_pattern_governance'}]
behavior = [c for c in controls['reports'][0]['cases'] if c not in governance]+probe['reports'][0]['cases']
assert len(new) == 20 and not any(c['failures'] or c['skips'] for c in new)
assert len(behavior) == 24 and not any(c['failures'] or c['skips'] for c in behavior)
assert len(governance) == 5 and sum(bool(c['failures']) for c in governance) == 1
assert next(c for c in governance if c['failures'])['name'] == 'test_canonical_classes_defined_only_in_owning_sheet'
sources = json.loads((evidence/'final-sources.json').read_text(encoding='utf-8-sig'))
for source in sources:
    source['current_sha256'] = hashlib.sha256((root/source['path']).read_bytes()).hexdigest()
    source['unchanged_since_final_snapshot'] = source['current_sha256'].lower() == source['sha256'].lower()
assert all(s['unchanged_since_final_snapshot'] for s in sources)
summary = dict(status='DONE_WITH_CONCERNS', new_regressions=dict(total=20, passed=20),
    existing_behavior_controls=dict(total=24, passed=24, profile='supported bootstrap_profile replay for selected legacy non-private cases'),
    governance=dict(total=5, passed=4, failed=1, failures=[c for c in governance if c['failures']]),
    default_legacy_setup_error=[c for c in new_run['reports'][0]['cases'] if c['failures']],
    fully_green_default_batch=False, hosted_gate_verified=False, sources=sources,
    evidence_runs=['UNIQUE-task1-final-01','UNIQUE-task1-control-probe-01','UNIQUE-task1-controls-01'])
(evidence/'final-summary.json').write_text(json.dumps(summary,indent=2),encoding='utf-8')
print(json.dumps(dict(status=summary['status'], new=summary['new_regressions'],
                     behavior=summary['existing_behavior_controls'],
                     governance=dict(total=5,passed=4,failed=1),
                     all_final_source_hashes_match=True),indent=2))
