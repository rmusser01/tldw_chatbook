import hashlib
import importlib.metadata
import json
import sys
from pathlib import Path

package = Path(sys.executable).parent.parent/'Lib/site-packages/textual'
ranges = {'reactive.py': [(87,122),(398,414)],
          'screen.py': [(229,229),(1097,1143)],
          'message_pump.py': [(527,537)]}
records = []
for name, spans in ranges.items():
    path = package/name
    lines = path.read_text(encoding='utf-8').splitlines()
    records.append(dict(path=str(path), sha256=hashlib.sha256(path.read_bytes()).hexdigest(),
        excerpts=[dict(start=start,end=end,text='\n'.join(lines[start-1:end])) for start,end in spans]))
data = dict(textual_version=importlib.metadata.version('textual'), sources=records,
    conclusions=[
        'Synchronous watch callbacks execute inline at the reactive assignment; awaitables alone defer.',
        'Screen.focused is reactive and set_focus assigns it synchronously before posting Focus.',
        'Message-pump retirement sets _closing True.',
        'External global watches hold owner/callback references and prune closing owners on the next change.',
        'No immediate unregistration is claimed; no private watcher list was inspected or modified.',
        'The ordinary native Save control checks the retired revision stays fixed after a subsequent focus change.'
    ])
out = Path.cwd()/'.test-tmp/textual-37266-37268/task1/fix1-watch-lifetime.json'
out.write_text(json.dumps(data,indent=2),encoding='utf-8')
print(json.dumps(dict(textual_version=data['textual_version'],sources=[dict(path=r['path'],sha256=r['sha256']) for r in records]),indent=2))
