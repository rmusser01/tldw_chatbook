import hashlib
import json
import subprocess
import sys
from pathlib import Path

root = Path.cwd()
owned = [
    'tldw_chatbook/UI/Evals/character_bench_editor.py',
    'tldw_chatbook/UI/Screens/evals_screen.py',
    'Tests/UI/test_evals_character_bench_save_publication.py',
    'Docs/Architecture/evals.md',
]
commands = [
    [sys.executable, '-m', 'ruff', 'check', *owned[:3]],
    [sys.executable, '-m', 'ruff', 'format', '--check', *owned[:3]],
    ['git', 'diff', '--check', '--', *owned],
]
results = []
for args in commands:
    process = subprocess.run(args, cwd=root, capture_output=True, text=True, encoding='utf-8')
    results.append(dict(args=args, returncode=process.returncode, stdout=process.stdout, stderr=process.stderr))
data = dict(commands=results, sources=[dict(path=p, lines=len((root/p).read_text(encoding='utf-8').splitlines()),
    sha256=hashlib.sha256((root/p).read_bytes()).hexdigest()) for p in owned])
dest = root / '.test-tmp/textual-37266-37268/task1/static-checks.json'
dest.write_text(json.dumps(data, indent=2), encoding='utf-8')
print(json.dumps(data, indent=2))
sys.exit(any(r['returncode'] for r in results))
