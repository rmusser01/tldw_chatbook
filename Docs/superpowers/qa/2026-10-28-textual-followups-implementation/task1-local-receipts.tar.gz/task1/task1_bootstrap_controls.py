"""Replay only selected legacy controls using the supported private bootstrap profile.

This does not replace any fixture, guard or test body. Source-bound config
consumers keep the collection-time private profile for their interpreter lifetime.
"""

import json
from pathlib import Path

import pytest


def pytest_collection_modifyitems(items):
    selectors = json.loads((Path(__file__).parent / 'control-selectors.json').read_text())
    for item in items:
        if getattr(item.obj, '_private_profile_test', False):
            continue
        if any(item.nodeid == selected or item.nodeid.startswith(selected+'[')
               for selected in selectors):
            item.add_marker(pytest.mark.bootstrap_profile)
