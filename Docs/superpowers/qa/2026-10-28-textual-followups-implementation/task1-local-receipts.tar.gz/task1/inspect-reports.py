"""Retain and inspect the actual launcher parent and private child JUnit."""

import hashlib
import json
import shutil
import sys
import xml.etree.ElementTree as ET
from pathlib import Path

root = Path.cwd()
run = root / '.test-tmp/textual-37266-37268' / sys.argv[1]
receipt = json.loads((run / 'verification.json').read_text(encoding='utf-8'))
out = root / '.test-tmp/textual-37266-37268/task1' / run.name
out.mkdir(exist_ok=True)
reports = []
for index, report in enumerate(receipt['reports']):
    source = Path(report['path'])
    dest = out / f'{index:02d}-{source.name}'
    shutil.copyfile(source, dest)
    cases = []
    for case in ET.parse(source).iter('testcase'):
        cases.append(dict(
            name=case.get('name'), classname=case.get('classname'),
            total_seconds=float(case.get('time', '0')),
            failures=[dict(kind=c.tag, message=c.get('message'), text=c.text)
                      for c in case if c.tag in ('failure', 'error')],
            skips=[c.get('message') for c in case if c.tag == 'skipped'],
        ))
    log = run / 'run.log' if source.name == 'result.xml' else source.with_name('pytest.log')
    durations = []
    warnings = []
    if log.exists():
        shutil.copyfile(log, out / f'{index:02d}-pytest.log')
        lines = log.read_text(encoding='utf-8', errors='replace').splitlines()
        durations = [line for line in lines if 's setup ' in line or 's call ' in line or 's teardown ' in line]
        warnings = sorted(set(line.strip() for line in lines if 'Warning:' in line or '| WARNING ' in line))
    reports.append(dict(original=str(source), retained=str(dest),
                        sha256=hashlib.sha256(source.read_bytes()).hexdigest(),
                        cases=cases, durations=durations, warnings=warnings))
shutil.copyfile(run / 'command.json', out / 'command.json')
shutil.copyfile(run / 'verification.json', out / 'verification.json')
shutil.copyfile(run / 'run.log', out / 'run.log')
summary = dict(run=run.name, exit_code=receipt['exit_code'], reports=reports)
(out / 'inspection.json').write_text(json.dumps(summary, indent=2), encoding='utf-8')
print(json.dumps(dict(run=run.name, exit_code=receipt['exit_code'],
    reports=[dict(path=r['retained'], sha256=r['sha256'],
                  cases=[dict(name=c['name'], total_seconds=c['total_seconds'],
                              failures=[(f['message'] or '').splitlines()[0] for f in c['failures']], skips=c['skips'])
                         for c in r['cases']], durations=r['durations'])
             for r in reports]), indent=2))
