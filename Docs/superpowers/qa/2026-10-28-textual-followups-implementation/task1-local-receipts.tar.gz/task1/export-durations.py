import json
import sys
from pathlib import Path

evidence = Path.cwd() / '.test-tmp/textual-37266-37268/task1'
data = json.loads((evidence/sys.argv[1]/'inspection.json').read_text(encoding='utf-8'))
parent = next(r for r in data['reports'] if r['original'].endswith('result.xml'))
children = {c['classname']+'::'+c['name']: (c, r) for r in data['reports']
            if r['original'].endswith('pytest.xml') for c in r['cases']}
rows = []
for case in parent['cases']:
    if case['classname'] != 'Tests.UI.test_evals_character_bench_save_publication':
        continue
    child, report = children[case['classname']+'::'+case['name']]
    nodeid = case['classname'].replace('.', '/')+'.py::'+case['name']
    rows.append(dict(nodeid=nodeid, parent_total_seconds=case['total_seconds'],
        child_total_seconds=child['total_seconds'], parent_xml=parent['retained'],
        parent_xml_sha256=parent['sha256'], child_xml=report['retained'],
        child_xml_sha256=report['sha256'],
        parent_phases=[line for line in parent['durations'] if line.endswith(nodeid)],
        child_phases=report['durations']))
path = evidence / ('new-case-durations-'+sys.argv[1]+'.json')
path.write_text(json.dumps(rows, indent=2), encoding='utf-8')
print(json.dumps(dict(output=str(path), cases=len(rows),
    parent_total_seconds=sum(r['parent_total_seconds'] for r in rows),
    child_total_seconds=sum(r['child_total_seconds'] for r in rows),
    parent_max=max(r['parent_total_seconds'] for r in rows)), indent=2))
