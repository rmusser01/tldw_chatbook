# PR3290 native failure review

Reviewed head: `66090f00733618c51857af8b7fd5dd626df61f36`; current dev: `dcdb2249294c60c5b660011e8d7b0f3c8babb28c`; original reviewed source: `188fe0fc92dfd64ddb70f3fc890919640f77d036`.

Read-only investigation using requesting-code-review and systematic-debugging. No test execution, collection, project imports, subagents, source changes, Git changes, or profile/provider access. Only this report was written. Parent-owned unrelated-worker cancellation, premature context focus and Windows separator fixes were excluded.

## Evidence provenance

Inspected `test-runtime/remaining-native-1793491137592994500/{command.json,head.txt,source-hashes.json,result.xml,pytest.log}`. The command launches the real `Tests.windows_private_fixture_runner`, which changes/restores native TokenOwner and delegates to pytest; it does not bypass source admission or supply a separate config fixture. Parent outcome is 7 failed / 9 passed. The four assigned cases execute directly in this parent: the three link modules carry `bootstrap_profile`, and none of these four nodes has `private_profile_test`. Their parent XML/log is therefore the actual execution evidence, not merely a child launcher result.

The five relevant current test/helper files match the receipt SHA256s when CRLF is normalized to LF (raw filesystem byte hashes differ only for that reason). The helper digest is `bb264481f7d17917143b99f636139fd01260b121ea09d859fb0cc5557a5d9185`. Current source was compared with immutable Git objects using explicit cwd and safe.directory. No diff against current dev exists for `library_screen.py`, `library_notes_controller.py`, or `library_notes_canvas.py`; these current presentation/navigation owners are inherited, not PR3290 product edits. This alone does not establish that a failing runtime behavior is harmless or passing on dev.

## Finding 1: legacy export setup changes an already-bound config source

**Certainty: established; fixture failure, before export.**

`test_library_shell.py:22910` has only `pytest.mark.asyncio`. It has neither the per-node `bootstrap_profile` marker nor `private_profile_test`. `Tests/conftest.py:1336` retains the collection-time private profile only for opted-in nodes/families; this exact shell node is not opted in. The normal redirect then points its config at the case's `test_data/config/config.toml`.

The recorded stack is `_build_test_app` -> `app_factory.build_test_app_config:125` -> real `load_settings` -> config participant scope -> `_register_raw_participant`, which rejects `state.selected != selected` with `raw_source_selection_changed`. It fails at app creation, so no export content, worker, publication, or notification assertion executes. Collection-time source registration is expected here: root conftest deliberately initializes guarded config consumers before per-test redirects, and the shared app factory imports the config loader.

**Minimal correction:** mark this exact export-content node `pytest.mark.bootstrap_profile`. It does not intentionally select or test another config source; its output remains tmp_path-owned. This uses the existing private bootstrap fixture/restoration contract and leaves all production admission guards enabled. Do not clear participant registries, fake `load_settings`, change native custody, or enroll the whole legacy file. A private-profile child is an alternative only if this node demonstrably needs durable per-case config isolation; current behavior does not require it.

Re-run the exact node afterward. Its original export assertions still need qualification; this failure supplies no export verdict.

## Finding 2: all three link tests proceed past a failed source snapshot as if setup were ready

**Certainty: source failures and readiness mismatch established. Exact final failing predicate was not logged; keyboard causality beyond setup remains to be qualified.**

Actual `pytest.log` contains these source failures before the helper timeouts:

- Keyboard: line4393, 17:07:41.570, and line5405, 17:08:06.012: `Failed to load local Library source snapshot. (deadline: waited 5 s)`.
- Extended Preview: line7654, 17:09:47.807: same deadline.
- Mouse Preview: line8882, 17:10:59.254: same deadline.

`library_quit_guard_support._library:160` delegates to `test_library_shell._wait_for_library_shell:3839`. That wait only requires `_library_loaded` and a mounted rail, then two pauses. It does not require `_library_lookup_error is None`. Production explicitly considers these distinct states: `_apply_source_snapshot_timeout:13652` publishes a loaded placeholder plus error; the real snapshot gather's TimeoutError branch at `library_screen.py:14089` returns recovery state with the real Retry. Notes compose at `library_screen.py:15765` chooses `_library_canvas_error_widget()` when lookup_error is set, instead of constructing `#library-notes-canvas`. Production elsewhere uses `loaded AND no lookup_error` for real source readiness.

The log corroborates missing Notes ownership, not merely slow text painting:

- Keyboard contains seven `NoMatches` failures for `#library-notes-canvas` at log lines4625,5403,5671,6096,6206,6458,6660. The first comes from `_begin_library_note_create`; the second from `_create_library_note` calling `_sync_library_canvas(..., then=finish_create_projection)`. These are real setup/create projection failures, swallowed into fallback recomposition.
- Extended Preview line7937 and mouse Preview line9181 show the same missing canvas from `_load_library_notes_trash` -> `_sync_library_canvas`.

For both Preview cases, the exact XML stack fails on their FIRST `_open_note(INDEX, ...)` inside `_open_notes`, before any Preview, Enter, painted-link click, or URL assertion. `_notes_tree_publication` requires exactly the retained Notes list and Work owners. A recovery surface with no Notes list cannot satisfy that condition. Increasing its timeout or deleting its DOM guards does not create a valid setup.

For the keyboard case, `_new_blank_note` and the initial title-focus check completed, but the exact title value after `_type(VERIFIER)` never matched. The receipt does not include actual title, focused widget, current editor identity, or pending recompose state. Repeated missing-canvas/create-projection errors make proceeding without healthy source setup invalid. They do not prove the final keystroke-loss mechanism, and this review does not relabel a possible product typing bug as fixed.

**Minimal bounded fixture correction:** add healthy-source preparation local to the link harness, before selecting Notes or Create. Require `_library_loaded AND _library_lookup_error is None`, then the current live route DOM. On the recorded recoverable source error, await the actual `#library-source-retry` publication, press that real Button, and await either successful current-source settlement or a new failure; use a fixed small number of attempts and preserve the original test deadline/behavior assertions. The existing export `_ready_note` demonstrates the real-control recovery approach. Do not copy its broad `workers.wait_for_complete`: replacement workers can be legitimately canceled (parent is separately addressing that). Wait for the specific source generation/observable result and mounted current owner instead. Do not reset error fields, fabricate snapshots, bypass database services, or extend production timeouts.

All link test modules already have `bootstrap_profile`; adding it again or changing the native runner cannot repair these source/DOM setup failures. Keep real DB note identities, actual keyboard/click actions, current DOM/row identity checks, URL recorders and backlink outcomes.

## Helper integration assessment and next diagnostic

Current dev's original `_open_notes` directly awaits preparatory `_select_library_rail_row`; the merged helper posts a native rail Button and waits for navigation generation/epoch acknowledgement plus full tree publication. Current real handler still reaches that same navigation seam. Current Notes controller resets/reloads a fresh Browse visit and handles retained Create-to-Browse separately. Retained list and work-pane owners remain present in healthy current Notes compose; tree note rows preserve projection order. No static contradiction was found in those branches that explains the recorded first Browse failures independently of unhealthy source setup.

The prior integration review's static assessment should be qualified by this actual evidence. It did not establish healthy runtime setup on the current base. The stronger merged predicate is not itself evidence of a product regression, nor does the old direct helper's simpler wait establish a safe passing alternative.

If a link failure remains after healthy-source preparation, perform ONE scoped observation run before another fix. Record compact state only at relevant boundaries and on failure:

1. After `_library`, before/after Retry, before/after rail press: source generation, loaded/error kind, retry visibility, active screen/selected row, navigation generation and topology epoch.
2. Split `_notes_tree_publication` failure into route/session, branch readiness, owner count/recompose/liveness, and exact projected-vs-DOM row identity clauses. Record pressed rail button identity/active ancestry before posting and whether its handler acknowledges the visit. This distinguishes a retired rail Button from an unavailable canvas or stale projection without weakening any assertion.
3. For the keyboard case, record actual title and its current widget identity, focus identity, snapshot/draft title, editor_armed, work-pane recompose flags at click, after typing and on failure. Observe focus/recompose transitions without changing their scheduling or assigning text directly.

Keep these observations to fixture-owned IDs/status/text (the title is the known literal fixture); do not dump real profile contents. If healthy setup still loses the title, compare the exact same focused probe on dev before classifying it as inherited. If the acknowledged-generation clause alone fails, then evaluate the native rail-button lifetime/reacquisition rather than reverting all publication guards.

## Scope and remaining uncertainty

The source snapshot deadline's underlying slow contributor is not identified by the existing log: the gathered source operations share one five-second deadline. It could be native/local worker contention, startup activity, or another service; no evidence supports naming one yet. This review recommends real bounded recovery because the product exposes it and these tests are about note links, not snapshot deadline reliability. If retries fail consistently, inspect completion/cancellation timings of each gathered local source call; do not hide the failure or increase the deadline.

No current passing result is claimed. The three link behavior outcomes and legacy export remain unqualified until their real setups and original assertions complete. No full suite, hosted CI, release, PR3267, or PR3297 work is included.

## Follow-up: uncommitted source-recovery wrapper review

Reviewed the new `library_note_links_support._library` wrapper, three importing modules, and the exact legacy export node's `bootstrap_profile` marker only. No execution/imports or additional changes. Parent reports export retries passed separately; those results are outside this follow-up's scope.

The exact-node marker is correct and preserves the source guard. All three link modules now import the local wrapper; other quit-guard consumers remain unchanged. The real Retry handler calls `_refresh_local_source_snapshot`, whose actual group is `library_source_snapshot` (`library_screen.py:12034`, `:22937`). The current wrapper correctly uses the real Button and does not clear production error state.

**Important F1 — A live-worker poll is not a completion receipt.** The wrapper's `retry_workers()` queries only workers still in `app.workers`, and its start-or-complete predicate accepts completion only when the result is healthy. Textual's WorkerManager removes every completed worker (`_remove_worker:121` discards it). If a Retry finishes with another source failure between two predicate evaluations, the error remains non-None and the finished worker is absent, so the wrapper spends its deadline waiting for an admission that already completed and never reaches its allowed second attempt. A five-second failure can also be missed if a native layout/message turn is slow; this is not limited to instantaneous service failures. The subsequent raw `asyncio.gather(worker.wait())` has no helper-level deadline and still raises on same-group supersession; filtering unrelated workers does not make source workers nonreplaceable.

**Minimal correction:** use the source publication receipt instead of sampling ephemeral worker membership. Capture `_library_snapshot_state_generation` before pressing Retry; await a newer published source generation with the existing bounded predicate wait, then await current source reconciliation (`_library_snapshot_rendered_generation == _library_snapshot_state_generation`, with the actual route/DOM gates). Repeated identical recoverable failures increment their `attempt` in `_apply_local_source_snapshot:13552-13567`, so even those failed attempts produce a new state generation and can advance to the second bounded retry. A successful retry also changes the old error state. This requires no worker wait and naturally follows a superseding source operation's actual result rather than treating cancellation as an export/link failure.

Keep the final healthy-state assertion coupled to the DOM gate: loaded, no current lookup error, current source generation rendered, live rail row, no error canvas. The current check asserts health before an await and then checks only DOM absence/rail activity; checking both together avoids accepting an old healthy assertion if a new result arrives while waiting. Existing downstream Notes tree/Preview publication assertions must remain intact. This is a test readiness correction, not a product timeout change.

## Follow-up closure: generation-based recovery

Re-read the revised `_library` wrapper after F1 corrections. **F1 is closed by code inspection.** Before each actual Retry press, it captures `_library_snapshot_state_generation` and uses the existing bounded `_until` to await a newer published result. The ephemeral worker-manager poll and unbounded `worker.wait()` gather are gone. Production's repeated recoverable failure attempt increment makes even an identical retry failure observable as a newer state generation; the existing two-attempt bound remains.

The final predicate now checks health and publication together: `_library_loaded`, no current `_library_lookup_error`, rendered generation equal to current state generation, no dirty entry reconcile, absent error canvas, and active Notes rail row. `_complete_library_entry_reconcile` only marks the still-current generation/current route rendered. All three import substitutions and the exact legacy-node bootstrap marker remain correct; downstream note/tree/Preview behavior assertions are unchanged.

No further Important issue found within this requested wrapper/fixture scope. This is a static closure only: no tests, collection, project imports, network, or broader product review were performed. Native link and legacy-export qualification remains the parent's pending focused run; this closure does not claim those cases pass.
