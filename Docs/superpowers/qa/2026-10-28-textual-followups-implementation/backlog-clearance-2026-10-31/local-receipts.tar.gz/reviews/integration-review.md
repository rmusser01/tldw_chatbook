# PR3290 independent integration review

Reviewed immutable integrated head: `dacd4da58c082259c92ce1133ff12c1f4764defc`.
Integrated dev / verified merge-base: `1609dc6af556e3c04e053a32acc03ef83f75b16b`.
Previously reviewed source: `188fe0fc92dfd64ddb70f3fc890919640f77d036`.

This supplements the initial independent requesting-code-review review. It evaluates actual rebase resolutions and interaction with newly merged3259. All inspection used exact immutable Git objects and explicit safe.directory/workdir. No tests, collection, application imports, source/Git/remote changes, or subagents were performed. This report is written outside all checkouts. Focused local tests and capacity recomputation were pending when this review began; no passing result is inferred for this new head. Hosted CI and size caps are explicitly waived for the current operation. No release is reviewed or requested.

## Strengths and preserved boundaries

- Dev1609dc is the actual merge-base of dacd4da, confirming the requested rebase rather than a merge of dev into the source branch.
- All four reviewed product blobs are identical to source188fe0: CharacterBenchEditor, EvalsScreen, ResearchWindow, and library_file_export. All three new behavior-test blobs are also identical. Publication revisions, post-await owner checks, operation capture, native workers, no-clobber collisions and atomic Replace behavior survive intact. No production conflict required inventing a new runtime or storage boundary.
- Census conservation is exact: source1189, dev1197, integrated1241 entries. There are no duplicate selectors, no lost source entries and no lost dev entries. The integrated set equals all1197 current-dev selectors plus exactly44 source-only additions. The complete source1189 ordering is a prefix, and52 dev-only selectors append. Old dev selectors intentionally move under the source's32-shard redistribution; preserving dev's old order is not an invariant of this rebase.
- `scripts/check_ui_pr_gate_census.py:656` sets floor1241 without dropping dev's history. The three source split-file additions remain in `Tests/CI/test_ui_pr_gate_census_checker.py:501`; dev's existing split/static contracts remain. The replay algorithm is unchanged; its documentation and checkpoint test retain the source's reviewed32-shard contract.
- The complete workflow diff against current dev is only the current-lane comment and28-to32 matrix expansion (`.github/workflows/derived-artifacts.yml:698`, `:711`). Max-parallel17, all current-dev test/UAT targets, timeouts and aggregation survive. The two corresponding CI contract changes retain all current-dev content and alter only the matrix expectation.
- Diagnostic inventory comparison is exact at the parsed-object level:712 owner entries, all other top-level fields and every owner/call count/privacy rule conserved. Only library_file_export's diagnostic digest changes from `b4a748817136c4c4f8de` to `c352738411d1464094ba` (`Docs/security/production-diagnostic-inventory.json:3232`), consistent with the previously reviewed warning-owner move. This is source conservation, not a newly executed inventory-check pass.
- Both lesson files are additive against current dev: four added lines for backlog hygiene,15 for testing evidence, with no removed lines. Current-dev architecture additions are preserved while the Notes export paragraph is added.
- Notes helper resolution intentionally combines both branches. `Tests/UI/library_note_links_support.py:211` posts the native rail Button and waits for an acknowledged newer navigation generation and complete current tree publication; this prevents the old current-row shortcut before navigation settles. The real handler (`library_screen.py:23193`) awaits the same `_select_library_rail_row` (`:23287`) that dev's direct preparatory call used. Source's current tree/Preview DOM, row reacquisition, identity and focus guards remain; dev's painted-link polling remains in `_click_preview_link` (`library_note_links_support.py:323`). The complete `_select_library_rail_row_after_source_admission` function is unchanged from source, so this helper combination does not introduce a new Create/retained-navigation assumption.

## Issues

### Critical

None found.

### Important I1 — Integrate Notes Markdown expectations with3259's YAML contract

**Locations:** `Tests/UI/test_library_note_export_responsiveness.py:44-46`, uses at`:193`, `:220`, `:295`, `:359`; also the touched legacy control `Tests/UI/test_library_shell.py:22953`.

**What is wrong:** The new regression's literal expected Markdown still requires an unquoted timestamp and a `keywords: ` scalar. Newly merged3259 deliberately changes `build_note_export_content` to a real YAML renderer with a `tags` list (`tldw_chatbook/Library/library_notes_state.py:923-941`). Its renderer preserves scalar types, including a timestamp string (`tldw_chatbook/Notes/note_frontmatter.py:27-57`). Source188fe0's test passed against the old formatter; copying that blob unchanged does not make its expected bytes valid on dev1609dc. The legacy export-content assertion also still requires `keywords: alpha, beta`, which the integrated formatter no longer emits.

**Concrete reproduction from code:** Run `Tests/UI/test_library_note_export_responsiveness.py::test_note_export_dispatches_app_key_before_destination_release[new-ordinary]` after normal source readiness. The production export supplies fields `{title: 'Q3 retro', date: '2026-10-28 12:34:56', tags: [], note_id: 'n-1'}` to the real renderer, but line193 demands a file containing `keywords:` instead of `tags: []`. The byte assertion must fail once the export succeeds. This does not depend on thread scheduling or timing. The same obsolete constant is used by all four ordinary/held new/Replace cases, the late-collision Replace case and both changed-result-owner cases: seven new cases are affected. The touched shell content case fails at its old keywords assertion. This review did not run any of them.

**Why it matters:** Focused integration qualification cannot pass, and rolling back the formatter or weakening byte/content assertions would discard3259's actual title/keyword round-trip fix. This is test-oracle integration drift, not evidence that worker offloading breaks export.

**Minimal correction:** Keep production's real YAML/tags behavior. Update the independent literal expectation for the pinned empty-tags fixture to the new serializer output, retaining native newline conversion, body bytes and exactly-one-publication assertions. Update the touched legacy content oracle to assert the new tags semantics without calling the production export helper to construct its expected value. Preserve all dispatch, atomicity, cancellation, ownership, focus and source-preservation oracles. The existing current-dev `Tests/Library/test_library_notes_state.py::test_export_content_markdown_has_frontmatter_and_heading` and `Tests/Chatbooks/test_note_frontmatter_round_trip.py` document the new contract; do not restore `keywords:` merely to satisfy historical expectations.

### Minor

None newly introduced requiring a separate change request.

## Notes source interaction with3259

The integrated exporter still calls the current shared `build_note_export_content` before admitting its worker and captures the resulting immutable payload. Thus3259's YAML/title/tags semantics are preserved in the actual side effect; they are not duplicated into the worker or bypassed. The plain-text formatter remains unchanged. The exporter source, atomic writer and screen's export delegator retain their reviewed contracts; current-dev's broader Notes tree/link/folder changes remain present.

No new product bug was found in this interaction. The stale independent expectations above are the material integration issue. Initial source permission-error behavior is not relabeled a new3290 regression or a3259 repair merely because the PR number appears in old task descriptions.

## Capacity and verification limits

The historical32-shard forecast for1189 entries does not qualify1241 entries. Appending the52 dev-only selectors preserves source replay ordering but still changes shard loads. The52 appended dev-only selectors are unmeasured in the retained source model. A capacity report can honestly state the measured-prefix forecast and missing inputs; it must not invent costs or change capacity blindly. A newly measured integrated forecast would need complete setup/call/teardown costs and the actual census/matrix. This is a disclosed capacity-evidence limit, not an additional hosted-CI, full-suite, concurrency or timeout gate. The source's prior hosted40-job/Perf Guard result and archived local children remain historical evidence only.

The initial source review independently verified six archived SHA-256s,606 mapped members and final local XML counts. Those archives remain conserved; that work is not a test execution or current-head pass. This integration review does not repeat archived runtime tests or claim a current clean result.

## Minimal representative focused checks after correcting I1

The four product blobs and three new-test blobs are identical to the independently reviewed source. The current-base changes are composition and helper/formatter interaction, so repeating all43 historical cases is not necessary solely because a rebase occurred. The representative set below exercises each affected ownership boundary while preserving the full43 historical-receipt limitation.

1. Notes export: held new and held Replace App-dispatch cases; late-collision Replace; both retired-screen and changed-region ownership cases. These cover both native admission callbacks, worker completion, actual captured YAML bytes, atomic collision re-entry and publication retirement. Include the exact touched legacy shell export-content case and existing native Escape/Replace journey; retain every original byte, source, focus and operation assertion. The changed hard-link-refusal case is a small useful atomic-platform compatibility check if included in the parent's focused batch.
2. Character: one `test_character_save_preserves_later_draft[samples-01-during-refresh]` case (raw normalized-equal spelling through the awaited rail boundary) and `test_character_save_preserves_newer_selection[lock-pending]`. Source conservation supports using these to sample the two distinct publication/selection owners without replaying all26 cases.
3. Research: `test_refresh_preserves_newer_run_selection` and `test_local_refresh_cannot_restore_a_departed_source[source-aba]`. Together these qualify native timer publication against both newer selection and source departure/return on the current base without replaying all7 cases.
4. Reconciled Notes helper: the actual full keyboard journey `test_typing_two_brackets_opens_a_keyboard_picker_that_inserts_a_real_link`, extended sibling `test_enter_on_the_focused_preview_follows_the_only_link_and_lists_several`, and mouse consumer `test_clicking_a_note_link_in_preview_opens_that_note_and_never_reaches_open_url`. These exercise acknowledged native navigation, current focused Preview publication and dev's painted-link wait. Add the already changed filtered Reader identity case. Do not substitute setup predicates for original link/picker/write-target outcomes.
5. Run focused affected census/checker, workflow, replay and queue contracts and the real diagnostic-inventory check, plus scoped lint/format/whitespace checks. Verify actual1241 membership and unique additions; no full application sweep is implied. A contract failure or changed product path can justify a further targeted run; the rebase alone does not justify blanket expansion.

Root subsequently supplied `frontmatter-oracle-repair.json`: the original literal does not match the actual current pure formatter, and the corrected independent literal does. That receipt corroborates I1 and its proposed correction; it is expressly pure-formatter proof, not a native-export pass or a new immutable reviewed-head result. Native qualification remains pending.
## Declined to judge

- Natural frequency and full terminal-session/storage-latency behavior: neither held historical interleavings nor this read-only inspection measures them.
- Existing Research artifact-action mismatch and separate Media typing/Notes gesture defects: independently owned and unchanged by the rebase; helper preparation does not claim those product repairs.
- Current-head runtime/static success: tests, inventory checker and capacity recomputation were pending; this review supplies no fictional passing result.
- Hosted CI, full sweeps, size caps and release: explicitly outside this operation's requested verification scope.

## Assessment

**Ready with fixes:** The actual conflict resolutions preserve source and dev invariants, and no new product defect was found. Fix I1's obsolete Markdown expectations, then qualify the resulting immutable head with the representative local checks. Preserve the explicit missing-capacity-input qualification rather than claiming a current measured forecast. Until that oracle correction and local qualification complete, dacd4da is not ready to declare integration finished.

