"""Apply the reviewed existing-policy capacity amendment, preserving membership."""

from pathlib import Path
import ast
import hashlib
import importlib.util
import json
import yaml

root = Path.cwd()
folder = root / ".test-tmp/textual-37266-37268"
proof = json.loads((folder / "capacity-candidate.json").read_text())
inherited = json.loads((folder / "inherited-capacity.json").read_text())
spec = importlib.util.spec_from_file_location("capacity_replay", root / "scripts/ui_lane_shard_replay.py")
replay = importlib.util.module_from_spec(spec)
spec.loader.exec_module(replay)
census = root / "scripts/ui_pr_gate_census.txt"
old_text = census.read_text()
assert replay.read_census(census) == inherited["entries"]
(folder / "census-before.txt").write_text(old_text, encoding="utf-8")
text = old_text.replace("Current UI lane: 28 shards; current evidence is the pending-draft QA report.",
                        "Current UI lane: 32 shards; evidence: 2026-10-28-textual-followups-implementation.md.")
text = text.replace("TASK-37236 full-census replay checkpoint: the 1140",
                    "TASK-37266..37268 full-census replay checkpoint: the 1184")
text = text.replace("round-robin over 28 shards", "round-robin over 32 shards")
text = text.rstrip() + "\n"
for node in proof["added_entries"]:
    text += "# TASK-37266..37268: native publication/export or canonical-class governance coverage.\n" + node + "\n"
census.write_text(text, encoding="utf-8", newline="\n")
entries = replay.read_census(census)
census.write_text(replay._reordered(census, entries, proof["order"]), encoding="utf-8", newline="\n")
assert replay.read_census(census) == proof["order"]
assert set(proof["order"]) - set(inherited["entries"]) == set(proof["added_entries"])
workflow = root / ".github/workflows/derived-artifacts.yml"
before_workflow = yaml.safe_load(workflow.read_text())
text = workflow.read_text().replace(
    "Current UI lane: 28 shards (TASK-37236 all-phase/checkout qualification).",
    "Current UI lane: 32 shards (TASK-37266..37268 measured full-phase enrollment).")
old_matrix = "shard: [" + ", ".join(map(str, range(1, 29))) + "]"
new_matrix = "shard: [" + ", ".join(map(str, range(1, 33))) + "]"
assert text.count(old_matrix) == 1
workflow.write_text(text.replace(old_matrix, new_matrix), encoding="utf-8", newline="\n")
after_workflow = yaml.safe_load(workflow.read_text())
before_workflow["jobs"]["ui-fast-lane"]["strategy"]["matrix"]["shard"] = list(range(1, 33))
assert before_workflow == after_workflow, "unexpected workflow contract delta"
checker = root / "scripts/check_ui_pr_gate_census.py"
text = checker.read_text().replace("Current UI lane: 28 shards.", "Current UI lane: 32 shards.")
assert text.count("MINIMUM_FILES = 1140") == 1
checker.write_text(text.replace("MINIMUM_FILES = 1140", "MINIMUM_FILES = 1184"), encoding="utf-8", newline="\n")
replay_path = root / "scripts/ui_lane_shard_replay.py"
before_tree = ast.parse(replay_path.read_text())
text = replay_path.read_text().replace("--shards 28 ", "--shards 32 ")
replay_path.write_text(text, encoding="utf-8", newline="\n")
after_tree = ast.parse(text)
before_tree.body = before_tree.body[1:]
after_tree.body = after_tree.body[1:]
assert ast.dump(before_tree) == ast.dump(after_tree), "replay implementation changed"
proof["conservation"] = dict(inherited_exactly_once=1140, added_exactly_once=44, total=1184,
                             workflow_only_matrix_changed=True, replay_algorithm_unchanged=True,
                             concurrency=17, job_timeout_minutes=20, test_timeout_seconds=180)
proof["inherited_inputs"] = inherited
proof["source_hashes"] = {path: hashlib.sha256((root / path).read_bytes()).hexdigest()
                           for path in ["scripts/ui_pr_gate_census.txt", "scripts/check_ui_pr_gate_census.py",
                                        "scripts/ui_lane_shard_replay.py", ".github/workflows/derived-artifacts.yml"]}
out = root / "Docs/superpowers/qa/2026-10-28-textual-followups-implementation"
(out / "capacity-replay.json").write_text(json.dumps(proof, indent=2), encoding="utf-8", newline="\n")
print(json.dumps(proof["conservation"]))
