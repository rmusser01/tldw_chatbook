"""Capture real inventory drift/write/check and conserve latest-dev owners."""

from pathlib import Path
import copy
import json
import os
import subprocess
import sys

root = Path.cwd()
folder = root / ".test-tmp/textual-37266-37268"
env = dict(os.environ, GIT_CONFIG_COUNT="1", GIT_CONFIG_KEY_0="safe.directory",
           GIT_CONFIG_VALUE_0=root.as_posix(), PYTHONUTF8="1")
prefix = [sys.executable, "-X", "utf8", "scripts/check_persistent_diagnostic_inventory.py"]
g = ["git", "-c", "safe.directory=" + root.as_posix(), "-c", "gc.auto=0"]
base = subprocess.check_output(g + ["rev-parse", "origin/dev"], text=True).strip()
before = json.loads(subprocess.check_output(g + ["show", base + ":Docs/security/production-diagnostic-inventory.json"], text=True, encoding="utf-8"))
steps = []

def run(extra):
    args = prefix + extra
    p = subprocess.run(args, capture_output=True, text=True, encoding="utf-8", errors="replace", env=env)
    receipt = dict(args=args, exit_code=p.returncode, stdout=p.stdout, stderr=p.stderr)
    steps.append(receipt)
    (folder / "diagnostic-inventory.json").write_text(json.dumps(dict(base=base, steps=steps), indent=2), encoding="utf-8")
    return receipt

pre = run([])
assert pre["exit_code"] == 1
delta = run(["--statements", "tldw_chatbook/UI/Library_Modules/library_file_export.py", "--since", base])
assert delta["exit_code"] == 0
write = run(["--write"])
assert write["exit_code"] == 0
after = json.loads((root / "Docs/security/production-diagnostic-inventory.json").read_text())
old_row = next(row for row in before["owners"] if row["path"].endswith("/library_file_export.py"))
new_row = next(row for row in after["owners"] if row["path"] == old_row["path"])
expected = copy.deepcopy(before)
expected["owners"][before["owners"].index(old_row)] = new_row
assert expected == after, "unrelated inventory owner, privacy or sink drift"
assert old_row["call_count"] == new_row["call_count"] == 4
assert old_row["diagnostic_digest"] == "b4a748817136c4c4f8de"
assert new_row["diagnostic_digest"] == "c352738411d1464094ba"
for key in old_row.keys() - {"diagnostic_digest"}:
    assert old_row[key] == new_row[key]
post = run([])
assert post["exit_code"] == 0
proof = dict(base=base, steps=steps, old_owner=old_row, new_owner=new_row,
             every_other_owner_privacy_rule_candidate_and_sink_conserved=True,
             qualification="Actual subprocess stdout, stderr and exit codes. The four sanitized calls retain their arguments/messages/severity/multiplicity; one nested owner moves from _write to _fail. No raw exception logging or sink change.")
out = root / "Docs/superpowers/qa/2026-10-28-textual-followups-implementation/diagnostic-inventory.json"
out.write_text(json.dumps(proof, indent=2), encoding="utf-8", newline="\n")
print(json.dumps(dict(exit_codes=[s["exit_code"] for s in steps], only_owner_digest_changed=True, calls=4, base=base)))
