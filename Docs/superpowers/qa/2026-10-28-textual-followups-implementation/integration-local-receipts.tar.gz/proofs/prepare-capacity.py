"""Read measured receipts, conserve selectors, and compare bounded layouts."""

from pathlib import Path
import hashlib
import importlib.util
import json
import re
import xml.etree.ElementTree as ET

root = Path.cwd()
folder = root / ".test-tmp/textual-37266-37268"
inherited = json.loads((folder / "inherited-capacity.json").read_text())
old = inherited["entries"]
collected = [line.strip() for line in (folder / "integration-collect/run.log").read_text().splitlines()
             if line.startswith("Tests/UI/") and "::" in line]
assert len(collected) == len(set(collected)) == 44
assert not set(old) & set(collected)
costs = dict(inherited["costs"])
inputs = {}

def read(relative):
    path = folder / relative
    raw = path.read_bytes()
    inputs[path.relative_to(root).as_posix()] = hashlib.sha256(raw).hexdigest()
    return json.loads(raw)

for relative in ("task1/new-case-durations.json",
                 "task1/new-case-durations-UNIQUE-task1-final-01.json",
                 "task1/new-case-durations-UNIQUE-task1-fix1-green-01.json"):
    for row in read(relative):
        node = row["nodeid"]
        assert node in collected, node
        costs[node] = max(costs.get(node, 0), row["parent_total_seconds"])
for row in read("task2/new-case-timings.json"):
    node = "Tests/UI/test_research_run_refresh_publication.py::" + row["name"]
    assert node in collected
    costs[node] = float(row["parent_inclusive_seconds"])
task3_path = root / ".test-tmp/task3-green-timings.json"
inputs[task3_path.relative_to(root).as_posix()] = hashlib.sha256(task3_path.read_bytes()).hexdigest()
for row in json.loads(task3_path.read_text())["cases"]:
    node = "Tests/UI/test_library_note_export_responsiveness.py::" + row["name"]
    assert node in collected
    costs[node] = float(row["parent_inclusive_seconds"])
guard = next(node for node in collected if "test_component_pattern_governance.py::" in node)
guard_xml = folder / "task1/UNIQUE-task1-controls-01/00-result.xml"
inputs[guard_xml.relative_to(root).as_posix()] = hashlib.sha256(guard_xml.read_bytes()).hexdigest()
guard_case = next(case for case in ET.parse(guard_xml).iter("testcase") if case.get("name") == guard.split("::")[1])
costs[guard] = float(guard_case.get("time"))
assert set(costs) == set(old) | set(collected)
entries = old + collected
comparisons = []
orders = {}
for total in range(28, 37):
    slots = [sum(index % total == shard for index in range(len(entries))) for shard in range(total)]
    bins = [[] for _ in range(total)]
    loads = [0.0] * total
    for node in sorted(entries, key=lambda node: (-costs[node], node)):
        shard = min((s for s in range(total) if len(bins[s]) < slots[s]), key=lambda s: (loads[s], s))
        bins[shard].append(node)
        loads[shard] += costs[node]
    offsets = [0] * total
    order = []
    for index in range(len(entries)):
        shard = index % total
        order.append(bins[shard][offsets[shard]])
        offsets[shard] += 1
    assert len(order) == len(set(order)) == 1184 and set(order) == set(entries)
    assert all(abs(sum(costs[node] for node in order[s::total]) - loads[s]) < 1e-6 for s in range(total))
    forecast = max(loads) * 1.15 + 310
    comparisons.append(dict(shards=total, maximum_work_seconds=max(loads), minimum_work_seconds=min(loads),
                            forecast_seconds=forecast, ideal_lower_bound_seconds=sum(costs.values()) / total * 1.15 + 310,
                            target_seconds=1020, meets_target=forecast <= 1020))
    orders[total] = order
selected = next(row for row in comparisons if row["meets_target"])
proof = dict(inherited_entries=len(old), added_entries=collected, entries=len(entries),
             inherited_work_seconds=sum(inherited["costs"].values()),
             added_work_seconds=sum(costs[node] for node in collected),
             weighted_seconds=sum(costs.values()), new_timing_inputs=inputs,
             inherited_model="inherited-capacity.json", comparisons=comparisons, selected=selected,
             order=orders[selected["shards"]], costs=costs,
             qualification="Forecast only. New native costs include parent case setup/call/teardown and subprocess overhead. Character costs retain larger successful earlier/final source observations. The extra canonical guard uses its inherited failing Windows run solely as a cost input. Collection/session overhead is outside per-case costs and reserved with setup/checkout. No timeout, parallelism or selection reduction; actual final-head hosted CI is required.")
(folder / "capacity-candidate.json").write_text(json.dumps(proof, indent=2), encoding="utf-8")
print(json.dumps({key: proof[key] for key in ("entries", "inherited_work_seconds", "added_work_seconds", "weighted_seconds", "selected", "comparisons")}))
