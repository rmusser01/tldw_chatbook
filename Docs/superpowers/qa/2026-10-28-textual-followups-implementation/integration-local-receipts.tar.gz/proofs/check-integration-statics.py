"""Capture scoped static outputs and conserve existing formatting debt."""

from pathlib import Path
import hashlib
import json
import re
import subprocess
import sys

root = Path.cwd()
folder = root / ".test-tmp/textual-37266-37268"
baseline = json.loads((folder / "ci-static-baseline.json").read_text())
results = []

def run(args):
    p = subprocess.run(args, capture_output=True, text=True, encoding="utf-8", errors="replace")
    return dict(args=args, exit_code=p.returncode, stdout=p.stdout, stderr=p.stderr)

def regions(diff):
    return [line for line in diff.splitlines() if not re.match(r"^@@ .* @@$", line)]

for old in baseline:
    path = old["path"]
    lint = run([sys.executable, "-m", "ruff", "check", "--no-cache", "--output-format=json", path])
    fmt = run([sys.executable, "-m", "ruff", "format", "--no-cache", "--diff", path])
    conserved = regions(fmt["stdout"]) == regions(old["format_diff"]["stdout"])
    results.append(dict(path=path, sha256=hashlib.sha256((root / path).read_bytes()).hexdigest(),
                        lint=lint, format_diff=fmt, baseline_format_regions_conserved=conserved))
extra = "Tests/UI/test_evals_character_bench_save_publication.py"
extra_lint = run([sys.executable, "-m", "ruff", "check", "--no-cache", extra])
extra_format = run([sys.executable, "-m", "ruff", "format", "--no-cache", "--check", extra])
whitespace = run(["git", "-c", "safe.directory=" + str(root).replace("\\", "/"), "diff", "--check"])
proof = dict(results=results, extra_test_lint=extra_lint, extra_test_format=extra_format, whitespace=whitespace)
(folder / "integration-statics.json").write_text(json.dumps(proof, indent=2), encoding="utf-8")
print(json.dumps(dict(lint_codes=[r["lint"]["exit_code"] for r in results],
                      format_codes=[r["format_diff"]["exit_code"] for r in results],
                      format_conserved=[r["baseline_format_regions_conserved"] for r in results],
                      extra_codes=[extra_lint["exit_code"], extra_format["exit_code"]], whitespace=whitespace["exit_code"])))
assert all(r["lint"]["exit_code"] == 0 and r["baseline_format_regions_conserved"] for r in results)
assert extra_lint["exit_code"] == extra_format["exit_code"] == whitespace["exit_code"] == 0
