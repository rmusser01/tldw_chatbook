"""Pin the inherited census and conservative timing model before enrollment."""

from pathlib import Path
import hashlib
import importlib.util
import json
import re
from types import SimpleNamespace

root = Path.cwd()
folder = root / ".test-tmp/textual-37266-37268"
prior = root / ".test-tmp/textual-37031-37034"
spec = importlib.util.spec_from_file_location("textual_delivery_replay", root / "scripts/ui_lane_shard_replay.py")
replay = importlib.util.module_from_spec(spec)
spec.loader.exec_module(replay)
entries = replay.read_census(root / "scripts/ui_pr_gate_census.txt")
assert len(entries) == len(set(entries)) == 1140
old = json.loads((prior / "capacity-full-phase/candidate.json").read_text())
assert set(old["costs"]) == set(entries)
log_folder = prior / "current-head-29a25102-watch/logs"
qualified = json.loads((log_folder.parent / "qualified-proof.json").read_text())
ui_jobs = {str(job["id"]): job for job in qualified["jobs"]
           if re.fullmatch(r"UI Fast Lane \(\d+\)", job["name"])}
ui_logs = [path for path in log_folder.glob("*.log") if path.stem in ui_jobs]
assert len(ui_logs) == 28 and all(job["conclusion"] == "success" for job in ui_jobs.values())
latest = replay.entry_seconds(entries, replay.run_seconds(SimpleNamespace(glob=lambda pattern: ui_logs)))
costs = {entry: max(old["costs"][entry], latest[entry]) for entry in entries}
paths = ["scripts/ui_pr_gate_census.txt", "scripts/check_ui_pr_gate_census.py",
         "scripts/ui_lane_shard_replay.py", ".github/workflows/derived-artifacts.yml"]
receipt = dict(base="7884e11a496a677c8180cc5d67234a57b7d659b9", entries=entries,
               source_hashes={path: hashlib.sha256((root / path).read_bytes()).hexdigest() for path in paths},
               prior_inputs=old["inputs"], latest_head=qualified["head"],
               latest_log_hashes={p.name: hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(ui_logs)},
               costs=costs, weighted_seconds=sum(costs.values()),
               qualification="Inherited worst-observed progress/all-phase model plus only the last complete actual 28 UI shard logs; unrelated lane logs are excluded to avoid duplicate costs. Each cost retains the larger value. Includes existing Media allowance. New task cases are not yet enrolled or charged. Forecast only; actual final-head CI is required.")
(folder / "inherited-capacity.json").write_text(json.dumps(receipt, indent=2), encoding="utf-8")
print(json.dumps(dict(entries=len(entries), weighted_seconds=receipt["weighted_seconds"], latest_logs=len(receipt["latest_log_hashes"]))))
