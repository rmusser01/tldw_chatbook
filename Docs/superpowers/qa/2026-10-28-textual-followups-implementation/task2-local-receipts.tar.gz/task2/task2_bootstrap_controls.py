"""Supported bootstrap-profile replay for exact legacy Research controls only."""

import json
from pathlib import Path

import pytest


def pytest_collection_modifyitems(items):
    selectors = json.loads(
        (Path(__file__).parent / "legacy-selectors.json").read_text(encoding="utf-8")
    )
    for item in items:
        if item.nodeid in selectors:
            item.add_marker(pytest.mark.bootstrap_profile)
