"""Compare unchanged/current Research AST inputs using the guard's public seam."""

import ast
import hashlib
import json
from pathlib import Path

from Tests.Architecture import test_timer_path_static_update_inventory as guard


root = Path.cwd()
output = root / ".test-tmp/textual-37266-37268/task2"
baseline = root / ".test-tmp/textual-37266-37268/task2-red03-sources/Research_Window.py"
live = root / "tldw_chatbook/UI/Research_Window.py"
modules = guard._load_package()
dotted = "tldw_chatbook.UI.Research_Window"
baseline_modules = dict(modules)
baseline_modules[dotted] = guard._index_module(
    live, ast.parse(baseline.read_text(encoding="utf-8")), dotted
)


def observations(module_map):
    sites = guard.census(modules=module_map)
    graph = guard._CallGraph(module_map)
    roots, problems = guard._collect_clock_roots(module_map, graph)
    raw_unclassified = [list(key) for key, value in sites.items()
                        if not value["explicit"] and key not in guard.CLASSIFIED_SITES]
    normalized_unclassified = [list(key) for key, value in sites.items()
                               if not value["explicit"]
                               and (key[0].replace("\\", "/"), *key[1:])
                               not in guard.CLASSIFIED_SITES]
    return dict(
        sites=[dict(key=key, lines=sorted(value["lines"]), explicit=value["explicit"],
                    roots=sorted(value["roots"])) for key, value in sorted(sites.items())],
        roots=sorted(roots), problems=[dict(key=key, value=value) for key,value in sorted(problems.items())],
        raw_unclassified=sorted(raw_unclassified), normalized_unclassified=sorted(normalized_unclassified),
    )


before, after = observations(baseline_modules), observations(modules)
semantic_before = [{k:v for k,v in site.items() if k != "lines"} for site in before["sites"]]
semantic_after = [{k:v for k,v in site.items() if k != "lines"} for site in after["sites"]]
result = dict(
    baseline_sha256=hashlib.sha256(baseline.read_bytes()).hexdigest(),
    current_sha256=hashlib.sha256(live.read_bytes()).hexdigest(),
    guard_sha256=hashlib.sha256(Path(guard.__file__).read_bytes()).hexdigest(),
    exact_same_semantic_sites=semantic_before == semantic_after,
    exact_same_roots=before["roots"] == after["roots"],
    exact_same_problems=before["problems"] == after["problems"],
    baseline=before, current=after,
)
(output / "timer-input-comparison.json").write_text(json.dumps(result, indent=2), encoding="utf-8")
print(json.dumps({k:v for k,v in result.items() if k not in {"baseline", "current"}},indent=2))
print(json.dumps(dict(raw_unclassified=len(after["raw_unclassified"]),
                      normalized_unclassified=after["normalized_unclassified"]),indent=2))
