"""Shared workspace creation modal (spec 2026-08-17 §4).

Used by the Console rail, Settings ▸ Workspaces, and Library. The modal
owns the create/bind service calls so failures render inline; surfaces
own post-create UI sync via their dismissal callbacks (§4.3).
"""

from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Any, ClassVar

from textual import on
from textual.app import ComposeResult
from textual.containers import Horizontal, Vertical, VerticalScroll
from textual.screen import ModalScreen
from textual.widgets import Button, Checkbox, Input, Static

from tldw_chatbook.Skills_Interop.project_skills_discovery import (
    ProjectSkillsDiscovery,
    discover_project_skills,
)
from tldw_chatbook.Third_Party.textual_fspicker import SelectDirectory
from tldw_chatbook.Utils.input_validation import sanitize_string
from tldw_chatbook.Widgets.modal_dismissal import SafeModalDismissMixin
from tldw_chatbook.Widgets.workspace_persona_default import (
    WorkspacePersonaPicker,
    WorkspacePersonaSelection,
)
from tldw_chatbook.Workspaces.registry_service import (
    LocalWorkspaceRegistryService,
    WorkspaceRegistryServiceError,
    next_local_workspace_identity,
    validate_folder_binding_path,
)

_WORKSPACE_EXPLAINER = (
    "A workspace groups related Console conversations and can narrow "
    "retrieval through its RAG Scope. Every chat has private scratch space. "
    "Bind project folders here to add explicit project-file access "
    "(read-only unless you grant write in Settings). Folder access is "
    "optional; add or change folders later in Settings ▸ Workspaces."
)


@dataclass(frozen=True)
class WorkspaceCreateResult:
    """Outcome of a completed create dialog (spec §4.3)."""

    workspace_id: str
    name: str
    bound_folders: tuple[str, ...] = ()
    failed_folders: tuple[tuple[str, str], ...] = ()  # (path, error message)
    make_active: bool = True
    #: One ProjectSkillsDiscovery per bound folder whose root contains a
    #: non-empty .SKILLS/ (spec §5.5 create-modal chaining). Empty when no
    #: bound folder had project skills, or none were bound at all.
    project_skills: tuple[ProjectSkillsDiscovery, ...] = ()
    offer_profile_interview: bool = False


class _WorkspaceCreateError(Static):
    """Reveal feedback after the error text's actual reflow."""

    def on_resize(self) -> None:
        if isinstance(self.screen, WorkspaceCreateModal):
            self.screen._reveal_error()


class WorkspaceCreateModal(
    SafeModalDismissMixin, ModalScreen["WorkspaceCreateResult | None"]
):
    """Collect a workspace name + optional folder bindings."""

    BUNDLED_CSS = """
    WorkspaceCreateModal {
        align: center middle;
    }

    #workspace-create-modal {
        width: 72;
        height: auto;
        max-height: 32;
        border: tall $surface-lighten-2;
        background: $surface;
        color: $text;
        padding: 1 2;
    }

    #workspace-create-explainer {
        color: $text-muted;
        margin: 0 0 1 0;
    }

    #workspace-create-error {
        color: $error;
        height: auto;
    }

    #workspace-create-folder-row {
        height: auto;
    }

    #workspace-create-folder-path {
        width: 1fr;
    }

    #workspace-create-actions {
        height: auto;
        margin: 1 0 0 0;
        align-horizontal: right;
    }

    #workspace-create-folder-list {
        height: auto;
    }

    .workspace-create-folder-item {
        height: auto;
    }

    .workspace-create-folder-locator {
        width: 1fr;
        content-align: left middle;
    }
    """

    SAFE_MODAL_CONTENT = "#workspace-create-modal"
    BINDINGS: ClassVar = [("escape", "request_safe_cancel", "Cancel")]
    AUTO_FOCUS = "#workspace-create-name"

    def __init__(
        self,
        *,
        registry_service: LocalWorkspaceRegistryService,
        persona_service: Any = None,
        description: str = "Created from the workspace setup dialog.",
    ) -> None:
        """Build the dialog against a registry, with per-surface provenance.

        Args:
            registry_service: Local workspace registry the dialog reads the
                next free identity from and writes the new workspace to.
            description: Provenance stored on the created ``WorkspaceRecord``
                (TASK-17962). Each surface passes its own wording; the
                default covers callers that do not care.
        """
        super().__init__()
        self._registry = registry_service
        self._personas = persona_service
        self._persona_selection = WorkspacePersonaSelection()
        #: Provenance stored on the created ``WorkspaceRecord`` (TASK-17962):
        #: each surface (Console/Settings/Library) passes its own wording so
        #: a workspace's origin is still visible after creation -- restoring
        #: the per-surface description the surfaces used before they shared
        #: this one modal.
        self._description = description
        self._folders: list[str] = []
        #: Folder locator -> its project-skills discovery, populated only
        #: for folders whose root contains a non-empty .SKILLS/ (spec §5.5
        #: create-modal chaining). Keyed by the same resolved-locator string
        #: stored in ``self._folders`` so `_create()` can filter by
        #: ``bound_folders`` without a second discovery pass.
        self._folder_discoveries: dict[str, ProjectSkillsDiscovery] = {}
        self._error = ""
        self._error_origin = None
        # Finding 1: one-shot guard against a double-submit (rapid
        # Enter-Enter, or a double-click race on Create) running
        # create_workspace()/add_folder_binding() twice before the modal
        # actually pops off the screen stack.
        self._committed = False
        # Finding 7: once a workspace has actually been created, a Create
        # press retries only the remaining folder bindings -- the
        # name/sanitize/create_workspace logic below is skipped entirely.
        self._created_workspace_id: str | None = None
        self._created_workspace_name: str = ""
        self._make_active_result: bool = True
        self._offer_profile_interview_result: bool = False
        self._bound_folders: tuple[str, ...] = ()
        # (path -> message) for whatever is still failing after the most
        # recent bind attempt; used to build the partial result if the user
        # cancels instead of retrying.
        self._failed_folder_messages: dict[str, str] = {}
        # Captured once so recompose()s triggered by add/remove-folder don't
        # clobber a user-edited name back to the original suggestion.
        try:
            _, self._suggested_name = next_local_workspace_identity(self._registry)
        except WorkspaceRegistryServiceError:
            # Finding 6a: a raise here (list_workspaces() failing) must not
            # crash the modal before it can even mount -- fall back to an
            # empty suggestion and surface the failure inline so the user
            # can still type a name and retry.
            self._suggested_name = ""
            self._error = (
                "Workspace registry could not be read — you can still type "
                "a name and retry."
            )
        self._name_value = self._suggested_name
        self._folder_path_value = ""
        self._make_active_value = True
        self._offer_profile_interview_value = False

    def compose(self) -> ComposeResult:
        """Build the name/folder-binding form and its action buttons.

        Returns:
            The modal's widget tree: header, explainer, name input, folder
            add/list controls, inline error area, make-active checkbox, and
            the Cancel/Create action row.
        """
        workspace_created = self._created_workspace_id is not None
        offer_profile_interview = (
            self._offer_profile_interview_result
            if workspace_created
            else self._offer_profile_interview_value
        )
        with VerticalScroll(id="workspace-create-modal"):
            yield Static("New Workspace", classes="console-modal-header")
            yield Static(
                _WORKSPACE_EXPLAINER, id="workspace-create-explainer", markup=False
            )
            yield Input(
                value=self._name_value,
                id="workspace-create-name",
                placeholder="Workspace name",
                compact=True,
                disabled=workspace_created,
            )
            yield WorkspacePersonaPicker(
                self._personas,
                selection=self._persona_selection,
                allow_auto=True,
                disabled=workspace_created,
            )
            with Horizontal(id="workspace-create-folder-row"):
                yield Input(
                    value=self._folder_path_value,
                    id="workspace-create-folder-path",
                    placeholder="~/path/to/project (optional)",
                    compact=True,
                )
                yield Button("Browse…", id="workspace-create-browse", compact=True)
                yield Button(
                    "Add folder", id="workspace-create-folder-add", compact=True
                )
            with Vertical(id="workspace-create-folder-list"):
                for index, folder in enumerate(self._folders):
                    discovery = self._folder_discoveries.get(folder)
                    if discovery is not None and discovery.entries:
                        # TASK-17964: grammatically correct singular/plural
                        # rather than the literal "1 project skill(s)"
                        # live-verified during TASK-18705's Step 4.
                        count = len(discovery.entries)
                        noun = "project skill" if count == 1 else "project skills"
                        label = f"{folder} — contains {count} {noun}"
                    else:
                        label = folder
                    with Horizontal(classes="workspace-create-folder-item"):
                        yield Static(
                            label,
                            classes="workspace-create-folder-locator",
                            markup=False,
                        )
                        yield Button(
                            "Remove",
                            id=f"workspace-create-folder-remove-{index}",
                            compact=True,
                        )
            yield _WorkspaceCreateError(
                self._error, id="workspace-create-error", markup=False
            )
            yield Checkbox(
                "Switch to this workspace",
                self._make_active_value,
                id="workspace-create-make-active",
                compact=True,
                disabled=workspace_created,
            )
            yield Checkbox(
                "Define project context after creating",
                offer_profile_interview,
                id="workspace-create-profile-interview",
                disabled=workspace_created,
                compact=True,
            )
            with Horizontal(id="workspace-create-actions"):
                yield Button(
                    "Keep workspace" if workspace_created else "Cancel",
                    id="workspace-create-cancel",
                    compact=True,
                )
                yield Button(
                    "Retry folders" if workspace_created else "Create",
                    id="workspace-create-confirm",
                    compact=True,
                )

    @on(Button.Pressed, "#workspace-create-cancel")
    async def _cancel(self, event: Button.Pressed) -> None:
        event.stop()
        await self.request_safe_cancel(source="button")

    async def _perform_safe_cancel(self, *, source: str) -> None:
        """Route Cancel/Escape/backdrop to a partial result once created.

        Finding 7: a workspace that already exists (folder-binding retry in
        progress) is a fact, not something Cancel can undo -- deliver the
        current state as a result instead of ``None`` so callers still sync
        their workspace list/active-workspace UI.
        """
        if self._created_workspace_id is None:
            await super()._perform_safe_cancel(source=source)
            return
        self.dismiss_safe_once(
            WorkspaceCreateResult(
                workspace_id=self._created_workspace_id,
                name=self._created_workspace_name,
                bound_folders=self._bound_folders,
                failed_folders=tuple(
                    (folder, self._failed_folder_messages.get(folder, ""))
                    for folder in self._folders
                ),
                make_active=self._make_active_result,
                offer_profile_interview=self._offer_profile_interview_result,
                project_skills=self._project_skills_for(self._bound_folders),
            )
        )

    def _project_skills_for(self, folders: tuple[str, ...]) -> tuple:
        """Discoveries for bound folders whose root carries a .SKILLS/ dir.

        Args:
            folders: Locator strings of successfully bound folders.

        Returns:
            The ``ProjectSkillsDiscovery`` entries recorded at Add time for
            those folders, in binding order (spec 2026-08-17 §5.5).
        """
        return tuple(
            self._folder_discoveries[folder]
            for folder in folders
            if folder in self._folder_discoveries
        )

    @on(Button.Pressed, "#workspace-create-browse")
    def _browse(self, event: Button.Pressed) -> None:
        event.stop()

        def _picked(selected: Path | None) -> None:
            if selected is not None:
                self.query_one("#workspace-create-folder-path", Input).value = str(
                    selected
                )

        self.app.push_screen(SelectDirectory(title="Bind Project Folder"), _picked)

    def _stash_form_state(self) -> None:
        """Capture live Input/Checkbox values before a recompose discards them.

        `refresh(recompose=True)` tears down and rebuilds every child widget
        from `compose()`, which re-reads `self._name_value`,
        `self._folder_path_value`, and `self._make_active_value`. Without
        capturing the live values here first, a folder add/remove would
        silently reset a user-edited name back to the original suggestion
        (and an unchecked "make active" box back to checked).
        """
        self._name_value = self.query_one("#workspace-create-name", Input).value
        self._persona_selection = self.query_one(WorkspacePersonaPicker).selection()
        self._folder_path_value = self.query_one(
            "#workspace-create-folder-path", Input
        ).value
        self._make_active_value = self.query_one(
            "#workspace-create-make-active", Checkbox
        ).value
        self._offer_profile_interview_value = self.query_one(
            "#workspace-create-profile-interview", Checkbox
        ).value

    def _set_error(self, message: str) -> None:
        self._error = message
        self._error_origin = self.app.focused
        self.query_one("#workspace-create-error", Static).update(message)
        self.call_after_refresh(self._reveal_error)

    def _reveal_error(self) -> None:
        """Keep the current error beside its action without moving newer focus."""
        origin = self._error_origin
        if (
            not self._error
            or not self.is_attached
            or self.app.screen is not self
            or origin is None
            or not origin.is_attached
            or self.app.focused is not origin
        ):
            return
        content = self.query_one("#workspace-create-modal")
        anchor = origin
        while anchor.parent is not content:
            anchor = anchor.parent
            if anchor is None or anchor is self:
                return
        error = self.query_one("#workspace-create-error")
        children = list(content.children)
        if children.index(error) != children.index(anchor) + 1:
            content.move_child(error, after=anchor)
            self.call_after_refresh(self._reveal_error)
            return
        error.scroll_visible(animate=False, immediate=True)

    @on(Button.Pressed, "#workspace-create-folder-add")
    def _add_folder(self, event: Button.Pressed) -> None:
        event.stop()
        raw = self.query_one("#workspace-create-folder-path", Input).value.strip()
        if not raw:
            self._set_error("")
            return
        try:
            resolved = validate_folder_binding_path(raw, self._folders)
        except WorkspaceRegistryServiceError as exc:
            self._set_error(str(exc))
            return
        resolved_locator = str(resolved)
        self._folders.append(resolved_locator)
        # Pure filesystem scan (no side effects, no trust decisions) so the
        # row can flag "contains N project skills" up front; only stored
        # when there's something to offer later (spec §5.5). Skipped
        # entirely when the kill-switch is off (Finding 1, final review
        # 2026-08-17): the feature's "no scanning" promise must be
        # literally true, not merely "no offer" once the flag was already
        # set. Imported locally (like app.py's startup discovery worker
        # does) rather than at module import time.
        #
        # TASK-17964 (off-thread discovery, decided and NOT implemented):
        # this is a synchronous, blocking filesystem walk on the UI thread.
        # It stays that way. The scan itself is hard-bounded (500 scanned
        # children / 50 recognized entries / 64 KiB frontmatter reads per
        # entry, non-recursive -- see project_skills_discovery.py), so it
        # cannot run away on an ordinary project. The real risk named by
        # the task -- a `.SKILLS/` that resolves onto a slow or hung
        # network mount -- is NOT fixed by moving only this call off-
        # thread: `validate_folder_binding_path` above (line ~330) already
        # did a synchronous `Path.resolve()`/`is_dir()` stat on the exact
        # same filesystem before this line ever runs, on the same UI
        # thread, with no bound at all. A dead mount hangs the modal at
        # validation regardless of what this discovery call does. Moving
        # validation AND discovery off the main thread is a materially
        # different (and separately sized) change; if the hang is ever hit
        # in practice, that's the fix to file, not this one call site.
        from tldw_chatbook.config import get_cli_setting

        if get_cli_setting("skills", "project_skills_prompt_enabled", True):
            discovery = discover_project_skills(resolved)
            if discovery is not None and discovery.entries:
                self._folder_discoveries[resolved_locator] = discovery
            else:
                # Finding 9 (Qodo review, PR #1810): a re-add of the same
                # locator (e.g. after Remove) must not resurrect a stale
                # discovery from an earlier scan when the fresh one finds
                # nothing usable -- assign-or-pop, not assign-only.
                self._folder_discoveries.pop(resolved_locator, None)
        self._error = ""
        self._stash_form_state()
        self._folder_path_value = ""  # the just-consumed path is cleared
        self.refresh(recompose=True)

    @on(Button.Pressed, "#workspace-create-folder-list Button")
    def _remove_folder(self, event: Button.Pressed) -> None:
        event.stop()
        button_id = event.button.id or ""
        try:
            index = int(button_id.rsplit("-", 1)[-1])
        except ValueError:
            return
        if 0 <= index < len(self._folders):
            locator = self._folders[index]
            del self._folders[index]
            # Finding 9 (Qodo review, PR #1810): a removed folder's stale
            # discovery must not linger -- otherwise re-adding a DIFFERENT
            # folder that happens to resolve to the same locator later (or
            # a subsequent buggy rescan) could read an annotation for a
            # folder that is no longer bound at all.
            self._folder_discoveries.pop(locator, None)
            self._error = ""
            self._stash_form_state()
            self.refresh(recompose=True)

    @on(Input.Submitted, "#workspace-create-name")
    def _name_submitted(self, event: Input.Submitted) -> None:
        event.stop()
        self._create()

    @on(Button.Pressed, "#workspace-create-confirm")
    def _confirm(self, event: Button.Pressed) -> None:
        event.stop()
        self._create()

    def _bind_folders(
        self, workspace_id: str, folders: list[str]
    ) -> tuple[list[str], list[tuple[str, str]]]:
        """Attempt to bind each folder, collecting per-folder failures.

        Args:
            workspace_id: The workspace to bind folders onto.
            folders: Folder locators to attempt to bind, in order.

        Returns:
            A ``(bound, failed)`` pair: successfully bound folder paths, and
            ``(path, error message)`` pairs for the ones that failed.
        """
        bound: list[str] = []
        failed: list[tuple[str, str]] = []
        for folder in folders:
            try:
                self._registry.add_folder_binding(workspace_id, folder)
                bound.append(folder)
            except WorkspaceRegistryServiceError as exc:
                failed.append((folder, str(exc)))
        return bound, failed

    def _finish_or_retry_bindings(
        self, newly_bound: list[str], failed: list[tuple[str, str]]
    ) -> None:
        """Dismiss on full success, otherwise leave the modal open to retry.

        Finding 7: a per-folder binding failure must not discard the
        already-created workspace or the successful bindings -- it renders
        the failures inline, narrows ``self._folders`` to just the
        remainder, and resets ``_committed`` so a subsequent Create press
        retries only what is still outstanding.

        Args:
            newly_bound: Folders that just succeeded in this attempt.
            failed: ``(path, error message)`` pairs that just failed.
        """
        all_bound = tuple(self._bound_folders) + tuple(newly_bound)
        if failed:
            self._bound_folders = all_bound
            self._folders = [folder for folder, _message in failed]
            self._failed_folder_messages = dict(failed)
            self._error = (
                f"Created {self._created_workspace_name}. Retry the failed folders "
                "or keep the workspace with its successful bindings.\n"
                + "\n".join(f"{folder}: {message}" for folder, message in failed)
            )
            self._stash_form_state()
            self.run_worker(self._show_binding_retry(), exclusive=True)
            return
        self._bound_folders = all_bound
        self._failed_folder_messages = {}
        self.dismiss_safe_once(
            WorkspaceCreateResult(
                workspace_id=self._created_workspace_id,
                name=self._created_workspace_name,
                bound_folders=all_bound,
                failed_folders=(),
                make_active=self._make_active_result,
                offer_profile_interview=self._offer_profile_interview_result,
                project_skills=self._project_skills_for(all_bound),
            )
        )

    async def _show_binding_retry(self) -> None:
        """Focus the replacement retry action after its form has mounted."""
        await self.recompose()
        self._committed = False
        if not self.is_attached or self.app.screen is not self:
            return
        # TASK-32800.4's guard: the attachment checks above say this modal is
        # still up, not that the recompose produced this particular button.
        confirms = self.query("#workspace-create-confirm")
        if not confirms:
            return
        retry = confirms.first(Button)
        retry.focus()
        self._error_origin = retry
        self.call_after_refresh(self._reveal_error)

    async def _prepare_automatic_creation(self) -> None:
        """Wait without blocking Cancel or owning the shared app initialization."""
        generation = self._safe_mount_generation
        try:
            await self.app.ensure_workspace_agent_provisioning()
        finally:
            if generation == self._safe_mount_generation:
                self._committed = False
        if (
            not self.is_attached
            or self.app.screen is not self
            or self._safe_dismiss_committed
            or generation != self._safe_mount_generation
        ):
            return
        # Re-read the form and validate again after the asynchronous boundary.
        self._create(authority_prepared=True)

    def _create(self, *, authority_prepared: bool = False) -> None:
        # Finding 1: guard against a double-submit (rapid Enter-Enter on the
        # name Input, or a double-click on Create) re-running the side
        # effects below before the modal has actually popped off the screen
        # stack -- without this, a second queued call would create another
        # workspace (auto-generated names don't collide across calls) and
        # then crash with ScreenStackError trying to dismiss twice.
        if self._committed:
            return
        self._committed = True

        if self._created_workspace_id is not None:
            # Finding 7 retry path: the workspace already exists -- only
            # re-attempt the folders that are still outstanding. Name/
            # sanitize/create_workspace logic below is intentionally skipped.
            bound, failed = self._bind_folders(
                self._created_workspace_id, list(self._folders)
            )
            self._finish_or_retry_bindings(bound, failed)
            return

        # Finding 2: validate the name at the boundary before it reaches the
        # registry. Control characters or an overlong name are rejected
        # inline rather than silently truncated/stripped into the DB; a
        # blank name still falls back to the generated suggestion below.
        raw_name = self.query_one("#workspace-create-name", Input).value.strip()
        sanitized_name = sanitize_string(raw_name, 100).strip()
        if raw_name and (sanitized_name != raw_name or not sanitized_name):
            self._committed = False
            self._set_error(
                "Workspace name is too long or contains unsupported characters."
            )
            return
        name = sanitized_name

        # Finding 6b: identity generation (next_local_workspace_identity)
        # can also raise WorkspaceRegistryServiceError -- it must be inside
        # this try so a raise resets _committed instead of permanently
        # locking the Create button for the rest of the session.
        try:
            assistant_kwargs = self.query_one(WorkspacePersonaPicker).creation_kwargs()
            if (
                not assistant_kwargs
                and not authority_prepared
                and callable(
                    getattr(self.app, "ensure_workspace_agent_provisioning", None)
                )
            ):
                self.run_worker(
                    self._prepare_automatic_creation(),
                    group="workspace-create-readiness",
                    exclusive=False,
                    exit_on_error=False,
                )
                return
            workspace_id, generated_name = next_local_workspace_identity(self._registry)
            self._registry.create_workspace(
                workspace_id=workspace_id,
                name=name or generated_name,
                description=self._description,
                **assistant_kwargs,
            )
        except (ValueError, WorkspaceRegistryServiceError) as exc:
            # Nothing was committed -- let the user fix the name/folder and
            # retry rather than permanently locking the dialog.
            self._committed = False
            self._set_error(str(exc))
            return

        self._created_workspace_id = workspace_id
        self._created_workspace_name = name or generated_name
        self._make_active_result = self.query_one(
            "#workspace-create-make-active", Checkbox
        ).value
        self._offer_profile_interview_result = self.query_one(
            "#workspace-create-profile-interview", Checkbox
        ).value

        bound, failed = self._bind_folders(workspace_id, list(self._folders))
        self._finish_or_retry_bindings(bound, failed)
