# ChatbookImportWizard.py
# Description: Multi-step wizard for importing chatbooks
#
"""
Chatbook Import Wizard
----------------------

Implements the chatbook import workflow:
1. File Selection
2. Preview & Validation
3. Conflict Resolution
4. Import Options
5. Progress & Completion
"""

import asyncio
from pathlib import Path
from typing import ClassVar, Dict, List, Any, Optional, Tuple, TYPE_CHECKING

from textual.app import ComposeResult
from textual.containers import Container
from textual import on
from textual.widgets import (
    Static,
    Button,
    Label,
    Tree,
    ProgressBar,
    RadioSet,
    RadioButton,
    Checkbox,
)
from textual.worker import Worker
from textual.reactive import reactive
from loguru import logger

from .BaseWizard import WizardContainer, WizardStep, WizardStepConfig, WizardScreen
from ...Chatbooks.database_paths import get_chatbook_database_paths
from ...Chatbooks.chatbook_importer import (
    IMPORT_OUTCOME_EMPTY,
    IMPORT_OUTCOME_EXCLUDED,
    IMPORT_OUTCOME_FAILED,
    IMPORT_OUTCOME_IMPORTED,
    IMPORT_OUTCOME_NONE,
    IMPORT_OUTCOME_PARTIAL,
    IMPORT_OUTCOME_SKIPPED,
    UNSUPPORTED_BY_IMPORTER_NOUN,
    ChatbookImporter,
    ImportConflict,
    ImportStatus,
    ImportTypeResult,
)
from ...Chatbooks.chatbook_models import ChatbookManifest, ContentType
from ...Chatbooks.conflict_resolver import ConflictResolution
from ...Chatbooks.server_chatbook_service import (
    build_server_import_selections_from_manifest,
    build_server_job_record,
    get_server_import_blockers_from_manifest,
    record_server_job,
)
from ..server_chatbook_service_lease import (
    close_server_chatbook_service_lease,
    server_chatbook_service_lease,
)
from ...Widgets.enhanced_file_picker import EnhancedFileOpen
from tldw_chatbook.Widgets.pausable_progress import PausableProgressBar

if TYPE_CHECKING:
    pass


# --- Result-driven completion reporting (task-19734) ------------------------
#
# Every claim the completion screen makes is derived here, from what the
# import actually recorded. Nothing in this section may consult a manifest:
# a manifest count says what a chatbook *contains*, and the wizard used to
# tick "✓ Imported conversations" off exactly that -- which stays true when
# every single item was skipped as already present.

#: (row id, content type, plural noun) for each per-type status row.
PER_TYPE_STATUS_ROWS: List[Tuple[str, ContentType, str]] = [
    ("status-conversations", ContentType.CONVERSATION, "conversations"),
    ("status-notes", ContentType.NOTE, "notes"),
    ("status-characters", ContentType.CHARACTER, "characters"),
    ("status-media", ContentType.MEDIA, "media items"),
]


def _manifest_item_count(
    manifest: Optional[ChatbookManifest], content_type: ContentType
) -> int:
    """How many items of one content type the chatbook's manifest lists.

    Used only where a claim must be made about what the FILE holds (the
    fatal-error per-type rows, task-19869) -- never to report what a run
    imported, which only results can say (task-19734).
    """
    if manifest is None:
        return 0
    counts = {
        ContentType.CONVERSATION: manifest.total_conversations,
        ContentType.NOTE: manifest.total_notes,
        ContentType.CHARACTER: manifest.total_characters,
        ContentType.MEDIA: manifest.total_media_items,
    }
    return counts.get(content_type, 0)

#: The progress-panel title for each whole-import outcome.
_OUTCOME_TITLES = {
    IMPORT_OUTCOME_IMPORTED: "✅ Import Complete!",
    IMPORT_OUTCOME_PARTIAL: "⚠️ Import Finished With Issues",
    IMPORT_OUTCOME_SKIPPED: "⊘ Nothing Imported",
    IMPORT_OUTCOME_EMPTY: "⊘ Nothing to Import",
    # Distinct from EMPTY on purpose: "there was nothing to import" and "there
    # was something and none of it was attempted" are different facts, and the
    # first is a claim about the user's file (Qodo review of PR #1945).
    IMPORT_OUTCOME_EXCLUDED: "⊘ All Items Left Out",
    IMPORT_OUTCOME_FAILED: "❌ Import Failed",
}


def _count_detail(*parts: Tuple[int, str]) -> str:
    """Join the non-zero ``(count, noun)`` pairs into a readable clause."""
    return ", ".join(f"{count} {noun}" for count, noun in parts if count > 0)


def describe_type_result(result: ImportTypeResult, noun: str) -> Tuple[str, str]:
    """Return the ``(state, text)`` for one content type's status row.

    Takes a result and nothing else, so a row can only ever report what that
    type's import actually did.
    """
    outcome = result.outcome

    if outcome == IMPORT_OUTCOME_NONE:
        return "", f"— No {noun} in this chatbook"

    if outcome == IMPORT_OUTCOME_EXCLUDED:
        # Two different reasons an item was never attempted, reported apart:
        # the user's own choice, and this importer's limit.
        reasons = []
        if result.excluded > 0:
            reasons.append(
                f"{result.excluded} {noun} in this chatbook were not imported "
                "(you turned this option off)"
            )
        if result.unsupported > 0:
            reasons.append(
                f"{result.unsupported} {noun} in this chatbook were not imported "
                "(not supported by this importer)"
            )
        return "", "— " + "; ".join(reasons)

    if outcome == IMPORT_OUTCOME_IMPORTED:
        return "completed", f"✓ Imported {result.successful} {noun}"

    if outcome == IMPORT_OUTCOME_PARTIAL:
        detail = _count_detail(
            (result.skipped, "skipped"),
            (result.failed, "failed"),
            (result.attempted - result.accounted, "unaccounted for"),
        )
        text = f"⚠ Imported {result.successful} of {result.attempted} {noun}"
        if detail:
            text += f" — {detail}"
        return "warning", text

    if outcome == IMPORT_OUTCOME_SKIPPED:
        detail = _count_detail((result.attempted - result.accounted, "unaccounted for"))
        text = f"⊘ Skipped {result.skipped} {noun} — already present, nothing imported"
        if detail:
            text += f" ({detail})"
        return "warning", text

    detail = _count_detail(
        (result.failed, "failed"),
        (result.skipped, "skipped"),
        (result.attempted - result.accounted, "unaccounted for"),
    )
    text = f"✗ Imported no {noun}"
    if detail:
        text += f" — {detail}"
    return "error", text


def describe_import_outcome(status: ImportStatus) -> Tuple[str, str, str]:
    """Return ``(title, banner, state)`` for the completion panel.

    The banner carries the same numbers the summary panel shows, so the two
    cannot disagree.
    """
    outcome = status.outcome
    title = _OUTCOME_TITLES.get(outcome, _OUTCOME_TITLES[IMPORT_OUTCOME_FAILED])
    state = f"outcome-{outcome}"

    # Items of a type this importer cannot write are named on screen wherever
    # they exist. They used to go only into ``status.warnings``, which this
    # panel renders nowhere, so a chatbook of 8 items with 2 importable ones
    # said "2 of 2 item(s) imported" and the other 6 were never mentioned
    # (Qodo review of PR #1945). Items the USER excluded are not repeated
    # here -- their own per-type row already names them.
    unsupported = (status.unsupported_items, UNSUPPORTED_BY_IMPORTER_NOUN)

    if outcome == IMPORT_OUTCOME_IMPORTED:
        detail = _count_detail(unsupported)
        banner = (
            f"✅ Import completed — {status.successful_items} of "
            f"{status.total_items} item(s) imported"
        )
        banner += f" ({detail})." if detail else "."
    elif outcome == IMPORT_OUTCOME_PARTIAL:
        detail = _count_detail(
            (status.skipped_items, "skipped"),
            (status.failed_items, "failed"),
            (status.unaccounted_items, "unaccounted for"),
            unsupported,
        )
        banner = (
            f"⚠️ Import finished — {status.successful_items} of "
            f"{status.total_items} item(s) imported"
        )
        banner += f" ({detail})." if detail else "."
    elif outcome == IMPORT_OUTCOME_SKIPPED:
        detail = _count_detail(
            (status.unaccounted_items, "unaccounted for"), unsupported
        )
        banner = (
            f"⊘ Nothing was imported — {status.skipped_items} of "
            f"{status.attempted_items} item(s) were already present and were "
            "skipped"
        )
        banner += f" ({detail})." if detail else "."
    elif outcome == IMPORT_OUTCOME_EXCLUDED:
        # The chatbook was NOT empty. It held items and this run attempted
        # none of them; say which reason kept each of them out.
        banner = (
            "⊘ Nothing was imported — none of this chatbook's "
            f"{status.left_out_items} item(s) were attempted: "
            f"{status.left_out_detail()}."
        )
    elif outcome == IMPORT_OUTCOME_EMPTY:
        banner = "⊘ Nothing was imported — this chatbook contained no items."
    else:
        detail = _count_detail(
            (status.failed_items, "failed"),
            (status.skipped_items, "skipped"),
            (status.unaccounted_items, "unaccounted for"),
            unsupported,
        )
        banner = "❌ Nothing was imported"
        banner += f" — {detail}." if detail else " and the import reported no results."

    return title, banner, state


class FileSelectionStep(WizardStep):
    """Step 1: File Selection."""

    def __init__(self, wizard: WizardContainer, config: WizardStepConfig, **kwargs):
        super().__init__(wizard, config, **kwargs)
        self.selected_file: Optional[Path] = None

    def compose(self) -> ComposeResult:
        """Compose the file selection UI."""
        with Container(classes="file-selection-container"):
            # Drop zone (visual only for now)
            with Container(classes="drop-zone"):
                with Container(classes="drop-zone-content"):
                    yield Static("📦", classes="drop-zone-icon")
                    yield Static("Drop chatbook file here", classes="drop-zone-text")
                    yield Static("or", classes="drop-zone-text")

            yield Button(
                "Browse for Chatbook",
                id="browse-file",
                variant="primary",
                classes="browse-button",
                tooltip="Choose a .zip Chatbook pack from disk.",
            )

            # File path display
            with Container(
                id="file-path-container", classes="file-path-display hidden"
            ):
                yield Label("Selected file:", classes="path-label")
                yield Static("", id="selected-path", classes="path-value")

    async def on_button_pressed(self, event: Button.Pressed) -> None:
        """Handle button presses."""
        logger.info(f"FileSelectionStep.on_button_pressed: button_id={event.button.id}")
        if event.button.id == "browse-file":
            logger.info(
                "FileSelectionStep.on_button_pressed: Browse button clicked, calling _browse_for_file"
            )
            await self._browse_for_file()

    async def _browse_for_file(self) -> None:
        """Open file browser to select chatbook.

        TASK-34000.19 fix round 1 (found live, 2026-10-22): this used to
        ``await push_screen(file_dialog, wait_for_dismiss=True)`` from a
        button handler. Textual 8 pushes the dialog and THEN raises
        ``NoActiveWorker`` for a wait outside a worker, and the ``except``
        below turned that into an "Error selecting file" toast -- so the
        dialog showed, the user picked a file, and nothing was selected
        (Next stayed disabled; the import could never start). The chosen
        path now arrives through the push callback.
        """
        try:
            # Use the enhanced file picker
            file_dialog = EnhancedFileOpen(
                title="Select Chatbook File", filters=["*.zip"], must_exist=True
            )
            await self.wizard.app_instance.push_screen(
                file_dialog, callback=self._on_file_dialog_dismissed
            )
        except Exception as e:
            logger.opt(exception=True).error(
                f"FileSelectionStep._browse_for_file: Error selecting file: {e}"
            )
            self.wizard.app_instance.notify(
                f"Error selecting file: {str(e)}", severity="error"
            )

    def _on_file_dialog_dismissed(self, file_path: object) -> None:
        """Record the dialog's choice and let the wizard re-validate."""
        if file_path:
            logger.info(
                f"FileSelectionStep._browse_for_file: File selected: {file_path}"
            )
            self.selected_file = Path(str(file_path))
            self._update_file_display()
            # Notify wizard that we can proceed
            self.wizard.refresh_current_step()
        else:
            logger.info("FileSelectionStep._browse_for_file: No file selected")

    def _update_file_display(self) -> None:
        """Update the file path display."""
        if self.selected_file:
            container = self.query_one("#file-path-container", Container)
            container.remove_class("hidden")

            path_display = self.query_one("#selected-path", Static)
            path_display.update(str(self.selected_file))

    def get_step_data(self) -> Dict[str, Any]:
        """Get selected file path."""
        return {"file_path": str(self.selected_file) if self.selected_file else None}

    def validate(self) -> tuple[bool, List[str]]:
        """Validate file selection."""
        errors = []
        if not self.selected_file:
            errors.append("Please select a chatbook file")
        elif not self.selected_file.exists():
            errors.append("Selected file does not exist")
        elif not self.selected_file.suffix == ".zip":
            errors.append("Please select a valid chatbook file (.zip)")

        return len(errors) == 0, errors


class PreviewValidationStep(WizardStep):
    """Step 2: Preview & Validation."""

    def __init__(self, wizard: WizardContainer, config: WizardStepConfig, **kwargs):
        super().__init__(wizard, config, **kwargs)
        self.manifest: Optional[ChatbookManifest] = None
        self.validation_passed = False

    def compose(self) -> ComposeResult:
        """Compose preview UI."""
        with Container(classes="preview-header"):
            yield Static("📋 Chatbook Preview", classes="section-title")

        # Chatbook information
        with Container(classes="chatbook-info"):
            yield Static("", id="chatbook-title", classes="info-title")

            with Container(classes="info-row"):
                yield Static("Description:", classes="info-label")
                yield Static("", id="chatbook-description", classes="info-value")

            with Container(classes="info-row"):
                yield Static("Author:", classes="info-label")
                yield Static("", id="chatbook-author", classes="info-value")

            with Container(classes="info-row"):
                yield Static("Created:", classes="info-label")
                yield Static("", id="chatbook-created", classes="info-value")

            with Container(classes="info-row"):
                yield Static("Version:", classes="info-label")
                yield Static("", id="chatbook-version", classes="info-value")

        # Content preview
        with Container(classes="content-preview"):
            yield Static("Contents:", classes="preview-title")
            yield Tree("Content", id="content-tree", classes="content-tree")

        # Validation results
        with Container(classes="validation-results"):
            yield Static("Validation Results:", classes="validation-title")
            yield Container(id="validation-list")

    def on_show(self) -> None:
        """Load and validate chatbook when entering step."""
        super().on_show()
        self.run_worker(self._load_and_validate_chatbook())

    async def _load_and_validate_chatbook(self) -> None:
        """Load chatbook manifest and validate."""
        file_path = self.wizard.wizard_data.get("file-selection", {}).get("file_path")
        if not file_path:
            return

        try:
            # Create importer
            db_paths = get_chatbook_database_paths()

            importer = ChatbookImporter(db_paths)

            # Preview the chatbook
            self.manifest, error = importer.preview_chatbook(Path(file_path))

            if error:
                self._show_validation_error(error)
                return

            if not self.manifest:
                self._show_validation_error("Failed to load chatbook manifest")
                return

            # Display manifest info
            self._display_manifest_info()

            # Display content tree
            self._display_content_tree()

            # Run validation
            self._run_validation()

        except Exception as e:
            logger.error(f"Error loading chatbook: {e}")
            self._show_validation_error(str(e))

    def _display_manifest_info(self) -> None:
        """Display manifest information."""
        if not self.manifest:
            return

        self.query_one("#chatbook-title", Static).update(f"📚 {self.manifest.name}")
        self.query_one("#chatbook-description", Static).update(
            self.manifest.description or "No description"
        )
        self.query_one("#chatbook-author", Static).update(
            self.manifest.author or "Unknown"
        )
        self.query_one("#chatbook-created", Static).update(
            self.manifest.created_at.strftime("%Y-%m-%d %H:%M")
        )
        self.query_one("#chatbook-version", Static).update(self.manifest.version.value)

    def _display_content_tree(self) -> None:
        """Display content in tree view."""
        if not self.manifest:
            return

        tree = self.query_one("#content-tree", Tree)
        tree.clear()
        root = tree.root

        # Group by content type
        type_counts = {}
        for item in self.manifest.content_items:
            if item.type not in type_counts:
                type_counts[item.type] = 0
            type_counts[item.type] += 1

        # Add summary nodes
        if type_counts.get(ContentType.CONVERSATION):
            root.add(f"💬 Conversations ({type_counts[ContentType.CONVERSATION]})")

        if type_counts.get(ContentType.NOTE):
            root.add(f"📝 Notes ({type_counts[ContentType.NOTE]})")

        if type_counts.get(ContentType.CHARACTER):
            root.add(f"👤 Characters ({type_counts[ContentType.CHARACTER]})")

        if type_counts.get(ContentType.MEDIA):
            root.add(f"🎬 Media ({type_counts[ContentType.MEDIA]})")

        if type_counts.get(ContentType.PROMPT):
            root.add(f"💡 Prompts ({type_counts[ContentType.PROMPT]})")

        if type_counts.get(ContentType.KEPT_BRIEFING):
            root.add(f"📰 Kept Briefings ({type_counts[ContentType.KEPT_BRIEFING]})")

    @staticmethod
    def _expected_content_total(manifest: ChatbookManifest) -> int:
        """Sum of the manifest's per-type statistics.

        Compared against `len(manifest.content_items)` in `_run_validation`
        to flag a stats/content-items mismatch. Every content type the
        manifest tracks a total for must be included here -- a chatbook
        containing only kept briefings (task-1870's own happy path) used
        to sum to 0 while `content_items` held 1, producing a false
        "Statistics mismatch" warning (task-1870 fix-wave F2). Pulled out
        as its own method so this arithmetic can be tested without
        mounting the wizard step.
        """
        return (
            manifest.total_conversations
            + manifest.total_notes
            + manifest.total_characters
            + manifest.total_media_items
            + manifest.total_prompts
            + manifest.total_kept_briefings
        )

    def _run_validation(self) -> None:
        """Run validation checks."""
        validation_list = self.query_one("#validation-list", Container)
        validation_list.remove_children()

        if not self.manifest:
            validation_list.mount(
                Static(
                    "❌ No manifest found", classes="validation-item validation-error"
                )
            )
            self.validation_passed = False
            return

        errors = []
        warnings = []
        successes = []

        # Check version compatibility
        if self.manifest.version == "1.0":
            successes.append("✓ Compatible chatbook version")
        else:
            warnings.append("⚠️ Unknown chatbook version - import may fail")

        # Check for content
        if self.manifest.content_items:
            successes.append(
                f"✓ Found {len(self.manifest.content_items)} content items"
            )
        else:
            warnings.append("⚠️ No content items found in chatbook")

        # Check statistics match
        expected_total = self._expected_content_total(self.manifest)
        actual_total = len(self.manifest.content_items)

        if expected_total == actual_total:
            successes.append("✓ Content statistics match manifest")
        else:
            warnings.append(
                f"⚠️ Statistics mismatch: expected {expected_total}, found {actual_total}"
            )

        # Display results
        for success in successes:
            validation_list.mount(
                Static(success, classes="validation-item validation-success")
            )

        for warning in warnings:
            validation_list.mount(
                Static(warning, classes="validation-item validation-warning")
            )

        for error in errors:
            validation_list.mount(
                Static(error, classes="validation-item validation-error")
            )

        # Overall validation status
        self.validation_passed = len(errors) == 0

        if self.validation_passed:
            validation_list.mount(
                Static(
                    "\n✅ Validation passed - chatbook is ready to import",
                    classes="validation-item validation-success",
                )
            )
        else:
            validation_list.mount(
                Static(
                    "\n❌ Validation failed - please check errors above",
                    classes="validation-item validation-error",
                )
            )

        # Update wizard navigation
        self.wizard.refresh_current_step()

    def _show_validation_error(self, error: str) -> None:
        """Show validation error."""
        validation_list = self.query_one("#validation-list", Container)
        validation_list.remove_children()
        validation_list.mount(
            Static(f"❌ {error}", classes="validation-item validation-error")
        )
        self.validation_passed = False
        self.wizard.refresh_current_step()

    def get_step_data(self) -> Dict[str, Any]:
        """Get validation data."""
        return {"manifest": self.manifest, "validation_passed": self.validation_passed}

    def validate(self) -> tuple[bool, List[str]]:
        """Check if validation passed."""
        errors = []
        if not self.validation_passed:
            errors.append("Chatbook validation failed")
        return len(errors) == 0, errors


class ConflictResolutionStep(WizardStep):
    """Step 3: Conflict Resolution.

    Whether the destination already holds any of this chatbook's items is a
    COMPUTED fact, not a default: this step used to render an unconditional
    "✅ No conflicts detected - all content is new" that no code had checked,
    under a "Potential Conflicts Detected" panel that no code could ever
    reveal (task-19861). Both elements are now driven by
    ``ChatbookImporter.scan_conflicts``, which runs when the step is shown:

    * findings -> the conflict panel lists them, and no "no conflicts" claim
      is made anywhere on the step;
    * a completed scan with no findings -> the "no conflicts" message is
      shown, worded as what was actually checked;
    * no manifest yet, or the scan failed -> the step says nothing about
      conflicts either way.
    """

    #: What one rendered conflict line calls the item's content type.
    _TYPE_LABELS: ClassVar[Dict[ContentType, str]] = {
        ContentType.CONVERSATION: "Conversation",
        ContentType.NOTE: "Note",
        ContentType.CHARACTER: "Character",
        ContentType.MEDIA: "Media item",
    }

    #: The coverage sentence both outcomes state, so neither can over- or
    #: under-claim what "conflict" was measured over. Prompts are not listed
    #: because the resolution strategy does not apply to them; kept briefings
    #: and canvas graphs are matched by content, not by name.
    _COVERAGE_NOTE: ClassVar[str] = (
        "Checked the conversations, notes, characters and media in this "
        "chatbook against your databases."
    )

    def on_show(self) -> None:
        """Run the conflict scan every time the step is shown."""
        super().on_show()
        self.conflict_worker = self.run_worker(self._scan_conflicts(), exclusive=True)

    def compose(self) -> ComposeResult:
        """Compose conflict resolution UI."""
        with Container(classes="resolution-header"):
            yield Static(
                "Configure how to handle items that already exist in your database",
                classes="header-text",
            )

        # Resolution strategy selection
        with Container(classes="strategy-section"):
            yield Static("Conflict Resolution Strategy:", classes="strategy-title")

            yield RadioSet(
                RadioButton("Skip existing items", value=True, id="strategy-skip"),
                RadioButton("Rename imported items", id="strategy-rename"),
                RadioButton("Replace existing items", id="strategy-replace"),
                RadioButton("Merge where possible", id="strategy-merge"),
                id="resolution-strategy",
            )

            # Strategy descriptions
            yield Static(
                "Skip: Keep existing items unchanged, only import new items",
                classes="strategy-description",
            )
            yield Static(
                "Rename: Import all items with new names (e.g., 'Title (Imported)')",
                classes="strategy-description",
            )
            yield Static(
                "Replace: Overwrite existing items with imported versions",
                classes="strategy-description",
            )
            yield Static(
                "Merge: Combine content intelligently (conversations append messages)",
                classes="strategy-description",
            )

        # Conflicts the scan found. Hidden until the scan reports findings;
        # ``_apply_scan_result`` is the code path that reveals it.
        with Container(id="conflict-container", classes="conflict-preview hidden"):
            yield Static("Potential Conflicts Detected:", classes="conflict-title")
            yield Container(id="conflict-list", classes="conflict-list")

        # No conflicts message. Hidden until a scan actually ran and found
        # nothing -- an unearned reassurance is the defect this step is
        # named after (task-19861).
        yield Static(
            "✅ No conflicts detected - all content is new",
            id="no-conflicts",
            classes="no-conflicts hidden",
        )

    async def _scan_conflicts(self) -> None:
        """Scan the destination for items this chatbook would collide with."""
        self._reset_conflict_ui()
        file_path = self.wizard.wizard_data.get("file-selection", {}).get("file_path")
        manifest = self.wizard.wizard_data.get("preview-validation", {}).get("manifest")
        if not file_path or not manifest:
            # Nothing validated yet: say nothing about conflicts either way.
            return
        try:
            db_paths = get_chatbook_database_paths()
            findings, error = ChatbookImporter(db_paths).scan_conflicts(Path(file_path))
        except Exception as e:
            logger.opt(exception=True).error(
                f"ConflictResolutionStep._scan_conflicts: scan failed: {e}"
            )
            return
        if error is not None or findings is None:
            logger.error(
                f"ConflictResolutionStep._scan_conflicts: {error or 'no result'}"
            )
            return
        self._apply_scan_result(findings)

    def _reset_conflict_ui(self) -> None:
        """Hide both conflict elements until the scan says which to show."""
        self.query_one("#conflict-container", Container).add_class("hidden")
        self.query_one("#no-conflicts", Static).add_class("hidden")
        self.query_one("#conflict-list", Container).remove_children()

    def _apply_scan_result(self, findings: List["ImportConflict"]) -> None:
        """Render one completed scan: the findings, or their earned absence."""
        no_conflicts = self.query_one("#no-conflicts", Static)
        if findings:
            conflict_list = self.query_one("#conflict-list", Container)
            for finding in findings:
                label = self._TYPE_LABELS.get(finding.content_type, "Item")
                conflict_list.mount(
                    Static(
                        f"• {label} \"{finding.title}\" — already present as "
                        f"\"{finding.existing_name}\"",
                        classes="conflict-item",
                    )
                )
            self.query_one("#conflict-container", Container).remove_class("hidden")
            # The reassurance copy does not merely get hidden here: a claim
            # this scan just falsified is cleared outright, so it cannot be
            # read back out of the widget tree (task-19861).
            no_conflicts.update("")
        else:
            no_conflicts.update(
                "✅ No conflicts detected — no conversation, note, character "
                "or media item in this chatbook already exists in your "
                "databases. " + self._COVERAGE_NOTE
            )
            no_conflicts.remove_class("hidden")

    def get_step_data(self) -> Dict[str, Any]:
        """Get selected resolution strategy."""
        strategy_map = {
            "strategy-skip": ConflictResolution.SKIP,
            "strategy-rename": ConflictResolution.RENAME,
            "strategy-replace": ConflictResolution.REPLACE,
            "strategy-merge": ConflictResolution.MERGE,
        }

        selected_strategy = ConflictResolution.SKIP  # default
        strategy_set = self.query_one("#resolution-strategy", RadioSet)
        if strategy_set.pressed_button:
            selected_strategy = strategy_map.get(
                strategy_set.pressed_button.id, ConflictResolution.SKIP
            )

        return {"resolution_strategy": selected_strategy}


class ImportOptionsStep(WizardStep):
    """Step 4: Import Options."""

    def compose(self) -> ComposeResult:
        """Compose import options UI."""
        # The next step starts writing as soon as it is shown, so this is the
        # last screen the user can still back out from -- state the real risk
        # here (task-19550). This wizard used to offer a default-ON "Create
        # backup" checkbox that took no backup at all; the honest replacement
        # for a control we cannot honour is the plain fact.
        yield Static(
            "⚠ This import writes directly into your databases and cannot be "
            "undone. The app takes no backup for you — copy your databases "
            "first if you need to be able to go back.",
            id="import-irreversible-warning",
            classes="warning-text",
        )

        with Container(classes="options-section"):
            yield Static("Execution Mode:", classes="section-title")
            yield RadioSet(
                RadioButton("Local import (Recommended)", value=True, id="mode-local"),
                RadioButton("Server import", id="mode-server"),
                id="execution-mode",
            )
            yield Static(
                "Server import currently supports conversations, notes, and characters. "
                "Chatbooks containing prompts, media, embeddings, or evaluations must use local import.",
                classes="option-description",
            )
            yield Static("", id="server-mode-warning", classes="option-description")

        # Import options
        with Container(classes="options-section"):
            yield Static("Import Options:", classes="section-title")

            yield Checkbox(
                "Import media files",
                value=True,
                id="import-media",
                classes="checkbox-option",
            )
            yield Static(
                "Copy referenced media files to local storage",
                classes="option-description",
            )

            # Embedding items are a SERVER-request option only: the local
            # importer cannot write them (it reports the type as unsupported),
            # and chatbooks produced by this app never contain any -- the
            # exporter never writes embedding data, so there is nothing to
            # import even in principle (task-19868). The control is therefore
            # hidden in local mode rather than shown doing nothing: a
            # default-ON box that does nothing is a claim.
            with Container(id="embeddings-option-group", classes="hidden"):
                yield Checkbox(
                    "Import embeddings",
                    value=False,
                    id="import-embeddings",
                    classes="checkbox-option",
                )
                yield Static(
                    "Server import: include embedding items in the request "
                    "(left out when unchecked)",
                    classes="option-description",
                )

            # This box used to read "Merge with existing tags" and was wired
            # straight to the importer's `prefix_imported` flag, which never
            # touches a tag -- it renames items (task-19734). The behaviour is
            # real and worth keeping; the label now says what it does.
            # NB: the square brackets must stay escaped -- Textual renders
            # these strings as console markup, and a bare "[Imported]" is
            # parsed as a style tag and vanishes from the label entirely.
            yield Checkbox(
                r'Prefix imported item names with "\[Imported]"',
                value=True,
                id="prefix-imported",
                classes="checkbox-option",
            )
            yield Static(
                "Renames imported conversations, notes, characters and prompts "
                r'(e.g. "\[Imported] Weekly notes") so you can tell them apart. '
                "Tags and keywords are unaffected.",
                classes="option-description",
            )

    def on_show(self) -> None:
        """Apply initial execution mode when the step is first shown."""
        super().on_show()
        if getattr(self.wizard, "initial_execution_mode", "local") == "server":
            # ``RadioSet.pressed_index`` has no setter (textual 8.x); pressing
            # the radio through its value is the public API and fires the
            # same ``RadioSet.Changed`` a user click does.
            self.query_one("#mode-server", RadioButton).value = True
        self._update_embeddings_control_visibility()
        self._update_server_mode_availability()

    @on(RadioSet.Changed, "#execution-mode")
    def _on_execution_mode_changed(self, event: RadioSet.Changed) -> None:
        """Re-evaluate the options the newly selected mode actually has."""
        self._update_embeddings_control_visibility()
        self._update_server_mode_availability()

    def _update_embeddings_control_visibility(self) -> None:
        """Show the embeddings option only in the mode that consumes it.

        The option changes what the SERVER request includes; the local import
        call takes no embeddings option at all (task-19868), so in local mode
        the control is absent rather than present-and-inert.
        """
        mode_set = self.query_one("#execution-mode", RadioSet)
        server_selected = (
            mode_set.pressed_button is not None
            and mode_set.pressed_button.id == "mode-server"
        )
        group = self.query_one("#embeddings-option-group", Container)
        if server_selected:
            group.remove_class("hidden")
        else:
            group.add_class("hidden")

    async def on_checkbox_changed(self, event: Checkbox.Changed) -> None:
        """Re-evaluate server mode availability when content-affecting options change."""
        if event.checkbox.id in {"import-media", "import-embeddings"}:
            self._update_server_mode_availability()

    def _update_server_mode_availability(self) -> None:
        """Disable server mode when the selected chatbook contains unsupported content."""
        manifest = self.wizard.wizard_data.get("preview-validation", {}).get("manifest")
        import_media = self.query_one("#import-media", Checkbox).value
        import_embeddings = self.query_one("#import-embeddings", Checkbox).value
        blockers = get_server_import_blockers_from_manifest(
            manifest,
            import_media=import_media,
            import_embeddings=import_embeddings,
        )

        warning = self.query_one("#server-mode-warning", Static)
        server_radio = self.query_one("#mode-server", RadioButton)
        mode_set = self.query_one("#execution-mode", RadioSet)

        if blockers:
            server_radio.disabled = True
            if mode_set.pressed_button and mode_set.pressed_button.id == "mode-server":
                self.query_one("#mode-local", RadioButton).value = True
            warning.update(
                "Server import unavailable for this selection. Unsupported content: "
                + ", ".join(blockers)
            )
        else:
            server_radio.disabled = False
            warning.update("Server import is available for the current selection.")

    def get_step_data(self) -> Dict[str, Any]:
        """Get import options."""
        execution_mode = "local"
        mode_set = self.query_one("#execution-mode", RadioSet)
        if mode_set.pressed_button and mode_set.pressed_button.id == "mode-server":
            execution_mode = "server"

        # Every key here is consumed by the import dispatch that follows, in
        # the mode it is collected in: `execution_mode` picks the path,
        # `import_media` and `prefix_imported` are parameters of BOTH import
        # calls, and `import_embeddings` -- collected in server mode only --
        # is a parameter of the server request (it filters embedding items
        # out of the selection). The local importer takes no embeddings
        # option: it cannot write embeddings, and chatbooks contain none
        # because the exporter never writes them (task-19868). Three former
        # keys were collected and read by nothing at all
        # (`preserve_timestamps`, `import_tags` -- task-19734 -- and the
        # local-mode `import_embeddings`, task-19868); their controls are
        # gone from the mode that ignored them.
        options: Dict[str, Any] = {
            "execution_mode": execution_mode,
            "import_media": self.query_one("#import-media", Checkbox).value,
            "prefix_imported": self.query_one("#prefix-imported", Checkbox).value,
        }
        if execution_mode == "server":
            options["import_embeddings"] = self.query_one(
                "#import-embeddings", Checkbox
            ).value
        return options


class ImportProgressStep(WizardStep):
    """Step 5: Progress & Completion."""

    def __init__(self, wizard: WizardContainer, config: WizardStepConfig, **kwargs):
        super().__init__(wizard, config, **kwargs)
        self.import_worker: Optional[Worker] = None
        self.progress_value = reactive(0)
        self.is_complete = reactive(False)
        self.import_status: Optional[ImportStatus] = None
        # Set by the server branch when the job payload carried no item
        # counts at all: unreported is UNKNOWN, not zero (task-19869).
        self._server_counts_unknown = False

    def compose(self) -> ComposeResult:
        """Compose progress UI."""
        with Container(classes="progress-container"):
            yield Static(
                "Importing Chatbook...", id="progress-title", classes="progress-title"
            )

            # Progress bar
            yield PausableProgressBar(
                total=100, show_percentage=True, show_eta=False, id="import-progress"
            )

            # Status list
            with Container(classes="progress-status"):
                yield Static(
                    "⟳ Preparing import",
                    id="status-prepare",
                    classes="status-item active",
                )
                yield Static(
                    "○ Importing conversations",
                    id="status-conversations",
                    classes="status-item",
                )
                yield Static(
                    "○ Importing notes", id="status-notes", classes="status-item"
                )
                yield Static(
                    "○ Importing characters",
                    id="status-characters",
                    classes="status-item",
                )
                yield Static(
                    "○ Importing media", id="status-media", classes="status-item"
                )
                yield Static(
                    "○ Updating indexes", id="status-indexes", classes="status-item"
                )
                yield Static(
                    "○ Finalizing import", id="status-finalize", classes="status-item"
                )

            # Completion message (hidden initially). Its text is written by
            # `_show_completion` from the recorded result -- the panel never
            # ships a pre-baked success claim (task-19734).
            with Container(id="completion-container", classes="hidden"):
                yield Static("", id="completion-message", classes="completion-message")

                # Import statistics
                with Container(classes="completion-stats"):
                    yield Static("Import Summary:", classes="section-title")

                    with Container(classes="stat-row"):
                        yield Static("Total items:", classes="stat-label")
                        yield Static("0", id="stat-total", classes="stat-value")

                    with Container(classes="stat-row"):
                        yield Static("Imported:", classes="stat-label")
                        yield Static(
                            "0", id="stat-imported", classes="stat-value stat-success"
                        )

                    with Container(classes="stat-row"):
                        yield Static("Skipped:", classes="stat-label")
                        yield Static(
                            "0", id="stat-skipped", classes="stat-value stat-warning"
                        )

                    with Container(classes="stat-row"):
                        yield Static("Failed:", classes="stat-label")
                        yield Static(
                            "0", id="stat-failed", classes="stat-value stat-error"
                        )

    def on_show(self) -> None:
        """Start import when entering step."""
        super().on_show()
        # Hide back button during import
        self.wizard.can_go_back = False
        # Start import process
        self.import_worker = self.run_worker(self._import_chatbook())

    async def _import_chatbook(self) -> None:
        """Import the chatbook with progress updates."""
        try:
            # Get wizard data
            file_path = Path(
                self.wizard.wizard_data.get("file-selection", {}).get("file_path", "")
            )
            manifest = self.wizard.wizard_data.get("preview-validation", {}).get(
                "manifest"
            )
            resolution_strategy = self.wizard.wizard_data.get(
                "conflict-resolution", {}
            ).get("resolution_strategy", ConflictResolution.SKIP)
            options = self.wizard.wizard_data.get("import-options", {})
            execution_mode = options.get("execution_mode", "local")

            # Update progress: Preparing
            self._update_status("status-prepare", "active", "⟳ Preparing import...")
            self._update_progress(5)

            # No backup is taken here, and none is claimed: the import writes
            # straight into the live databases with no rollback (task-19550).
            # The options step states that plainly before the user confirms.

            if execution_mode == "server":
                self._update_status(
                    "status-prepare", "active", "⟳ Preparing server import..."
                )
                self._update_progress(20)

                if hasattr(self.wizard.app_instance, "app_config"):
                    config = self.wizard.app_instance.app_config
                elif hasattr(self.wizard.app_instance, "config_data"):
                    config = self.wizard.app_instance.config_data
                else:
                    from ...config import load_settings

                    config = load_settings()

                lease = server_chatbook_service_lease(
                    self.wizard.app_instance,
                    config=config,
                    policy_enforcer=getattr(
                        self.wizard.app_instance, "service_policy_enforcer", None
                    ),
                )
                service = lease.service
                try:
                    server_selections = build_server_import_selections_from_manifest(
                        manifest,
                        import_media=options.get("import_media", True),
                        import_embeddings=options.get("import_embeddings", False),
                    )
                    unsupported = service.validate_server_import_selection(
                        server_selections
                    )
                    if unsupported:
                        raise ValueError(
                            "Server import currently supports only conversations, notes, and characters. "
                            f"Unsupported content in this chatbook: {', '.join(unsupported)}"
                        )

                    response = await service.import_chatbook_from_selection(
                        file_path,
                        selections=server_selections,
                        conflict_resolution=resolution_strategy,
                        prefix_imported=options.get("prefix_imported", False),
                        import_media=options.get("import_media", True),
                        import_embeddings=options.get("import_embeddings", False),
                        async_mode=True,
                    )

                    job_id = response.get("job_id")
                    if not job_id:
                        raise ValueError(
                            response.get(
                                "message", "Server import did not return a job id."
                            )
                        )

                    job_result = response
                    self._update_status(
                        "status-prepare", "completed", "✓ Submitted server import"
                    )
                    self._update_status(
                        "status-indexes", "active", "⟳ Waiting for server import job..."
                    )
                    for _ in range(60):
                        status = str(job_result.get("status", "")).lower()
                        if status in {
                            "completed",
                            "success",
                            "failed",
                            "error",
                            "cancelled",
                        }:
                            break
                        self._update_progress(
                            max(
                                25,
                                min(
                                    95,
                                    int(
                                        job_result.get("progress_percentage", 25) or 25
                                    ),
                                ),
                            )
                        )
                        await asyncio.sleep(1)
                        job_result = await service.get_import_job(job_id)

                    if hasattr(self.wizard, "app_instance"):
                        record_server_job(
                            self.wizard.app_instance,
                            build_server_job_record("import", job_result),
                        )

                    final_status = str(job_result.get("status", "")).lower()
                    if final_status not in {"completed", "success"}:
                        raise ValueError(
                            job_result.get("message")
                            or f"Server import ended with status '{job_result.get('status', 'unknown')}'."
                        )

                    self.import_status = ImportStatus()
                    # Only counts the server actually reported are recorded:
                    # a missing key means UNKNOWN, not zero (task-19869). The
                    # old code defaulted ``successful_items`` to 0 and
                    # hard-set ``skipped_items = 0``, which made a 4-item
                    # chatbook report "this chatbook contained no items" and
                    # invented a skip count the server never sent.
                    raw_successful = job_result.get("successful_items")
                    raw_failed = job_result.get("failed_items")
                    raw_skipped = job_result.get("skipped_items")
                    if raw_successful is not None:
                        self.import_status.successful_items = int(raw_successful or 0)
                    if raw_failed is not None:
                        self.import_status.failed_items = int(raw_failed or 0)
                    if raw_skipped is not None:
                        self.import_status.skipped_items = int(raw_skipped or 0)
                    counts_reported = any(
                        value is not None
                        for value in (raw_successful, raw_failed, raw_skipped)
                    )
                    self._server_counts_unknown = not counts_reported
                    if counts_reported:
                        status_total = (
                            self.import_status.successful_items
                            + self.import_status.failed_items
                            + self.import_status.skipped_items
                        )
                        self.import_status.total_items = status_total
                        self.import_status.processed_items = status_total

                    # A server import returns totals only, so no per-type row
                    # can honestly claim anything (task-19734).
                    self._mark_type_rows_not_itemised()
                    self._update_status(
                        "status-indexes", "completed", "✓ Server import completed"
                    )
                    self._update_status(
                        "status-finalize", "completed", "✓ Import finalized"
                    )
                    self._update_progress(100)
                    await self._show_completion()
                    return
                finally:
                    await close_server_chatbook_service_lease(lease)

            # Create importer
            db_paths = get_chatbook_database_paths()

            importer = ChatbookImporter(db_paths)

            # Mark preparation complete
            self._update_status("status-prepare", "completed", "✓ Prepared import")
            self._update_progress(20)

            # Create import status to track progress
            self.import_status = ImportStatus()

            # Update UI to show what we're importing
            if manifest:
                if manifest.total_conversations > 0:
                    self._update_status(
                        "status-conversations", "active", "⟳ Importing conversations..."
                    )
                if manifest.total_notes > 0:
                    self._update_status(
                        "status-notes", "active", "⟳ Preparing notes..."
                    )
                if manifest.total_characters > 0:
                    self._update_status(
                        "status-characters", "active", "⟳ Preparing characters..."
                    )
                if options.get("import_media", True) and manifest.total_media_items > 0:
                    self._update_status(
                        "status-media", "active", "⟳ Preparing media..."
                    )

            # Perform the actual import
            logger.info(f"Starting chatbook import from {file_path}")

            success, message = importer.import_chatbook(
                chatbook_path=file_path,
                content_selections=None,  # Import all by default
                conflict_resolution=resolution_strategy,
                prefix_imported=options.get("prefix_imported", False),
                import_media=options.get("import_media", True),
                import_status=self.import_status,
            )

            # Update progress based on actual results
            if success:
                # Per-type rows come from the RESULTS the import recorded, not
                # from the manifest's advertised totals (task-19734). A
                # manifest count says what the chatbook contains; only a
                # result says what landed, and an all-skipped re-import used
                # to tick four green "✓ Imported ..." rows off the former.
                self._paint_type_result_rows()

                # Indexes are updated as part of the import
                self._update_status("status-indexes", "completed", "✓ Updated indexes")
                self._update_progress(95)

                # Finalize
                self._update_status(
                    "status-finalize", "completed", "✓ Import completed"
                )
                self._update_progress(100)

                await self._show_completion()
            else:
                # Import failed
                self._update_status(
                    "status-finalize", "error", f"✗ Import failed: {message}"
                )
                await self._show_error(message)

        except Exception as e:
            logger.error(f"Import error: {e}")
            self._update_status("status-finalize", "error", f"✗ Error: {str(e)}")
            await self._show_error(str(e))

    def _update_progress(self, value: int) -> None:
        """Update progress bar."""
        self.progress_value = value
        progress_bar = self.query_one("#import-progress", ProgressBar)
        progress_bar.update(progress=value)

    def _update_status(self, status_id: str, state: str, text: str) -> None:
        """Update status item."""
        status_item = self.query_one(f"#{status_id}", Static)
        status_item.update(text)

        # Update classes
        status_item.remove_class("active", "completed", "error", "warning")
        if state:
            status_item.add_class(state)

    def _mark_type_rows_not_itemised(self) -> None:
        """State plainly that no per-type result is available for this run."""
        for status_id, _content_type, _noun in PER_TYPE_STATUS_ROWS:
            self._update_status(
                status_id, "", "— No per-type breakdown returned by the server"
            )

    def _paint_type_result_rows(self) -> None:
        """Report each content type's own result in its status row.

        The only input is ``self.import_status``: what the import recorded.
        """
        status = self.import_status
        if status is None:
            return

        progress = 30
        for status_id, content_type, noun in PER_TYPE_STATUS_ROWS:
            state, text = describe_type_result(
                status.result_snapshot(content_type), noun
            )
            self._update_status(status_id, state, text)
            progress += 15
            self._update_progress(progress)

    async def _show_completion(self) -> None:
        """Show the completion panel, headlined by what actually happened."""
        self.is_complete = True

        if self._server_counts_unknown:
            # The server completed the job but reported no item counts. That
            # is neither success nor emptiness -- the honest report is
            # "unknown", never a zero the server did not send (task-19869).
            manifest = self.wizard.wizard_data.get("preview-validation", {}).get(
                "manifest"
            )
            item_count = len(manifest.content_items) if manifest else 0
            title = "⚠️ Import Finished — Item Counts Unknown"
            banner = (
                "⚠ The server completed the import but reported no item "
                "counts. "
            )
            if item_count:
                banner += (
                    f"This chatbook contains {item_count} item(s); how many "
                    "of them landed is unknown. "
                )
            banner += "Check your databases before retrying: anything that already landed will conflict or duplicate."
            outcome_state = "outcome-unknown"
        else:
            title, banner, outcome_state = describe_import_outcome(
                self.import_status or ImportStatus()
            )
            # "This chatbook contained no items" is a claim about the FILE
            # (the one-vocabulary rule, task-19734). A server payload of
            # explicit zeros for a chatbook whose manifest lists items must
            # not earn it: the run imported nothing, but the file is not
            # empty (task-19869).
            if outcome_state == f"outcome-{IMPORT_OUTCOME_EMPTY}":
                manifest = self.wizard.wizard_data.get("preview-validation", {}).get(
                    "manifest"
                )
                listed_items = len(manifest.content_items) if manifest else 0
                if listed_items:
                    title = "⊘ Nothing Imported"
                    banner = (
                        "⊘ Nothing was imported — the server reported no "
                        f"items imported. This chatbook contains "
                        f"{listed_items} item(s)."
                    )

        # Update title
        self.query_one("#progress-title", Static).update(title)

        # Show completion container
        completion = self.query_one("#completion-container", Container)
        completion.display = True

        message_widget = self.query_one("#completion-message", Static)
        message_widget.update(banner)
        message_widget.remove_class(
            *(f"outcome-{name}" for name in _OUTCOME_TITLES),
            "outcome-unknown",
        )
        message_widget.add_class(outcome_state)

        # Update statistics. An unreported count is shown as unknown, not as
        # zero (task-19869).
        if self.import_status:
            self.query_one("#stat-total", Static).update(
                "?" if self._server_counts_unknown else str(self.import_status.total_items)
            )
            self.query_one("#stat-imported", Static).update(
                "?" if self._server_counts_unknown else str(self.import_status.successful_items)
            )
            self.query_one("#stat-skipped", Static).update(
                "?" if self._server_counts_unknown else str(self.import_status.skipped_items)
            )
            self.query_one("#stat-failed", Static).update(
                "?" if self._server_counts_unknown else str(self.import_status.failed_items)
            )

        # Update wizard navigation
        self.wizard.can_go_back = False
        next_button = self.wizard.query_one("#wizard-next", Button)
        next_button.label = "Close"
        next_button.variant = "default"

    def _fatal_error_banner(self) -> str:
        """What a fatal import error must say about what was already written.

        There is no rollback (task-19550): items committed before the failure
        are permanently in the databases, and the old error surface concealed
        exactly that -- a frozen "Preparing ..." list over no stats panel,
        reading as "nothing happened" (task-19869).
        """
        status = self.import_status
        if status is None or (
            status.planned_items == 0 and status.accounted_items == 0
        ):
            # The run died before recording any result at all: what happened
            # is unknown in every direction, and saying less would repeat the
            # "nothing happened" reading this surface exists to prevent.
            return (
                "❌ Import failed — it stopped before reporting any result. "
                "Items may still have been written — this import cannot be "
                "rolled back; check your databases before retrying."
            )
        written = status.successful_items
        unaccounted = status.unaccounted_items
        if written and unaccounted:
            detail = (
                f"{written} item(s) were already written and stay written, "
                f"and the {unaccounted} item(s) the import was working on may "
                "also have landed"
            )
        elif written:
            detail = f"{written} item(s) were already written and stay written"
        elif unaccounted:
            detail = (
                f"the {unaccounted} item(s) the import was working on may "
                "have landed; their fate is unknown"
            )
        else:
            detail = "no items were recorded as written"
        return (
            f"❌ Import failed — {detail}. This import cannot be rolled "
            "back. Retry with care: anything that already landed will "
            "conflict or duplicate."
        )

    def _error_surface_row(self, content_type: ContentType, noun: str) -> Tuple[str, str]:
        """What one per-type row says on a fatal-error surface.

        What the import recorded comes first. A type the run never reported
        on says so as UNKNOWN -- never as a claim about the chatbook, and
        never frozen on "Preparing ..." (task-19869).
        """
        status = self.import_status
        if status is not None:
            result = status.result_snapshot(content_type)
            if result.attempted > 0 or result.left_out > 0:
                return describe_type_result(result, noun)

        manifest = self.wizard.wizard_data.get("preview-validation", {}).get("manifest")
        manifest_count = _manifest_item_count(manifest, content_type)
        if content_type == ContentType.MEDIA and manifest_count:
            options = self.wizard.wizard_data.get("import-options", {})
            if not options.get("import_media", True):
                return (
                    "",
                    (
                        f"— {manifest_count} {noun} in this chatbook were not "
                        "imported (you turned this option off)"
                    ),
                )
        if manifest_count:
            return (
                "",
                f"❓ Unknown — the import stopped before {noun} were reported",
            )
        return ("", f"— No {noun} in this chatbook")

    async def _show_error(self, error_message: str) -> None:
        """Show the failure surface, reporting what the run had already done.

        The import writes item by item with no rollback, so a fatal error
        leaves every already-written item in the databases. This surface
        states that, paints each per-type row with what is known about that
        type (including unknown), and shows the counts recorded before the
        failure (task-19869).
        """
        self._update_status("status-finalize", "error", f"✗ Error: {error_message}")
        self.query_one("#progress-title", Static).update("❌ Import Failed")

        for status_id, content_type, noun in PER_TYPE_STATUS_ROWS:
            state, text = self._error_surface_row(content_type, noun)
            self._update_status(status_id, state, text)

        # The stats panel renders on failure too: the counts recorded up to
        # the failure are real, and hiding them reads as "nothing happened".
        completion = self.query_one("#completion-container", Container)
        completion.display = True
        message_widget = self.query_one("#completion-message", Static)
        message_widget.update(self._fatal_error_banner())
        message_widget.remove_class(
            *(f"outcome-{name}" for name in _OUTCOME_TITLES), "outcome-unknown"
        )
        message_widget.add_class("outcome-failed")
        if self.import_status is not None:
            self.query_one("#stat-total", Static).update(
                str(self.import_status.attempted_items)
            )
            self.query_one("#stat-imported", Static).update(
                str(self.import_status.successful_items)
            )
            self.query_one("#stat-skipped", Static).update(
                str(self.import_status.skipped_items)
            )
            self.query_one("#stat-failed", Static).update(
                str(self.import_status.failed_items)
            )

        # Allow going back to fix issues
        self.wizard.can_go_back = True

    def get_step_data(self) -> Dict[str, Any]:
        """Get completion data."""
        return {
            "completed": self.is_complete,
            "import_status": self.import_status.to_dict()
            if self.import_status
            else None,
        }

    def can_proceed(self) -> bool:
        """Can only proceed when import is complete."""
        return self.is_complete


class ChatbookImportWizard(WizardScreen):
    """Chatbook import wizard screen."""

    def compose(self) -> ComposeResult:
        """Compose the wizard screen."""
        wizard = ChatbookImportWizardContainer(self.app_instance, **self.wizard_kwargs)
        yield wizard


class ChatbookImportWizardContainer(WizardContainer):
    """The actual chatbook import wizard implementation."""

    def __init__(self, app_instance, initial_execution_mode="local", **kwargs):
        self.initial_execution_mode = initial_execution_mode
        # Create steps with proper config
        steps = self._create_steps()

        super().__init__(
            app_instance=app_instance,
            steps=steps,
            title="Import Chatbook",
            on_complete=self.handle_wizard_complete,
            **kwargs,
        )

    def _create_steps(self) -> List[WizardStep]:
        """Create wizard steps with proper configuration."""
        return [
            FileSelectionStep(
                wizard=self,
                config=WizardStepConfig(
                    id="file-selection",
                    title="Select File",
                    description="Choose chatbook to import",
                    step_number=1,
                ),
            ),
            PreviewValidationStep(
                wizard=self,
                config=WizardStepConfig(
                    id="preview-validation",
                    title="Preview & Validate",
                    description="Check chatbook contents",
                    step_number=2,
                ),
            ),
            ConflictResolutionStep(
                wizard=self,
                config=WizardStepConfig(
                    id="conflict-resolution",
                    title="Conflict Resolution",
                    description="Handle existing items",
                    step_number=3,
                ),
            ),
            ImportOptionsStep(
                wizard=self,
                config=WizardStepConfig(
                    id="import-options",
                    title="Import Options",
                    description="Configure import settings",
                    step_number=4,
                ),
            ),
            ImportProgressStep(
                wizard=self,
                config=WizardStepConfig(
                    id="import-progress",
                    title="Importing",
                    description="Import in progress",
                    step_number=5,
                ),
            ),
        ]

    def handle_wizard_complete(self, wizard_data: Dict[str, Any]) -> None:
        """Handle wizard completion."""
        # Return import status
        result = wizard_data.get("import-progress", {}).get("import_status")
        if self.app and hasattr(self.app, "pop_screen"):
            self.app.pop_screen(result)
