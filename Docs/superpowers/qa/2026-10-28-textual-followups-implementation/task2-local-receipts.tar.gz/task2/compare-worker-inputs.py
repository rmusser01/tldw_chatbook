"""Bind each failing worker input to BASE without modifying live sources."""

import ast
import hashlib
import json
import re
import subprocess
from pathlib import Path

from Tests.Architecture import test_worker_exclusive_group_inventory as guard


root = Path.cwd()
output = root / ".test-tmp/textual-37266-37268/task2"
base = "8fbc9d2e1d91c31654742736f652d173b07b3ea9"
receipt = json.loads((output / "task2-controls01/inspection.json").read_text(encoding="utf-8"))
failed = [case for case in receipt["reports"][0]["cases"] if case["failures"]]
group_failure = next(c for c in failed if c["name"] == "test_no_ungrouped_exclusive_workers")
paths = {p.replace("\\", "/") for p in re.findall(
    r"^  (tldw_chatbook[^:]+):[0-9]+ \(", group_failure["failures"][0]["message"], re.M
)}
paths.update(guard.FORBIDDEN_MUTATION_LOADERS_BY_PATH)
paths.update({"tldw_chatbook/UI/Research_Window.py",
              "Tests/Architecture/test_worker_exclusive_group_inventory.py",
              "Tests/Architecture/test_timer_path_static_update_inventory.py"})
snapshots = output / "static-inputs"
snapshots.mkdir(exist_ok=True)
records = []
for relative in sorted(paths):
    old = subprocess.check_output([
        "git", "-c", f"safe.directory={root.as_posix()}", "show", f"{base}:{relative}"
    ], cwd=root)
    new = (root / relative).read_bytes()
    name = relative.replace("/", "__")
    (snapshots / ("baseline__" + name)).write_bytes(old)
    (snapshots / ("current__" + name)).write_bytes(new)
    before, after = ast.parse(old.decode("utf-8")), ast.parse(new.decode("utf-8"))
    record = dict(path=relative, baseline_sha256=hashlib.sha256(old).hexdigest(),
                  current_sha256=hashlib.sha256(new).hexdigest(), bytes_identical=old == new,
                  ast_identical=ast.dump(before) == ast.dump(after))
    if relative.startswith("tldw_chatbook/"):
        record["baseline_group_findings"] = guard._violations_in_tree(before)
        record["current_group_findings"] = guard._violations_in_tree(after)
        record["same_group_findings"] = record["baseline_group_findings"] == record["current_group_findings"]
    if relative in guard.FORBIDDEN_MUTATION_LOADERS_BY_PATH:
        owners = {key.split("::",1)[1]:value for key,value in guard.MUTATION_REFRESH_HELPER_INVENTORY.items()
                  if key.startswith(relative + "::")}
        record["baseline_mutation_findings"] = guard._mutation_refresh_violations_in_tree(
            before, forbidden_loaders=guard.FORBIDDEN_MUTATION_LOADERS_BY_PATH[relative], owner_helpers=owners)
        record["current_mutation_findings"] = guard._mutation_refresh_violations_in_tree(
            after, forbidden_loaders=guard.FORBIDDEN_MUTATION_LOADERS_BY_PATH[relative], owner_helpers=owners)
        record["same_mutation_findings"] = record["baseline_mutation_findings"] == record["current_mutation_findings"]
    records.append(record)
result = dict(base=base, sources=records,
              all_group_findings_unchanged=all(r.get("same_group_findings",True) for r in records),
              all_mutation_findings_unchanged=all(r.get("same_mutation_findings",True) for r in records),
              all_other_sources_byte_identical=all(r["bytes_identical"] for r in records
                  if r["path"] != "tldw_chatbook/UI/Research_Window.py"))
(output / "worker-input-comparison.json").write_text(json.dumps(result,indent=2),encoding="utf-8")
print(json.dumps({k:v for k,v in result.items() if k != "sources"},indent=2))
print(json.dumps([r for r in records if r["path"] == "tldw_chatbook/UI/Research_Window.py"],indent=2))
