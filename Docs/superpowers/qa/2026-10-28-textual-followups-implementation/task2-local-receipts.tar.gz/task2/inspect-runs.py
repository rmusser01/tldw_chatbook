"""Retain exact parent/child receipts and measured test phase costs."""

import hashlib
import json
import re
import shutil
import sys
import xml.etree.ElementTree as ET
from pathlib import Path


root = Path.cwd()
base = root / ".test-tmp/textual-37266-37268"
evidence = base / "task2"


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def phases(log):
    return [dict(seconds=float(seconds), phase=phase, node=node)
            for seconds, phase, node in re.findall(
                r"^\s*([0-9.]+)s (setup|call|teardown)\s+(.+)$", log, re.M
            )]


for label in sys.argv[1:]:
    run = base / label
    target = evidence / label
    target.mkdir(exist_ok=True)
    receipt = json.loads((run / "verification.json").read_text(encoding="utf-8"))
    for name in ("command.json", "verification.json", "run.log"):
        shutil.copyfile(run / name, target / name)
    reports = []
    for index, record in enumerate(receipt["reports"]):
        original = Path(record["path"])
        archived = target / ("parent.xml" if index == 0 else f"child-{index:02}.xml")
        shutil.copyfile(original, archived)
        tree = ET.parse(original)
        cases = []
        for case in tree.iter("testcase"):
            cases.append(dict(
                name=case.get("name"), classname=case.get("classname"),
                inclusive_seconds=float(case.get("time", "0")),
                failures=[dict(kind=kind, message=node.get("message"), text=node.text)
                          for kind in ("failure", "error", "skipped")
                          for node in case.findall(kind)],
                properties={prop.get("name"): prop.get("value")
                            for prop in case.findall("./properties/property")},
            ))
        log = original.parent / "pytest.log" if index else run / "run.log"
        log_text = log.read_text(encoding="utf-8", errors="replace") if log.exists() else ""
        if index and log.exists():
            shutil.copyfile(log, target / f"child-{index:02}.log")
        reports.append(dict(
            original_path=str(original), archived_path=archived.relative_to(root).as_posix(),
            sha256=digest(original), suites=[node.attrib for node in tree.iter("testsuite")],
            cases=cases, phases=phases(log_text),
            hidden_phase_notice=re.findall(r"\([^\n]*durations[^\n]*hidden[^\n]*\)", log_text),
            log_sha256=digest(log) if log.exists() else None,
        ))
    result = dict(label=label, exit_code=receipt["exit_code"], reports=reports)
    (target / "inspection.json").write_text(json.dumps(result, indent=2), encoding="utf-8")
    print(json.dumps(dict(label=label, exit_code=receipt["exit_code"],
                          reports=[dict(cases=len(r["cases"]),
                                        failures=sum(bool(c["failures"]) for c in r["cases"]))
                                   for r in reports])))

sources = []
for directory in ("task2-red-sources", "task2-red02-sources", "task2-red03-sources", "task2-green01-sources"):
    for source in sorted((base / directory).glob("*.py")):
        sources.append(dict(path=source.relative_to(root).as_posix(), sha256=digest(source)))
for name in ("tldw_chatbook/UI/Research_Window.py", "Tests/UI/test_research_run_refresh_publication.py",
             "tldw_chatbook/UI/Research_Modules/research_controller.py", "Docs/Architecture/research-workspace.md",
             ".test-tmp/textual-37266-37268/run-targeted.py", str(evidence / "task2_bootstrap_controls.py")):
    source = root / name
    sources.append(dict(path=source.relative_to(root).as_posix(), sha256=digest(source)))
(evidence / "source-hashes.json").write_text(json.dumps(sources, indent=2), encoding="utf-8")
