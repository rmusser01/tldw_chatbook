# One bounded CI fix wave: existing Reader and note-link controls

Read first: this is your complete scope and report contract. Workspace:
C:/Users/GDesktop-1/.codex/worktrees/textual-settings-patterns/tldw_tui.
User requires completedTASK37266–37268, reviewedPRdev, actualgreenCI and feedback
repair. Product tasks are independently approved/Done; source7c2b8f5aab passed
all40Derived+Perf. Metadata3e414ff824 has identical inputs but two existing UI
controls failed. All other application jobs+Perf passed; required aggregate
correctly propagated UI failure. This is one combined fix wave, not a new feature.

## Read and ownership

Read both complete investigation reports in this plan workspace:
ci-media-filter-investigation-report.md and ci-note-open-investigation-report.md.
Read existing TASK34000.18 and TASK34000.11 Markdown specs (glob exactfiles),
applicableAGENTS, relevant architecture/testing lessons and Task5 of
Docs/superpowers/plans/2026-10-28-textual-37266-37268.md.
The root's new Ruling accepts only native setup maintenance under those existing
ACs. Preserve all outcomes. Real Media slow-typing defect is newmediumToDo
TASK37360 (already created), not repaired by a Paste. Broader Notes action loss
is existingTASK34000.85 in the all-refcatalog, not a new task or product claim.

## Allowed permanent source edits — exactly3 files

1. Tests/UI/test_library_media_reader_controls_in_list_view.py:
   only filter setup of
   test_a_dirty_form_filtered_off_the_page_saves_to_the_reader_item_after_trash_back,
   required Paste import/doc qualification, remove now-unused _query_settled.
   Replace P/roduct burst with real focused App Paste("Product"), authoritative
   browse settle and same row expectation. Investigation verified full original
   Reader tail succeeds and its post-browse AST is identical. Keep actual query
   filtering/service, not Input.value/controller assignment. Update comments to
   acknowledge native Paste prep and separate typed-input obligation.
2. Tests/UI/library_note_links_support.py:
   only local _open_notes/_open_note setup barrier and small local support as
   necessary. Acknowledged current/fresh visit plus full expected branch work
   AND actual current tree DOM publication, not any row/busy=false alone.
   See investigation's exact proposed owner fields and identity checks. Support
   already-list callers correctly: follow actual owner semantics, do not invent
   an epoch change where the existing route makes none. Keep one original row
   press, reacquiring its live identity after a native turn; keep original
   _armed_editor unchanged. Single existing30s overall setup budget; no per-phase
   fresh budget, fixed sleeps, global worker drain or action retry. Existing
   RecomposeCaptureGuard.recompose_in_flight and native pending mark are read-only
   publication witnesses; no production flag/API added. Match ordered live note
   placement/note identities to current projection and nonpruning live ancestors.
3. Tests/UI/test_library_note_links_picker_and_preview.py:
   only _blank_note_with_body_focused explicit native title click/focus readiness
   before original _type(VERIFIER), as used in both qualified investigation runs.
   Retain title equality, body click/focus and every later assertion. No product
   new-note focus fix is claimed. Preserve all other AST owners.

No product files, shared generic _wait_for_selector/_armed_editor/_type helpers,
fixtures/services/getters, timeouts, styles, workflows, census or task edits.
Root owns metadata, task notes, public archives, staging/commits/push/review.
Do not dispatch subagents and do not mutateGit/index/branch.

## Findings to address verbatim

1. UI shard12 failed originalReadercase atline192:
   query 'roduct' never settled to1rows:
   MediaBrowseScope(query='t',media_type=None,sort_by='last_modified_desc',page=1) rows=2.
   Controlled native paced keys reproduce it on a FRESH attached field: each
   debounce recompose restores focus/select-all, next key replaces prefix.
   This is real pre-existing product debt; robust Paste is only the Reader test's
   preparation. Original fast and one Paste controls pass; all Reader assertions
   remain independent. Native report/raw receipts already supplied; no need to
   rediscover or repeat full diagnostic battery.
2. UI shard19 failed
   test_typing_two_brackets_opens_a_keyboard_picker_that_inserts_a_real_link,
   line245 reopenNAVIGATION after actual link insertion/autosave:
   AssertionError: timed out waiting for the note editor to open and arm.
   Controlled actual folder answer/row-message delivery reproduces it: target
   attached atpress; native recompose sets pruning=True,parent_active=False before
   its queued Button.Pressed bubbles. No _begin_library_note_load occurs. The
   initial titleNoMatches probe is INVALID for this failure, not a RED substitute.

## Verification — meaningful, bounded, actual owned sources

Apply Superpowers systematic debugging/TDD/verification and Ponytail minimal
patterns. Baseline negative evidence is already retained; save the executed
after-source hashes and actual XML/observations. One native App batch at a time;
slot currently free. ProjectPython and approved run-targeted.py as in reports,
native700 externalprofile/TEMP, bootstrap markers, original180s. No fullsuite
and do not rerun43 passing feature cases.

- Actual owned-source full failingReader journey and the other2 tests in its file.
- Actual owned-source full link journey (all original escape/latch/title/body/
  caret/focus/persistence/navigation/backlink assertions), plus the sibling
  preview-opens-in-app module; select one appropriate extended helper consumer
  if needed to cover its setup mode. No blanket optional test sweep.
- A deterministic native held-folder publication check of the NEW helper: it
  must remain pending after placements rows paint while the real folder answer
  is held, then finish only after actual DOM publication, and its single pressed
  row must deliver. The OLD helper must fail that pending/publication oracle.
  Do not deadlock release waiting for the row press that the new barrier prevents:
  drive release from an independent native App/message witness, drain all holds
  insideApp, and report watchdog/missing-mechanism failures honestly.
- One private wrong-Reader-target negative control showing the existing write-ID
  assertion still fails with Paste setup. A deliberate wrong-target injection is
  permitted ONLY as negative oracle mutation, never in a positive fixture or to
  fake product validity. Preserve source/label of that mutation in receipts.
- Scoped Ruff/no-cache and formatter, recording exact baseline formatting/lint
  debt if present rather than reformatting unrelated owners. AST-compare every
  unaffected owner and the original Reader/link assertion tails. No assertion
  deletion, skipped target, broadened condition or test/job-timeout increase.

Use existing investigation plugins/receipts as tools, not as unexamined truth.
If a proposal lacks a real source field or safe single-budget wait, inspect the
actual bounded owner and choose the smallest correct helper. Any scope need
outside3files requires concrete evidence to root before editing it.

## Report

.superpowers/sdd/2026-10-28-textual-37266-37268/ci-fix-wave-report.md.
Record files/functions, exact changes/why, each finding addressed, native commands
and actual outcomes, raw source/XML/trace hashes, baseline debt/conservation,
invalid attempts, negative controls, limitations and self-review. Root will verify
and commit then dispatch exactly one scoped re-review. Return short status,
test outcomes and concerns. No source commit by you.


## Root-approved Preview helper amendment (before implementation)

Native current-helper comparison proves Enter reaches focused live Preview, then Work/Items recompose starts before App binding dispatch; the old Preview becomes pruning and focus becomes Items grip, so no follow action/load occurs. Extend allowed library_note_links_support._preview setup ONLY to await actual current Preview/Work DOM publication (pending/inflight guards, current live region/body and original painted text, reacquired across a native turn) before returning. Keep all existing focused Preview/Enter/link/picker assertions in every caller. Use existing overall bounds; no fixed sleeps, action retries, direct follow calls, getters/services or production changes. Reuse local publication witness without broadening into a generic framework.

Verify actual current-source extended keyboard consumer plus the already-covering Preview sibling. Add a bounded native held-Preview-publication observation/negative showing old _preview returns before pending publication and new _preview does not; release holds insideApp. Recheck the full link/held helper only if shared publication logic changes; do not rerun Reader whose source is unchanged. Preserve optional prior outcomes (new line87, old source-bootstrap invalid, qualified old line105) as distinct; do not call them exact baseline equivalence. This is the same single combined fix wave, not another product feature or independent fix round.
