"""Library notes canvas: list mode (rows + filter + sort), editor mode, and
create mode (Blank note + template rows)."""

from __future__ import annotations

from collections import Counter, defaultdict
from collections.abc import Sequence
from contextlib import nullcontext
from dataclasses import dataclass
from typing import Any, Callable, ClassVar, Literal

from loguru import logger
from rich.cells import cell_len
from tldw_chatbook.Utils.input_validation import escape_markup
from rich.text import Text
from textual import on
from textual.app import ComposeResult
from textual.binding import Binding
from textual.containers import Horizontal, Vertical, VerticalScroll
from textual.css.query import NoMatches
from textual.events import Blur, Focus, Key, Resize
from textual.message import Message
from textual.message_pump import NoActiveAppError
from textual.widgets import Button, Input, Markdown, Static, TextArea

from tldw_chatbook.Library.library_notes_state import (
    LibraryNoteSessionSnapshot,
    LibraryNotesListState,
    LibraryNotesTrashState,
    build_library_note_template_rows,
    ellipsize_note_title_cells,
)
from tldw_chatbook.Library.library_note_import_state import LibraryNoteImportSnapshot
from tldw_chatbook.Library.library_notes_lasting_sync_state import (
    LibraryNotesLastingSyncSnapshot,
)
from tldw_chatbook.Utils.Utils import elide_path_middle
from tldw_chatbook.Notes.agent_lessons import (
    AGENT_LESSONS_FOLDER,
    AGENT_LESSONS_FOLDER_GLOSS,
)
from tldw_chatbook.Notes.note_import_plan_models import render_note_links
from tldw_chatbook.Library.library_notes_tree_state import (
    LibraryNotesTreeProjection,
    LibraryNotesTreeRow,
)
from tldw_chatbook.Library.library_shell_state import (
    LIBRARY_EXPORT_SELECTED_DISABLED_TOOLTIP,
    LIBRARY_EXPORT_SELECTED_TOOLTIP,
    LIBRARY_NOTES_SORT_FILTERED_TOOLTIP,
    LIBRARY_SELECT_TOGGLE_DISABLED_TOOLTIP,
    back_cue_label,
    library_disabled_action_label,
    library_disabled_reason_line,
    library_selection_count_line,
)
from tldw_chatbook.Widgets.Library.library_rail import LibraryRailSearchInput
from tldw_chatbook.Widgets.Library.library_canvas_sync import (
    PostRecomposeCallback,
    library_row_button,
)
from tldw_chatbook.Widgets.Library.library_choice_strip import (
    compose_library_choice_strip,
)
from tldw_chatbook.Widgets.Library.library_note_import_canvas import (
    LibraryNoteImportCanvas,
)
from tldw_chatbook.Widgets.Library.library_notes_add_from_files_canvas import (
    LibraryNotesAddFromFilesCanvas,
)
from tldw_chatbook.Widgets.Library.library_notes_sync_roots_canvas import (
    LibraryNotesSyncRootsCanvas,
)
from tldw_chatbook.Widgets.detach_safe_text_area import DetachSafeTextArea
from tldw_chatbook.Widgets.recompose_capture_guard import RecomposeCaptureGuard

_SORT_LABELS = {"newest": "Newest", "oldest": "Oldest", "title": "Title"}


def notes_sort_is_blocked(*, tree_projection: object, filter_value: str) -> bool:
    """Whether Sort cannot own the rows currently projected (task-32172).

    A filter window's rows come back from the FTS search seam in its own
    order (grouped by folder path), so Sort is offered disabled there
    rather than silently reordering nothing. Shared with the screen's
    canvas-kwargs pass, which closes an OPEN chooser under exactly this
    condition -- a chooser whose mode outlived what paints it left the
    footer offering "choose sort" and spent the next Escape on nothing
    (task-32128 review round 2).

    Args:
        tree_projection: The projection about to be rendered, if any.
        filter_value: The current Notes filter text.

    Returns:
        Whether the Sort control must render blocked.
    """
    return bool(tree_projection is not None and filter_value.strip())

#: Columns the list pane needs before the browse and transfer toolbars share
#: one row. Under this width the merged row clips its last action off the
#: pane, which is worse than the third row it saves (task-32127, review 1).
#: Their widest composition is New (7), Sort (16), Select (10), Add from
#: files… (19), Export (10), Manage sync folders (23), Last import (15),
#: plus both toolbars' own padding -- 109 cells, measured button by button
#: rather than estimated. task-32172 raised this from 100: Sort left the
#: folder tree in task-32128 and this figure was re-derived without it (97),
#: so putting Sort back pushed the widest frame 16 cells wider and "Last
#: import" fell off the pane at every width from 100 to 108. Pinned at the
#: threshold itself by test_notes_toolbar_fits_at_the_exact_width_it_starts_
#: merging, since the widths pinned either side of it (137, 62, 38) all miss
#: that band.
_TOOLBAR_MERGE_MIN_WIDTH = 109

#: What the list's second action group is called on screen (task-32617 AC#2).
#: The toolbars above it act on the LIST; everything under this heading acts
#: on the folder tree and on whatever row is selected in it. The groups were
#: already built that way -- three separately packed rows -- but nothing said
#: so, so the reader met ten peers with no rule between them (A cap 40).
#: Suppressed in the compact shell, whose rows are a fixed height budget.
NOTES_TREE_ACTION_GROUP_HEADING = "Folders & placement"

#: Why the three placement actions are blocked with no row selected
#: (task-32617 AC#1). Phrased as the reason half of
#: ``library_disabled_reason_line``, like Sort's "clear the filter".
NOTE_ACTIONS_UNSELECTED_REASON = "select a note in the list"

#: How many actions the notes list is allowed to put on screen at once.
#:
#: task-32617 AC#3. Assessor A counted the decision points on this row and
#: got ten, against a four-choice checklist; the number was nobody's
#: decision, it was whatever the last five tasks each added. This is the
#: deliberate ceiling, and ``test_the_notes_list_action_budget_is_the_stated
#: _number`` fails when a new action pushes past it -- which is the point:
#: the next action has to displace one, move behind a disclosure, or move
#: this number on purpose.
#:
#: The 13 are the widest composition the canvas can reach: New, Sort, Select
#: (browse); Add from files…, Export, Manage sync folders, Last import
#: (transfer); New folder plus the three placement actions and Restore
#: folder (folders & placement); Clear filter (status row). Counted from the
#: composed buttons, not by hand.
NOTES_LIST_VISIBLE_ACTION_BUDGET = 13

#: Columns a single action group needs to stay on one row. The transfer group
#: (Add from files…, Export, Last import) is 47 cells and the folder actions
#: (New folder, Rename, Move, Remove) are 46, so at the 44-column pane a
#: 130-column terminal gives the list beside an open note, "Last import" and
#: "Remove" were painted past the pane's right edge and could not be pressed
#: (task-32127, final review). Below this width each group stacks, the way the
#: delete receipt already stacks its recovery actions (task-32123) -- Textual
#: toolbars do not wrap. NOT in a compact shell: there the split screen sheet
#: pins these rows to `height: 1; overflow-x: hidden`, so a stacked column
#: would be clipped to its first button instead of merely running off-pane.
_TOOLBAR_STACK_MIN_WIDTH = 48


def _toolbar_shape(pane_width: int, compact: bool) -> tuple[bool, bool]:
    """Return the two toolbar decisions one pane width drives.

    A width of 0 means "not measured yet": the canvas is composed before the
    reader shell it lives in exists, so the first frame of a Notes visit has
    no resolved Items width. That frame takes the conservative shape -- one
    row per group, neither merged nor stacked -- which is what the list
    rendered before either threshold existed; the first state sync then
    composes at the real width (task-32127, review round 2).

    Args:
        pane_width: Columns the list pane has, or 0 when unmeasured.
        compact: Whether the compact shell pins the toolbars to one row.

    Returns:
        ``(merged, stacked)`` -- whether the browse and transfer groups
        share a row, and whether a group stacks its actions vertically.
    """
    return (
        pane_width >= _TOOLBAR_MERGE_MIN_WIDTH,
        0 < pane_width < _TOOLBAR_STACK_MIN_WIDTH and not compact,
    )


#: The editor header's two action groups, in the order they are composed
#: (``compose`` reads these tuples, so the derived width below cannot drift
#: from the labels on screen). Discard new note is the WIDE wording; a
#: one-line task row (compact or stacked) shortens it to "Discard".
_HEADER_MODE_LABELS = ("Edit", "Preview", "Info")
_HEADER_TASK_LABELS = ("Save", "Use in Console", "Discard new note")
_HEADER_DISCARD_SHORT_LABEL = "Discard"

#: Cells one wide-stage header Button costs beyond its label: its
#: ``padding: 0 1`` (2), Textual's ``line-pad: 1`` on both sides (2) and the
#: toolbar's 1-cell trailing margin. MEASURED at 235x52 with content-sized
#: buttons: "Edit" resolved 8 cells, "Preview" 11, "Use in Console" 18 --
#: label + 4 each -- a cell apart.
_HEADER_ACTION_CHROME = 5

#: Discard new note's ``.library-media-action-danger`` margin is ``0 0 0 4``:
#: the 4-cell gap collapses the preceding button's 1-cell margin, so it
#: costs 3 more cells than a plain action would (measured: the task row
#: resolved 53 cells for 8 + 18 + 20 cells of buttons, 2 of gutter and 4 of
#: gaps).
_HEADER_DANGER_ACTION_GAP = 3

#: ``padding: 0 1`` on each ``.ds-toolbar`` box the header nests -- three on
#: the one-row strip: ``#library-note-primary-actions`` and its two rows.
_HEADER_TOOLBAR_BOX_GUTTER = 2
_HEADER_TOOLBAR_GUTTER = 3 * _HEADER_TOOLBAR_BOX_GUTTER

#: Columns the editor pane needs for a STACKED task row to hold the full
#: "Discard new note": the primary box's gutter and the row's own, Save and
#: Use in Console with their chrome, Discard without a trailing margin, and
#: its danger gap -- 4 + 9 + 19 + 20 + 3 = 55 for the labels above (the row
#: measured 53 inside a 2-cell primary gutter). Below it the row takes the
#: compact wording "Discard" (review M-2: wording follows the row's width,
#: not the shape).
_HEADER_STACKED_TASK_ROW_MIN_WIDTH = (
    2 * _HEADER_TOOLBAR_BOX_GUTTER
    + sum(len(label) + _HEADER_ACTION_CHROME for label in _HEADER_TASK_LABELS[:2])
    + len(_HEADER_TASK_LABELS[2])
    + (_HEADER_ACTION_CHROME - 1)
    + _HEADER_DANGER_ACTION_GAP
)

#: The save state's floor on a shared row (TASK-34000.8 AC#4): "Saved" plus
#: its separator is readable, a one-column "S" is not. TASK-32513/32514 own
#: its home and wording; this is only its minimum width on this row.
_HEADER_STATUS_MIN_WIDTH = 12

#: Columns the editor pane needs for the header to be ONE row: the save
#: state at its floor, then [Edit · Preview · Info] and [Save · Use in
#: Console · Discard new note] content-sized, with Discard's space reserved
#: whether or not it applies (TASK-32623: the mode controls never move).
#: Derived from the labels, not a per-size threshold: 12 + 6 + 49 + 30 + 3
#: = 100 for the labels above, one cell over the 99 measured (Discard has
#: no trailing margin). Below it the header stacks -- the compact shape's
#: machinery, three rows either way, so stacking costs the body nothing.
_HEADER_ONE_ROW_MIN_WIDTH = (
    _HEADER_STATUS_MIN_WIDTH
    + _HEADER_TOOLBAR_GUTTER
    + sum(
        len(label) + _HEADER_ACTION_CHROME
        for label in _HEADER_MODE_LABELS + _HEADER_TASK_LABELS
    )
    + _HEADER_DANGER_ACTION_GAP
)


def _header_shape(work_width: int, compact: bool) -> bool:
    """Whether the editor header stacks its save state and two action rows.

    TASK-34000.8 (review N-05): from the shell's 120-column breakpoint up
    the header was one horizontal strip regardless of how wide the EDITOR
    pane was -- 48 cells at 120x36, 82 at 160x45 with the rail open --
    so Save and Use in Console were painted past the pane edge and the save
    state was squeezed to one column. The shape is now decided from the
    pane the header lives in, the way ``_toolbar_shape`` decides the list
    toolbar's from the Items width.

    Args:
        work_width: Columns the editor pane has (the shell's
            ``reader_width``), or 0 when unmeasured -- which takes the
            one-row shape, exactly as ``_toolbar_shape`` treats 0.
        compact: Whether the compact shell is in force; it has its own
            stacked shape, so this answers False there.

    Returns:
        True when the header should be the stacked shape: the save state
        on its own row, then [Edit · Preview · Info], then [Save · Use in
        Console · Discard].
    """
    return 0 < work_width < _HEADER_ONE_ROW_MIN_WIDTH and not compact


#: Cells a compact toolbar Button costs beyond its own label: the compact
#: sheet's ``padding: 0 1`` (2) plus its ``margin: 0 1 0 0`` (1), plus the
#: cell Textual's Button reserves for its own edge. MEASURED at 60x24, where
#: the three browse actions resolved regions of 7, 16 and 10 cells for the
#: 3-, 12- and 6-character labels "New", "Sort: Newest" and "Select".
_TOOLBAR_ACTION_CHROME = 4

#: Terminal columns below which the Notes canvas drops its authority prefix
#: (review F1). The guide's own narrow-stage threshold: above it the line
#: has room for the noun, below it the compact sheet's two-row cap does not.
_AUTHORITY_PREFIX_MIN_WIDTH = 64


#: Review F5: cells of slack a SPLIT browse row must regain before it
#: rejoins. Splitting costs a line, which can bring a scrollbar into the
#: pane and shave it -- without this the answer would flip straight back
#: and `on_resize` would recompose for ever.
_TOOLBAR_SPLIT_HYSTERESIS = 2

#: task-32143: terminal columns below which the editor chrome strip drops
#: its facts cell. The save state owns that row alone on a narrow terminal,
#: where the compact sheet already caps it at one ellipsized line.
NOTE_CHROME_FACTS_MIN_WIDTH = 80


def library_note_chrome_facts(word_count: int, row: int, column: int) -> str:
    """The editor chrome strip's right-hand facts (task-32143).

    Args:
        word_count: Words in the body draft, counted by the controller for
            the meta line it already builds every keystroke.
        row: Zero-based caret row, as ``TextArea.cursor_location`` reports it.
        column: Zero-based caret column, likewise.

    Returns:
        ``"N words · L:C"`` with a one-based caret -- what every other
        editor's status line means by "line 3, column 14".
    """
    words = "1 word" if word_count == 1 else f"{word_count:,} words"
    return f"{words} · {row + 1}:{column + 1}"


#: task-32640: what an unbound note's header says. The Notes list header
#: already tells a reader that these notes "live in the Library's own
#: database"; this is the same fact for one note, in the same words.
NOTE_LOCATION_DATABASE_ONLY = "In the Library database only — no file on disk"

#: The world a bound note is in. "Synced folder" is the chooser's own noun
#: for the relationship (Keep a folder synced), not an internal name.
NOTE_LOCATION_SYNCED_PREFIX = "In a synced folder"

#: The inline delete prompt (task-32268: rendered inside Info, under Delete).
DELETE_CONFIRM_COPY = "Delete this note? Undo will be available in the Notes list."
#: TASK-32633 (review finding N-03, third sentence): deleting a note that
#: lives in a sync folder never touches its file -- lasting sync holds the
#: folder for review, and in this release only restoring the note resolves
#: it (TASK-34000.15). Said in the prompt, in plain words, and kept short:
#: the Info confirm clips at 120x36 (N-10) and every extra line makes it
#: worse.
DELETE_CONFIRM_COPY_SYNCED = (
    "Delete this note? Its file stays on disk; the synced folder waits for "
    "review until the note is restored. Undo will be available in the Notes list."
)


def delete_confirm_copy(*, synced: bool) -> str:
    """The delete prompt's sentence for a note in, or not in, a sync folder."""

    return DELETE_CONFIRM_COPY_SYNCED if synced else DELETE_CONFIRM_COPY

#: TASK-34000.2: said right after the world when the note's sync folder is
#: held for attention -- nothing typed here reaches the file until it is
#: resolved, so it outranks the path and the write time for the row's cells.
NOTE_LOCATION_ATTENTION = "⚠ Sync needs attention"
#: TASK-34000.2: the Notes list's idle status while any sync folder is held,
#: and the control that resolves it (the list toolbar's own button label).
SYNC_ATTENTION_LIST_STATUS = "⚠ A sync folder needs attention"
SYNC_ATTENTION_NEXT_ACTION = "Open Manage sync folders."

#: Below this many cells for the path, the write time is dropped to buy the
#: path room. Eight cells is "…/x.md" plus an ellipsis -- less than that and
#: the path is noise either way.
_NOTE_LOCATION_PATH_FLOOR = 8


def library_note_location_line(
    path: str, written: str, width: int, *, attention: bool = False
) -> str:
    """Answer "where does this note live?" in one row (task-32640).

    The rule, in the order a reader can predict it: the world is stated
    first and is never shortened; a held sync folder is said next and is
    never shortened either (TASK-34000.2); the path follows, middle-elided
    so its filename survives; the write time follows that, and is the first
    thing dropped when the row runs out of cells.

    Args:
        path: The bound file's absolute path, or ``""`` for a note that
            lives in the Library database alone.
        written: When that file was last written, or ``""`` when there is
            no file or its time could not be read.
        width: Cells the row has. ``0`` or less means "not measured yet",
            where nothing is elided -- the Static's own overflow handling
            is a better answer than a guessed width.
        attention: Whether the file's sync folder is held for attention.

    Returns:
        The single line to render.
    """
    if not path:
        return NOTE_LOCATION_DATABASE_ONLY
    world = NOTE_LOCATION_SYNCED_PREFIX
    if attention:
        world = f"{world} · {NOTE_LOCATION_ATTENTION}"
    written_clause = f"file written {written}" if written else ""
    if width <= 0:
        return " · ".join(part for part in (world, path, written_clause) if part)
    fixed = len(world) + 3
    budget = width - fixed - (len(written_clause) + 3 if written_clause else 0)
    if budget < _NOTE_LOCATION_PATH_FLOOR and written_clause:
        written_clause = ""
        budget = width - fixed
    budget = max(budget, _NOTE_LOCATION_PATH_FLOOR)
    shown = elide_path_middle(path, budget=budget)
    return " · ".join(part for part in (world, shown, written_clause) if part)


def library_note_property_block(
    properties: tuple[tuple[str, str], ...],
    metadata_line: str,
    *,
    compact: bool,
) -> str:
    """Info's Properties: one labelled row per property, or the joined line.

    task-32642: Info rendered every property as one " · "-joined sentence,
    so four facts shared a row in a pane 185 columns wide and 36 rows tall
    -- and in the compact pane, 46 columns wide, that same sentence ran to
    84 characters against a sheet that pins the Static to one row. Measured
    at dev 67bfde41d1, it painted "Created 2026-06-30 20:00 · 10w ago ·
    Modified" and stopped: three of the four properties were off the pane.

    One property per row either way. Wide, the values are aligned into a
    second column; compact drops the padding and keeps a single column, so
    a value is wrapped onto the property's own rows rather than cut (AC#2).

    Args:
        properties: ``(label, value)`` pairs in display order.
        metadata_line: The joined spelling of the same facts. Used only when
            no pairs were supplied -- a caller that predates the pairs.
        compact: Whether the compact sheet is in force.

    Returns:
        The rows to render, newline-separated, or the joined line.
    """
    rows = tuple((label, value) for label, value in properties if value)
    if not rows:
        return metadata_line
    if compact:
        return "\n".join(f"{label} {value}" for label, value in rows)
    width = max(len(label) for label, _ in rows)
    return "\n".join(f"{label.ljust(width)}  {value}" for label, value in rows)


def browse_row_width(labels: tuple[str, ...]) -> int:
    """Cells the browse toolbar row needs to paint these labels.

    Measured from the labels ABOUT to be rendered rather than from a width
    constant, because a disabled action grows a "○ " marker (2 more cells)
    that a constant cannot see.

    Args:
        labels: The rendered action labels, disabled markers included, in
            the order they are composed.

    Returns:
        Total terminal cells the row needs: every label plus the
        per-Button chrome the compact sheet gives it.
    """
    return sum(len(label) + _TOOLBAR_ACTION_CHROME for label in labels)


# TASK-32752: a tree action's painted width includes two Button edge cells
# and two padding cells; the right margin consumes a fifth cell. The row
# itself has padding on both sides. Measured with production CSS, including
# disabled labels, rather than borrowed from the older browse-row budget.
_TREE_ACTION_CHROME = 5
_TREE_TOOLBAR_PADDING = 2


def toolbar_action_rows(
    labels: tuple[str, ...], pane_width: int
) -> tuple[tuple[int, ...], ...]:
    """Split one action group into the rows its pane can actually paint.

    Textual toolbars do not wrap, so a group wider than its pane paints its
    last action past the edge: task-32544 measured "Remove placement" at
    x=48..68 of the 64-column pane a 235-column terminal gives the list
    beside an open note, and it read on screen as "Remove pl". This is the
    guide's own narrow-pane rule ("the toolbar moves the action that does
    not fit onto a row of its own") applied to a group of any size, rather
    than to the single action ``browse_row_overflows`` was written for.

    Greedy, in composed order: actions keep their reading order and a row
    closes as soon as the next one would not fit. An action too wide for
    the pane on its own still takes a row of its own -- there is nothing
    narrower to give it.

    Args:
        labels: The rendered action labels, disabled markers included, in
            the order they are composed.
        pane_width: Columns the pane has, or 0 when unmeasured -- which
            keeps the single row the group has always had.

    Returns:
        One tuple of label indices per row, never empty.
    """
    if pane_width <= 0 or not labels:
        return (tuple(range(len(labels))),)
    budget = pane_width - _TREE_TOOLBAR_PADDING
    rows: list[tuple[int, ...]] = []
    current: list[int] = []
    used = 0
    for index, label in enumerate(labels):
        cost = cell_len(label) + _TREE_ACTION_CHROME
        if current and used + cost > budget:
            rows.append(tuple(current))
            current, used = [], 0
        current.append(index)
        used += cost
    rows.append(tuple(current))
    return tuple(rows)


def browse_row_overflows(pane_width: int, needed: int, *, already_split: bool) -> bool:
    """Whether these actions cannot all be painted on one row of the pane.

    task-32360 AC#2 (critique #10, handed over from the layout branch): at
    60 columns the Notes list pane resolves to 32 cells and the three browse
    actions need 33, so the compact sheet's ``overflow-x: hidden`` cropped
    the last one to "Sel" -- a half word, which is exactly what that AC
    forbids.

    Args:
        pane_width: Columns the list pane has, or 0 when unmeasured (the
            first frame of a visit, before the reader shell resolves) --
            which keeps the single-row shape it has always had.
        needed: Cells the row needs (``browse_row_width``).
        already_split: Whether the row is split right now. A split row only
            rejoins with ``_TOOLBAR_SPLIT_HYSTERESIS`` cells to spare, so
            the line the split itself costs cannot flip the answer back.

    Returns:
        ``True`` when the row needs more cells than the pane can give it.
    """
    if pane_width <= 0:
        return False
    return needed > pane_width - (_TOOLBAR_SPLIT_HYSTERESIS if already_split else 0)


def _drop_leading_title_heading(body: str, title: str) -> str:
    """Drop a body's opening H1 when it only repeats the note's own title.

    task-32551: task-32142 put the title above the Preview body, so an
    imported note whose Markdown starts with ``# <its own title>`` -- the
    normal shape of a file exported from any notes app -- printed that
    title twice, once as the pane's title line and once as the rendered H1.

    Exact match only (case-sensitive, whitespace-stripped): a heading that
    merely resembles the title is the author's own first section and stays.

    Args:
        body: The note's stored Markdown source.
        title: The note's title.

    Returns:
        ``body`` with that one line removed, or ``body`` unchanged.
    """
    wanted = title.strip()
    if not wanted:
        return body
    lines = body.split("\n")
    for index, line in enumerate(lines):
        if not line.strip():
            continue
        if line.strip() == f"# {wanted}":
            del lines[index]
            return "\n".join(lines)
        return body
    return body


def render_preview_source(body: str, *, title: str = "") -> str:
    """Return the note body as the Markdown Preview should render it.

    ONE home for the order, because Preview renders from two places -- the
    compose that mounts the widget and the in-place sync that refreshes it --
    and the sync's staleness check compares against what compose produced. Two
    call sites spelling the rewrites differently is a re-render on every sync
    at best and a stale Preview at worst.

    Args:
        body: The note's stored Markdown source.
        title: The note's title, so a leading ``# <title>`` is not rendered
            underneath the title line Preview already shows (task-32551).
            Omitted callers keep the old behaviour.

    Returns:
        The source with imported `[[Title]](note://<id>)` links reduced to
        their display text (task-32263), Obsidian callout headers turned
        into plain blockquote headers (task-32249), and a redundant opening
        H1 dropped (task-32551).
    """
    # Lazy, like the parser factory below it: this module is on the Library
    # route's pre-import path (Tests/Performance/test_screen_preimport_payload_budget.py).
    from tldw_chatbook.Utils.markdown_parsing import render_obsidian_callouts

    return render_obsidian_callouts(
        render_note_links(_drop_leading_title_heading(body, title))
    )


def compose_note_row_label(
    title: str,
    *,
    folder_label: str = "",
    age_label: str = "",
    tiebreak_label: str = "",
) -> str:
    """Render one Notes list row label: title, folder, age, tie-break.

    The one renderer both list paths call (task-32137). The flat list used
    to put the age on a second line of its own -- a branch nothing reached
    once a folder tree existed -- while the tree rows carried no age at all,
    so two notes titled "Reading list" rendered as identical rows.

    Calling it is not the same as feeding it: only the TREE path passes
    ``folder_label`` and ``tiebreak_label``, so only the tree path tells
    duplicates apart. The flat fallback runs solely when there is no tree
    projection at all, and its row records carry neither a folder nor a
    clock to disambiguate WITH -- widening it would mean widening
    ``LibraryNotesListRow`` for a path no live visit reaches, so the flat
    path deliberately keeps title-and-age (task-32254).

    Args:
        title: The note title, already markup-escaped.
        folder_label: The row's parent folder ("Unfiled", "Work / Q3"),
            included only when the row needs telling apart from a sibling
            with the same title, or when a filter has scattered the rows.
        age_label: Relative age of the note ("3m", "1d"), if known.
        tiebreak_label: The third key (task-32254) -- a modified time of
            day ("14:05") or a short id ("#0f3a") -- present ONLY for rows
            that would otherwise be byte-identical to another row.

    Returns:
        The row label, its present parts joined with " · ".
    """
    return " · ".join(
        part for part in (title, folder_label, age_label, tiebreak_label) if part
    )


def note_row_tiebreak_labels(
    rows: Sequence[LibraryNotesTreeRow],
) -> dict[str, str]:
    """Return a third key per placement, for rows that still collide.

    task-32254: task-32137's folder-then-age discriminator is a no-op in
    the case it is most needed -- two notes titled "Reading list", both
    unfiled, both minutes old, render as the same string, and
    unfiled-and-recent is exactly the state of two notes a user has just
    made twice. The remedy is a THIRD key, and only for the rows that
    actually tie: everything else keeps the label 32137 shipped.

    The preferred key is the modified time of day, which answers "which
    one did I just touch?". Notes written in the same minute (a duplicate
    made by a script or a double press) share that too, so such a group
    falls back to a short, stable id -- ugly, but it is an identity, and
    two rows that cannot be told apart at all are worse.

    Args:
        rows: The projection's rows, note and non-note alike.

    Returns:
        ``placement_id -> label``, holding only the colliding rows.
    """
    groups: dict[tuple[str, str, str], list[LibraryNotesTreeRow]] = defaultdict(list)
    for row in rows:
        if row.kind == "note":
            groups[(row.folder_id or "", row.label, row.age_label)].append(row)
    tiebreakers: dict[str, str] = {}
    for group in groups.values():
        if len(group) < 2:
            continue
        clocks = [row.clock_label for row in group]
        if all(clocks) and len(set(clocks)) == len(group):
            for row, clock in zip(group, clocks, strict=True):
                tiebreakers[row.placement_id] = clock
            continue
        for row in group:
            tiebreakers[row.placement_id] = f"#{str(row.note_id or '')[:4]}"
    return tiebreakers


def _library_note_heading_title(title: str, suffix: str, width: int) -> str:
    """Ellipsize one note title, then re-attach its list-row tie-break.

    task-32548: appended AFTER the ellipsis on purpose -- a title long
    enough to be trimmed is exactly the one whose tie-break would be
    trimmed away first, and the tie-break is the only part of the string
    that identifies WHICH note is open.
    """
    ellipsized = ellipsize_note_title_cells(title, width)
    return f"{ellipsized} · {suffix}" if suffix else ellipsized


def note_title_tiebreak_suffix(
    projection: LibraryNotesTreeProjection | None, note_id: str
) -> str:
    """Return the tie-break label one note's own list row carries.

    task-32548: ``note_row_tiebreak_labels`` is a list-row projection, so a
    reader who opened one of two "Reading list" notes lost the only thing
    telling them apart the moment the editor filled the pane. The editor
    header asks the SAME function the row asked, rather than inventing a
    second discriminator that could disagree with the list beside it.

    Args:
        projection: The notes tree projection the list is drawn from, or
            ``None`` when the tree has not loaded (a flat-list fallback,
            where nothing is tie-broken either).
        note_id: The open note's id.

    Returns:
        The row's third key (``"#8d61"``, ``"09:16"``), or ``""`` when the
        note is absent, unknown, or does not collide with anything.
    """
    rows = projection.rows if projection is not None else ()
    if not rows or not note_id:
        return ""
    labels = note_row_tiebreak_labels(rows)
    if not labels:
        return ""
    for row in rows:
        if row.kind == "note" and row.note_id == note_id:
            label = labels.get(row.placement_id, "")
            if label:
                return label
    return ""


#: Backlink rows Info renders at most (task-32145). The loader asks for one
#: more than this so an over-cap result can say "50+" rather than claim an
#: exact 50 that is not the real number.
LIBRARY_NOTE_BACKLINK_DISPLAY_CAP = 50


def library_note_backlink_header(
    backlinks: tuple[tuple[str, str], ...],
    status: str = "ready",
) -> str:
    """The "Linked from" heading for one note's inbound links.

    Args:
        backlinks: ``(note_id, title)`` rows, possibly one over the display
            cap (see ``LIBRARY_NOTE_BACKLINK_DISPLAY_CAP``).
        status: ``"loading"``, ``"ready"`` or ``"failed"`` -- the count is
            only claimed once the query has actually answered, so a pending
            or failed lookup never reads as a verified zero.

    Returns:
        The heading, which names the count and, when there are none, says
        so in words rather than leaving a bare ``(0)`` to be read as a
        failed load.
    """
    if status == "loading":
        return "Linked from — checking…"
    if status == "failed":
        return "Linked from — couldn't check"
    if not backlinks:
        return "Linked from (0) — no notes link here yet"
    if len(backlinks) > LIBRARY_NOTE_BACKLINK_DISPLAY_CAP:
        return f"Linked from ({LIBRARY_NOTE_BACKLINK_DISPLAY_CAP}+)"
    return f"Linked from ({len(backlinks)})"


def _library_note_back_label(compact: bool) -> str:
    """The single Back wording (task-32139), sized by ``compact``.

    PR #2547 review (Qodo finding 1): compose time and state-apply time
    each inlined this same ternary; a wording change could update one
    rendering path and leave the other stale. One function, both callers.

    task-32553 routes both spellings through ``back_cue_label`` so the
    editor's wording and every other Library back cue share one glyph and
    one grammar.
    """
    return back_cue_label("Back to list" if compact else "Notes")


#: The storage authority every Database Notes surface answers to. Painted once
#: per screen: the mounted list pane owns it, and a work pane beside it drops
#: it rather than repeating the same sentence (task-32063).
#:
#: task-32218: ONE noun for this source. It used to read "Library notes ·
#: Library database", and three sibling sites said "Database Notes · Library
#: database" -- five names for two sources across one journey, so the word a
#: reader clicked in the strip ("Library notes") never reappeared where they
#: landed. The source strip's own label is the noun; everything else here
#: quotes it.
NOTES_AUTHORITY_PREFIX = "Library notes"

#: Every control a reader types a note into. A refresh that would recompose
#: this canvas while one of them has focus is deferred instead (task-32062).
#: The keyword boxes belong here for the same reason the title does -- review
#: of PR #2531: both are live ``Input``s, and only one of the two is mounted
#: visible at a time (wide editor vs. context region).
_NOTE_EDITOR_INPUT_IDS = frozenset(
    {
        "library-note-title",
        "library-note-body",
        "library-note-keywords",
        "library-note-context-keywords",
    }
)


#: TASK-34000.10 (N-07): the class a vetoed field carries (an error outline,
#: ``features/_library_notes_panels.tcss``), and the hint Static under each
#: field that shows the coordinator's reason while that field is vetoed.
#: ``(field selector, hint selector, veto field name)``; both keyword boxes
#: take the keywords mark -- only one of them is ever displayed.
_NOTE_FIELD_INVALID_CLASS = "library-note-field-invalid"
_NOTE_FIELD_HINT_CLASS = "library-note-field-hint"
_NOTE_FIELD_MARKS: tuple[tuple[str, str, str], ...] = (
    ("#library-note-title", "#library-note-title-hint", "title"),
    ("#library-note-keywords", "#library-note-keywords-hint", "keywords"),
    (
        "#library-note-context-keywords",
        "#library-note-context-keywords-hint",
        "keywords",
    ),
    ("#library-note-body", "#library-note-body-hint", "body"),
)


def _library_note_field_hint(widget_id: str, shown: bool, reason: str) -> Static:
    """A field's reason-under-it hint, composed hidden unless its veto stands.

    An empty Static still takes its row, so the hint is ``display``-gated,
    not just cleared (lessons-textual); ``markup=False`` because the reason
    quotes what the user typed.
    """
    hint = Static(
        reason if shown else "",
        id=widget_id,
        classes=_NOTE_FIELD_HINT_CLASS,
        markup=False,
    )
    hint.display = shown
    return hint


#: task-32106 AC#1: shared by every field of the note editor -- see
#: ``NoteEditorInput`` below for the mechanism and the measurement.
_NOTE_FIELD_TAB_BINDINGS = [
    Binding("tab", "screen.focus_next", show=False, priority=True),
    Binding("shift+tab", "screen.focus_previous", show=False, priority=True),
]

#: task-32247: the note body's own keys, on top of the shared Tab pair --
#: see ``NoteEditorTextArea`` for why Textual supplies neither.
_NOTE_BODY_BINDINGS = [
    *_NOTE_FIELD_TAB_BINDINGS,
    Binding("ctrl+end", "cursor_document_end", "End of note", show=False),
    Binding("ctrl+home", "cursor_document_start", "Start of note", show=False),
]


class NoteEditorInput(Input):
    """A note field whose Tab moves focus BEFORE the next key is forwarded.

    task-32253: it also does NOT select its content on focus, and parks the
    caret at the end instead. Textual's ``Input`` default is select-on-focus
    -- browser behaviour, and right for a query box you are about to
    replace. It is wrong for the one field on this screen whose content must
    not be destroyed: live at dev 4a14b3f36f, Shift+Tab out of the body into
    the Title selected "Ideas for study decks" whole, one "!" replaced it,
    and autosave committed the loss a second later ("Saved 15:23"). Textual's
    ``Input`` has no undo, so nothing could bring the title back. The keyword
    boxes share this class and the same rule for the same reason; the path
    fields that genuinely WANT select-on-focus are a different widget
    (task-32251).

    task-32106 AC#1: ``Screen.BINDINGS``' ``Binding("tab", "app.focus_next")``
    is not ``priority=True``, so ``Key(tab)`` is posted to the focused
    ``Input`` and has to bubble one message-queue hop per ancestor up to the
    Screen -- while the App keeps dequeuing the following keys and forwarding
    each to ``self.focused``, which is still this field. Typed fast enough
    (one terminal read, or a message queue backed up behind a busy Library
    screen) the body lands in the title. Reproduced in stock Textual 8 with
    nothing from this repo in it:

        pilot  elapsed=1268.9ms  title='My first note'      body='hello'
        burst  elapsed=   0.2ms  title='My first notehello' body=''

    A priority binding makes the App resolve the focus move before it
    forwards the next key. The action is namespaced to the SCREEN so it
    resolves to ``LibraryScreen.action_focus_next``, which cycles inside
    ``#screen-content`` (task-32052 AC#3) -- ``app.focus_next`` would walk
    the nav bar instead, and a bare ``focus_next`` resolves against this
    ``Input``, which has no such action, so the binding never fires.
    """

    BINDINGS = _NOTE_FIELD_TAB_BINDINGS

    def __init__(self, *args: Any, **kwargs: Any) -> None:
        """Build the field with select-on-focus off unless asked otherwise."""
        kwargs.setdefault("select_on_focus", False)
        super().__init__(*args, **kwargs)

    def _on_focus(self, event: Focus) -> None:
        super()._on_focus(event)
        if not self.select_on_focus:
            # Textual leaves the caret wherever it was (position 0 on a
            # fresh field), which reads as "type here and push the title
            # along". End-of-text is where a reader arriving by Shift+Tab
            # means to continue.
            self.action_end()


class NoteEditorTextArea(DetachSafeTextArea):
    """The note body, with the same synchronous Tab as the fields around it.

    task-32247: it also carries the document-end and document-start keys.
    Textual 8.2.8's ``TextArea`` binds ``home``/``end`` to the LINE ends and
    defines neither a ``ctrl+end`` binding nor a ``cursor_document_end``
    action at all -- so on a 35 KB note, Ctrl+End (in every encoding: the
    named key, ``\\x1b[1;5F``, ``\\x1bOF``-style variants all resolve to the
    one key name ``ctrl+end``) was not swallowed by anything upstream, as
    the report inferred; there was simply no key to swallow, and typing
    after it landed at character 0. Editing near the end of a long note was
    unreachable by keyboard.

    The body has the identical defect one widget over (coordinator addendum
    from a peer session): bursting ``hello`` + Tab + ``world`` into it left
    BOTH words in the body -- measured here as
    ``'helloworldalpha budget line'`` -- because Tab's focus move landed
    after the burst.

    Safe only while ``tab_behavior`` is ``"focus"`` -- Textual's default,
    and what this editor wants: the body is prose, not code, and Tab is how
    a reader leaves it. Under ``"indent"`` this binding would steal the key
    the ``TextArea`` needs, so the pin asserts that behaviour rather than
    trusting the default.

    TASK-34789: a ``DetachSafeTextArea``. A rail switch away from an open
    note removes this pane (``LibraryBrowseReaderShell.swap_work``) while the
    screen's own handler is still running, so the screen cannot process the
    reflow request yet and the next repaint still renders the removed body;
    stock ``TextArea`` raises ``KeyError: text-area--gutter`` there. The
    ``batch_update`` around that removal ends before the reflow can happen,
    so it narrows the window without closing it.
    """

    BINDINGS = _NOTE_BODY_BINDINGS

    #: TASK-34000.11: the keys the open ``[[`` picker owns. Up/Down move its
    #: highlight, Enter/Tab accept, Escape dismisses -- routed to the owning
    #: screen as ``LinkPickerKey`` (ADR-031: routed, not bound), and never
    #: a printable key, so typing keeps narrowing.
    LINK_PICKER_KEYS: ClassVar[frozenset[str]] = frozenset(
        {"up", "down", "enter", "escape", "tab"}
    )

    #: TASK-34000.11: set by the Notes controller while the picker is open.
    #: A plain attribute, not a reactive: it gates a key handler, nothing
    #: paints from it.
    link_picker_open: bool = False
    #: Fix round 1 (M-11): whether the open picker shows a real row. With
    #: only a hint row ("No note titled …", "Keep typing…") Enter and Tab
    #: are NOT intercepted, so the editor inserts its newline / moves focus
    #: and the context change closes the picker; Escape is still claimed.
    link_picker_has_rows: bool = False
    #: Fix round 5: the terminal size the open picker was armed at. A
    #: resize closes the picker, through the screen's own ``Resize`` --
    #: but the App batches that behind a 1/120 s timer, so a key pressed
    #: right behind the terminal's resize reaches ``on_key`` first, while
    #: ``app.size`` already says the new size. That key is handled as if
    #: no picker were open (Enter is the editor's newline), never routed
    #: to a box laid out for a terminal that no longer exists.
    link_picker_terminal: tuple[int, int] | None = None

    class LinkPickerKey(Message):
        """One of ``LINK_PICKER_KEYS`` pressed while the picker is open."""

        def __init__(self, text_area: "NoteEditorTextArea", key: str) -> None:
            super().__init__()
            self.text_area = text_area
            self.key = key

        @property
        def control(self) -> "NoteEditorTextArea":
            return self.text_area

    def on_key(self, event: Key) -> None:
        """Hand the picker its keys before ``TextArea._on_key`` sees them.

        ``prevent_default()`` is what keeps Textual's MRO walk from reaching
        the base ``_on_key`` (``message_pump._get_dispatch_methods`` breaks
        on ``_no_default_action``), so Enter does not also insert a newline;
        ``stop()`` keeps Up/Down/Escape from bubbling to the screen's
        bindings. Tab reaches here only while the screen deactivates its
        priority ``focus_next`` binding -- which it does for an open picker
        that shows a REAL row; over a hint row Tab moves focus as usual
        (fix round 2, R2-2).
        """
        if not self.link_picker_open or event.key not in self.LINK_PICKER_KEYS:
            return
        if self.link_picker_terminal_changed():
            # Fix round 5: the terminal has already changed size; the
            # screen's Resize (and the close it does) is still in the
            # App's 1/120 s batch. The key is the editor's own, and the
            # close is the controller's (routed, like every other close).
            self.link_picker_open = False
            self.link_picker_has_rows = False
            self.post_message(self.LinkPickerKey(self, "resize"))
            if event.key == "escape":
                # Final fix round (P-2): the box is still painted, so the
                # user's Escape means "close it" -- claimed here, or it
                # fell through to the editor's Back and closed the editor.
                event.stop()
                event.prevent_default()
            return
        if event.key != "escape" and not self.link_picker_has_rows:
            return
        event.stop()
        event.prevent_default()
        self.post_message(self.LinkPickerKey(self, event.key))

    def link_picker_terminal_changed(self) -> bool:
        """Whether the terminal is a different size from the one the open
        picker was armed at (fix round 5)."""
        if not self.link_picker_open or self.link_picker_terminal is None:
            return False
        try:
            return tuple(self.app.size) != self.link_picker_terminal
        except Exception:  # noqa: BLE001 - no active app: nothing to compare
            return False

    def watch_scroll_y(self, old_value: float, new_value: float) -> None:
        """Fix round 3 (R3-3): a body scroll re-anchors the open picker, or
        closes it when the caret row leaves the body -- routed as the
        pseudo-key ``"scroll"`` so the controller owns the one re-anchor
        path. ``Widget.watch_scroll_y`` still runs (the scrollbar, the
        refresh); ``TextArea._watch_scroll_y`` is a separate private watcher."""
        super().watch_scroll_y(old_value, new_value)
        if self.link_picker_open and round(old_value) != round(new_value):
            self.post_message(self.LinkPickerKey(self, "scroll"))

    def on_resize(self, event: Resize) -> None:
        """Fix round 5: a resize of the body closes the open picker (its
        anchor geometry is gone), routed as the pseudo-key ``"resize"`` so
        the controller owns the one close path. A terminal resize closes it
        earlier, on the screen's own ``Resize``; this is the body-only case
        (a pane toggle). ``TextArea._on_resize`` still runs after this (the
        MRO walk)."""
        if self.link_picker_open:
            self.post_message(self.LinkPickerKey(self, "resize"))

    def _on_blur(self, event: Blur) -> None:
        """Fix round 1 (M-4): the picker goes with the focus.

        A click on the Title or Shift+Tab out of the body used to leave the
        picker open with this widget's key routing armed. Routed as the
        pseudo-key ``"blur"`` so the controller owns the one close path;
        the MRO walk still reaches ``TextArea._on_blur`` after this.
        """
        if self.link_picker_open:
            self.post_message(self.LinkPickerKey(self, "blur"))

    def action_cursor_document_end(self) -> None:
        """Move the caret to the end of the note body."""
        self.move_cursor(self.document.end)

    def action_cursor_document_start(self) -> None:
        """Move the caret to the start of the note body."""
        self.move_cursor((0, 0))


@dataclass(frozen=True)
class NotesStatusChannels:
    """Independent Notes header channels with one optional recovery action."""

    content_recovery: str
    authority_git: str
    safe_next_action: str | None = None


def resolve_database_note_status_channels(
    *,
    conflict: bool = False,
    unavailable: bool = False,
    read_only: bool = False,
    save_failed: bool = False,
    saving: bool = False,
    dirty: bool = False,
) -> NotesStatusChannels:
    """Resolve Database Notes status in the approved deterministic order.

    Args:
        conflict: Whether the database note and editor draft conflict.
        unavailable: Whether the Library database cannot currently be reached.
        read_only: Whether the active note cannot be edited.
        save_failed: Whether the latest save attempt failed.
        saving: Whether a save is currently running.
        dirty: Whether the editor contains unsaved changes.

    Returns:
        The independent content, authority, and safe-action status channels.
    """
    if conflict:
        content = "Conflict — the note changed elsewhere; your draft is preserved."
        safe = "Review recovery"
    elif unavailable:
        content = (
            "Unavailable — the database cannot be reached; your draft is preserved."
        )
        safe = "Retry when storage is available"
    elif read_only:
        content = "Read-only — this note cannot be changed; your draft is preserved."
        safe = "Keep the draft"
    elif save_failed:
        content = "Save failed — your draft remains in the editor."
        safe = "Retry Save"
    elif saving:
        content, safe = "Saving…", None
    elif dirty:
        content, safe = "Unsaved changes", None
    else:
        content, safe = "Saved", None
    return NotesStatusChannels(content, NOTES_AUTHORITY_PREFIX, safe)


@dataclass(frozen=True)
class _EditorSurfaceFlags:
    """Which editor surfaces one presentation state shows (TASK-34000.25).

    The one derivation both ``_compose_editor`` and ``apply_session_state``
    read -- see ``LibraryNotesCanvas._editor_surface_flags``.
    """

    conflict: bool
    confirming_delete: bool
    bulk_read_only: bool
    show_context: bool
    show_preview: bool
    show_editor: bool
    locked: bool


def _pending_widget_lookup(roots: Sequence[Any]) -> Callable[[str], Any]:
    """Resolve ``#id`` selectors over a composed-but-unmounted widget tree.

    TASK-34000.25: inside ``compose`` a child yielded under ``with
    Container():`` is attached to that container at yield time
    (``compose_add_child`` -> ``_pending_children``) and nothing is mounted
    until the generator ends, so the tree is complete -- and still
    unmounted, hence unpainted -- when ``_compose_editor`` reaches its last
    line. Gating the surfaces there is what makes the first frame right.
    """
    index: dict[str, Any] = {}

    def walk(widget: Any) -> None:
        widget_id = getattr(widget, "id", None)
        if widget_id:
            index[f"#{widget_id}"] = widget
        for child in getattr(widget, "_pending_children", ()):
            walk(child)

    for root in roots:
        walk(root)

    def lookup(selector: str) -> Any:
        try:
            return index[selector]
        except KeyError as exc:
            raise NoMatches(f"No composed node matches {selector!r}") from exc

    return lookup


@dataclass(frozen=True)
class LibraryNotePresentationState:
    """Immutable presentation input for one mounted Database Note canvas.

    The coordinator snapshot is the only source of draft text. Everything
    else describes how that draft is presented; applying this state must not
    perform persistence, navigation, or draft mutation.
    """

    snapshot: LibraryNoteSessionSnapshot
    metadata_line: str
    status_line: str
    #: task-32642: the same facts ``metadata_line`` joins, as ``(label,
    #: value)`` pairs. Info renders these as aligned rows on a wide
    #: terminal and falls back to the joined line when compact, where the
    #: sheet pins the meta Static to one row.
    properties: tuple[tuple[str, str], ...] = ()
    #: task-32640: the file this note is kept in step with, or ``""`` when
    #: it lives in the Library database alone. Resolved live per note by
    #: ``_load_library_note_location`` -- never carried on the note record.
    location_path: str = ""
    #: task-32640: when that file was last written, as the filesystem
    #: reports it, or ``""`` (no file, or it could not be read).
    location_written: str = ""
    #: TASK-34000.2: whether that file's sync folder is held for attention
    #: (an open entry, a conflict, a failed pass) -- the location row and the
    #: status line then say so instead of a plain "Saved".
    location_attention: bool = False
    region: Literal["editor", "context"] = "editor"
    presentation: Literal["edit", "preview"] = "edit"
    compact: bool = False
    validation: bool = False
    #: TASK-34000.10 (N-07): the field the standing veto named ("title" /
    #: "body" / "keywords") and the coordinator's own reason, or "" / "" when
    #: no veto stands. The field is outlined and the reason shown directly
    #: under it; both keyword boxes carry the keywords mark (one is displayed).
    validation_field: str = ""
    validation_message: str = ""
    #: TASK-34000.9: whether an autosave is armed or running right now. The
    #: status line promises "changes save automatically" for a dirty note
    #: only while this holds; a modal stops the timer, and a dirty note with
    #: nothing scheduled names Save instead.
    autosave_scheduled: bool = False
    conflict: bool = False
    conflict_running: bool = False
    confirming_delete: bool = False
    destructive_running: bool = False
    discard_new_note: bool = False
    transfer_status: str = ""
    transfer_running: bool = False
    bulk_read_only: bool = False
    bulk_included: bool = False
    status_channels: NotesStatusChannels | None = None
    #: ``(note_id, title)`` for each note linking to this one (task-32145).
    backlinks: tuple[tuple[str, str], ...] = ()
    #: Whether the backlink query has answered yet -- see
    #: ``library_note_backlink_header``.
    backlinks_status: str = "loading"
    #: TASK-34000.11: ``(label, note_id)`` for each stored note link the body
    #: carries, computed only while Preview is shown (the same gate the
    #: preview source uses). The Preview's Enter follows the one link or
    #: lists several; the footer advertises ``enter follow link`` from it.
    note_links: tuple[tuple[str, str], ...] = ()
    #: Words in the draft body, for the editor chrome strip (task-32143).
    #: The controller counts this for ``metadata_line`` anyway; carrying the
    #: number instead of the sentence keeps the strip off a second scan.
    word_count: int = 0
    #: task-32548: the tie-break the open note's own LIST row carries when
    #: its title collides with another visible note ("· #8d61" / "· 09:16"),
    #: or ``""`` when nothing collides. Computed once per canvas sync from
    #: the projection the list is drawn from, so the editor header and the
    #: list row can never disagree about which note is open.
    title_suffix: str = ""


class _LibraryNotesTreePagerButton(Button):
    """Keep semantic focus during an inert loading-state replacement."""

    _retain_disabled_focus = False

    @property
    def focusable(self) -> bool:
        """Allow only the recompose restorer to retain disabled focus."""
        return self._retain_disabled_focus or super().focusable

    def retain_semantic_focus(self) -> None:
        """Restore focus without making a disabled pager activatable."""
        self._retain_disabled_focus = True
        self.focus()
        self.app.call_later(self._clear_disabled_focus_override)

    def _clear_disabled_focus_override(self) -> None:
        self._retain_disabled_focus = False


class LibraryNotesCanvas(PostRecomposeCallback, RecomposeCaptureGuard, Vertical):
    """Render the Library notes canvas: the list view, or the note editor.

    Attributes:
        list_state: List-view display state (header, filter, sort, rows).
            Only used when ``mode == "list"``.
        sort_mode: Current notes sort mode key (``"newest"``/``"oldest"``/
            ``"title"``), used to label the sort control.
        filter_value: Current notes filter text, prefilled into the filter
            ``Input``.
        mode: ``"list"`` renders the notes list; ``"loading"`` renders the
            editor loading/retry receipt; ``"editor"`` renders the in-canvas
            note editor for ``presentation_state``; ``"create"`` renders the
            Blank note / template picker reached from the rail's Create > New
            note row; ``"sync"`` renders the in-canvas notes sync panel for
        presentation_state: Canonical snapshot plus presentation-only state.
            Required when ``mode == "editor"``.
        import_snapshot: Reviewed one-time import presentation state. Required
            when ``mode == "import"``.
        import_receipt_available: Whether the latest same-session receipt can
            reopen from list mode.
        title_placeholder_only: When ``True`` (editor mode only), the title
            ``Input`` renders empty with an "Untitled" placeholder instead
            of a literal editable "Untitled" value -- LIB-14's fix for a
            just-created, never-touched "Blank note": with a literal
            ``value="Untitled"``, typing right after opening the note
            landed after the existing text instead of replacing it (e.g.
            "UntitledAtlas follow-ups"). An empty value with a placeholder
            sidesteps the ambiguity entirely -- there is no text to land
            after. The screen sets this only while the open note is still
            its own pristine "Blank note" (the same condition that also
            arms it for GC-on-exit -- see
            ``_notes_state.pending_blank_gc_id``); it never applies to a
            note whose title happens to equal the word "Untitled" by the
            user's own choice.
        compact: Whether compact, 60-column-safe action labels are active.
        create_running: Whether a Create request is currently in flight.
        create_status: Visible Create completion or recovery status.
    """

    #: PR #3055 review (Important 1): the compose-time surface gating has
    #: fallen through to the post-refresh path at least once this process.
    #: Class-level so the WARNING is logged once, not once per note opened.
    _pending_lookup_warned: ClassVar[bool] = False

    def __init__(
        self,
        list_state: LibraryNotesListState | None = None,
        *,
        sort_mode: str = "newest",
        filter_value: str = "",
        mode: str = "list",
        presentation_state: LibraryNotePresentationState | None = None,
        import_snapshot: LibraryNoteImportSnapshot | None = None,
        import_receipt_available: bool = False,
        lasting_sync_snapshot: LibraryNotesLastingSyncSnapshot | None = None,
        tree_projection: LibraryNotesTreeProjection | None = None,
        tree_selected_placement_id: str = "",
        tree_deleted_folder_available: bool = False,
        trash: LibraryNotesTrashState | None = None,
        title_placeholder_only: bool = False,
        compact: bool = False,
        pane_width: int = 0,
        create_running: bool = False,
        create_status: str = "",
        load_state: str = "loading",
        load_message: str = "",
        authority_id: str = "library-notes-authority",
        **kwargs: Any,
    ) -> None:
        """Initialize one list, editor, create, sync, or import canvas.

        Args:
            list_state: List-mode rows, counts, selection, and empty-state copy.
            sort_mode: Active list sort key.
            filter_value: Text prefilled into the list filter.
            mode: Canvas surface to compose: list, loading, editor, create,
                or sync.
            presentation_state: Canonical editor snapshot and UI-only flags.
            import_snapshot: Display state for the one-time import surface.
            tree_projection: Placement-aware folder rows for list mode.
            tree_selected_placement_id: Context row for folder actions.
            tree_deleted_folder_available: Whether Undo folder removal is available.
            title_placeholder_only: Render an empty title with an Untitled
                placeholder for a pristine newly-created note.
            compact: Whether 60-column-safe controls and labels are active.
            pane_width: Columns the mounted list pane has, from the resolved
                reader layout. Only the toolbar reads it, to decide whether
                one row can hold both action groups; ``0`` (unknown) keeps
                them on their own rows.
            create_running: Whether note creation is in progress.
            create_status: Visible creation completion or recovery status.
            load_state: Editor-load state (``"loading"`` or ``"failed"``).
            load_message: Recovery copy shown after an editor-load failure.
            **kwargs: Additional keyword arguments forwarded to ``Vertical``.
        """
        super().__init__(**kwargs)
        self._children_ready = False
        self.list_state = list_state
        self.sort_mode = sort_mode
        self.filter_value = filter_value
        self.mode = mode
        self.presentation_state = presentation_state
        self.import_snapshot = import_snapshot
        self.import_receipt_available = import_receipt_available
        self.lasting_sync_snapshot = lasting_sync_snapshot
        self.tree_projection = tree_projection
        self.tree_selected_placement_id = tree_selected_placement_id
        self.tree_deleted_folder_available = tree_deleted_folder_available
        self.trash = trash
        self.title_placeholder_only = title_placeholder_only
        self.compact = compact
        self.pane_width = pane_width
        self.create_running = create_running
        self.create_status = create_status
        self.load_state = load_state
        self.load_message = load_message
        self.authority_id = authority_id
        #: task-32360: cells the browse toolbar row needed the last time it
        #: was composed, so ``on_resize`` can re-decide the row split once
        #: this pane's real width is known, and that measured width.
        self._browse_row_needed = 0
        self._browse_overflow = False
        self._measured_width = 0
        #: TASK-34000.8: the EDITOR pane's resolved width (the shell's
        #: ``reader_width``), handed over by ``apply_work_width``; 0 until
        #: the shell has resolved one. ``pane_width`` above is the ITEMS
        #: width contract and must not be confused with it -- the location
        #: row's use of the list width is TASK-32811.4's open defect.
        self._work_width = 0
        self._tree_action_labels: tuple[str, ...] = ()
        self._rendered_tree_action_rows: tuple[tuple[int, ...], ...] = ()
        #: task-32356: create mode's template disclosure. Canvas-local on
        #: purpose -- nothing outside this widget reads or writes it, so it
        #: needs no ``LibraryNotesState`` field and no kwargs plumbing. It
        #: resets whenever the canvas leaves create mode (``sync_state``),
        #: so arriving at Create always shows the one folded row.
        self.templates_open = False
        self._tree_pager_focus_id: str | None = None
        self._tree_pager_focus_guard: Callable[[], bool] | None = None
        self._tree_pager_focus_generation = 0
        #: Which backlink rows the mounted Info panel currently holds, so a
        #: sync only remounts them when the set actually changed (task-32145).
        self._rendered_backlinks: tuple[tuple[str, str], ...] = ()
        #: Last word count the controller fed the chrome strip (task-32143).
        #: Caret moves and resizes repaint from this instead of re-scanning
        #: a body the controller already counted.
        self._note_chrome_word_count = 0
        #: task-32640: the last (path, written) the controller resolved for
        #: the open note, so a resize can re-state the location row without
        #: another binding read.
        self._note_location: tuple[str, str, bool] = ("", "", False)
        self._tree_focus_intent_generation: Callable[[], int] | None = None
        self.add_class("w-fill")
        self.styles.min_width = 40
        self.add_class(f"library-notes-mode-{mode}")

    def _after_recompose(self) -> None:
        """Re-run the post-compose wiring ``on_mount`` does.

        ``on_mount`` fires once, when the canvas itself mounts -- a
        ``refresh(recompose=True)`` remounts this widget's CHILDREN without
        re-firing it, so ``sync_state``'s recompose would otherwise leave the
        editor's stable subtree (populated by ``apply_session_state``) and the
        compact label rewrites showing compose-time defaults.

        Implemented as ``PostRecomposeCallback``'s hook rather than a
        ``recompose()`` override so it runs BEFORE any queued follow-up
        (task-15457 review round 1, minor 5): with the override form, a
        ``then=`` that focused a control saw its pre-compact label.
        """
        self._children_ready = True
        self._apply_post_compose_state()
        focus_id = self._tree_pager_focus_id
        guard = self._tree_pager_focus_guard
        generation = self._tree_pager_focus_generation
        self._tree_pager_focus_id = None
        self._tree_pager_focus_guard = None
        if not focus_id or not self._tree_pager_authority_is_current(guard, generation):
            return
        matches = self.query(f"#{focus_id}")
        if not matches:
            return
        pager = matches.first(_LibraryNotesTreePagerButton)
        if pager.disabled:
            self.call_after_refresh(
                self._retain_tree_pager_focus,
                pager,
                guard,
                generation,
            )
        elif self._tree_pager_authority_is_current(guard, generation):
            pager.focus()

    def _tree_pager_authority_is_current(
        self,
        guard: Callable[[], bool] | None,
        generation: int,
    ) -> bool:
        """Return whether one sync still owns semantic pager focus."""
        return generation == self._tree_pager_focus_generation and (
            guard is None or guard()
        )

    def _retain_tree_pager_focus(
        self,
        pager: _LibraryNotesTreePagerButton,
        guard: Callable[[], bool] | None,
        generation: int,
    ) -> None:
        """Retain disabled pager focus only for the originating sync."""
        if not self._tree_pager_authority_is_current(guard, generation):
            return
        if not pager.is_attached:
            return
        pager.retain_semantic_focus()

    async def recompose(self) -> None:
        """Preserve a newer in-canvas focus when pager authority expires."""
        newest_focus_id: str | None = None
        focus_generation = self._tree_pager_focus_generation
        focus_intent_generation: int | None = None
        focus_intent_generation_getter = self._tree_focus_intent_generation
        pager_focus_id = self._tree_pager_focus_id
        if pager_focus_id and not self._tree_pager_authority_is_current(
            self._tree_pager_focus_guard,
            self._tree_pager_focus_generation,
        ):
            focused = self.app.focused
            if (
                focused is not None
                and focused.id
                and focused.id != pager_focus_id
                and self in focused.ancestors_with_self
            ):
                newest_focus_id = focused.id
                if focus_intent_generation_getter is not None:
                    focus_intent_generation = focus_intent_generation_getter()
        if self.is_attached and not self._pruning:
            self._children_ready = False
        await super().recompose()
        if (
            not newest_focus_id
            or not self.is_attached
            or focus_generation != self._tree_pager_focus_generation
            or (
                focus_intent_generation is not None
                and focus_intent_generation_getter is not None
                and focus_intent_generation_getter() != focus_intent_generation
            )
        ):
            return
        matches = self.query(f"#{newest_focus_id}")
        if matches:
            matches.first().screen.set_focus(matches.first())

    def compose(self) -> ComposeResult:
        yield Static(
            self._authority_copy(),
            id=self.authority_id,
            markup=False,
        )
        if self.mode == "loading":
            yield from self._compose_loading()
            return
        if self.mode == "editor":
            yield from self._compose_editor()
            return
        if self.mode == "create":
            yield from self._compose_create()
            return
        if self.mode == "trash":
            yield from self._compose_trash()
            return
        if self.mode == "import":
            if self.import_snapshot is not None:
                yield LibraryNoteImportCanvas(
                    self.import_snapshot,
                    compact=self.compact,
                    id="library-note-import-canvas",
                )
            yield Button(
                back_cue_label("Notes"),
                id="library-notes-import-back",
                classes="library-canvas-action",
                compact=True,
            )
            return
        if self.mode == "lasting_add":
            if self.lasting_sync_snapshot is not None:
                yield LibraryNotesAddFromFilesCanvas(
                    self.lasting_sync_snapshot,
                    id="library-notes-lasting-add-canvas",
                )
            return
        if self.mode == "lasting_roots":
            if self.lasting_sync_snapshot is not None:
                yield LibraryNotesSyncRootsCanvas(
                    self.lasting_sync_snapshot,
                    id="library-notes-lasting-roots-canvas",
                )
            return
        yield from self._compose_list()

    def _authority_prefix(self) -> str:
        """Return the authority this canvas names before its own status.

        Subclasses that render beside a pane already naming the authority
        return ``""`` -- see ``LibraryNoteWorkPane`` (task-32063).

        task-32360 AC#2 (critique #10): the compact sheet caps this line at
        two rows, and at 60 columns the pane is 32 cells wide, where the
        full line takes three -- so "files." was simply cut off the bottom,
        with no ellipsis and no way to know something was missing. The
        narrow stage drops the prefix instead: the source strip directly
        above already says "Library notes | Folder files", so the authority
        is named on screen either way, and what is left ("Ready · Next:
        Create a note or add from files.") fits the two rows whole.

        Review F1: gated on ``compact`` alone this dropped the noun on
        EVERY terminal under 120 columns (``LIBRARY_NOTES_COMPACT_BREAKPOINT``)
        -- including the standard 100-column stage, where the line has room
        and nothing clips, and where the guide's own "narrower than 64
        columns" then described something the app did not do. The threshold
        is the one the guide states, measured off the terminal the stage is
        resolved from rather than off this pane (at 100 columns the Items
        pane is only 42 cells, so a pane-width test would drop it there
        too). A widget with no live app keeps the prefix: that is the
        answer that loses nothing.
        """
        try:
            narrow_stage = self.compact and self.app.size.width < _AUTHORITY_PREFIX_MIN_WIDTH
        except Exception:
            narrow_stage = False
        return "" if narrow_stage else NOTES_AUTHORITY_PREFIX

    def _authority_copy(self) -> str:
        """Describe Library storage, current status, and the next action."""
        prefix = self._authority_prefix()
        def line(*parts: str) -> str:
            """Join the non-empty clauses this state actually has."""
            return " · ".join(part for part in (prefix, *parts) if part)

        if self.mode == "loading":
            if self.load_state == "failed":
                status = self.load_message or "Could not load note."
                return line(status, "Next: Retry loading.")
            # task-32063: a "Next:" clause names a control the reader can
            # press. "Wait for loading to finish" names none, so this state
            # ends at its status.
            return line("Loading note…")
        if self.mode == "editor":
            state = self.presentation_state
            if state is None:
                return line("Editor unavailable", "Next: Back to notes.")
            status = state.status_line or "Ready"
            transfer = (
                f" · {state.transfer_status}"
                if state.transfer_status and state.transfer_status != status
                else ""
            )
            if state.conflict:
                next_action = "Resolve the conflict or reload the note."
            elif state.snapshot.saving or state.transfer_running:
                next_action = ""
            elif "Next:" in state.transfer_status:
                # task-32536 AC#2: a hand-off failure names its own remedy;
                # a second "Next:" here would offer "Review the error" for
                # an error that is not on screen.
                next_action = ""
            elif "failed" in f"{status} {state.transfer_status}".lower():
                next_action = "Review the error, then keep editing."
            elif state.presentation == "preview":
                # task-32249: Preview is read-only, so "changes save
                # automatically" named a behaviour this surface does not
                # have. Name the control that gets the reader back to the
                # one that does.
                next_action = "Press Edit to change this note."
            elif state.validation:
                # TASK-34000.10 (N-07): a veto stands, or a field is still
                # marked -- and a marked field means the next save is refused
                # by the same rule until that field changes (fix round 1,
                # M-5) -- so neither promise below is true; name the way out:
                # the marked field, or Save, which routes to it. Above the
                # empty-body arm: a vetoed title on an empty note needs this,
                # not "Start typing".
                next_action = "Fix the marked field, or press Save to go to it."
            elif not state.snapshot.body:
                # Review F4: "Keep editing" presumes editing has started.
                # The brief's "Start typing" belongs here -- this is the
                # surface with the empty box on it.
                next_action = "Start typing."
            elif state.autosave_scheduled or not state.snapshot.dirty:
                # TASK-34000.9 (N-06): true while a save is armed or running,
                # and for a clean note (the next keystroke arms it).
                next_action = "Keep editing; changes save automatically."
            else:
                # Dirty with nothing scheduled -- a modal stopped the timer,
                # or an autosave was refused -- names the control that saves.
                next_action = "Keep editing; press Save to save now."
            # TASK-34000.2: a held sync folder outranks any healthy wording. A
            # plain "Saved" over "In a synced folder" told a user typing into a
            # wedged folder that the file had it; it has the Notes copy only.
            attention = (
                NOTE_LOCATION_ATTENTION
                if state.location_attention
                and state.location_path
                and not state.conflict
                else ""
            )
            if attention:
                status = f"{status} in Notes" if status.startswith("Saved") else status
                if next_action:
                    next_action = SYNC_ATTENTION_NEXT_ACTION
            return line(
                f"{status}{transfer}",
                attention,
                f"Next: {next_action}" if next_action else "",
            )
        if self.mode == "create":
            status = self.create_status or (
                "Creating note…" if self.create_running else "Ready"
            )
            next_action = (
                ""
                if self.create_running
                # task-32356: Blank note is the answer nearly every time,
                # so the line names it as the default rather than posing
                # the nine-way question the canvas no longer asks.
                # Review F4: it names the two controls that are ON this
                # canvas -- the brief's "Start typing" was written for the
                # editor the key now goes to, and there is no box to type
                # in here.
                else "Press Blank note, or choose a template."
            )
            return line(status, f"Next: {next_action}" if next_action else "")
        if self.mode == "import":
            state = self.import_snapshot
            status = "Import unavailable" if state is None else state.status_line
            return line("Import once", status, "Next: Review the import workflow.")
        if self.mode in {"lasting_add", "lasting_roots"}:
            state = self.lasting_sync_snapshot
            status = "Unavailable" if state is None else state.status_line
            if state is not None and state.phase == "choose":
                # task-32125: naming one of the two relationships before the
                # reader has picked either presumed the answer.
                return line(
                    "Add from files",
                    status,
                    "Next: Choose Import once or Keep a folder synced.",
                )
            next_action = (
                "Use Import once."
                if state is None or not state.lasting_available
                else "Review the current lasting-sync step."
            )
            return line("Lasting sync", status, f"Next: {next_action}")
        state = self.list_state
        status = state.operation_status if state is not None else ""
        running = state is not None and state.operation_running
        # TASK-34000.2: "Ready" over a held sync folder was the finding's own
        # lie; the held folder outranks the idle wording (never an operation's).
        held = not status and not running and state is not None and state.sync_attention
        status = status or (
            "Updating notes…"
            if running
            else SYNC_ATTENTION_LIST_STATUS
            if held
            else "Ready"
        )
        # task-32616 AC#3: measured at dev 3b26c66ce0, both panes carried a
        # "Next:" at once and they disagreed -- this pane's "Create a note or
        # add from files." beside the work pane's "Start typing." for the
        # note already open (A cap 04). "Create a note" is advice for a
        # reader with nothing open; with a note open beside it, it is advice
        # against what they are doing. The work pane owns the instruction
        # while it has something to instruct about.
        #
        # NOT the staleness the finding also alleged: cap 05 was re-derived
        # live and the work pane's line is not stale -- after a TITLE-only
        # edit the body really is empty, so "Start typing." is the true next
        # step, and it becomes "Keep editing" as soon as the body has words.
        note_open = state is not None and state.note_open
        next_action = (
            ""
            if running or note_open
            else SYNC_ATTENTION_NEXT_ACTION
            if held
            else "Create a note or add from files."
        )
        return line(status, f"Next: {next_action}" if next_action else "")

    def _effective_pane_width(self) -> int:
        """The width the toolbar shapes itself to.

        ``pane_width`` is the screen's contract -- the Items pane width the
        reader layout resolved -- and wins whenever it has arrived. It is
        ``0`` on a canvas composed before its shell exists, and task-32360
        AC#2 measured a narrow route where no later sync ever carried the
        real one, leaving the width-aware toolbar (task-32127) permanently
        on its "not measured yet" shape. This widget's OWN rendered width
        is the honest fallback for exactly that case.

        Deliberately NOT the measured width first (task-32557, tried and
        reverted): a resize delivers this canvas a run of MID-LAYOUT widths
        -- 110, 106, 46, 48, 68, 40, 1, 72 were logged for one 60 -> 170 ->
        60 round trip -- and every one of them is a real number this method
        would have to answer with. Deciding the toolbar's shape from them
        recomposed the canvas on transients, which cost the in-place
        breakpoint path its widget identity
        (``test_library_note_compact_labels_round_trip_without_recompose``).
        The contract's staleness is cured at its source instead, by
        ``apply_pane_width`` below.
        """
        return self.pane_width or self._measured_width

    def _toolbar_decisions(self, width: int) -> tuple[bool, bool, bool]:
        """The three width-driven shape answers for one pane width."""
        merged, stacked = _toolbar_shape(width, self.compact)
        overflow = browse_row_overflows(
            width, self._browse_row_needed, already_split=self._browse_overflow
        )
        return merged, stacked, overflow

    def _tree_toolbar_width(self, pane_width: int) -> int:
        """Remove the stable Items host chrome from its outer-width contract."""
        if pane_width <= 0:
            return pane_width
        host = self.parent
        gutter = self.styles.gutter.width
        # The fallback measurement already excludes the Items host chrome.
        if self.pane_width and host is not None and host.id == "library-canvas":
            gutter += host.styles.gutter.width
        return max(1, pane_width - gutter)

    def _tree_actions_need_repack(self) -> bool:
        """Whether a composed row no longer fits the settled width contract.

        Compare the actual composition, including the initial unmeasured row.
        Extra rows after growth are harmless and must not force recomposition.
        """
        width = self._tree_toolbar_width(self._effective_pane_width())
        return any(
            len(
                toolbar_action_rows(
                    tuple(self._tree_action_labels[index] for index in row), width
                )
            )
            > 1
            for row in self._rendered_tree_action_rows
        )

    def on_resize(self, event: Resize) -> None:
        """Re-decide the toolbar's shape once this pane has a real width.

        Recomposing only when an answer actually flips keeps this from
        looping: the decisions are a pure function of the width. It never
        writes ``pane_width`` -- that attribute is the screen's contract and
        is asserted against the resolved layout (``test_list_toolbar_uses_
        the_width_the_pane_has_after_a_round_trip``); the canvas is a few
        cells narrower than the pane that holds it at wide sizes.

        Args:
            event: Textual's resize event, carrying this canvas's own size.
        """
        if self.mode != "list":
            self._keep_delete_prompt_in_view()
            self._measure_work_width(event.size.width)
            return
        width = event.size.width
        if width <= 0 or width == self._measured_width:
            return
        before = self._toolbar_decisions(self._effective_pane_width())
        self._measured_width = width
        if (
            before != self._toolbar_decisions(self._effective_pane_width())
            or self._tree_actions_need_repack()
        ):
            self.refresh(recompose=True)

    def _keep_delete_prompt_in_view(self) -> None:
        """Keep an open delete prompt inside Info's viewport across a resize.

        TASK-34000.13: the prompt is revealed once, when Delete is pressed
        (the controller scrolls Info to it after the refresh). A terminal
        resize while it is open re-lays Info out, and Textual does not
        re-scroll a focused widget on resize: measured at 160x45 -> 120x36
        the prompt dropped below Info's fold (``max_scroll_y`` 3,
        ``scroll_y`` 0) with Tab still trapped inside it -- the blind-Enter
        shape again. The widget owns its content (ADR-086), so it keeps the
        block in view itself; focus is left alone (the user may be on
        Delete). Scheduled after the refresh so the new geometry is real;
        never a timer.
        """
        try:
            prompt = self.query_one("#library-note-delete-confirmation")
        except NoMatches:
            return
        if not prompt.display:
            return
        self.call_after_refresh(
            prompt.scroll_visible, animate=False, immediate=True, force=True
        )

    def apply_pane_width(self, pane_width: int) -> None:
        """Take a freshly resolved Items width; re-shape only if it shrank.

        task-32557: ``pane_width`` used to arrive only with a state sync, so
        after a resize the toolbar kept deciding its shape from the width it
        had at its last compose. Live, a 235-column list merged its two
        action groups (pane 138), the terminal was narrowed to 60, and the
        merged row stayed -- painting "Add from files…" as "Add from"
        against the grip of a 50-column pane. The screen now hands the
        resolved width straight over.

        Only a SHRINK re-shapes, and that asymmetry is the point: a shape
        too wide for its pane paints half words, which is a correctness
        defect and has to be answered this frame; a shape too narrow for its
        pane only leaves space, and can wait for the compose that is coming
        anyway (compose always reads the current width). Re-shaping on
        growth too would recompose on every breakpoint crossing and cost the
        in-place responsive path its widget identity -- pinned by
        ``test_library_note_compact_labels_round_trip_without_recompose``.

        A GROWN width is still RECORDED, without refreshing (review M1).
        ``_effective_pane_width`` gives this attribute priority over the
        measured width, so dropping a grown width on the floor left
        235 -> 60 -> 235 composing the 50-cell shape into a 138-cell pane
        until an unrelated state sync re-stamped it -- a state dev never
        reaches, because dev's ``pane_width`` never moves off its compose
        value. Recording it means the next compose reads the true width.

        Args:
            pane_width: The Items width the reader layout just resolved.
        """
        if pane_width <= 0:
            return
        if self.pane_width and pane_width >= self.pane_width:
            self.pane_width = pane_width
            return
        before = self._toolbar_decisions(self._effective_pane_width())
        self.pane_width = pane_width
        if self.mode == "list" and (
            before != self._toolbar_decisions(self._effective_pane_width())
            or self._tree_actions_need_repack()
        ):
            self.refresh(recompose=True)

    def _effective_work_width(self) -> int:
        """The width the editor header shapes itself to.

        ``_work_width`` is the screen's contract -- the shell's resolved
        ``reader_width`` -- and wins whenever it has arrived; this widget's
        own measured width is the fallback for a canvas no sync has reached
        yet (the same priority ``_effective_pane_width`` gives the Items
        contract, for the reason given there).
        """
        return self._work_width or self._measured_width

    def _measure_work_width(self, width: int) -> None:
        """Record this pane's own width in editor mode; re-shape in place on a flip."""
        if width <= 0 or width == self._measured_width:
            return
        before = _header_shape(self._effective_work_width(), self.compact)
        self._measured_width = width
        if before != _header_shape(self._effective_work_width(), self.compact):
            self.apply_compact_presentation(self.compact)

    def apply_work_width(self, work_width: int) -> None:
        """Take the editor pane's freshly resolved width; re-shape the header.

        TASK-34000.8: the screen hands the shell's ``reader_width`` over
        beside ``apply_pane_width`` (the Items width), so the header's shape
        follows the pane it lives in rather than the shell's breakpoint. The
        shape is applied IN PLACE by ``apply_compact_presentation`` -- the
        same machinery the compact crossing uses, so growth and shrink both
        re-shape without a recompose and widget identity survives
        (``test_library_note_compact_labels_round_trip_without_recompose``).
        Nothing happens unless the answer flips, which keeps a run of
        mid-layout widths from doing any work.

        Args:
            work_width: The work (Reader) width the reader layout just
                resolved; 0 means unmeasured and is ignored.
        """
        if work_width <= 0:
            return
        before = _header_shape(self._effective_work_width(), self.compact)
        self._work_width = work_width
        if self.is_mounted and before != _header_shape(
            self._effective_work_width(), self.compact
        ):
            self.apply_compact_presentation(self.compact)

    def on_button_pressed(self, event: Button.Pressed) -> None:
        """Refuse row/action presses while this canvas is resident but hidden.

        Phase C keeps both browse canvases mounted and toggles ``display``
        (``UI/Library_Modules/library_browse_route_swap.py``). Textual 8.2.8's
        ``Button.press()`` consults the BUTTON's own ``disabled``/``display``
        and nothing above it, so a press aimed at a hidden canvas's row still
        bubbles to the screen and would act on a route the user has left --
        the design record's verified finding #3. Stop it here, at the canvas
        that owns the residency state, rather than in each of the screen's
        row handlers.

        **Scope, stated because it is narrower than it looks.** This gates
        ``Button.Pressed`` and nothing else. Still ungated, deliberately:
        ``Input.Changed`` / ``Input.Submitted`` (a hidden widget is not in the
        focus chain, so a user cannot type into one, and no code drives these
        programmatically off-route). Unlike ``LibraryMediaCanvas``, this
        canvas has no row-geometry message of its own -- there is no Notes
        analogue of ``LibraryMediaRowGeometryChanged`` to gate or fence
        (verified: that message is defined and posted only in
        ``library_media_canvas.py``). If a future change makes a hidden
        canvas focusable, drives its Inputs from code, or adds a Notes
        geometry message, this gate does NOT cover it.

        Args:
            event: The bubbling press.

        Returns:
            None.
        """
        if not self.display:
            event.stop()
            event.prevent_default()
            return
        # task-32356: the create canvas's template disclosure. Handled here
        # rather than on the screen because nothing outside this widget reads
        # the open/closed state -- same reason it is not a canvas kwarg.
        if event.button.id == "library-note-from-template":
            event.stop()
            self.templates_open = True
            # Without this the recompose drops focus out of the canvas
            # entirely (measured: onto the Items pane grip), so a keyboard
            # user who opened the templates could not then walk into them.
            self.preserve_same_id_focus_after_recompose()
            self.refresh(recompose=True)

    def sync_state(
        self,
        *,
        list_state: LibraryNotesListState | None,
        sort_mode: str,
        filter_value: str,
        mode: str,
        presentation_state: LibraryNotePresentationState | None,
        import_snapshot: LibraryNoteImportSnapshot | None = None,
        import_receipt_available: bool = False,
        lasting_sync_snapshot: LibraryNotesLastingSyncSnapshot | None = None,
        tree_projection: LibraryNotesTreeProjection | None,
        tree_selected_placement_id: str,
        tree_deleted_folder_available: bool,
        trash: LibraryNotesTrashState | None = None,
        title_placeholder_only: bool,
        compact: bool,
        pane_width: int = 0,
        create_running: bool,
        create_status: str,
        load_state: str,
        load_message: str,
        deferred_guard: Callable[[], bool] | None = None,
        focus_intent_generation: Callable[[], int] | None = None,
    ) -> None:
        """Apply a complete screen-owned snapshot within this canvas only.

        The method replaces every compose input before updating the visible
        surface. A retained import child accepts same-route snapshots directly
        so active text input keeps identity; other routes rebuild this widget's
        children.

        Args:
            list_state: Notes list snapshot, or ``None`` outside list mode.
            sort_mode: Active Notes sort identifier.
            filter_value: Current Notes filter text.
            mode: Canvas surface to render.
            presentation_state: Note editor/create presentation snapshot.
            import_snapshot: Reviewed one-time import presentation snapshot.
            import_receipt_available: Whether the latest same-session receipt can reopen.
            tree_projection: Placement-aware folder rows for list mode.
            tree_selected_placement_id: Context row for folder actions.
            tree_deleted_folder_available: Whether Undo folder removal is available.
            title_placeholder_only: Whether the title is placeholder-only.
            compact: Whether compact editor controls are enabled.
            pane_width: Columns the mounted list pane has (see ``__init__``).
                Defaults to the same ``0`` the constructor uses for "not
                measured yet", so a caller outside the screen's reader
                layout gets the conservative toolbar shape rather than a
                ``TypeError`` (PR #2549 review, finding 6).
            create_running: Whether note creation is in progress.
            create_status: Current note-creation status copy.
            load_state: Current note-loading state identifier.
            load_message: Current note-loading status or error copy.
            deferred_guard: Authority predicate for pager focus restoration
                scheduled by this exact sync.
            focus_intent_generation: Current screen focus-intent generation,
                read before and after an awaited recompose.
        """
        previous_mode = self.mode
        focused = self.app.focused
        self._tree_pager_focus_generation += 1
        self._tree_focus_intent_generation = focus_intent_generation
        if (
            focused is not None
            and focused.id
            and focused.has_class("library-notes-tree-pager")
            and self in focused.ancestors_with_self
        ):
            self._tree_pager_focus_id = focused.id
            self._tree_pager_focus_guard = deferred_guard
        else:
            self._tree_pager_focus_id = None
            self._tree_pager_focus_guard = None
        self.list_state = list_state
        self.sort_mode = sort_mode
        self.filter_value = filter_value
        self.mode = mode
        self.presentation_state = presentation_state
        self.import_snapshot = import_snapshot
        self.import_receipt_available = import_receipt_available
        self.lasting_sync_snapshot = lasting_sync_snapshot
        self.tree_projection = tree_projection
        self.tree_selected_placement_id = tree_selected_placement_id
        self.tree_deleted_folder_available = tree_deleted_folder_available
        self.trash = trash
        self.title_placeholder_only = title_placeholder_only
        self.compact = compact
        self.pane_width = pane_width
        self.create_running = create_running
        self.create_status = create_status
        self.load_state = load_state
        self.load_message = load_message
        if mode != "create":
            # task-32356: arriving at Create always shows the one folded row.
            self.templates_open = False
        if previous_mode != mode:
            self.remove_class(f"library-notes-mode-{previous_mode}")
            self.add_class(f"library-notes-mode-{mode}")
        import_canvases = self.query("#library-note-import-canvas")
        if (
            previous_mode == mode == "import"
            and import_snapshot is not None
            and import_canvases
        ):
            try:
                self.query_one(f"#{self.authority_id}", Static).update(
                    self._authority_copy()
                )
            except NoMatches:
                pass
            child = import_canvases.first(LibraryNoteImportCanvas)
            child.compact = compact
            callback = self._post_recompose_callback
            self._post_recompose_callback = None
            child.queue_after_recompose(callback)
            child.sync_state(import_snapshot)
            if not getattr(child, "_recompose_required", False):
                child.queue_after_recompose(None)
                if callback is not None:
                    self.call_after_refresh(callback)
            return
        lasting_canvases = self.query("#library-notes-lasting-add-canvas")
        if (
            previous_mode == mode == "lasting_add"
            and lasting_sync_snapshot is not None
            and lasting_canvases
        ):
            try:
                self.query_one(f"#{self.authority_id}", Static).update(
                    self._authority_copy()
                )
            except NoMatches:
                pass
            lasting_canvases.first(LibraryNotesAddFromFilesCanvas).sync_state(
                lasting_sync_snapshot
            )
            return
        if previous_mode == mode and self.editor_has_focus():
            # task-32062: a Notes refresh (a save landing, the first note
            # reaching the list, an evidence-driven reload) recomposed the
            # surface the reader was typing into: the title Input and body
            # TextArea were rebuilt and focus fell onto the list grip, so the
            # next keystrokes went somewhere else. Reported as a title that
            # swallowed the body. Every compose input above is already stored,
            # so the next refresh from outside the field paints this state --
            # only the rebuild is skipped, and only while the surface is
            # STAYING put: a mode change is a navigation the reader asked for
            # and must paint immediately.
            #
            # Known ceiling: a banner this recompose would have painted (the
            # "changed elsewhere" conflict, say) waits for the next refresh
            # that arrives with the reader's hands off the field. Interrupting
            # a sentence to show it costs them their keystrokes, which is the
            # worse half of the trade.
            #
            # The caller must not queue a post-recompose follow-up for a
            # rebuild that is not happening -- see the `notes_editor_owned`
            # guard in ``canvas_sync._sync_library_canvas``, without which the
            # Notes focus restore sat here and fired at the NEXT recompose,
            # dragging focus back out of whatever field the reader moved to.
            return
        self.refresh(recompose=True)

    def editor_has_focus(self) -> bool:
        """Whether a field of THIS canvas's note editor currently has focus.

        Returns:
            ``True`` while the focused widget is one of this canvas's own
            editable note fields (title, body, or either keyword box).
        """
        try:
            focused = self.app.focused
        except Exception:
            return False
        if focused is None or focused.id not in _NOTE_EDITOR_INPUT_IDS:
            return False
        try:
            return self in focused.ancestors_with_self
        except Exception:
            return False

    def _compose_loading(self) -> ComposeResult:
        """Render the existing note-loading/retry surface inside the canvas."""
        with Vertical(id="library-note-load-state"):
            with Horizontal(id="library-note-load-heading"):
                # task-32177: this view's Back was left out of task-32139's
                # unification and stayed hard-coded "‹ Notes" at every width.
                yield Button(
                    _library_note_back_label(self.compact),
                    id="library-note-back",
                    classes="library-canvas-action",
                    compact=True,
                )
                yield Static(
                    "Edit note",
                    id="library-note-loading-title",
                    markup=False,
                )
            load_copy = (
                self.load_message if self.load_state == "failed" else "Loading note…"
            )
            yield Static(
                load_copy,
                id="library-note-loading",
                classes="destination-purpose",
                markup=False,
            )
            with Vertical(id="library-note-loading-viewport"):
                if self.load_state == "failed":
                    yield Button(
                        "Retry",
                        id="library-note-load-retry",
                        classes="library-canvas-action",
                        compact=True,
                    )

    def _compose_list(self) -> ComposeResult:
        self._tree_action_labels = ()
        self._rendered_tree_action_rows = ()
        list_state = self.list_state
        if list_state is None:
            return
        yield Static(
            list_state.header_copy,
            id="library-notes-header",
            classes="destination-section",
            markup=False,
        )
        # Database mode persists notes in the Library; Folder files edits a
        # folder directly, while Add from files owns import/sync setup.
        database_purpose = Static(
            "These notes live in the Library's own database — for notes "
            "that live in a folder on disk, switch to Folder files. To copy "
            "or keep a folder synced, choose Add from files.",
            id="library-notes-database-purpose",
            markup=False,
        )
        database_purpose.display = not self.compact
        yield database_purpose
        with Horizontal(id="library-notes-filter-row"):
            yield Static("Filter", id="library-notes-filter-label", markup=False)
            # task-32131: a plain ``Input`` here let a SECOND "/" -- pressed
            # while the filter already had focus -- insert a literal slash
            # (Screen.on_key's "/" handling bails as soon as an Input owns
            # focus, so it never gets a chance to redirect). Reuse the rail
            # search box's widget instead of re-solving it -- but with
            # ``swallow_slash_on_focus=False`` (fix round 1 Important 4,
            # controller ruling): notes filter content can legitimately
            # contain "/" (folder-style filters like "Work/Q3"), so once
            # this box has focus "/" must be a plain typeable character,
            # not an accelerator that swallows it. The screen-level "/"
            # handler already only fires while this box is NOT focused.
            yield LibraryRailSearchInput(
                placeholder="Filter notes… (Enter)",
                id="library-notes-filter",
                value=self.filter_value,
                swallow_slash_on_focus=False,
            )
        select_mode = list_state.select_mode
        # Gate/label off the RENDERED rows, not any total-count field -- only
        # rendered rows are selectable, matching the media/conversations
        # canvases' ``len(rows)`` convention.
        rendered_note_ids = (
            {
                row.note_id
                for row in self.tree_projection.rows
                if row.kind == "note" and row.note_id
            }
            if self.tree_projection is not None
            else {row.note_id for row in list_state.rows}
        )
        rendered_count = len(rendered_note_ids)
        if select_mode:
            action_row = Horizontal(
                id="library-notes-selection-actions", classes="ds-toolbar"
            )
            action_row.add_class("h-auto")
            with action_row:
                # task-2853 review round 2: the SAME unbounded-width defect
                # proved live in the Media canvas's identical counter (see
                # library_media_canvas.py's compose()) also affects this
                # canvas's counter -- fixed generally via the shared
                # ``library-toolbar-count`` class (css/components/
                # _agentic_terminal.tcss's ``width: auto``) rather than a
                # per-canvas one-off.
                in_row_count = Static(
                    f"{list_state.selected_count} selected",
                    id="library-notes-selected-count",
                    classes="library-toolbar-count library-notes-selection-count",
                    markup=False,
                )
                # task-32261 AC#1: this counter costs 11 of the 42 columns a
                # 100x30 terminal gives the list pane, which is what pushed
                # "Export selected" off the right edge -- the strip painted
                # "0 selected  Done  All 10  Clear" and the guide's fifth
                # action was unreachable.
                #
                # Hiding it is only safe because task-32272 made the count a
                # CLASS the patcher writes to (``library-notes-selection-
                # count``, above): ``_apply_library_row_toggle`` now updates
                # every renderer wearing it, hidden ones included, so the
                # line below this strip tracks the selection instead of
                # keeping the compose-time number. The first round of this
                # branch hid the only patched widget and shipped a stale
                # "0 selected" over a checked row -- pinned now by
                # ``test_the_compact_select_strip_counts_the_row_the_reader_
                # just_checked``.
                in_row_count.display = not self.compact
                yield in_row_count
                yield Button(
                    "Done",
                    id="library-notes-select-toggle",
                    classes="library-canvas-action",
                    compact=True,
                )
                yield Button(
                    (
                        f"All {rendered_count}"
                        if self.compact
                        else f"Select all {rendered_count} shown"
                    ),
                    id="library-notes-select-all",
                    classes="library-canvas-action",
                    compact=True,
                )
                yield Button(
                    "Clear",
                    id="library-notes-select-clear",
                    classes="library-canvas-action",
                    compact=True,
                )
                export_base = "Export" if self.compact else "Export selected"
                export_disabled = list_state.selected_count == 0
                export_selected = Button(
                    # task-4023 AC#1 (RC-07): "○" disabled marker; base
                    # label stashed for `_apply_library_row_toggle`'s
                    # in-place patch (compact and full spellings differ,
                    # so the patcher must not hard-code either).
                    # task-31959: the enabled spelling reserves the
                    # marker's own width, so the word holds its column
                    # when the first selection enables this in place.
                    library_disabled_action_label(
                        export_base, export_disabled, align=True
                    ),
                    id="library-notes-export-selected",
                    classes="library-canvas-action",
                    compact=True,
                )
                export_selected._library_disabled_marker_base = export_base
                export_selected._library_disabled_marker_align = True
                export_selected.disabled = export_disabled
                # F-018: a disabled action says why.
                export_selected.tooltip = (
                    LIBRARY_EXPORT_SELECTED_DISABLED_TOOLTIP
                    if export_selected.disabled
                    else LIBRARY_EXPORT_SELECTED_TOOLTIP
                )
                yield export_selected
            yield Static(
                # task-32549: "○ Export selected" said that exporting was
                # off and nothing about why -- the reason was on a tooltip,
                # which does not render in a TUI. Named on THIS line rather
                # than in the label or on a line of its own: the strip above
                # has no cells to spare (task-32261 had to hide its own
                # in-row counter to keep this very action on a 42-column
                # pane), and a new line costs the tree a row at 60x20, which
                # `test_library_note_60x20_navigator_state_allocation`
                # caught when this was tried that way.
                library_selection_count_line(
                    list_state.selected_count, export_base
                ),
                id="library-notes-selection-status",
                # task-32272: the class, not the id, is what the in-place
                # toggle patcher looks for -- a new count renderer opts in
                # by wearing it rather than by someone remembering that
                # `_apply_library_row_toggle` exists.
                classes="library-notes-selection-count",
                markup=False,
            )
        else:
            # task-4023 AC#1 (RC-07): every disabled toolbar action carries
            # the non-colour "○" marker plus an F-018 reason.
            running = list_state.operation_running
            running_tooltip = "Wait for the running notes operation to finish."
            # task-32128 removed Sort from the folder tree because the
            # tree's row order was a hard-coded repository contract.
            # task-32172 made that order a parameter of BOTH the pager and
            # the deep-link locator's rank, so the control is back and
            # really re-pages. The one thing it still cannot own is the
            # filter window: those rows come from the FTS search seam,
            # ranked by folder path, so Sort is blocked there with a reason
            # rather than silently reordering nothing.
            sort_blocked = notes_sort_is_blocked(
                tree_projection=self.tree_projection, filter_value=self.filter_value
            )
            sort_choices_visible = (
                not sort_blocked and list_state.sort_choices_visible
            )
            # task-32127: the browse and transfer actions share ONE row, so
            # the toolbar is two rows rather than three -- but only where the
            # pane can hold both groups. Below the threshold the merged row
            # clipped its last action off the pane, which is worse than the
            # third row it saves (review round 1).
            pane_width = self._effective_pane_width()
            merged, stacked = _toolbar_shape(pane_width, self.compact)
            action_rows: Horizontal | None = None
            if merged:
                action_rows = Horizontal(id="library-notes-action-rows")
                action_rows.add_class("h-auto")
            with action_rows or nullcontext():
                browse_actions = Horizontal(
                    id="library-notes-browse-actions", classes="ds-toolbar"
                )
                browse_actions.add_class("h-auto")
                if action_rows is not None:
                    browse_actions.add_class("w-auto")
                browse_actions.display = not sort_choices_visible
                new_label = library_disabled_action_label("New", running)
                sort_base = f"Sort: {_SORT_LABELS.get(self.sort_mode, 'Newest')}"
                sort_disabled = running or sort_blocked
                sort_label = library_disabled_action_label(sort_base, sort_disabled)
                select_disabled = rendered_count == 0 or running
                select_label = library_disabled_action_label(
                    "Select", select_disabled
                )
                # task-32360 AC#2: three actions need 33 cells and the
                # narrow pane has 32, so the last one used to be cropped
                # mid-word ("Sel"). It moves to a row of its own instead --
                # the same "one group per row" shape ``stacked`` already
                # uses for a narrow pane, which the compact sheet's
                # height-1 toolbar pin rules out for a single row.
                self._browse_row_needed = browse_row_width(
                    (new_label, sort_label, select_label)
                )
                browse_overflow = browse_row_overflows(
                    pane_width,
                    self._browse_row_needed,
                    already_split=self._browse_overflow,
                )
                self._browse_overflow = browse_overflow
                select_button = Button(
                    select_label,
                    id="library-notes-select-toggle",
                    classes="library-canvas-action",
                    compact=True,
                    disabled=select_disabled,
                    tooltip=(
                        (
                            running_tooltip
                            if running
                            else LIBRARY_SELECT_TOGGLE_DISABLED_TOOLTIP
                        )
                        if select_disabled
                        else None
                    ),
                )
                with browse_actions:
                    yield Button(
                        new_label,
                        id="library-notes-new",
                        classes="library-canvas-action",
                        compact=True,
                        disabled=running,
                        tooltip=running_tooltip if running else None,
                    )
                    yield Button(
                        sort_label,
                        id="library-notes-sort",
                        classes="library-canvas-action",
                        compact=True,
                        disabled=sort_disabled,
                        tooltip=(
                            running_tooltip
                            if running
                            else LIBRARY_NOTES_SORT_FILTERED_TOOLTIP
                            if sort_blocked
                            else None
                        ),
                    )
                    if not browse_overflow:
                        yield select_button
                if browse_overflow:
                    browse_overflow_row = Horizontal(
                        id="library-notes-browse-actions-overflow",
                        classes="ds-toolbar",
                    )
                    browse_overflow_row.add_class("h-auto")
                    browse_overflow_row.display = not sort_choices_visible
                    with browse_overflow_row:
                        yield select_button
                if sort_choices_visible:
                    # task-14902: composed through the ONE shared strip builder
                    # (this control is the pattern's precedent; the media type /
                    # prompts sort / skills sort / export quality strips share
                    # the same mechanism).
                    yield from compose_library_choice_strip(
                        strip_id="library-notes-sort-choices",
                        choice_class="library-notes-sort-choice",
                        options=tuple(
                            (f"library-notes-sort-{mode}", mode, label)
                            for mode, label in _SORT_LABELS.items()
                        ),
                        active_value=self.sort_mode,
                    )
                import_phase = (
                    self.import_snapshot.phase
                    if self.import_snapshot is not None
                    else ""
                )
                transfer_actions = (Vertical if stacked else Horizontal)(
                    id="library-notes-transfer-actions", classes="ds-toolbar"
                )
                transfer_actions.add_class("h-auto")
                with transfer_actions:
                    for label, button_id in (
                        ("Add from files…", "library-notes-add-from-files"),
                        ("Export", "library-notes-export"),
                    ):
                        view_import = (
                            button_id == "library-notes-add-from-files"
                            and import_phase == "importing"
                        )
                        disabled = list_state.operation_running and not view_import
                        yield Button(
                            library_disabled_action_label(
                                "View import" if view_import else label, disabled
                            ),
                            id=button_id,
                            classes="library-canvas-action",
                            compact=True,
                            disabled=disabled,
                            tooltip=running_tooltip if disabled else None,
                        )
                    if self.lasting_sync_snapshot is not None and (
                        self.lasting_sync_snapshot.roots
                        or self.lasting_sync_snapshot.root_page_count > 1
                    ):
                        yield Button(
                            "Manage sync folders",
                            id="library-notes-manage-sync-folders",
                            classes="library-canvas-action",
                            compact=True,
                            disabled=list_state.operation_running,
                        )
                    if self.import_receipt_available:
                        yield Button(
                            "Last import",
                            id="library-notes-import-receipt",
                            classes="library-canvas-action",
                            compact=True,
                            disabled=list_state.operation_running,
                        )
            if self.tree_projection is not None:
                yield from self._compose_tree_actions(
                    operation_running=list_state.operation_running
                )
        if not select_mode and notes_sort_is_blocked(
            tree_projection=self.tree_projection, filter_value=self.filter_value
        ):
            # Only while the Sort control is on screen: select mode replaces
            # the whole toolbar, and a reason for a control nobody can see is
            # the same dishonesty in the other direction (walked live at
            # 100x30, `layout-23-100x30-export-reason`).
            # task-32549: "○ Sort: Newest" said that sorting was off and
            # nothing about why -- the reason was on a tooltip, which does
            # not render in a TUI. On the shared `.library-disabled-reason`
            # line rather than in the label, and MEASURED that way: the
            # label spelling was walked live first and painted "○ Sort
            # unavailable — clear the" against the grip on the 42-column
            # pane a 100x30 terminal gives this list
            # (`wave4-caps/layout/layout-21-100x30-sort-reason`). Same line,
            # same sentence, as Export selected below and "○ Server notes"
            # in the sync canvas.
            yield Static(
                library_disabled_reason_line("Sort", "clear the filter"),
                id="library-notes-sort-disabled-reason",
                classes="library-disabled-reason",
                markup=False,
            )
        status_row = Horizontal(id="library-notes-status-row")
        status_row.add_class("h-auto")
        status_row.display = not select_mode
        with status_row:
            status = Static(
                list_state.status_copy,
                id="library-notes-status",
                markup=False,
            )
            status.display = not select_mode
            yield status
            if self.filter_value:
                yield Button(
                    "Clear filter",
                    id="library-notes-filter-clear",
                    classes="library-canvas-action",
                    compact=True,
                )
        receipt = list_state.delete_receipt
        if receipt is not None:
            title = ellipsize_note_title_cells(
                receipt.title or "Untitled", 18 if self.compact else 42
            )
            # task-32123: the copy and the two recovery actions are stacked,
            # not laid side by side. A one-row receipt needed the title's 42
            # cells PLUS both buttons, so in a narrow list pane Undo -- the
            # only recovery path there is, with no Trash browser -- was
            # painted past the pane edge and could not be pressed.
            receipt_row = Vertical(
                id="library-notes-delete-receipt", classes="ds-toolbar"
            )
            receipt_row.add_class("h-auto")
            with receipt_row:
                yield Static(
                    f"✓ deleted · {title}",
                    id="library-notes-delete-receipt-copy",
                    classes="library-toolbar-count",
                    markup=False,
                )
                receipt_actions = Horizontal(
                    id="library-notes-delete-receipt-actions"
                )
                receipt_actions.add_class("h-auto")
                with receipt_actions:
                    yield Button(
                        "Undo",
                        id="library-notes-delete-undo",
                        classes="library-canvas-action",
                        compact=True,
                        disabled=list_state.operation_running,
                    )
                    yield Button(
                        "Dismiss",
                        id="library-notes-delete-receipt-dismiss",
                        classes="library-canvas-action",
                        compact=True,
                        disabled=list_state.operation_running,
                    )
        if self.tree_projection is not None:
            # The opener is the row list's last row -- see
            # ``_compose_trash_opener``.
            yield from self._compose_tree_rows(list_state)
            return
        if not list_state.rows:
            yield Static(list_state.empty_copy, id="library-notes-empty", markup=False)
            yield from self._compose_trash_opener()
            return
        with Vertical(id="library-notes-list"):
            for index, row in enumerate(list_state.rows):
                # Button labels are parsed as Rich markup: escape the
                # user-supplied title so "[draft] Q3 plan [wip]" renders
                # verbatim instead of eating bracketed segments as tags
                # (or crashing on an unmatched closing tag) -- the same
                # fix class as the escaped search-history Button labels.
                title = escape_markup(row.title)
                label_rest = compose_note_row_label(title, age_label=row.age_label)
                if select_mode:
                    # Notes rows had no marker at all before select mode
                    # existed -- normal mode keeps that markerless label
                    # (no ``▸``, unlike the media/conversations rows).
                    glyph = "☑ " if row.checked else "☐ "
                    label = f"{glyph}{label_rest}"
                else:
                    label = label_rest
                # task-31945: shared row press behaviour (no 0.2s flash
                # swallowing the next click on the same row).
                button = library_row_button(
                    label,
                    id=f"library-notes-row-{index}",
                    classes="library-notes-row",
                    compact=True,
                    disabled=list_state.operation_running,
                )
                button.note_id = row.note_id
                # task-281 (PR #665 review): raw marker-less label for the
                # in-place toggle (reading it back off the Button un-escapes
                # user titles).
                button._library_row_label_rest = label_rest
                yield button
            yield from self._compose_trash_opener()

    def _compose_trash_opener(self) -> ComposeResult:
        """Name the Trash under the tree, and only while it holds something.

        task-32144: the delete receipt was the ONLY way back from a delete,
        so dismissing it stranded the note. This row is the standing second
        net; at zero it is absent rather than disabled -- an empty Trash has
        nothing to say and a dead affordance is worse than none.

        Composed as the row list's LAST ROW, not as a sibling after it: the
        list is ``height: 1fr``, so a sibling docked to the foot of the pane
        with a dozen blank rows between it and the tree (measured live at
        235x52) -- the same detached-affordance shape task-28015 fixed in the
        Media Trash. Every path that has no row list yields it directly.
        """
        trash = self.trash
        if trash is None or trash.total <= 0:
            return
        yield Button(
            f"Recently deleted ({trash.total})",
            id="library-notes-trash-open",
            classes="library-canvas-action",
            compact=True,
        )

    def _compose_trash(self) -> ComposeResult:
        """Render the soft-deleted notes with one Restore each, and no more.

        Restore is the only mutation this view offers: it commits through
        the same ``_undo_library_note_delete`` seam the receipt's Undo uses,
        so the row returns to its folder (or Unfiled) and the rail count
        moves exactly as an Undo would. There is deliberately no permanent
        delete here -- ADR-055 keeps destruction behind its own receipt, and
        this surface exists to recover.
        """
        trash = self.trash or LibraryNotesTrashState()
        yield Static(
            "Recently deleted",
            id="library-notes-trash-header",
            classes="destination-section",
            markup=False,
        )
        yield Static(
            "Deleted notes stay here until you restore them. Restore puts a "
            "note back where it was; nothing is removed for good from here.",
            id="library-notes-trash-purpose",
            markup=False,
        )
        yield Button(
            _library_note_back_label(self.compact),
            id="library-notes-trash-back",
            classes="library-canvas-action",
            compact=True,
        )
        if not trash.rows:
            yield Static(
                "Nothing deleted recently. Deleted notes appear here — press "
                "Escape to go back to the list.",
                id="library-notes-trash-empty",
                markup=False,
            )
            return
        with Vertical(id="library-notes-trash-list"):
            for index, row in enumerate(trash.rows):
                trash_row = Horizontal(classes="library-notes-trash-row")
                trash_row.add_class("h-auto")
                with trash_row:
                    yield Static(
                        compose_note_row_label(row.title, age_label=row.age_label),
                        classes="library-notes-trash-row-copy",
                        markup=False,
                    )
                    button = Button(
                        "Restore",
                        id=f"library-notes-trash-restore-{index}",
                        classes=(
                            "library-canvas-action library-notes-trash-restore"
                        ),
                        compact=True,
                    )
                    button.note_id = row.note_id
                    button.note_title = row.title
                    button.note_version = row.version
                    yield button
        if trash.total > len(trash.rows):
            yield Static(
                f"Showing the {len(trash.rows)} most recently deleted of "
                f"{trash.total}. Restore one to see the rest.",
                id="library-notes-trash-more",
                markup=False,
            )

    def _compose_tree_rows(self, list_state: LibraryNotesListState) -> ComposeResult:
        """Render placement-aware rows while retaining legacy note handlers."""
        projection = self.tree_projection
        if projection is None:
            return
        if not projection.rows:
            yield Static(
                list_state.empty_copy,
                id="library-notes-empty",
                markup=False,
            )
            yield from self._compose_trash_opener()
            return
        # task-32126: a seeded folder (Agent_Lessons) gives the tree
        # projection rows even when the library holds zero notes, so the
        # "no rows" check above never fires and the empty state never
        # renders. Render it above the tree whenever the library itself is
        # empty, independent of whether the projection has folder rows.
        # PR #2538 review (Qodo finding 5): a fresh visit renders with
        # empty_kind == "source-empty" before the bulk source-count lookup
        # resolves, while the tree's own root "folders"/"placements" slices
        # are still loading (a loading pager row, not an empty projection).
        # Skip the banner while any row is still in flight so a user who
        # does have notes never sees "No notes yet" flash ahead of the
        # load result.
        if list_state.empty_kind == "source-empty" and not any(
            row.loading for row in projection.rows
        ):
            yield Static(
                list_state.empty_copy,
                id="library-notes-empty",
                markup=False,
            )
        checked_ids = {row.note_id for row in list_state.rows if row.checked}
        # task-32137: only a title that repeats under the SAME parent earns
        # a folder suffix -- two rows with one title in two folders already
        # sit under their own folder rows, and spending the width there
        # ellipsized the semantic sync status instead.
        sibling_counts = Counter(
            (row.folder_id or "", row.label)
            for row in projection.rows
            if row.kind == "note"
        )
        duplicate_siblings = {
            sibling for sibling, count in sibling_counts.items() if count > 1
        }
        # task-32254: folder+age still ties for two unfiled notes of the
        # same age -- the case it was needed for most -- so those rows earn
        # a third key.
        tiebreak_labels = note_row_tiebreak_labels(projection.rows)
        with Vertical(id="library-notes-list", classes="library-notes-tree"):
            for index, row in enumerate(projection.rows):
                indent = "  " * row.depth
                if row.kind == "pager":
                    button = _LibraryNotesTreePagerButton(
                        Text(f"{indent}{row.label}"),
                        id=row.focus_id,
                        classes="library-notes-tree-pager library-canvas-action",
                        compact=True,
                        disabled=row.disabled,
                    )
                    button.placement_id = row.placement_id
                    button.parent_folder_id = row.parent_folder_id
                    button.content_kind = row.content_kind
                    button.paging_action = row.paging_action
                    button.retry_direction = row.retry_direction
                    button.range_copy = row.range_copy
                    button.pager_status = row.status_text
                    button.action_copy = row.action_copy
                    button.paging_loading = row.loading
                    yield button
                    continue
                if row.kind in {"folder", "unfiled"}:
                    glyph = "▾" if row.expanded else "▸"
                    label = f"{indent}{glyph} {escape_markup(row.label)}"
                    # task-32126: gloss the seeded Agent_Lessons folder while
                    # the library holds zero notes -- a first-time user's
                    # first question is what this folder is and whether they
                    # made it themselves.
                    # ponytail: keyed off "the whole library is empty"
                    # rather than "this folder has no children" (no per-
                    # folder note count is loaded for a collapsed row) --
                    # exactly the scoped scenario this task covers; widen to
                    # a real per-folder empty check if Agent_Lessons ever
                    # needs the gloss while sibling notes exist elsewhere.
                    if (
                        row.label == AGENT_LESSONS_FOLDER
                        and list_state.empty_kind == "source-empty"
                    ):
                        label = f"{label} — {AGENT_LESSONS_FOLDER_GLOSS} (empty)"
                    if row.status_text:
                        label = f"{label}  {row.status_text}"
                    classes = "library-notes-folder-row"
                    if row.kind == "unfiled":
                        # TASK-34000.14: lets the screen's "g" gate tell the
                        # automatic group from a real folder row without a
                        # second query.
                        classes += " library-notes-unfiled-row"
                    if row.semantic_status == "connected":
                        classes += " library-notes-tree-connected"
                    elif row.semantic_status == "needs_attention":
                        classes += " library-notes-tree-needs-attention"
                    button = library_row_button(
                        label,
                        id=f"library-notes-tree-folder-{index}",
                        classes=classes,
                        compact=True,
                        tooltip=row.breadcrumb,
                    )
                    if row.placement_id == self.tree_selected_placement_id:
                        button.add_class("is-selected")
                    self._set_tree_row_metadata(button, row)
                    yield button
                    continue

                # A filter scatters rows out of their folders, and a
                # repeated title is otherwise an identical row: both name
                # their folder (task-32137).
                folder_label = (
                    row.breadcrumb.rsplit(" / ", 1)[0]
                    if row.breadcrumb
                    and (
                        self.filter_value
                        or (row.folder_id or "", row.label) in duplicate_siblings
                    )
                    else ""
                )
                title = indent + compose_note_row_label(
                    escape_markup(row.label),
                    folder_label=escape_markup(folder_label),
                    age_label=row.age_label,
                    tiebreak_label=tiebreak_labels.get(row.placement_id, ""),
                )
                if row.status_text:
                    title = f"{title}  {row.status_text}"
                if list_state.select_mode:
                    marker = "☑ " if row.note_id in checked_ids else "☐ "
                    label_rest = title
                    label = f"{marker}{label_rest}"
                else:
                    label_rest = title
                    label = label_rest
                classes = "library-notes-row library-notes-tree-note-row"
                if row.semantic_status == "connected":
                    classes += " library-notes-tree-connected"
                elif row.semantic_status == "needs_attention":
                    classes += " library-notes-tree-needs-attention"
                button = library_row_button(
                    label,
                    id=f"library-notes-tree-note-{index}",
                    classes=classes,
                    compact=True,
                    tooltip=row.breadcrumb,
                    disabled=list_state.operation_running,
                )
                if row.placement_id == self.tree_selected_placement_id:
                    button.add_class("is-selected")
                self._set_tree_row_metadata(button, row)
                button._library_row_label_rest = label_rest
                yield button
            yield from self._compose_trash_opener()

    def _compose_tree_actions(self, *, operation_running: bool) -> ComposeResult:
        """Render actions appropriate to the selected folder-tree placement."""
        buttons = self._tree_action_buttons(operation_running=operation_running)
        if not self.compact:
            # task-32617 AC#2: the rule, in the same `destination-section`
            # grammar Folder files uses for "File actions" / "Session Git" /
            # "Danger" one mode over. Costs one row, so the compact shell --
            # whose list rows are a measured budget (task-32123/32261) --
            # does without it.
            yield Static(
                NOTES_TREE_ACTION_GROUP_HEADING,
                id="library-notes-tree-actions-heading",
                classes="destination-section",
                markup=False,
            )
        self._tree_action_labels = tuple(str(button.label) for button in buttons)
        rows = toolbar_action_rows(
            self._tree_action_labels,
            self._tree_toolbar_width(self._effective_pane_width()),
        )
        self._rendered_tree_action_rows = rows
        for row_index, row in enumerate(rows):
            container = Horizontal(
                id=(
                    "library-notes-tree-actions"
                    if row_index == 0
                    else f"library-notes-tree-actions-{row_index + 1}"
                ),
                # The class is how a pin reaches EVERY packed row: Textual
                # has no attribute selectors, so a selector aimed at
                # `#library-notes-tree-actions` alone stopped seeing the
                # overflow row this packer introduced (review M4).
                classes="ds-toolbar library-notes-tree-action-row h-auto",
            )
            with container:
                for index in row:
                    yield buttons[index]
        if self._tree_note_actions_unselected():
            # The reason the three placement actions above render blocked,
            # on the shared line rather than a tooltip a TUI never paints --
            # the same sentence, in the same place, as Sort's
            # (task-32617 AC#1, task-32549's grammar).
            yield Static(
                library_disabled_reason_line(
                    "Note actions", NOTE_ACTIONS_UNSELECTED_REASON
                ),
                id="library-notes-tree-actions-disabled-reason",
                classes="library-disabled-reason",
                markup=False,
            )

    def _tree_note_actions_unselected(self) -> bool:
        """Return whether the blocked-note-actions reason belongs on screen.

        True only when the three placement actions were composed blocked --
        so never in the compact shell, which does not compose them at all
        (see ``_tree_action_buttons``).
        """
        if self.compact:
            return False
        projection = self.tree_projection
        selected = (
            projection.row(self.tree_selected_placement_id)
            if projection is not None and self.tree_selected_placement_id
            else None
        )
        return selected is None

    def _tree_action_buttons(self, *, operation_running: bool) -> list[Button]:
        """Every action the selected placement offers, in composed order.

        Built as a LIST rather than yielded straight into a container
        (task-32544): the widest composition -- "New folder / Add to folder
        / Move note / Remove placement" with a note selected, 62 cells --
        did not fit the 64-column pane a 235-column terminal gives the list
        beside an open note, and Textual toolbars do not wrap, so "Remove
        placement" painted at x=48..68 and read on screen as "Remove pl".
        Measuring the labels first is what lets ``toolbar_action_rows``
        split them across rows the pane can paint, which is the guide's own
        narrow-pane rule applied to this group.

        Args:
            operation_running: Whether a Notes mutation is in flight.

        Returns:
            The group's buttons, freshly built so a caller can mount them.
        """
        projection = self.tree_projection
        selected = (
            projection.row(self.tree_selected_placement_id)
            if projection is not None and self.tree_selected_placement_id
            else None
        )
        selected_folder_protected = bool(
            selected is not None and selected.kind == "folder" and selected.protected
        )
        selected_branch_stale = bool(
            selected is not None and selected.unsafe_mutation_disabled
        )
        protected_reason = (
            "This folder is managed by sync; change its sync root instead."
        )
        stale_reason = "This branch may be out of date; retry it before changing it."
        buttons: list[Button] = [
            Button(
                "New folder",
                id="library-notes-folder-new",
                classes="library-canvas-action",
                compact=True,
                disabled=(
                    operation_running
                    or selected_folder_protected
                    or selected_branch_stale
                ),
                tooltip=(
                    stale_reason
                    if selected_branch_stale
                    else protected_reason
                    if selected_folder_protected
                    else None
                ),
            )
        ]
        if selected is not None and selected.kind == "folder":
            for label, button_id in (
                ("Rename", "library-notes-folder-rename"),
                ("Move", "library-notes-folder-move"),
                ("Remove", "library-notes-folder-remove"),
            ):
                buttons.append(
                    Button(
                        label,
                        id=button_id,
                        classes="library-canvas-action",
                        compact=True,
                        disabled=(
                            operation_running
                            or selected.protected
                            or selected_branch_stale
                        ),
                        tooltip=(
                            stale_reason
                            if selected_branch_stale
                            else protected_reason
                            if selected.protected
                            else None
                        ),
                    )
                )
        elif selected is None or selected.kind == "note":
            # task-32617 AC#1: this branch used to require a selected NOTE,
            # so with none the three note actions were DROPPED rather than
            # disabled -- proven by capture with the canvas driven directly:
            # with `tree_selected_placement_id=""` only "New folder" is
            # composed, filter or no filter (the critique read the vanishing
            # as filter-caused; the filter is what LOSES the selection).
            # Hidden controls teach the reader the feature does not exist,
            # and Sort one control to the left already has the right
            # pattern: disabled, marked, with its reason on the shared line.
            note = selected
            protected = note is not None and note.protected
            unselected = note is None
            if unselected and self.compact:
                # The compact shell is a measured row budget: three blocked
                # actions wrap its 50-cell toolbar onto two extra rows and
                # take a third for their reason, and
                # `test_library_note_60x20_navigator_state_allocation` reads
                # those rows straight off the list. Same reasoning as the
                # heading above and as task-32261's hidden select counter --
                # this shell keeps the rows for the notes.
                return buttons
            unplaced = note is not None and not note.membership_id
            protected_placement_reason = (
                "This placement is managed by sync; change its sync root instead."
            )
            for label, button_id, blocked, reason in (
                (
                    "Add to folder",
                    "library-notes-placement-add",
                    False,
                    None,
                ),
                (
                    "Move note",
                    "library-notes-placement-move",
                    protected,
                    protected_placement_reason,
                ),
                (
                    "Remove placement",
                    "library-notes-placement-remove",
                    protected or unplaced,
                    (
                        protected_placement_reason
                        if protected
                        else "Unfiled is shown automatically; move the note "
                        "into a folder."
                    ),
                ),
            ):
                disabled = (
                    operation_running
                    or selected_branch_stale
                    or unselected
                    or blocked
                )
                buttons.append(
                    Button(
                        library_disabled_action_label(label, disabled),
                        id=button_id,
                        classes="library-canvas-action",
                        compact=True,
                        disabled=disabled,
                        tooltip=(
                            stale_reason
                            if selected_branch_stale
                            else NOTE_ACTIONS_UNSELECTED_REASON
                            if unselected
                            else reason
                            if blocked
                            else None
                        ),
                    )
                )
        if self.tree_deleted_folder_available:
            buttons.append(
                Button(
                    "Restore folder",
                    id="library-notes-folder-restore",
                    classes="library-canvas-action",
                    compact=True,
                    disabled=operation_running,
                )
            )
        return buttons

    @staticmethod
    def _backlink_buttons(
        backlinks: tuple[tuple[str, str], ...],
    ) -> list[Button]:
        """Build one activatable row per inbound link (task-32145).

        The single renderer for both paths -- compose, and the remount in
        ``apply_session_state`` for backlinks that arrive after the editor
        is already on screen (their loader runs after the note opens, and a
        recompose is deferred while the reader is typing).

        Args:
            backlinks: ``(note_id, title)`` rows, possibly one over the cap.

        Returns:
            Row buttons carrying their own ``note_id``, capped for display.
        """
        buttons: list[Button] = []
        for note_id, title in backlinks[:LIBRARY_NOTE_BACKLINK_DISPLAY_CAP]:
            button = library_row_button(
                escape_markup(ellipsize_note_title_cells(title, 60) or "Untitled"),
                classes="library-canvas-action library-note-backlink",
                compact=True,
            )
            button.note_id = note_id
            buttons.append(button)
        return buttons

    @staticmethod
    def _set_tree_row_metadata(button: Button, row: LibraryNotesTreeRow) -> None:
        """Attach stable domain identities without encoding them in DOM ids."""
        button.tree_kind = row.kind
        button.placement_id = row.placement_id
        button.note_id = row.note_id or ""
        button.folder_id = row.folder_id or ""
        button.membership_id = row.membership_id or ""
        button.breadcrumb = row.breadcrumb
        button.ownership = row.ownership or ""
        button.owner_active = row.owner_active
        button.protected_placement = row.protected
        button.folder_version = row.version

    def _compose_editor(self) -> ComposeResult:
        """Mount every editor-session presentation surface exactly once.

        TASK-34000.25 (review finding S-02's false "changed elsewhere" and
        its siblings -- Edit, Preview and Info stacked, two Back buttons, the
        bulk strip, the body unpainted): every display-gated surface is
        gated from ``presentation_state`` HERE, through the same helper
        ``apply_session_state`` runs, before any of it mounts. The mount-time
        apply never ran (Textual sets ``is_mounted`` after the Mount
        handler), and every later sync was a race the retained-note return
        did not always win. ``roots`` holds the top-level nodes so the whole
        pending tree can be gated on the last line, where it is complete and
        still unmounted (``_pending_widget_lookup``).
        """
        presentation_state = self.presentation_state
        if presentation_state is None:
            return
        roots: list[Any] = []

        def root(widget: Any) -> Any:
            roots.append(widget)
            return widget

        snapshot = presentation_state.snapshot
        title = snapshot.title
        content = snapshot.body
        keywords_text = snapshot.keywords_text
        metadata_line = presentation_state.metadata_line
        status_line = presentation_state.status_line
        channels = presentation_state.status_channels or NotesStatusChannels(
            status_line or "Saved",
            NOTES_AUTHORITY_PREFIX,
        )

        # File-synced notes may carry YAML front matter; consume it instead
        # of rendering the delimiter block as note content.
        from tldw_chatbook.Utils.markdown_parsing import front_matter_parser_factory

        # task-32139: Edit/Preview said "‹ Notes", Info said "‹ Note" (two
        # wordings for the identical Back action, live-caught at 235x52),
        # and BOTH said "‹ Notes" on a compact terminal where the guide
        # documents "‹ Back to list" (60x24). One label now, sized by
        # ``self.compact`` like the guide's own compact-vs-wide split.
        back_label = _library_note_back_label(self.compact)
        # task-32548: the heading strip carries the same tie-break the note's
        # list row carries, so two same-titled notes stay distinguishable once
        # one of them is open. Appended AFTER the ellipsis so a long title
        # cannot eat the identity.
        heading_title = _library_note_heading_title(
            title, presentation_state.title_suffix, 72
        )
        with root(Horizontal(id="library-note-heading")):
            yield Button(
                back_label,
                id="library-note-back",
                classes="library-canvas-action",
                compact=True,
            )
            yield Button(
                back_label,
                id="library-note-context-back",
                classes="library-canvas-action",
                compact=True,
            )
            yield Static(
                heading_title,
                id="library-note-editor-title",
                markup=False,
            )
            yield Static(
                heading_title,
                id="library-note-preview-title",
                markup=False,
            )
            yield Static(
                heading_title,
                id="library-note-context-title",
                markup=False,
            )
            yield Static(
                channels.authority_git,
                id="library-note-authority-git-status",
                markup=False,
            )
        # task-32640: one row under the title saying which of the three
        # worlds this note is in, and -- for a note kept in step with a file
        # -- which file, and when that file was last written. Composed
        # unconditionally so the answer is on screen in Edit, Preview and
        # Info alike; `_note_location_follows_width` re-states it against the
        # pane's measured width, like the chrome strip below the body.
        yield root(Static(
            library_note_location_line(
                presentation_state.location_path,
                presentation_state.location_written,
                self._effective_pane_width(),
                attention=presentation_state.location_attention,
            ),
            id="library-note-location",
            markup=False,
        ))
        yield root(Static(
            "Included in bulk selection"
            if presentation_state.bulk_included
            else "Not included in bulk selection",
            id="library-note-bulk-status",
            classes="destination-purpose",
            markup=False,
        ))
        with root(Horizontal(id="library-note-header-second-row")):
            yield Static(
                channels.content_recovery,
                id="library-note-status",
                markup=False,
            )
            primary_actions = Horizontal(
                id="library-note-primary-actions", classes="ds-toolbar"
            )
            primary_actions.add_class("h-auto")
            edit_label, preview_label, info_label = _HEADER_MODE_LABELS
            save_label, use_in_console_label, _discard_label = _HEADER_TASK_LABELS
            with primary_actions:
                with Horizontal(id="library-note-mode-controls", classes="ds-toolbar"):
                    yield Button(
                        edit_label,
                        id="library-note-edit",
                        classes="library-canvas-action",
                        compact=True,
                    )
                    yield Button(
                        preview_label,
                        id="library-note-preview",
                        classes="library-canvas-action",
                        compact=True,
                    )
                    yield Button(
                        info_label,
                        id="library-note-context",
                        classes="library-canvas-action",
                        compact=True,
                    )
                with Horizontal(id="library-note-task-actions", classes="ds-toolbar"):
                    yield Button(
                        save_label,
                        id="library-note-save",
                        classes="library-canvas-action",
                        compact=True,
                    )
                    yield Button(
                        use_in_console_label,
                        id="library-note-use-in-console",
                        classes="library-canvas-action",
                        compact=True,
                    )
                    work_width = self._effective_work_width()
                    discard_new = Button(
                        self._discard_new_label(
                            self.compact,
                            _header_shape(work_width, self.compact),
                            work_width,
                        ),
                        id="library-note-discard-new",
                        classes="library-canvas-action library-media-action-danger",
                        compact=True,
                    )
                    # TASK-34000.8: hidden by VISIBILITY, never by display.
                    # An invisible Button keeps its cells, so the task row
                    # is always its Discard-shown width and the mode
                    # controls beside it never move when Discard comes and
                    # goes (TASK-32623's guarantee, by construction, in
                    # place of the 61-cell `min-width` that pushed Save off
                    # a 48-cell pane). Textual 8.2.8 leaves an invisible
                    # node out of `focus_chain` and `get_widget_at`, so it
                    # is neither Tab-reachable nor clickable. Its visibility
                    # and disabled state are gates, set by
                    # ``_apply_editor_surface_gates`` on the last line of
                    # this compose like every other (fix round 2).
                    yield discard_new
        # TASK-34000.10 (N-07): a veto standing when the editor composes is
        # marked here, from the state, for the same reason every other
        # display-gated surface is (the mount-time apply never runs).
        vetoed_field = presentation_state.validation_field
        veto_reason = presentation_state.validation_message
        with root(Vertical(id="library-note-editor-region")):
            with Horizontal(id="library-note-title-row"):
                yield Static("Title", id="library-note-title-label", markup=False)
                title_input = NoteEditorInput(
                    value="" if self.title_placeholder_only else title,
                    placeholder="Untitled" if self.title_placeholder_only else "",
                    id="library-note-title",
                )
                title_input.set_class(vetoed_field == "title", _NOTE_FIELD_INVALID_CLASS)
                yield title_input
            yield _library_note_field_hint(
                "library-note-title-hint", vetoed_field == "title", veto_reason
            )
            # task-32642 AC#3: keywords used to be reachable only by opening
            # Info -- this Input is the twin that lived, permanently
            # undisplayed, inside `#library-note-wide-utilities`. It is the
            # same id, the same `Input.Changed` handler and the same
            # `apply_session_state` reconciliation it always had; only its
            # parent changed, so it is now on the editor's own Tab ring,
            # under the title, where the note's other two fields are.
            with Horizontal(id="library-note-keywords-row"):
                yield Static("Keywords", id="library-note-keywords-label", markup=False)
                keywords_input = NoteEditorInput(
                    value=keywords_text,
                    placeholder="Comma-separated keywords",
                    id="library-note-keywords",
                )
                keywords_input.set_class(
                    vetoed_field == "keywords", _NOTE_FIELD_INVALID_CLASS
                )
                yield keywords_input
            yield _library_note_field_hint(
                "library-note-keywords-hint", vetoed_field == "keywords", veto_reason
            )
            yield Static("Body", id="library-note-body-label", markup=False)
            body_area = NoteEditorTextArea(content, id="library-note-body")
            body_area.set_class(vetoed_field == "body", _NOTE_FIELD_INVALID_CLASS)
            yield body_area
            yield _library_note_field_hint(
                "library-note-body-hint", vetoed_field == "body", veto_reason
            )

        with root(VerticalScroll(id="library-note-preview-region", can_focus=True)):
            # task-32142 AC#1: the shared heading row's title Static (above)
            # sits in a crowded strip with the mode buttons and Back --
            # easy to miss, and NOT part of the scrolling content, so it
            # never reads as the document's own title the way Edit's Title
            # field does. This one renders INSIDE the preview, immediately
            # above the rendered body, like a document heading.
            yield Static(
                ellipsize_note_title_cells(title, 72),
                id="library-note-preview-body-title",
                classes="destination-section",
                markup=False,
            )
            # TASK-34000.11 (AC#3): ``open_links=False`` -- Textual's default
            # hands every clicked href to ``app.open_url``, which sent a
            # ``note://<id>`` to the operating system. The screen handles
            # ``Markdown.LinkClicked`` for this body instead (a note link
            # opens the note; http(s) goes to the browser through the app's
            # own worker; anything else is refused with a notice).
            yield Markdown(
                render_preview_source(content, title=title),
                id="library-note-preview-body",
                parser_factory=front_matter_parser_factory(),
                open_links=False,
            )
        # TASK-34000.11 (AC#1): the ``[[`` picker. Its own root, not a child
        # of ``#library-note-editor-region``: that region is hidden while
        # Preview shows, and the Preview's Enter lists several links through
        # this same overlay (follow mode). Hidden in code until the
        # controller shows it. Imported here, not at module level
        # (ADR-097): the screen pre-import pass loads this canvas, and the
        # picker is first needed when an editor composes.
        from tldw_chatbook.Widgets.Library.library_note_link_picker import (
            LibraryNoteLinkPicker,
        )

        yield root(
            LibraryNoteLinkPicker(
                id="library-note-link-picker", classes="library-note-link-picker"
            )
        )
        with root(VerticalScroll(id="library-note-context-region", can_focus=True)):
            yield Static("Properties", classes="destination-section", markup=False)
            with Horizontal(id="library-note-context-keywords-row"):
                yield Static(
                    "Keywords", id="library-note-context-keywords-label", markup=False
                )
                context_keywords_input = NoteEditorInput(
                    value=keywords_text,
                    placeholder="Comma-separated keywords",
                    id="library-note-context-keywords",
                )
                context_keywords_input.set_class(
                    vetoed_field == "keywords", _NOTE_FIELD_INVALID_CLASS
                )
                yield context_keywords_input
            yield _library_note_field_hint(
                "library-note-context-keywords-hint",
                vetoed_field == "keywords",
                veto_reason,
            )
            yield Static(
                library_note_property_block(
                    presentation_state.properties,
                    metadata_line,
                    compact=self.compact,
                ),
                id="library-note-context-meta",
                markup=False,
            )
            backlinks = (
                presentation_state.backlinks if presentation_state is not None else ()
            )
            self._rendered_backlinks = tuple(backlinks)
            yield Static(
                library_note_backlink_header(
                    self._rendered_backlinks,
                    presentation_state.backlinks_status
                    if presentation_state is not None
                    else "loading",
                ),
                id="library-note-context-backlinks-title",
                markup=False,
            )
            backlink_rows = Vertical(id="library-note-context-backlinks")
            # Auto height or the empty container claims the whole Info
            # scroll region and pushes Reuse & Export off the pane.
            backlink_rows.add_class("h-auto")
            with backlink_rows:
                yield from self._backlink_buttons(self._rendered_backlinks)
            yield Static("Reuse & Export", classes="destination-section", markup=False)
            legacy_use_in_console = Button(
                "Use in Console",
                id="library-note-context-use-in-console",
                classes="library-canvas-action",
                compact=True,
            )
            # Retain the incumbent selector/handler for compatibility while the
            # single visible affordance lives in the primary task group.
            legacy_use_in_console.display = False
            yield legacy_use_in_console
            yield Button(
                "Copy",
                id="library-note-context-copy",
                classes="library-canvas-action",
                compact=True,
            )
            yield Button(
                "Export Markdown",
                id="library-note-context-export-md",
                classes="library-canvas-action",
                compact=True,
            )
            yield Button(
                "Export text",
                id="library-note-context-export-txt",
                classes="library-canvas-action",
                compact=True,
            )
            yield Static(
                presentation_state.transfer_status
                if presentation_state is not None
                else "",
                id="library-note-context-transfer-status",
                markup=False,
            )
            yield Static("Danger", classes="destination-section", markup=False)
            yield Button(
                "Delete",
                id="library-note-context-delete",
                classes="library-canvas-action library-media-action-danger",
                compact=True,
            )
            # task-32268: the prompt belongs to the button above it. It used
            # to compose as a sibling of every region, below the (hidden)
            # wide utilities and the conflict callout -- live at dev
            # 4a14b3f36f it painted five rows under Delete and OUTSIDE the
            # Info border, which closed above it, so the guide's "renders
            # where Delete was pressed" was not what the screen showed. It is
            # the next child of Danger now, which is also the only place it
            # can be: Delete is reachable from Info alone (task-32132), and
            # ``apply_session_state`` keeps Info open while confirming.
            yield from self._compose_delete_confirmation()
        # task-32143: the editor chrome strip. One row at the bottom of the
        # body, where a terminal reader looks for a status line, carrying
        # the two facts the critique found nowhere on the editing surface:
        # the word count (it lived only under Info) and the caret's line and
        # column (it existed nowhere at all).
        #
        # It does NOT carry the save state, even though the design sketch
        # asked for it: ``apply_compact_presentation`` sets the save state's
        # width/height/wrap as INLINE styles that assume it sits in
        # ``#library-note-header-second-row`` (whose own ``min_height`` is
        # pinned to 3 there), so relocating it means rewriting that shared
        # compact block and re-pinning five deliberate tests -- see
        # task-32143's Implementation Notes.
        yield root(Static(
            library_note_chrome_facts(0, 0, 0),
            id="library-note-chrome-facts",
            markup=False,
        ))
        yield root(Static(
            presentation_state.transfer_status,
            id="library-note-transfer-status",
            markup=False,
        ))

        wide_utilities = root(Vertical(id="library-note-wide-utilities"))
        with wide_utilities:
            # task-32642 AC#3: the Keywords label and field that used to sit
            # here are now in `#library-note-editor-region`, displayed. This
            # container stays `display = False` and keeps only the duplicate
            # action buttons it always had.
            # task-32143 AC#2: `#library-note-meta` used to render the
            # Created/Modified/version/word-count line here. Its container
            # has been `display = False` unconditionally since the utilities
            # moved into Info (see ``apply_session_state``), so it was
            # composed and re-rendered on every state apply and never seen.
            # Info's `#library-note-context-meta` is the one that is read,
            # and the word count it carried now also reads on the chrome
            # strip under the body. Removed rather than left as a second,
            # invisible home for the same sentence.
            wide_actions = Horizontal(classes="ds-toolbar")
            wide_actions.add_class("h-auto")
            with wide_actions:
                yield Button(
                    "Export Markdown",
                    id="library-note-export-md",
                    classes="library-canvas-action",
                    compact=True,
                )
                yield Button(
                    "Export text",
                    id="library-note-export-txt",
                    classes="library-canvas-action",
                    compact=True,
                )
                yield Button(
                    "Copy",
                    id="library-note-copy",
                    classes="library-canvas-action",
                    compact=True,
                )
                yield Button(
                    "Delete",
                    id="library-note-delete",
                    classes="library-canvas-action library-media-action-danger",
                    compact=True,
                )

        conflict_region = root(Vertical(id="library-note-conflict-region"))
        with conflict_region:
            yield Static(
                "This note changed elsewhere — Overwrite saves your text; "
                "Reload discards it.",
                id="library-note-conflict-copy",
                classes="destination-purpose",
                markup=False,
            )
            conflict_actions = Horizontal(
                id="library-note-conflict-actions", classes="ds-toolbar"
            )
            conflict_actions.add_class("h-auto")
            with conflict_actions:
                yield Button(
                    "Overwrite",
                    id="library-note-conflict-overwrite",
                    classes="library-canvas-action",
                    compact=True,
                )
                yield Button(
                    "Reload",
                    id="library-note-conflict-reload",
                    classes="library-canvas-action",
                    compact=True,
                )
        # Every root above is composed and still unmounted: gate the whole
        # tree from the state now, before the first frame can paint it.
        try:
            self._apply_editor_surface_gates(
                presentation_state, _pending_widget_lookup(roots)
            )
        except NoMatches as exc:
            self._defer_editor_surface_gates(exc)

    def _defer_editor_surface_gates(self, exc: NoMatches) -> None:
        """Gate the editor one refresh late when the compose-time lookup misses.

        PR #3055 review (Important 1): ``_pending_widget_lookup`` reads
        Textual's private compose-time registry (``_pending_children``). If
        a Textual change empties that index, the first gated selector raises
        ``NoMatches`` INSIDE ``compose`` -- and a compose exception means the
        Notes editor cannot mount at all (the nav-freeze shape). Ruling:
        never raise out of compose and never skip the gates. Log once at
        WARNING (the selector only, no note content) and run the same
        ``_apply_editor_surface_gates`` over the mounted tree after the
        first refresh -- one frame late, still correct. The fast-lane
        contract test keeps the loud pin on the attribute's name.

        Args:
            exc: The miss, for the one-time log line.
        """
        if not LibraryNotesCanvas._pending_lookup_warned:
            LibraryNotesCanvas._pending_lookup_warned = True
            logger.warning(
                "Library note editor: compose-time surface gating could not "
                "resolve its nodes ({}); gating after the first refresh instead",
                exc,
            )
        self.call_after_refresh(self._apply_editor_surface_gates_after_mount)

    def _apply_editor_surface_gates_after_mount(self) -> None:
        """The deferred half of :meth:`_defer_editor_surface_gates`."""
        state = self.presentation_state
        if state is None or self.mode != "editor":
            return
        try:
            self._apply_editor_surface_gates(state, self.query_one)
        except NoMatches:
            # Recomposed away between the miss and the refresh; the next
            # compose gates its own tree.
            return

    def _compose_delete_confirmation(self) -> ComposeResult:
        """Mount the delete prompt where task-32268 requires it: in Danger."""
        with Vertical(id="library-note-delete-confirmation"):
            yield Static(
                delete_confirm_copy(synced=False),
                id="library-note-delete-confirm-copy",
                markup=False,
            )
            delete_actions = Horizontal(
                id="library-note-delete-actions", classes="ds-toolbar"
            )
            delete_actions.add_class("h-auto")
            with delete_actions:
                yield Button(
                    "Cancel",
                    id="library-note-delete-cancel",
                    classes="library-canvas-action",
                    compact=True,
                )
                yield Button(
                    "Delete",
                    id="library-note-delete-confirm",
                    classes="library-canvas-action library-media-action-danger",
                    compact=True,
                )

    def on_mount(self) -> None:
        """Apply initial visibility after the stable editor subtree mounts."""
        self._children_ready = True
        self._apply_post_compose_state()
        if self.mode == "lasting_add":
            self.call_after_refresh(self._focus_initial_lasting_sync_control)

    def _focus_initial_lasting_sync_control(self) -> None:
        """Focus the safe first control once, after the wrapper initially mounts."""

        canvases = self.query("#library-notes-lasting-add-canvas")
        if canvases:
            canvases.first(LibraryNotesAddFromFilesCanvas).focus_first_safe_control()

    def _apply_post_compose_state(self) -> None:
        """Post-compose wiring shared by ``on_mount`` and ``_after_recompose``.

        Gated on the MOUNTED CHILDREN, not on ``self.mode``. ``on_mount``
        could trust the mode because it fires once, immediately after its own
        compose. ``_after_recompose`` cannot: ``sync_state`` mutates the
        fields and only SCHEDULES the rebuild, so a second ``sync_state``
        landing while the first recompose is still awaiting ``mount_all``
        leaves this hook reading the newer state against the older children.
        Observed exactly that on the list -> loading -> editor row-press
        sequence: ``mode`` was already "editor" with a presentation state set
        while the mounted child was still ``#library-note-load-state``, and
        ``apply_session_state``'s ``query_one("#library-note-title")`` raised
        into the sync's whole-screen fallback. The newer state's own
        recompose is already queued and applies it a moment later.
        """
        self.apply_compact_presentation(self.compact)
        if self.mode != "editor" or self.presentation_state is None:
            return
        try:
            self.query_one("#library-note-title")
        except NoMatches:
            return
        self.apply_session_state(self.presentation_state)

    @staticmethod
    def _discard_new_label(compact: bool, stacked: bool, work_width: int) -> str:
        """Discard new note's wording: the full label wherever its row holds it.

        The compact sheet keeps its own short "Discard" (its 60-column
        shapes are pinned). A STACKED task row has the pane's width less the
        toolbar gutters, and takes the full wording when that holds
        ``_HEADER_STACKED_TASK_ROW_MIN_WIDTH`` (55 for the labels above):
        measured at 120x36 the row is the 48-cell pane and "Save · Use in
        Console · Discard new note" needs 53 cells inside a 2-cell gutter
        (8 + 18 + 20 of buttons, 2 of gutter, 4 of gaps), so there it takes
        the compact wording the AC allows; at 160x45 the row has 82+ cells
        and keeps "Discard new note" (review M-2). The three-row strip
        always keeps the full wording -- its width is in the one-row rule.
        """
        if compact:
            return _HEADER_DISCARD_SHORT_LABEL
        if stacked and 0 < work_width < _HEADER_STACKED_TASK_ROW_MIN_WIDTH:
            return _HEADER_DISCARD_SHORT_LABEL
        return _HEADER_TASK_LABELS[2]

    def apply_compact_presentation(self, compact: bool) -> None:
        """Update responsive copy without remounting the canvas."""
        self.compact = compact
        self.styles.min_width = 0 if compact else 40
        if not self.is_mounted or not self._children_ready or self._pruning:
            # TASK-34789: this canvas's own ``recompose()`` prunes its
            # children leaf-first and remounts them root-first, so for its
            # whole duration the header row can be in the DOM without the
            # save state and toolbars the block below reads unguarded. A
            # shell resize handled on the SCREEN's pump in that window
            # (``apply_work_width``, on a work pane a notes-tree or trash
            # reload was recomposing) raised ``NoMatches`` out of the
            # screen's resize handler: the end of a headless run, and in the
            # running app the keep-alive retiring the Library screen.
            #
            # Nothing is lost for a recompose: ``compact`` is stored above
            # and the widths by the callers, and ``_after_recompose``
            # re-applies them to the new children. A canvas that is itself
            # being removed (``_pruning``) loses its children the same way
            # while both flags still read True; it never paints again, so
            # there is nothing to re-apply. The not-yet-mounted half is
            # older than this guard and keeps the gap ``apply_session_state``
            # documents (a width handed over before mount waits for the next
            # sync).
            return
        if self.mode == "list" and self.list_state is not None:
            try:
                self.query_one(
                    "#library-notes-database-purpose", Static
                ).display = not compact
            except NoMatches:
                pass
            rendered_count = len(self.list_state.rows)
            # task-32261 AC#1: the in-strip counter's compact hide flips on a
            # breakpoint crossing, like the two labels below -- this method
            # is the canvas's whole in-place responsive path.
            try:
                self.query_one(
                    "#library-notes-selected-count", Static
                ).display = not compact
            except NoMatches:
                pass
            try:
                self.query_one("#library-notes-select-all", Button).label = (
                    f"All {rendered_count}"
                    if compact
                    else f"Select all {rendered_count} shown"
                )
            except NoMatches:
                pass
            try:
                button = self.query_one("#library-notes-export-selected", Button)
            except NoMatches:
                button = None
            if button is not None:
                # Whole-branch review IMPORTANT-1: this in-place rewrite must
                # compose through the same marker helper as compose() and the
                # screen's `_patch_library_disabled_marker_label`, and re-tier
                # the stashed base -- a plain rewrite stripped the AC#1 "○"
                # marker on every compact-boundary crossing while disabled,
                # and left the stash at the wrong-tier spelling for the next
                # in-place patch.
                export_base = "Export" if compact else "Export selected"
                button._library_disabled_marker_base = export_base
                button.label = library_disabled_action_label(
                    export_base, button.disabled, align=True
                )
            return
        try:
            second_row = self.query_one("#library-note-header-second-row", Horizontal)
        except NoMatches:
            second_row = None
        # TASK-34000.8: the second row has three shapes. Wide (one 3-row
        # strip: save state, mode controls, task actions side by side),
        # STACKED (the editor pane is narrower than the strip needs: the
        # save state on its own full-width row, then the mode row, then the
        # task row -- three rows, one each) and compact (the shell's own
        # stacked sheet, where the save state may wrap to three lines).
        # Stacked reuses the compact shape's machinery, in place, so the
        # widgets keep their identity across every crossing.
        stacked = _header_shape(self._effective_work_width(), compact)
        rows = compact or stacked
        if second_row is not None:
            heading = self.query_one("#library-note-heading")
            status = self.query_one("#library-note-status", Static)
            authority = self.query_one("#library-note-authority-git-status", Static)
            primary = self.query_one("#library-note-primary-actions", Horizontal)
            mode_controls = self.query_one("#library-note-mode-controls", Horizontal)
            task_actions = self.query_one("#library-note-task-actions", Horizontal)
            heading.styles.layout = "horizontal"
            heading.set_class(compact, "h-1")
            heading.set_class(not compact, "h-3")
            heading.styles.min_height = 1 if compact else 3
            heading.styles.max_height = 1 if compact else 3
            second_row.styles.layout = "vertical" if rows else "horizontal"
            second_row.set_class(rows, "h-auto")
            second_row.set_class(not rows, "h-3")
            second_row.styles.min_height = 3
            second_row.styles.max_height = 5 if compact else 3
            status.add_class("w-fill")
            status.set_class(compact, "h-auto")
            status.set_class(stacked, "h-1")
            status.set_class(not rows, "h-3")
            status.styles.min_height = 1 if rows else 3
            status.styles.max_height = 1 if stacked else 3
            # AC#4: on the shared row the save state is never squeezed to
            # one column -- the one-row shape is only chosen when the pane
            # has room for this floor beside both action groups.
            status.styles.min_width = 0 if rows else _HEADER_STATUS_MIN_WIDTH
            status.styles.text_wrap = "nowrap" if stacked else "wrap"
            status.styles.text_overflow = "ellipsis" if stacked else "clip"
            primary.styles.layout = "vertical" if rows else "horizontal"
            primary.set_class(rows, "w-full")
            primary.set_class(not rows, "w-auto")
            primary.set_class(rows, "h-2")
            primary.set_class(not rows, "h-3")
            primary.styles.min_height = 2 if rows else 3
            primary.styles.max_height = 2 if rows else 3
            for actions in (mode_controls, task_actions):
                actions.set_class(rows, "w-full")
                actions.set_class(not rows, "w-auto")
                actions.set_class(rows, "h-1")
                actions.set_class(not rows, "h-3")
                actions.styles.min_height = 1 if rows else 3
                actions.styles.max_height = 1 if rows else 3
            authority.set_class(compact, "w-18")
            authority.set_class(not compact, "w-auto")
            authority.styles.min_width = 12 if compact else 0
            authority.styles.max_width = 18 if compact else None
            authority.set_class(compact, "h-1")
            authority.set_class(not compact, "h-3")
            authority.styles.text_wrap = "nowrap" if compact else "wrap"
            authority.styles.text_overflow = "ellipsis" if compact else "clip"
            for button in primary.query(Button):
                button.add_class("w-auto")
                button.set_class(rows, "h-1")
                button.set_class(not rows, "h-3")
                button.styles.min_height = 1 if rows else 3
                button.styles.max_height = 1 if rows else 3
        try:
            self.query_one("#library-note-discard-new", Button).label = (
                self._discard_new_label(
                    compact, stacked, self._effective_work_width()
                )
            )
        except NoMatches:
            pass
        # PR #2555 review (Qodo finding 2): the New-note and load-retry views
        # pick their Back wording at compose time only, and crossing the
        # compact breakpoint re-runs this method instead of recomposing them
        # -- so without this they keep the previous width's wording. (The
        # editor's own #library-note-back/#library-note-context-back are
        # rewritten from the snapshot in ``apply_session_state``, which calls
        # this method first, so a stale value there is corrected either way.)
        back_label = _library_note_back_label(compact)
        for selector in ("#library-note-back", "#library-notes-create-back"):
            try:
                button = self.query_one(selector, Button)
            except NoMatches:
                continue
            if str(button.label) != back_label:
                button.label = back_label

    @staticmethod
    def _static_text(widget: Static) -> str:
        renderable = widget.renderable
        return getattr(renderable, "plain", str(renderable))

    @staticmethod
    def _editor_surface_flags(state: LibraryNotePresentationState) -> _EditorSurfaceFlags:
        """Derive which editor surfaces ``state`` shows (TASK-34000.25: one owner).

        task-32132: Delete is only reachable from the Info Danger section
        (the Edit pane's own Delete lives in ``library-note-wide-utilities``,
        permanently hidden). Confirming used to force ``show_context`` off
        unconditionally, snapping the pane to Edit -- "delete this note?"
        painted 14 rows away, under a body editor the user never opened.
        Info stays put while confirming; only Preview (which never hosts a
        Delete button) still yields to Edit. task-32268: the prompt is a
        child of Info's Danger section, so Info has to be the surface
        whenever it is up -- stating it as a condition makes the invariant
        the prompt's placement depends on explicit rather than incidental.
        """
        conflict = state.conflict
        confirming_delete = state.confirming_delete and not conflict
        bulk_read_only = state.bulk_read_only
        show_context = (
            (state.region == "context" or confirming_delete)
            and not conflict
            and not bulk_read_only
        )
        show_preview = bulk_read_only or (
            not show_context
            and not conflict
            and not confirming_delete
            and state.presentation == "preview"
        )
        show_editor = not show_context and not show_preview
        locked = confirming_delete or state.destructive_running or bulk_read_only
        return _EditorSurfaceFlags(
            conflict=conflict,
            confirming_delete=confirming_delete,
            bulk_read_only=bulk_read_only,
            show_context=show_context,
            show_preview=show_preview,
            show_editor=show_editor,
            locked=locked,
        )

    def _apply_editor_surface_gates(
        self,
        state: LibraryNotePresentationState,
        node: Callable[[str], Any],
    ) -> _EditorSurfaceFlags:
        """Set every display / disabled / is-active / can_focus gate from ``state``.

        TASK-34000.25: the ONE owner of the gating rules. ``_compose_editor``
        calls it over the unmounted tree (``node`` resolves ``#id`` through
        ``_pending_widget_lookup``) so the first frame is right, and
        ``apply_session_state`` calls it with ``self.query_one`` on every
        sync. Values (labels, copy, field text) stay in the sync -- they are
        not gates and re-assigning them echoes ``Changed`` events.

        Args:
            state: The presentation state to gate from.
            node: ``#id`` selector -> widget.

        Returns:
            The derived flags, for the caller's own value work.
        """
        flags = self._editor_surface_flags(state)
        show_editor = flags.show_editor
        show_preview = flags.show_preview
        show_context = flags.show_context
        confirming_delete = flags.confirming_delete
        bulk_read_only = flags.bulk_read_only
        locked = flags.locked
        for selector in (
            "#library-note-transfer-status",
            "#library-note-context-transfer-status",
        ):
            node(selector).display = bool(state.transfer_status) and not state.compact
        back_button = node("#library-note-back")
        back_button.display = not show_context and not bulk_read_only
        back_button.disabled = confirming_delete
        context_back_button = node("#library-note-context-back")
        context_back_button.display = show_context
        # PR #2547 review (Qodo finding 4): Back was left out of the
        # disabled-selector loops below, so it stayed live behind the
        # confirmation prompt. A press ran the Back handler, which clears
        # ``_library_note_context`` without cancelling the pending
        # admission -- displacing the prompt instead of leaving Info in
        # place like every other Danger/Reuse & Export action.
        context_back_button.disabled = confirming_delete
        node("#library-note-editor-title").display = show_editor
        node("#library-note-preview-title").display = show_preview
        node("#library-note-context-title").display = show_context
        node("#library-note-bulk-status").display = bulk_read_only
        node("#library-note-editor-region").display = show_editor
        node("#library-note-preview-region").display = show_preview
        node("#library-note-context-region").display = show_context
        node("#library-note-edit").set_class(show_editor, "is-active")
        node("#library-note-preview").set_class(
            show_preview and not bulk_read_only, "is-active"
        )
        node("#library-note-context").set_class(show_context, "is-active")
        node("#library-note-primary-actions").display = (
            not flags.conflict and not confirming_delete
        )
        node("#library-note-wide-utilities").display = False
        node("#library-note-conflict-region").display = flags.conflict
        node("#library-note-delete-confirmation").display = confirming_delete
        # task-32106 (PR #2571 re-review, NEW-2): DISABLED, not read-only,
        # is load-bearing while ``confirming_delete``. These four fields
        # carry a PRIORITY tab binding (``NoteEditorInput`` /
        # ``NoteEditorTextArea``), which ``App._check_bindings`` resolves
        # before ``LibraryScreen.on_key`` -- and ``on_key`` is where the
        # delete prompt's Tab trap lives. Textual blurs a widget when it
        # becomes disabled and drops it from ``focusable``, so no note field
        # can be in the binding chain while the prompt is open and the trap
        # holds. Keep one of these live behind the prompt and Tab would walk
        # straight out of it; ``test_delete_confirmation_traps_tab_between_
        # cancel_and_delete`` asserts the disabled state for that reason.
        node("#library-note-title").disabled = not show_editor or locked
        node("#library-note-body").disabled = not show_editor or locked
        # task-32642 AC#3: the same rule as the title and body above. This
        # field used to be disabled whenever the terminal was compact --
        # harmless while it lived undisplayed inside
        # `#library-note-wide-utilities`, and a silent Tab hole the moment it
        # became the editor's own Keywords stop: `focusable` was False at
        # 100x30 and 60x20 while `display` and `visible` were both True.
        node("#library-note-keywords").disabled = not show_editor or locked
        node("#library-note-context-keywords").disabled = not show_context or locked
        node("#library-note-preview-body").can_focus = False
        node("#library-note-preview-region").can_focus = show_preview
        node("#library-note-context-region").can_focus = show_context
        # TASK-34000.11: the link picker lives with the surface that opened
        # it -- the editor in insert mode, Preview in follow mode. When that
        # surface goes (Preview pressed over an open ``[[`` picker, Back,
        # Info), the picker goes with it and the body's key routing is
        # released; the controller owns every other show/hide.
        picker = node("#library-note-link-picker")
        if picker.is_open and (
            (picker.mode == "insert" and not show_editor)
            or (picker.mode == "follow" and not show_preview)
        ):
            picker.hide()
            body = node("#library-note-body")
            body.link_picker_open = False
            body.link_picker_has_rows = False

        for selector in (
            "#library-note-edit",
            "#library-note-save",
            "#library-note-preview",
            "#library-note-context",
            "#library-note-use-in-console",
            "#library-note-export-md",
            "#library-note-export-txt",
            "#library-note-copy",
            "#library-note-delete",
            "#library-note-context-use-in-console",
            "#library-note-context-export-md",
            "#library-note-context-export-txt",
            "#library-note-context-copy",
            "#library-note-context-delete",
        ):
            node(selector).disabled = (
                state.destructive_running or bulk_read_only or confirming_delete
            )
        for selector in (
            "#library-note-use-in-console",
            "#library-note-export-md",
            "#library-note-export-txt",
            "#library-note-copy",
            "#library-note-context-use-in-console",
            "#library-note-context-export-md",
            "#library-note-context-export-txt",
            "#library-note-context-copy",
        ):
            node(selector).disabled = (
                state.destructive_running
                or state.transfer_running
                or bulk_read_only
                # task-32132 fix round 1 Important 5: Info stays visible
                # while confirming (this fix's own AC#1), so its Danger/
                # Reuse & Export buttons -- Delete, Copy, Export, Use in
                # Console -- were still live behind the confirmation
                # prompt; a press could navigate away (Use in Console) or
                # mutate (Copy/Export) with the delete admission still
                # pending.
                or confirming_delete
            )
        # Visibility, not display: the cells stay reserved (see compose).
        discard_new = node("#library-note-discard-new")
        discard_new.visible = state.discard_new_note
        discard_new.disabled = state.destructive_running or bulk_read_only
        for selector in (
            "#library-note-conflict-overwrite",
            "#library-note-conflict-reload",
        ):
            node(selector).disabled = (
                state.destructive_running or state.conflict_running
            )
        for selector in (
            "#library-note-delete-confirm",
            "#library-note-delete-cancel",
        ):
            node(selector).disabled = state.destructive_running
        return flags

    def _apply_field_validation_marks(self, state: LibraryNotePresentationState) -> None:
        """Outline the vetoed field and show its reason under it; clear the rest.

        TASK-34000.10 (N-07): the only veto styling used to be the compact
        status-row rule on the whole canvas. The mark follows the state on
        every sync: editing the marked field itself clears it (fix round 1,
        M-5 -- a key typed into another field leaves it where it is), and a
        veto on another field moves it. Difference-checked like the other
        surfaces: ``display`` flips lay the pane out.
        """
        for field_selector, hint_selector, field in _NOTE_FIELD_MARKS:
            vetoed = state.validation_field == field
            self.query_one(field_selector).set_class(vetoed, _NOTE_FIELD_INVALID_CLASS)
            hint = self.query_one(hint_selector, Static)
            reason = state.validation_message if vetoed else ""
            if self._static_text(hint) != reason:
                hint.update(reason)
            if hint.display != vetoed:
                hint.display = vetoed

    def apply_session_state(self, state: LibraryNotePresentationState) -> None:
        """Synchronize stable editor surfaces from one immutable snapshot.

        Value assignments are difference-checked so repeated application is
        idempotent. The screen owns the presentation-sync guard around calls
        that may assign ``Input`` or ``TextArea`` values.
        """
        # Shallow title/authority nodes can precede nested toolbar children.
        # Retain updates until the mount hook can apply them to the whole tree.
        #
        # Known (TASK-34000.25): Textual flips ``_is_mounted`` only AFTER the
        # ``Mount`` handler returns, so the call ``on_mount`` makes through
        # ``_apply_post_compose_state`` takes this early return and applies
        # nothing -- a freshly composed editor shows its surfaces exactly as
        # ``_compose_editor`` composed them until the next sync. Widening
        # the guard to ``is_attached`` changed two pinned behaviours (the
        # emptied-blank GC on Back, the compact Preview scroll memory), so
        # the compose itself now reads the display-gated flags from the
        # state (see ``_compose_editor``), and this guard is left as it was.
        if self.mode != "editor" or not self.is_mounted or not self._children_ready:
            self.presentation_state = state
            self.compact = state.compact
            return
        self.presentation_state = state
        self.compact = state.compact
        # Second half of the early-out above: a MOUNTED pane whose CHILDREN
        # are between removal and remount has none of the surfaces below, and
        # `query_one` raised `NoMatches` on the first of them. The backlinks
        # loader reaches here from a WORKER, whose default
        # `exit_on_error=True` turns that into a dead process rather than a
        # skipped paint (task-32467, reproduced twice live on dev).
        #
        # Guarded HERE, not at a caller: several callers reach this method
        # directly, and returning before it would also discard the
        # `title_placeholder_only` and stage-visibility work the controller
        # does around this call. `_apply_post_compose_state` guards the same
        # shape for its own call and documents the sequence that produces it.
        #
        # Returning is complete, not lossy: the state is stored above and
        # `_apply_post_compose_state` re-applies it the moment the recompose
        # that removed these children mounts the new ones.
        try:
            authority = self.query_one(f"#{self.authority_id}", Static)
            self.query_one("#library-note-title")
        except NoMatches:
            return
        authority_copy = self._authority_copy()
        if self._static_text(authority) != authority_copy:
            authority.update(authority_copy)
        snapshot = state.snapshot
        flags = self._editor_surface_flags(state)
        confirming_delete = flags.confirming_delete
        show_preview = flags.show_preview

        title_input = self.query_one("#library-note-title", Input)
        body_input = self.query_one("#library-note-body", TextArea)
        wide_keywords = self.query_one("#library-note-keywords", Input)
        context_keywords = self.query_one("#library-note-context-keywords", Input)
        presented_title = "" if self.title_placeholder_only else snapshot.title
        # task-32062: the field the reader is typing in is its OWN authority.
        # This patch used to overwrite it from a snapshot that could be one
        # keystroke behind -- and assigning `Input.value` clamps the cursor to
        # the shorter text, so the rest of the sentence was then inserted at
        # that stale position. Live: "My first note", Tab, a body typed within
        # ~0.4 s stored the title "Mhello from jordan, testing the libraryy
        # first note" with an empty body. A focused field is skipped; its own
        # Changed events are what the snapshot is built from anyway.
        if title_input.value != presented_title and not title_input.has_focus:
            with title_input.prevent(Input.Changed):
                title_input.value = presented_title
        title_input.placeholder = "Untitled" if self.title_placeholder_only else ""
        if body_input.text != snapshot.body and not body_input.has_focus:
            with body_input.prevent(TextArea.Changed):
                body_input.text = snapshot.body
        # Same rule as the title above: a keyword box the reader is typing in
        # is its own authority, and the snapshot is built from its own Changed
        # events anyway (review of PR #2531).
        if (
            wide_keywords.value != snapshot.keywords_text
            and not wide_keywords.has_focus
        ):
            with wide_keywords.prevent(Input.Changed):
                wide_keywords.value = snapshot.keywords_text
        if (
            context_keywords.value != snapshot.keywords_text
            and not context_keywords.has_focus
        ):
            with context_keywords.prevent(Input.Changed):
                context_keywords.value = snapshot.keywords_text

        title_width = 52 if state.compact else 72
        title = ellipsize_note_title_cells(snapshot.title, title_width)
        # task-32548: the heading strip carries the tie-break; the Preview
        # body's document heading does not -- it is the note's own title as
        # the reader wrote it, not a list identity.
        heading_title = _library_note_heading_title(
            snapshot.title, state.title_suffix, title_width
        )
        for selector, copy in (
            ("#library-note-editor-title", heading_title),
            ("#library-note-preview-title", heading_title),
            ("#library-note-context-title", heading_title),
            ("#library-note-preview-body-title", title),
        ):
            widget = self.query_one(selector, Static)
            if self._static_text(widget) != copy:
                widget.update(copy)

        preview_body = self.query_one("#library-note-preview-body", Markdown)
        # Markdown.update() parses and remounts asynchronously. Keep the
        # hidden Preview stale while typing, then perform one canonical update
        # when Preview becomes the active surface so edits cannot queue an
        # unbounded hidden-render backlog.
        #
        # task-32263: an imported body stores its links as
        # `[[Title]](note://<id>)` -- a working Obsidian link this module's own
        # parser reads back. Markdown does not know that spelling, so Preview
        # renders the display text and leaves the identifier behind the link.
        # task-32249: and an Obsidian callout header renders as a callout
        # rather than printing its `[!note]` marker. Both rewrites run at
        # compose time too, so the staleness comparison below has to be
        # against the SAME rendered source -- comparing the raw body would
        # re-render every sync on any note carrying a link or a callout.
        # TASK-32804.11: compute the (link/callout-rewritten) preview source
        # ONLY when Preview is the active surface. It ran on every sync --
        # including every keystroke while Preview was hidden -- exactly the
        # hidden-render backlog the comment above says to avoid.
        if show_preview:
            preview_source = render_preview_source(
                snapshot.body, title=snapshot.title
            )
            if preview_body.source != preview_source:
                preview_body.update(preview_source)
        channels = state.status_channels or NotesStatusChannels(
            state.status_line or "Saved",
            NOTES_AUTHORITY_PREFIX,
        )
        content_copy = channels.content_recovery
        if channels.safe_next_action:
            content_copy = f"{content_copy} Next: {channels.safe_next_action}."
        status_widget = self.query_one("#library-note-status", Static)
        if self._static_text(status_widget) != content_copy:
            status_widget.update(content_copy)
        authority_status = self.query_one("#library-note-authority-git-status", Static)
        if self._static_text(authority_status) != channels.authority_git:
            authority_status.update(channels.authority_git)
        # task-32143 AC#2: was a two-selector loop -- the second home,
        # `#library-note-meta`, was never displayed. One meta line now.
        # task-32640: kept current from the state, not from the note record.
        self._note_location = (
            state.location_path,
            state.location_written,
            state.location_attention,
        )
        self._restate_note_location()
        context_meta = self.query_one("#library-note-context-meta", Static)
        meta_copy = library_note_property_block(
            state.properties, state.metadata_line, compact=state.compact
        )
        if self._static_text(context_meta) != meta_copy:
            context_meta.update(meta_copy)
        # task-32145: backlinks are loaded by their own worker AFTER the note
        # opens, so they land on an editor that is already composed -- and a
        # recompose is deferred for as long as the reader owns a field
        # (task-32062). Reconciling them here is what makes them appear at
        # all: switching Edit -> Info is a `display` flip on this same
        # composition, not a rebuild.
        backlinks = tuple(state.backlinks)
        if backlinks != self._rendered_backlinks:
            self._rendered_backlinks = backlinks
            container = self.query_one("#library-note-context-backlinks", Vertical)
            container.remove_children()
            rows = self._backlink_buttons(backlinks)
            if rows:
                container.mount_all(rows)
        backlink_title = self.query_one(
            "#library-note-context-backlinks-title", Static
        )
        backlink_copy = library_note_backlink_header(
            backlinks, state.backlinks_status
        )
        if self._static_text(backlink_title) != backlink_copy:
            backlink_title.update(backlink_copy)
        for selector in (
            "#library-note-transfer-status",
            "#library-note-context-transfer-status",
        ):
            transfer = self.query_one(selector, Static)
            if self._static_text(transfer) != state.transfer_status:
                transfer.update(state.transfer_status)

        self.apply_compact_presentation(state.compact)
        self.set_class(state.validation, "library-note-validation")
        self._apply_field_validation_marks(state)
        # task-32139: one Back label, sized by compact -- see the matching
        # compose-time comment above.
        back_label = _library_note_back_label(state.compact)
        back_button = self.query_one("#library-note-back", Button)
        if str(back_button.label) != back_label:
            back_button.label = back_label
        context_back_button = self.query_one("#library-note-context-back", Button)
        if str(context_back_button.label) != back_label:
            context_back_button.label = back_label
        bulk_status = self.query_one("#library-note-bulk-status", Static)
        bulk_copy = (
            "Read-only preview · Included in bulk selection"
            if state.bulk_included
            else "Read-only preview · Not included in bulk selection"
        )
        if self._static_text(bulk_status) != bulk_copy:
            bulk_status.update(bulk_copy)
        if confirming_delete:
            # TASK-32633 (N-03): a synced note's delete says what happens to
            # its file, read from the same live location the row states.
            confirm_copy = self.query_one("#library-note-delete-confirm-copy", Static)
            wanted = delete_confirm_copy(synced=bool(state.location_path))
            if self._static_text(confirm_copy) != wanted:
                confirm_copy.update(wanted)

        # TASK-34000.25: every display / disabled / is-active / can_focus gate
        # lives in ``_apply_editor_surface_gates`` -- the same helper
        # ``_compose_editor`` runs over the unmounted tree -- so compose and
        # sync can never disagree about which surface a state shows.
        self._apply_editor_surface_gates(state, self.query_one)
        self.update_note_chrome_facts(state.word_count)

    # --- editor chrome strip (task-32143) ---------------------------------

    def update_note_chrome_facts(
        self,
        word_count: int | None = None,
        body: TextArea | None = None,
    ) -> None:
        """Repaint the chrome strip's facts cell from the live editor.

        Counts nothing: the controller already scans the body for the meta
        line on every change, so the number arrives with the presentation
        state, and the caret comes off the ``TextArea``. Nothing here reads
        the database.

        It is not free, though, and this docstring used to imply it was
        (review F3). The cost was never the format -- it was the lookups,
        and specifically ``if not self.query("#id")``: truth-testing a
        ``DOMQuery`` walks the whole subtree, where ``query_one`` on an id
        does not. Measured per call on a 35,310-byte note in the real
        editor route: the old four-lookup sequence **263.6 us**, the two
        lookups that replace it **0.7 us**, and the whole-body
        ``len(text.split())`` the design ruled out **80.4 us**. So the
        repaint had been costing ~3x the banned scan, and now costs ~1% of
        it. The caret handler hands in the ``TextArea`` its own event
        already carries; the rest share one ``try``. No debounce needed at
        0.7 us -- add one only if this ever grows a real scan back.

        Args:
            word_count: The controller's count. Omitted by the caret and
                resize handlers, which repaint from the last one fed in.
            body: The editor body, when the caller already holds it (the
                ``SelectionChanged`` event carries it). Looked up otherwise.
        """
        if word_count is not None:
            self._note_chrome_word_count = word_count
        try:
            facts = self.query_one("#library-note-chrome-facts", Static)
            editing = bool(self.query_one("#library-note-editor-region").display)
            if body is None:
                body = self.query_one("#library-note-body", TextArea)
        except NoMatches:
            # Any mode but the editor, and the editor before it composes.
            return
        try:
            wide = self.app.size.width >= NOTE_CHROME_FACTS_MIN_WIDTH
        except NoActiveAppError:
            # Same answer as ``_authority_prefix`` (:769), which reads this
            # same ``self.app.size.width`` under its own guard and documents
            # the choice as "a widget with no live app keeps the prefix:
            # that is the answer that loses nothing". It catches ``Exception``
            # where this catches the one error ``self.app`` actually raises.
            wide = True
        # Preview and Info have no caret to report, and a narrow terminal
        # has no room -- the save state owns the row alone in both cases.
        facts.display = editing and wide
        if not facts.display:
            return
        row, column = body.cursor_location
        copy = library_note_chrome_facts(self._note_chrome_word_count, row, column)
        if self._static_text(facts) != copy:
            facts.update(copy)

    @on(TextArea.SelectionChanged, "#library-note-body")
    def _note_chrome_follows_caret(self, event: TextArea.SelectionChanged) -> None:
        """Follow the caret: arrow keys never reach the presentation state."""
        self.update_note_chrome_facts(body=event.text_area)

    @on(Resize)
    def _note_link_picker_follows_resize(self, event: Resize) -> None:
        """The FOLLOW-mode picker re-anchors to the pane's new geometry (fix
        round 3, R3-4: it is anchored to the Preview region, which a resize
        moves). Decorated, like ``_note_chrome_follows_width`` beside it: the
        pane's own ``on_resize`` keeps running."""
        from tldw_chatbook.Widgets.Library.library_note_link_picker import (
            LibraryNoteLinkPicker,
        )

        try:
            picker = self.query_one("#library-note-link-picker", LibraryNoteLinkPicker)
        except NoMatches:
            return
        # The insert-mode picker does not re-anchor on a resize: fix round 5
        # CLOSES it on the screen's own Resize (the controller's
        # ``close_library_note_link_picker_on_resize``), and typing within
        # the ``[[`` reopens it. This hook is the follow picker's alone.
        if picker.is_open and picker.mode == "follow":
            picker.reanchor()

    def _restate_note_location(self) -> None:
        """Re-state the location row against the width the pane actually has.

        Compose runs before the canvas is measured, so the row is composed
        at whatever ``_effective_pane_width`` can say then and re-stated
        here -- on every state apply and on every resize. Same shape as the
        import canvas's ``_fit_source_summary``, and the same reason.

        Below ``NOTE_CHROME_FACTS_MIN_WIDTH`` the row is given back to the
        body, on the same terms and at the same threshold as the chrome
        strip under it: measured at 60x20, the editor's body is four rows
        before this task and two after it plus task-32642's Keywords row.
        A note editor with two rows of note is a worse answer to "can I
        work here" than an unanswered "where does this live". Nothing else
        answers it at that width -- the trade is recorded on task-32640.
        """
        try:
            row = self.query_one("#library-note-location", Static)
        except NoMatches:
            # Every mode but the editor, and the editor before it composes --
            # the same guard ``update_note_chrome_facts`` uses beside it.
            return
        try:
            row.display = self.app.size.width >= NOTE_CHROME_FACTS_MIN_WIDTH
        except NoActiveAppError:
            row.display = True
        if not row.display:
            return
        path, written, attention = self._note_location
        copy = library_note_location_line(
            path, written, self._effective_pane_width(), attention=attention
        )
        if self._static_text(row) != copy:
            row.update(copy)

    @on(Resize)
    def _note_chrome_follows_width(self, event: Resize) -> None:
        """Re-decide the 80-column gate; the compact flag only flips at 120.

        Load-bearing for any resize that does not also cross 120 -- a
        breakpoint crossing re-runs ``apply_session_state``, which decides
        the gate anyway. Pinned by the 100 -> 79 -> 100 walk in
        ``test_the_strip_is_hidden_off_the_editor_and_below_eighty_columns``.

        task-32640's location row is re-stated on the same event, for the
        same reason: its path elision is width-dependent.
        """
        self.update_note_chrome_facts()
        self._restate_note_location()

    def _compose_create(self) -> ComposeResult:
        """Render the notes canvas in create mode: Blank note + template rows.

        Reached via the rail's Create > New note row (canvas kind
        ``"notes-create"``). The Blank note action and every template row
        are stacked, full-width, compact buttons styled like the list
        view's note rows (``library-notes-create-row`` copies the
        ``library-notes-row`` look) so the create view reads as more note
        rows rather than a distinct toolbar -- a *different* class on
        purpose: reusing ``library-notes-row`` itself would also match the
        list view's ``.library-notes-row`` press handler (selecting a note
        row and opening the editor for it), double-dispatching alongside
        this view's own create handlers on every press. Templates come
        from ``NOTE_TEMPLATES`` (imported locally to match the existing
        deferred-import convention used elsewhere for this module-level
        dict), sorted by key for a stable order; each row's
        ``template_key`` attribute (mirroring ``note_id`` on list rows) is
        read by the screen's press handler to resolve the template's
        fields via ``_library_note_template_fields`` -- this widget only
        needs the key and a human label, never the raw title/content.
        """
        with Horizontal(id="library-notes-create-heading"):
            # task-32177: this view's Back was also left out of task-32139's
            # unification and stayed hard-coded "‹ Notes" at every width.
            yield Button(
                _library_note_back_label(self.compact),
                id="library-notes-create-back",
                classes="library-canvas-action",
                compact=True,
                disabled=self.create_running,
            )
            yield Static(
                "New note",
                id="library-notes-create-header",
                classes="destination-section",
                markup=False,
            )
        with VerticalScroll(id="library-notes-create-viewport"):
            yield Button(
                "Blank note",
                id="library-notes-create-blank",
                classes="library-notes-create-row",
                compact=True,
                disabled=self.create_running,
            )
            # task-32356 (critique #10, A cap 10): the eight dated templates
            # used to stand open under Blank note, so every new note cost a
            # read of nine rows at the moment of lowest patience. They fold
            # behind one row now -- and ``ctrl+n``/``n`` skip this canvas
            # entirely for the blank answer (``action_library_notes_new``).
            yield Button(
                "From a template…",
                id="library-note-from-template",
                classes="library-notes-create-row",
                compact=True,
                disabled=self.create_running,
            )
            if self.templates_open:
                from tldw_chatbook.Event_Handlers.notes_events import NOTE_TEMPLATES

                # The pure builder excludes the "blank" template (it
                # duplicates the Blank note action above) and pre-resolves
                # each template's title so the row's muted secondary line
                # shows the exact title the created note will get (date
                # placeholders already substituted).
                rows = build_library_note_template_rows(NOTE_TEMPLATES)
                for index, row in enumerate(rows):
                    label = (
                        f"{row.label}\n{row.resolved_title}"
                        if row.resolved_title
                        else row.label
                    )
                    button = Button(
                        label,
                        id=f"library-notes-template-{index}",
                        classes="library-notes-create-row library-notes-template-row",
                        compact=True,
                    )
                    button.template_key = row.template_key
                    button.disabled = self.create_running
                    yield button
            yield Static(
                self.create_status,
                id="library-notes-create-status",
                markup=False,
            )
