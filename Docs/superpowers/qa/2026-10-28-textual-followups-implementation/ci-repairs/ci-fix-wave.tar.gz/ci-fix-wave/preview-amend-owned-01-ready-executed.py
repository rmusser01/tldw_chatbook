"""Exact before-source helper control; no production or worktree replacement."""
import hashlib
import json
import os
from pathlib import Path

import pytest


@pytest.fixture(autouse=True)
def exact_before_helper(monkeypatch):
    import Tests.UI.test_library_note_links_picker_and_preview_extended as case
    path=Path(__file__).with_name('before-library_note_links_support.py')
    source=path.read_bytes()
    assert hashlib.sha256(source).hexdigest() == 'b153b5720194669f9f73a8829988baab83851b2821c2b8a794d357072e2d736f'
    namespace={'__name__':'private_exact_3e_support','__file__':str(path)}
    exec(compile(source,str(path),'exec'),namespace)
    old_helper=os.environ.get('CI_USE_OLD_HELPER','1')=='1'
    if old_helper:
        monkeypatch.setattr(case,'_open_note',namespace['_open_note'])
    real_library=case._library
    async def ready_library(app,pilot):
        screen=await real_library(app,pilot)
        observations=[]
        def observe(kind):
            observations.append(dict(kind=kind,loaded=screen._library_loaded,error=screen._library_lookup_error,
                                     retry=[dict(id=b.id,label=str(b.label),region=str(b.region),display=b.display)
                                            for b in screen.query('#library-source-retry')]))
        await namespace['_until'](pilot,lambda: screen._library_loaded or screen._library_lookup_error is not None,
                                  'the actual source answer or recovery callout')
        observe('actual-source-answer')
        if screen._library_lookup_error is not None:
            await namespace['_until'](pilot,lambda: any(b.display and b.region.area for b in screen.query('#library-source-retry')),
                                      'the visible supported source Retry')
            button=next(b for b in screen.query('#library-source-retry') if b.display and b.region.area)
            observe('visible-source-retry-pressed-once')
            button.press()
            await namespace['_until'](pilot,lambda: screen._library_loaded and screen._library_lookup_error is None,
                                      'the real source Retry to succeed')
        observe('source-ready-before-original-index-open')
        await pilot.pause()
        Path(__file__).with_name('old-helper-source-recovery.json').write_text(json.dumps(observations,indent=2),encoding='utf-8')
        return screen
    monkeypatch.setattr(case,'_library',ready_library)
    Path(__file__).with_name('old-helper-baseline-source.json').write_text(
        json.dumps(dict(path=str(path),sha256=hashlib.sha256(source).hexdigest(),
                        override='extended._open_note -> exact before-source helper namespace' if old_helper
                        else 'none: actual current helper retained'),indent=2),encoding='utf-8')
    yield
