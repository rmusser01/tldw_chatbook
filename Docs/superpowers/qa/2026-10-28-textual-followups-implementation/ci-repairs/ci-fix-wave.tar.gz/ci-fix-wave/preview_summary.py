import hashlib
import json
from pathlib import Path

out=Path(__file__).parent
result={}
for label in ('old','new'):
    path=out/f'preview-{label}-helper-ready.trace.json'
    events=json.loads(path.read_text(encoding='utf-8'))
    keys=[row for row in events if row['kind']=='enter-message-before' and row['owner']=='VerticalScroll']
    first=keys[0]['t']
    result[label]=dict(trace_sha256=hashlib.sha256(path.read_bytes()).hexdigest(),
        first_enter=first,
        first_enter_publication=[row for row in events if first-.03 <= row['t'] <= first+.6],
        all_follow_actions=[row for row in events if row['kind'] in (
            'follow-check','action_library_note_preview_follow_link-before',
            '_open_library_note_link_target-before','_open_library_note_link_target-after')])
(out/'preview-comparison-summary.json').write_text(json.dumps(result,indent=2),encoding='utf-8')
print(json.dumps({label:dict(trace_sha256=data['trace_sha256'],first_enter=data['first_enter']) for label,data in result.items()},indent=2))
