"""Private native control: real folder answers held until independent DOM witness."""
import asyncio
import hashlib
import json
from pathlib import Path
import time

import pytest
from textual.widgets import Button

pytestmark = [pytest.mark.asyncio, pytest.mark.bootstrap_profile]
OUT = Path(__file__).parent


def pytest_collection_modifyitems(items):
    for item in items:
        item.obj = test_helper_waits_for_real_folder_publication


async def test_helper_waits_for_real_folder_publication(tmp_path, monkeypatch):
    from Tests.UI import library_note_links_support as support
    from Tests.UI.library_quit_guard_support import SIZE, _library, _new_blank_note, _type
    from tldw_chatbook.UI.Screens.library_screen import LibraryScreen

    app, profile = support._app(tmp_path)
    records = []
    held, release = asyncio.Event(), asyncio.Event()
    context = dict(active=False, returned=False, presses=0, delivered=0, watchdog=False)

    def emit(kind, screen=None, **extra):
        record = dict(t=time.monotonic(), kind=kind, **extra)
        if screen is not None:
            record.update(epoch=screen._notes_state.tree_topology_epoch,
                          view=screen._notes_state.view,
                          rows=[dict(obj=hex(id(b)), note=b.note_id, placement=b.placement_id,
                                     pruning=b._pruning, attached=b.is_attached,
                                     parent_active=b.is_parent_active)
                                for b in screen.query('.library-notes-tree-note-row')],
                          branches=[dict(key=str(k), loading=v.loading, freshness=v.freshness)
                                    for k,v in screen._notes_state.tree_branches.items()])
        records.append(record)

    real_page = LibraryScreen._apply_library_notes_tree_slice_page
    async def page(self, key, incoming, **kwargs):
        if context['active'] and key.parent_id is None and key.slice_kind == 'folders':
            emit('actual-folder-answer-held', self)
            held.set()
            try:
                await asyncio.wait_for(release.wait(), 10)
            except TimeoutError:
                context['watchdog'] = True
            finally:
                emit('actual-folder-answer-released', self)
        return await real_page(self, key, incoming, **kwargs)
    monkeypatch.setattr(LibraryScreen, '_apply_library_notes_tree_slice_page', page)

    real_notes = support._open_notes
    async def notes(screen, pilot, **kwargs):
        result = await real_notes(screen, pilot, **kwargs)
        if context['active']:
            context['returned'] = True
            emit('open_notes-returned', screen)
        return result
    monkeypatch.setattr(support, '_open_notes', notes)

    real_press = Button.press
    def press(self):
        if context['active'] and getattr(self, 'note_id', None) == profile.lisbon_id:
            context['presses'] += 1
            emit('target-row-press', self.screen)
        return real_press(self)
    monkeypatch.setattr(Button, 'press', press)

    real_load = LibraryScreen._begin_library_note_load
    def load(self, note_id, *args, **kwargs):
        if context['active'] and note_id == profile.lisbon_id:
            context['delivered'] += 1
            emit('target-load-began', self)
        return real_load(self, note_id, *args, **kwargs)
    monkeypatch.setattr(LibraryScreen, '_begin_library_note_load', load)
    emit('provenance', files=[dict(path=str(p), sha256=hashlib.sha256(p.read_bytes()).hexdigest())
                             for p in [Path(support.__file__), Path(__file__)]])
    try:
        async with app.run_test(size=SIZE) as pilot:
            screen = await _library(app, pilot)
            await _new_blank_note(screen, pilot)
            await pilot.click('#library-note-title')
            await support._until(pilot, lambda: screen.focused is screen.query_one('#library-note-title'), 'title focus')
            await _type(pilot, 'Publication probe')
            await support._until(pilot, lambda: support._title_value(screen) == 'Publication probe', 'typed title')
            context['active'] = True
            task = asyncio.create_task(support._open_note(screen, pilot, support.LISBON, profile.lisbon_id))
            try:
                await support._until(pilot, lambda: held.is_set(), 'the actual folder answer to be held')
                def placements_painted():
                    rows = list(screen.query('.library-notes-tree-note-row'))
                    canvases = list(screen.query('#library-notes-canvas, #library-note-work-pane'))
                    return (any(getattr(b, 'note_id', None) == profile.lisbon_id
                                and b.is_attached and not b._pruning for b in rows)
                            and len(canvases) == 2
                            and all(not c.recompose_in_flight and not c._recompose_required for c in canvases))
                await support._until(pilot, placements_painted, 'placements to publish before the folder answer')
                await pilot.pause()
                emit('independent-placements-publication-witness', screen, **context)
                assert not context['watchdog'], 'hold watchdog expired: missing independent witness'
                assert not context['returned'], 'old helper returned before the held folder publication'
                assert context['presses'] == 0, 'a target row was pressed before the held folder publication'
                assert not task.done(), 'open helper must remain pending while the real folder answer is held'
            finally:
                release.set()
                await task
                emit('all-holds-drained-inside-app', screen, **context)
            assert not context['watchdog']
            assert context['returned']
            assert context['presses'] == context['delivered'] == 1
            assert screen._library_note_session.snapshot.note_id == profile.lisbon_id
            assert screen.query_one('#library-note-body').text == 'itinerary'
            context['active'] = False
            await support._open_notes(screen, pilot)
            current_epoch = screen._notes_state.tree_topology_epoch
            emit('already-list-consumer-before', screen)
            await support._open_note(screen, pilot, support.INDEX, profile.index_id)
            emit('already-list-consumer-after', screen, prior_epoch=current_epoch)
            assert screen._library_note_session.snapshot.note_id == profile.index_id
    finally:
        (OUT/'held-publication.trace.json').write_text(json.dumps(records,indent=2),encoding='utf-8')
