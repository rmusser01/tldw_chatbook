import hashlib
import json
from pathlib import Path
import xml.etree.ElementTree as ET

out=Path(__file__).parent
runs=[]
for folder in sorted(out.iterdir()):
    if not folder.is_dir() or not (folder/'result.xml').exists(): continue
    xml=folder/'result.xml'
    tree=ET.parse(xml)
    cases=[]
    for case in tree.iter('testcase'):
        error=case.find('failure')
        if error is None: error=case.find('error')
        cases.append(dict(name=case.attrib.get('name'),time=case.attrib.get('time'),
                          status='failed' if case.find('failure') is not None else 'error' if case.find('error') is not None
                          else 'skipped' if case.find('skipped') is not None else 'passed',
                          message=None if error is None else error.attrib.get('message')))
    runs.append(dict(run=folder.name,xml_sha256=hashlib.sha256(xml.read_bytes()).hexdigest(),cases=cases,
                     command=json.loads((folder/'command.json').read_text(encoding='utf-8')),
                     verification=json.loads((folder/'verification.json').read_text(encoding='utf-8'))
                     if (folder/'verification.json').exists() else None))
files=[p for p in out.iterdir() if p.is_file() and p.suffix in {'.py','.json'}
       and p.name not in {'evidence-receipt.json','receipt-summary.json'}]
sources=[Path('Tests/UI')/name for name in ('library_note_links_support.py','test_library_media_reader_controls_in_list_view.py','test_library_note_links_picker_and_preview.py')]
sources += [Path(name) for name in ('Tests/UI/library_quit_guard_support.py','Tests/UI/test_library_shell.py',
            'Tests/UI/test_library_note_links_preview_opens_in_app.py','Tests/UI/test_library_note_links_picker_and_preview_extended.py',
            'tldw_chatbook/UI/Screens/library_screen.py','tldw_chatbook/UI/Library_Modules/library_notes_controller.py',
            'tldw_chatbook/UI/Library_Modules/library_media_controller.py','tldw_chatbook/Widgets/Library/library_notes_canvas.py')]
proof=dict(runs=runs,artifacts=[dict(path=str(p),sha256=hashlib.sha256(p.read_bytes()).hexdigest()) for p in files],
           sources=[dict(path=str(p),sha256=hashlib.sha256(p.read_bytes()).hexdigest()) for p in sources])
(out/'evidence-receipt.json').write_text(json.dumps(proof,indent=2),encoding='utf-8')
print(json.dumps(dict(runs=[dict(run=r['run'],cases=r['cases'],xml_sha256=r['xml_sha256']) for r in runs],sources=proof['sources']),indent=2))
