"""Native Preview-publication boundary: defer a real queued recompose callback."""
import asyncio
import hashlib
import json
import os
from pathlib import Path
import time

import pytest

OUT=Path(__file__).parent


def pytest_collection_modifyitems(items):
    for item in items: item.obj=test_held_preview_publication


async def test_held_preview_publication(tmp_path,monkeypatch):
    from textual.widget import Widget
    from Tests.UI import library_note_links_support as support
    from Tests.UI.library_quit_guard_support import SIZE,_library,_new_blank_note,_type
    mode=os.environ.get('PREVIEW_HOLD_MODE','old')
    app,profile=support._app(tmp_path)
    held,release,published=asyncio.Event(),asyncio.Event(),asyncio.Event()
    context=dict(active=False,returned=False,injected=False,watchdog=False)
    records=[]
    def emit(kind,screen,**extra):
        records.append(dict(t=time.monotonic(),kind=kind,**extra,
            focus=repr(screen.focused),
            canvases=[dict(id=c.id,pending=c._recompose_required,inflight=c.recompose_in_flight)
                      for c in screen.query('#library-notes-canvas, #library-note-work-pane')],
            region=[dict(obj=hex(id(c)),attached=c.is_attached,pruning=c._pruning)
                    for c in screen.query('#library-note-preview-region')]))
    real_check=Widget._check_recompose
    deferred=[]
    async def check(self):
        if (context['active'] and self.id=='library-note-work-pane'
                and self._recompose_required and not release.is_set()):
            if not held.is_set():
                held.set()
                emit('native-pending-preview-publication-held',self.screen)
                async def resume():
                    try: await asyncio.wait_for(release.wait(),5)
                    except TimeoutError: context['watchdog']=True
                    async def complete():
                        try:
                            emit('real-native-publication-resumed',self.screen)
                            await real_check(self)
                        finally:
                            published.set()
                            emit('real-native-publication-completed',self.screen)
                    self.call_next(complete)
                deferred.append(asyncio.create_task(resume()))
            # Leave the native refresh's actual pending mark intact. Holding
            # its callback here keeps App message/layout turns available.
            return
        return await real_check(self)
    monkeypatch.setattr(Widget,'_check_recompose',check)
    real_paint=support._until_painted
    async def painted(app,screen,pilot,selector,needle,**kwargs):
        await real_paint(app,screen,pilot,selector,needle,**kwargs)
        if context['active'] and selector=='#library-note-preview-body' and not context['injected']:
            context['injected']=True
            work=screen.query_one('#library-note-work-pane')
            emit('actual-preview-painted-before-refresh',screen,
                 painted=support._painted(app,screen,selector))
            # Exercise the same native publication path used by sync_state;
            # no data/flag assignment or service/getter substitution.
            work.refresh(recompose=True)
    monkeypatch.setattr(support,'_until_painted',painted)
    records.append(dict(kind='provenance',mode=mode,files=[dict(path=str(p),sha256=hashlib.sha256(p.read_bytes()).hexdigest())
        for p in (Path(support.__file__),Path(__file__))]))
    try:
        async with app.run_test(size=SIZE) as pilot:
            screen=await _library(app,pilot)
            await support._until(pilot,lambda: screen._library_loaded or screen._library_lookup_error is not None,'actual source answer')
            if screen._library_lookup_error is not None:
                await support._until(pilot,lambda: any(b.display and b.region.area for b in screen.query('#library-source-retry')),'visible source Retry')
                next(b for b in screen.query('#library-source-retry') if b.display and b.region.area).press()
                await support._until(pilot,lambda: screen._library_loaded and screen._library_lookup_error is None,'source Retry result')
            await _new_blank_note(screen,pilot)
            await pilot.click('#library-note-title')
            await support._until(pilot,lambda: screen.focused is screen.query_one('#library-note-title'),'native title focus')
            await _type(pilot,'Probe')
            await support._until(pilot,lambda: support._title_value(screen)=='Probe','native title preparation')
            await support._open_note(screen,pilot,support.INDEX,profile.index_id)
            context['active']=True
            async def preview():
                await support._preview(screen,pilot,support.LISBON,app)
                context['returned']=True
                emit('preview-helper-returned',screen)
            task=asyncio.create_task(preview())
            try:
                await support._until(pilot,held.is_set,'native pending Preview publication hold')
                if mode=='old':
                    await support._until(pilot,lambda: context['returned'],'old Preview helper to reach its return boundary')
                else:
                    await pilot.pause()
                emit('independent-native-boundary-witness',screen,**context,
                     painted=support._painted(app,screen,'#library-note-preview-body'))
                assert not context['watchdog'],'held-publication watchdog expired'
                assert not context['returned'],'Preview helper returned before native pending publication'
            finally:
                release.set()
                await support._until(pilot,published.is_set,'held native publication to complete inside App')
                await task
                for deferred_task in deferred: await deferred_task
                emit('all-preview-holds-drained-inside-app',screen,**context)
            assert context['returned'] and not context['watchdog']
            assert support.LISBON in support._painted(app,screen,'#library-note-preview-body')
            region=screen.query_one('#library-note-preview-region')
            assert region.is_attached and not region._pruning and screen.focused is region
            await pilot.press('enter')
            await support._armed_editor(screen,pilot,profile.lisbon_id)
            assert support._title_value(screen)==support.LISBON
    finally:
        (OUT/('held-preview-'+mode+'.trace.json')).write_text(json.dumps(records,indent=2),encoding='utf-8')
