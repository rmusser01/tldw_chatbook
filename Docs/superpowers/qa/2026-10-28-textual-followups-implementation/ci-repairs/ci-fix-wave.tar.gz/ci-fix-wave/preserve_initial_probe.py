"""Recover the invalid first held-run plugin version; verify its recorded digest."""
import hashlib
from pathlib import Path

out=Path(__file__).parent
text=(out/'wave_probe.py').read_text(encoding='utf-8')
text=text.replace("    wrong_write = dict(armed=False)\n",'')
text=text.replace("        if mode == 'wrongreader' and self.id == 'library-media-edit-save':\n            wrong_write['armed'] = True\n            emit('negative-mutation-armed-at-original-save-press')\n",'')
text=text.replace('real_save = LibraryScreen.handle_library_media_edit_save',
                  'real_save = LibraryMediaController.handle_library_media_edit_save')
start=text.index('        real_target = LibraryMediaController._library_media_reader_target_id')
end=text.index("\n\n    paths=",start)
text=text[:start]+"        monkeypatch.setattr(LibraryMediaController,'_reader_action_target',lambda self: 'local:media:2')"+text[end:]
payload=text.encode('utf-8')
digest=hashlib.sha256(payload).hexdigest()
print(digest)
assert digest=='dd08cee9b90d94bf4cd0ef3915672cca01ea4bf98fbc2342d5da4cfb333e8297'
(out/'held-full-new-01-probe-recovered.py').write_bytes(payload)
