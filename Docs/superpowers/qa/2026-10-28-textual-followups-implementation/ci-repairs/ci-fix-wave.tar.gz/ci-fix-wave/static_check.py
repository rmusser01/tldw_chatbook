import ast
import hashlib
import json
from pathlib import Path
import re
import subprocess
import sys

out = Path(__file__).parent
names = ['library_note_links_support.py', 'test_library_media_reader_controls_in_list_view.py',
         'test_library_note_links_picker_and_preview.py']

def run(args):
    p = subprocess.run(args, capture_output=True, encoding='utf-8', errors='replace')
    return dict(args=args, code=p.returncode, stdout=p.stdout, stderr=p.stderr)

if sys.argv[1] == 'baseline':
    results=[]
    for name in names:
        path=out/('before-'+name)
        results.append(dict(name=name, sha256=hashlib.sha256(path.read_bytes()).hexdigest(),
                            lint=run([sys.executable,'-m','ruff','check','--no-cache',str(path)]),
                            format=run([sys.executable,'-m','ruff','format','--no-cache','--diff',str(path)])))
    (out/'static-baseline.json').write_text(json.dumps(results,indent=2),encoding='utf-8')
    print(json.dumps(results,indent=2))
else:
    allowed = {'library_note_links_support.py': {'_open_note','_open_notes','_preview'},
               'test_library_media_reader_controls_in_list_view.py': {'_query_settled','test_a_dirty_form_filtered_off_the_page_saves_to_the_reader_item_after_trash_back'},
               'test_library_note_links_picker_and_preview.py': {'_blank_note_with_body_focused'}}
    results=[]
    for name in names:
        before=ast.parse((out/('before-'+name)).read_text(encoding='utf-8'))
        path=Path('Tests/UI')/name
        after=ast.parse(path.read_text(encoding='utf-8'))
        old={n.name:n for n in before.body if isinstance(n,(ast.FunctionDef,ast.AsyncFunctionDef,ast.ClassDef))}
        new={n.name:n for n in after.body if isinstance(n,(ast.FunctionDef,ast.AsyncFunctionDef,ast.ClassDef))}
        unchanged={key:ast.dump(node)==ast.dump(new[key]) for key,node in old.items() if key not in allowed[name]}
        tails={}
        if name.startswith('test_library_media'):
            target='test_a_dirty_form_filtered_off_the_page_saves_to_the_reader_item_after_trash_back'
            def tail(node):
                body=node.body[-1].body
                i=next(i for i,n in enumerate(body) if isinstance(n,ast.Expr) and isinstance(n.value,ast.Await)
                       and getattr(getattr(n.value.value,'func',None),'id',None)=='_browse_settled')
                return [ast.dump(n) for n in body[i+1:]]
            tails['all_post_browse_statements_identical']=tail(old[target])==tail(new[target])
        if name=='test_library_note_links_picker_and_preview.py':
            target='_blank_note_with_body_focused'
            def tail(node):
                i=next(i for i,n in enumerate(node.body) if isinstance(n,ast.Expr) and isinstance(n.value,ast.Await)
                       and getattr(getattr(n.value.value,'func',None),'id',None)=='_type')
                return [ast.dump(n) for n in node.body[i:]]
            tails['title_typing_and_all_following_statements_identical']=tail(old[target])==tail(new[target])
        results.append(dict(name=name,sha256=hashlib.sha256(path.read_bytes()).hexdigest(),unchanged_owners=unchanged,
                            tails=tails,lint=run([sys.executable,'-m','ruff','check','--no-cache',str(path)]),
                            format=run([sys.executable,'-m','ruff','format','--no-cache','--diff',str(path)])))
    baseline=json.loads((out/'static-baseline.json').read_text(encoding='utf-8'))
    def format_debt(diff):
        return [line for line in diff.splitlines()[2:] if not line.startswith('@@')]
    for result, old in zip(results, baseline):
        result['baseline_format_debt_conserved'] = format_debt(result['format']['stdout']) == format_debt(old['format']['stdout'])
    phase_one=ast.parse((out/'before-preview-amendment-support.py').read_text(encoding='utf-8'))
    current=ast.parse(Path('Tests/UI/library_note_links_support.py').read_text(encoding='utf-8'))
    def owners(tree):
        return {n.name:ast.dump(n) for n in tree.body if isinstance(n,(ast.FunctionDef,ast.AsyncFunctionDef))}
    a,b=owners(phase_one),owners(current)
    shared_publication_unchanged={name:a[name]==b[name] for name in ('_notes_tree_publication','_open_notes','_open_note')}
    proof=dict(files=results,phase_one_shared_publication_unchanged=shared_publication_unchanged)
    (out/'static-after.json').write_text(json.dumps(proof,indent=2),encoding='utf-8')
    print(json.dumps(proof,indent=2))
    assert all(all(r['unchanged_owners'].values()) and all(r['tails'].values())
               and r['lint']['code']==0 and r['baseline_format_debt_conserved'] for r in results)
    assert all(shared_publication_unchanged.values())
