"""Observation-only distinction between initial route loss and mount gaps."""
import hashlib
import inspect
import json
from pathlib import Path
import time

import pytest

OUT=Path(__file__).parent


@pytest.fixture(autouse=True)
def title_trace(monkeypatch,request):
    from textual.widgets import Input
    import Tests.UI.test_library_note_links_picker_and_preview as case
    rows=[]

    def emit(kind,screen,control=None,**extra):
        state=screen._notes_state
        rows.append(dict(t=time.monotonic(),kind=kind,route=screen._library_selected_row_id,
                         view=state.view,app_screen=type(screen.app.screen).__name__,focus=repr(screen.focused),
                         title_nodes=[dict(obj=hex(id(c)),value=c.value,attached=c.is_attached,
                                           pruning=c._pruning,parent_active=c.is_parent_active)
                                      for c in screen.query('#library-note-title')],
                         canvases=[dict(id=c.id,pending=c._recompose_required,inflight=c.recompose_in_flight)
                                   for c in screen.query('#library-notes-canvas, #library-note-work-pane')],
                         control=None if control is None else hex(id(control)),**extra))
    original=case._type
    async def typed(pilot,text):
        if text!=case.VERIFIER: return await original(pilot,text)
        screen=pilot.app.screen
        emit('title-type-before',screen)
        try: return await original(pilot,text)
        finally: emit('title-type-after',screen)
    monkeypatch.setattr(case,'_type',typed)
    for name in ('_on_key','_on_focus'):
        real=getattr(Input,name)
        def make(real,name):
            if inspect.iscoroutinefunction(real):
                async def observed(self,*args,**kwargs):
                    active=self.id=='library-note-title'
                    if active: emit(name+'-before',self.screen,self,event=repr(args))
                    try: return await real(self,*args,**kwargs)
                    finally:
                        if active: emit(name+'-after',self.screen,self,event=repr(args))
            else:
                def observed(self,*args,**kwargs):
                    active=self.id=='library-note-title'
                    if active: emit(name+'-before',self.screen,self,event=repr(args))
                    try: return real(self,*args,**kwargs)
                    finally:
                        if active: emit(name+'-after',self.screen,self,event=repr(args))
            return observed
        monkeypatch.setattr(Input,name,make(real,name))
    rows.append(dict(kind='provenance',sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest()))
    yield
    (OUT/('title-'+request.node.name+'.trace.json')).write_text(json.dumps(rows,indent=2),encoding='utf-8')
