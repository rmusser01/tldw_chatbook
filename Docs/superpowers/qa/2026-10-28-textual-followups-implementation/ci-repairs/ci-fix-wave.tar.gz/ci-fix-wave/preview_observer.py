"""Observe real Enter delivery, gates and publication without altering them."""
import inspect
import json
from pathlib import Path
import time

import pytest


@pytest.fixture(autouse=True)
def preview_observations(monkeypatch,request):
    from textual import events
    from textual.message_pump import MessagePump
    from textual.widgets import Button
    from tldw_chatbook.UI.Screens.library_screen import LibraryScreen
    from tldw_chatbook.UI.Library_Modules.library_notes_controller import LibraryNotesController
    from tldw_chatbook.Widgets.Library.library_notes_canvas import LibraryNotesCanvas
    rows=[]
    def emit(kind,obj,**extra):
        row=dict(t=time.monotonic(),kind=kind,owner=type(obj).__name__,owner_id=getattr(obj,'id',None),**extra)
        try:
            screen=obj if isinstance(obj,LibraryScreen) else (obj._screen if isinstance(obj,LibraryNotesController) else obj.screen)
            snapshot=screen._library_note_session.snapshot
            row.update(route=screen._library_selected_row_id,view=screen._notes_state.view,
                       focus=repr(screen.focused),focus_obj=hex(id(screen.focused)),
                       epoch=screen._notes_state.tree_topology_epoch,
                       snapshot=None if snapshot is None else snapshot.note_id,
                       canvases=[dict(id=c.id,pending=c._recompose_required,inflight=c.recompose_in_flight)
                                 for c in screen.query('#library-notes-canvas, #library-note-work-pane')],
                       regions=[dict(obj=hex(id(w)),attached=w.is_attached,pruning=w._pruning,parent_active=w.is_parent_active)
                                for w in screen.query('#library-note-preview-region')])
        except Exception as exc: row['observation_error']=repr(exc)
        rows.append(row)
    real_message=MessagePump._on_message
    async def message(self,event):
        active=isinstance(event,events.Key) and event.key=='enter'
        if active: emit('enter-message-before',self)
        try: return await real_message(self,event)
        finally:
            if active: emit('enter-message-after',self)
    monkeypatch.setattr(MessagePump,'_on_message',message)
    real_check=LibraryScreen.check_action
    def check(self,action,parameters):
        result=real_check(self,action,parameters)
        if action=='library_note_preview_follow_link': emit('follow-check',self,result=result)
        return result
    monkeypatch.setattr(LibraryScreen,'check_action',check)
    for cls,name in [(LibraryScreen,'action_library_note_preview_follow_link'),
                     (LibraryNotesController,'_open_library_note_link_target'),
                     (LibraryNotesCanvas,'recompose')]:
        original=getattr(cls,name)
        def wrap(original,name):
            async def observed(self,*args,**kwargs):
                emit(name+'-before',self,args=repr(args))
                try: return await original(self,*args,**kwargs)
                finally: emit(name+'-after',self)
            return observed
        monkeypatch.setattr(cls,name,wrap(original,name))
    real_press=Button.press
    def press(self):
        if self.id in {'library-note-preview','library-row-browse-notes'}: emit('button-press',self)
        return real_press(self)
    monkeypatch.setattr(Button,'press',press)
    yield
    Path(__file__).with_name('preview-'+request.node.name+'.trace.json').write_text(json.dumps(rows,indent=2),encoding='utf-8')
