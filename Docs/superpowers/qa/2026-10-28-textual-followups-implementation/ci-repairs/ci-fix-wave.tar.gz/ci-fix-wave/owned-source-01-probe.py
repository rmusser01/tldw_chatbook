"""Read-only receipts; held-answer and wrong-write modes are explicit controls."""
import asyncio
import hashlib
import json
import os
from pathlib import Path
import time

import pytest

OUT = Path(__file__).parent


@pytest.fixture(autouse=True)
def wave_observations(monkeypatch, request):
    from textual.widgets import Button
    from tldw_chatbook.UI.Screens.library_screen import LibraryScreen
    from tldw_chatbook.UI.Library_Modules.library_media_controller import LibraryMediaController
    import Tests.UI.library_note_links_support as support
    import Tests.UI.test_library_note_links_picker_and_preview as case

    mode = os.environ.get('CI_FIX_MODE', 'observe')
    records = []
    active = dict(on=False, target=None, notes_returned=False, presses=0, delivered=0, watchdog=False)
    wrong_write = dict(armed=False)
    held, release = asyncio.Event(), asyncio.Event()

    def emit(kind, screen=None, **extra):
        record = dict(t=time.monotonic(), kind=kind, **extra)
        if screen is not None:
            state = screen._notes_state
            record.update(epoch=state.tree_topology_epoch, view=state.view,
                          route=screen._library_selected_row_id,
                          navigation=screen._library_navigation_context_generation,
                          selected=state.selected_note_id,
                          branches=[dict(key=str(k), generation=v.generation, loading=v.loading,
                                         epoch=v.topology_epoch, freshness=v.freshness) for k,v in state.tree_branches.items()],
                          rows=[dict(obj=hex(id(b)), placement=b.placement_id,note=b.note_id,
                                     attached=b.is_attached,pruning=b._pruning,parent_active=b.is_parent_active)
                                for b in screen.query('.library-notes-tree-note-row')],
                          canvases=[dict(id=c.id, obj=hex(id(c)), pending=c._recompose_required,
                                         inflight=c.recompose_in_flight, attached=c.is_attached,pruning=c._pruning)
                                    for c in screen.query('#library-notes-canvas, #library-note-work-pane')])
        records.append(record)

    real_notes = support._open_notes
    async def notes(screen, pilot, **kwargs):
        emit('open_notes-before',screen)
        result = await real_notes(screen,pilot,**kwargs)
        if active['on']: active['notes_returned'] = True
        emit('open_notes-after',screen)
        return result
    monkeypatch.setattr(support,'_open_notes',notes)
    real_press = Button.press
    def press(self):
        if mode == 'wrongreader' and self.id == 'library-media-edit-save':
            wrong_write['armed'] = True
            emit('negative-mutation-armed-at-original-save-press')
        if getattr(self,'note_id',None):
            emit('note-row-press',self.screen,note=self.note_id,obj=hex(id(self)))
            if active['on'] and self.note_id == active['target']: active['presses'] += 1
        return real_press(self)
    monkeypatch.setattr(Button,'press',press)
    real_load = LibraryScreen._begin_library_note_load
    def load(self,note_id,*args,**kwargs):
        emit('note-load-began',self,note=note_id)
        if active['on'] and note_id == active['target']: active['delivered'] += 1
        return real_load(self,note_id,*args,**kwargs)
    monkeypatch.setattr(LibraryScreen,'_begin_library_note_load',load)

    if mode == 'held':
        real_page = LibraryScreen._apply_library_notes_tree_slice_page
        async def page(self,key,incoming,**kwargs):
            if active['on'] and key.parent_id is None and key.slice_kind == 'folders':
                emit('actual-folder-answer-held',self)
                held.set()
                try: await asyncio.wait_for(release.wait(),10)
                except TimeoutError: active['watchdog'] = True
                finally: emit('actual-folder-answer-released',self)
            return await real_page(self,key,incoming,**kwargs)
        monkeypatch.setattr(LibraryScreen,'_apply_library_notes_tree_slice_page',page)
        real_open = case._open_note
        async def open_note(screen,pilot,title,note_id):
            if title != case.NAVIGATION: return await real_open(screen,pilot,title,note_id)
            active.update(on=True,target=note_id)
            async def independent_witness():
                try:
                    async with asyncio.timeout(10):
                        await held.wait()
                        while True:
                            rows=list(screen.query('.library-notes-tree-note-row'))
                            canvases=list(screen.query('#library-notes-canvas, #library-note-work-pane'))
                            if (any(b.note_id==note_id and b.is_attached and not b._pruning for b in rows)
                                    and len(canvases)==2 and all(not c._recompose_required and not c.recompose_in_flight for c in canvases)):
                                break
                            await asyncio.sleep(.02)
                        # Independent native message/layout turn witnesses the
                        # placements publication, not the target press we forbid.
                        await pilot.pause()
                        emit('independent-publication-witness',screen,**active)
                        assert not active['watchdog'], 'hold watchdog expired'
                        assert not active['notes_returned'], 'helper returned before folder publication'
                        assert active['presses']==0, 'row pressed before folder publication'
                finally: release.set()
            witness=asyncio.create_task(independent_witness())
            try:
                result=await real_open(screen,pilot,title,note_id)
                await witness
                assert active['presses']==active['delivered']==1
                emit('target-delivered-after-publication',screen,**active)
                return result
            finally:
                release.set()
                await witness
                active['on']=False
                emit('all-holds-drained-inside-app',screen)
        monkeypatch.setattr(case,'_open_note',open_note)

    if mode == 'wrongreader':
        real_save = LibraryScreen.handle_library_media_edit_save
        # Deliberate NEGATIVE ORACLE MUTATION ONLY: route the actual Save
        # write at item 2 after the correct Reader item 1 setup.
        import inspect
        emit('negative-mutation-source',source=inspect.getsource(real_save))
        # The mutation is installed below at the action-target method, preserving
        # the real service/write recorder and the original write-ID assertion.
        real_target = LibraryMediaController._library_media_reader_target_id
        def wrong_target(self):
            result = real_target(self)
            if wrong_write['armed']:
                emit('negative-wrong-target',original=result,mutated='local:media:2')
                return 'local:media:2'
            return result
        monkeypatch.setattr(LibraryMediaController,'_library_media_reader_target_id',wrong_target)

    paths=[Path(support.__file__),Path(case.__file__),Path('Tests/UI/test_library_media_reader_controls_in_list_view.py'),
           Path('tldw_chatbook/UI/Screens/library_screen.py'),Path('tldw_chatbook/UI/Library_Modules/library_notes_controller.py'),
           Path('tldw_chatbook/UI/Library_Modules/library_media_controller.py'),Path(__file__)]
    emit('provenance',mode=mode,files=[dict(path=str(p.resolve()),sha256=hashlib.sha256(p.read_bytes()).hexdigest()) for p in paths])
    yield
    (OUT/(mode+'-'+request.node.name+'.trace.json')).write_text(json.dumps(records,indent=2),encoding='utf-8')
