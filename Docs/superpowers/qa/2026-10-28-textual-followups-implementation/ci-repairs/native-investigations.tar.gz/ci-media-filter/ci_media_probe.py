"""Observation-only native filter trace; loaded solely by bounded investigation."""
import functools
import ast
import hashlib
import inspect
import json
import os
from pathlib import Path
import time

import pytest

OUT = Path(__file__).parent


def pytest_collection_modifyitems(items):
    if os.environ.get('MEDIA_PROBE_MODE') != 'fullpaste':
        return
    from textual.events import Paste
    for item in items:
        original=item.obj
        tree=ast.parse(inspect.getsource(original))
        function=tree.body[0]
        body=function.body[-1].body  # Existing async-with App body.
        start=next(i for i,node in enumerate(body) if isinstance(node,ast.Expr)
                   and isinstance(node.value,ast.Await)
                   and isinstance(node.value.value,ast.Call)
                   and getattr(node.value.value.func,'id','')=='_focus_filter_box')
        end=next(i for i in range(start,len(body)) if isinstance(body[i],ast.Expr)
                 and isinstance(body[i].value,ast.Await)
                 and isinstance(body[i].value.value,ast.Call)
                 and getattr(body[i].value.value.func,'id','')=='_browse_settled')
        setup=ast.parse('''async def setup():
    await _focus_filter_box(screen, pilot)
    pilot.app.post_message(NativePaste("Product"))
    await _browse_settled(screen, pilot, query="Product", rows=1)
''').body[0].body
        body[start:end+1]=setup
        ast.fix_missing_locations(tree)
        source=ast.unparse(tree)
        path=OUT/'fullpaste-probe-function.py'
        path.write_text(source+'\n',encoding='utf-8')
        namespace=dict(original.__globals__,NativePaste=Paste)
        exec(compile(tree,str(path),'exec'),namespace)
        item.obj=namespace[original.__name__]


@pytest.fixture(autouse=True)
def filter_trace(monkeypatch, request):
    from textual.widgets import Input
    from tldw_chatbook.Widgets.Library.library_media_canvas import LibraryMediaCanvas
    from tldw_chatbook.UI.Library_Modules.library_media_controller import LibraryMediaController
    import Tests.UI.test_library_media_reader_controls_in_list_view as case

    records = []
    mode=os.environ.get('MEDIA_PROBE_MODE','exact')
    def emit(kind, obj=None, **extra):
        row = dict(t=time.monotonic(), kind=kind, **extra)
        if obj is not None:
            row.update(obj=hex(id(obj)), value=getattr(obj, 'value', None),
                       selection=str(getattr(obj, 'selection', None)),
                       attached=getattr(obj, 'is_attached', None))
            try:
                screen=obj.screen
                row['focus']=repr(screen.focused)
                row['focus_obj']=hex(id(screen.focused))
                ctrl=screen._library_media_browse_controller
                row['requested']=repr(ctrl.requested_scope)
                row['applied']=repr(ctrl.applied_scope)
                row['loading']=ctrl.loading
            except Exception:
                pass
        records.append(row)
    def wrap(cls, name, key=False):
        original=getattr(cls,name)
        if inspect.iscoroutinefunction(original):
            @functools.wraps(original)
            async def traced(self,*args,**kwargs):
                active=not key or self.id=='library-media-filter'
                if active: emit(name+':before',self,event=repr(args[0]) if args else None)
                try: return await original(self,*args,**kwargs)
                finally:
                    if active: emit(name+':after',self)
        else:
            @functools.wraps(original)
            def traced(self,*args,**kwargs):
                active=not key or self.id=='library-media-filter'
                if active: emit(name+':before',self,args=repr(args),kwargs=repr(kwargs))
                try: return original(self,*args,**kwargs)
                finally:
                    if active: emit(name+':after',self)
        monkeypatch.setattr(cls,name,traced)
    for name in ('_on_key','_on_focus','_on_paste'):
        wrap(Input,name,key=True)
    for name in ('recompose','sync_state','handle_library_media_filter_changed'):
        wrap(LibraryMediaCanvas,name)
    for name in ('handle_library_media_filter_changed','_request_library_media_filter'):
        wrap(LibraryMediaController,name)
    original_type=case._type
    if mode in ('paced','paste'):
        async def gesture(pilot,text):
            if text != 'roduct':
                return await original_type(pilot,text)
            emit('probe-gesture',mode=mode,text=text)
            if mode=='paste':
                from textual.events import Paste
                pilot.app.post_message(Paste(text))
                await pilot.pause()
            else:
                for char in text:
                    await pilot.press(char)
                    # Deliberately spaced user keys expose the natural debounce
                    # and native recompose/focus without changing product timing.
                    await pilot.pause(1.2)
        monkeypatch.setattr(case,'_type',gesture)
    files=[Path(inspect.getfile(cls)) for cls in (Input,LibraryMediaCanvas,LibraryMediaController)]
    records.append(dict(kind='provenance',files=[dict(path=str(p),sha256=hashlib.sha256(p.read_bytes()).hexdigest()) for p in files]))
    yield
    (OUT/(mode+'.trace.json')).write_text(json.dumps(records,indent=2,default=str),encoding='utf-8')
