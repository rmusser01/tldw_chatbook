async def test_a_dirty_form_filtered_off_the_page_saves_to_the_reader_item_after_trash_back(monkeypatch):
    """Route 1: the dirty form is pinned to item 1 through the filter and the
    Trash round trip; in the list view the selection keeps naming item 1
    (no row wears the cue: item 1 is off the page) and Save writes item 1,
    with no toast. Before the fix the adopt seam moved the selection to row
    0 in the list view and Save wrote ``{'media_id': 2, ...}``."""
    host, app, service = _host()
    toasts = _record_toasts(monkeypatch, app)
    async with host.run_test(size=SIZE) as pilot:
        screen = _active_library_screen(host)
        await _wait_for_library_shell(screen, pilot)
        await _open_row_1(screen, pilot)
        await _open_edit_form(screen, pilot)
        await pilot.press('end')
        await pilot.press('exclamation_mark')
        await _wait_for_condition(pilot, lambda: screen.query_one('#library-media-edit-title', Input).value == f'{ITEM_1_TITLE}!', message='typed char never landed')
        await _focus_filter_box(screen, pilot)
        pilot.app.post_message(NativePaste('Product'))
        await _browse_settled(screen, pilot, query='Product', rows=1)
        assert [str(row.media_id) for row in _rows(screen)] == [ROW_0]
        await _trash_round_trip(screen, pilot)
        assert screen._media_state.selected_media_id == ROW_1
        assert _highlighted(screen) == []
        assert screen._media_state.editing is True
        assert screen.query_one('#library-media-edit-title', Input).value == f'{ITEM_1_TITLE}!'
        screen.query_one('#library-media-edit-save', Button).press()
        await _wait_for_condition(pilot, lambda: bool(service.update_calls), message='Save never wrote')
        for _ in range(6):
            await pilot.pause()
        assert [call['media_id'] for call in service.update_calls] == [ITEM_1], service.update_calls
        assert service.update_calls[-1]['title'] == f'{ITEM_1_TITLE}!'
        assert toasts == [], toasts
