import ast
import hashlib
import json
from pathlib import Path
import xml.etree.ElementTree as ET

root=Path.cwd()
out=root/'.test-tmp/textual-37266-37268/ci-media-filter'
source_paths=[
    'Tests/UI/test_library_media_reader_controls_in_list_view.py',
    'Tests/UI/test_library_media_editor_dirty_escape.py',
    'Tests/UI/test_library_media_editor_dirty_escape_extended.py',
    'tldw_chatbook/UI/Library_Modules/library_media_controller.py',
    'tldw_chatbook/UI/Screens/library_screen.py',
    'tldw_chatbook/Widgets/Library/library_media_canvas.py',
]
receipt=dict(sources=[dict(path=p,sha256=hashlib.sha256((root/p).read_bytes()).hexdigest()) for p in source_paths])
receipt['runs']=[]
for label in ('exact-native-01','paced-native-01','fullpaste-native-01'):
    path=out/label/'result.xml'
    cases=list(ET.parse(path).iter('testcase'))
    receipt['runs'].append(dict(label=label,xml_sha256=hashlib.sha256(path.read_bytes()).hexdigest(),cases=len(cases),failures=sum(c.find('failure') is not None for c in cases),errors=sum(c.find('error') is not None for c in cases),skips=sum(c.find('skipped') is not None for c in cases)))
original=ast.parse((root/source_paths[0]).read_text(encoding='utf-8'))
original_fn=next(n for n in original.body if isinstance(n,ast.AsyncFunctionDef) and n.name.startswith('test_a_dirty_form_filtered'))
probe_fn=ast.parse((out/'fullpaste-probe-function.py').read_text(encoding='utf-8')).body[0]
def after_filter(fn):
    body=fn.body[-1].body
    index=next(i for i,node in enumerate(body) if isinstance(node,ast.Expr) and isinstance(node.value,ast.Await) and isinstance(node.value.value,ast.Call) and getattr(node.value.value.func,'id','')=='_browse_settled')
    return [ast.dump(node,include_attributes=False) for node in body[index+1:]]
receipt['fullpaste_remaining_reader_assertions_ast_identical']=after_filter(original_fn)==after_filter(probe_fn)
receipt['traces']=[dict(path=p.name,sha256=hashlib.sha256(p.read_bytes()).hexdigest()) for p in sorted(out.glob('*.trace.json'))]
(out/'evidence-receipt.json').write_text(json.dumps(receipt,indent=2),encoding='utf-8')
print(json.dumps(receipt,indent=2))
