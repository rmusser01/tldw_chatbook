import hashlib
import json
from pathlib import Path
import xml.etree.ElementTree as ET

root=Path(__file__).parent
def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()
runs=[]
for label,trace,qualification in (
    ('original-trace-01','test_typing_two_brackets_opens_a_keyboard_picker_that_inserts_a_real_link.trace.json','Unqualified for reopen: initial title preparation navigated away, line139 NoMatches.'),
    ('titleprep-trace-01','titleprep.trace.json','All original assertions passed; only an initial Pilot click on the actual title control was added.'),
    ('held-delivery-trace-01','holdpress.trace.json','Exact line245 timeout reproduced after picker/autosave. Real folder answer and original row Pressed delivery ordered across native recomposition; no fixture/service/getter replacement.'),
):
    xml=root/label/'result.xml'
    tree=ET.parse(xml)
    cases=list(tree.iter('testcase'))
    observations=json.loads((root/trace).read_text(encoding='utf-8'))
    provenance=next(r for r in observations if r['kind']=='provenance')
    runs.append(dict(label=label,xml_sha256=sha(xml),trace_sha256=sha(root/trace),
                     time=float(tree.getroot().find('testsuite').attrib['time']),
                     cases=len(cases),failures=sum(c.find('failure') is not None for c in cases),
                     errors=sum(c.find('error') is not None for c in cases),
                     qualification=qualification,sources=provenance['files']))
receipt=dict(runs=runs,probe_sha256=sha(root/'ci_note_probe.py'),
             note='Original script version for each earlier run is described by its mode and preserved tool-call patch history; product/test source hashes are taken inside each actual run. Final probe contains unused later modes in earlier-run comparisons.')
(root/'evidence-receipt.json').write_text(json.dumps(receipt,indent=2),encoding='utf-8')
print(json.dumps([{k:v for k,v in r.items() if k!='sources'} for r in runs],indent=2))
