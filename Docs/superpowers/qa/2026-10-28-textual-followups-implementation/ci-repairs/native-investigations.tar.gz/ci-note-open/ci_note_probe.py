"""Read-only observation of the original post-autosave note-open control."""
import asyncio
import functools
import hashlib
import inspect
import json
import os
from pathlib import Path
import time

import pytest

OUT = Path(__file__).parent


@pytest.fixture(autouse=True)
def note_open_trace(monkeypatch, request):
    from textual.message_pump import MessagePump
    from textual.widgets import Button
    from tldw_chatbook.UI.Screens.library_screen import LibraryScreen
    from tldw_chatbook.UI.Library_Modules.library_notes_controller import LibraryNotesController
    from tldw_chatbook.Widgets.Library.library_notes_canvas import LibraryNotesCanvas
    import Tests.UI.library_note_links_support as support
    import Tests.UI.test_library_note_links_picker_and_preview as case

    records = []
    mode = os.environ.get('NOTE_PROBE_MODE', 'exact')
    context = dict(target=None, active=False, held=False)
    press_seen = asyncio.Event()
    def button_state(obj):
        return dict(obj=hex(id(obj)), id=getattr(obj, 'id', None),
                    note_id=getattr(obj, 'note_id', None),
                    attached=getattr(obj, 'is_attached', None),
                    closing=getattr(obj, '_closing', None),
                    closed=getattr(obj, '_closed', None),
                    pruning=getattr(obj, '_pruning', None),
                    display=getattr(obj, 'display', None),
                    disabled=getattr(obj, 'disabled', None))

    def emit(kind, obj=None, **extra):
        row = dict(t=time.monotonic(), kind=kind, **extra)
        if obj is not None:
            row.update(button_state(obj))
            try:
                screen = obj if isinstance(obj, LibraryScreen) else (
                    obj._screen if isinstance(obj, LibraryNotesController) else obj.screen)
                state = screen._notes_state
                snapshot = screen._library_note_session.snapshot
                row.update(view=state.view, selected=state.selected_note_id,
                           armed=state.editor_armed, load=state.load_state,
                           topology=state.tree_topology_epoch,
                           focus=repr(screen.focused),
                           snapshot=None if snapshot is None else dict(
                               note_id=snapshot.note_id, dirty=snapshot.dirty,
                               saving=snapshot.saving))
                row['branches'] = [dict(key=str(k), generation=v.generation,
                                        loading=getattr(v, 'loading', None),
                                        items=len(v.items))
                                   for k,v in state.tree_branches.items()]
                row['rows'] = [button_state(b) for b in screen.query('.library-notes-tree-note-row')]
            except Exception as exc:
                row['observation_error'] = repr(exc)
        records.append(row)

    def relevant(button):
        return bool(button is not None and (
            getattr(button, 'id', '') == 'library-row-browse-notes'
            or getattr(button, 'note_id', None)))

    original_press = Button.press
    def press(self):
        active = relevant(self)
        if active: emit('Button.press:before', self)
        result = original_press(self)
        if active: emit('Button.press:after', self)
        return result
    monkeypatch.setattr(Button, 'press', press)

    original_post = MessagePump.post_message
    def post(self, message):
        active = isinstance(message, Button.Pressed) and relevant(message.button)
        result = original_post(self, message)
        if active: emit('post_message', message.button, owner=repr(self), accepted=result)
        return result
    monkeypatch.setattr(MessagePump, 'post_message', post)

    original_message = MessagePump._on_message
    async def message(self, event):
        active = isinstance(event, Button.Pressed) and relevant(event.button)
        if active: emit('bubble:before', event.button, owner=repr(self))
        if (mode == 'holdpress' and context['active'] and not context['held']
                and isinstance(event, Button.Pressed) and self is event.button
                and getattr(self, 'note_id', None) == context['target']):
            context['held'] = True
            emit('probe.press-delivery-held', self)
            press_seen.set()
            try:
                async with asyncio.timeout(5):
                    while self.is_parent_active and self.is_attached and not self._closing:
                        await asyncio.sleep(0.005)
            finally:
                emit('probe.press-delivery-released', self,
                     parent_active=self.is_parent_active)
        try: return await original_message(self, event)
        finally:
            if active: emit('bubble:after', event.button, owner=repr(self))
    monkeypatch.setattr(MessagePump, '_on_message', message)

    original_page = LibraryScreen._apply_library_notes_tree_slice_page
    async def page(self, key, incoming, **kwargs):
        if (mode == 'holdpress' and context['active'] and not context['held']
                and key.parent_id is None and key.slice_kind == 'folders'):
            emit('probe.real-folder-answer-held', self)
            try:
                await asyncio.wait_for(press_seen.wait(), 5)
            finally:
                emit('probe.real-folder-answer-released', self)
        return await original_page(self, key, incoming, **kwargs)
    monkeypatch.setattr(LibraryScreen, '_apply_library_notes_tree_slice_page', page)

    def wrap(cls, name):
        original = getattr(cls, name)
        if inspect.iscoroutinefunction(original):
            @functools.wraps(original)
            async def observed(self, *args, **kwargs):
                emit(name+':before', self, args=repr(args), kwargs=repr(kwargs))
                try: return await original(self, *args, **kwargs)
                finally: emit(name+':after', self)
        else:
            @functools.wraps(original)
            def observed(self, *args, **kwargs):
                emit(name+':before', self, args=repr(args), kwargs=repr(kwargs))
                try: return original(self, *args, **kwargs)
                finally: emit(name+':after', self)
        monkeypatch.setattr(cls, name, observed)

    for name in ('_select_library_rail_row', 'handle_library_notes_row',
                 '_begin_library_note_load', '_refresh_library_note_detail',
                 '_request_library_notes_tree_initial_load', '_load_library_notes_tree_slice',
                 '_run_library_notes_tree_slice_request'):
        wrap(LibraryScreen, name)
    for name in ('_try_switch_retained_library_notes_route', '_reset_library_note_editor_state'):
        wrap(LibraryNotesController, name)
    for name in ('recompose', 'sync_state'):
        wrap(LibraryNotesCanvas, name)

    if mode in ('titleprep', 'holdpress'):
        original_new = case._new_blank_note
        async def new_note(screen, pilot):
            await original_new(screen, pilot)
            emit('probe.title-click:before', screen)
            await pilot.click('#library-note-title')
            await support._until(pilot, lambda: screen.focused is screen.query_one('#library-note-title'),
                                 'probe title click to take focus')
            emit('probe.title-click:after', screen)
        monkeypatch.setattr(case, '_new_blank_note', new_note)

    original_open_notes = support._open_notes
    async def open_notes(screen, pilot):
        emit('helper.open_notes:before', screen)
        try: return await original_open_notes(screen, pilot)
        finally: emit('helper.open_notes:after', screen)
    monkeypatch.setattr(support, '_open_notes', open_notes)
    original_open = case._open_note
    async def open_note(screen, pilot, title, note_id):
        emit('helper.open_note:before', screen, target=note_id, title=title)
        if mode == 'holdpress' and title == case.NAVIGATION:
            context.update(active=True, target=note_id)
        try: return await original_open(screen, pilot, title, note_id)
        finally:
            context['active'] = False
            press_seen.set()
            emit('helper.open_note:after', screen, target=note_id, title=title)
    monkeypatch.setattr(case, '_open_note', open_note)

    paths=[Path(inspect.getfile(c)) for c in (Button,MessagePump,LibraryScreen,LibraryNotesController,LibraryNotesCanvas)]
    paths += [Path(support.__file__), Path(case.__file__)]
    emit('provenance', files=[dict(path=str(p),sha256=hashlib.sha256(p.read_bytes()).hexdigest()) for p in paths])
    yield
    (OUT/(mode+'.trace.json')).write_text(json.dumps(records,indent=2,default=str),encoding='utf-8')
