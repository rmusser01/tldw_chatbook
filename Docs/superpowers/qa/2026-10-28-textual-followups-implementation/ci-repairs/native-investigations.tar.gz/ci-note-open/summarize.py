import hashlib
import json
from pathlib import Path

root = Path(__file__).parent
for name in ('titleprep', 'holdpress'):
    path = root / (name + '.trace.json')
    if not path.exists():
        continue
    records = json.loads(path.read_text(encoding='utf-8'))
    first = next((r for r in records if r['kind'] == 'helper.open_note:before'), None)
    if first is None:
        continue
    last = next(r for r in records if r['kind'] == 'helper.open_note:after')
    keep = []
    for row in records:
        if not first['t'] <= row['t'] <= last['t']:
            continue
        if row['kind'].startswith(('sync_state:', 'post_message', 'bubble:')):
            if not row.get('note_id') == first['target']:
                continue
        summary = {k:v for k,v in row.items() if k in (
            'kind','obj','id','target','note_id','title','view','selected','armed',
            'load','closing','closed','pruning','attached','snapshot','owner',
            'parent_active','accepted')}
        summary['dt'] = round(row['t'] - first['t'], 6)
        summary['branches'] = row.get('branches', [])
        summary['row_count'] = len(row.get('rows', []))
        if row['kind'] == 'helper.open_notes:after':
            summary['target_rows'] = [b for b in row.get('rows', []) if b.get('note_id') == first['target']]
        keep.append(summary)
    out = root / (name+'.timeline.json')
    out.write_text(json.dumps(keep,indent=2),encoding='utf-8')
    print(json.dumps(dict(mode=name,trace_sha256=hashlib.sha256(path.read_bytes()).hexdigest(),timeline=str(out),events=len(keep))))
