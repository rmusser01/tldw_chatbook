# Task 27: conditional new_chat routing advertisement

Technical verdict: the posted Qodo finding is not actionable at the inspected current/published HEAD. Its premise treats the five-field static base as the complete advertised schema. The actual first-request plan builds routing properties per run and the Console supplies the necessary inputs.

Approval verdict: **approved** for this finding's read-only diagnosis. No source fix required for the alleged omission. This is not approval of the whole PR, a merge decision, or an external finding dismissal.

Finding: `b2e60199-050f-4074-a7df-1fede1fc6a74`, comment `4182699992`, thread `PRRT_kwDOOcyyl86o-1jM`, current-head review `5412722170`. Feedback was read from task-27-current-feedback.json. The specific recommendation is to add provider/model/preset unconditionally to NEW_CHAT_TOOL_SCHEMA.

## Contract and code evidence

- `backlog/decisions/219-console-chat-destinations-and-bounded-starts.md:109–111` and `Docs/superpowers/specs/2026-10-02-console-chat-destinations-and-starts-design.md:327–329` explicitly retain optional routing under the existing conditional schema gates while preserving the five base fields. Spec lines31–36 name those base fields.
- `backlog/decisions/147-agent-provider-routing.md:16–17` requires override enablement, allowlist and final-provider checks and omission of ad-hoc fields when the override flag is off. Preset routing is a distinct user-authored route. Unconditionally adding these fields to the base would contradict this disclosure contract.
- `tldw_chatbook/Agents/tool_catalog.py:781–829` is indeed the five-field base. `build_chat_create_schema` at238–310 returns the base unchanged when no routed definition and no override exist (266–268); otherwise it copies base properties (269–271), adds preset only for definitions carrying provider/model (272–285), adds provider/model only when override_enabled (286–300), and preserves the base required list (308). It does not mutate the base on construction.
- Preset disclosure has an enum of routed names plus provider/model identity prose (278–284). Override disclosure includes configured allowlisted provider/model identities via `_override_provider_description` (321–339); `_spawn_override_targets` (`agent_service.py:650–691`) builds this roster from allowlist provider identities and configured models, without exposing endpoint URLs or sampling parameters. Allowlist globs are not expanded; the new-chat model description explicitly explains that runtime matching can still accept an unlisted model matching a glob (tool_catalog.py:294–298).

Expected properties from these branches, including the original five fields in every row:

| Run inputs | Added properties | Required |
| --- | --- | --- |
| No routed definitions; override gate closed | none | [] |
| Override gate open; no routed definitions | provider, model | [] |
| Routed definitions; override gate closed | preset with routed-name enum | [] |
| Routed definitions; override gate open | preset with routed-name enum, provider, model | [] |

These are static branch conclusions, not a freshly executed matrix.

## Actual advertisement path and named callers

1. Console roster construction (`console_agent_bridge.py:4754–4767`) obtains enabled definitions. The live Console reads routing config and computes gate/targets at6305–6317. Its `build_console_first_request_plan` call forwards chat-create capability flags, override gate, targets and runtime definitions at6353–6359.
2. `build_console_first_request_plan` passes those values to `build_first_request_schema_plan` at5052–5075, specifically5062–5067. That planner's `make_plan` calls `build_chat_create_schema(NEW_CHAT_TOOL_SCHEMA, agent_definitions or (), override_enabled=spawn_override_enabled, override_targets=spawn_override_targets)` at `agent_service.py:934–942` and returns the resulting runtime schemas at954–961.
3. Both discovery and direct plans use that same `make_plan` (964,1014). The bounded context fallback at975–983 can intentionally omit all tools, rather than substituting a five-field new_chat schema. Routing properties are not uniquely lost by progressive disclosure.
4. The live Console forwards the already-built plan into the service at `console_agent_bridge.py:7854`. `AgentService` uses it directly at `agent_service.py:5110–5111`, then reads `schema_plan.runtime_schemas` at5202. In the service's non-prebuilt fallback,5119–5178 obtains routing settings when max_subagents>0, passes enabled chat-create callbacks and turn definitions (5143–5148), and forwards override gate/targets (5169–5177). This fallback has its existing positive-subagent-budget routing-config gate; the actual prebuilt Console path computes the chat-create gate directly. This report does not assert all arbitrary external service configurations expose overrides.
5. Provider request construction retains these schemas at `agent_service.py:3031–3051`. Its log-only filtering does not remove new_chat or replace its properties. Native mode converts the current schema list using `schemas_to_openai_tools`; `native_tools.py:275–303` projects each supplied schema's parameters, and its conformant object fast path at191–194 returns those parameters unchanged. Text protocol mode emits each supplied schema's parameters directly at `agent_runtime.py:384–391`. Both consume the dynamic schema; neither reloads the static base.
6. `_chat_create_runtime_schemas` (`agent_service.py:760–775`) does return static bases. Focused references search across tldw_chatbook and Tests found no production caller: only its definition and `Tests/Agents/test_agent_chat_create_tools.py:135–149`, `Tests/Agents/test_agent_runtime.py:1584–1601`. It therefore does not establish a real advertisement bypass.
7. The other planner call at `agent_service.py:6422–6448` builds the SubagentStart hook's tool-id snapshot; it neither enables new_chat nor injects that child_plan into the provider first-request path. It is not a static-base advertisement bypass.

## Acceptance and execution are distinct

The eight-field validator at `Utils/input_validation.py:123–134,160–171` and bridge forwarding at `console_agent_bridge.py:11220–11249,11261–11270` are correctly identified by the reviewer. They prove accepted public input, not unconditional disclosure. Actual prepared new_chat routing (`console_chat_controller.py:16923–16988`) verifies an enabled routed preset (16939–16958), passes explicit override values to the shared resolver using fresh destination settings, and blanks subagent default routing (16959–16971). The resolver checks override enablement/provider allowlist (`agent_routing.py:283–296`) and final resolved target allowlist (354–359). There is a reason to accept these public strings while only offering them under the operator's gates.

## Existing checks inspected and limits

Read `Tests/Agents/test_agent_chat_create_tools.py:33–44` (five-field base),47–70 (actual planner capability gates),78–91 (base identity),94–109 (routed preset enum/prose),112–127 (new_chat override disclosure),135–172 (subagent pin/plan capability). Read the helper gating matrix at `Tests/Agents/test_agent_runtime.py:1584–1601`. These tests were inspected, not executed or reported as passing.

No execution probe or test cohort was needed: the real first-plan branch, live call-site inputs, exact plan handoff and native/text serializers settle the newly named doubt. No provider/LLM/tool execution, import/bootstrap workaround, installation, suppression, profile change, timeout/cap change, source/index/HEAD/remote mutation, or external response occurred. Static inspection does not claim a live provider wire capture or full routing/creation end-to-end qualification.

ADR required: no new ADR. Existing ADR-147 and ADR-219 already define the conditional contract. If broader service-budget behavior is separately requested, it should be scoped separately; it does not substantiate the posted claim that agents can never discover routing fields.

## Identity and read-only check

Inspected HEAD: `3790437bdb686e40539cb82af64277b1f074f6b6`. Source hashes below were captured before report creation and rechecked afterwards. Index SHA-256 before/after: `c9903ec8e43eef0e0fa7b57116c9b5d39e3e2a3465ce355239bb4c7df0152e43`. HEAD, index and all listed inputs remained identical around this artifact-only write. Git tracked status was empty at the inspection point. Remote state was not modified or re-queried; published identity is supplied by the Task27 brief.

| File | SHA-256 before = after |
| --- | --- |
| tldw_chatbook/Agents/tool_catalog.py | `6a175d0e2c5716ccbc24c06b5764d926f6d44196bb9570ac0ec780f31c1ee46c` |
| tldw_chatbook/Agents/agent_service.py | `47ed36d7c8ee0946a74b48ba48a0a0e7bf18e4e143979f7896d099b045a7b3d0` |
| tldw_chatbook/Chat/console_agent_bridge.py | `37a0c12ec6de14b1d949eb2d0f9c2d06f2ca9b0c260f870e71ba60c0bbfeabdf` |
| tldw_chatbook/Chat/console_chat_controller.py | `30ffdb89ab918f005330c25912b8b1c578dd8812b3b30ac11c0b4d68dee89767` |
| tldw_chatbook/Agents/agent_routing.py | `b2e091ccfdbcf1fcb9bf6d34eee3429ea9db1e244ff44782a2d892822bf03c46` |
| tldw_chatbook/Agents/native_tools.py | `c97cc9e913f76237d9e34b41bf32f4e6c40c84551cd9913a3c8cfdad9d634fef` |
| tldw_chatbook/Agents/agent_runtime.py | `ce14f26605b5b380886e0e0ca9f33285ba6af94fbe72ab1da296fdbcd5bf4e9e` |
| tldw_chatbook/Utils/input_validation.py | `ebf77a23e64d7762202b864ad4caa576c2a5748015da6046c0cde39d45598cab` |
| Tests/Agents/test_agent_chat_create_tools.py | `e7601b3151b19ee0a9d0c8a594003bf024f74169f7b15a7468a32b58580ced8e` |
| Tests/Agents/test_agent_runtime.py | `2b0c3690e1bb6d8f32d0a333d27b69a438893685c232c7ab0cec3209229bdefe` |
| backlog/decisions/147-agent-provider-routing.md | `845a6c87bf79cec2b00e2135c93bd3810ea1d32a6fb1b710867b139a0bf892af` |
| backlog/decisions/219-console-chat-destinations-and-bounded-starts.md | `82c469828465dc2b00a8c87ce82e92d6afe21ba5c1adbb2bb215fe25d6db6da7` |
| Docs/superpowers/specs/2026-10-02-console-chat-destinations-and-starts-design.md | `8ef34a9ebc0825ce2656e104e297a904807bbcc4e0e9ec8853c536fc92598d7f` |
| .superpowers/sdd/2026-10-03-console-pr2995-review-and-merge/task-27-current-feedback.json | `e2d5f702fb3b0b7fe081068e57968d1643d8673077393cb4052afcd036f173fa` |
