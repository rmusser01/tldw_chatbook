from pathlib import Path
import subprocess
import sys

root = Path(__file__).parent
python = sys.executable
files = ["tldw_chatbook/Chat/console_chat_controller.py", "tldw_chatbook/Chat/console_chat_store.py", "tldw_chatbook/Chat/console_chat_start.py", "tldw_chatbook/Widgets/Chat_Widgets/chat_create_confirm_card.py", "Tests/Chat/test_console_chat_start.py", "Tests/Chat/test_chat_create_confirm_card.py", "Tests/Agents/test_agent_chat_create_tools.py"]
commands = [
    [python, "-m", "ruff", "check", "--select", "E9,F63,F7,F82", *files],
    [python, "-m", "ruff", "format", "--check", "tldw_chatbook/Chat/console_chat_start.py", "Tests/Chat/test_console_chat_start.py", "Tests/DB/test_chachanotes_v74_agent_chat_starts_migration.py"],
]
for name in ("task2-format.json", "task2-fix1-format.json", "task2-fix2-format.json", "final-fix-format.json", "final-fix-format-schema-test.json"):
    commands.append([python, "scripts/terminal_qualification/format_ratchet.py", "verify", "--baseline", str(root / name), *(["--head", sys.argv[1]] if len(sys.argv) > 1 else [])])
commands.append(["git", "diff", "--check"])
failed = False
for command in commands:
    print("COMMAND", repr(command), flush=True)
    result = subprocess.run(command)
    print("EXIT", result.returncode, flush=True)
    failed |= result.returncode != 0
sys.exit(int(failed))
