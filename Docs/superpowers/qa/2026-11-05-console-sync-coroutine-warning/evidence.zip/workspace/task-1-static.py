import collections
import difflib
import hashlib
import json
import subprocess
from pathlib import Path

root = Path('.superpowers/sdd/2026-11-05-console-sync-coroutine-warning-fix')
files = list(json.loads((root / 'task-1-before-hashes.json').read_text())) + [
    'Tests/UI/test_console_readiness_config_projection.py',
    'Tests/UI/test_console_sync_worker_admission.py',
]
receipts = []
for name in files:
    path = Path(name)
    current = path.read_text()
    before_path = root / 'task-1-before' / path.name
    before = before_path.read_text() if before_path.exists() else ''
    diagnostics = []
    for source in (before, current):
        result = subprocess.run(
            ['.venv/bin/python', '-m', 'ruff', 'check', '--output-format', 'json', '--stdin-filename', str(path.resolve()), '-'],
            input=source, text=True, capture_output=True,
        )
        rows = json.loads(result.stdout)
        diagnostics.append(collections.Counter((row['code'], row['message']) for row in rows))
    formatted = subprocess.run(
        ['.venv/bin/python', '-m', 'ruff', 'format', '--stdin-filename', name, '-'],
        input=current, text=True, capture_output=True, check=True,
    ).stdout
    edits = [(j1, j2) for tag, i1, i2, j1, j2 in difflib.SequenceMatcher(a=before.splitlines(), b=current.splitlines(), autojunk=False).get_opcodes() if tag != 'equal']
    formats = [(i1, i2) for tag, i1, i2, j1, j2 in difflib.SequenceMatcher(a=current.splitlines(), b=formatted.splitlines(), autojunk=False).get_opcodes() if tag != 'equal']
    overlaps = [(e, f) for e in edits for f in formats if max(e[0], f[0]) < min(e[1], f[1]) or (e[0] == e[1] and f[0] <= e[0] < f[1]) or (f[0] == f[1] and e[0] <= f[0] < e[1])]
    introduced = diagnostics[1] - diagnostics[0]
    receipts.append(dict(path=name, sha256=hashlib.sha256(path.read_bytes()).hexdigest(), lint_before=sum(diagnostics[0].values()), lint_after=sum(diagnostics[1].values()), introduced=[(key, value) for key, value in introduced.items()], formatter_blocks=len(formats), formatter_edit_overlaps=overlaps))
    assert not introduced, (name, introduced)
    assert not overlaps, (name, overlaps)
subprocess.run(['git', 'diff', '--check', '--', *files], check=True)
baseline = json.loads((root / 'baseline.json').read_text())
changed = [item['path'] for item in baseline['protected'] if item.get('kind') == 'file' and (not Path(item['path']).is_file() or hashlib.sha256(Path(item['path']).read_bytes()).hexdigest() != item['sha256'])]
assert not changed, changed
assert hashlib.sha256(subprocess.check_output(['git', 'diff', '--cached', '--binary'])).hexdigest() == baseline['cached_sha256']
(root / 'task-1-static-final.json').write_text(json.dumps(dict(files=receipts, protected_changes=changed, staged_baseline_preserved=True), indent=2) + '\n')
(root / 'task-1-source-final.json').write_text(json.dumps({name: hashlib.sha256(Path(name).read_bytes()).hexdigest() for name in files}, indent=2) + '\n')
print('PASS: 11 files; zero introduced lint findings or formatter overlaps; diff whitespace clean; 279 protected files and staged61 intact')
