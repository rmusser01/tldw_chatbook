# TASK-38614 implementation evidence

Commit: `5f03c716fe4b1356678a61d578c39d687b1a1fe0` (exact11 product/test paths; no task, plan, status, unrelated path or evidence staged).

## Cause and allocation evidence

Original production allocation is `ChatScreen._sync_native_console_chat_ui` finally replay at `tldw_chatbook/UI/Screens/chat_screen.py:17791`, reached through `_reconcile_console_after_attach:15393`; original screen SHA256 `a144ee0bd7f25f69c5ac24c0cb88bc0cbb929ea00996fe5b2a670a2fa618b39c`. The actual mounted `existing_journey` completed every original assertion and printed `retired and reopened`; its child then failed on the captured RuntimeWarning. CPython coroutine origin tracking(depth12) and tracemalloc(depth1) independently identify17791. The warning receiver was unrelated installed `textual/cache.py:226`. `/private/tmp/task38614-origin-red3/restart-output.log:1299–1332` retains the complete raw proof; task-1-origin-red.log retains the parent failure as a separate observation. Exit1,43.35s.

Installed Textual8.2.8 Worker stores supplied work in `_work`, schedules `_run` via asyncio.create_task and creates/invokes callable work only inside `_run_async`. Cancellation/replacement before that entry leaves an eagerly supplied coroutine unawaited; cancel does not close it. The new real-Worker regression witnesses exact task entry through the original method's code object: refused/cancelled/replaced work never enters, admitted replacement does enter, succeeds and publishes an actual store-created session tab. Before the correction it captured3 native coroutine warnings (refusal/cancel/replacement); afterward it captures zero RuntimeWarnings. No mocked run_worker supplies this proof.

Read earlier TASK34852/32492 acceptance remedy, actual connected caller contracts and installed Textual source, Console/lifecycle architecture and ADR094, design-language/component-pattern catalog, testing/live lessons and systematic-debugging/TDD/test-quality/ponytail instructions. Root released the production-edit gate only after reading the concrete allocation evidence. No delegate/helper/reviewer was dispatched by this agent.

## Complete narrow correction

Eight production files: screen6 eager worker arguments; workspace5 direct worker arguments plus its stored-work switch path; session2; message2; agent2 (including the accessor-returned bound method); send-ack1; wiring1; spend's stored publication coroutine. These now provide admitted async callable work. Existing groups, exclusivity, error policy, currentness and teardown checks, direct awaits, return values and coalescing guards are preserved. One local async wiring forwarder replaces the synchronous lambda injection for workspace/session/message and returns the actual original bool/False; it retains late lookup of the screen method. The workspace switch path still accepts existing synchronous callback results/awaitables through its original compatibility behavior. No general scheduler, runtime owner, dependency, UI token/style or unrelated coroutine scheduling changed.

Tests: added real Worker admission/physical original-entry/tab-publication regression, strengthened the existing workflow child to capture/GC/assert on every RuntimeWarning within the child, and adapted the readiness fake scheduler to Textual's actual callable-or-awaitable API while retaining its published-result assertion. The new regression also injects a RuntimeError at the actual first awaited tabs dependency after natural idle observation and verifies the live original sync propagates it; the dependency is immediately restored. No busy/teardown guard is flipped for this control.

## Commands and receipts

All pytest commands use `.venv/bin/python -m pytest`, `-q`, a unique `--basetemp=/private/tmp/task38614-*`, and `-W error::RuntimeWarning -W error::pytest.PytestUnraisableExceptionWarning`. Full reproducible command strings are in task-1-commands.json. No full suite/provider/network replay.

| Observation | Result / seconds | Raw evidence |
| --- | --- | --- |
| Actual origin-traced mounted journey, original source | RED exit1 /43.35 | task-1-origin-red.log; original child log above |
| Final deterministic original-source refusal/cancel/replacement | RED exit1,3 warnings /5.77 | task-1-worker-red.log |
| Corrected real-Worker/tab publication | GREEN exit0 /5.52 | task-1-worker-green.log |
| Same origin-traced mounted journey, corrected product | GREEN exit0 /38.10 | task-1-origin-green.log; `/private/tmp/task38614-origin-green/restart-output.log`, cleanup marker1290, no JOURNEY_ERROR/RAW_WARNING |
| Corrected Worker + readiness published-result fake | GREEN2P exit0 /6.36 | task-1-worker-final.log |
| Final targeted cohort | GREEN14P exit0 /44.07 | task-1-targeted-final.log |
| Final amended Worker/live-error control, final test bytes | GREEN1P exit0 /5.77 | task-1-live-control.log |
| Supported-bootstrap original7-node invocation | exit1,1F/6P /61.93 | task-1-originals-bootstrap.log |

Final14P comprises both original workflow modes; final FULL poll completion; real Worker regression; readiness published-result, changed-owner, closed-owner, disposed-runtime controls; original inflight workspace-switch literal UI check. Product bytes match final source pins. The later new live-error control changes only the new test and has its separate final receipt. Traced GREEN preceded the blank-line formatting correction in wiring; final14P ran after that correction. Original source pins, exact before bytes, final pins and per-file static comparisons are retained in task-1-before/, task-1-before-hashes.json, task-1-source-final.json and task-1-static-final.json.

## Adverse observations and limits

An earlier depth3-tracemalloc run failed the original pilot tab-click assertion before warning reporting (exit1/54.56s); `/private/tmp/task38614-origin-red2/restart-output.log` retains it. Two initial scratch setup errors (import path and missing temporary parent) happened before any native journey. The strict uninstrumented mounted baseline independently passed16.59s: this warning is timing-sensitive; that is not substituted for the traced RED.

A wider affected-controller attempt was deliberately interrupted: observed partial55F/157P105.54s, exit2, NOT a completed cohort (task-1-controller-green.log). All55 observed controller failures are enumerated by node, raw-log starting line and exact signature in task-1-controller-green-failures.json:1 introduced readiness fake `assert published` (fixed and independently GREEN);32 `raw_source_selection_changed` (31 at app-factory config read before screen construction,1 at test_console_message_send_persists_user_and_assistant_rows's initial app factory);20 fixture SimpleNamespace DBs missing get_message_exchanges during ChatScreen constructor→wiring raw-store initialization→ConsoleRuntime.ensure_chat_store, before any UI scheduling;1 SimpleNamespace mode-bar fixture missing _console_rate_reading at unchanged screen17431;1 ctor-doc check missing complete_manual_read_visit. No blanket historical-baseline claim is made. A separate original native selection completed7F/12P59.11s: task-1-native-green-failures.json accounts for all7 nodes:6 raw_source_selection_changed before screen construction,1 send-ack wait timeout accompanied by preparation-source-unavailable refusal. No unrelated repair/reset/source swap was made.

Root approved a DIFFERENT narrowly qualified invocation: retained scratch plugin task-1-bootstrap/task_1_bootstrap_plugin.py adds only the existing bootstrap_profile marker to exactly7 explicit original IDs, before fixtures; it preserves the genuine collection-selected private profile, with no source/config/registry/authority/guard reset and no deadline changes. Six original navigation/teardown/workspace/edit checks pass. The original live-screen NoMatches control remains failed and unchanged: its helper injects at avatar refresh after current tabs publication (production tabs17634 vs avatar17673), so its stated before-tabs injection no longer names the current order. Source-order evidence does not establish a historical baseline pass. The new actual-await RuntimeError control supplies meaningful live-error propagation evidence without weakening that existing assertion.

## Static checks, self-review and preservation

`task-1-static.py` run before staging and again after commit:11 files, zero introduced Ruff code/message multiplicities per file; zero formatter-edit overlaps; `git diff --check` clean. Existing product lint debt remains unchanged (screen187, workspace67, session47, message38, agent12, wiring2, send_ack2); spend and all3 tests lint clean. New regression and existing workflow test fully format clean; existing formatter debt elsewhere is outside changed ranges. No broad formatting applied.

Self-review traced every original exact coroutine reference, accessor/lambda ownership and direct-await boundary; inspected the complete owned diff, retained callable group/exclusivity/error semantics and removed only the obsolete spend publication.close (no coroutine now exists before admission). No data/schema/provider/interface/security ownership changed; ADR required:no, routine existing Textual boundary correction under ADR094.

Postcommit all279 baseline protected file hashes remain equal and original staged61 binary diff SHA remains `c5fcb00eab4ea09c49d1797567cbd4cc9f0eb9bb8d99cc2355f764638aaa7248`; original staged61 paths remain61. Commit used scoped escalation, `git -c gc.auto=0 add` for only the new test and `git -c gc.auto=0 commit --only` for exact11 paths. No branch/worktree/stash/reset/clean/maintenance/push/merge or user-profile edit. Root owns independent review, living docs, Backlog/plan/status closeout and any review followup.
