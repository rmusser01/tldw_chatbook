"""Keep the existing collection-selected private profile for exactly seven tests."""

import pytest

NODES = {
    "Tests/UI/test_console_sync_outlives_screen.py::test_a_console_sync_tick_scheduled_after_teardown_cannot_kill_the_app",
    "Tests/UI/test_console_sync_outlives_screen.py::test_a_torn_down_screen_runs_no_sync_work_and_never_re_arms",
    "Tests/UI/test_console_sync_outlives_screen.py::test_a_live_screens_console_sync_failure_still_propagates",
    "Tests/UI/test_console_sync_outlives_screen.py::test_a_real_navigation_arriving_mid_tick_is_absorbed",
    "Tests/UI/test_console_sync_outlives_screen.py::test_a_partly_dismantled_screen_mid_tick_is_absorbed",
    "Tests/UI/test_console_native_chat_flow.py::test_console_workspace_switch_refreshes_visible_session_tabs",
    "Tests/UI/test_console_native_chat_flow.py::test_console_selected_message_edit_action_opens_modal_and_saves_content",
}


def pytest_collection_modifyitems(items):
    for item in items:
        if item.nodeid in NODES:
            item.add_marker(pytest.mark.bootstrap_profile)
