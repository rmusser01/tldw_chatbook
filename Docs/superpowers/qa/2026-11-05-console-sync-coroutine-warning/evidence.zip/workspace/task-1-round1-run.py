"""Record source identities around one exact, sequential verification command."""

import datetime
import hashlib
import json
import shlex
import subprocess
import sys
import time
from pathlib import Path

root = Path(__file__).resolve().parent
label, *command = sys.argv[1:]
files = list(json.loads((root / 'task-1-source-final.json').read_text())) + [
    'Tests/UI/test_console_shared_context_policy.py',
    'Tests/Chat/test_console_context_presentation_current.py',
]

def pins():
    return {name: hashlib.sha256(Path(name).read_bytes()).hexdigest() for name in files}

before = pins()
started = datetime.datetime.now(datetime.timezone.utc).isoformat()
base = root / ('task-1-round1-' + label)
base.with_suffix('.before.json').write_text(json.dumps(dict(command=command, shell_display=shlex.join(command), started_utc=started, source_sha256=before), indent=2) + '\n')
start = time.monotonic()
with base.with_suffix('.log').open('w') as output:
    result = subprocess.run(command, stdout=output, stderr=subprocess.STDOUT, check=False)
elapsed = time.monotonic() - start
after = pins()
receipt = dict(command=command, shell_display=shlex.join(command), started_utc=started, exit=result.returncode, duration_seconds=elapsed, before=before, after=after, source_unchanged=before == after)
base.with_suffix('.receipt.json').write_text(json.dumps(receipt, indent=2) + '\n')
print(json.dumps(dict(label=label, exit=result.returncode, duration_seconds=elapsed, source_unchanged=before == after)))
assert before == after, 'source changed during execution'
raise SystemExit(result.returncode)
