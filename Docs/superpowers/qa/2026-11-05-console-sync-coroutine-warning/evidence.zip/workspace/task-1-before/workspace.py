"""Workspace and conversation-browser ownership for the Console.

`ConsoleWorkspaceController` owns 57 non-DOM methods covering Workspace
policy and lifecycle, scope selection, persisted-conversation resume, the
named-workspace Tree projection, and the flat Default/unassigned browser.
Workspaces and Conversations own independent search attempts; page generations
are scoped per workspace. Legacy Workspace row and scalar names are
compatibility aliases over the flat lane.

The Textual screen retains only framework and DOM edges. Its bounded search
handler extracts plain query/disabled values and delegates the transition;
the Clear button delegates the complete clear transition. Browser services
and sibling-owned data enter through explicit late-bound constructor
callables so replacements remain observable and moved methods never query the
DOM or reach through sibling controllers.
"""

from __future__ import annotations

import asyncio
import inspect
import json
import re
import time
from collections.abc import Awaitable, Callable, Iterable, Mapping, Sequence
from contextlib import contextmanager, nullcontext
from dataclasses import dataclass, field, replace
from datetime import datetime, timezone
from functools import partial
from types import FunctionType, MappingProxyType, ModuleType
from typing import TYPE_CHECKING, Any, Optional

from loguru import logger
from tldw_chatbook.Utils.input_validation import escape_markup
from textual.css.query import NoMatches

from tldw_chatbook.DB.base_db import operation_owned_connection, run_owned_db_call
from tldw_chatbook.DB.Workspace_DB import WorkspaceDB

from ...Character_Chat.character_conversation_navigation import (
    LocalCharacterConversationTarget,
)
from ...Chat.console_appearance import ConsoleConversationAppearance
from ...Chat.message_metadata import AgentHandoffLaunchMetadata
from ...Chat.console_chat_models import (
    CONSOLE_GLOBAL_WORKSPACE_ID,
    CONSOLE_RUN_MARKER_GLYPHS,
    DEFAULT_CONSOLE_SESSION_TITLE,
    ConsoleRunMarker,
    ConsoleStagedSource,
    ConsoleWorkspaceContext,
)
from ...Chat.console_conversation_hydration import (
    ConsoleGenerationSettingsHydration,
    ConversationLoadFailed,
    ConversationServiceUnavailable,
    hydrate_console_session,
    load_console_conversation_tree,
)
from ...Chat.console_display_state import evidence_bundle_from_launch
from ...Chat.console_live_work import ConsoleLiveWorkLaunch
from ...Chat.console_session_settings import blank_console_session_settings
from ...Chat.console_switcher_state import (
    CONSOLE_SWITCHER_PAGE_LIMIT,
    ConsoleSwitcherActivitySignal,
    ConsoleSwitcherEntry,
    ConsoleSwitcherHistoryPage,
    ConsoleSwitcherTarget,
    SwitcherTargetKind,
    build_console_active_results,
    group_console_history_entries,
    parse_console_switcher_instant,
    plan_console_history_query,
    resolve_console_history_timezone,
)
from ...Chat.rag_scope import RagScope
from ...config import save_setting_to_cli_config
from ...Utils.input_validation import (
    CONSOLE_SWITCHER_QUERY_MAX_LENGTH,
    sanitize_string,
    validate_console_switcher_query,
    validate_text_input,
)
from ...Widgets.confirmation_dialog import ConfirmationDialog
from ...Widgets.Console import (
    ConsoleWorkspaceContextTray,
    ConsoleWorkspaceRenameModal,
    ConsoleWorkspaceSwitcherModal,
)
from ...Widgets.Console.console_scope_picker_modal import ConsoleScopePickerModal
from ...Widgets.glyph_fallback import resolve_glyph
from ...Widgets.project_skills_import_modal import maybe_offer_project_skills_import
from ...Workspaces import (
    CONSOLE_CONVERSATION_BROWSER_RESULT_LIMIT,
    DEFAULT_WORKSPACE_ID,
    ConsoleConversationBrowserInputRow,
    ConsoleConversationBrowserRow,
    WorkspaceRecord,
    WorkspaceTreeWorkspace,
    build_console_conversation_browser_state,
    build_workspace_tree_state,
    console_conversation_browser_group_row_limit,
    console_persisted_row_updated_sort,
    overlay_console_conversation_markers,
)
from ...Workspaces.conversation_browser_state import (
    console_conversation_status_detail,
    format_console_relative_age,
)
from ...Workspaces.display_state import (
    CONSOLE_WORKSPACE_CONVERSATION_RESULT_LIMIT,
    ConsoleWorkspaceContextState,
    ConsoleWorkspaceConversationRow,
    ConsoleWorkspaceConversationSectionState,
    _recompute_filesystem_binding_status,
    build_console_workspace_state,
    console_workspace_conversation_result_copy,
)
from ...Workspaces.models import (
    RuntimeBindingKind,
    RuntimeBindingStatus,
    WorkspaceRuntimeBinding,
)
from ...Workspaces import registry_service as _workspace_registry_source
from ...Workspaces.registry_service import (
    _DEFAULT_BINDING_DISPLAY_CHECK,
    LocalWorkspaceRegistryService,
    WorkspaceNotFound,
    WorkspaceRegistryServiceError,
    binding_exclusion_entries,
)
from ..character_display_text import sanitize_character_display_label

if TYPE_CHECKING:
    from ...Chat.console_chat_controller import ConsoleChatController
    from ...Chat.console_conversation_actions import ConversationMenuTarget
    from ...Chat.console_conversation_activation import (
        CharacterConversationActivationRequest,
        ConsoleActivationCommit,
        ConsoleActivationResultKind,
        ConsoleConversationActivationResult,
    )
    from ...Widgets.Console.console_workspace_files_modal import (
        ConsoleWorkspaceFilesModal,
        WorkspaceFilesAttention,
        WorkspaceFilesBinding,
        WorkspaceFilesService,
    )
    from ...Widgets.workspace_create_modal import WorkspaceCreateResult
    from ..Screens.chat_screen import ChatScreen

logger = logger.bind(module="ChatScreen")

CONSOLE_PERSISTED_ROWS_CACHE_TTL_SECONDS = 10.0
# PR #2480 review (#7): keep the appearance map cache short so changes
# made elsewhere show up promptly, while the several merges inside one
# state build share one read.
CONSOLE_APPEARANCE_MAP_CACHE_TTL_SECONDS = 2.0
CONSOLE_SAVED_CONVERSATION_RESUME_FAILURE_COPY = (
    "Couldn't resume this saved conversation: it was deleted or couldn't be read.\n"
    "Your previous Console chat is still active."
)


def persist_console_workspace_tree_expansion_preferences(
    workspace_ids: list[str],
) -> None:
    """Write native Workspace Tree disclosure preferences off the UI loop."""

    try:
        save_setting_to_cli_config(
            "console.conversation_browser",
            "expanded_workspace_ids",
            list(workspace_ids),
        )
    except Exception as exc:
        logger.warning(
            "Failed to persist Workspace Tree disclosure (exception_type={})",
            type(exc).__name__,
        )


#: Ceiling for a user-entered conversation title. Titles render in the
#: Context rail, the tab strip and the transcript header, so the limit is
#: about legibility in a narrow column, not storage.
_CONVERSATION_TITLE_MAX = 200


class UnknownMembership:
    __slots__ = ()


_MEMBERSHIP_UNKNOWN = UnknownMembership()

# TASK-25827: two unrelated failures used to share one sentence, so the rail
# could not tell "we could not check your access" from "the query failed" --
# and at the rail's width the shared sentence clipped to "Workspace
# conversations a...", which named neither. Keep these short enough to read
# in the rail and distinct enough to act on.
WORKSPACE_CONVERSATIONS_ACCESS_UNKNOWN = "Workspace access unknown."
WORKSPACE_CONVERSATIONS_LOAD_FAILED = "Couldn't load conversations."


@dataclass(slots=True)
class SearchAttemptState:
    """One projection's explicit debounce, request, result, and Retry state."""

    query: str = ""
    debounce: Any = None
    generation: int = 0
    request_key: tuple[str, str, int, object, object, int] | None = None
    rows: tuple[ConsoleConversationBrowserInputRow, ...] = ()
    total: int | None = None
    settled_rows: tuple[ConsoleConversationBrowserInputRow, ...] = ()
    settled_total: int | None = None
    settled_query: str = ""
    error: str = ""
    cache: dict[
        str, tuple[tuple[ConsoleConversationBrowserInputRow, ...], int | None]
    ] = field(default_factory=dict)
    retry_query: str | None = None
    worker: Any = None


@dataclass(slots=True)
class PageAttemptState:
    """One workspace's bounded page request and accumulated child state."""

    generation: int = 0
    loading: bool = False
    request_key: tuple[str, tuple[str, ...], int, int] | None = None
    membership_token: tuple[str, ...] | None = None
    owner_token: object = None
    lifecycle_token: object = None
    rows: tuple[ConsoleConversationBrowserInputRow, ...] = ()
    next_cursor: int | None = None
    error: str = ""
    retry_cursor: int | None = None
    membership_unknown: bool = False
    worker: Any = None


WORKSPACE_FILES_AVAILABILITY_CACHE_TTL_SECONDS = 1.0
WORKSPACE_FILES_NO_FOLDERS_COPY = "No local folders are attached. Add one in Settings."
WORKSPACE_FILES_OTHER_VISIT_COPY = (
    "Close Workspace Files before inspecting another workspace."
)
WORKSPACE_FILES_MINIMUM_COPY = "Workspace Files needs at least 80 × 24 terminal cells."


@dataclass(frozen=True)
class _WorkspaceFilesResolution:
    """Off-loop registry snapshot used to construct one pinned visit."""

    workspace_id: str
    workspace_name: str
    active_workspace_id: str | None
    active_workspace_name: str
    bindings: tuple[WorkspaceFilesBinding, ...]
    had_bindings: bool


class _WorkspaceFilesVisitService:
    """One visit's narrow service: safe reads plus exclusion toggles.

    The Workspace Files modal deliberately owns no registry dependency, so
    its inspector gains exclusion edits by composition: the read-only
    ``WorkspaceFileInspector`` handles listing/filtering/preview and the
    controller's validated ``set_exclusion`` seam handles toggles.
    """

    def __init__(self, reads: Any, toggles: Any) -> None:
        self._reads = reads
        self._toggles = toggles

    def list_directory(
        self,
        scope: Any,
        directory_parts: tuple[str, ...] = (),
        *,
        continuation: Any | None = None,
    ) -> Any:
        return self._reads.list_directory(
            scope, directory_parts, continuation=continuation
        )

    def filter_paths(
        self,
        scope: Any,
        query: str,
        *,
        is_cancelled: Any | None = None,
        on_progress: Any | None = None,
    ) -> Any:
        return self._reads.filter_paths(
            scope, query, is_cancelled=is_cancelled, on_progress=on_progress
        )

    def read_file(
        self,
        scope: Any,
        raw_parts: tuple[str, ...],
        *,
        page_offset: int | None = None,
        expected_revision: Any | None = None,
    ) -> Any:
        return self._reads.read_file(
            scope,
            raw_parts,
            page_offset=page_offset,
            expected_revision=expected_revision,
        )

    def set_exclusion(
        self, binding_id: str, relative_path: str, excluded: bool
    ) -> None:
        self._toggles.set_exclusion(binding_id, relative_path, excluded)


#: Alt+W switcher chip severity (Task 20): BLOCKED outranks MISSING
#: outranks STALE_IDENTITY; READY/cold carries no chip (healthy rows stay
#: uncluttered -- the chip exists to warn before switching).
_SSH_CHIP_SEVERITY = {"BLOCKED": 3, "MISSING": 2, "STALE_IDENTITY": 1}


def _console_workspace_ssh_status_chips(
    registry: Any, workspaces: Sequence[Any]
) -> dict[str, str]:
    """One worst-binding SSH status chip per workspace row (Task 20).

    Reads the process-wide remote-binding status cache only (never
    probes); returns ``{workspace_id: "ssh: <display word>"}`` for every
    workspace owning at least one DEGRADED ssh binding, worst state
    first. Healthy or ssh-less workspaces are omitted. Guarded end to
    end: any failure is a silent omit, never a broken switcher.
    """
    from tldw_chatbook.Tools.remote_binding_status import (
        cached_status_display,
        get_remote_binding_status_cache,
    )

    chips: dict[str, str] = {}
    try:
        list_ssh = getattr(registry, "list_ssh_bindings", None)
        if not callable(list_ssh):
            return chips
        cache = get_remote_binding_status_cache()
        for workspace in workspaces:
            workspace_id = str(getattr(workspace, "workspace_id", "") or "")
            if not workspace_id:
                continue
            try:
                bindings = tuple(list_ssh(workspace_id))
            except Exception:  # noqa: BLE001 - display-only
                continue
            worst_state = ""
            worst_display = ""
            for binding in bindings:
                binding_id = str(getattr(binding, "binding_id", "") or "")
                if not binding_id:
                    continue
                try:
                    state = str(cache.status(binding_id).state)
                    display = cached_status_display(binding_id, cache)
                except Exception:  # noqa: BLE001 - display-only
                    continue
                if _SSH_CHIP_SEVERITY.get(state, 0) > _SSH_CHIP_SEVERITY.get(
                    worst_state, 0
                ):
                    worst_state = state
                    worst_display = display
            if worst_state:
                chips[workspace_id] = f"ssh: {worst_display}"
    except Exception:  # noqa: BLE001 - display-only, degrade silently
        return {}
    return chips


def _bind_composer_after_switch(owner: Any) -> None:
    """Bind the Console composer to the chat a workspace path just switched to.

    TASK-33622.7: see ``ConsoleSessionController._bind_composer_to_active_
    session`` -- never leave the rebind to the coalescable sync pass. Focus
    stays with the path, which focuses the composer when it finishes.

    Args:
        owner: The workspace controller (or a test double); reached through
            its screen's session controller when one is attached.
    """
    session = getattr(getattr(owner, "_screen", None), "_session", None)
    bind = getattr(session, "_bind_composer_to_active_session", None)
    if callable(bind):
        bind(focus=False)


def _normalized_console_workspace_id(workspace_id: str | None) -> str:
    """Fold the "no explicit workspace" sentinels onto one identity.

    A Console session's default ``workspace_id`` (unset, or the explicit
    ``CONSOLE_GLOBAL_WORKSPACE_ID`` sentinel) and the registry's built-in
    Default workspace row (``DEFAULT_WORKSPACE_ID`` -- the resting state
    ``ensure_default_workspace`` establishes at boot and switch seams, and
    the id the read-only context resolution floors a missing active
    workspace to, TASK-21118) are THE SAME state on two layers (task-15120
    owner ruling, see ``_set_active_workspace_for_console_session``), not
    two different workspaces that happen to share a session. Any comparison between a
    session's ``workspace_id`` and a registry workspace id must normalize
    through this before comparing, or an aligned "global"/Default session
    reads as diverged purely because of which layer's spelling it carries.
    """
    normalized = str(workspace_id or "").strip()
    if not normalized or normalized == CONSOLE_GLOBAL_WORKSPACE_ID:
        return DEFAULT_WORKSPACE_ID
    return normalized


def _default_display_bindings_are_empty(service: object, workspace_id: object) -> bool:
    """Decline changed/malformed selectors before invoking the stock policy."""
    record = _DEFAULT_BINDING_DISPLAY_CHECK
    if (
        type(record) is not tuple
        or len(record) != 4
        or type(_workspace_registry_source) is not ModuleType
        or vars(_workspace_registry_source).get("_DEFAULT_BINDING_DISPLAY_CHECK")
        is not record
    ):
        return False
    checker, code, defaults, keywords = record
    if (
        type(checker) is not FunctionType
        or vars(_workspace_registry_source).get("_default_binding_display_current")
        is not checker
        or checker.__globals__ is not vars(_workspace_registry_source)
        or checker.__code__ is not code
        or checker.__defaults__ is not defaults
        or checker.__kwdefaults__ is not keywords
    ):
        return False
    return checker(service, workspace_id)


class _ConsoleRegistryDisplayReads:
    """Generation-keyed read-through view over the workspace registry.

    TASK-22201 (extending the TASK-21118 memo pattern): the Console run tick
    rebuilt its workspace context state up to six times per 0.2 s (see
    :class:`ConsoleTickWorkspaceBuilds`), and each build performed the
    registry's whole display read set as synchronous SQLite on the event
    loop -- measured at ~80 WorkspaceDB round-trips per settled tick. Every one of those reads is a pure function of registry
    tables that ``mutation_generation`` versions, so this view serves them
    from a cache revalidated against (service identity, generation) and every
    registry mutation anywhere in the app -- create, rename, archive,
    set-active, binding and membership writes -- invalidates it on the very
    next read.

    Contract details:

    * Only the four display reads are intercepted (``get_active_workspace``,
      ``list_workspaces``, ``list_runtime_bindings``,
      ``list_workspace_memberships``); every other attribute delegates to the
      wrapped service, so this object can stand in for it inside
      ``build_console_workspace_state``.
    * A raised read is never cached -- callers keep their existing degraded
      paths, and the next read retries live.
    * Doubles without a real ``int`` generation are never cached (a
      MagicMock's auto-attribute compares equal to itself forever and would
      freeze the view -- the TASK-21118 lesson), so reduced test doubles stay
      on live reads.
    * ADR-028 is preserved by construction: only the SQL is cached.
      ``display_state._safe_runtime_bindings`` still recomputes filesystem
      binding status straight from disk on every build.
    """

    __slots__ = ("_service", "_generation", "_cache")

    def __init__(self, service: Any) -> None:
        self._service = service
        self._generation: int | None = None
        self._cache: dict[tuple, Any] = {}

    @property
    def service(self) -> Any:
        """The wrapped registry service (identity checks by the owner)."""
        return self._service

    def _cacheable(self) -> bool:
        """Revalidate the cache against the service's mutation generation."""
        generation = getattr(self._service, "mutation_generation", None)
        if isinstance(generation, bool) or not isinstance(generation, int):
            self._cache.clear()
            self._generation = None
            return False
        if generation != self._generation:
            self._cache.clear()
            self._generation = generation
        return True

    def _read(self, key: tuple, method_name: str, *args: Any) -> Any:
        cacheable = self._cacheable()
        if cacheable and key in self._cache:
            return self._cache[key]
        value = getattr(self._service, method_name)(*args)
        if cacheable:
            self._cache[key] = value
        return value

    def get_active_workspace(self) -> Any:
        return self._read(("active",), "get_active_workspace")

    def list_workspaces(self, *, include_archived: bool = False) -> Any:
        if include_archived:
            # Rare (Settings archive lists); not worth a cache slot.
            return self._service.list_workspaces(include_archived=True)
        return self._read(("workspaces",), "list_workspaces")

    def list_runtime_bindings(self, workspace_id: str) -> Any:
        if _default_display_bindings_are_empty(self._service, workspace_id):
            return ()
        return self._read(
            ("bindings", str(workspace_id)), "list_runtime_bindings", workspace_id
        )

    def list_workspace_memberships(self, workspace_id: str) -> Any:
        return self._read(
            ("memberships", str(workspace_id)),
            "list_workspace_memberships",
            workspace_id,
        )

    def __getattr__(self, name: str) -> Any:
        # Private names never delegate: with ``__slots__`` a not-yet-bound
        # ``_service`` would otherwise recurse straight back through here.
        if name.startswith("_"):
            raise AttributeError(name)
        return getattr(self._service, name)


class ConsoleTickWorkspaceBuilds:
    """One run tick's shared workspace-context build (TASK-22201).

    ``_sync_native_console_chat_ui`` used to build
    ``_build_console_workspace_context_state()`` SIX times per 0.2 s tick
    (measured with a stack probe): the two rail-state legs, the
    workspace-context push, the control bar's and the agent section's
    inspector legs, and the settings summary's rail read. This object is
    created fresh for ONE tick by ``tick_workspace_build_scope`` and serves
    every build the tick's own task performs; each read revalidates the
    controller's volatile-input fingerprint, so:

    * a settled tick pays for exactly one build;
    * the PR #660 freshness ruling holds -- a session created/activated by
      ``_sync_console_native_session_tabs`` mid-tick changes the store
      fingerprint, and the workspace-context push and the visibility check
      rebuild rather than reuse the pre-await snapshot;
    * a ``None`` fingerprint (reduced doubles, any component failure) means
      every read builds live, exactly the pre-cache behavior.

    Task-scoped and never shared across ticks: ``accepts_current_task``
    admits only the coroutine task that opened the scope, so workers,
    message handlers, and search settles interleaving during the tick's
    awaits keep building live -- a mutation followed by a push can never be
    masked. Inputs outside the fingerprint changing DURING one tick are
    repainted by the next tick, at most 0.2 s later -- the same cadence
    every other tick-driven surface repaints at.
    """

    __slots__ = ("_controller", "_task", "_fingerprint", "_state", "_building")

    def __init__(self, controller: "ConsoleWorkspaceController") -> None:
        self._controller = controller
        try:
            self._task = asyncio.current_task()
        except RuntimeError:
            self._task = None
        self._fingerprint: tuple | None = None
        self._state: Any = None
        self._building = False

    def accepts_current_task(self) -> bool:
        """Whether the calling context is the tick task that owns this cache.

        Also False while the shared build itself is running (re-entrancy
        guard) and when the scope was opened outside any asyncio task.
        """
        if self._building or self._task is None:
            return False
        try:
            return asyncio.current_task() is self._task
        except RuntimeError:
            return False

    def state(self) -> Any:
        """Return the current context state, rebuilding when inputs changed."""
        controller = self._controller
        fingerprint = controller._console_workspace_build_fingerprint()
        if (
            self._state is not None
            and fingerprint is not None
            and fingerprint == self._fingerprint
        ):
            return self._state
        self._building = True
        try:
            state = controller._build_console_workspace_context_state()
        finally:
            self._building = False
        # Recomputed AFTER the build: building advances canonical-owner
        # bookkeeping some fingerprint components include, and the stored
        # token must describe the state actually cached.
        self._fingerprint = controller._console_workspace_build_fingerprint()
        self._state = state
        return state


def _availability_methods_current(owner, originals):
    """Select only the directly consumed original display callbacks."""
    return all(
        getattr(callback := getattr(owner, name, None), "__self__", None) is owner
        and getattr(callback, "__func__", None) is function
        and function.__code__ is code
        and function.__defaults__ is defaults
        and function.__kwdefaults__ is keywords
        for name, function, code, defaults, keywords in originals
    )


class _WorkspaceAvailabilityObsolete(RuntimeError):
    """A finite display read lost its original publisher."""


class ConsoleWorkspaceController:
    """Own Workspace lifecycle, resume, scope, and conversation browsing.

    The controller holds the canonical rich browser state and exposes the
    legacy Workspace search shape only as a compatibility projection. Its 57
    owned methods use explicit late-bound dependencies for non-Workspace
    services; Textual event binding, focus, and rendering remain on the screen.
    """

    def __init__(
        self,
        screen: "ChatScreen",
        *,
        app_instance: Any,
        chat_store_accessor: Callable[[], Any],
        current_chat_store_accessor: Callable[[], Any],
        current_conversation_id_accessor: Callable[[], str | None],
        native_session_rows_accessor: Callable[
            [ConsoleWorkspaceContextState], ConsoleWorkspaceContextState
        ],
        capture_draft_switch_snapshot: Callable[[], None],
        sync_chat_core_state: Callable[[], None],
        sync_native_console_chat_ui: Callable[[], Any],
        sync_temporary_chip: Callable[[], None],
        default_session_settings_accessor: Callable[[], Any],
        scope_picker_listers_accessor: Callable[[], tuple[Any, Any, Any]],
        active_native_session_accessor: Callable[[], Any],
        refresh_effective_scope_and_sync: Callable[[Any], Any],
        messages_from_conversation_tree_accessor: Callable[[dict], list],
        session_settings_for_resume_accessor: Callable[[Any], Any],
        inject_resume_agent_markers_accessor: Callable[[list, str], list],
        resolve_effective_scope_state: Callable[[Any], Any],
        sync_retrieval_scope_row: Callable[[], None],
        note_follow_intent: Callable[[], None],
        focus_composer_if_needed: Callable[..., None],
        conversation_section_config_accessor: Callable[[], dict],
        conversation_browser_config: Callable[[], dict[str, Any]],
        focus_conversation_search: Callable[[], None],
        sync_workspace_context: Callable[[], None],
        schedule_timer: Callable[[float, Callable[[], None]], Any],
        screen_running_accessor: Callable[[], bool],
        current_chat_controller_accessor: Callable[[], Any],
        fleet_unseen_ids_accessor: Callable[[], frozenset[str]],
        run_marker_with_unseen: Callable[[Any, Any, frozenset[str]], Any],
        broken_conversation_ids_accessor: Callable[[], set[str]],
        ensure_agent_bridge: Callable[[], Any],
        subagent_counts_for_rows: Callable[[Any, Iterable[Any]], dict[str, int]],
        conversation_browser_collapse_preferences: Callable[[], dict[str, bool]],
        wake_retry_poke: Callable[[], None] | None = None,
        workspace_tree_owner_accessor: Callable[[], object] | None = None,
        flat_conversation_owner_accessor: Callable[[], object] | None = None,
        screen_lifecycle_token_accessor: Callable[[], object] | None = None,
        persist_workspace_tree_expansion_preferences: (
            Callable[[list[str]], None] | None
        ) = None,
        session_id_for_browser_row: (
            Callable[[ConsoleConversationBrowserInputRow], str | None] | None
        ) = None,
        ensure_chat_controller: Callable[[], Any] | None = None,
        set_conversation_row_loading: Callable[[str, bool], None] | None = None,
        mark_conversation_row_broken: Callable[[str], None] | None = None,
        rail_body_height_accessor: Callable[[], int | None] | None = None,
        notify_character_navigation: Callable[..., None] | None = None,
        resolve_resumed_character_name: Callable[[int], Any] | None = None,
        resolve_resumed_persona_name: Callable[[str, str], Any] | None = None,
        begin_manual_read_visit: Callable[..., Any] | None = None,
        complete_manual_read_visit: Callable[..., None] | None = None,
        sync_session_titles: Callable[[], Awaitable[None]] | None = None,
        await_title_views: Callable[[], Awaitable[bool]] | None = None,
    ) -> None:
        """Bind canonical Workspace state and its late-bound dependencies.

        Framework services are read from ``screen`` when used. Browser data,
        configuration, scheduling, markers, sub-agent counts, focus, and final
        Workspace synchronization are supplied as named callables, keeping
        controller ownership explicit without snapshotting replaceable screen
        collaborators.

        Args:
            screen: Owning Console screen for retained framework services.
            sync_session_titles: Late-bound tab and transcript-header publisher.
            await_title_views: Mounted rail/tree publication receipt.
            app_instance: Application service container.
            chat_store_accessor: Resolve or create the Console chat store.
            current_chat_store_accessor: Return the current Console chat store.
            current_conversation_id_accessor: Return the active conversation id.
            native_session_rows_accessor: Add native session rows to Workspace state.
            capture_draft_switch_snapshot: Preserve the draft before switching.
            sync_chat_core_state: Refresh Console chat-core state.
            sync_native_console_chat_ui: Refresh the native Console UI.
            sync_temporary_chip: Refresh the temporary-chat chip.
            default_session_settings_accessor: Return default session settings.
            scope_picker_listers_accessor: Return scope-picker data providers.
            active_native_session_accessor: Return the active native session.
            refresh_effective_scope_and_sync: Refresh effective retrieval scope.
            messages_from_conversation_tree_accessor: Convert a saved message tree.
            session_settings_for_resume_accessor: Resolve resumed session settings.
            inject_resume_agent_markers_accessor: Add agent markers on resume.
            resolve_effective_scope_state: Resolve effective scope state.
            sync_retrieval_scope_row: Refresh the retrieval-scope row.
            note_follow_intent: Record that Console should follow the selection.
            focus_composer_if_needed: Restore composer focus when appropriate.
            conversation_section_config_accessor: Return legacy section config.
            conversation_browser_config: Return grouped-browser config.
            focus_conversation_search: Focus the browser search input.
            sync_workspace_context: Render current Workspace state.
            schedule_timer: Schedule a delayed browser callback.
            screen_running_accessor: Return whether the owning screen is running.
            current_chat_controller_accessor: Return the current chat controller.
            fleet_unseen_ids_accessor: Return unseen conversation ids.
            run_marker_with_unseen: Project unseen state into a run marker.
            broken_conversation_ids_accessor: Return non-openable conversation ids.
            ensure_agent_bridge: Return the Console agent bridge.
            subagent_counts_for_rows: Compute sub-agent counts for browser rows.
            conversation_browser_collapse_preferences: Return collapse preferences.
            wake_retry_poke: Optionally request a staged-wake retry after resume.
            workspace_tree_owner_accessor: Return the mounted Tree owner identity.
            flat_conversation_owner_accessor: Return the mounted flat owner identity.
            screen_lifecycle_token_accessor: Return the current screen mount identity.
            persist_workspace_tree_expansion_preferences: Persist the exact Tree
                disclosure set to durable Console configuration.
            session_id_for_browser_row: Resolve an already-open session for a row.
            ensure_chat_controller: Resolve or create the native chat controller.
            set_conversation_row_loading: Paint persisted-row loading state.
            mark_conversation_row_broken: Mark a missing persisted record.
            rail_body_height_accessor: Return the Console rail body height in
                terminal lines (or ``None`` before layout) so the browser's
                per-section/group visible-row cap can adapt to fill the
                available space.
            notify_character_navigation: Report a character-conversation
                activation result to the user; defaults to the app-level
                ``notify`` when not supplied.
            resolve_resumed_character_name: Optionally resolve a resumed
                character's display name from its live card (bare-controller/
                test construction keeps the persisted snapshot label).
            resolve_resumed_persona_name: Optionally resolve a resumed persona's
                display name from its live profile (bare-controller/test
                construction leaves the session unlabeled).
        """
        self._screen = screen
        self._begin_manual_read_visit = begin_manual_read_visit
        self._complete_manual_read_visit = complete_manual_read_visit
        self._notify_character_navigation = notify_character_navigation
        self.app_instance = app_instance
        self._conversation_rename_lock = asyncio.Lock()
        self._sync_session_titles_fn = sync_session_titles
        self._await_title_views_fn = await_title_views
        self._chat_store_accessor = chat_store_accessor
        self._current_chat_store_accessor = current_chat_store_accessor
        self._current_conversation_id_accessor = current_conversation_id_accessor
        self._native_session_rows_accessor = native_session_rows_accessor
        self._capture_draft_switch_snapshot_fn = capture_draft_switch_snapshot
        self._sync_chat_core_state_fn = sync_chat_core_state
        self._sync_native_console_chat_ui_fn = sync_native_console_chat_ui
        self._sync_temporary_chip_fn = sync_temporary_chip
        self._default_session_settings_accessor = default_session_settings_accessor
        self._scope_picker_listers_accessor = scope_picker_listers_accessor
        self._active_native_session_accessor = active_native_session_accessor
        self._refresh_effective_scope_and_sync_fn = refresh_effective_scope_and_sync
        self._messages_from_conversation_tree_accessor = (
            messages_from_conversation_tree_accessor
        )
        self._session_settings_for_resume_accessor = (
            session_settings_for_resume_accessor
        )
        self._resolve_resumed_character_name_fn = resolve_resumed_character_name
        self._resolve_resumed_persona_name_fn = resolve_resumed_persona_name
        self._inject_resume_agent_markers_accessor = (
            inject_resume_agent_markers_accessor
        )
        self._resolve_effective_scope_state_fn = resolve_effective_scope_state
        self._sync_retrieval_scope_row_fn = sync_retrieval_scope_row
        self._note_follow_intent_fn = note_follow_intent
        self._focus_composer_if_needed_fn = focus_composer_if_needed
        self._conversation_section_config_accessor = (
            conversation_section_config_accessor
        )
        self._conversation_browser_config_fn = conversation_browser_config
        self._focus_conversation_search_fn = focus_conversation_search
        self._sync_workspace_context_fn = sync_workspace_context
        self._schedule_timer_fn = schedule_timer
        self._screen_running_accessor = screen_running_accessor
        self._current_chat_controller_accessor = current_chat_controller_accessor
        self._fleet_unseen_ids_accessor = fleet_unseen_ids_accessor
        self._run_marker_with_unseen_fn = run_marker_with_unseen
        self._broken_conversation_ids_accessor = broken_conversation_ids_accessor
        self._ensure_agent_bridge_fn = ensure_agent_bridge
        self._subagent_counts_for_rows_fn = subagent_counts_for_rows
        self._conversation_browser_collapse_preferences_fn = (
            conversation_browser_collapse_preferences
        )
        #: task-15864 AC#2: `ConsoleFleetLifecycleController._poke_console_wake_retry` -- resume
        #: is the one loader of persisted conversations into sessions, so
        #: session-open becomes a wake retry trigger here. Optional so the
        #: pre-existing direct-construction tests need no new kwarg.
        self._wake_retry_poke_fn = wake_retry_poke
        self._workspace_tree_owner_accessor = workspace_tree_owner_accessor
        self._flat_conversation_owner_accessor = flat_conversation_owner_accessor
        self._screen_lifecycle_token_accessor = screen_lifecycle_token_accessor
        self._persist_workspace_tree_expansion_preferences = (
            persist_workspace_tree_expansion_preferences
        )
        self._session_id_for_browser_row_fn = session_id_for_browser_row or (
            lambda _row: None
        )
        self._ensure_chat_controller_fn = (
            ensure_chat_controller or current_chat_controller_accessor
        )
        self._set_conversation_row_loading_fn = set_conversation_row_loading or (
            lambda _conversation_id, _loading: None
        )
        self._mark_conversation_row_broken_fn = mark_conversation_row_broken or (
            lambda _conversation_id: None
        )
        self._rail_body_height_accessor = rail_body_height_accessor
        self._workspace_files_visit_workspace_id: str | None = None
        self._workspace_files_modal: ConsoleWorkspaceFilesModal | None = None
        self._workspace_files_attention_generation = 0
        self._workspace_files_admission_lock = asyncio.Lock()
        self._workspace_files_admission_claim: str | None = None
        # Folder binding status may touch the filesystem.  Context rendering
        # runs on Textual's event loop, so it reads only this immutable cache;
        # one controller-owned worker refreshes it off-loop below.
        self._workspace_files_availability_by_id: Mapping[str, bool] = MappingProxyType(
            {}
        )
        self._workspace_files_runtime_bindings_by_id: Mapping[
            str, tuple[WorkspaceRuntimeBinding, ...]
        ] = MappingProxyType({})
        self._workspace_files_availability_requested_ids: tuple[str, ...] = ()
        self._workspace_files_availability_generation = 0
        self._workspace_files_availability_refresh_in_flight = False
        self._workspace_files_availability_cached_at = 0.0
        self._preparation_reads = set()
        self._workspace_files_availability_task = None

        self._workspace_tree_search = SearchAttemptState()
        self._flat_conversation_search = SearchAttemptState()
        self._workspace_page_attempts: dict[str, PageAttemptState] = {}
        self._collapsed_workspace_ids: set[str] = set()
        self._workspace_membership_rows: dict[
            str, tuple[ConsoleConversationBrowserInputRow, ...]
        ] = {}
        self._canonical_membership_revision = 0
        self._canonical_owner_observations: dict[str, str] = {}

        # Canonical flat-browser state. Legacy workspace-search names below are
        # aliases/projections, never a second writer or backing row store.
        self._console_persisted_rows_cache = None
        self._console_persisted_rows_cache_key = None
        self._console_persisted_rows_cache_at = 0.0
        self._console_persisted_rows_cache_token = 0
        self._console_persisted_rows_refresh_key = None
        self._console_conversation_browser_query = ""
        self._console_conversation_browser_search_timer = None
        self._console_conversation_browser_search_token = 0
        self._console_conversation_browser_rows: tuple[
            ConsoleConversationBrowserInputRow, ...
        ] = ()
        self._console_conversation_browser_total = None
        self._console_conversation_browser_error = ""
        self._console_workspace_conversation_workspace_id: str | None = None
        # task-15471: serializes star toggles now that the durable write
        # runs off the loop -- two rapid presses must queue (each resolving
        # current truth before toggling), never race two pool threads into
        # a stale double-star.
        self._console_star_toggle_lock = asyncio.Lock()
        # PR #2480 review (#7): TTL cache for the batched appearance map so
        # recurring merge calls do not re-query per sync; cleared on write.
        self._console_appearance_map_cache: dict[str, tuple[str, str]] | None = None
        self._console_appearance_map_cached_at: float = 0.0
        self._character_conversation_activation_coordinator = None

    @property
    def _character_conversation_activation(self):
        """Create the exact activation owner on the first activation, not boot."""
        from ...Chat.console_conversation_activation import (
            ConsoleConversationActivationCoordinator,
        )

        if self._character_conversation_activation_coordinator is None:
            self._character_conversation_activation_coordinator = ConsoleConversationActivationCoordinator[
                str | None
            ](
                capture_state=lambda: (
                    self._ensure_console_chat_store().active_session_id
                ),
                revalidate=self._revalidate_character_conversation_target,
                open_target=self._open_character_conversation_activation,
                rollback_opened_target=self._rollback_character_conversation_activation,
                restore_state=self._restore_character_conversation_prior_session,
                exact_target_visible=self._character_conversation_target_visible,
                mutation_lock=getattr(
                    getattr(self.app_instance, "console_runtime", None),
                    "character_conversation_activation_lock",
                    None,
                ),
            )
        return self._character_conversation_activation_coordinator

    @property
    def _console_conversation_browser_query(self) -> str:
        return self._flat_conversation_search.query

    @_console_conversation_browser_query.setter
    def _console_conversation_browser_query(self, value: str) -> None:
        self._flat_conversation_search.query = str(value or "")

    @property
    def _console_conversation_browser_search_timer(self) -> Any:
        return self._flat_conversation_search.debounce

    @_console_conversation_browser_search_timer.setter
    def _console_conversation_browser_search_timer(self, value: Any) -> None:
        self._flat_conversation_search.debounce = value

    @property
    def _console_conversation_browser_search_token(self) -> int:
        return self._flat_conversation_search.generation

    @_console_conversation_browser_search_token.setter
    def _console_conversation_browser_search_token(self, value: int) -> None:
        self._flat_conversation_search.generation = int(value)

    @property
    def _console_conversation_browser_rows(
        self,
    ) -> tuple[ConsoleConversationBrowserInputRow, ...]:
        return self._flat_conversation_search.rows

    @_console_conversation_browser_rows.setter
    def _console_conversation_browser_rows(
        self, value: Iterable[ConsoleConversationBrowserInputRow]
    ) -> None:
        self._flat_conversation_search.rows = tuple(value)

    @property
    def _console_conversation_browser_total(self) -> int | None:
        return self._flat_conversation_search.total

    @_console_conversation_browser_total.setter
    def _console_conversation_browser_total(self, value: int | None) -> None:
        self._flat_conversation_search.total = value

    @property
    def _console_conversation_browser_error(self) -> str:
        return self._flat_conversation_search.error

    @_console_conversation_browser_error.setter
    def _console_conversation_browser_error(self, value: str) -> None:
        self._flat_conversation_search.error = str(value or "")

    @property
    def _console_workspace_conversation_query(self) -> str:
        return self._console_conversation_browser_query

    @_console_workspace_conversation_query.setter
    def _console_workspace_conversation_query(self, value: str) -> None:
        self._console_conversation_browser_query = value

    @property
    def _console_workspace_conversation_search_timer(self) -> Any:
        return self._console_conversation_browser_search_timer

    @_console_workspace_conversation_search_timer.setter
    def _console_workspace_conversation_search_timer(self, value: Any) -> None:
        self._console_conversation_browser_search_timer = value

    @property
    def _console_workspace_conversation_search_token(self) -> int:
        return self._console_conversation_browser_search_token

    @_console_workspace_conversation_search_token.setter
    def _console_workspace_conversation_search_token(self, value: int) -> None:
        self._console_conversation_browser_search_token = value

    @property
    def _console_workspace_conversation_search_rows(
        self,
    ) -> tuple[ConsoleWorkspaceConversationRow, ...]:
        return tuple(
            ConsoleWorkspaceConversationRow(
                conversation_id=str(row.conversation_id or ""),
                title=row.title,
                status=row.status,
                selected=row.selected,
            )
            for row in self._console_conversation_browser_rows
        )

    @_console_workspace_conversation_search_rows.setter
    def _console_workspace_conversation_search_rows(
        self, value: Iterable[ConsoleWorkspaceConversationRow]
    ) -> None:
        self._console_conversation_browser_rows = tuple(
            ConsoleConversationBrowserInputRow(
                row_key=row.conversation_id,
                conversation_id=row.conversation_id,
                native_session_id=None,
                title=row.title,
                scope_type="workspace",
                workspace_id=DEFAULT_WORKSPACE_ID,
                workspace_label="Chats",
                status=row.status,
                selected=row.selected,
                source_kind="persisted",
            )
            for row in value
        )

    @property
    def _console_workspace_conversation_search_total(self) -> int | None:
        return self._console_conversation_browser_total

    @_console_workspace_conversation_search_total.setter
    def _console_workspace_conversation_search_total(self, value: int | None) -> None:
        self._console_conversation_browser_total = value

    @property
    def _console_workspace_conversation_search_error(self) -> str:
        return self._console_conversation_browser_error

    @_console_workspace_conversation_search_error.setter
    def _console_workspace_conversation_search_error(self, value: str) -> None:
        self._console_conversation_browser_error = value

    # -- Framework services (kind 1: live-read via `@property`) ------------

    @property
    def run_worker(self) -> Any:
        """`Screen.run_worker`, bound. See `__init__`'s docstring for why
        this is a property rather than a value snapshotted once."""
        return self._screen.run_worker

    @property
    def push_screen(self) -> Any:
        """`Screen.app.push_screen`, bound. See `__init__`'s docstring."""
        return self._screen.app.push_screen

    def open_workspace_files_modal(
        self,
        *,
        inspector: WorkspaceFilesService,
        inspected_workspace_id: str,
        inspected_workspace_name: str,
        active_workspace_id: str | None,
        active_workspace_name: str,
        bindings: Sequence[WorkspaceFilesBinding],
        attention: WorkspaceFilesAttention | None = None,
        on_back_to_console: Callable[[], None] | None = None,
        on_visit_closed: Callable[[], None] | None = None,
    ) -> Any:
        """Push one already-resolved, read-only Workspace Files visit.

        This deliberately accepts only presentation-safe identities and the
        narrow read-only inspector supplied by its future entry owner.  It
        neither reads the registry nor updates Console workspace/session/
        context state; Task 3 owns admission and resolution from its controls.

        Args:
            inspector: Narrow read-only filesystem service for this visit.
            inspected_workspace_id: Stable identity of the workspace being viewed.
            inspected_workspace_name: Presentation name of the viewed workspace.
            active_workspace_id: Stable identity of the unchanged active workspace.
            active_workspace_name: Presentation name of the active workspace.
            bindings: Presentation-safe binding scopes for the viewed workspace.
            attention: Optional privacy-minimized Console attention snapshot.
            on_back_to_console: Optional callback after explicit Console return.
            on_visit_closed: Optional callback after terminal visit teardown.

        Returns:
            The pushed, pinned Workspace Files modal.
        """
        from ...Widgets.Console.console_workspace_files_modal import (
            ConsoleWorkspaceFilesModal,
        )

        safe_bindings = tuple(
            binding
            if (
                binding.scope is None
                or binding.scope.workspace_id == inspected_workspace_id
            )
            else replace(
                binding,
                scope=None,
                available=False,
                availability_copy="Unavailable: binding belongs to a different workspace.",
            )
            for binding in bindings
        )
        modal = ConsoleWorkspaceFilesModal(
            inspector=inspector,
            inspected_workspace_id=inspected_workspace_id,
            inspected_workspace_name=inspected_workspace_name,
            active_workspace_id=active_workspace_id,
            active_workspace_name=active_workspace_name,
            bindings=safe_bindings,
            attention=attention,
            on_back_to_console=on_back_to_console,
            on_visit_closed=on_visit_closed,
        )
        self.push_screen(modal)
        return modal

    async def request_workspace_files(
        self, workspace_id: str, *, expected_available: bool = False
    ) -> None:
        """Admit one non-activating Workspace Files visit for ``workspace_id``.

        Registry and binding inspection happens off the event loop.  The only
        main-loop effects are the modal push/focus and a generic notification;
        neither changes the Console workspace, session, or staged context.

        Args:
            workspace_id: Stable identity of the workspace to inspect.
            expected_available: Whether the clicked cached route previously
                advertised an attached folder, allowing recovery to open if the
                binding changed during admission.

        Returns:
            None after refusal, focus recovery, or modal admission.
        """
        requested_id = str(workspace_id or DEFAULT_WORKSPACE_ID).strip()
        size = self._screen.size
        if size.width < 80 or size.height < 24:
            self.app_instance.notify(WORKSPACE_FILES_MINIMUM_COPY, severity="warning")
            return

        async with self._workspace_files_admission_lock:
            modal = self._workspace_files_modal
            if modal is not None:
                if self._workspace_files_visit_workspace_id == requested_id:
                    if modal.is_mounted:
                        modal.query_one("#console-workspace-files-back").focus()
                else:
                    self.app_instance.notify(
                        WORKSPACE_FILES_OTHER_VISIT_COPY, severity="warning"
                    )
                return
            if self._workspace_files_admission_claim is not None:
                if self._workspace_files_admission_claim != requested_id:
                    self.app_instance.notify(
                        WORKSPACE_FILES_OTHER_VISIT_COPY, severity="warning"
                    )
                return
            self._workspace_files_admission_claim = requested_id
        try:
            resolution = await asyncio.to_thread(
                self._resolve_workspace_files_visit, requested_id
            )
            if resolution is None or (
                not resolution.had_bindings and not expected_available
            ):
                self.app_instance.notify(
                    WORKSPACE_FILES_NO_FOLDERS_COPY, severity="warning"
                )
                return

            attention = self._workspace_files_attention_snapshot()

            def _closed() -> None:
                if self._workspace_files_visit_workspace_id == resolution.workspace_id:
                    self._workspace_files_visit_workspace_id = None
                    self._workspace_files_modal = None

            async with self._workspace_files_admission_lock:
                if self._workspace_files_modal is not None:
                    # A closing visit owns the ledger until its awaited
                    # unmount callback clears it; never retarget it.
                    return
                self._workspace_files_visit_workspace_id = resolution.workspace_id
                try:
                    from ...Workspaces.file_inspector import WorkspaceFileInspector

                    self._workspace_files_modal = self.open_workspace_files_modal(
                        inspector=_WorkspaceFilesVisitService(
                            WorkspaceFileInspector(
                                getattr(
                                    self.app_instance,
                                    "workspace_registry_service",
                                    None,
                                )
                            ),
                            self,
                        ),
                        inspected_workspace_id=resolution.workspace_id,
                        inspected_workspace_name=resolution.workspace_name,
                        active_workspace_id=resolution.active_workspace_id,
                        active_workspace_name=resolution.active_workspace_name,
                        bindings=resolution.bindings,
                        attention=attention,
                        on_visit_closed=_closed,
                    )
                except Exception:
                    self._workspace_files_visit_workspace_id = None
                    self._workspace_files_modal = None
                    raise
        finally:
            # Cancellation is a normal outcome for a Textual exclusive
            # worker. Claim access is confined to this event loop, so the
            # await-free compare-and-clear is atomic with respect to other
            # request coroutines. Reacquiring the lock here would make the
            # cleanup itself interruptible by a second cancellation.
            if self._workspace_files_admission_claim == requested_id:
                self._workspace_files_admission_claim = None

    def set_exclusion(
        self, binding_id: str, relative_path: str, excluded: bool
    ) -> None:
        """Apply or remove one binding exclusion through the workspace registry.

        The Workspace Files visit service delegates here so exclusion edits
        reuse the registry's validation (spec §1) while the modal keeps its
        narrow service boundary.  Callers run this off the Textual event
        loop, matching the visit admission's registry discipline.

        Args:
            binding_id: Stable local-folder binding identity.
            relative_path: Binding-relative path to exclude or restore.
            excluded: True to hide the path from agent file tools, False to
                restore it.

        Raises:
            WorkspaceRegistryServiceError: If the registry is unavailable,
                the binding is unknown, or the path fails exclusion
                validation; callers translate failures to status copy.
        """
        registry = getattr(self.app_instance, "workspace_registry_service", None)
        if registry is None:
            raise WorkspaceRegistryServiceError("Workspace registry is unavailable.")
        binding = registry.get_runtime_binding(binding_id)
        if binding is None:
            raise WorkspaceRegistryServiceError(
                "Folder binding not found in this workspace."
            )
        workspace_id = str(binding.workspace_id)
        if excluded:
            registry.add_binding_exclusion(workspace_id, binding_id, relative_path)
        else:
            registry.remove_binding_exclusion(workspace_id, binding_id, relative_path)

    def _resolve_workspace_files_visit(
        self, workspace_id: str
    ) -> _WorkspaceFilesResolution | None:
        """Read current workspace/bindings and capture safe scopes off-loop."""
        from ...Widgets.Console.console_workspace_files_modal import (
            WorkspaceFilesBinding,
        )
        from ...Workspaces.file_inspector import (
            ScopeCaptureError,
            WorkspaceFileInspector,
        )

        registry = getattr(self.app_instance, "workspace_registry_service", None)
        if registry is None or workspace_id == DEFAULT_WORKSPACE_ID:
            return None
        try:
            workspace = registry.get_workspace(workspace_id)
            if workspace is None or workspace.archived:
                return None
            raw_bindings = tuple(registry.list_folder_bindings(workspace_id))
            active = registry.get_active_workspace()
        except Exception:
            return None
        inspector = WorkspaceFileInspector(registry)
        bindings: list[WorkspaceFilesBinding] = []
        for binding in raw_bindings:
            access = str(getattr(binding, "metadata", {}).get("access", "ro")).lower()
            access_label = "Read/write" if access == "rw" else "Read-only"
            exclusions = tuple(
                entry.path for entry in binding_exclusion_entries(binding)
            )
            try:
                scope = inspector.capture_binding(workspace_id, binding.binding_id)
            except ScopeCaptureError:
                bindings.append(
                    WorkspaceFilesBinding(
                        binding_id=binding.binding_id,
                        label=binding.label,
                        scope=None,
                        access_label=access_label,
                        available=False,
                        availability_copy="Unavailable: folder access changed.",
                        exclusions=exclusions,
                    )
                )
            else:
                bindings.append(
                    WorkspaceFilesBinding(
                        binding_id=binding.binding_id,
                        label=binding.label,
                        scope=scope,
                        access_label=access_label,
                        exclusions=exclusions,
                    )
                )
        return _WorkspaceFilesResolution(
            workspace_id=workspace.workspace_id,
            workspace_name=workspace.name,
            active_workspace_id=(active.workspace_id if active is not None else None),
            active_workspace_name=(
                active.name if active is not None else "Local Default"
            ),
            bindings=tuple(bindings),
            had_bindings=bool(raw_bindings),
        )

    def _workspace_files_attention_snapshot(self) -> WorkspaceFilesAttention:
        """Return only generic Console-attention copy; never payload details."""
        from ...Widgets.Console.console_workspace_files_modal import (
            WorkspaceFilesAttention,
        )

        count_getter = getattr(self._screen, "_console_pending_approval_count", None)
        count = int(count_getter()) if callable(count_getter) else 0
        controller = self._current_chat_controller_accessor()
        run_state = getattr(controller, "run_state", None)
        status = str(getattr(run_state, "status", "") or "").casefold()
        # These all derive from existing Console state: run status and the
        # durable fleet-unseen marker. No raw tool/approval payload crosses
        # this boundary.
        blocked = "block" in status or "approval" in status
        failed = "fail" in status or "error" in status
        new_activity = bool(self._fleet_unseen_ids_accessor())
        if count:
            noun = "approval" if count == 1 else "approvals"
            return WorkspaceFilesAttention(
                f"Console needs attention · {count} {noun} waiting",
                pending_approval_count=count,
                has_blocked_activity=blocked,
                has_failed_activity=failed,
                has_new_activity=new_activity,
            )
        if blocked or failed or new_activity:
            return WorkspaceFilesAttention(
                "Console has new activity",
                has_blocked_activity=blocked,
                has_failed_activity=failed,
                has_new_activity=new_activity,
            )
        return WorkspaceFilesAttention()

    def update_workspace_files_attention(self) -> None:
        """Publish one monotonically ordered generic attention snapshot.

        Returns:
            None after publishing to an open visit or finding no active visit.
        """
        modal = self._workspace_files_modal
        if modal is None:
            return
        self._workspace_files_attention_generation += 1
        modal.update_attention(
            self._workspace_files_attention_snapshot(),
            self._workspace_files_attention_generation,
        )

    @property
    def call_after_refresh(self) -> Any:
        """`Screen.call_after_refresh`, bound. See `__init__`'s docstring."""
        return self._screen.call_after_refresh

    # -- Sibling clusters' reach-backs (kind 2) -----------------------------

    @property
    def _pending_console_launch_context(self) -> Optional[ConsoleLiveWorkLaunch]:
        """The staged-evidence cluster's own attribute (not extracted this
        wave). Live `@property` through `screen`, never snapshotted."""
        return self._screen._pending_console_launch_context

    @property
    def _console_agent_drilldown_run_id(self) -> str | None:
        """The sub-agent drill-in cluster's own attribute. Read+write:
        the moved resume body clears it unconditionally on every resume."""
        return self._screen._console_agent_drilldown_run_id

    @_console_agent_drilldown_run_id.setter
    def _console_agent_drilldown_run_id(self, value: str | None) -> None:
        self._screen._console_agent_drilldown_run_id = value

    # -- Named constructor dependencies (kind 3) ----------------------------
    #
    # Each property below is a thin wrapper around a stored callable, kept
    # under the SAME name the original `ChatScreen` method/attribute used --
    # see `__init__`'s docstring. Two shapes:
    #
    # - The original was a METHOD CALL (`self._name(...)`): the property
    #   returns the stored callable itself, unbound-called by the moved
    #   body exactly as before (`self._name(...)` still resolves, and a
    #   bare reference like `self.call_after_refresh(self._name)` also
    #   still works, since the property hands back the same callable
    #   object either way).
    # - The original was a PLAIN ATTRIBUTE READ (`self._name`, no `()`):
    #   the property CALLS the stored accessor immediately and returns the
    #   value, matching the bare-read call shape (`_console_chat_store`
    #   only).

    @property
    def _ensure_console_chat_store(self) -> Any:
        return self._chat_store_accessor

    @property
    def _console_chat_store(self) -> Any:
        return self._current_chat_store_accessor()

    @property
    def _current_console_conversation_id(self) -> Any:
        return self._current_conversation_id_accessor

    @property
    def _with_native_console_session_rows(self) -> Any:
        return self._native_session_rows_accessor

    @property
    def _capture_console_draft_switch_snapshot(self) -> Any:
        return self._capture_draft_switch_snapshot_fn

    @property
    def _sync_console_chat_core_state(self) -> Any:
        return self._sync_chat_core_state_fn

    @property
    def _sync_native_console_chat_ui(self) -> Any:
        return self._sync_native_console_chat_ui_fn

    @property
    def _sync_console_temporary_chip(self) -> Any:
        return self._sync_temporary_chip_fn

    @property
    def _default_console_session_settings(self) -> Any:
        return self._default_session_settings_accessor

    def _blank_console_session_settings(self) -> Any:
        """Build config-owned defaults for an eligible workspace blank chat."""
        app_config = getattr(self.app_instance, "app_config", {})
        if not isinstance(app_config, Mapping):
            app_config = {}
        return blank_console_session_settings(app_config)

    def _console_new_chat_default_generation(self) -> int:
        """Return the current app-owned explicit-default generation."""
        generation = getattr(
            self.app_instance,
            "console_new_chat_default_generation",
            0,
        )
        return generation if type(generation) is int and generation >= 0 else 0

    @property
    def _console_scope_picker_listers(self) -> Any:
        return self._scope_picker_listers_accessor

    @property
    def _active_native_console_session(self) -> Any:
        return self._active_native_session_accessor

    @property
    def _refresh_console_effective_scope_and_sync(self) -> Any:
        return self._refresh_effective_scope_and_sync_fn

    @property
    def _console_messages_from_conversation_tree(self) -> Any:
        return self._messages_from_conversation_tree_accessor

    @property
    def _console_session_settings_for_resume(self) -> Any:
        return self._session_settings_for_resume_accessor

    @property
    def _resolve_resumed_character_name(self) -> Any:
        resolver = self._resolve_resumed_character_name_fn
        if resolver is None:
            # Bare-controller/test construction: live re-resolution is
            # unavailable, so the persisted snapshot label stands.
            async def _unresolved(_character_id: int) -> str:
                return ""

            return _unresolved
        return resolver

    @property
    def _resolve_resumed_persona_name(self) -> Any:
        resolver = self._resolve_resumed_persona_name_fn
        if resolver is None:
            # Bare-controller/test construction: best-effort resume simply
            # leaves the session unlabeled.
            async def _unresolved(_persona_id: str, _runtime_backend: str) -> str:
                return ""

            return _unresolved
        return resolver

    @property
    def _inject_resume_agent_markers(self) -> Any:
        return self._inject_resume_agent_markers_accessor

    @property
    def _resolve_console_effective_scope_state(self) -> Any:
        return self._resolve_effective_scope_state_fn

    @property
    def _sync_console_retrieval_scope_row(self) -> Any:
        return self._sync_retrieval_scope_row_fn

    @property
    def _note_console_follow_intent(self) -> Any:
        return self._note_follow_intent_fn

    @property
    def _focus_console_composer_if_needed(self) -> Any:
        return self._focus_composer_if_needed_fn

    @property
    def _console_conversation_section_config(self) -> Any:
        return self._conversation_section_config_accessor

    @property
    def _console_conversation_browser_config(self) -> Any:
        """The injected `conversation_browser_config`. The config TREE stays
        on `ChatScreen` (it holds rail-state and search preferences this
        cluster does not own); only the grouped-browser collapse write below
        moved here, since nothing on the screen calls it. See `__init__`'s
        docstring."""
        return self._conversation_browser_config_fn

    def _set_console_conversation_browser_group_collapsed(
        self,
        group_id: str,
        collapsed: bool,
    ) -> None:
        """Store one grouped browser collapse preference.

        Args:
            group_id: The browser group whose state is being recorded; blank
                or whitespace-only ids are ignored.
            collapsed: True to record the group as collapsed.
        """
        normalized_group_id = str(group_id or "").strip()
        if not normalized_group_id:
            return
        browser_config = self._console_conversation_browser_config()
        collapsed_groups = browser_config.get("collapsed_groups")
        if not isinstance(collapsed_groups, dict):
            collapsed_groups = {}
            browser_config["collapsed_groups"] = collapsed_groups
        collapsed_groups[normalized_group_id] = bool(collapsed)

    def workspace_tree_expansion_preferences(self) -> frozenset[str] | None:
        """Return the persisted disclosure set, preserving explicit emptiness."""

        raw = self._console_conversation_browser_config().get("expanded_workspace_ids")
        if not isinstance(raw, (list, tuple, set, frozenset)):
            return None
        return frozenset(
            workspace_id for value in raw if (workspace_id := str(value or "").strip())
        )

    def set_workspace_tree_expansion_preferences(
        self, workspace_ids: frozenset[str]
    ) -> None:
        """Persist the exact non-search disclosure preference set."""

        serialized = sorted(
            str(workspace_id).strip()
            for workspace_id in workspace_ids
            if str(workspace_id).strip()
        )
        self._console_conversation_browser_config()["expanded_workspace_ids"] = (
            serialized
        )
        callback = self._persist_workspace_tree_expansion_preferences
        if callback is not None:
            callback(serialized)

    @property
    def _focus_console_workspace_conversation_search(self) -> Any:
        """Stays on `ChatScreen` (DOM: `query_one`). See module docstring."""
        return self._focus_conversation_search_fn

    @property
    def _sync_console_workspace_context(self) -> Any:
        """Stays on `ChatScreen` (DOM: `query_one`/`query`). See module
        docstring."""
        return self._sync_workspace_context_fn

    @property
    def _schedule_console_browser_timer(self) -> Any:
        return self._schedule_timer_fn

    @property
    def _console_chat_controller(self) -> Any:
        return self._current_chat_controller_accessor()

    @property
    def _console_fleet_unseen_ids(self) -> Any:
        return self._fleet_unseen_ids_accessor

    @property
    def _console_run_marker_with_unseen(self) -> Any:
        return self._run_marker_with_unseen_fn

    @property
    def _console_broken_conversation_ids(self) -> set[str]:
        return self._broken_conversation_ids_accessor()

    @property
    def _ensure_console_agent_bridge(self) -> Any:
        return self._ensure_agent_bridge_fn

    @property
    def _console_subagent_counts_for_rows(self) -> Any:
        return self._subagent_counts_for_rows_fn

    @property
    def _console_conversation_browser_collapse_preferences(self) -> Any:
        return self._conversation_browser_collapse_preferences_fn

    def _console_rail_body_height(self) -> int | None:
        accessor = self._rail_body_height_accessor
        return accessor() if accessor is not None else None

    def _workspace_tree_owner_token(self) -> object | None:
        accessor = self._workspace_tree_owner_accessor
        return accessor() if accessor is not None else None

    def _flat_conversation_owner_token(self) -> object:
        accessor = self._flat_conversation_owner_accessor
        return accessor() if accessor is not None else self._screen

    def _screen_lifecycle_token(self) -> object:
        accessor = self._screen_lifecycle_token_accessor
        return accessor() if accessor is not None else self._screen

    async def refresh_workspace_tree_search(self, query: str) -> None:
        """Run one full-scope named-workspace search attempt."""
        lane = self._workspace_tree_search
        lane.query = str(query or "")
        lane.generation += 1
        generation = lane.generation
        owner_token = self._workspace_tree_owner_token()
        lifecycle_token = self._screen_lifecycle_token()
        request_key = (
            "workspaces",
            lane.query,
            generation,
            owner_token,
            lifecycle_token,
            self._canonical_membership_revision,
        )
        lane.request_key = request_key
        lane.error = ""
        lane.retry_query = None
        if self._screen_running_accessor():
            self._sync_console_workspace_context()
        try:
            rows, total = await self._load_workspace_tree_search_rows(lane.query)
        except Exception:
            if self._workspace_search_attempt_is_current(request_key):
                lane.error = "Workspace search is unavailable."
                lane.retry_query = lane.query
            if lane.request_key == request_key:
                lane.request_key = None
                if self._screen_running_accessor():
                    self._sync_console_workspace_context()
            return
        if not self._workspace_search_attempt_is_current(request_key):
            if lane.request_key == request_key:
                lane.request_key = None
                if self._screen_running_accessor():
                    self._sync_console_workspace_context()
            return
        lane.rows = self._merge_console_browser_rows(rows)
        self._record_canonical_owner_rows(lane.rows)
        lane.total = max(len(lane.rows), int(total or 0))
        lane.cache = {lane.query: (lane.rows, lane.total)}
        lane.settled_rows = lane.rows
        lane.settled_total = lane.total
        lane.settled_query = lane.query
        lane.error = ""
        lane.retry_query = None
        lane.request_key = None
        self._sync_console_workspace_context()

    async def refresh_flat_conversation_search(self, query: str) -> None:
        """Run one Default/unassigned search attempt independently."""
        lane = self._flat_conversation_search
        lane.query = str(query or "")
        lane.generation += 1
        generation = lane.generation
        owner_token = self._flat_conversation_owner_token()
        lifecycle_token = self._screen_lifecycle_token()
        request_key = (
            "conversations",
            lane.query,
            generation,
            owner_token,
            lifecycle_token,
            self._canonical_membership_revision,
        )
        lane.request_key = request_key
        lane.error = ""
        lane.retry_query = None
        try:
            rows, total = await self._load_flat_conversation_search_rows(lane.query)
        except Exception:
            if self._flat_search_attempt_is_current(request_key):
                lane.error = "Conversation search is unavailable."
                lane.retry_query = lane.query
            if lane.request_key == request_key:
                lane.request_key = None
                if self._screen_running_accessor():
                    self._sync_console_workspace_context()
            return
        if not self._flat_search_attempt_is_current(request_key):
            if lane.request_key == request_key:
                lane.request_key = None
                if self._screen_running_accessor():
                    self._sync_console_workspace_context()
            return
        lane.rows = self._merge_console_browser_rows(
            row for row in rows if self._row_belongs_to_flat_projection(row)
        )
        self._record_canonical_owner_rows(lane.rows)
        lane.total = max(len(lane.rows), int(total or 0))
        lane.cache = {lane.query: (lane.rows, lane.total)}
        lane.settled_rows = lane.rows
        lane.settled_total = lane.total
        lane.settled_query = lane.query
        lane.error = ""
        lane.retry_query = None
        lane.request_key = None
        self._sync_console_workspace_context()

    async def retry_workspace_tree_search(self) -> None:
        """Replace the failed workspace-search generation, if any."""
        query = self._workspace_tree_search.retry_query
        if query is not None:
            await self.refresh_workspace_tree_search(query)

    async def retry_flat_conversation_search(self) -> None:
        """Replace the failed flat-search generation, if any."""
        query = self._flat_conversation_search.retry_query
        if query is not None:
            await self.refresh_flat_conversation_search(query)

    def _workspace_search_attempt_is_current(
        self, request_key: tuple[str, str, int, object, object, int]
    ) -> bool:
        lane = self._workspace_tree_search
        return bool(
            self._screen_running_accessor()
            and lane.request_key == request_key
            and lane.generation == request_key[2]
            and lane.query == request_key[1]
            and self._workspace_tree_owner_token() is request_key[3]
            and self._screen_lifecycle_token() is request_key[4]
            and self._canonical_membership_revision == request_key[5]
        )

    def _flat_search_attempt_is_current(
        self, request_key: tuple[str, str, int, object, object, int]
    ) -> bool:
        lane = self._flat_conversation_search
        return bool(
            self._screen_running_accessor()
            and lane.request_key == request_key
            and lane.generation == request_key[2]
            and lane.query == request_key[1]
            and self._flat_conversation_owner_token() is request_key[3]
            and self._screen_lifecycle_token() is request_key[4]
            and self._canonical_membership_revision == request_key[5]
        )

    async def _load_workspace_tree_search_rows(
        self, query: str
    ) -> tuple[tuple[ConsoleConversationBrowserInputRow, ...], int | None]:
        request_key = self._workspace_tree_search.request_key
        offset = 0
        named_rows: tuple[ConsoleConversationBrowserInputRow, ...] = ()
        while True:
            rows, total, error = await self._persisted_console_browser_rows(
                query,
                scopes=(("all", None),),
                offset=offset,
            )
            if error:
                raise RuntimeError(error)
            named_rows = self._merge_console_browser_rows(
                named_rows,
                (
                    row
                    for row in rows
                    if row.scope_type == "workspace"
                    and row.workspace_id not in (None, DEFAULT_WORKSPACE_ID)
                ),
            )
            if (
                request_key is not None
                and not self._workspace_search_attempt_is_current(request_key)
            ):
                return (), None
            offset += CONSOLE_CONVERSATION_BROWSER_RESULT_LIMIT
            if total is None or offset >= total:
                break
        native_rows = self._filter_console_browser_rows_for_query(
            self._native_console_browser_rows(),
            query,
        )
        named_rows = self._merge_console_browser_rows(
            (
                row
                for row in native_rows
                if row.scope_type == "workspace"
                and row.workspace_id not in (None, DEFAULT_WORKSPACE_ID)
            ),
            named_rows,
        )
        if request_key is not None and not self._workspace_search_attempt_is_current(
            request_key
        ):
            return (), None
        return named_rows, len(named_rows)

    async def _load_flat_conversation_search_rows(
        self, query: str
    ) -> tuple[tuple[ConsoleConversationBrowserInputRow, ...], int | None]:
        rows, total, error = await self._persisted_console_browser_rows(query)
        if error:
            raise RuntimeError(error)
        return tuple(rows), total

    @staticmethod
    def _row_belongs_to_flat_projection(
        row: ConsoleConversationBrowserInputRow,
    ) -> bool:
        # TASK-32309: keep this controller-side twin in agreement with the
        # builder's `_belongs_to_chats` -- character conversations belong to
        # the Character section (or their workspace Tree node), never the
        # flat lane, so the settled-rows cache must not retain them either.
        if str(row.character_id or "").strip():
            return False
        return row.scope_type == "global" or row.workspace_id in (
            None,
            DEFAULT_WORKSPACE_ID,
        )

    @staticmethod
    def _new_workspace_page_state(
        *,
        rows: Iterable[ConsoleConversationBrowserInputRow] = (),
        next_cursor: int | None = None,
    ) -> PageAttemptState:
        return PageAttemptState(rows=tuple(rows), next_cursor=next_cursor)

    def _workspace_membership_token(
        self, workspace_id: str
    ) -> tuple[str, ...] | UnknownMembership:
        service = getattr(self.app_instance, "workspace_registry_service", None)
        list_conversations = getattr(service, "list_workspace_conversations", None)
        if not callable(list_conversations):
            return _MEMBERSHIP_UNKNOWN
        try:
            return tuple(
                sorted(
                    str(getattr(row, "item_id", "") or "")
                    for row in list_conversations(workspace_id)
                    if str(getattr(row, "item_id", "") or "")
                )
            )
        except Exception:
            return _MEMBERSHIP_UNKNOWN

    async def load_workspace_tree_page(self, workspace_id: str, cursor: int) -> None:
        """Load one bounded workspace page if its full request key stays current."""
        workspace_id = str(workspace_id or "").strip()
        cursor = max(0, int(cursor))
        attempt = self._workspace_page_attempts.setdefault(
            workspace_id, PageAttemptState()
        )
        if attempt.loading and attempt.request_key is not None:
            return
        attempt.generation += 1
        generation = attempt.generation
        membership_token = self._workspace_membership_token(workspace_id)
        if membership_token is _MEMBERSHIP_UNKNOWN:
            attempt.loading = False
            attempt.error = WORKSPACE_CONVERSATIONS_ACCESS_UNKNOWN
            attempt.retry_cursor = cursor
            attempt.membership_unknown = True
            self._sync_console_workspace_context()
            return
        attempt.membership_unknown = False
        request_key = (
            workspace_id,
            membership_token,
            self._workspace_tree_search.generation,
            cursor,
        )
        attempt.request_key = request_key
        attempt.owner_token = self._workspace_tree_owner_token()
        attempt.lifecycle_token = self._screen_lifecycle_token()
        attempt.loading = True
        attempt.error = ""
        attempt.retry_cursor = None
        attempt.membership_unknown = False
        self._sync_console_workspace_context()
        try:
            try:
                rows, next_cursor = await self._fetch_workspace_tree_page(
                    workspace_id, cursor
                )
            except Exception:
                self._commit_workspace_page_failure(
                    workspace_id, generation, request_key
                )
                return
            if not self._workspace_page_attempt_is_current(
                workspace_id, generation, request_key
            ):
                return
            attempt.rows = self._merge_page_rows(attempt.rows, rows)
            self._record_canonical_owner_rows(rows)
            attempt.membership_token = request_key[1]
            attempt.next_cursor = next_cursor
            attempt.error = ""
            attempt.retry_cursor = None
        finally:
            self._settle_workspace_page_attempt(workspace_id, generation, request_key)

    async def retry_workspace_tree_page(self, workspace_id: str) -> None:
        """Replace the failed page generation for one workspace."""
        attempt = self._workspace_page_attempts.get(workspace_id)
        if attempt is not None and attempt.retry_cursor is not None:
            await self.load_workspace_tree_page(workspace_id, attempt.retry_cursor)

    def request_workspace_tree_page(self, workspace_id: str, cursor: int) -> None:
        """Schedule one page worker without canceling another workspace lane."""
        target = str(workspace_id or "").strip()
        attempt = self._workspace_page_attempts.setdefault(target, PageAttemptState())
        if attempt.loading:
            return
        attempt.loading = True
        attempt.error = ""
        attempt.retry_cursor = None
        self._sync_console_workspace_context()
        attempt.worker = self.run_worker(
            self.load_workspace_tree_page(target, cursor),
            group=f"console-workspace-page-{target}",
            exclusive=False,
        )

    def _workspace_page_attempt_is_current(
        self,
        workspace_id: str,
        generation: int,
        request_key: tuple[str, tuple[str, ...], int, int] | None,
    ) -> bool:
        attempt = self._workspace_page_attempts.get(workspace_id)
        request_is_current = bool(
            request_key is not None
            and attempt is not None
            and self._screen_running_accessor()
            and attempt.generation == generation
            and attempt.request_key == request_key
            and request_key[2] == self._workspace_tree_search.generation
            and attempt.owner_token is self._workspace_tree_owner_token()
            and workspace_id not in self._collapsed_workspace_ids
        )
        if not request_is_current:
            return False
        if attempt.lifecycle_token is not self._screen_lifecycle_token():
            return False
        current_membership = self._workspace_membership_token(workspace_id)
        if current_membership is _MEMBERSHIP_UNKNOWN:
            self._mark_workspace_membership_unknown(workspace_id)
            return False
        if request_key[1] != current_membership:
            return False
        return True

    def transition_workspace_tree_expansion(
        self, workspace_id: str, *, expanded: bool
    ) -> None:
        """Fence a collapsed workspace page lane while retaining loaded rows."""

        target = str(workspace_id or "").strip()
        if not target:
            return
        if expanded:
            self._collapsed_workspace_ids.discard(target)
            if target not in self._workspace_page_attempts:
                self.request_workspace_tree_page(target, 0)
            return
        self._collapsed_workspace_ids.add(target)
        attempt = self._workspace_page_attempts.get(target)
        if attempt is None:
            return
        attempt.generation += 1
        attempt.request_key = None
        attempt.loading = False
        worker = attempt.worker
        attempt.worker = None
        cancel = getattr(worker, "cancel", None)
        if callable(cancel):
            cancel()

    def request_next_workspace_tree_page(self, workspace_id: str) -> None:
        """Request the retained lane's next cursor, when one exists."""

        attempt = self._workspace_page_attempts.get(str(workspace_id or "").strip())
        if attempt is not None and attempt.next_cursor is not None:
            self.request_workspace_tree_page(workspace_id, attempt.next_cursor)

    def activate_workspace_id(self, workspace_id: str) -> None:
        """Activate a workspace selected from the native Tree."""

        self._switch_console_workspace(workspace_id)

    def _switch_console_workspace(self, workspace_id: str) -> bool:
        """Switch registry, session, controller, rail, and native UI together."""

        target = str(workspace_id or "").strip()
        service = getattr(self.app_instance, "workspace_registry_service", None)
        if not target or service is None:
            return False
        try:
            service.set_active_workspace(target)
        except Exception:
            logger.opt(exception=True).warning("Unable to switch Console workspace")
            notify = getattr(self.app_instance, "notify", None)
            if callable(notify):
                notify("Workspace could not be selected.", severity="error")
            return False
        self._sync_console_chat_core_state()
        self._activate_console_session_for_workspace(target)
        self._sync_console_workspace_context()
        native_sync = self._sync_native_console_chat_ui()
        if inspect.isawaitable(native_sync):
            self.run_worker(
                native_sync,
                exclusive=True,
                group="console-sync",
            )
        return True

    def _settle_workspace_page_attempt(
        self,
        workspace_id: str,
        generation: int,
        request_key: tuple[str, tuple[str, ...], int, int] | None,
    ) -> None:
        """Settle only the captured page attempt and publish to its current owner."""
        attempt = self._workspace_page_attempts.get(workspace_id)
        if (
            attempt is None
            or attempt.generation != generation
            or attempt.request_key != request_key
        ):
            return
        attempt.loading = False
        if (
            self._screen_running_accessor()
            and attempt.owner_token is self._workspace_tree_owner_token()
        ):
            self._sync_console_workspace_context()

    def _commit_workspace_page_failure(
        self,
        workspace_id: str,
        generation: int,
        request_key: tuple[str, tuple[str, ...], int, int] | None,
    ) -> None:
        if not self._workspace_page_attempt_is_current(
            workspace_id, generation, request_key
        ):
            return
        attempt = self._workspace_page_attempts[workspace_id]
        attempt.error = WORKSPACE_CONVERSATIONS_LOAD_FAILED
        attempt.retry_cursor = request_key[3] if request_key is not None else None
        attempt.membership_unknown = False

    @staticmethod
    def _merge_page_rows(
        current: Iterable[ConsoleConversationBrowserInputRow],
        incoming: Iterable[ConsoleConversationBrowserInputRow],
    ) -> tuple[ConsoleConversationBrowserInputRow, ...]:
        merged: dict[str, ConsoleConversationBrowserInputRow] = {}
        for row in (*tuple(current), *tuple(incoming)):
            conversation_id = str(row.conversation_id or "").strip()
            if conversation_id:
                merged.setdefault(conversation_id, row)
        return tuple(merged.values())

    @staticmethod
    def _canonical_owner_id(row: ConsoleConversationBrowserInputRow) -> str:
        workspace_id = str(row.workspace_id or "").strip()
        if row.scope_type == "global" or workspace_id in ("", DEFAULT_WORKSPACE_ID):
            return DEFAULT_WORKSPACE_ID
        return workspace_id

    def _record_canonical_owner_rows(
        self, rows: Iterable[ConsoleConversationBrowserInputRow]
    ) -> None:
        for row in rows:
            conversation_id = str(row.conversation_id or "").strip()
            if conversation_id:
                self._canonical_owner_observations[conversation_id] = (
                    self._canonical_owner_id(row)
                )

    def _rows_with_latest_canonical_owner(
        self, rows: Iterable[ConsoleConversationBrowserInputRow]
    ) -> tuple[ConsoleConversationBrowserInputRow, ...]:
        return tuple(
            row
            for row in rows
            if not row.conversation_id
            or (
                observed := self._canonical_owner_observations.get(
                    str(row.conversation_id)
                )
            )
            is None
            or self._canonical_owner_id(row) == observed
        )

    async def _fetch_workspace_tree_page(
        self, workspace_id: str, cursor: int
    ) -> tuple[tuple[ConsoleConversationBrowserInputRow, ...], int | None]:
        rows, total, error = await self._fetch_workspace_rows(
            workspace_id, query="", cursor=cursor
        )
        if error:
            raise RuntimeError(error)
        next_cursor = cursor + CONSOLE_CONVERSATION_BROWSER_RESULT_LIMIT
        if total is None or next_cursor >= total:
            next_cursor = None
        return rows, next_cursor

    async def _fetch_workspace_rows(
        self, workspace_id: str, *, query: str, cursor: int
    ) -> tuple[tuple[ConsoleConversationBrowserInputRow, ...], int | None, str]:
        service = getattr(self.app_instance, "chat_conversation_scope_service", None)
        list_conversations = getattr(service, "list_conversations", None)
        if not callable(list_conversations):
            return (), None, ""
        try:
            list_kwargs = {
                "mode": "local",
                "query": query,
                "scope_type": "workspace",
                "workspace_id": workspace_id,
                "limit": CONSOLE_CONVERSATION_BROWSER_RESULT_LIMIT,
                "offset": cursor,
            }
            result = (
                list_conversations(**list_kwargs)
                if inspect.iscoroutinefunction(list_conversations)
                else await asyncio.to_thread(list_conversations, **list_kwargs)
            )
            result = await result if inspect.isawaitable(result) else result
        except Exception:
            # TASK-25827: this was the ONLY record of why the rail failed and
            # it sat at debug, so "check the app log" led nowhere.
            logger.opt(exception=True).warning(
                "Unable to load Console workspace page workspace_id={}", workspace_id
            )
            return (), None, WORKSPACE_CONVERSATIONS_LOAD_FAILED
        if not isinstance(result, dict):
            return (), 0, ""
        items = result.get("items") if isinstance(result.get("items"), list) else []
        labels = self._console_browser_workspace_labels()
        # Review finding 6: workspace Tree pages legitimately contain
        # character conversations (workspace wins), so their rows must carry
        # the same character identity the other producers set -- downstream
        # overlays and the Character-section routing key off it.
        item_character_ids = [
            text_id
            for text_id in (
                str(item.get("character_id") or "").strip()
                if isinstance(item, dict)
                else ""
                for item in items
            )
            if text_id
        ]
        character_labels = self._console_browser_character_labels_for(
            item_character_ids
        )
        starred_ids = self._starred_console_conversation_ids()
        rows: list[ConsoleConversationBrowserInputRow] = []
        for item in items:
            if not isinstance(item, dict):
                continue
            conversation_id = str(item.get("id") or "").strip()
            if not conversation_id:
                continue
            character_id = str(item.get("character_id") or "").strip() or None
            row = ConsoleConversationBrowserInputRow(
                row_key=conversation_id,
                conversation_id=conversation_id,
                native_session_id=None,
                title=str(item.get("title") or "Untitled conversation"),
                scope_type="workspace",
                workspace_id=workspace_id,
                workspace_label=labels.get(workspace_id, workspace_id),
                status=self._saved_handoff_status(item),
                selected=conversation_id == self._current_console_conversation_id(),
                source_kind="persisted",
                updated_sort=console_persisted_row_updated_sort(item),
                run_marker=self._console_browser_unseen_marker(conversation_id),
                character_id=character_id,
                character_label=(
                    character_labels.get(character_id, "")
                    if character_id is not None
                    else ""
                ),
            )
            rows.append(self._apply_console_browser_star_state(row, starred_ids))
        total = result.get("total")
        if total is None and isinstance(result.get("pagination"), dict):
            total = result["pagination"].get("total")
        try:
            total_count = int(total)
        except (TypeError, ValueError):
            total_count = len(rows)
        return tuple(rows), total_count, ""

    def apply_workspace_membership_snapshot(
        self,
        memberships: Mapping[str, tuple[str, ...]],
        *,
        complete: bool,
        workspace_labels: Mapping[str, str] | None = None,
        canonical_rows: Iterable[ConsoleConversationBrowserInputRow] = (),
    ) -> None:
        """Apply already-read canonical membership without projection-time I/O."""
        current_tokens = {
            str(workspace_id): tuple(dict.fromkeys(conversation_ids))
            for workspace_id, conversation_ids in memberships.items()
        }
        labels = dict(workspace_labels or {})
        owner_by_conversation: dict[str, str] = {}
        for workspace_id in sorted(current_tokens):
            for conversation_id in current_tokens[workspace_id]:
                owner_by_conversation.setdefault(conversation_id, workspace_id)
        canonical_by_conversation: dict[str, ConsoleConversationBrowserInputRow] = {}
        canonical_by_owner: dict[
            tuple[str, str], ConsoleConversationBrowserInputRow
        ] = {}
        for row in canonical_rows:
            conversation_id = str(row.conversation_id or "").strip()
            if not conversation_id:
                continue
            owner_id = self._canonical_owner_id(row)
            owner_by_conversation[conversation_id] = owner_id
            canonical_by_conversation[conversation_id] = row
            canonical_by_owner[conversation_id, owner_id] = row
            labels.setdefault(owner_id, str(row.workspace_label or owner_id))

        if complete:
            self._canonical_membership_revision += 1
            complete_owners: dict[str, str] = {}
            for workspace_id in sorted(current_tokens):
                for conversation_id in current_tokens[workspace_id]:
                    complete_owners.setdefault(conversation_id, workspace_id)
            complete_workspace_ids = set(current_tokens)
            for conversation_id, owner_id in tuple(
                self._canonical_owner_observations.items()
            ):
                if (
                    owner_id in complete_workspace_ids
                    and conversation_id not in complete_owners
                ):
                    self._canonical_owner_observations.pop(conversation_id, None)
            self._canonical_owner_observations.update(complete_owners)
            for conversation_id, owner_id in tuple(owner_by_conversation.items()):
                if (
                    owner_id in complete_workspace_ids
                    and conversation_id not in complete_owners
                ):
                    owner_by_conversation.pop(conversation_id, None)
            owner_by_conversation.update(complete_owners)
        for conversation_id, owner_id in self._canonical_owner_observations.items():
            owner_by_conversation[conversation_id] = owner_id
            canonical_row = canonical_by_owner.get((conversation_id, owner_id))
            if canonical_row is not None:
                canonical_by_conversation[conversation_id] = canonical_row
            labels.setdefault(
                owner_id,
                "Default" if owner_id == DEFAULT_WORKSPACE_ID else owner_id,
            )

        changed_workspaces: set[str] = set()
        for workspace_id, attempt in self._workspace_page_attempts.items():
            token = current_tokens.get(workspace_id)
            owner_conflict = any(
                owner_by_conversation.get(str(row.conversation_id or "").strip())
                not in (None, workspace_id)
                for row in attempt.rows
            )
            if token is None:
                if owner_conflict:
                    changed_workspaces.add(workspace_id)
                continue
            if complete:
                if attempt.membership_unknown:
                    attempt.error = ""
                    attempt.retry_cursor = None
                    attempt.membership_unknown = False
                if attempt.membership_token is None:
                    attempt.membership_token = token
                elif attempt.membership_token != token:
                    changed_workspaces.add(workspace_id)
            if owner_conflict:
                changed_workspaces.add(workspace_id)

        moved_rows: dict[str, list[ConsoleConversationBrowserInputRow]] = {}
        for workspace_id, cached_rows in tuple(self._workspace_membership_rows.items()):
            if workspace_id not in current_tokens:
                continue
            retained: list[ConsoleConversationBrowserInputRow] = []
            for row in cached_rows:
                conversation_id = str(row.conversation_id or "").strip()
                owner_id = owner_by_conversation.get(conversation_id)
                if owner_id == workspace_id or (owner_id is None and not complete):
                    retained.append(row)
                elif owner_id is not None:
                    moved_rows.setdefault(owner_id, []).append(
                        replace(
                            row,
                            workspace_id=owner_id,
                            workspace_label=labels.get(owner_id, owner_id),
                        )
                    )
            retained_rows = tuple(retained)
            if retained_rows != cached_rows:
                self._workspace_membership_rows[workspace_id] = retained_rows

        for workspace_id in changed_workspaces:
            attempt = self._workspace_page_attempts[workspace_id]
            retained: list[ConsoleConversationBrowserInputRow] = []
            for row in attempt.rows:
                conversation_id = str(row.conversation_id or "").strip()
                owner_id = owner_by_conversation.get(conversation_id)
                if owner_id == workspace_id:
                    retained.append(row)
                elif owner_id == DEFAULT_WORKSPACE_ID:
                    canonical_row = canonical_by_conversation.get(conversation_id)
                    if canonical_row is not None and (
                        self._canonical_owner_id(canonical_row) != owner_id
                    ):
                        canonical_row = None
                    moved_rows.setdefault(owner_id, []).append(
                        canonical_row
                        or replace(
                            row,
                            workspace_id=owner_id,
                            workspace_label="Default",
                        )
                    )
                elif owner_id in labels and owner_id != DEFAULT_WORKSPACE_ID:
                    canonical_row = canonical_by_conversation.get(conversation_id)
                    if canonical_row is not None and (
                        self._canonical_owner_id(canonical_row) != owner_id
                    ):
                        canonical_row = None
                    moved_rows.setdefault(owner_id, []).append(
                        canonical_row
                        or replace(
                            row,
                            workspace_id=owner_id,
                            workspace_label=labels[owner_id],
                        )
                    )
                elif owner_id is None and not complete:
                    retained.append(row)
            attempt.rows = tuple(retained)
            attempt.membership_token = current_tokens.get(
                workspace_id,
                tuple(
                    str(row.conversation_id) for row in retained if row.conversation_id
                ),
            )
            attempt.generation += 1
            attempt.request_key = None
            attempt.loading = False
            attempt.error = ""
            attempt.retry_cursor = None
            attempt.next_cursor = 0
            attempt.membership_unknown = False

        for workspace_id, rows in moved_rows.items():
            if workspace_id == DEFAULT_WORKSPACE_ID:
                current = self._workspace_membership_rows.get(workspace_id, ())
                self._workspace_membership_rows[workspace_id] = self._merge_page_rows(
                    current, rows
                )
                continue
            attempt = self._workspace_page_attempts.setdefault(
                workspace_id, PageAttemptState()
            )
            attempt.rows = self._merge_page_rows(attempt.rows, rows)
            attempt.membership_token = current_tokens[workspace_id]

    def _mark_workspace_membership_unknown(self, workspace_id: str) -> None:
        attempt = self._workspace_page_attempts.get(workspace_id)
        if attempt is None:
            return
        attempt.error = WORKSPACE_CONVERSATIONS_ACCESS_UNKNOWN
        attempt.loading = False
        attempt.retry_cursor = (
            attempt.next_cursor if attempt.next_cursor is not None else 0
        )
        attempt.membership_unknown = True

    def _prune_stale_workspace_page_attempts(self) -> tuple[WorkspaceRecord, ...]:
        """Drop page attempts for workspaces gone from the registry.

        Returns:
            Live named-workspace records (non-archived, excluding the
            built-in Default), the set the workspace tree renders.
        """
        all_records = tuple(
            record
            for record in self._console_browser_workspace_records()
            if str(record.workspace_id or "").strip()
            and not bool(getattr(record, "archived", False))
        )
        records = tuple(
            record
            for record in all_records
            if str(record.workspace_id or "").strip() != DEFAULT_WORKSPACE_ID
        )
        workspace_ids = {str(record.workspace_id) for record in records}
        for workspace_id in tuple(self._workspace_page_attempts):
            if workspace_id not in workspace_ids:
                self._workspace_page_attempts.pop(workspace_id, None)
        return records

    def workspace_tree_projection(
        self,
        rows: Iterable[ConsoleConversationBrowserInputRow] = (),
        *,
        prepared_rows: tuple[ConsoleConversationBrowserInputRow, ...] | None = None,
    ) -> tuple[WorkspaceTreeWorkspace, ...]:
        """Return the current immutable named-workspace projection.

        Args:
            rows: Browser input rows to merge with the page-attempt rows on
                the no-query path.
            prepared_rows: The state build's already merged + canonical-owner
                + overlay processed union of browser and page-attempt rows
                (TASK-22201). When provided and no tree query is active, the
                merge/canonical/overlay pipeline is NOT re-run here -- the
                build already ran it once over the identical input set.
                Standalone callers omit it and keep the self-contained path.
        """
        records = self._prune_stale_workspace_page_attempts()
        workspace_lane = self._workspace_tree_search
        projection_query = (
            workspace_lane.settled_query
            if workspace_lane.error
            else workspace_lane.query
        )
        if projection_query.strip():
            source_rows = (
                workspace_lane.settled_rows
                if workspace_lane.error
                else workspace_lane.rows
            )
            source_rows = self._rows_with_latest_canonical_owner(source_rows)
            source_rows = self._overlay_current_console_browser_markers(source_rows)
        elif prepared_rows is not None:
            source_rows = prepared_rows
        else:
            source_rows = self._merge_console_browser_rows(
                rows,
                *(attempt.rows for attempt in self._workspace_page_attempts.values()),
            )
            source_rows = self._rows_with_latest_canonical_owner(source_rows)
            source_rows = self._overlay_current_console_browser_markers(source_rows)
        bridge = self._ensure_console_agent_bridge()
        read_counts = getattr(bridge, "progress_counts", None)
        return build_workspace_tree_state(
            progress_counts=read_counts() if callable(read_counts) else {},
            workspaces=(
                (str(record.workspace_id), str(record.name or record.workspace_id))
                for record in records
            ),
            rows=source_rows,
            next_cursors={
                workspace_id: attempt.next_cursor
                for workspace_id, attempt in self._workspace_page_attempts.items()
            },
            loading={
                workspace_id: attempt.loading
                for workspace_id, attempt in self._workspace_page_attempts.items()
            },
            errors={
                workspace_id: attempt.error
                for workspace_id, attempt in self._workspace_page_attempts.items()
            },
            retry_cursors={
                workspace_id: attempt.retry_cursor
                for workspace_id, attempt in self._workspace_page_attempts.items()
            },
            membership_unknown={
                workspace_id: attempt.membership_unknown
                for workspace_id, attempt in self._workspace_page_attempts.items()
            },
            query=projection_query,
            active_workspace_id=(
                self._current_console_workspace_context().active_workspace_id
            ),
        )

    def transition_browser_search(self, query: str, disabled: bool) -> None:
        """Apply one input change and schedule its canonical browser refresh."""
        if disabled or query == self._console_conversation_browser_query:
            return
        if not query.strip():
            self.clear_console_conversation_browser_search()
            return
        self._console_conversation_browser_query = query
        self._console_conversation_browser_search_token += 1
        token = self._console_conversation_browser_search_token
        self._flat_conversation_search.request_key = (
            "conversations",
            query,
            token,
            self._flat_conversation_owner_token(),
            self._screen_lifecycle_token(),
            self._canonical_membership_revision,
        )
        if self._console_conversation_browser_search_timer is not None:
            self._console_conversation_browser_search_timer.stop()
            self._console_conversation_browser_search_timer = None
        self._console_conversation_browser_rows = (
            self._filter_console_browser_rows_for_query(
                self._console_conversation_browser_rows,
                query,
            )
        )
        self._console_conversation_browser_search_timer = (
            self._schedule_console_browser_timer(
                0.2,
                partial(
                    self._start_console_conversation_browser_search,
                    query,
                    token,
                ),
            )
        )

    def transition_workspace_tree_search(self, query: str, disabled: bool) -> None:
        """Debounce Workspaces search without touching Conversations state."""
        lane = self._workspace_tree_search
        if disabled or query == lane.query:
            return
        if lane.debounce is not None:
            lane.debounce.stop()
            lane.debounce = None
        lane.query = str(query or "")
        lane.generation += 1
        generation = lane.generation
        if not lane.query.strip():
            worker = lane.worker
            cancel = getattr(worker, "cancel", None)
            if callable(cancel):
                cancel()
            lane.worker = None
            lane.request_key = None
            lane.rows = ()
            lane.total = None
            lane.settled_rows = ()
            lane.settled_total = None
            lane.settled_query = ""
            lane.error = ""
            lane.retry_query = None
            self._sync_console_workspace_context()
            return
        lane.debounce = self._schedule_console_browser_timer(
            0.2,
            partial(self._start_workspace_tree_search, lane.query, generation),
        )

    def _start_workspace_tree_search(self, query: str, generation: int) -> None:
        lane = self._workspace_tree_search
        if generation != lane.generation or query != lane.query:
            return
        lane.worker = self.run_worker(
            self.refresh_workspace_tree_search(query),
            group="console-workspace-tree-search",
            exclusive=True,
        )

    def clear_console_conversation_browser_search(self) -> None:
        """Clear canonical browser search state and restore search focus."""
        if self._console_conversation_browser_search_timer is not None:
            self._console_conversation_browser_search_timer.stop()
            self._console_conversation_browser_search_timer = None
        self._console_conversation_browser_search_token += 1
        self._console_conversation_browser_query = ""
        self._console_conversation_browser_rows = ()
        self._console_conversation_browser_total = None
        self._console_conversation_browser_error = ""
        self._flat_conversation_search.request_key = None
        self._flat_conversation_search.retry_query = None
        self._flat_conversation_search.settled_rows = ()
        self._flat_conversation_search.settled_total = None
        self._flat_conversation_search.settled_query = ""
        self._sync_console_workspace_context()
        self.call_after_refresh(self._focus_console_workspace_conversation_search)

    def _start_console_conversation_browser_search(
        self,
        query: str,
        token: int,
    ) -> None:
        """Run the debounced half of a rail conversation-search keystroke."""
        if token != self._console_conversation_browser_search_token:
            return
        if query != self._console_conversation_browser_query:
            return
        self._flat_conversation_search.request_key = (
            "conversations",
            query,
            token,
            self._flat_conversation_owner_token(),
            self._screen_lifecycle_token(),
            self._canonical_membership_revision,
        )
        self._invalidate_console_persisted_rows_cache()
        if not query.strip():
            self._console_conversation_browser_rows = ()
            self._console_conversation_browser_total = None
            self._console_conversation_browser_error = ""
            self._sync_console_workspace_context()
            self.call_after_refresh(self._focus_console_workspace_conversation_search)
            return
        self._console_conversation_browser_rows = (
            self._filter_console_browser_rows_for_query(
                self._merge_console_browser_rows(
                    self._native_console_browser_rows(),
                    *self._workspace_membership_rows.values(),
                ),
                query,
            )
        )
        self._console_conversation_browser_total = None
        self._console_conversation_browser_error = ""
        self._sync_console_workspace_context()
        self._flat_conversation_search.worker = self.run_worker(
            self._refresh_console_conversation_browser_search(query, token),
            group="console-flat-conversation-search",
            exclusive=True,
        )

    @staticmethod
    def _console_browser_row_key(row: ConsoleConversationBrowserInputRow) -> str:
        return str(row.row_key or row.conversation_id or "").strip()

    @staticmethod
    def _console_browser_row_scope_copy(row: ConsoleConversationBrowserInputRow) -> str:
        if row.scope_type == "global":
            return "global chats"
        if row.workspace_id == DEFAULT_WORKSPACE_ID:
            return "default workspace chats"
        if row.workspace_id:
            return f"workspace {row.workspace_label}"
        return "chats"

    @staticmethod
    def _console_browser_row_matches_query(
        row: ConsoleConversationBrowserInputRow,
        normalized_query: str,
    ) -> bool:
        haystack = " ".join(
            (
                str(row.title or ""),
                str(row.workspace_label or ""),
                str(row.status or ""),
                ConsoleWorkspaceController._console_browser_row_scope_copy(row),
            )
        ).lower()
        return normalized_query in haystack

    def _filter_console_browser_rows_for_query(
        self,
        rows: Iterable[ConsoleConversationBrowserInputRow],
        query: str,
    ) -> tuple[ConsoleConversationBrowserInputRow, ...]:
        """Return rows matching ``query`` without service or database access."""
        normalized_query = str(query or "").strip().lower()
        row_tuple = tuple(rows)
        if not normalized_query:
            return row_tuple
        return tuple(
            row
            for row in row_tuple
            if self._console_browser_row_matches_query(row, normalized_query)
        )

    def _find_console_browser_row(
        self,
        row_key: str,
        *,
        conversation_id: str | None = None,
    ) -> ConsoleConversationBrowserRow | None:
        """Return the current grouped browser row for a rendered row key."""
        target_row_key = str(row_key or "").strip()
        target_conversation_id = str(conversation_id or "").strip()
        if not target_row_key and not target_conversation_id:
            return None
        state = self._build_console_workspace_context_state()
        browser = state.conversation_browser
        if browser is None:
            return None
        allow_conversation_fallback = not target_row_key
        fallback: ConsoleConversationBrowserRow | None = None
        for section in browser.sections:
            for row in section.rows:
                if target_row_key and row.row_key == target_row_key:
                    return row
                if (
                    allow_conversation_fallback
                    and fallback is None
                    and target_conversation_id
                    and row.conversation_id == target_conversation_id
                ):
                    fallback = row
            for group in section.groups:
                for row in group.rows:
                    if target_row_key and row.row_key == target_row_key:
                        return row
                    if (
                        allow_conversation_fallback
                        and fallback is None
                        and target_conversation_id
                        and row.conversation_id == target_conversation_id
                    ):
                        fallback = row
        return fallback

    @staticmethod
    def _console_browser_display_identity(
        row: ConsoleConversationBrowserInputRow,
    ) -> tuple[str, str, str, str] | tuple[str, str]:
        """Return the display identity used to dedupe grouped browser rows."""
        conversation_id = str(row.conversation_id or "").strip()
        if conversation_id:
            scope_type = str(row.scope_type or "").strip() or "workspace"
            workspace_id = (
                "" if scope_type == "global" else str(row.workspace_id or "").strip()
            )
            return ("conversation", scope_type, workspace_id, conversation_id)
        return (
            "row",
            ConsoleWorkspaceController._console_browser_row_key(row),
        )

    def _starred_console_conversation_ids(self) -> set[str]:
        """Return locally starred durable conversation ids."""
        service = getattr(self.app_instance, "conversation_local_marks_service", None)
        list_marked = getattr(service, "list_marked_conversation_ids", None)
        if not callable(list_marked):
            return set()
        try:
            return {str(conversation_id) for conversation_id in list_marked()}
        except Exception:
            logger.opt(exception=True).debug("Unable to read local conversation stars")
            return set()

    def _apply_console_browser_star_state(
        self,
        row: ConsoleConversationBrowserInputRow,
        starred_ids: set[str] | None = None,
    ) -> ConsoleConversationBrowserInputRow:
        """Apply local star state and star eligibility to one browser row."""
        conversation_id = str(row.conversation_id or "").strip()
        ids = (
            starred_ids
            if starred_ids is not None
            else self._starred_console_conversation_ids()
        )
        star_enabled = bool(conversation_id) and not str(row.row_key or "").startswith(
            "native:"
        )
        return replace(
            row,
            conversation_id=conversation_id or None,
            starred=bool(conversation_id and conversation_id in ids),
            star_enabled=bool(star_enabled),
        )

    async def conversation_menu_presentation(
        self, conversation_id: str | None, session_id: str = ""
    ) -> dict[str, Any]:
        """Capture current read state and saved appearance for either row menu.

        Args:
            conversation_id: Persisted conversation ID, or None for an unsaved chat.
            session_id: Native session ID used for live attention facts.

        Returns:
            Menu target fields including read state, appearance, attention, and
            profile authority. Read state is None when unavailable.
        """
        from ...Workspaces.conversation_attention import present_conversation_attention

        authority = self._console_switcher_authority()
        service = getattr(self.app_instance, "conversation_local_marks_service", None)
        manual = None
        if conversation_id and callable(getattr(service, "unread_token", None)):
            try:
                manual = (
                    await asyncio.to_thread(service.unread_token, conversation_id)
                    is not None
                )
            except Exception:  # noqa: BLE001 - unread remains unknown on service failure
                manual = None
        appearance = (
            self._console_conversation_appearance_map([conversation_id])
            if conversation_id
            else {}
        )
        icon, color = appearance.get(conversation_id, ("", ""))
        row = ConsoleConversationBrowserInputRow(
            row_key=conversation_id or session_id,
            conversation_id=conversation_id,
            native_session_id=session_id,
            title="",
            scope_type="global",
            workspace_id=None,
            workspace_label="",
        )
        facts = self._conversation_attention_rows((row,))[0].attention
        # The explicit read above is fresher than the asynchronous row cache.
        from ...Workspaces.conversation_attention import ConversationAttentionFact

        facts = tuple(fact for fact in facts if fact.kind != "unread")
        if manual:
            facts += (ConversationAttentionFact("unread", "Unread"),)
        return {
            "manual_unread": manual,
            "icon": icon,
            "color": color,
            "attention_summary": present_conversation_attention(facts).summary,
            "profile_authority": authority,
        }

    def set_conversation_manual_unread(
        self, target: ConversationMenuTarget, *, unread: bool
    ) -> None:
        """Schedule a profile-fenced reminder mutation for a persisted chat.

        Args:
            target: Captured menu target including conversation and profile identity.
            unread: True to set a reminder; False to clear only the manual mark.
        """
        service = getattr(self.app_instance, "conversation_local_marks_service", None)
        db = getattr(self.app_instance, "chachanotes_db", None)
        if service is None or db is None or not target.conversation_id:
            self.app_instance.notify("Read state is unavailable.", severity="warning")
            return
        authority = self._console_switcher_authority()
        if (
            target.profile_authority is not None
            and target.profile_authority != authority
        ):
            return
        self.run_worker(
            self._write_manual_unread(
                target.conversation_id, unread, service, db, authority
            ),
            group="console-manual-unread-write",
            exclusive=False,
        )

    async def _write_manual_unread(self, cid, unread, service, db, authority) -> None:
        def write():
            if not db.get_conversation_by_id(cid):
                raise ValueError("Conversation no longer exists")
            return service.mark_unread(cid) if unread else service.mark_read(cid)

        if (
            self._console_switcher_authority() != authority
            or getattr(self.app_instance, "conversation_local_marks_service", None)
            is not service
        ):
            return
        try:
            await asyncio.to_thread(write)
        except Exception:  # noqa: BLE001 - contain local mark service failures
            if self._console_switcher_authority() == authority:
                self.app_instance.notify(
                    "Could not update read state. Reopen the menu and try again.",
                    severity="error",
                )
            return
        if self._console_switcher_authority() == authority:
            self._sync_console_workspace_context()

    def _manual_unread_for_rows(self, rows) -> dict[str, bool | None]:
        """Return cached reminders and batch missing identities off the UI loop."""
        service = getattr(self.app_instance, "conversation_local_marks_service", None)
        ids = {str(row.conversation_id) for row in rows if row.conversation_id}
        if not callable(getattr(service, "unread_ids_for", None)):
            return dict.fromkeys(ids)
        key = (service, service.manual_revision, self._console_switcher_authority())
        state = getattr(self, "_manual_unread_cache", None)
        if state is None or state["key"] != key:
            state = {"key": key, "values": {}, "pending": set()}
            self._manual_unread_cache = state
        missing = ids - state["values"].keys() - state["pending"]
        if missing:
            state["pending"].update(missing)
            self.run_worker(
                self._load_manual_unread_rows(service, state, tuple(sorted(missing))),
                group="console-manual-unread-load",
                exclusive=False,
            )
        return {cid: state["values"].get(cid) for cid in ids}

    async def _load_manual_unread_rows(self, service, state, ids) -> None:
        try:
            unread = await asyncio.to_thread(service.unread_ids_for, ids)
            values = {cid: cid in unread for cid in ids}
        except Exception:  # noqa: BLE001 - contain local mark service failures
            values = dict.fromkeys(ids)
        if (
            getattr(self, "_manual_unread_cache", None) is not state
            or getattr(self.app_instance, "conversation_local_marks_service", None)
            is not service
            or state["key"]
            != (service, service.manual_revision, self._console_switcher_authority())
        ):
            return
        state["pending"].difference_update(ids)
        state["values"].update(values)
        self._sync_console_workspace_context()

    def _conversation_attention_rows(self, rows):
        from ...Workspaces.conversation_attention import (
            ConversationAttentionFact as Fact,
        )

        rows = tuple(rows)
        unread = self._manual_unread_for_rows(rows)
        by_conversation = {}
        by_session = {}
        store = self._console_chat_store
        controller = self._console_chat_controller
        read_attention = getattr(controller, "conversation_attention_for", None)
        if store is not None and callable(read_attention):
            for session in store.sessions():
                facts = read_attention(session.id)
                by_session[session.id] = list(facts)
                if session.persisted_conversation_id:
                    by_conversation.setdefault(
                        session.persisted_conversation_id, []
                    ).extend(facts)
        runtime = getattr(self.app_instance, "console_runtime", None)
        receipts = getattr(runtime, "activity_receipts", None)
        known_outcomes = set()
        labels = {
            "done": ("ready", "New result ready"),
            "error": ("failed", "Failed"),
            "blocked": ("blocked", "Blocked"),
            "stuck": ("blocked", "Stuck — needs attention"),
            "complete": ("ready", "New result ready"),
            "completed": ("ready", "New result ready"),
            "failed": ("failed", "Failed"),
            "stopped": ("stopped", "Stopped"),
            "cancelled": ("stopped", "Cancelled"),
        }
        for receipt in receipts.unseen_snapshot() if receipts is not None else ():
            if receipt.conversation_id:
                kind, label = labels.get(
                    receipt.status,
                    (
                        "outcome_unknown",
                        "Background activity ended — outcome unavailable",
                    ),
                )
                by_conversation.setdefault(receipt.conversation_id, []).append(
                    Fact(kind, label)
                )
                known_outcomes.add(receipt.conversation_id)
            elif receipt.session_id:
                kind, label = labels.get(
                    receipt.status,
                    (
                        "outcome_unknown",
                        "Background activity ended — outcome unavailable",
                    ),
                )
                by_session.setdefault(receipt.session_id, []).append(Fact(kind, label))
        for cid in self._console_fleet_unseen_ids() - known_outcomes:
            by_conversation.setdefault(cid, []).append(
                Fact(
                    "outcome_unknown", "Background activity ended — outcome unavailable"
                )
            )
        result = []
        for row in rows:
            facts = list(
                by_conversation.get(row.conversation_id, ())
                if row.conversation_id
                else by_session.get(row.native_session_id, ())
            )
            manual = unread.get(row.conversation_id)
            if manual:
                facts.append(Fact("unread", "Unread"))
            facts = tuple(dict.fromkeys(facts))
            result.append(
                row
                if (row.attention, row.manual_unread) == (facts, manual)
                else replace(row, attention=facts, manual_unread=manual)
            )
        return tuple(result)

    def _overlay_current_console_browser_markers(
        self,
        rows: Iterable[ConsoleConversationBrowserInputRow],
        current_conversation_id: str | None = None,
    ) -> tuple[ConsoleConversationBrowserInputRow, ...]:
        row_tuple = tuple(rows)
        unseen_ids = self._console_fleet_unseen_ids()
        unseen_marker = resolve_glyph(
            CONSOLE_RUN_MARKER_GLYPHS.get(ConsoleRunMarker.SUBAGENT_UNSEEN, "")
        )
        run_markers = {
            str(row.conversation_id): "" for row in row_tuple if row.conversation_id
        }
        live_conversation_ids: set[str] = set()
        store = self._console_chat_store
        controller = self._console_chat_controller
        if store is not None and controller is not None:
            for session in store.sessions():
                conversation_id = str(session.persisted_conversation_id or "").strip()
                if not conversation_id:
                    continue
                live_conversation_ids.add(conversation_id)
                marker = self._console_run_marker_with_unseen(
                    controller, session, unseen_ids
                )
                run_markers[conversation_id] = resolve_glyph(
                    CONSOLE_RUN_MARKER_GLYPHS.get(marker, "")
                )
        for conversation_id in unseen_ids:
            conversation_id = str(conversation_id)
            if conversation_id not in live_conversation_ids:
                run_markers[conversation_id] = unseen_marker
        return overlay_console_conversation_markers(
            self._conversation_attention_rows(row_tuple),
            starred_ids=self._starred_console_conversation_ids(),
            selected_conversation_id=(
                current_conversation_id or self._current_console_conversation_id()
            ),
            run_markers=run_markers,
        )

    def _console_conversation_appearance_map(
        self, conversation_ids: Iterable[str]
    ) -> dict[str, tuple[str, str]]:
        """Batch-read sanitized conversation appearance keyed by id.

        task-31207: one batched SELECT decorates every browser row (native,
        membership, and persisted alike — merged native rows supersede the
        persisted row that carried the metadata, so the map is the single
        source for all of them). Failures degrade to "no appearance".

        PR #2480 review (#7): the merge runs on recurring sync paths (and
        several times per state build), so the full map is cached under a
        short TTL rather than re-queried per merge; a successful appearance
        write clears the cache (see `_write_console_conversation_appearance_
        off_loop`) alongside the persisted-rows cache. Unknown ids simply
        miss the cached map, exactly like a failed read.
        """
        service = getattr(self.app_instance, "local_chat_conversation_service", None)
        get_appearances = getattr(service, "get_conversation_appearances", None)
        if not callable(get_appearances):
            return {}
        wanted = {str(value) for value in conversation_ids if value}
        if not wanted:
            return {}
        cache_at = getattr(self, "_console_appearance_map_cached_at", 0.0)
        cached_map = getattr(self, "_console_appearance_map_cache", None)
        now = time.monotonic()
        if (
            cached_map is not None
            and now - cache_at < CONSOLE_APPEARANCE_MAP_CACHE_TTL_SECONDS
            and wanted <= set(cached_map)
        ):
            return cached_map
        try:
            appearances = get_appearances(sorted(wanted))
        except Exception:
            logger.opt(exception=True).debug(
                "Unable to read Console conversation appearances"
            )
            return cached_map if cached_map is not None else {}
        merged_map = dict(cached_map or {})
        merged_map.update(
            {
                str(conversation_id): (
                    str(appearance.icon or ""),
                    str(appearance.color or ""),
                )
                for conversation_id, appearance in appearances.items()
            }
        )
        self._console_appearance_map_cache = merged_map
        self._console_appearance_map_cached_at = now
        return merged_map

    @staticmethod
    def _apply_console_browser_appearance_state(
        row: ConsoleConversationBrowserInputRow,
        appearances: dict[str, tuple[str, str]],
    ) -> ConsoleConversationBrowserInputRow:
        """Apply persisted appearance metadata to one browser row."""
        conversation_id = str(row.conversation_id or "").strip()
        if not conversation_id or conversation_id not in appearances:
            return row
        icon, color = appearances[conversation_id]
        if row.icon == icon and row.color == color:
            return row
        return replace(row, icon=icon, color=color)

    def _native_console_browser_rows(
        self,
        current_conversation_id: str | None = None,
    ) -> list[ConsoleConversationBrowserInputRow]:
        """Return open native Console sessions across all workspaces."""
        store = self._console_chat_store
        if store is None:
            return []
        labels = self._console_browser_workspace_labels()
        starred_ids = self._starred_console_conversation_ids()
        active_session_id = store.active_session_id
        controller = self._console_chat_controller

        def _session_character_id(session: Any) -> str | None:
            local_character_id = getattr(session, "local_character_id", None)
            if not callable(local_character_id):
                return None
            return str(local_character_id() or "").strip() or None

        # Review finding 7: resolve labels only for the character sessions
        # that actually exist -- never a full-library read, and no database
        # access at all for the common no-character-sessions build.
        # A session's authoritative name already wins below, so only an
        # unnamed session needs a checked card fallback.
        session_character_ids = [
            character_id
            for character_id in (
                _session_character_id(session)
                for session in store.sessions()
                if not str(getattr(session, "character_name", "") or "").strip()
            )
            if character_id is not None
        ]
        character_labels = self._console_browser_character_labels_for(
            session_character_ids
        )
        rows: list[ConsoleConversationBrowserInputRow] = []
        for session in store.sessions():
            session_workspace_id = str(session.workspace_id or "").strip()
            scope_type = (
                "global"
                if session_workspace_id == CONSOLE_GLOBAL_WORKSPACE_ID
                else "workspace"
            )
            workspace_id = None if scope_type == "global" else session_workspace_id
            # TASK-32309: a live global character session carries its
            # character identity so the flat lane excludes it like every
            # other character conversation. The session's own
            # character_name wins over the cards DB (it is the
            # authoritative projection for the bound card).
            session_character_id = _session_character_id(session)
            session_character_label = ""
            if session_character_id is not None:
                session_character_label = str(
                    getattr(session, "character_name", "") or ""
                ).strip() or character_labels.get(session_character_id, "")
            persisted_id = (
                str(session.persisted_conversation_id).strip()
                if session.persisted_conversation_id
                else ""
            )
            row_key = persisted_id or f"native:{session.id}"
            selected = session.id == active_session_id
            run_marker = (
                resolve_glyph(
                    CONSOLE_RUN_MARKER_GLYPHS.get(
                        self._console_run_marker_with_unseen(
                            controller, session, self._console_fleet_unseen_ids()
                        ),
                        "",
                    )
                )
                if controller is not None
                else ""
            )
            queued_count = (
                controller.activity_for(session.id).queued_count
                if controller is not None
                else 0
            )
            row = ConsoleConversationBrowserInputRow(
                row_key=row_key,
                conversation_id=persisted_id or None,
                native_session_id=session.id,
                title=str(session.title or "Untitled conversation"),
                scope_type=scope_type,
                workspace_id=workspace_id,
                workspace_label=self._console_browser_workspace_label(
                    workspace_id, labels
                ),
                status=(
                    session.agent_handoff_launch.label
                    if getattr(session, "agent_handoff_launch", None) is not None
                    else "active session"
                    if selected
                    else "open session"
                ),
                selected=selected,
                source_kind="native",
                updated_sort=str(session.updated_at or ""),
                run_marker=run_marker,
                queued_count=queued_count,
                character_id=session_character_id,
                character_label=session_character_label,
            )
            rows.append(self._apply_console_browser_star_state(row, starred_ids))
        return rows

    def _native_console_switcher_rows(
        self,
        cached_rows: Iterable[ConsoleConversationBrowserInputRow] = (),
    ) -> list[ConsoleConversationBrowserInputRow]:
        """Project open sessions for Active using only app-lifetime memory.

        Cached workspace rows may contribute display labels and star state,
        but this path never calls a registry, mark store, or conversation
        service. Controller activity is merged separately as memory signals.
        """
        store = self._console_chat_store
        if store is None:
            return []
        cached = tuple(cached_rows)
        labels = {
            str(row.workspace_id): str(row.workspace_label or row.workspace_id)
            for row in cached
            if row.workspace_id and row.workspace_label
        }
        cached_by_conversation = {
            str(row.conversation_id): row for row in cached if row.conversation_id
        }
        active_session_id = store.active_session_id
        controller = self._console_chat_controller
        rows: list[ConsoleConversationBrowserInputRow] = []
        for session in store.sessions():
            session_workspace_id = str(session.workspace_id or "").strip()
            scope_type = (
                "global"
                if session_workspace_id == CONSOLE_GLOBAL_WORKSPACE_ID
                else "workspace"
            )
            workspace_id = None if scope_type == "global" else session_workspace_id
            persisted_id = str(session.persisted_conversation_id or "").strip()
            cached_row = cached_by_conversation.get(persisted_id)
            workspace_label = (
                "Chats"
                if not workspace_id or workspace_id == DEFAULT_WORKSPACE_ID
                else labels.get(workspace_id, workspace_id)
            )
            queued_count = 0
            if controller is not None:
                try:
                    queued_count = controller.activity_for(session.id).queued_count
                except Exception:  # noqa: BLE001 - keep the open shell usable
                    queued_count = 0
            rows.append(
                ConsoleConversationBrowserInputRow(
                    row_key=persisted_id or f"native:{session.id}",
                    conversation_id=persisted_id or None,
                    native_session_id=session.id,
                    title=str(session.title or "Untitled conversation"),
                    scope_type=scope_type,
                    workspace_id=workspace_id,
                    workspace_label=workspace_label,
                    status=(
                        session.agent_handoff_launch.label
                        if getattr(session, "agent_handoff_launch", None) is not None
                        else "active session"
                        if session.id == active_session_id
                        else "open session"
                    ),
                    selected=session.id == active_session_id,
                    source_kind="native",
                    updated_sort=str(session.updated_at or ""),
                    queued_count=queued_count,
                    starred=bool(getattr(cached_row, "starred", False)),
                    star_enabled=bool(persisted_id),
                )
            )
        return rows

    def _membership_console_browser_rows(
        self,
        current_conversation_id: str | None = None,
    ) -> list[ConsoleConversationBrowserInputRow]:
        """Return conversation membership rows across every local workspace.

        This complete registry scan is reserved for the explicit Ctrl+K
        switcher action. Ordinary Workspaces rendering remains page-backed and
        never calls it while composing or reconciling the rail.
        """

        service = getattr(self.app_instance, "workspace_registry_service", None)
        list_conversations = getattr(service, "list_workspace_conversations", None)
        if not callable(list_conversations):
            return []
        labels = self._console_browser_workspace_labels()
        starred_ids = self._starred_console_conversation_ids()
        current_conversation = (
            current_conversation_id or self._current_console_conversation_id()
        )
        active_session = self._active_native_console_session()
        active_workspace_id = (
            str(active_session.workspace_id or "").strip()
            if active_session is not None
            else str(
                self._current_console_workspace_context().active_workspace_id or ""
            ).strip()
        )
        rows: list[ConsoleConversationBrowserInputRow] = []
        for record in self._console_browser_workspace_records():
            workspace_id = str(record.workspace_id or "").strip()
            if not workspace_id:
                continue
            try:
                memberships = list_conversations(workspace_id)
            except Exception:
                logger.opt(exception=True).debug(
                    "Unable to list Console switcher workspace conversations "
                    "workspace_id={}",
                    workspace_id,
                )
                continue
            for membership in memberships:
                conversation_id = str(getattr(membership, "item_id", "") or "").strip()
                if not conversation_id:
                    continue
                title = str(getattr(membership, "title", "") or conversation_id)
                row = ConsoleConversationBrowserInputRow(
                    row_key=(
                        f"workspace:{workspace_id}:conversation:{conversation_id}"
                    ),
                    conversation_id=conversation_id,
                    native_session_id=None,
                    title=title,
                    scope_type="workspace",
                    workspace_id=workspace_id,
                    workspace_label=self._console_browser_workspace_label(
                        workspace_id, labels
                    ),
                    status=str(getattr(membership, "role", "") or "workspace-thread"),
                    selected=bool(
                        current_conversation
                        and current_conversation == conversation_id
                        and active_workspace_id == workspace_id
                    ),
                    source_kind="membership",
                    updated_sort=str(getattr(membership, "created_at", "") or ""),
                    run_marker=self._console_browser_unseen_marker(conversation_id),
                    openable=(
                        conversation_id not in self._console_broken_conversation_ids
                    ),
                )
                rows.append(self._apply_console_browser_star_state(row, starred_ids))
        return rows

    def _console_switcher_authority(self) -> tuple[str, str]:
        """Return stable production authority with a safe harness fallback."""
        runtime = getattr(self.app_instance, "console_runtime", None)
        profile = str(getattr(runtime, "profile_authority", "") or "").strip()
        token = str(getattr(runtime, "authority_token", "") or "").strip()
        store = self._console_chat_store
        fallback = f"ephemeral:{id(store) if store is not None else id(self)}"
        return profile or fallback, token or fallback

    def console_session_switcher_active_entries(self) -> tuple[Any, ...]:
        """Return the immediate memory-only canonical Active projection."""
        cached_named_rows = self._merge_console_switcher_memory_rows(
            self._workspace_tree_search.rows,
            self._workspace_tree_search.settled_rows,
            *(attempt.rows for attempt in self._workspace_page_attempts.values()),
            *self._workspace_membership_rows.values(),
        )
        native_rows = self._native_console_switcher_rows(cached_named_rows)
        rows = self._merge_console_switcher_memory_rows(native_rows, cached_named_rows)
        # task-31208: decorate the switcher projection with per-conversation
        # appearance (icon + color) the same way the rail's merge does, so
        # both surfaces show the same customization.
        appearance_map = self._console_conversation_appearance_map(
            str(row.conversation_id or "").strip()
            for row in rows
            if str(row.conversation_id or "").strip()
        )
        rows = tuple(
            self._apply_console_browser_appearance_state(row, appearance_map)
            for row in rows
        )
        profile, token = self._console_switcher_authority()
        runtime = getattr(self.app_instance, "console_runtime", None)
        receipt_service = getattr(runtime, "activity_receipts", None)
        receipts = (
            receipt_service.unseen_snapshot() if receipt_service is not None else ()
        )
        controller = self._console_chat_controller
        signals: list[ConsoleSwitcherActivitySignal] = []
        if controller is not None:
            for row in native_rows:
                session_id = str(row.native_session_id or "").strip()
                if not session_id:
                    continue
                try:
                    activity = controller.activity_for(session_id)
                    run_state = controller.run_state_for(session_id)
                except Exception:  # noqa: BLE001 - open shell remains available
                    continue
                state = ""
                if activity.needs_approval:
                    state = "approval"
                elif activity.queue_paused:
                    state = "paused"
                elif str(getattr(run_state.status, "value", run_state.status)) not in {
                    "idle",
                    "completed",
                    "failed",
                    "stopped",
                }:
                    state = str(getattr(run_state.status, "value", run_state.status))
                elif activity.queued_count:
                    state = "queued"
                elif getattr(activity, "agent_handoff_status", "") in {
                    "Not started",
                    "Review required",
                }:
                    state = "blocked"
                if state:
                    signals.append(
                        ConsoleSwitcherActivitySignal(
                            source_key=f"controller:native:{session_id}:{state}",
                            state=state,
                            session_id=session_id,
                            conversation_id=row.conversation_id,
                            occurred_at=row.updated_sort,
                        )
                    )
        entries = build_console_active_results(
            rows,
            receipts=receipts,
            controller_signals=signals,
            profile_authority=profile,
            authority_token=token,
        )
        unread = self._manual_unread_for_rows(rows)
        return tuple(
            replace(entry, subtitle=f"{entry.subtitle} · Unread")
            if unread.get(entry.conversation_id)
            else entry
            for entry in entries
        )

    async def load_console_session_switcher_history(
        self,
        *,
        query: str,
        offset: int,
        limit: int,
    ) -> ConsoleSwitcherHistoryPage:
        """Load one validated, bounded all-local History page off the event loop.

        Args:
            query: Exact switcher query from the UI validation boundary.
            offset: Requested zero-based result offset.
            limit: Requested maximum result count.

        Returns:
            One bounded History page. Invalid queries return an empty page with
            the same recovery copy used by the switcher input.
        """
        bounded_limit = min(CONSOLE_SWITCHER_PAGE_LIMIT, max(1, int(limit)))
        bounded_offset = max(0, int(offset))
        try:
            validated_query = validate_console_switcher_query(query)
        except ValueError:
            return ConsoleSwitcherHistoryPage(
                (),
                bounded_offset,
                bounded_limit,
                0,
                f"Search is limited to {CONSOLE_SWITCHER_QUERY_MAX_LENGTH} characters.",
            )
        query_plan = plan_console_history_query(validated_query)
        if not query_plan.can_match:
            return ConsoleSwitcherHistoryPage((), bounded_offset, bounded_limit, 0)
        service = getattr(self.app_instance, "local_chat_conversation_service", None)
        include_mode = False
        if service is None:
            service = getattr(
                self.app_instance, "chat_conversation_scope_service", None
            )
            include_mode = service is not None
        list_conversations = getattr(service, "list_conversations", None)
        if not callable(list_conversations):
            return ConsoleSwitcherHistoryPage(
                (), bounded_offset, bounded_limit, 0, "History is unavailable."
            )
        labels = self._console_browser_workspace_labels()
        consumed_text_indexes: set[int] = set()
        workspace_terms: list[str] = []
        for index, term in enumerate(query_plan.ordered_terms):
            if term.kind != "workspace":
                continue
            phrase_terms = [term.value]
            following_index = index + 1
            while (
                following_index < len(query_plan.ordered_terms)
                and query_plan.ordered_terms[following_index].kind == "text"
            ):
                following_term = query_plan.ordered_terms[following_index].value
                extended_terms = (*phrase_terms, following_term)
                if not any(
                    all(
                        value.casefold() in str(label or "").casefold()
                        for value in extended_terms
                    )
                    for label in labels.values()
                ):
                    break
                phrase_terms.append(following_term)
                consumed_text_indexes.add(following_index)
                following_index += 1
            workspace_terms.extend(phrase_terms)
        text_terms = [
            term.value
            for index, term in enumerate(query_plan.ordered_terms)
            if term.kind == "text" and index not in consumed_text_indexes
        ]

        text_query = " ".join(text_terms)
        kwargs: dict[str, Any] = {
            "query": text_query,
            "scope_type": "all",
            "limit": bounded_limit,
            "offset": bounded_offset,
        }
        if workspace_terms:
            workspace_ids = tuple(
                workspace_id
                for workspace_id, label in labels.items()
                if all(
                    term in str(label or "").casefold()
                    for term in (item.casefold() for item in workspace_terms)
                )
            )
            include_global_scope = all(
                term.casefold() in "chats" for term in workspace_terms
            )
            if not workspace_ids and not include_global_scope:
                return ConsoleSwitcherHistoryPage((), bounded_offset, bounded_limit, 0)
            if workspace_ids:
                kwargs["workspace_ids"] = workspace_ids
            if include_global_scope:
                kwargs["include_global_scope"] = True
        if text_terms:
            kwargs["query_terms"] = tuple(text_terms)
            kwargs["query_workspace_ids_by_term"] = tuple(
                tuple(
                    workspace_id
                    for workspace_id, label in labels.items()
                    if term.casefold() in str(label or "").casefold()
                )
                for term in text_terms
            )
            kwargs["query_include_global_scope_by_term"] = tuple(
                term.casefold() in "chats" for term in text_terms
            )
        if include_mode:
            kwargs["mode"] = "local"
        try:
            db = getattr(service, "db", None)
            if inspect.iscoroutinefunction(list_conversations):
                payload = await list_conversations(**kwargs)
            elif bool(getattr(db, "is_memory_db", False)):
                payload = list_conversations(**kwargs)
            else:
                payload = await asyncio.to_thread(list_conversations, **kwargs)
            if inspect.isawaitable(payload):
                payload = await payload
        except Exception as exc:  # noqa: BLE001 - History degrades independently
            logger.warning(
                "Console switcher History load failed (exception_type={})",
                type(exc).__name__,
            )
            return ConsoleSwitcherHistoryPage(
                (), bounded_offset, bounded_limit, 0, "History is unavailable."
            )
        if not isinstance(payload, Mapping):
            payload = {}
        items = payload.get("items")
        if not isinstance(items, list):
            items = []
        pagination = payload.get("pagination")
        total_value = (
            pagination.get("total") if isinstance(pagination, Mapping) else None
        )
        if total_value is None:
            total_value = payload.get("total")
        try:
            total = max(len(items), int(total_value))
        except (TypeError, ValueError):
            total = len(items)
        profile, token = self._console_switcher_authority()
        labels = self._console_browser_workspace_labels()
        history_now = datetime.now(timezone.utc)
        entries: list[ConsoleSwitcherEntry] = []
        for item in items[:bounded_limit]:
            if not isinstance(item, Mapping):
                continue
            conversation_id = str(item.get("id") or "").strip()
            if not conversation_id:
                continue
            scope_type = str(item.get("scope_type") or "workspace")
            workspace_id = (
                None
                if scope_type == "global"
                else str(item.get("workspace_id") or DEFAULT_WORKSPACE_ID)
            )
            updated = parse_console_switcher_instant(
                console_persisted_row_updated_sort(item)
            )
            target = ConsoleSwitcherTarget(
                kind=SwitcherTargetKind.PERSISTED_CONVERSATION,
                profile_authority=profile,
                authority_token=token,
                session_id=None,
                conversation_id=conversation_id,
                scope_type=scope_type,
                workspace_id=workspace_id,
            )
            lifecycle = self._saved_handoff_status(item)
            workspace_label = self._console_browser_workspace_label(
                workspace_id, labels
            )
            entries.append(
                ConsoleSwitcherEntry(
                    row_key=f"conversation:{profile}:{conversation_id}",
                    title=str(item.get("title") or "Untitled conversation"),
                    subtitle=" · ".join(
                        part
                        for part in (
                            workspace_label,
                            console_conversation_status_detail(lifecycle),
                            format_console_relative_age(
                                updated.isoformat() if updated else "",
                                now=history_now,
                            ),
                        )
                        if part
                    ),
                    native_session_id=None,
                    conversation_id=conversation_id,
                    scope_type=scope_type,
                    workspace_id=workspace_id,
                    is_active=False,
                    target=target,
                    latest_at=updated,
                    workspace_label=workspace_label,
                    lifecycle=lifecycle,
                )
            )
        marks = getattr(self.app_instance, "conversation_local_marks_service", None)
        if callable(getattr(marks, "unread_ids_for", None)):
            try:
                unread = await asyncio.to_thread(
                    marks.unread_ids_for, (entry.conversation_id for entry in entries)
                )
            except Exception:  # noqa: BLE001 - history remains navigable if local marks fail
                unread = set()
            if (profile, token) == self._console_switcher_authority():
                entries = [
                    replace(entry, subtitle=f"{entry.subtitle} · Unread")
                    if entry.conversation_id in unread
                    else entry
                    for entry in entries
                ]
        local_timezone = resolve_console_history_timezone(
            getattr(self.app_instance, "local_timezone_name", None)
        )
        grouped = group_console_history_entries(
            entries,
            now=history_now,
            local_timezone=local_timezone,
        )
        return ConsoleSwitcherHistoryPage(
            grouped,
            bounded_offset,
            bounded_limit,
            total,
        )

    def _console_browser_unseen_marker(self, conversation_id: str | None) -> str:
        """Return the unseen glyph for a marked sessionless conversation."""
        conversation_key = str(conversation_id or "").strip()
        if not conversation_key:
            return ""
        if conversation_key not in self._console_fleet_unseen_ids():
            return ""
        return resolve_glyph(
            CONSOLE_RUN_MARKER_GLYPHS.get(ConsoleRunMarker.SUBAGENT_UNSEEN, "")
        )

    @staticmethod
    def _saved_handoff_status(item: Mapping[str, Any]) -> str:
        """Read bounded saved launch display facts without granting authority."""
        metadata = item.get("metadata")
        if isinstance(metadata, str):
            try:
                metadata = json.loads(metadata)
            except (TypeError, ValueError):
                metadata = None
        handoff = (
            metadata.get("console_agent_handoff")
            if isinstance(metadata, dict)
            else None
        )
        launch = (
            AgentHandoffLaunchMetadata.read(handoff.get("launch"))
            if isinstance(handoff, dict) and handoff.get("version") == 2
            else None
        )
        return launch.label if launch else str(item.get("state") or "workspace-thread")

    async def _persisted_console_browser_rows(
        self,
        query: str = "",
        current_conversation_id: str | None = None,
        *,
        scopes: tuple[tuple[str, str | None], ...] | None = None,
        offset: int = 0,
    ) -> tuple[list[ConsoleConversationBrowserInputRow], int | None, str]:
        """Return persisted global/workspace rows for grouped browser search."""
        services: list[tuple[Any, bool]] = []
        scope_service = getattr(
            self.app_instance,
            "chat_conversation_scope_service",
            None,
        )
        local_service = getattr(
            self.app_instance, "local_chat_conversation_service", None
        )

        def add_service(candidate: Any, *, include_mode: bool) -> None:
            if candidate is None:
                return
            if any(candidate is existing for existing, _include_mode in services):
                return
            services.append((candidate, include_mode))

        add_service(local_service, include_mode=False)
        add_service(getattr(scope_service, "local_service", None), include_mode=False)
        add_service(scope_service, include_mode=True)
        if not services:
            return [], None, ""

        labels = self._console_browser_workspace_labels()
        # The flat Conversations lane owns only unassigned/global and Default
        # records. Named-workspace search and pages have separate service calls.
        # TASK-32309 (review finding 1): character conversations are excluded
        # AT THE QUERY, before the service's limit/offset/total math -- a
        # post-fetch filter would let character chats consume page slots and
        # inflate the displayed total while ordinary chats beyond the page
        # stayed unfetched.
        query_scopes = scopes or (
            ("global", None),
            ("workspace", DEFAULT_WORKSPACE_ID),
        )
        last_error = ""
        for service, include_mode in services:
            stock_read = None
            if (
                not include_mode and scopes is None
                and type(query) is str and type(offset) is int
                and query_scopes == (("global", None), ("workspace", DEFAULT_WORKSPACE_ID))
            ):
                stock_read = _capture_stock_browser_read(
                    self, service, local_service, scope_service
                )
            list_conversations = (
                stock_read.reader if stock_read is not None
                else getattr(service, "list_conversations", None)
            )
            if not callable(list_conversations):
                continue
            rows: list[ConsoleConversationBrowserInputRow] = []
            total_count = 0
            saw_total = False
            saw_result = False
            current_conversation = (
                current_conversation_id or self._current_console_conversation_id()
            )
            starred_ids = self._starred_console_conversation_ids()
            stock_results = None
            if stock_read is not None:
                kwargs_pair = tuple(
                    {
                        "query": query, "scope_type": scope_type,
                        "workspace_id": workspace_id,
                        "limit": CONSOLE_CONVERSATION_BROWSER_RESULT_LIMIT,
                        "offset": max(0, int(offset)), "character_scope": "generic",
                    }
                    for scope_type, workspace_id in query_scopes
                )
                try:
                    stock_results = await stock_read.run(kwargs_pair)
                except Exception:
                    logger.exception("Unable to read captured Console browser source")
                    return [], None, "Conversation search is unavailable."
            for scope_index, (scope_type, workspace_id) in enumerate(query_scopes):
                list_kwargs: dict[str, Any] = {
                    "query": query,
                    "scope_type": scope_type,
                    "workspace_id": workspace_id,
                    "limit": CONSOLE_CONVERSATION_BROWSER_RESULT_LIMIT,
                    "offset": max(0, int(offset)),
                    # TASK-32309 (review finding 1): flat-lane ownership is a
                    # query filter, not a post-fetch removal.
                    "character_scope": "generic",
                }
                if include_mode:
                    list_kwargs["mode"] = "local"
                try:
                    if stock_results is not None:
                        stock_read.require_loop_current()
                        result, read_error = stock_results[scope_index]
                        if read_error is not None:
                            raise read_error
                    elif include_mode and not inspect.iscoroutinefunction(
                        list_conversations
                    ):
                        result = await asyncio.to_thread(
                            list_conversations, **list_kwargs
                        )
                    elif include_mode:
                        result = list_conversations(**list_kwargs)
                    else:
                        db = getattr(service, "db", None)
                        if bool(getattr(db, "is_memory_db", False)):
                            result = list_conversations(**list_kwargs)
                        else:
                            from tldw_chatbook.Chat.chat_conversation_service import (
                                ChatConversationService,
                            )
                            from tldw_chatbook.DB.ChaChaNotes_DB import CharactersRAGDB

                            def read_in_worker(
                                method=list_conversations,
                                kwargs=list_kwargs,
                                owner=service,
                                database=db,
                            ):
                                try:
                                    return method(**kwargs)
                                finally:
                                    if (
                                        type(owner) is ChatConversationService
                                        and type(database) is CharactersRAGDB
                                    ):
                                        database.close_connection()

                            result = await asyncio.to_thread(read_in_worker)
                    if inspect.isawaitable(result):
                        result = await result
                except Exception as exc:
                    if stock_read is not None and stock_read.source_changed:
                        return [], None, "Conversation search is unavailable."
                    if (
                        isinstance(exc, ValueError)
                        and "service is unavailable" in str(exc).lower()
                    ):
                        logger.debug(
                            "Local persisted conversation service is unavailable"
                        )
                        last_error = ""
                        break
                    logger.exception(
                        "Unable to search Console conversation browser "
                        "query={!r} scope_type={} workspace_id={} include_mode={}",
                        query,
                        scope_type,
                        workspace_id,
                        include_mode,
                    )
                    return (
                        rows,
                        None if not saw_total else total_count,
                        "Conversation search is unavailable.",
                    )
                saw_result = True
                if not isinstance(result, dict):
                    continue
                items = result.get("items")
                if not isinstance(items, list):
                    items = []
                total = result.get("total")
                if total is None:
                    pagination = result.get("pagination")
                    if isinstance(pagination, dict):
                        total = pagination.get("total")
                try:
                    total_count += int(total)
                    saw_total = True
                except (TypeError, ValueError):
                    total_count += len(items)
                    saw_total = True
                for item in items:
                    if not isinstance(item, dict):
                        continue
                    conversation_id = str(item.get("id") or "").strip()
                    if not conversation_id:
                        continue
                    item_scope_type = str(
                        item.get("scope_type") or scope_type or "workspace"
                    )
                    item_workspace_id = item.get("workspace_id", workspace_id)
                    normalized_workspace_id = (
                        None
                        if item_scope_type == "global"
                        else str(item_workspace_id or workspace_id or "").strip()
                    )
                    row = ConsoleConversationBrowserInputRow(
                        row_key=conversation_id,
                        conversation_id=conversation_id,
                        native_session_id=None,
                        title=str(item.get("title") or "Untitled conversation"),
                        scope_type=item_scope_type,
                        workspace_id=normalized_workspace_id,
                        workspace_label=self._console_browser_workspace_label(
                            normalized_workspace_id,
                            labels,
                        ),
                        status=self._saved_handoff_status(item),
                        selected=bool(
                            current_conversation
                            and current_conversation == conversation_id
                        ),
                        source_kind="persisted",
                        updated_sort=console_persisted_row_updated_sort(item),
                        run_marker=self._console_browser_unseen_marker(conversation_id),
                    )
                    rows.append(
                        self._apply_console_browser_star_state(row, starred_ids)
                    )
            if saw_result:
                if stock_read is not None:
                    try:
                        stock_read.require_loop_current()
                    except Exception:  # noqa: BLE001 - preserve original optional browser or availability failure results.
                        return [], None, "Conversation search is unavailable."
                return rows, total_count if saw_total else None, last_error
        return [], None, last_error

    def _invalidate_console_persisted_rows_cache(self) -> None:
        """Clear the TTL-cached persisted conversation-browser rows."""
        self._console_persisted_rows_cache = None
        self._console_persisted_rows_cache_key = None
        self._console_persisted_rows_cache_at = 0.0
        self._console_persisted_rows_cache_token += 1
        self._console_persisted_rows_refresh_key = None

    def _sync_persisted_console_browser_rows(
        self,
        query: str = "",
        current_conversation_id: str | None = None,
    ) -> tuple[list[ConsoleConversationBrowserInputRow], int | None, str]:
        """Return cached persisted rows without service or database access."""
        result = self._compute_persisted_console_browser_rows(
            query,
            current_conversation_id,
        )
        if result is not None:
            return result
        refresh_key = (
            query,
            current_conversation_id,
            self._console_persisted_rows_cache_token,
        )
        if self._console_persisted_rows_refresh_key != refresh_key:
            # task-15791: this sync derivation is called from state BUILDERS,
            # which the suite's bare-screen convention runs on an unmounted
            # ChatScreen (no active app) -- and `run_worker` on such a node
            # raises NoActiveAppError (520b1ec12 introduced the spawn here).
            # The refresh is best-effort by design ("without service or
            # database access"), so skip scheduling when the pump is not
            # running; the mounted app always is, and the guard also avoids
            # minting a coroutine that can never be awaited.
            if self._screen_running_accessor():
                self._console_persisted_rows_refresh_key = refresh_key
                self.run_worker(
                    partial(
                        self._refresh_console_persisted_rows_cache,
                        query,
                        current_conversation_id=current_conversation_id,
                        refresh_key=refresh_key,
                    ),
                    # task-24460: `run_worker` derives the worker name from
                    # `getattr(work, "__name__", "")`, and a `functools.partial`
                    # has no `__name__` -- so wrapping this call in a partial
                    # silently renamed the worker to "". That broke its
                    # boot-census allowlist row (which still reads
                    # `_refresh_console_persisted_rows_cache`) and made the
                    # worker anonymous in every worker diagnostic. Name it
                    # explicitly so the partial cannot erase it again.
                    name="_refresh_console_persisted_rows_cache",
                    group="console-persisted-browser-cache",
                    exclusive=True,
                )
        # TTL expiry schedules a refresh; it does not mean the rows vanished.
        # Keep the same query/selection visible while that worker runs so the
        # rail does not collapse and restore its scroll position on every refresh.
        # Explicit invalidation clears this entry; another key never reuses it.
        if (
            self._console_persisted_rows_cache is not None
            and self._console_persisted_rows_cache_key
            == (query, current_conversation_id)
        ):
            return self._console_persisted_rows_cache
        return [], None, ""

    async def _refresh_console_persisted_rows_cache(
        self,
        query: str = "",
        current_conversation_id: str | None = None,
        *,
        refresh_key: tuple[str, str | None, int] | None = None,
    ) -> tuple[list[ConsoleConversationBrowserInputRow], int | None, str]:
        """Refresh persisted rows asynchronously when the TTL cache is stale."""
        cached = self._compute_persisted_console_browser_rows(
            query,
            current_conversation_id,
        )
        if cached is not None:
            if (
                refresh_key is not None
                and self._console_persisted_rows_refresh_key == refresh_key
            ):
                self._console_persisted_rows_refresh_key = None
                self._sync_console_workspace_context()
            return cached
        membership_revision = self._canonical_membership_revision
        cache_token = self._console_persisted_rows_cache_token
        archive_states_before = dict(
            getattr(self.app_instance, "_conversation_archive_states", {})
        )
        archive_was_inflight = bool(
            getattr(self.app_instance, "_conversation_archive_inflight", ())
        )
        try:
            result = await self._persisted_console_browser_rows(
                query,
                current_conversation_id=current_conversation_id,
            )
        except asyncio.CancelledError:
            if self._console_persisted_rows_refresh_key == refresh_key:
                self._console_persisted_rows_refresh_key = None
            raise
        if (
            refresh_key is not None
            and self._console_persisted_rows_refresh_key != refresh_key
        ):
            return result
        if membership_revision != self._canonical_membership_revision:
            if (
                refresh_key is not None
                and self._console_persisted_rows_refresh_key == refresh_key
            ):
                self._console_persisted_rows_refresh_key = None
                self._sync_console_workspace_context()
            return result
        rows, _total, error = result
        if not error:
            self._record_canonical_owner_rows(rows)
        store = self._console_chat_store
        native_ids = [
            str(session.persisted_conversation_id)
            for session in (store.sessions() if store is not None else ())
            if session.persisted_conversation_id
        ]
        states = {}
        if native_ids:
            from ...Chat.conversation_archive_actions import (
                local_conversation_service,
                storage_call,
            )

            try:
                states = await storage_call(
                    local_conversation_service(self.app_instance),
                    "get_conversation_archive_states",
                    native_ids,
                )
            except Exception:  # noqa: BLE001 - keep current rows when recovery reads fail
                logger.debug("Archive state refresh unavailable")
                states = {}
        # Both database reads await: retain ownership through the last one,
        # including any archive receipt that settled while its snapshot loaded.
        if (
            (
                refresh_key is not None
                and self._console_persisted_rows_refresh_key != refresh_key
            )
            or membership_revision != self._canonical_membership_revision
            or cache_token != self._console_persisted_rows_cache_token
            or archive_was_inflight
            or getattr(self.app_instance, "_conversation_archive_inflight", ())
            or archive_states_before
            != getattr(self.app_instance, "_conversation_archive_states", {})
        ):
            if (
                refresh_key is not None
                and self._console_persisted_rows_refresh_key == refresh_key
            ):
                self._console_persisted_rows_refresh_key = None
                self._sync_console_workspace_context()
            return result
        cached_states = getattr(self.app_instance, "_conversation_archive_states", {})
        cached_states.update(states)
        self.app_instance._conversation_archive_states = cached_states
        self._console_persisted_rows_cache = result
        self._console_persisted_rows_cache_key = (query, current_conversation_id)
        self._console_persisted_rows_cache_at = time.monotonic()
        if refresh_key is not None:
            self._console_persisted_rows_refresh_key = None
            self._sync_console_workspace_context()
        return result

    def _compute_persisted_console_browser_rows(
        self,
        query: str = "",
        current_conversation_id: str | None = None,
    ) -> tuple[list[ConsoleConversationBrowserInputRow], int | None, str] | None:
        """Return a fresh matching cache entry without performing I/O."""
        cache_key = (query, current_conversation_id)
        if (
            self._console_persisted_rows_cache is not None
            and self._console_persisted_rows_cache_key == cache_key
            and (time.monotonic() - self._console_persisted_rows_cache_at)
            < CONSOLE_PERSISTED_ROWS_CACHE_TTL_SECONDS
        ):
            return self._console_persisted_rows_cache
        return None

    def _merge_console_browser_rows(
        self,
        *row_groups: Iterable[ConsoleConversationBrowserInputRow],
    ) -> tuple[ConsoleConversationBrowserInputRow, ...]:
        """Merge browser rows with native, membership, then persisted precedence."""
        merged: list[ConsoleConversationBrowserInputRow] = []
        seen: set[tuple[str, ...]] = set()
        starred_ids = self._starred_console_conversation_ids()
        # PR #2480 review (#4): several callers pass one-shot generators (flat
        # search settlement, paginated workspace search); materialize each
        # group ONCE here -- the appearance pass below would otherwise
        # exhaust them and silently drop their rows.
        materialized_groups = [tuple(group) for group in row_groups]
        conversation_ids = sorted(
            {
                str(row.conversation_id or "").strip()
                for group in materialized_groups
                for row in group
                if str(row.conversation_id or "").strip()
            }
        )
        appearances = self._console_conversation_appearance_map(conversation_ids)
        for group in materialized_groups:
            for raw_row in group:
                if getattr(self.app_instance, "_conversation_archive_states", {}).get(
                    str(raw_row.conversation_id or "")
                ):
                    continue
                row = self._apply_console_browser_star_state(raw_row, starred_ids)
                row = self._apply_console_browser_appearance_state(row, appearances)
                identity = self._console_browser_display_identity(row)
                if not identity[-1] or identity in seen:
                    continue
                seen.add(identity)
                merged.append(row)
        return tuple(merged)

    def _merge_console_switcher_memory_rows(
        self,
        *row_groups: Iterable[ConsoleConversationBrowserInputRow],
    ) -> tuple[ConsoleConversationBrowserInputRow, ...]:
        """Dedupe already-cached switcher rows without refreshing star state."""
        merged: list[ConsoleConversationBrowserInputRow] = []
        seen: set[tuple[str, ...]] = set()
        for group in row_groups:
            for row in group:
                if getattr(self.app_instance, "_conversation_archive_states", {}).get(
                    str(row.conversation_id or "")
                ):
                    continue
                identity = self._console_browser_display_identity(row)
                if not identity[-1] or identity in seen:
                    continue
                seen.add(identity)
                merged.append(row)
        return tuple(merged)

    def _current_console_browser_rows(
        self,
        query: str,
        current_conversation_id: str | None = None,
    ) -> tuple[tuple[ConsoleConversationBrowserInputRow, ...], int | None, str]:
        """Return current grouped browser rows plus optional search metadata."""
        native_rows = self._native_console_browser_rows(current_conversation_id)
        self._record_canonical_owner_rows(native_rows)
        local_rows = self._merge_console_browser_rows(
            native_rows,
            *self._workspace_membership_rows.values(),
        )
        persisted_rows, persisted_total, sync_error = (
            self._sync_persisted_console_browser_rows(
                query,
                current_conversation_id=current_conversation_id,
            )
        )
        cached_rows = self._console_conversation_browser_rows
        rows = self._merge_console_browser_rows(local_rows, persisted_rows, cached_rows)
        if str(query or "").strip():
            total = (
                self._console_conversation_browser_total
                if self._console_conversation_browser_total is not None
                else persisted_total
            )
        else:
            total = None
        return rows, total, self._console_conversation_browser_error or sync_error

    async def _refresh_console_conversation_browser_search(
        self,
        query: str,
        token: int,
    ) -> None:
        """Refresh grouped browser search rows if query and token are current."""
        if token != self._console_conversation_browser_search_token:
            return
        if query != self._console_conversation_browser_query:
            return
        request_key = (
            "conversations",
            query,
            token,
            self._flat_conversation_owner_token(),
            self._screen_lifecycle_token(),
            self._canonical_membership_revision,
        )
        scheduled_attempt = self._flat_conversation_search.request_key == request_key
        settled_rows = (
            self._flat_conversation_search.settled_rows
            if scheduled_attempt
            else self._console_conversation_browser_rows
        )
        settled_total = (
            self._flat_conversation_search.settled_total
            if scheduled_attempt
            else self._console_conversation_browser_total
        )
        self._flat_conversation_search.request_key = request_key
        if not str(query or "").strip():
            self._console_conversation_browser_rows = ()
            self._console_conversation_browser_total = None
            self._console_conversation_browser_error = ""
            self._sync_console_workspace_context()
            self.call_after_refresh(self._focus_console_workspace_conversation_search)
            return

        local_rows = tuple(
            row
            for row in self._filter_console_browser_rows_for_query(
                self._merge_console_browser_rows(
                    self._native_console_browser_rows(),
                    *self._workspace_membership_rows.values(),
                ),
                query,
            )
            if self._row_belongs_to_flat_projection(row)
        )
        self._console_conversation_browser_rows = local_rows
        self._console_conversation_browser_total = None
        self._console_conversation_browser_error = ""
        self._sync_console_workspace_context()
        self.call_after_refresh(self._focus_console_workspace_conversation_search)

        (
            persisted_rows,
            persisted_total,
            error_copy,
        ) = await self._persisted_console_browser_rows(query)
        if not self._flat_search_attempt_is_current(request_key):
            return
        if error_copy:
            restored_rows = settled_rows or local_rows
            self._console_conversation_browser_rows = restored_rows
            self._console_conversation_browser_total = (
                settled_total if settled_total is not None else len(restored_rows)
            )
            self._console_conversation_browser_error = error_copy
            self._flat_conversation_search.retry_query = query
            self._sync_console_workspace_context()
            self.call_after_refresh(self._focus_console_workspace_conversation_search)
            return
        merged = self._merge_console_browser_rows(
            local_rows,
            (
                row
                for row in persisted_rows
                if self._row_belongs_to_flat_projection(row)
            ),
        )
        result_total = persisted_total
        if result_total is None or result_total < len(merged):
            result_total = len(merged)
        self._console_conversation_browser_rows = merged
        self._record_canonical_owner_rows(merged)
        self._console_conversation_browser_total = result_total
        self._console_conversation_browser_error = error_copy
        self._flat_conversation_search.cache = {query: (merged, result_total)}
        self._flat_conversation_search.settled_rows = merged
        self._flat_conversation_search.settled_total = result_total
        self._flat_conversation_search.settled_query = query
        self._flat_conversation_search.retry_query = query if error_copy else None
        self._sync_console_workspace_context()
        self.call_after_refresh(self._focus_console_workspace_conversation_search)

    async def _refresh_console_conversation_browser_after_selection(self) -> None:
        """Refresh grouped browser rows after selection or star changes."""
        query = self._console_conversation_browser_query
        if not query.strip():
            self._console_conversation_browser_rows = ()
            self._console_conversation_browser_total = None
            self._console_conversation_browser_error = ""
            self._sync_console_workspace_context()
            return
        if self._console_conversation_browser_search_timer is not None:
            self._console_conversation_browser_search_timer.stop()
            self._console_conversation_browser_search_timer = None
        self._console_conversation_browser_search_token += 1
        token = self._console_conversation_browser_search_token
        await self._refresh_console_conversation_browser_search(query, token)

    def _with_console_conversation_browser_state(
        self,
        state: ConsoleWorkspaceContextState,
        current_conversation_id: str | None = None,
    ) -> ConsoleWorkspaceContextState:
        """Attach grouped all-workspaces conversation browser state."""
        legacy_state = self._with_console_workspace_conversation_section(state)
        marks_service = getattr(
            self.app_instance,
            "conversation_local_marks_service",
            None,
        )
        query = self._console_conversation_browser_query
        projection_query = (
            self._flat_conversation_search.settled_query
            if self._flat_conversation_search.error
            else query
        )
        rows, total, error_copy = self._current_console_browser_rows(
            projection_query,
            current_conversation_id=current_conversation_id,
        )
        active_workspace_id = str(
            self._current_console_workspace_context().active_workspace_id or ""
        ).strip()
        active_workspace_label = str(
            legacy_state.workspace_label.removeprefix("Workspace: ") or "Chats"
        )
        legacy_membership_rows = tuple(
            ConsoleConversationBrowserInputRow(
                row_key=row.conversation_id,
                conversation_id=row.conversation_id,
                native_session_id=None,
                title=row.title,
                scope_type="workspace",
                workspace_id=active_workspace_id or DEFAULT_WORKSPACE_ID,
                workspace_label=active_workspace_label,
                status=row.status,
                selected=row.selected,
                source_kind="persisted",
            )
            for row in legacy_state.conversation_rows
        )
        rows = self._merge_console_browser_rows(
            rows,
            (
                row
                for row in legacy_membership_rows
                if self._row_belongs_to_flat_projection(row)
            ),
        )
        workspace_rows = (
            self._workspace_tree_search.settled_rows
            if self._workspace_tree_search.error
            else self._workspace_tree_search.rows
        )
        materialized_ids = {
            str(row.conversation_id)
            for group in (
                rows,
                legacy_membership_rows,
                workspace_rows,
                *(attempt.rows for attempt in self._workspace_page_attempts.values()),
                *self._workspace_membership_rows.values(),
            )
            for row in group
            if row.conversation_id
        }
        for conversation_id in tuple(self._canonical_owner_observations):
            if conversation_id not in materialized_ids:
                self._canonical_owner_observations.pop(conversation_id, None)
        canonical_rows = (*rows, *legacy_membership_rows, *workspace_rows)
        canonical_memberships: dict[str, list[str]] = {}
        canonical_labels: dict[str, str] = {}
        for row in canonical_rows:
            conversation_id = str(row.conversation_id or "").strip()
            if not conversation_id:
                continue
            workspace_id = str(row.workspace_id or "").strip()
            owner_id = (
                DEFAULT_WORKSPACE_ID
                if row.scope_type == "global"
                or workspace_id in ("", DEFAULT_WORKSPACE_ID)
                else workspace_id
            )
            canonical_memberships.setdefault(owner_id, []).append(conversation_id)
            canonical_labels.setdefault(owner_id, str(row.workspace_label or owner_id))
        for conversation_id, owner_id in self._canonical_owner_observations.items():
            canonical_memberships.setdefault(owner_id, []).append(conversation_id)
            canonical_labels.setdefault(
                owner_id,
                "Default" if owner_id == DEFAULT_WORKSPACE_ID else owner_id,
            )
        if canonical_memberships:
            self.apply_workspace_membership_snapshot(
                {
                    workspace_id: tuple(conversation_ids)
                    for workspace_id, conversation_ids in canonical_memberships.items()
                },
                complete=False,
                workspace_labels=canonical_labels,
                canonical_rows=canonical_rows,
            )
        # TASK-22201: ONE canonical-owner + overlay pass per build. The
        # browser rows and the workspace tree's no-query source (browser
        # rows + surviving page-attempt rows) used to run this pipeline
        # separately -- twice per build, up to six times per run tick. Both
        # passes are per-row (the canonical filter and every overlay marker
        # depend only on the row itself plus controller/store state), so one
        # pass over the merged union, partitioned back out by display
        # identity, is exactly equivalent. Stale page attempts are pruned
        # FIRST -- the projection used to do that before its own merge, and
        # a just-deleted workspace's rows must not ride in via the union.
        self._prune_stale_workspace_page_attempts()
        browser_identities = {
            self._console_browser_display_identity(row) for row in rows
        }
        union_rows = self._merge_console_browser_rows(
            rows,
            *(attempt.rows for attempt in self._workspace_page_attempts.values()),
        )
        union_rows = self._rows_with_latest_canonical_owner(union_rows)
        union_rows = self._overlay_current_console_browser_markers(
            union_rows, current_conversation_id
        )
        rows = tuple(
            row
            for row in union_rows
            if self._console_browser_display_identity(row) in browser_identities
        )
        if not projection_query.strip() and not self._flat_conversation_search.error:
            ordinary_rows = tuple(
                row for row in rows if self._row_belongs_to_flat_projection(row)
            )
            self._flat_conversation_search.settled_rows = ordinary_rows
            self._flat_conversation_search.settled_total = total
            self._flat_conversation_search.settled_query = ""
        bridge = self._ensure_console_agent_bridge()
        subagent_counts = self._console_subagent_counts_for_rows(bridge, rows)
        browser = build_console_conversation_browser_state(
            rows=rows,
            active_workspace_id=(
                self._current_console_workspace_context().active_workspace_id
            ),
            group_collapse_preferences=(
                self._console_conversation_browser_collapse_preferences()
            ),
            query=projection_query,
            marks_available=marks_service is not None,
            error_copy=error_copy or self._console_conversation_browser_error,
            result_total_count=total,
            result_limit=CONSOLE_CONVERSATION_BROWSER_RESULT_LIMIT,
            subagent_counts=subagent_counts,
            progress_counts=(
                bridge.progress_counts()
                if callable(getattr(bridge, "progress_counts", None))
                else {}
            ),
            # The visible-row cap grows with the measured rail body height so
            # the Chats section expands to fill its even share of the rail
            # alongside the Workspaces tree; the historical 12-row default
            # still floors it on short/unmeasured rails.
            group_row_limit=console_conversation_browser_group_row_limit(
                self._console_rail_body_height()
            ),
        )
        return replace(
            state,
            conversation_browser=browser,
            conversation_section=legacy_state.conversation_section,
            workspace_tree=self.workspace_tree_projection(
                rows, prepared_rows=union_rows
            ),
            workspace_query=self._workspace_tree_search.query,
            workspace_loading=self._workspace_tree_search.request_key is not None,
            workspace_error=str(self._workspace_tree_search.error or ""),
            workspace_retry_available=(
                self._workspace_tree_search.retry_query is not None
            ),
            workspace_marks_available=marks_service is not None,
        )

    # -- Workspace policy context -------------------------------------------

    #: Memoized active-workspace resolution for the per-keystroke Console
    #: context read: (registry service instance, its ``mutation_generation``
    #: at read time, resolved workspace id), or ``None`` before the first
    #: cacheable read. A CLASS attribute default, matching the screen's
    #: memo conventions, so hand-built fixtures that skip ``__init__``
    #: still read a defined value.
    _console_workspace_id_memo: "tuple[Any, int, str] | None" = None

    def _resolve_console_active_workspace_id(self) -> str:
        """Resolve the active workspace id read-only, memoized per screen.

        TASK-21118: this sits on the per-keystroke path (DraftChanged ->
        control-state build -> provider selection ->
        ``_current_console_workspace_context``), which used to call
        ``ensure_default_workspace`` ~1.25x per key -- a synchronous SQLite
        read on the UI thread, plus that method's repair side-effects (a
        probing SELECT and, with stale Default bindings, a DELETE write
        transaction). Two changes here:

        * READ-ONLY: the keystroke path now calls ``get_active_workspace``
          only. The ensure/repair behavior lives at session-start and
          workspace-switch seams instead (app wiring's
          ``ensure_default_workspace``, ``set_active_workspace``'s
          switch-to-Default repair, ``_set_active_workspace_for_console_
          session``'s global branch, ``_console_browser_workspace_records``,
          and ``archive_workspace``). A missing active workspace is floored
          to ``DEFAULT_WORKSPACE_ID`` in memory -- the same id ``ensure_
          default_workspace`` returned for that state -- without writing.
        * MEMOIZED: the resolution is served from a memo revalidated
          against the registry's in-memory ``mutation_generation`` (bumped
          by every workspace-record mutator, from any screen), so a warm
          keystroke performs zero DB round-trips while a workspace change
          anywhere -- Console switcher, browser row, session switch,
          Settings "Set active", Library create, archive -- invalidates it
          on the very next read. The generation must be a real ``int``
          before anything is cached: a MagicMock double's auto-attribute
          compares equal to itself forever and would freeze the memo, so
          doubles without an integer generation stay on live reads.

        This memo COMPOSES with the task-15452 per-pass derivation memo
        rather than replacing it: that memo dedupes the provider-selection
        legs within one synchronous pass, and each pass's single remaining
        context read is what this cross-pass memo serves.
        """
        registry_service = getattr(
            self.app_instance, "workspace_registry_service", None
        )
        if registry_service is None:
            return CONSOLE_GLOBAL_WORKSPACE_ID
        generation = getattr(registry_service, "mutation_generation", None)
        if isinstance(generation, bool) or not isinstance(generation, int):
            generation = None
        # getattr, not a bare read: `_current_console_workspace_context` is
        # deliberately callable unbound on duck-typed screen stand-ins (see
        # test_console_staged_evidence_strip's bundleless-launch pin), which
        # lack this class-attribute default.
        memo = getattr(self, "_console_workspace_id_memo", None)
        if (
            memo is not None
            and generation is not None
            and memo[0] is registry_service
            and memo[1] == generation
        ):
            return memo[2]
        workspace_id = CONSOLE_GLOBAL_WORKSPACE_ID
        try:
            get_active_workspace = getattr(
                registry_service, "get_active_workspace", None
            )
            if callable(get_active_workspace):
                active_workspace = get_active_workspace()
                if active_workspace is None:
                    # Read-only floor: `ensure_default_workspace` used to
                    # create/activate the built-in Default here and return
                    # it. Boot wiring and every switch seam keep the
                    # registry resting on an active workspace, so this
                    # only covers the moments in between -- same id,
                    # minus the write.
                    if generation is not None:
                        self._console_workspace_id_memo = (
                            registry_service,
                            generation,
                            DEFAULT_WORKSPACE_ID,
                        )
                    return DEFAULT_WORKSPACE_ID
            else:
                # Reduced test doubles supply only `ensure_default_workspace`;
                # production always has the read-only accessor above.
                ensure_default_workspace = getattr(
                    registry_service, "ensure_default_workspace", None
                )
                if not callable(ensure_default_workspace):
                    return workspace_id
                active_workspace = ensure_default_workspace()
            candidate = getattr(active_workspace, "workspace_id", None)
            if candidate:
                workspace_id = str(candidate)
        except Exception:
            logger.debug("Console workspace registry was unavailable for send context")
            return workspace_id
        if generation is not None:
            self._console_workspace_id_memo = (
                registry_service,
                generation,
                workspace_id,
            )
        return workspace_id

    def _current_console_workspace_context(self) -> ConsoleWorkspaceContext:
        """Return explicit workspace policy context for native Console sends.

        Runs on every printable keystroke; the active-workspace resolution
        is memoized and read-only (see
        ``_resolve_console_active_workspace_id``), and the staged-launch
        evidence bundle below is parsed at most once per launch
        (``evidence_bundle_from_launch`` caches on the launch object).

        Resolution goes through the class, not ``self``: this method is
        callable unbound on duck-typed screen stand-ins exposing only
        ``app_instance`` and ``_pending_console_launch_context``, and both
        legs preserve that contract.
        """
        workspace_id = ConsoleWorkspaceController._resolve_console_active_workspace_id(
            self
        )

        staged_sources: list[ConsoleStagedSource] = []
        pending_launch = self._pending_console_launch_context
        if pending_launch is not None:
            payload = pending_launch.payload
            source_workspace = payload.get("workspace_id")
            launch_workspace_id = str(source_workspace) if source_workspace else None
            # RAG UX v2 PR-4: this builder is the SINGLE seam feeding both
            # the Inspector rail badge ("{n} staged") and the settings
            # context estimate, and it used to append exactly ONE staged
            # source per launch -- so the status chip could read "Sources: 4
            # staged" while its two siblings read 1. One row per bundle
            # reference puts all three in the same vocabulary (and gives the
            # workspace policy check a real per-source id to gate on).
            bundle = evidence_bundle_from_launch(pending_launch)
            references = bundle.references if bundle is not None else ()
            for reference in references:
                chunk_id = reference.metadata.get("chunk_id")
                # Two chunks of one document share a source_id; qualify with
                # the chunk id (exactly as the capture adapter does) so
                # `allowed_sources`' source_id dedupe cannot collapse them.
                staged_sources.append(
                    ConsoleStagedSource(
                        source_id=str(
                            chunk_id
                            if isinstance(chunk_id, str) and chunk_id
                            else reference.source_id
                        ),
                        label=reference.title,
                        source_type=reference.source_type,
                        workspace_id=reference.workspace_id or launch_workspace_id,
                    )
                )
            if not staged_sources:
                # A launch with no (or an empty) evidence bundle is still one
                # staged item -- the same fallback `console_staged_source_count`
                # and the strip use, so all three surfaces still agree.
                source_id = (
                    payload.get("source_id")
                    or payload.get("target_id")
                    or payload.get("run_id")
                    or pending_launch.title
                )
                staged_sources.append(
                    ConsoleStagedSource(
                        source_id=str(source_id),
                        label=pending_launch.title,
                        source_type=str(pending_launch.source),
                        workspace_id=launch_workspace_id,
                    )
                )

        return ConsoleWorkspaceContext(
            active_workspace_id=workspace_id,
            staged_sources=tuple(staged_sources),
        )

    def _active_console_workspace_id_for_conversation_search(self) -> str:
        """Return the current active workspace id for Console conversation search."""
        try:
            workspace_id = str(
                self._current_console_workspace_context().active_workspace_id or ""
            ).strip()
        except Exception:
            logger.opt(exception=True).debug(
                "Unable to read current workspace context for conversation search",
            )
            workspace_id = ""
        if workspace_id:
            return workspace_id
        service = getattr(self.app_instance, "workspace_registry_service", None)
        get_active_workspace = getattr(service, "get_active_workspace", None)
        if callable(get_active_workspace):
            try:
                workspace = get_active_workspace()
            except Exception:
                logger.opt(exception=True).debug(
                    "Unable to read active workspace for conversation search"
                )
                workspace = None
            workspace_id = str(getattr(workspace, "workspace_id", "") or "").strip()
            if workspace_id:
                return workspace_id
        store = self._console_chat_store
        if store is not None and store.workspace_context.active_workspace_id:
            return str(store.workspace_context.active_workspace_id)
        return ""

    # -- Workspace switcher / rename / archive / create ---------------------

    def _open_console_workspace_switcher(self, *, show_archived: bool = False) -> None:
        """Open the active Console workspace switcher."""
        registry_service = getattr(
            self.app_instance, "workspace_registry_service", None
        )
        if registry_service is None:
            self.app_instance.notify(
                "Workspace service is not ready.", severity="warning"
            )
            return
        from tldw_chatbook.Chat.conversation_archive_actions import storage_call

        receipt = getattr(self, "_console_workspace_archive_receipt", None)
        # A completion received while away remains reachable on the next visit.
        show_archived = show_archived or receipt is not None
        request = object()
        self._console_workspace_switcher_request = request

        def _current() -> bool:
            return (
                self._console_workspace_switcher_request is request
                and self._screen.is_mounted
                and self._screen.app.screen is self._screen
            )

        async def _open() -> None:
            try:
                workspaces = tuple(
                    await storage_call(
                        registry_service, "list_workspaces", include_archived=True
                    )
                )
                active_workspace = await storage_call(
                    registry_service, "get_active_workspace"
                )
            except Exception:
                logger.exception("Unable to open Console workspace switcher")
                if not _current():
                    return
                self.app_instance.notify(
                    "Workspace registry could not be read.",
                    severity="error",
                )
                return
            if not _current():
                return
            if not workspaces:
                self.app_instance.notify(
                    "Create one with the rail's New button or in Settings > Workspaces.",
                    severity="warning",
                )
                return

            active_workspace_id = (
                active_workspace.workspace_id if active_workspace is not None else None
            )

            # Task 20: per-binding SSH status chips (worst state per
            # workspace row) read from the status cache OFF the UI loop --
            # the same discipline as the workspace fetch above.
            try:
                ssh_status_chips = await asyncio.to_thread(
                    _console_workspace_ssh_status_chips, registry_service, workspaces
                )
            except Exception:  # noqa: BLE001 - display-only, degrade silently
                ssh_status_chips = {}

            def _switch_to(workspace_id: str) -> None:
                self._switch_console_workspace(workspace_id)

            def _apply_workspace_switch(
                result: tuple[str, str] | None,
            ) -> None:
                if not result:
                    return
                action, workspace_id = result
                if action == "switch":
                    _switch_to(workspace_id)
                elif action == "rename":
                    self._open_console_workspace_rename(workspace_id)
                elif action == "archive":
                    self._confirm_console_workspace_archive(workspace_id)
                elif action in {"restore", "restore_as"}:
                    self._restore_console_workspace(
                        workspace_id, rename=action == "restore_as"
                    )

            self.push_screen(
                ConsoleWorkspaceSwitcherModal(
                    workspaces=workspaces,
                    active_workspace_id=active_workspace_id,
                    show_archived=show_archived,
                    ssh_status_chips=ssh_status_chips,
                ),
                callback=_apply_workspace_switch,
            )
            if getattr(self, "_console_workspace_archive_receipt", None) is receipt:
                self._console_workspace_archive_receipt = None

        self._screen.app.run_worker(
            _open(), group="console-workspace-switcher", exclusive=True
        )

    def _restore_console_workspace(
        self,
        workspace_id: str,
        *,
        rename: bool = False,
        expected_record: WorkspaceRecord | None = None,
    ) -> None:
        """Restore asynchronously without changing active workspace or session."""
        from tldw_chatbook.Chat.conversation_archive_actions import storage_call

        registry = getattr(self.app_instance, "workspace_registry_service", None)
        if registry is None:
            return
        request = object()
        self._console_workspace_restore_request = request

        def _current() -> bool:
            return (
                self._console_workspace_restore_request is request
                and self._screen.is_mounted
                and self._screen.app.screen is self._screen
            )

        def _failed(exc: WorkspaceRegistryServiceError) -> None:
            if not _current():
                return
            self.app_instance.notify(
                f"Could not restore workspace: {exc}. Retry from Show archived; "
                "use Restore as if the name is in use.",
                severity="warning",
            )
            self._open_console_workspace_switcher(show_archived=True)

        async def _restore(name: str | None = None) -> None:
            if not _current():
                return

            async def _complete_restore() -> None:
                try:
                    restored = await storage_call(
                        registry, "unarchive_workspace", workspace_id, name=name
                    )
                except WorkspaceRegistryServiceError as exc:
                    _failed(exc)
                    return
                # A committed restore invalidates cached data even if the user left.
                self._invalidate_console_persisted_rows_cache()
                if not _current():
                    return
                self.run_worker(
                    self._sync_native_console_chat_ui(),
                    exclusive=True,
                    group="console-sync",
                )
                self.app_instance.notify(
                    f"Restored {restored.name}. Active workspace unchanged; use Switch to open it.",
                    severity="information",
                )

            # Cancelling the exclusive worker cannot cancel a SQLite write
            # already executing in a thread or skip its cache publication.
            operation = asyncio.create_task(_complete_restore())
            operations = getattr(
                self.app_instance, "_workspace_lifecycle_operations", None
            )
            if operations is None:
                operations = self.app_instance._workspace_lifecycle_operations = set()
            operations.add(operation)
            operation.add_done_callback(operations.discard)
            operation.add_done_callback(
                lambda task: None if task.cancelled() else task.exception()
            )
            await asyncio.shield(operation)

        def _rename_finished(name: str | None) -> None:
            if name:
                self._screen.app.run_worker(
                    _restore(name), group="console-workspace-restore", exclusive=True
                )

        async def _prepare() -> None:
            try:
                record = await storage_call(registry, "get_workspace", workspace_id)
            except WorkspaceRegistryServiceError as exc:
                _failed(exc)
                return
            if not _current():
                return
            if expected_record is not None and record != expected_record:
                self.app_instance.notify(
                    "Workspace changed since archive. Review it in Show archived before restoring.",
                    severity="warning",
                )
                self._open_console_workspace_switcher(show_archived=True)
                return
            if record is None or not record.archived:
                self.app_instance.notify(
                    "Workspace is no longer archived.", severity="warning"
                )
                return
            if rename:
                self.push_screen(
                    ConsoleWorkspaceRenameModal(
                        current_name=record.name, restoring=True
                    ),
                    callback=_rename_finished,
                )
            else:
                await _restore()

        self._screen.app.run_worker(
            _prepare(), group="console-workspace-restore", exclusive=True
        )

    def _open_console_workspace_rename(self, workspace_id: str) -> None:
        """Prompt for and apply a new workspace name (TASK-714)."""
        registry_service = getattr(
            self.app_instance, "workspace_registry_service", None
        )
        if registry_service is None:
            self.app_instance.notify(
                "Workspace service is not ready.", severity="warning"
            )
            return
        record = registry_service.get_workspace(workspace_id)
        if record is None:
            self.app_instance.notify(
                "Workspace is no longer available.", severity="warning"
            )
            return

        def _apply_rename(new_name: str | None) -> None:
            if not new_name:
                return
            try:
                renamed = registry_service.rename_workspace(workspace_id, new_name)
            except WorkspaceRegistryServiceError as exc:
                self.app_instance.notify(str(exc), severity="warning")
                return
            except Exception:
                logger.opt(exception=True).warning("Unable to rename Console workspace")
                self.app_instance.notify(
                    "Workspace could not be renamed.", severity="error"
                )
                return
            self._sync_console_chat_core_state()
            self._sync_console_workspace_context()
            self.run_worker(
                self._sync_native_console_chat_ui(),
                exclusive=True,
                group="console-sync",
            )
            self.app_instance.notify(
                f"Renamed workspace to {renamed.name}.", severity="information"
            )

        self.push_screen(
            ConsoleWorkspaceRenameModal(current_name=record.name),
            callback=_apply_rename,
        )

    def _confirm_console_workspace_archive(self, workspace_id: str) -> None:
        """Confirm and archive a workspace without blocking registry storage."""
        registry_service = getattr(
            self.app_instance, "workspace_registry_service", None
        )
        if registry_service is None:
            self.app_instance.notify(
                "Workspace service is not ready.", severity="warning"
            )
            return
        from tldw_chatbook.Chat.conversation_archive_actions import (
            capture_console_archive_draft,
            storage_call,
            workspace_archive_refusal,
        )
        from tldw_chatbook.Widgets.Console.console_workspace_switcher_modal import (
            WorkspaceArchiveReceiptModal,
        )

        request = object()
        self._console_workspace_archive_request = request
        dialog = None
        archived_record = None

        def _current() -> bool:
            return (
                self._console_workspace_archive_request is request
                and self._screen.is_mounted
                and self._screen.app.screen in (self._screen, dialog)
            )

        def _refusal() -> str | None:
            capture_console_archive_draft(self.app_instance, screen=self._screen)
            return workspace_archive_refusal(self.app_instance, workspace_id)

        def _failed(message: str) -> None:
            if _current():
                self.app_instance.notify(message, severity="warning")

        async def _prepare() -> None:
            nonlocal dialog
            refusal = _refusal()
            if refusal:
                _failed(refusal)
                return
            try:
                record = await storage_call(
                    registry_service, "get_workspace", workspace_id
                )
            except WorkspaceRegistryServiceError as exc:
                _failed(str(exc))
                return
            except Exception:  # noqa: BLE001 - UI storage boundary offers retry
                logger.opt(exception=True).warning("Unable to read Console workspace")
                _failed(
                    "Workspace could not be read. Retry from the workspace switcher."
                )
                return
            if not _current():
                return
            if record is None:
                self.app_instance.notify(
                    "Workspace is no longer available.", severity="warning"
                )
                return
            was_active = bool(record.active)
            confirmation_cancelled = False
            receipt_shown = False

            async def _complete_archive() -> None:
                nonlocal archived_record
                try:
                    archived_record = await storage_call(
                        registry_service, "archive_workspace", workspace_id
                    )
                except WorkspaceRegistryServiceError as exc:
                    _failed(str(exc))
                    return
                except Exception:
                    logger.opt(exception=True).warning(
                        "Unable to archive Console workspace"
                    )
                    if _current():
                        self.app_instance.notify(
                            "Workspace could not be archived.", severity="error"
                        )
                    return
                # Commit completion survives cancellation of the confirming UI.
                self._invalidate_console_persisted_rows_cache()
                if self._console_workspace_archive_request is request:
                    self._console_workspace_archive_receipt = archived_record
                if not _current():
                    return
                self._sync_console_chat_core_state()
                if was_active:
                    self._activate_console_session_for_workspace(DEFAULT_WORKSPACE_ID)
                suffix = (
                    " Console switched to the Default workspace." if was_active else ""
                )
                self.app_instance.notify(
                    f"Archived {record.name}. Its conversations stay saved in "
                    f"Library.{suffix}",
                    severity="information",
                )
                if confirmation_cancelled:
                    await _show_receipt()

            async def _archive() -> None:
                nonlocal confirmation_cancelled
                if not _current():
                    return
                refusal = _refusal()
                if refusal:
                    _failed(refusal)
                    return
                store = getattr(
                    getattr(self.app_instance, "console_runtime", None),
                    "chat_store",
                    None,
                )
                reserved = (
                    {
                        session.persisted_conversation_id
                        for session in store.sessions()
                        if session.workspace_id == workspace_id
                        and session.persisted_conversation_id
                    }
                    if store is not None
                    else set()
                )
                inflight = getattr(
                    self.app_instance, "_conversation_archive_inflight", None
                )
                if inflight is None:
                    inflight = self.app_instance._conversation_archive_inflight = set()
                if reserved & inflight:
                    _failed("An archive change is already in progress.")
                    return
                inflight.update(reserved)

                async def _complete_reserved_archive() -> None:
                    try:
                        await _complete_archive()
                    finally:
                        inflight.difference_update(reserved)

                operation = asyncio.create_task(_complete_reserved_archive())
                operations = getattr(
                    self.app_instance, "_workspace_lifecycle_operations", None
                )
                if operations is None:
                    operations = self.app_instance._workspace_lifecycle_operations = (
                        set()
                    )
                operations.add(operation)
                operation.add_done_callback(operations.discard)
                operation.add_done_callback(
                    lambda task: None if task.cancelled() else task.exception()
                )
                try:
                    await asyncio.shield(operation)
                except asyncio.CancelledError:
                    confirmation_cancelled = True
                    raise

            def _recovery(action: str | None) -> None:
                if action == "view":
                    self._open_console_workspace_switcher(show_archived=True)
                elif action == "undo":
                    self._restore_console_workspace(
                        workspace_id, expected_record=archived_record
                    )

            async def _show_receipt() -> None:
                nonlocal receipt_shown
                if (
                    not receipt_shown
                    and archived_record is not None
                    and _current()
                    and self._screen.app.screen is self._screen
                ):
                    receipt_shown = True
                    if (
                        getattr(self, "_console_workspace_archive_receipt", None)
                        is archived_record
                    ):
                        self._console_workspace_archive_receipt = None
                    await self.push_screen(
                        WorkspaceArchiveReceiptModal(name=record.name),
                        callback=_recovery,
                    )
                    self.run_worker(
                        self._sync_native_console_chat_ui(),
                        exclusive=True,
                        group="console-sync",
                    )

            async def _after_archive(confirmed: bool | None) -> None:
                if confirmed or confirmation_cancelled:
                    await _show_receipt()

            dialog = ConfirmationDialog(
                title="Archive workspace?",
                message=(
                    f"Archive {record.name}? Its conversations stay saved and "
                    "remain visible in Library; the workspace disappears from "
                    "the active switcher list and the Console browser. Recover it using Show archived."
                ),
                confirm_label="Archive",
                confirm_callback=_archive,
            )
            self.push_screen(dialog, callback=_after_archive)

        self._screen.app.run_worker(
            _prepare(), group="console-workspace-archive", exclusive=True
        )

    def _create_console_workspace(self) -> None:
        """Open the shared create dialog (spec 2026-08-17 §4.3)."""
        registry_service = getattr(
            self.app_instance, "workspace_registry_service", None
        )
        if registry_service is None:
            self.app_instance.notify(
                "Workspace service is not ready.", severity="warning"
            )
            return
        from tldw_chatbook.Widgets.workspace_create_modal import WorkspaceCreateModal

        self.push_screen(
            WorkspaceCreateModal(
                registry_service=registry_service,
                persona_service=getattr(
                    self.app_instance, "local_character_persona_service", None
                ),
                description="Local workspace created from Console.",
            ),
            self._handle_workspace_create_result,
        )

    def _open_workspace_persona_default(self, workspace_id: str) -> None:
        """Edit future defaults for the requested workspace without changing sessions."""
        from ...Widgets.workspace_persona_default import WorkspacePersonaDefaultModal

        registry = getattr(self.app_instance, "workspace_registry_service", None)
        if registry is None or not workspace_id or workspace_id == DEFAULT_WORKSPACE_ID:
            return
        record = registry.get_workspace(workspace_id)
        if record is None or record.archived:
            self.app_instance.notify(
                "This workspace is unavailable.", severity="warning"
            )
            return
        self.push_screen(
            WorkspacePersonaDefaultModal(
                registry,
                getattr(self.app_instance, "local_character_persona_service", None),
                workspace_id,
            )
        )

    def _handle_workspace_create_result(
        self, result: WorkspaceCreateResult | None
    ) -> None:
        """Console-side post-create sync; the modal already created/bound."""
        if result is None:
            return
        if result.offer_profile_interview:
            from ...Personal_Context.interview_launch import (
                launch_workspace_profile_interview_after_commit,
            )

            launch_workspace_profile_interview_after_commit(
                self.app_instance,
                workspace_id=result.workspace_id,
                workspace_label=result.name,
                continuation=lambda: (
                    ConsoleWorkspaceController._continue_workspace_create_result(
                        self, result
                    )
                ),
            )
            return
        ConsoleWorkspaceController._continue_workspace_create_result(self, result)

    def _continue_workspace_create_result(self, result: WorkspaceCreateResult) -> None:
        """Run the established Console sync after the optional interview."""

        registry_service = getattr(
            self.app_instance, "workspace_registry_service", None
        )
        if registry_service is None:
            return
        for _folder, message in result.failed_folders:
            self.app_instance.notify(message, severity="warning")
        if not result.make_active:
            self._sync_console_workspace_context()
            self.app_instance.notify(f"Created {result.name}.", severity="information")
            if result.project_skills:
                maybe_offer_project_skills_import(
                    self.app_instance, result.project_skills
                )
            return
        try:
            registry_service.set_active_workspace(result.workspace_id)
        except WorkspaceRegistryServiceError:
            logger.opt(exception=True).warning(
                "Unable to activate new Console workspace"
            )
            self.app_instance.notify(
                "Workspace created but could not be activated.", severity="error"
            )
            if result.project_skills:
                maybe_offer_project_skills_import(
                    self.app_instance, result.project_skills
                )
            return
        self._sync_console_chat_core_state()
        self._activate_console_session_for_workspace(result.workspace_id)
        self._sync_console_workspace_context()
        self.run_worker(
            self._sync_native_console_chat_ui(), exclusive=True, group="console-sync"
        )
        # TASK-713: the whole sequence is invisible when the Workspace status
        # row is scrolled out of view -- keep the toast even with the modal.
        self.app_instance.notify(
            f"Created {result.name} and switched Console to it.",
            severity="information",
        )
        if result.project_skills:
            maybe_offer_project_skills_import(self.app_instance, result.project_skills)

    async def open_console_workspace_conversation(
        self,
        conversation_id: str,
        *,
        row_key: str = "",
        target_workspace_id: str | None = None,
        resume_if: Callable[[], bool] | None = None,
    ) -> bool | None:
        """Open a saved conversation while its optional resume claim is current.

        Args:
            conversation_id: Saved conversation identity or native session key.
            row_key: Optional browser row that owns the selected scope.
            target_workspace_id: Fallback workspace for a cold load.
            resume_if: Optional predicate rechecked after token preparation and
                before changing the active session.

        Returns:
            True after activation, False for a missing row, or None when the
            request is superseded or presentation fails.
        """

        conversation_id = str(conversation_id or "").strip()
        explicit_row_key = str(row_key or "").strip()
        browser_row = (
            self._find_console_browser_row(
                explicit_row_key,
                conversation_id=conversation_id,
            )
            if explicit_row_key
            else None
        )
        prior_browser_workspace_id: str | None = None
        if browser_row is not None:
            prior_browser_workspace_id = (
                self._active_console_workspace_id_for_conversation_search() or None
            )
            row_conversation_id = str(browser_row.conversation_id or "").strip()
            session_id = self._session_id_for_browser_row_fn(browser_row)
        else:
            row_conversation_id = conversation_id
            session_id = self._console_session_id_for_workspace_conversation(
                conversation_id
            )
        if session_id is None:
            if not row_conversation_id:
                self.app_instance.notify(
                    "This conversation row is no longer available.",
                    severity="warning",
                )
                return False
            self._set_conversation_row_loading_fn(row_conversation_id, True)
            try:
                resumed = await self._resume_console_workspace_conversation(
                    row_conversation_id,
                    target_scope_type=(
                        browser_row.scope_type
                        if browser_row is not None
                        else ("workspace" if target_workspace_id else None)
                    ),
                    target_workspace_id=(
                        browser_row.workspace_id
                        if browser_row is not None
                        else target_workspace_id
                    ),
                    resume_if=resume_if,
                )
            finally:
                try:
                    self._set_conversation_row_loading_fn(row_conversation_id, False)
                except BaseException:
                    logger.opt(exception=True).warning(
                        "Unable to clear Console conversation-row loading state"
                    )
            if resumed:
                if browser_row is not None:
                    self._activate_console_workspace_for_browser_row(
                        browser_row,
                        previous_workspace_id=prior_browser_workspace_id,
                    )
                return True
            if resumed is None:
                return None
            self._mark_conversation_row_broken_fn(row_conversation_id)
            self.app_instance.notify(
                CONSOLE_SAVED_CONVERSATION_RESUME_FAILURE_COPY,
                severity="warning",
                timeout=15,
            )
            return False
        controller = self._ensure_chat_controller_fn()
        store = controller.store
        prior_active_session_id = store.active_session_id
        visit = (
            await self._begin_manual_read_visit(session_id)
            if self._begin_manual_read_visit
            else None
        )
        try:
            from .conversation_token_preparation import prepare_conversation_tokens

            await prepare_conversation_tokens(self._screen, store, session_id)
            if resume_if is not None and not resume_if():
                return None
            if prior_active_session_id != session_id:
                self._capture_console_draft_switch_snapshot()
                controller.switch_session(session_id)
                _bind_composer_after_switch(self)
            self._set_active_workspace_for_console_session(session_id)
            session = next(item for item in store.sessions() if item.id == session_id)
            try:
                await self._refresh_console_effective_scope_and_sync(session)
            except Exception:  # noqa: BLE001 - optional display must not block activation
                logger.opt(exception=True).warning(
                    "Failed to refresh retrieval scope display on saved "
                    "conversation activation: {}",
                    session_id,
                )
            self._sync_console_chat_core_state()
            sync_result = self._sync_native_console_chat_ui_fn()
            if inspect.isawaitable(sync_result):
                await sync_result
            self._sync_temporary_chip_fn()
            self._focus_composer_if_needed_fn(force=True)
            await self._refresh_console_conversation_browser_after_selection()
        except asyncio.CancelledError:
            await self._restore_console_session_after_failed_open(
                store, prior_active_session_id
            )
            raise
        except Exception:
            logger.opt(exception=True).warning(
                "Failed to present an already-open Console saved conversation"
            )
            await self._restore_console_session_after_failed_open(
                store, prior_active_session_id
            )
            self.app_instance.notify(
                CONSOLE_SAVED_CONVERSATION_RESUME_FAILURE_COPY,
                severity="error",
                timeout=15,
            )
            return None
        if browser_row is not None:
            self._activate_console_workspace_for_browser_row(
                browser_row,
                previous_workspace_id=prior_browser_workspace_id,
            )
        if self._complete_manual_read_visit:
            self._complete_manual_read_visit(visit)
        return True

    # -- Workspace RAG-scope picker ------------------------------------------

    async def _open_console_workspace_scope_picker(self) -> None:
        """Open the RAG retrieval-scope picker for the ACTIVE workspace.

        Task-13 workspace entry point (design spec section 4, "Workspace
        entry: Scope button beside the workspace row in the Session area").
        ``universe=None`` -- the workspace picker offers the full library,
        unlike the conversation-target picker, which restricts to the
        workspace's own items once one is set (D3, see
        ``_open_console_retrieval_scope_picker``).

        Only a REAL registry workspace can be scoped -- gated the same way
        the mounted button itself is gated
        (``ConsoleWorkspaceContextState.rag_scope_enabled``): the built-in
        Default workspace has a real ``workspace_id`` row
        (``DEFAULT_WORKSPACE_ID``) once ``ensure_default_workspace`` has
        run, so it IS scopable; only the "Local Default"/error/no-registry
        sentinel states (no real workspace row at all) are refused here.
        """
        registry_service = getattr(
            self.app_instance, "workspace_registry_service", None
        )
        if registry_service is None:
            self.app_instance.notify(
                "Workspace service is not ready.", severity="warning"
            )
            return
        try:
            active_workspace = registry_service.get_active_workspace()
        except Exception:
            logger.opt(exception=True).warning(
                "Unable to read active workspace for the scope picker"
            )
            self.app_instance.notify(
                "Workspace registry could not be read.", severity="error"
            )
            return
        if active_workspace is None:
            self.app_instance.notify(
                "Create or select a workspace before setting a RAG scope.",
                severity="warning",
            )
            return
        workspace_id = active_workspace.workspace_id

        try:
            initial = await self._read_console_workspace_scope(
                registry_service, workspace_id
            )
        except Exception:
            logger.opt(exception=True).warning(
                "Unable to read workspace scope for {}", workspace_id
            )
            initial = None

        target_label = f"workspace '{active_workspace.name}'"
        media_lister, notes_lister, tag_lister = self._console_scope_picker_listers()

        def _on_save(scope: Optional[RagScope]) -> None:
            self.run_worker(
                self._apply_console_workspace_scope_save(workspace_id, scope),
                exclusive=True,
                group="console-workspace-scope-save",
            )

        self.push_screen(
            ConsoleScopePickerModal(
                target_label,
                None,
                initial,
                _on_save,
                media_lister=media_lister,
                notes_lister=notes_lister,
                tag_lister=tag_lister,
            )
        )

    async def _apply_console_workspace_scope_save(
        self,
        workspace_id: str,
        scope: Optional[RagScope],
    ) -> None:
        """Persist (or clear) a workspace's RAG retrieval scope (task-13).

        ``WorkspaceNotFound`` is caught deliberately -- the workspace may
        have been archived/deleted (e.g. from Library > Workspaces) between
        opening the picker and saving. Refreshes the ACTIVE Console
        session's effective-scope display afterward: a workspace-scope
        change can widen or narrow retrieval for every conversation linked
        to it, but only the currently active session's row/chip are
        mounted to refresh.

        Args:
            workspace_id: The workspace whose scope was just chosen.
            scope: The new scope, or ``None`` to clear it.
        """
        registry_service = getattr(
            self.app_instance, "workspace_registry_service", None
        )
        if registry_service is None:
            self.app_instance.notify(
                "Couldn't save scope: workspace service is not ready.",
                severity="error",
            )
            return
        try:
            await self._write_console_workspace_scope(
                registry_service, workspace_id, scope
            )
        except WorkspaceNotFound:
            logger.opt(exception=True).warning(
                "Workspace scope save target missing: {}", workspace_id
            )
            self.app_instance.notify(
                "Couldn't save scope: this workspace no longer exists.",
                severity="error",
            )
            return
        except Exception:
            logger.opt(exception=True).warning(
                "Failed to write workspace scope for {}", workspace_id
            )
            self.app_instance.notify("Couldn't save workspace scope.", severity="error")
            return
        session = self._active_native_console_session()
        if session is not None:
            await self._refresh_console_effective_scope_and_sync(session)

    # -- Workspace-scoped Console session activation -------------------------

    def _activate_console_session_for_workspace(self, workspace_id: str) -> None:
        """Activate or create the Console session for the selected workspace."""
        target_workspace_id = str(workspace_id).strip()
        if not target_workspace_id:
            return
        store = self._ensure_console_chat_store()
        if store.active_session_id is not None:
            for session in store.sessions():
                if (
                    session.id == store.active_session_id
                    and session.workspace_id == target_workspace_id
                ):
                    return
        for session in store.sessions():
            if session.workspace_id == target_workspace_id:
                self._capture_console_draft_switch_snapshot()
                store.switch_session(session.id)
                _bind_composer_after_switch(self)
                # task-7 review: this switches the active session with no
                # other chip-refresh call anywhere in the caller chain (all
                # three callers only run `_sync_native_console_chat_ui()`
                # afterward, which never touches the temporary chip -- see
                # `_sync_console_temporary_chip`). Without this the chip
                # could keep reading "Temporary" on a workspace's saved
                # session, or stay hidden on one that is actually temporary.
                self._sync_console_temporary_chip()
                return
        self._capture_console_draft_switch_snapshot()
        defaults = self._blank_console_session_settings()
        session = store.create_session(
            title=self._console_workspace_session_title(target_workspace_id),
            workspace_id=target_workspace_id,
            settings=defaults,
            canonical_settings_baseline=defaults,
        )
        session.new_chat_default_generation = (
            self._console_new_chat_default_generation()
        )
        # task-7 review: `create_session` activates the new (never
        # ephemeral -- no `ephemeral=` passed) session inline; same
        # staleness risk as the switch branch above if the workspace's
        # previous session was temporary.
        self._sync_console_temporary_chip()

    def _reconcile_console_session_with_registry(self) -> None:
        """Align the Console session with the registry's active workspace.

        TASK-18310: every IN-Console workspace-activation path -- the Alt+W
        switcher (``_open_console_workspace_switcher``'s ``_switch_to``), the
        shared create modal's Console handler
        (``_handle_workspace_create_result``), and conversation-browser
        row-open (``_activate_console_workspace_for_browser_row`` plus the
        session lookup around it) -- calls ``set_active_workspace`` on the
        registry AND ``_activate_console_session_for_workspace`` on this
        controller together, so the registry and the Console chat store's
        active session can never drift apart from any of those paths.
        Cross-screen activation -- Settings' create-modal ``_done``,
        Library's ``create_local_workspace`` ``_done``, and Settings' "Set
        active" button (Qodo finding 5 on PR #1809) -- only calls
        ``set_active_workspace`` on the registry, so registry/session
        misalignment can arise EXCLUSIVELY from a cross-screen change.

        Called from ``ChatScreen.on_screen_resume`` on every Console resume
        (including the mount's own -- the store is app-level and can carry
        a session that predates the first mount). When already aligned --
        the overwhelmingly common case, since every in-Console path keeps
        them in lockstep -- this is an O(1) early exit. Only on an actual
        cross-screen divergence does it re-run the same Console-side
        activation sequence the create handler uses, minus the registry
        write (already done by the other surface) and the toast (the
        originating surface already announced the switch).

        Deliberately conservative: any read of the registry is guarded, and
        a ``None`` registry or ``None`` active workspace returns quietly --
        this must never break screen resume. A store with no active session is
        different: TASK-2033 requires its first session to inherit the
        registry-active workspace instead of falling through to Default.

        Comparison is normalized, not a bare ``==``: a session's default
        ``workspace_id`` is the "no explicit workspace" sentinel
        (``CONSOLE_GLOBAL_WORKSPACE_ID``, `""` is treated the same), while
        the registry represents that identical state as its built-in
        Default workspace row (``DEFAULT_WORKSPACE_ID`` --
        ``ensure_default_workspace`` floors every context read to it). Per
        the task-15120 owner ruling (see
        ``_set_active_workspace_for_console_session``), those two spellings
        are THE SAME state on two layers, not a divergence -- comparing
        them raw here misfired on every plain/global mounted session
        whenever the registry's active workspace was Default (its ordinary
        resting state), tearing down a perfectly aligned session and
        replacing it with a fresh one on every resume. Caught by two
        existing tests going from GREEN to RED with the naive comparison
        (`test_mounted_first_chat_ack_exception_during_resume_restores_ui`,
        `test_mounted_console_unmount_times_out_hung_refresh_and_repairs_on_resume`).
        """
        registry_service = getattr(
            self.app_instance, "workspace_registry_service", None
        )
        if registry_service is None:
            return
        try:
            active = registry_service.get_active_workspace()
        except Exception:
            logger.opt(exception=True).debug(
                "Unable to read active workspace during Console resume reconcile"
            )
            return
        if active is None:
            return
        store = self._ensure_console_chat_store()
        active_session = None
        stale_active_session_id = False
        if store.active_session_id is not None:
            # O(1) active-session lookup (Qodo, PR #1880): with an id present,
            # ensure_session() is a pure dict hit. Do not call it for a fresh
            # store: that would create a Default/global session before the
            # registry-active workspace is applied, reproducing TASK-2033 and
            # leaving an unnecessary empty tab behind.
            try:
                active_session = store.ensure_session()
            except KeyError:
                # A stale id is divergent and follows the normal repair path.
                active_session = None
                stale_active_session_id = True
        if active_session is not None and _normalized_console_workspace_id(
            active_session.workspace_id
        ) == _normalized_console_workspace_id(active.workspace_id):
            return
        if stale_active_session_id:
            # Core sync reads the active session. Repair the invalid identity
            # first so that read cannot abort the resume-time reconciliation.
            self._activate_console_session_for_workspace(active.workspace_id)
            self._sync_console_chat_core_state()
        else:
            self._sync_console_chat_core_state()
            self._activate_console_session_for_workspace(active.workspace_id)
        self._sync_console_workspace_context()
        self.run_worker(
            self._sync_native_console_chat_ui(), exclusive=True, group="console-sync"
        )

    def _console_workspace_session_title(self, workspace_id: str) -> str:
        """Return a readable title for an auto-created workspace Console tab."""
        registry_service = getattr(
            self.app_instance, "workspace_registry_service", None
        )
        workspace_name = str(workspace_id).strip()
        if registry_service is not None:
            try:
                workspace = registry_service.get_workspace(workspace_id)
                if workspace is not None:
                    workspace_name = workspace.name
            except Exception:
                logger.opt(exception=True).debug(
                    "Unable to read Console workspace title"
                )
        if not workspace_name:
            workspace_name = "Workspace"
        return f"{workspace_name} Chat"

    def _console_initial_session_title_for_workspace(
        self, workspace_id: str | None
    ) -> str:
        """Return the first Console tab title for the active workspace."""
        target_workspace_id = str(workspace_id or "").strip()
        if not target_workspace_id or target_workspace_id in {
            CONSOLE_GLOBAL_WORKSPACE_ID,
            DEFAULT_WORKSPACE_ID,
        }:
            return DEFAULT_CONSOLE_SESSION_TITLE
        return self._console_workspace_session_title(target_workspace_id)

    def _set_active_workspace_for_console_session(self, session_id: str) -> None:
        """Keep workspace context aligned when switching Console tabs."""
        store = self._ensure_console_chat_store()
        target_session = next(
            (session for session in store.sessions() if session.id == session_id),
            None,
        )
        if target_session is None:
            return
        workspace_id = str(target_session.workspace_id or "").strip()
        registry_service = getattr(
            self.app_instance, "workspace_registry_service", None
        )
        if registry_service is None:
            return
        try:
            active_workspace = registry_service.get_active_workspace()
            if not workspace_id or workspace_id == CONSOLE_GLOBAL_WORKSPACE_ID:
                # task-15120 (owner ruling): the workspace context follows the
                # conversation -- a global conversation's context IS the
                # global scope, on both layers. This used to early-return,
                # leaving the registry on the previous workspace while the
                # store's context flipped to "global": two sources of truth
                # disagreeing, and the previous workspace's capabilities
                # bleeding into a global conversation. The registry's stable
                # representation of "no explicit workspace" is the built-in
                # Default (established here and at the other ensure seams,
                # deliberately -- capability-less, safe; the read-only
                # context resolution floors to the same id, TASK-21118), so
                # a global conversation lands there, not on bare None.
                if (
                    active_workspace is not None
                    and active_workspace.workspace_id != DEFAULT_WORKSPACE_ID
                ):
                    registry_service.clear_active_workspace()
                    ensure_default = getattr(
                        registry_service, "ensure_default_workspace", None
                    )
                    if callable(ensure_default):
                        ensure_default()
                return
            if (
                active_workspace is not None
                and active_workspace.workspace_id == workspace_id
            ):
                return
            registry_service.set_active_workspace(workspace_id)
        except Exception:
            logger.opt(exception=True).warning(
                "Unable to align Console workspace with selected tab",
            )

    # -- Workspace-scope persistence primitives ------------------------------

    @staticmethod
    async def _read_console_workspace_scope(
        registry_service: Any, workspace_id: str
    ) -> Optional[RagScope]:
        """Read a workspace's stored scope, off-loop for a file-backed registry.

        Mirrors ``_read_console_retrieval_scope``'s in-memory-DB guard
        (task-13): ``LocalWorkspaceRegistryService.db`` is never actually
        ``:memory:``-backed in production (``WorkspaceDB`` (task-3011) holds
        one connection per THREAD rather than sharing a single connection
        for ``:memory:``, so each new thread touching it would open its own
        empty, table-less ``:memory:`` database -- broken beyond a single
        thread), but the guard is applied anyway for the same defensive
        discipline the conversation-scope read uses.
        """
        db = getattr(registry_service, "db", None)
        if getattr(db, "is_memory_db", False):
            return registry_service.get_workspace_scope(workspace_id)
        return await run_owned_db_call(
            db, registry_service.get_workspace_scope, workspace_id
        )

    @staticmethod
    async def _write_console_workspace_scope(
        registry_service: Any, workspace_id: str, scope: Optional[RagScope]
    ) -> None:
        """Write (or clear) a workspace's stored scope; see the read twin's
        in-memory-registry-DB guard docstring for why this isn't
        unconditionally ``asyncio.to_thread``."""
        db = getattr(registry_service, "db", None)
        if getattr(db, "is_memory_db", False):
            registry_service.set_workspace_scope(workspace_id, scope)
        else:
            await run_owned_db_call(
                db, registry_service.set_workspace_scope, workspace_id, scope
            )

    # -- Resuming a persisted conversation ------------------------------------

    async def activate_character_conversation(
        self,
        target: LocalCharacterConversationTarget
        | CharacterConversationActivationRequest,
        cancellation: asyncio.Event | None = None,
        *,
        complete_presentation: Callable[[ConsoleConversationActivationResult], bool]
        | None = None,
    ) -> ConsoleConversationActivationResult:
        """Open one exact typed target through the canonical Console coordinator.

        Args:
            target: Captured local target and optional query revision.
            cancellation: Precommit cancellation event.
            complete_presentation: Optional synchronous request-owned switcher
                completion; ordinary callers retain strict exposed visibility.

        Returns:
            The canonical exact-open or rolled-back failure result.
        """

        return await self._character_conversation_activation.activate(
            target, cancellation, complete_presentation=complete_presentation
        )

    async def wait_until_character_conversation_commit_started(
        self,
        request: LocalCharacterConversationTarget
        | CharacterConversationActivationRequest,
        *,
        complete_presentation: Callable[[ConsoleConversationActivationResult], bool]
        | None = None,
    ) -> None:
        """Wait for the canonical coordinator's non-cancellable boundary."""

        await self._character_conversation_activation.wait_until_commit_started(
            request, complete_presentation=complete_presentation
        )

    async def _revalidate_character_conversation_target(
        self,
        request: LocalCharacterConversationTarget
        | CharacterConversationActivationRequest,
    ) -> ConsoleActivationResultKind | None:
        """Atomically recheck revision, authority, row, and card before commit."""

        return await asyncio.to_thread(
            self._revalidate_character_conversation_target_sync, request
        )

    def _revalidate_character_conversation_target_sync(
        self,
        request: LocalCharacterConversationTarget
        | CharacterConversationActivationRequest,
    ) -> ConsoleActivationResultKind | None:
        """Synchronous database half of exact activation revalidation."""
        from ...Chat.console_conversation_activation import (
            CharacterConversationActivationRequest,
            ConsoleActivationResultKind,
        )
        from ...DB.ChaChaNotes_DB import CharactersRAGDB

        db = getattr(self.app_instance, "chachanotes_db", None)
        if db is None:
            return ConsoleActivationResultKind.FAILED
        target = (
            request.target
            if isinstance(request, CharacterConversationActivationRequest)
            else request
        )
        try:
            with (
                operation_owned_connection(db)
                if type(db) is CharactersRAGDB and not db.is_memory_db
                else nullcontext(),
                db.transaction() as connection,
            ):
                authority_row = connection.execute(
                    "SELECT local_authority_id FROM rag_identity_context "
                    "WHERE context_name = 'default' LIMIT 2"
                ).fetchone()
                authority = str(authority_row[0]) if authority_row is not None else ""
                if authority != target.character.data_authority_id:
                    return ConsoleActivationResultKind.DATA_PROFILE_CHANGED
                record = connection.execute(
                    "SELECT c.deleted, c.runtime_backend, c.assistant_kind, "
                    "c.assistant_authority_id, c.character_id, "
                    "card.id AS live_card_id, card.deleted AS card_deleted "
                    "FROM conversations AS c "
                    "LEFT JOIN character_cards AS card ON card.id = c.character_id "
                    "WHERE c.id = ?",
                    (target.conversation_id,),
                ).fetchone()
                if isinstance(request, CharacterConversationActivationRequest):
                    revision_row = connection.execute(
                        "SELECT data_revision FROM "
                        "character_conversation_search_revision "
                        "WHERE singleton_id = 1"
                    ).fetchone()
                    revision = int(revision_row[0]) if revision_row else 0
            if record is None or bool(record["deleted"]):
                return ConsoleActivationResultKind.NOT_FOUND
            if (
                record["runtime_backend"] != "local"
                or record["assistant_kind"] != "character"
                or str(record["assistant_authority_id"] or "") != authority
                or str(record["character_id"] or "")
                != str(target.character.character_id)
                or record["live_card_id"] is None
                or bool(record["card_deleted"])
            ):
                return ConsoleActivationResultKind.CHARACTER_UNAVAILABLE
            if (
                isinstance(request, CharacterConversationActivationRequest)
                and revision != request.data_revision
            ):
                # The search revision is global: an unrelated conversation
                # may have changed while this exact row/card remained valid.
                # FAILED truthfully requests a new immutable results snapshot;
                # CHARACTER_UNAVAILABLE is reserved for the exact checks above.
                return ConsoleActivationResultKind.FAILED
        except Exception:  # noqa: BLE001 - exact revalidation fails closed across DB adapters
            logger.opt(exception=True).warning(
                "Unable to revalidate character conversation target"
            )
            return ConsoleActivationResultKind.FAILED
        return None

    async def preflight_character_conversation_activation(
        self,
        request: CharacterConversationActivationRequest,
    ) -> ConsoleActivationResultKind | None:
        """Run the Console-owned read-only check while Roleplay stays current."""

        return await self._revalidate_character_conversation_target(request)

    def apply_character_navigation_context(self, context: Mapping[str, object]) -> None:
        """Accept typed activation and validated return focus on the destination."""
        from ...Chat.console_conversation_activation import (
            CharacterConversationActivationRequest,
        )
        from ...Constants import (
            CHARACTER_NAV_CONTEXT_RETURN_FOCUS,
            CONSOLE_NAV_CONTEXT_CHARACTER_CONVERSATION_TARGET,
        )
        from ..Navigation.character_conversation_navigation import (
            deserialize_roleplay_character_conversation_link,
        )

        screen = self._screen
        payload = context.get(CONSOLE_NAV_CONTEXT_CHARACTER_CONVERSATION_TARGET)
        if isinstance(payload, Mapping):
            try:
                link = deserialize_roleplay_character_conversation_link(payload)
                if link.conversation_id is not None:
                    screen._pending_character_conversation_target = (
                        CharacterConversationActivationRequest(
                            target=LocalCharacterConversationTarget(
                                link.character, link.conversation_id
                            ),
                            data_authority_id=link.character.data_authority_id,
                            data_revision=link.data_revision,
                        )
                    )
            except (TypeError, ValueError):
                logger.warning(
                    "Rejected invalid character-conversation navigation payload"
                )
        focus_id = context.get(CHARACTER_NAV_CONTEXT_RETURN_FOCUS)
        if isinstance(focus_id, str) and re.fullmatch(
            r"[A-Za-z][A-Za-z0-9_-]{0,127}", focus_id
        ):
            screen._pending_character_return_focus_id = focus_id

    def restore_character_navigation_focus(self) -> None:
        """Consume the return anchor only when its mounted destination owns focus."""
        screen = self._screen
        focus_id = screen._pending_character_return_focus_id
        if focus_id is None or screen.app.screen is not screen:
            return
        if focus_id == "console-context-character":
            screen._character_context.return_reveal = True
            rail_state = screen._current_console_rail_state()
            screen._sync_console_rail_visibility_if_changed(rail_state)
            if not rail_state.left_open:
                self._focus_composer_if_needed_fn(force=True)
                return
            # Rail reveal restores saved child display flags. Apply the
            # transient disclosure afterwards, without persisting a gesture.
            screen.query_one("#console-left-rail").sync_sections(rail_state)
            focus_id = "console-character-search"
        try:
            target = screen.query_one(f"#{focus_id}")
            screen.set_focus(target)
            target.scroll_visible(animate=False)
        except NoMatches:
            return
        screen._pending_character_return_focus_id = None

    async def open_character_navigation_target(
        self, target: CharacterConversationActivationRequest
    ) -> bool:
        """Open an accepted target and retain failed intent with recoverable copy."""
        from ...Chat.console_conversation_activation import ConsoleActivationResultKind

        result = await self.activate_character_conversation(target)
        if result.kind is ConsoleActivationResultKind.OPENED:
            return True
        self._screen._failed_character_conversation_target = target
        notify = self._notify_character_navigation or self.app_instance.notify
        notify(
            {
                ConsoleActivationResultKind.NOT_FOUND: "Conversation is no longer available.",
                ConsoleActivationResultKind.DATA_PROFILE_CHANGED: "The active Data Profile changed. Return to Roleplay and try again.",
                ConsoleActivationResultKind.CHARACTER_UNAVAILABLE: "The saved character is unavailable. Open Library to repair it.",
            }.get(result.kind, "The conversation could not be opened."),
            severity="warning",
        )
        return False

    async def activate_character_conversation_after_commit(
        self,
        request: CharacterConversationActivationRequest,
        *,
        finalize_visible: Callable[[], Awaitable[None]] | None = None,
    ) -> ConsoleConversationActivationResult:
        """Hydrate on the surviving screen, re-fence, and prove exact visibility."""
        from ...Chat.console_conversation_activation import (
            ConsoleActivationResultKind,
            ConsoleConversationActivationResult,
        )

        prior_session_id = self._ensure_console_chat_store().active_session_id
        owned_runtime: object | None = None
        failure_kind = ConsoleActivationResultKind.FAILED
        cancellation: asyncio.CancelledError | None = None
        try:
            opened = await self._open_character_conversation_activation(request)
            owned_runtime = opened.owned_runtime_token
            if opened.opened:
                validation = await self._revalidate_character_conversation_target(
                    request
                )
                if validation is None and self._character_conversation_target_visible(
                    request
                ):
                    if finalize_visible is not None:
                        await finalize_visible()
                    return ConsoleConversationActivationResult(
                        ConsoleActivationResultKind.OPENED,
                        request.target,
                        True,
                    )
                if validation is not None:
                    failure_kind = validation
        except asyncio.CancelledError as error:
            cancellation = error
        except Exception:  # noqa: BLE001 - committed adapters must enter exact-runtime rollback
            logger.bind(
                operation_id=id(request),
                workspace_token=id(self),
                target_type="local_character_conversation",
                stage="open_target",
            ).opt(exception=True).warning(
                "Committed character-conversation activation failed"
            )

        async def settle_failed_activation() -> None:
            """Remove this attempt's runtime and restore the exact prior one."""

            if owned_runtime is not None:
                try:
                    await self._rollback_character_conversation_activation(
                        owned_runtime
                    )
                except Exception:  # noqa: BLE001 - failed owned-runtime removal must still restore prior
                    logger.bind(
                        operation_id=id(request),
                        workspace_token=id(self),
                        target_type="local_character_conversation",
                        stage="remove_owned_runtime",
                        runtime_token=id(owned_runtime),
                    ).opt(exception=True).error(
                        "Could not remove owned Console session after committed failure"
                    )
            try:
                await self._restore_character_conversation_prior_session(
                    prior_session_id
                )
            except Exception:  # noqa: BLE001 - report prior-session recovery without replacing outcome
                logger.bind(
                    operation_id=id(request),
                    workspace_token=id(self),
                    target_type="local_character_conversation",
                    stage="restore_prior_runtime",
                ).opt(exception=True).error(
                    "Could not restore prior Console session after committed failure"
                )

        cleanup = asyncio.create_task(
            settle_failed_activation(),
            name="character_conversation_activation_rollback",
        )
        while True:
            try:
                await asyncio.shield(cleanup)
            except asyncio.CancelledError as error:
                if cleanup.cancelled():
                    raise
                cancellation = cancellation or error
                continue
            break
        if cancellation is not None:
            raise cancellation
        return ConsoleConversationActivationResult(
            failure_kind,
            request.target,
            True,
        )

    async def _open_character_conversation_activation(
        self,
        request: LocalCharacterConversationTarget
        | CharacterConversationActivationRequest,
    ) -> ConsoleActivationCommit:
        """Open a target and capture only a runtime session created by this call."""
        from ...Chat.console_conversation_activation import (
            CharacterConversationActivationRequest,
            ConsoleActivationCommit,
        )

        target = (
            request.target
            if isinstance(request, CharacterConversationActivationRequest)
            else request
        )
        store = self._ensure_console_chat_store()
        before = {session.id: session for session in store.sessions()}
        opened = bool(
            await self.open_console_workspace_conversation(target.conversation_id)
        )
        owned = next(
            (
                session
                for session in store.sessions()
                if session.id not in before
                and str(session.persisted_conversation_id or "")
                == target.conversation_id
            ),
            None,
        )
        if opened:
            # Widget.focus() is queued by Textual. This committed Character
            # boundary must establish focus before the immediate exact-visible
            # proof, including when activation began in a Context row.
            try:
                # A whole-Console sync may coalesce into an already-running
                # pass. Publish this target before the exact-ready proof.
                await self._screen._sync_native_console_transcript()
                self._screen.set_focus(
                    self._screen.query_one("#console-native-composer")
                )
            except asyncio.CancelledError:
                # The caller has not received ownership yet. Settle only this
                # exact cold runtime synchronously, then let it restore prior UI.
                if owned is not None:
                    store.rollback_restored_session(
                        owned.id,
                        expected_session=owned,
                        prior_active_session_id=None,
                    )
                raise
            except Exception:  # noqa: BLE001 - preserve the owned token for rollback
                logger.opt(exception=True).warning(
                    "Could not focus the committed character conversation"
                )
                opened = False
        return ConsoleActivationCommit(opened=opened, owned_runtime_token=owned)

    async def _rollback_character_conversation_activation(
        self, owned_runtime: object
    ) -> bool:
        """Remove only the exact hydrated runtime owned by this activation."""

        session_id = getattr(owned_runtime, "id", None)
        if not isinstance(session_id, str) or not session_id:
            return False
        store = self._ensure_console_chat_store()
        return store.rollback_restored_session(
            session_id,
            expected_session=owned_runtime,
            prior_active_session_id=None,
        )

    async def _restore_character_conversation_prior_session(
        self, prior_active_session_id: str | None
    ) -> bool:
        return await self._restore_console_session_after_failed_open(
            self._ensure_console_chat_store(), prior_active_session_id
        )

    def _character_conversation_target_visible(
        self,
        request: LocalCharacterConversationTarget
        | CharacterConversationActivationRequest,
    ) -> bool:
        """Require an exposed Console plus its exact prepared target."""
        return (
            self._screen.app.screen is self._screen
            and self._character_conversation_target_ready(request)
        )

    def _character_conversation_target_ready(
        self,
        request: LocalCharacterConversationTarget
        | CharacterConversationActivationRequest,
    ) -> bool:
        """Check exact store, mounted transcript, and composer without revealing."""
        from ...Chat.console_conversation_activation import (
            CharacterConversationActivationRequest,
        )

        target = (
            request.target
            if isinstance(request, CharacterConversationActivationRequest)
            else request
        )
        store = self._ensure_console_chat_store()
        active = next(
            (
                session
                for session in store.sessions()
                if session.id == store.active_session_id
            ),
            None,
        )
        if (
            active is None
            or str(active.persisted_conversation_id or "") != target.conversation_id
            or not self._screen.is_mounted
        ):
            return False
        try:
            composer = self._screen.query_one("#console-native-composer")
            transcript = self._screen.query_one("#console-native-transcript")
            focused = self._screen.focused
            transcript_owner = getattr(transcript, "_session_identity", None)
            transcript_settled = bool(
                getattr(self._screen, "_last_native_transcript_refresh_key", None)
                is not None
                and getattr(self._screen, "_last_native_transcript_session_id", None)
                == active.id
            )
            return (
                bool(getattr(transcript, "display", True))
                and transcript_owner == active.id
                and transcript_settled
                and (
                    focused is composer
                    or (focused is not None and composer in focused.ancestors)
                )
            )
        except NoMatches:
            return False

    def _console_session_id_for_workspace_conversation(
        self,
        conversation_id: str,
    ) -> str | None:
        """Return an open Console session id for a workspace conversation row."""
        target = str(conversation_id or "").strip()
        if not target:
            return None
        store = self._console_chat_store
        if store is None:
            return None
        if target.startswith("native:"):
            session_id = target.removeprefix("native:")
            if any(session.id == session_id for session in store.sessions()):
                return session_id
            return None
        active_session = next(
            (
                session
                for session in store.sessions()
                if session.id == store.active_session_id
            ),
            None,
        )
        if (
            active_session is not None
            and str(active_session.persisted_conversation_id or "") == target
        ):
            return active_session.id
        for session in store.sessions():
            if str(session.persisted_conversation_id or "") == target:
                return session.id
        return None

    async def _restore_console_session_after_failed_open(
        self,
        store: Any,
        prior_active_session_id: str | None,
    ) -> bool:
        """Best-effort repaint; report errors without breaking legacy callers."""
        if not any(
            session.id == prior_active_session_id for session in store.sessions()
        ):
            return False
        restored = True
        try:
            store.switch_session(prior_active_session_id)
            _bind_composer_after_switch(self)
            self._set_active_workspace_for_console_session(prior_active_session_id)
            self._sync_console_chat_core_state()
            sync_result = self._sync_native_console_chat_ui_fn()
            if inspect.isawaitable(sync_result):
                await sync_result
            self._sync_temporary_chip_fn()
        except Exception:
            restored = False
            logger.opt(exception=True).warning(
                "Failed to repaint the prior Console session after saved-chat open"
            )
        finally:
            try:
                self._focus_composer_if_needed_fn(force=True)
            except Exception:
                restored = False
                logger.opt(exception=True).warning(
                    "Failed to focus the prior Console composer after saved-chat open"
                )
        return restored

    async def _resume_console_workspace_conversation(
        self,
        conversation_id: str,
        *,
        target_scope_type: str | None = None,
        target_workspace_id: str | None = None,
        reuse_existing: bool = False,
        preserve_persisted_scope: bool = False,
        resume_if: Callable[[], bool] | None = None,
    ) -> bool | None:
        """Load a persisted saved conversation into a native Console session.

        Args:
            conversation_id: Exact persisted conversation identity.
            target_scope_type: Optional fallback scope for cold hydration.
            target_workspace_id: Optional fallback workspace for cold hydration.
            reuse_existing: Prefer an open runtime after validating the saved
                record. History opts in; explicit fresh-session callers do not.
            preserve_persisted_scope: Restore the saved workspace or global scope.
            resume_if: Optional ownership predicate carried through activation.

        Returns:
            True on success; None on a transient failure this method already
            notified about (service unavailable / load error); False when the
            conversation record is missing - the caller owns that failure's
            feedback (TASK-717).
        """
        target = str(conversation_id or "").strip()
        if not target:
            return None
        store = self._ensure_console_chat_store()
        prior_active_session_id = store.active_session_id
        visit = (
            await self._begin_manual_read_visit("", target)
            if self._begin_manual_read_visit
            else None
        )
        # TASK-339: keystrokes typed while the conversation tree loads
        # belong to the resumed session — snapshot the composer now.
        self._capture_console_draft_switch_snapshot()
        # task-15860 Task 6: the tree load and the session build moved to
        # `Chat/console_conversation_hydration.py` -- the launch wake has to
        # hydrate a conversation with no screen in existence, and one policy
        # beats two. Everything BELOW the hydration call is this screen's own
        # work (marker overlay, scope warm, repaint, focus) and stays here;
        # so do both failure toasts, because the UX
        # for each failure is a view concern.
        try:
            tree = await load_console_conversation_tree(self.app_instance, target)
        except ConversationServiceUnavailable:
            await self._restore_console_session_after_failed_open(
                store, prior_active_session_id
            )
            self.app_instance.notify(
                "Saved conversation resume is unavailable in this build.",
                severity="warning",
            )
            return None
        except ConversationLoadFailed:
            logger.exception(
                f"Unable to resume Console saved conversation: conversation_id={target}"
            )
            await self._restore_console_session_after_failed_open(
                store, prior_active_session_id
            )
            self.app_instance.notify(
                CONSOLE_SAVED_CONVERSATION_RESUME_FAILURE_COPY,
                severity="error",
                timeout=15,
            )
            return None

        if resume_if is not None and not resume_if():
            return None

        if tree is None:
            # TASK-717: missing record - the caller owns this failure's UX
            # (honest toast + marking the row visibly broken), so do not
            # stack a second notification here.
            await self._restore_console_session_after_failed_open(
                store, prior_active_session_id
            )
            return False

        if reuse_existing or preserve_persisted_scope:
            matches = [
                session
                for session in store.sessions()
                if str(session.persisted_conversation_id or "") == target
            ]
            if matches:
                session = next(
                    (item for item in matches if item.id == store.active_session_id),
                    matches[0],
                )
                return await self.open_console_workspace_conversation(
                    f"native:{session.id}", resume_if=resume_if
                )

        conversation = tree.get("conversation")
        if not isinstance(conversation, dict):
            conversation = {}
        if preserve_persisted_scope:
            target_workspace_id = conversation.get("workspace_id") or None
            target_scope_type = "workspace" if target_workspace_id else "global"
        session = None
        hydration = self._console_session_settings_for_resume(conversation)
        if not isinstance(hydration, ConsoleGenerationSettingsHydration):
            raise TypeError(
                "Console resume settings must be ConsoleGenerationSettingsHydration"
            )
        try:
            session = await hydrate_console_session(
                app=self.app_instance,
                store=store,
                conversation_id=target,
                tree=tree,
                settings=hydration.settings,
                generation_durable_snapshot=hydration.durable_snapshot,
                generation_metadata_status=hydration.metadata_status,
                target_scope_type=target_scope_type,
                target_workspace_id=target_workspace_id,
                activate=False,
            )
            # Re-derive display-only agent TOOL markers from AgentRunsDB and
            # overlay them onto the restored active-path view.
            store.apply_resume_marker_overlay(
                session.id,
                self._inject_resume_agent_markers(
                    store.messages_for_session(session.id), target
                ),
            )
            # Live identity re-resolution on resume (task-32481, ADR-149):
            # refresh the display name from the live card/profile. Dev's
            # hydration already set the label from the persisted snapshot,
            # which stays as the fallback when live resolution fails.
            if (
                session.runtime_backend == "local"
                and session.assistant_kind == "character"
                and session.character_id is not None
            ):
                resolved_character_name = await self._resolve_resumed_character_name(
                    session.character_id
                )
                if resolved_character_name:
                    session.character_name = resolved_character_name
                    if session.settings is not None:
                        session.settings = replace(
                            session.settings,
                            character_label=resolved_character_name,
                        )
            elif session.assistant_kind == "persona" and session.assistant_id:
                # Persona sessions carry no local projection; the display name
                # is re-resolved from the live profile on every resume
                # (ADR-149), for local and server backends alike.
                persona_name = await self._resolve_resumed_persona_name(
                    session.assistant_id, session.runtime_backend
                )
                session.assistant_name = persona_name or None
                if persona_name:
                    # One-name invariant: a persona session never shows a
                    # stale character label.
                    session.character_name = None
                if session.settings is not None:
                    session.settings = replace(session.settings, character_label="")
            elif session.settings is not None:
                session.settings = replace(session.settings, character_label="")
            # Warm the effective conversation/workspace scope before the final
            # activation commit so any failure leaves the prior session active.
            await self._resolve_console_effective_scope_state(session)
            from .conversation_token_preparation import prepare_conversation_tokens

            await prepare_conversation_tokens(self._screen, store, session.id)
            if resume_if is not None and not resume_if():
                store.rollback_restored_session(
                    session.id,
                    expected_session=session,
                    prior_active_session_id=prior_active_session_id,
                )
                return None
            store.switch_session(session.id)
            _bind_composer_after_switch(self)
            self._set_active_workspace_for_console_session(session.id)
            self._sync_console_retrieval_scope_row()
            self._console_agent_drilldown_run_id = None
            self._note_console_follow_intent()
            self._sync_console_chat_core_state()
            await self._sync_native_console_chat_ui()
            await self._refresh_console_conversation_browser_after_selection()
            self._focus_console_composer_if_needed(force=True)
            if callable(self._wake_retry_poke_fn):
                self._wake_retry_poke_fn()
        except asyncio.CancelledError:
            if session is not None:
                store.rollback_restored_session(
                    session.id,
                    expected_session=session,
                    prior_active_session_id=prior_active_session_id,
                )
            await self._restore_console_session_after_failed_open(
                store, prior_active_session_id
            )
            raise
        except Exception:
            logger.opt(exception=True).warning(
                "Unable to present Console saved conversation"
            )
            if session is not None:
                store.rollback_restored_session(
                    session.id,
                    expected_session=session,
                    prior_active_session_id=prior_active_session_id,
                )
            await self._restore_console_session_after_failed_open(
                store, prior_active_session_id
            )
            self.app_instance.notify(
                CONSOLE_SAVED_CONVERSATION_RESUME_FAILURE_COPY,
                severity="error",
                timeout=15,
            )
            return None
        if self._complete_manual_read_visit:
            self._complete_manual_read_visit(visit, session.id)
        return True

    # -- Workspace context state / grouped conversation rows -----------------

    #: The open run tick's shared build cache, or ``None`` outside a tick
    #: (TASK-22201). A CLASS attribute default, matching the screen's memo
    #: conventions, so hand-built fixtures that skip ``__init__`` still
    #: read a defined value.
    _console_tick_builds: "ConsoleTickWorkspaceBuilds | None" = None

    @contextmanager
    def tick_workspace_build_scope(self):
        """Share ONE fingerprint-validated context build across a run tick.

        Opened by ``_sync_native_console_chat_ui`` around its sync body
        (TASK-22201): every ``_build_console_workspace_context_state`` call
        the tick's own asyncio task performs -- directly or through the
        inspector/control-bar/agent-section legs -- is served from one
        :class:`ConsoleTickWorkspaceBuilds` cache. Deliberately opt-in and
        scoped, like the screen's ``_console_derivation_scope``
        (task-15452): outside a ``with`` block, and for any OTHER task
        interleaving during the tick's awaits, every build is live exactly
        as before. Re-entrant (an inner scope keeps the outer cache) and
        always torn down, so a raising tick cannot leave a stale build
        cached for the next one.
        """
        if getattr(self, "_console_tick_builds", None) is not None:
            yield
            return
        self._console_tick_builds = ConsoleTickWorkspaceBuilds(self)
        try:
            yield
        finally:
            self._console_tick_builds = None

    def _workspace_availability_runtime(self):
        """Read only an existing owner; a display request never constructs one."""
        from ...Chat.console_runtime import CONSOLE_RUNTIME_ATTR, ConsoleRuntime

        app_values = getattr(self.app_instance, "__dict__", {})
        value = app_values.get(CONSOLE_RUNTIME_ATTR)
        if value is None:
            value = getattr(self._screen, "__dict__", {}).get("_console_runtime_fallback")
        return value if isinstance(value, ConsoleRuntime) else None


    async def _read_owned_workspace_availability(self, registry, database, workspace_ids):
        """Retain the original callback's exact finite DB scopes through cancel."""
        from ...Backup_Recovery.participants import _core_operation
        from ...Chat.console_preparation_reads import run_preparation_read
        from ...DB.base_db import operation_owned_connection

        app = self.app_instance
        runtime = self._workspace_availability_runtime()
        reader = self._read_workspace_files_availability
        database_path = database.db_path

        def current():
            if (
                self.app_instance is not app
                or getattr(app, "workspace_registry_service", None) is not registry
                or self._workspace_availability_runtime() is not runtime
                or getattr(registry, "db", None) is not database
                or database.db_path != database_path
                or not _availability_methods_current(self, _WORKSPACE_AVAILABILITY_METHODS)
                or not _availability_methods_current(registry, _WORKSPACE_AVAILABILITY_REGISTRY_METHODS)
                or (runtime is not None and runtime._disposed)
            ):
                raise _WorkspaceAvailabilityObsolete(
                    "workspace_availability_source_changed"
                )

        def read_captured_availability():
            # Same complete repository interval and newly-created-handle custody
            # as run_owned_db_call; its global/custom API remains unchanged.
            with operation_owned_connection(database), _core_operation(database):
                current()
                return reader(registry, database, workspace_ids)

        return await run_preparation_read(
            read_captured_availability,
            creator=self,
            session_id=None,
            reads=self._preparation_reads,
            observers=() if runtime is None else (runtime._preparation_reads,),
            require_current=current,
        )


    def _request_workspace_files_availability_refresh(
        self, workspace_ids: Sequence[str]
    ) -> None:
        """Coalesce one off-loop local-folder availability snapshot.

        The context rail is refreshed on the Textual loop.  Calling the
        registry's ``list_folder_bindings`` there recomputes filesystem
        status and can stall every Console interaction, so renderers only
        enqueue this best-effort cache refresh and fail closed until it lands.
        """
        runtime = self._workspace_availability_runtime()
        if runtime is not None and runtime._disposed:
            return
        requested_ids = tuple(
            sorted(
                {
                    str(item or "").strip()
                    for item in workspace_ids
                    if str(item or "").strip()
                }
            )
        )
        now = time.monotonic()
        if requested_ids == self._workspace_files_availability_requested_ids and (
            self._workspace_files_availability_refresh_in_flight
            or now - self._workspace_files_availability_cached_at
            < WORKSPACE_FILES_AVAILABILITY_CACHE_TTL_SECONDS
        ):
            return
        self._workspace_files_availability_requested_ids = requested_ids
        self._workspace_files_availability_generation += 1
        if self._workspace_files_availability_refresh_in_flight:
            return
        if not requested_ids or not self._screen_running_accessor():
            return
        self._workspace_files_availability_refresh_in_flight = True
        self.run_worker(
            self._refresh_workspace_files_availability_snapshot(),
            group="console-workspace-files-availability",
            exclusive=False,
        )

    def _capture_workspace_files_availability(
        self, workspace_ids: Sequence[str]
    ) -> tuple[dict[str, bool], dict[str, tuple[WorkspaceRuntimeBinding, ...]]]:
        """Read runtime bindings and folder readiness off-loop into a snapshot."""
        registry = getattr(self.app_instance, "workspace_registry_service", None)
        return self._capture_workspace_files_availability_for_registry(
            registry, workspace_ids
        )


    def _capture_workspace_files_availability_for_registry(
        self, registry: Any, workspace_ids: Sequence[str]
    ) -> tuple[dict[str, bool], dict[str, tuple[WorkspaceRuntimeBinding, ...]]]:
        """Retain the existing ownership route for direct and custom reads."""
        database = getattr(registry, "db", None)
        with operation_owned_connection(database):
            return self._read_workspace_files_availability(
                registry, database, workspace_ids
            )


    def _read_workspace_files_availability(
        self, registry: Any, database: object, workspace_ids: Sequence[str]
    ) -> tuple[dict[str, bool], dict[str, tuple[WorkspaceRuntimeBinding, ...]]]:
        """Read the captured registry owner within its caller's finite lifetime."""
        availability: dict[str, bool] = {}
        bindings_by_id: dict[str, tuple[WorkspaceRuntimeBinding, ...]] = {}
        for workspace_id in workspace_ids:
            if getattr(registry, "db", None) is not database:
                return {}, {}
            if registry is None:
                availability[workspace_id] = False
                bindings_by_id[workspace_id] = ()
                continue
            try:
                if (
                    type(registry) is LocalWorkspaceRegistryService
                    and _availability_methods_current(registry, _WORKSPACE_AVAILABILITY_REGISTRY_METHODS)
                ):
                    # Its folder lister reads the complete runtime set too.
                    # Reuse one read and the display layer's same disk checks
                    # within this finite operation, including Default cleanup.
                    runtime_bindings = tuple(
                        _recompute_filesystem_binding_status(binding)
                        for binding in registry.list_runtime_bindings(workspace_id)
                    )
                    folder_bindings = tuple(
                        binding
                        for binding in runtime_bindings
                        if binding.binding_kind is RuntimeBindingKind.LOCAL_FILESYSTEM
                    )
                else:
                    # Custom adapters may implement their own folder status
                    # contract. Keep their existing listers and merge behavior.
                    folder_bindings = tuple(registry.list_folder_bindings(workspace_id))
                    list_runtime_bindings = getattr(
                        registry, "list_runtime_bindings", None
                    )
                    stored_bindings = (
                        tuple(list_runtime_bindings(workspace_id))
                        if callable(list_runtime_bindings)
                        else folder_bindings
                    )
                    refreshed_by_binding_id = {
                        str(getattr(binding, "binding_id", "")): binding
                        for binding in folder_bindings
                    }
                    runtime_bindings = tuple(
                        refreshed_by_binding_id.get(
                            str(getattr(binding, "binding_id", "")), binding
                        )
                        for binding in stored_bindings
                    )
                bindings_by_id[workspace_id] = runtime_bindings
                availability[workspace_id] = any(
                    binding.binding_kind is RuntimeBindingKind.LOCAL_FILESYSTEM
                    and binding.status is RuntimeBindingStatus.READY
                    for binding in folder_bindings
                )
            except Exception:  # noqa: BLE001 - preserve original optional browser or availability failure results.
                availability[workspace_id] = False
                bindings_by_id[workspace_id] = ()
        return availability, bindings_by_id


    async def _refresh_workspace_files_availability_snapshot(self) -> None:
        """Publish only the latest completed folder-availability generation."""
        owner_task = asyncio.current_task()
        self._workspace_files_availability_task = owner_task
        try:
            while self._screen_running_accessor():
                runtime = self._workspace_availability_runtime()
                if runtime is not None and runtime._disposed:
                    return
                generation = self._workspace_files_availability_generation
                workspace_ids = self._workspace_files_availability_requested_ids
                registry = getattr(self.app_instance, "workspace_registry_service", None)
                database = getattr(registry, "db", None)
                stock_read = (
                    type(database) is WorkspaceDB and not database.is_memory_db
                    and type(registry) is LocalWorkspaceRegistryService
                    and _availability_methods_current(self, _WORKSPACE_AVAILABILITY_METHODS)
                    and _availability_methods_current(registry, _WORKSPACE_AVAILABILITY_REGISTRY_METHODS)
                )
                default_only = (
                    stock_read and workspace_ids == (DEFAULT_WORKSPACE_ID,)
                    and _default_display_bindings_are_empty(registry, DEFAULT_WORKSPACE_ID)
                )
                if default_only:
                    availability_snapshot = {DEFAULT_WORKSPACE_ID: False}
                    bindings_snapshot = {DEFAULT_WORKSPACE_ID: ()}
                elif stock_read:
                    availability_snapshot, bindings_snapshot = (
                        await self._read_owned_workspace_availability(
                            registry, database, workspace_ids
                        )
                    )
                else:
                    # Preserve the original custom/in-memory read route and its
                    # worker affinity while retaining physical completion.
                    from ...Chat.console_preparation_reads import run_preparation_read

                    availability_snapshot, bindings_snapshot = await run_preparation_read(
                        partial(self._capture_workspace_files_availability, workspace_ids),
                        creator=self, session_id=None, reads=self._preparation_reads,
                        observers=() if runtime is None else (runtime._preparation_reads,),
                        require_current=lambda: None,
                    )
                runtime = self._workspace_availability_runtime()
                if not self._screen_running_accessor() or (
                    runtime is not None and runtime._disposed
                ):
                    return
                if default_only and not _default_display_bindings_are_empty(
                    registry, DEFAULT_WORKSPACE_ID
                ):
                    continue
                if (
                    generation == self._workspace_files_availability_generation
                    and registry is getattr(self.app_instance, "workspace_registry_service", None)
                    and database is getattr(registry, "db", None)
                ):
                    self._workspace_files_availability_by_id = MappingProxyType(
                        {
                            workspace_id: bool(
                                availability_snapshot.get(workspace_id, False)
                            )
                            for workspace_id in workspace_ids
                        }
                    )
                    self._workspace_files_runtime_bindings_by_id = MappingProxyType(
                        {
                            workspace_id: tuple(bindings_snapshot.get(workspace_id, ()))
                            for workspace_id in workspace_ids
                        }
                    )
                    self._workspace_files_availability_cached_at = time.monotonic()
                    self._workspace_files_availability_refresh_in_flight = False
                    self._sync_console_workspace_context()
                    return
        except _WorkspaceAvailabilityObsolete:
            return
        except asyncio.CancelledError:
            raise
        finally:
            # A screen-owned worker is cancelled during teardown.  Do not
            # retain an in-flight claim that would make a resumed screen think
            # a non-existent worker still owns its snapshot.
            if self._workspace_files_availability_task is owner_task:
                self._workspace_files_availability_refresh_in_flight = False
                self._workspace_files_availability_task = None

    def _build_console_workspace_context_state(self) -> ConsoleWorkspaceContextState:
        builds = getattr(self, "_console_tick_builds", None)
        if builds is not None and builds.accepts_current_task():
            return builds.state()
        current_conversation = self._current_console_conversation_id()
        # The generation-keyed display-read view stands in for the raw
        # service (TASK-22201): the builder's read set (active workspace,
        # workspaces, runtime bindings, memberships) is served without SQL
        # while the registry is unchanged. ADR-028's from-disk binding
        # status recompute still runs per build inside the builder.
        state = build_console_workspace_state(
            registry_service=self._console_registry_reads_view(),
            current_conversation=current_conversation,
            conversations=(),
            server_adapter_state=getattr(
                self.app_instance,
                "workspace_server_adapter_state",
                None,
            ),
            acp_handoff_state=getattr(
                self.app_instance,
                "workspace_acp_handoff_state",
                None,
            ),
            runtime_bindings_by_workspace=self._workspace_files_runtime_bindings_by_id,
        )
        state = self._with_native_console_session_rows(state)
        state = self._with_console_conversation_browser_state(
            state,
            current_conversation_id=current_conversation,
        )
        workspace_ids = tuple(
            dict.fromkeys(
                workspace_id
                for workspace_id in (
                    str(state.workspace_id or "").strip(),
                    *(
                        str(workspace.workspace_id or "").strip()
                        for workspace in self._console_browser_workspace_records()
                    ),
                )
                if workspace_id
            )
        )
        self._request_workspace_files_availability_refresh(workspace_ids)
        availability = MappingProxyType(
            {
                workspace_id: bool(
                    self._workspace_files_availability_by_id.get(workspace_id, False)
                )
                for workspace_id in workspace_ids
            }
        )
        return replace(
            state,
            workspace_files_available=bool(
                self._workspace_files_availability_by_id.get(state.workspace_id, False)
            ),
            workspace_files_available_by_id=availability,
        )

    def _console_workspace_build_fingerprint(self) -> tuple | None:
        """Cheap change token over the context build's volatile inputs.

        Serves the run tick's build cache (TASK-22201): identical
        fingerprints between two reads WITHIN ONE TICK mean the cached
        build may be reused. Covered inputs -- registry identity +
        ``mutation_generation``, current conversation, store sessions
        (identity, title, timestamps, persistence, workspace) + active
        session, run status + per-session queued counts, canonical
        membership revision, persisted-rows cache token, both search
        lanes' generations/queries/errors, and the page-attempt shape --
        are exactly the ones the PR #660 / task-280 freshness rulings care
        about across the tick's awaits (session create/activate/persist).
        Deliberately NOT exhaustive: long-tail inputs (stars, unseen
        markers, collapse preferences) change only through paths that
        rebuild and push OUTSIDE the tick cache's lifetime, so a miss is
        bounded by one 0.2 s tick. Returns ``None`` (never reuse) when the
        registry lacks a real ``int`` generation or any component read
        fails.
        """
        try:
            registry_service = getattr(
                self.app_instance, "workspace_registry_service", None
            )
            generation = getattr(registry_service, "mutation_generation", None)
            if registry_service is not None and (
                isinstance(generation, bool) or not isinstance(generation, int)
            ):
                return None
            store = self._console_chat_store
            controller = self._console_chat_controller
            sessions_token: tuple = ()
            active_session_id = None
            queued_token: tuple = ()
            if store is not None:
                active_session_id = store.active_session_id
                sessions = tuple(store.sessions())
                sessions_token = tuple(
                    (
                        session.id,
                        str(session.title or ""),
                        str(session.updated_at or ""),
                        str(session.persisted_conversation_id or ""),
                        str(session.workspace_id or ""),
                    )
                    for session in sessions
                )
                if controller is not None:
                    queued_token = tuple(
                        controller.activity_for(session.id).queued_count
                        for session in sessions
                    )
            run_status = controller.run_state.status if controller is not None else None
            flat_lane = self._flat_conversation_search
            workspace_lane = self._workspace_tree_search
            attempts_token = tuple(
                (
                    workspace_id,
                    attempt.generation,
                    len(attempt.rows),
                    attempt.loading,
                    attempt.error,
                    attempt.next_cursor,
                    attempt.retry_cursor,
                    attempt.membership_unknown,
                )
                for workspace_id, attempt in self._workspace_page_attempts.items()
            )
            return (
                id(registry_service),
                generation,
                self._current_console_conversation_id(),
                active_session_id,
                sessions_token,
                queued_token,
                run_status,
                self._canonical_membership_revision,
                self._console_persisted_rows_cache_token,
                self._console_conversation_browser_query,
                (
                    flat_lane.generation,
                    flat_lane.query,
                    flat_lane.error,
                    flat_lane.settled_query,
                    flat_lane.request_key,
                ),
                (
                    workspace_lane.generation,
                    workspace_lane.query,
                    workspace_lane.error,
                    workspace_lane.settled_query,
                    workspace_lane.request_key,
                ),
                attempts_token,
                getattr(self.app_instance, "workspace_server_adapter_state", None),
                getattr(self.app_instance, "workspace_acp_handoff_state", None),
            )
        except Exception:
            logger.debug(
                "Console workspace build fingerprint unavailable; building live"
            )
            return None

    @staticmethod
    def _console_workspace_row_key(row: ConsoleWorkspaceConversationRow) -> str:
        return str(row.conversation_id or "").strip()

    def _activate_console_workspace_for_browser_row(
        self,
        row: ConsoleConversationBrowserRow,
        *,
        previous_workspace_id: str | None = None,
    ) -> None:
        """Align workspace context and announce a committed browser-row open."""
        scope_type = str(row.scope_type or "").strip()
        if scope_type == "global":
            return
        workspace_id = str(row.workspace_id or "").strip()
        if not workspace_id or workspace_id == CONSOLE_GLOBAL_WORKSPACE_ID:
            return
        registry_service = getattr(
            self.app_instance, "workspace_registry_service", None
        )
        if registry_service is None:
            return
        try:
            active_workspace = registry_service.get_active_workspace()
            workspace_changed = (
                active_workspace is None
                or active_workspace.workspace_id != workspace_id
            )
            if workspace_changed:
                registry_service.set_active_workspace(workspace_id)
            if (
                previous_workspace_id != workspace_id
                if previous_workspace_id is not None
                else workspace_changed
            ):
                # TASK-713: opening a row from another workspace's group
                # retargets the whole Console context; the Workspace status
                # row is usually scrolled out of view at that moment, so the
                # side effect needs an explicit announcement.
                switched = registry_service.get_active_workspace()
                switched_name = switched.name if switched is not None else workspace_id
                self.app_instance.notify(
                    f"Switched Console to {switched_name}.",
                    severity="information",
                )
            self._ensure_console_chat_store().set_workspace_context(
                self._current_console_workspace_context()
            )
        except Exception:
            logger.opt(exception=True).warning(
                "Unable to activate Console workspace for browser row",
            )

    #: Generation-keyed display-read view over the app's registry service,
    #: or ``None`` before the first read (TASK-22201). A CLASS attribute
    #: default, matching the screen's memo conventions, so hand-built
    #: fixtures that skip ``__init__`` still read a defined value.
    _console_registry_display_reads: "_ConsoleRegistryDisplayReads | None" = None

    def _console_registry_reads_view(self) -> "_ConsoleRegistryDisplayReads | None":
        """Return the display-read view bound to the CURRENT service instance.

        Rebound (dropping its cache) whenever the app swaps its registry
        service, mirroring the identity check in the TASK-21118 memo.
        """
        service = getattr(self.app_instance, "workspace_registry_service", None)
        if service is None:
            return None
        view = getattr(self, "_console_registry_display_reads", None)
        if view is None or view.service is not service:
            view = _ConsoleRegistryDisplayReads(service)
            self._console_registry_display_reads = view
        return view

    def _console_browser_workspace_records(self) -> tuple[WorkspaceRecord, ...]:
        """Return all local workspace records visible to the Console browser.

        Served from the generation-keyed display-read view (TASK-22201):
        the run tick reaches this method many times per 0.2 s (browser
        labels, the workspace tree projection, page-row labels), and each
        call used to run ``ensure_default_workspace()`` -- a write-capable
        REPAIR (SELECT + bindings probe + occasional DELETE transaction) --
        plus ``list_workspaces()``, synchronously on the event loop. The
        repair does not belong on a display path and was never this path's
        responsibility alone: boot wiring (``app.py``
        ``_wire_workspace_registry_services``), ``archive_workspace``,
        ``set_active_workspace``'s switch-to-Default repair, and
        ``_set_active_workspace_for_console_session``'s global branch all
        keep the registry resting on an active workspace. Display reads a
        degraded registry as degraded and repairs nothing.
        """
        view = self._console_registry_reads_view()
        if view is None:
            return ()
        list_workspaces = getattr(view, "list_workspaces", None)
        if not callable(list_workspaces):
            return ()
        try:
            return tuple(list_workspaces())
        except Exception:
            logger.opt(exception=True).debug(
                "Unable to list Console browser workspaces"
            )
            return ()

    def _console_browser_character_labels_for(
        self,
        character_ids: Iterable[str],
    ) -> dict[str, str]:
        """Return character card names keyed by stringified local character id.

        TASK-32309: browser rows that carry a character id label themselves
        with their card's name. Review findings 5 and 7: resolve ONLY the ids
        present on candidate rows (never a bounded full-library listing,
        which silently loses cards past its limit) and skip the database
        entirely when nothing needs a label -- the common no-character-rows
        build must not touch the cards table.
        """
        needed = sorted(
            {
                text_id
                for text_id in (str(value or "").strip() for value in character_ids)
                if text_id
            }
        )
        if not needed:
            return {}
        db = getattr(self.app_instance, "chachanotes_db", None)
        get_card = getattr(db, "get_character_card_by_id", None)
        if not callable(get_card):
            return {}
        labels: dict[str, str] = {}
        for text_id in needed:
            try:
                card_id = int(text_id)
            except ValueError:
                continue
            try:
                # Non-deleted cards only; a deleted or missing card returns
                # None and the row keeps its empty (unknown) label.
                card = get_card(card_id)
            except Exception:
                logger.opt(exception=True).debug(
                    "Unable to read character card {} for Console browser", card_id
                )
                continue
            name = str((card or {}).get("name") or "").strip()
            if name:
                labels[text_id] = name
        return labels

    def _console_browser_workspace_labels(self) -> dict[str, str]:
        """Return workspace labels keyed by workspace id for browser rows."""
        labels: dict[str, str] = {}
        for record in self._console_browser_workspace_records():
            workspace_id = str(record.workspace_id or "").strip()
            if not workspace_id:
                continue
            labels[workspace_id] = (
                "Chats"
                if workspace_id == DEFAULT_WORKSPACE_ID
                else str(record.name or workspace_id)
            )
        labels.setdefault(DEFAULT_WORKSPACE_ID, "Chats")
        return labels

    def _console_browser_workspace_label(
        self,
        workspace_id: str | None,
        labels: dict[str, str] | None = None,
    ) -> str:
        """Return display label for a workspace/global browser row."""
        if not workspace_id or workspace_id == CONSOLE_GLOBAL_WORKSPACE_ID:
            return "Chats"
        if workspace_id == DEFAULT_WORKSPACE_ID:
            return "Chats"
        workspace_labels = (
            labels if labels is not None else self._console_browser_workspace_labels()
        )
        return workspace_labels.get(workspace_id, workspace_id)

    def _selected_console_workspace_conversation_summary(
        self,
        rows: list[ConsoleWorkspaceConversationRow],
    ) -> str:
        selected = next((row for row in rows if row.selected), None)
        if selected is None:
            return "No active conversation."
        title = ConsoleWorkspaceContextTray._conversation_title(selected.title)
        detail = ConsoleWorkspaceContextTray._conversation_detail_status(
            selected.status
        )
        return f"{title} - {detail or 'conversation'}"

    def _merge_console_workspace_rows(
        self,
        primary: list[ConsoleWorkspaceConversationRow],
        secondary: list[ConsoleWorkspaceConversationRow],
    ) -> list[ConsoleWorkspaceConversationRow]:
        merged: list[ConsoleWorkspaceConversationRow] = []
        seen: set[str] = set()
        for row in primary + secondary:
            key = self._console_workspace_row_key(row)
            if not key or key in seen:
                continue
            seen.add(key)
            merged.append(row)
        return merged

    def _native_console_rows_for_workspace_search(
        self,
        workspace_id: str,
        query: str,
    ) -> list[ConsoleWorkspaceConversationRow]:
        """Return matching open native sessions for the active workspace search."""
        store = self._console_chat_store
        if store is None:
            return []
        needle = str(query or "").strip().lower()
        rows: list[ConsoleWorkspaceConversationRow] = []
        active_session_id = store.active_session_id
        for session in store.sessions():
            selected = session.id == active_session_id
            session_workspace_id = str(session.workspace_id or "").strip()
            if (
                workspace_id
                and workspace_id != CONSOLE_GLOBAL_WORKSPACE_ID
                and session_workspace_id != workspace_id
                and not selected
            ):
                continue
            title = str(session.title or "Untitled conversation")
            if needle and needle not in title.lower():
                continue
            conversation_id = (
                str(session.persisted_conversation_id)
                if session.persisted_conversation_id
                else f"native:{session.id}"
            )
            rows.append(
                ConsoleWorkspaceConversationRow(
                    conversation_id=conversation_id,
                    title=title,
                    status="active" if selected else "open",
                    selected=selected,
                )
            )
        return rows

    def _membership_console_rows_for_workspace_search(
        self,
        workspace_id: str,
        query: str,
    ) -> list[ConsoleWorkspaceConversationRow]:
        """Return matching workspace conversation membership rows."""
        service = getattr(self.app_instance, "workspace_registry_service", None)
        list_conversations = getattr(service, "list_workspace_conversations", None)
        if not callable(list_conversations) or not workspace_id:
            return []
        needle = str(query or "").strip().lower()
        try:
            memberships = list_conversations(workspace_id)
        except Exception:
            logger.opt(exception=True).debug(
                "Unable to search workspace conversation memberships"
            )
            return []
        rows: list[ConsoleWorkspaceConversationRow] = []
        current_conversation = self._current_console_conversation_id()
        for membership in memberships:
            title = str(
                getattr(membership, "title", "") or getattr(membership, "item_id", "")
            )
            if needle and needle not in title.lower():
                continue
            conversation_id = str(getattr(membership, "item_id", "") or "")
            rows.append(
                ConsoleWorkspaceConversationRow(
                    conversation_id=conversation_id,
                    title=title,
                    status=str(getattr(membership, "role", "") or "workspace-thread"),
                    selected=bool(
                        current_conversation and conversation_id == current_conversation
                    ),
                )
            )
        return rows

    async def _persisted_console_rows_for_workspace_search(
        self,
        workspace_id: str,
        query: str,
    ) -> tuple[list[ConsoleWorkspaceConversationRow], int | None, str]:
        """Return persisted workspace conversation search rows, total, and error copy."""
        scope_service = getattr(
            self.app_instance,
            "chat_conversation_scope_service",
            None,
        )
        list_conversations = getattr(scope_service, "list_conversations", None)
        if not callable(list_conversations) or not workspace_id:
            return [], None, ""
        if (
            hasattr(scope_service, "local_service")
            and getattr(scope_service, "local_service", None) is None
        ):
            return [], None, ""
        try:
            result = list_conversations(
                mode="local",
                query=query,
                scope_type="workspace",
                workspace_id=workspace_id,
                limit=CONSOLE_WORKSPACE_CONVERSATION_RESULT_LIMIT,
                offset=0,
            )
            result = await result if inspect.isawaitable(result) else result
        except Exception as exc:
            if (
                isinstance(exc, ValueError)
                and "service is unavailable" in str(exc).lower()
            ):
                logger.debug(
                    "Local persisted conversation search service is unavailable"
                )
                return [], None, ""
            logger.exception("Unable to search Console workspace conversations")
            return [], None, "Workspace conversation search is unavailable."
        if not isinstance(result, dict):
            return [], 0, ""
        items = result.get("items")
        if not isinstance(items, list):
            items = []
        total = result.get("total")
        if total is None:
            pagination = result.get("pagination")
            if isinstance(pagination, dict):
                total = pagination.get("total")
        try:
            total_count = int(total)
        except (TypeError, ValueError):
            total_count = len(items)
        current_conversation = self._current_console_conversation_id()
        rows: list[ConsoleWorkspaceConversationRow] = []
        for item in items:
            if not isinstance(item, dict):
                continue
            conversation_id = str(item.get("id") or "").strip()
            if not conversation_id:
                continue
            rows.append(
                ConsoleWorkspaceConversationRow(
                    conversation_id=conversation_id,
                    title=str(item.get("title") or "Untitled conversation"),
                    status=self._saved_handoff_status(item),
                    selected=bool(
                        current_conversation and current_conversation == conversation_id
                    ),
                )
            )
        return rows, total_count, ""

    def _with_console_workspace_conversation_section(
        self,
        state: ConsoleWorkspaceContextState,
    ) -> ConsoleWorkspaceContextState:
        """Attach renderable Conversations subsection state to workspace context."""
        workspace_id = ""
        try:
            workspace_id = str(
                self._current_console_workspace_context().active_workspace_id or ""
            ).strip()
        except Exception:
            workspace_id = ""
        store = self._console_chat_store
        if not workspace_id:
            if store is not None and store.workspace_context.active_workspace_id:
                workspace_id = str(store.workspace_context.active_workspace_id)
            elif state.workspace_label.startswith("Workspace: "):
                workspace_id = state.workspace_label.removeprefix("Workspace: ").strip()

        if self._console_workspace_conversation_workspace_id != workspace_id:
            # The flat Conversations lane is Default/unassigned scope and is
            # independent of whichever named workspace becomes active.
            self._console_workspace_conversation_workspace_id = workspace_id

        rows = list(state.conversation_rows)
        if self._console_workspace_conversation_query.strip():
            rows = list(self._console_workspace_conversation_search_rows)
        selected_summary = self._selected_console_workspace_conversation_summary(rows)
        query = self._console_workspace_conversation_query
        result_total = (
            self._console_workspace_conversation_search_total if query.strip() else None
        )
        if (
            query.strip()
            and result_total is None
            and not self._console_workspace_conversation_search_error
        ):
            result_total = len(rows)
        status_copy = console_workspace_conversation_result_copy(
            query=query,
            result_total_count=result_total,
            result_limit=CONSOLE_WORKSPACE_CONVERSATION_RESULT_LIMIT,
        )
        section = ConsoleWorkspaceConversationSectionState(
            workspace_id=workspace_id,
            collapsed=self._console_workspace_conversations_collapsed(workspace_id),
            query=query,
            selected_summary=selected_summary,
            rows=tuple(rows),
            workspace_total_count=len(rows),
            result_total_count=result_total,
            status_copy=status_copy,
            empty_copy=(
                "No matches in this workspace."
                if query.strip()
                else state.conversation_empty_copy
            ),
            search_enabled=True,
            new_conversation_enabled=state.new_conversation_enabled,
            error_copy=self._console_workspace_conversation_search_error,
        )
        return replace(state, conversation_section=section)

    def _console_workspace_conversations_collapsed(
        self,
        workspace_id: str | None,
    ) -> bool:
        """Return stored collapse preference for one workspace."""
        key = str(workspace_id or "global").strip() or "global"
        app_config = getattr(self.app_instance, "app_config", None)
        if not isinstance(app_config, dict):
            return False
        console_config = app_config.get("console")
        if not isinstance(console_config, dict):
            return False
        section_config = console_config.get("conversation_section")
        if not isinstance(section_config, dict):
            return False
        value = section_config.get(key)
        return bool(value.get("collapsed")) if isinstance(value, dict) else False

    def _set_console_workspace_conversations_collapsed(
        self,
        workspace_id: str | None,
        collapsed: bool,
    ) -> None:
        """Store collapse preference for one workspace in memory."""
        key = str(workspace_id or "global").strip() or "global"
        section_config = self._console_conversation_section_config()
        section_config[key] = {"collapsed": bool(collapsed)}

    # -- Conversation-browser press handling (wave-4 task 2) ----------------
    #
    # Three of `ChatScreen.on_button_pressed`'s 19 branches mutated nothing
    # but this cluster's state, so their bodies moved here whole and the
    # screen's branches became calls. Each takes the values the pressed
    # button carried rather than the `Button.Pressed` event: Textual's
    # event object stays on the screen (it is the screen that must
    # `event.stop()`), and a controller that never sees a widget cannot
    # start reading one.

    def _toggle_console_conversation_browser_section(self, group_id: str) -> None:
        """Flip one grouped-browser SECTION's collapse preference.

        Args:
            group_id: The pressed toggle's `group_id`, always
                ``"section:<section_id>"`` (see
                `ConsoleWorkspaceContextTray._compose_conversation_browser_
                section_header`). A section whose id no longer appears in
                current state collapses, matching the pre-move behaviour of
                treating a missing section as expanded.
        """
        state = self._build_console_workspace_context_state()
        section_id = group_id.removeprefix("section:")
        section = None
        browser = state.conversation_browser
        if browser is not None:
            section = next(
                (
                    candidate
                    for candidate in browser.sections
                    if candidate.section_id == section_id
                ),
                None,
            )
        collapsed = not bool(section.collapsed if section is not None else False)
        self._set_console_conversation_browser_group_collapsed(group_id, collapsed)
        self._sync_console_workspace_context()

    def _toggle_console_conversation_browser_group(self, group_id: str) -> None:
        """Flip one grouped-browser GROUP's collapse preference.

        Deliberately not folded together with
        `_toggle_console_conversation_browser_section` above: the two
        search different levels of the same tree (sections by
        `section_id`, groups by `group_id` across every section's
        `groups`), and the pre-move branches were two separate bodies. A
        shared helper here would hide exactly the difference a reader
        comes to this pair to find.

        Args:
            group_id: The pressed toggle's `group_id` -- a workspace group
                key, never the ``"section:"``-prefixed form.
        """
        state = self._build_console_workspace_context_state()
        group = None
        browser = state.conversation_browser
        if browser is not None:
            for section in browser.sections:
                group = next(
                    (
                        candidate
                        for candidate in section.groups
                        if candidate.group_id == group_id
                    ),
                    None,
                )
                if group is not None:
                    break
        collapsed = not bool(group.collapsed if group is not None else False)
        self._set_console_conversation_browser_group_collapsed(group_id, collapsed)
        self._sync_console_workspace_context()

    def _open_console_conversation_appearance_picker(
        self,
        conversation_id: str,
        *,
        conversation_title: str = "",
        icon: str = "",
        color: str = "",
    ) -> None:
        """Open the per-conversation icon + color picker (task-31207)."""
        normalized_id = str(conversation_id or "").strip()
        if not normalized_id:
            # Same guard copy as the star: an unpersisted native session has
            # no conversations row to carry metadata yet.
            self.app_instance.notify(
                "Save this conversation before customizing it.",
                severity="warning",
            )
            return
        # The emoji catalog build blocks the event loop for ~180 ms on first
        # process use (task-32804.12); build it off-thread, then push the modal
        # with the result already prepared so the click never freezes the UI.
        # exclusive=True: a second appearance click supersedes an in-flight one.
        self.run_worker(
            self._present_console_conversation_appearance_picker(
                normalized_id,
                str(conversation_title or ""),
                icon or None,
                color or None,
            ),
            group="console-appearance-picker",
            exclusive=True,
        )

    async def _present_console_conversation_appearance_picker(
        self,
        conversation_id: str,
        conversation_title: str,
        icon: str | None,
        color: str | None,
    ) -> None:
        """Build the emoji index off the loop, then present the picker."""
        # Deferred import (PR #2480 CI): the picker's module (and the emoji
        # catalog machinery it pulls in) must not join the boot path -- the
        # ui-ready module census and the boot CSS byte budget both ratchet
        # on eagerly parsed modules, and neither should grow for a modal
        # opened a handful of times per session.
        from ...Widgets.Console.console_appearance_picker_modal import (
            ConsoleAppearancePickerModal,
            _default_emoji_sequence,
        )

        emojis = await asyncio.to_thread(_default_emoji_sequence)
        self.push_screen(
            ConsoleAppearancePickerModal(
                conversation_id=conversation_id,
                conversation_title=conversation_title,
                icon=icon,
                color=color,
                emojis=emojis,
            ),
            callback=partial(
                self._on_console_conversation_appearance_result,
                conversation_id,
                conversation_title,
            ),
        )

    def _on_console_conversation_appearance_result(
        self,
        conversation_id: str,
        conversation_title: str,
        appearance: "ConsoleConversationAppearance | None",
    ) -> None:
        """Apply the picker's result; ``None`` means it was cancelled."""
        if appearance is None:
            return
        service = getattr(self.app_instance, "local_chat_conversation_service", None)
        set_appearance = getattr(service, "set_conversation_appearance", None)
        if not callable(set_appearance):
            self.app_instance.notify(
                "Conversation appearance is unavailable.",
                severity="warning",
            )
            return
        self.run_worker(
            self._write_console_conversation_appearance_off_loop(
                set_appearance, conversation_id, appearance, conversation_title
            ),
            group="console-conversation-appearance",
            exit_on_error=False,
        )

    async def _write_console_conversation_appearance_off_loop(
        self,
        set_appearance: Callable[..., bool],
        conversation_id: str,
        appearance: "ConsoleConversationAppearance",
        conversation_title: str,
    ) -> None:
        """Durably write one appearance change off the loop, then repaint.

        task-15471 discipline (same as the star toggle): the DB write runs
        off the event loop, guarded for per-connection memory DBs. Metadata
        writes also invalidate the persisted-rows TTL cache so the next tray
        sync re-reads rows instead of painting the stale appearance.
        """
        try:

            def _write_appearance() -> bool:
                return bool(
                    set_appearance(
                        conversation_id=conversation_id,
                        appearance=appearance,
                    )
                )

            db = getattr(
                getattr(self.app_instance, "local_chat_conversation_service", None),
                "db",
                None,
            )
            if bool(getattr(db, "is_memory_db", False)):
                wrote = _write_appearance()
            else:
                wrote = await asyncio.to_thread(_write_appearance)
        except asyncio.CancelledError:
            try:
                self._sync_console_workspace_context()
            except Exception:
                logger.debug("Appearance-write cancellation re-sync failed")
            raise
        except Exception:
            logger.error("Unable to write Console conversation appearance")
            self.app_instance.notify(
                "Could not update the conversation's appearance.",
                severity="error",
            )
            return
        if not wrote:
            self.app_instance.notify(
                "Could not update the conversation's appearance; try again.",
                severity="warning",
            )
            return
        # Untitled-conversation guard + markup escape: same toast rules the
        # star toggle established (task-3024, TASK-357).
        title = next(iter(str(conversation_title or "").splitlines()), "").strip()
        title_suffix = f' "{escape_markup(title)}"' if title else ""
        if appearance.icon is None and appearance.color is None:
            self.app_instance.notify(f"Cleared the icon for{title_suffix}.")
        else:
            self.app_instance.notify(f"Updated the icon for{title_suffix}.")
        self._invalidate_console_persisted_rows_cache()
        # PR #2480 review (#7): the appearance write must also clear the
        # appearance-map TTL cache, or the next merge repaints the stale
        # appearance for up to the TTL window.
        self._console_appearance_map_cache = None
        self._console_appearance_map_cached_at = 0.0
        self._sync_console_workspace_context()

    def _toggle_console_conversation_star(
        self,
        conversation_id: str,
        *,
        starred: bool,
        conversation_title: str,
    ) -> None:
        """Star or unstar one conversation and confirm the change.

        Moved verbatim out of `ChatScreen.on_button_pressed`'s
        `console-conversation-star-` branch (wave-4 task 2), the
        second-largest of its 19. The durable write goes through the app's
        `conversation_local_marks_service`; everything else here is the
        failure and confirmation copy that write needs to not be silent.

        Args:
            conversation_id: The pressed star's `conversation_id`. Blank
                for a native session that has never been persisted -- the
                tray disables those stars, so this guard only catches a
                stale row, and it explains rather than no-ops.
            starred: The pressed star's own `starred` attribute, used ONLY
                as a fallback when the marks service cannot answer
                `is_starred` -- current truth comes from the service, not
                from whatever the button was painted with.
            conversation_title: The pressed star's `conversation_title`,
                for the confirmation toast.
        """
        if not conversation_id:
            self.app_instance.notify(
                "Save this conversation before starring it.",
                severity="warning",
            )
            return
        marks_service = getattr(
            self.app_instance,
            "conversation_local_marks_service",
            None,
        )
        if marks_service is None:
            self.app_instance.notify(
                "Local stars are unavailable.",
                severity="warning",
            )
            return
        # task-15471: the resolve+toggle pair used to run right here, on the
        # event loop -- a read transaction plus a durable write transaction
        # per click, with the click frozen for the DB's whole busy_timeout
        # if any other writer held the file. It now runs on a worker; the
        # wrapper owns the failure/confirmation copy that followed it inline.
        self.run_worker(
            self._toggle_console_conversation_star_off_loop(
                marks_service,
                conversation_id,
                starred=starred,
                conversation_title=conversation_title,
            ),
            group="console-conversation-star",
            exit_on_error=False,
        )

    # ---- Row commands from the conversation action menu (TASK-23200) ----

    def set_console_conversation_state(
        self,
        conversation_id: str,
        state: str,
        *,
        conversation_title: str = "",
    ) -> None:
        """Persist a new conversation state and confirm it to the user.

        "Archive" is not a separate flag: it is the ``resolved`` state, the
        same mapping tldw_server's Sync v2 alias table uses. The write goes
        through ``update_conversation``, which normalizes the value against
        ``_ALLOWED_CONVERSATION_STATES`` and rejects anything else.

        Args:
            conversation_id: Persisted conversation to update.
            state: A canonical conversation state.
            conversation_title: Title for the confirmation toast.
        """
        db = getattr(self.app_instance, "chachanotes_db", None)
        if db is None:
            self.app_instance.notify(
                "Conversation storage is unavailable.", severity="error"
            )
            return

        label = conversation_title or "conversation"
        self.run_worker(
            self._set_console_conversation_state_off_loop(
                db, conversation_id, state, label
            ),
            group="console-conversation-state",
            exit_on_error=False,
        )

    async def _set_console_conversation_state_off_loop(
        self,
        db: Any,
        conversation_id: str,
        state: str,
        label: str,
    ) -> None:
        """Read the current version, write the state, and report the outcome."""

        from ...Chat.console_conversation_actions import conversation_state_label

        def _write() -> str:
            current = db.get_conversation_by_id(conversation_id)
            if not current:
                raise LookupError("conversation not found")
            db.update_conversation(
                conversation_id,
                {"state": state},
                expected_version=current["version"],
            )
            return state

        try:
            await asyncio.to_thread(_write)
        except LookupError:
            self.app_instance.notify(
                f"Could not find {label}; it may have been deleted.",
                severity="warning",
            )
            return
        except Exception as exc:  # noqa: BLE001 - surfaced to the user
            logger.error(
                "Console conversation state change failed: exception_type={}",
                type(exc).__name__,
            )
            self.app_instance.notify(
                f"Could not change the status of {label}.", severity="error"
            )
            return

        self.app_instance.notify(f"{label} set to {conversation_state_label(state)}.")
        await self._refresh_console_conversation_browser_after_selection()

    def open_console_conversation_rename(
        self, conversation_id: str, current_title: str
    ) -> None:
        """Prompt for a new title and persist it.

        Args:
            conversation_id: Persisted conversation to rename.
            current_title: Title to seed the prompt with.
        """
        from ...Widgets.Console.console_rename_session_modal import (
            ConsoleRenameSessionModal,
        )

        db = getattr(self.app_instance, "chachanotes_db", None)
        store = self._console_chat_store

        def _apply(new_title: str | None) -> None:
            if not new_title:
                return
            if (
                getattr(self.app_instance, "chachanotes_db", None) is not db
                or self._console_chat_store is not store
            ):
                self.app_instance.notify(
                    "The profile changed. Open Rename again.", severity="warning"
                )
                return
            candidate = new_title.strip()
            if not candidate or candidate == current_title.strip():
                return
            # Qodo review, PR #2233: user text reaching persistence must go
            # through the shared validator, not a bare strip(). Conversation
            # titles are rendered in the rail, the tab strip and the
            # transcript header, so length and content limits belong in one
            # place rather than being re-guessed per call site.
            if not validate_text_input(candidate, max_length=_CONVERSATION_TITLE_MAX):
                self.app_instance.notify(
                    "That title cannot be used. Keep it under "
                    f"{_CONVERSATION_TITLE_MAX} characters and free of markup.",
                    severity="warning",
                )
                return
            self._rename_console_conversation(
                conversation_id,
                sanitize_string(candidate, max_length=_CONVERSATION_TITLE_MAX),
            )

        self.app_instance.push_screen(
            ConsoleRenameSessionModal(title=current_title), _apply
        )

    def _rename_console_conversation(
        self, conversation_id: str, new_title: str
    ) -> None:
        """Commit a validated saved title, then publish it to live Console aliases.

        Args:
            conversation_id: Exact local persisted conversation identity.
            new_title: Nonblank user-supplied title to validate before writing.
        """

        candidate = new_title.strip()
        if not candidate or not validate_text_input(
            candidate, max_length=_CONVERSATION_TITLE_MAX
        ):
            self.app_instance.notify("That title cannot be used.", severity="warning")
            return
        new_title = sanitize_string(
            candidate, max_length=_CONVERSATION_TITLE_MAX
        ).strip()
        if not new_title:
            self.app_instance.notify("That title cannot be used.", severity="warning")
            return

        db = getattr(self.app_instance, "chachanotes_db", None)
        if db is None:
            self.app_instance.notify(
                "Conversation storage is unavailable.", severity="error"
            )
            return
        store = self._console_chat_store

        async def _run() -> None:
            lifecycle = self._screen_lifecycle_token()

            def view_is_current() -> bool:
                return (
                    getattr(self.app_instance, "chachanotes_db", None) is db
                    and self._console_chat_store is store
                    and self._screen_lifecycle_token() == lifecycle
                    and self._screen_running_accessor()
                )

            def _write() -> None:
                current = db.get_conversation_by_id(conversation_id)
                if not current or current.get("deleted"):
                    raise LookupError("conversation not found")
                applied = db.update_conversation(
                    conversation_id,
                    {"title": new_title},
                    expected_version=current["version"],
                )
                if not applied:
                    raise RuntimeError("conversation rename was not applied")

            async with self._conversation_rename_lock:
                if (
                    getattr(self.app_instance, "chachanotes_db", None) is not db
                    or self._console_chat_store is not store
                ):
                    return
                cancelled = False
                try:
                    admission = (
                        store.conversation_title_transition(conversation_id)
                        if store is not None
                        else nullcontext(None)
                    )
                    with admission as publish:
                        write_task = asyncio.create_task(asyncio.to_thread(_write))
                        # Cancellation cannot stop the SQLite thread. Keep the
                        # serialization/admission scope until it settles, then
                        # publish into its captured store even if the view or
                        # profile changed. Never paint/toast the detached view.
                        while not write_task.done():
                            try:
                                await asyncio.shield(write_task)
                            except asyncio.CancelledError:
                                cancelled = True
                        write_task.result()
                        if publish is not None:
                            publish(new_title)
                except LookupError:
                    if cancelled:
                        raise asyncio.CancelledError
                    if view_is_current():
                        self.app_instance.notify(
                            "Could not find that conversation; it may have been deleted.",
                            severity="warning",
                        )
                    return
                except Exception as exc:  # noqa: BLE001 - surfaced to the user
                    logger.error(
                        "Console conversation rename failed: exception_type={}",
                        type(exc).__name__,
                    )
                    if cancelled:
                        raise asyncio.CancelledError
                    if view_is_current():
                        self.app_instance.notify(
                            "Could not rename that conversation.", severity="error"
                        )
                    return
                if cancelled:
                    raise asyncio.CancelledError
                if not view_is_current():
                    return
                self._invalidate_console_persisted_rows_cache()
                self._publish_cached_conversation_title(conversation_id, new_title)
                if self._sync_session_titles_fn is not None:
                    await self._sync_session_titles_fn()
                if not view_is_current():
                    return
                if self._workspace_tree_search.query.strip():
                    await self.refresh_workspace_tree_search(
                        self._workspace_tree_search.query
                    )
                if not view_is_current():
                    return
                await self._refresh_console_conversation_browser_after_selection()
                if (
                    self._await_title_views_fn is not None
                    and not await self._await_title_views_fn()
                ):
                    return
                if not view_is_current():
                    return
                self.app_instance.notify(f"Renamed to {new_title}.")

        self.run_worker(
            _run(), group="console-conversation-rename", exit_on_error=False
        )

    def _publish_cached_conversation_title(
        self, conversation_id: str, title: str
    ) -> None:
        """Update exact local title copies without changing ownership or row IDs.

        Args:
            conversation_id: Committed local persisted identity.
            title: Validated durable title.
        """

        def renamed(rows):
            return tuple(
                replace(row, title=title)
                if row.conversation_id == conversation_id
                else row
                for row in rows
            )

        for lane in (self._workspace_tree_search, self._flat_conversation_search):
            lane.rows = renamed(lane.rows)
            lane.settled_rows = renamed(lane.settled_rows)
            lane.cache.clear()
        for attempt in self._workspace_page_attempts.values():
            attempt.rows = renamed(attempt.rows)
        for workspace_id, rows in tuple(self._workspace_membership_rows.items()):
            self._workspace_membership_rows[workspace_id] = renamed(rows)

    def confirm_console_conversation_delete(
        self, conversation_id: str, conversation_title: str
    ) -> None:
        """Ask before deleting, then soft-delete on confirmation.

        Soft delete, so the record is recoverable; the dialog says so rather
        than implying the chat is gone for good.

        Args:
            conversation_id: Persisted conversation to delete.
            conversation_title: Name shown in the confirmation.
        """
        from ...Widgets.delete_confirmation_dialog import DeleteConfirmationDialog

        def _confirmed(result: Any) -> None:
            if not result:
                return
            self._delete_console_conversation(conversation_id, conversation_title)

        self.app_instance.push_screen(
            DeleteConfirmationDialog(
                item_type="Conversation",
                item_name=conversation_title or "this conversation",
                permanent=False,
            ),
            _confirmed,
        )

    def _delete_console_conversation(
        self, conversation_id: str, conversation_title: str
    ) -> None:
        """Soft-delete one conversation off the event loop."""

        db = getattr(self.app_instance, "chachanotes_db", None)
        if db is None:
            self.app_instance.notify(
                "Conversation storage is unavailable.", severity="error"
            )
            return

        label = conversation_title or "Conversation"

        async def _run() -> None:
            def _write() -> None:
                current = db.get_conversation_by_id(conversation_id)
                if not current:
                    raise LookupError("conversation not found")
                db.soft_delete_conversation(
                    conversation_id, expected_version=current["version"]
                )

            try:
                await asyncio.to_thread(_write)
            except LookupError:
                self.app_instance.notify(
                    f"{label} was already removed.", severity="warning"
                )
                return
            except Exception as exc:  # noqa: BLE001 - surfaced to the user
                logger.error(
                    "Console conversation delete failed: exception_type={}",
                    type(exc).__name__,
                )
                self.app_instance.notify(f"Could not delete {label}.", severity="error")
                return
            self.app_instance.notify(f"Deleted {label}.")
            await self._refresh_console_conversation_browser_after_selection()

        self.run_worker(
            _run(), group="console-conversation-delete", exit_on_error=False
        )

    async def _toggle_console_conversation_star_off_loop(
        self,
        marks_service: Any,
        conversation_id: str,
        *,
        starred: bool,
        conversation_title: str,
    ) -> None:
        """Resolve current star truth, toggle it off the loop, and confirm.

        The deferred body of `_toggle_console_conversation_star`
        (task-15471). `_console_star_toggle_lock` serializes concurrent
        presses so each one resolves current truth from the service before
        toggling -- a rapid double-press still nets toggle-twice, exactly
        the pre-worker semantics, never two pool threads racing the same
        pre-state into a stale double-star.

        Args:
            marks_service: The app's `conversation_local_marks_service`,
                captured non-None by the dispatching guard.
            conversation_id: See `_toggle_console_conversation_star`.
            starred: Fallback only, as before -- used when the service
                cannot answer `is_starred`.
            conversation_title: For the confirmation toast.
        """
        progress = {"action": "resolve"}
        async with self._console_star_toggle_lock:
            try:

                def _resolve_and_toggle() -> str:
                    is_starred = getattr(marks_service, "is_starred", None)
                    currently_starred = (
                        bool(is_starred(conversation_id))
                        if callable(is_starred)
                        else bool(starred)
                    )
                    action = "unstar" if currently_starred else "star"
                    progress["action"] = action
                    if currently_starred:
                        marks_service.unstar_conversation(conversation_id)
                    else:
                        marks_service.star_conversation(conversation_id)
                    return action

                db = getattr(marks_service, "db", None)
                if bool(getattr(db, "is_memory_db", False)):
                    # A per-connection :memory: DB is only visible to the
                    # thread that migrated it -- same guard as the browser
                    # search threading (`chat_screen.py`, task-15455).
                    star_action = _resolve_and_toggle()
                else:
                    star_action = await asyncio.to_thread(_resolve_and_toggle)
            except asyncio.CancelledError:
                # Fix round (review minor 3): cancellation cannot stop the
                # pool thread, so the durable write may still land -- and
                # `CancelledError` is a `BaseException` that would sail past
                # the `except Exception` below, recreating exactly the
                # TASK-357 silent-toggle shape (write landed, no repaint).
                # Best-effort re-sync so the rail repaints from truth, then
                # let the cancellation propagate.
                try:
                    self._sync_console_workspace_context()
                except Exception:
                    logger.debug("Star-toggle cancellation re-sync failed")
                raise
            except Exception:
                logger.exception(
                    "Unable to update local conversation star "
                    "conversation_id={} action={}",
                    conversation_id,
                    progress["action"],
                )
                self.app_instance.notify(
                    "Unable to update local star.",
                    severity="warning",
                )
                return
        # TASK-357: confirm the toggle so a star/unstar is not a silent state
        # change (the review saw an accidental star go unnoticed).
        # `"".splitlines()` is `[]`, so indexing [0] raised IndexError on an
        # untitled conversation -- after the durable star write, which meant
        # the toggle landed but the user got no confirmation and the context
        # rail never re-synced (task-3024). The empty case was always
        # intended: `title_suffix` below already drops the quoted name when
        # `title` is falsy.
        title = next(iter(str(conversation_title or "").splitlines()), "").strip()
        # notify() interprets Rich markup, so escape the stored title before
        # interpolating it (a title like "[red]x[/red]" would otherwise inject
        # styling into the toast) — matches the escape_markup convention used
        # for the attachment toasts on the screen.
        title_suffix = f' "{escape_markup(title)}"' if title else ""
        if star_action == "star":
            self.app_instance.notify(f"Starred{title_suffix}.")
        elif star_action == "unstar":
            self.app_instance.notify(f"Unstarred{title_suffix}.")
        self._sync_console_workspace_context()

    # -- Misc toast helpers ----------------------------------------------------

    def _console_session_title_and_workspace_name(
        self, controller: "ConsoleChatController", session_id: str
    ) -> tuple[str, str]:
        """Return ``(session_title, workspace_name)`` for a fleet toast.

        Fix wave (rider 6, final review): shared by ``_park_console_
        approval`` and ``_notify_console_run_outcome``, which previously
        duplicated this exact lookup byte-for-byte. Falls back to the raw
        ``session_id``/workspace id when the session has already closed or
        the workspace can't be resolved -- a toast about a session that
        vanished microseconds ago must still say SOMETHING coherent rather
        than raise.
        """
        session_title = session_id
        workspace_id = CONSOLE_GLOBAL_WORKSPACE_ID
        for session in controller.store.sessions():
            if session.id == session_id:
                session_title = session.title
                workspace_id = session.workspace_id
                break
        return (
            sanitize_character_display_label(session_title, max_characters=500),
            sanitize_character_display_label(
                self._console_workspace_display_name(workspace_id),
                max_characters=500,
            ),
        )

    def _console_workspace_display_name(self, workspace_id: str) -> str:
        """Return ``workspace_id``'s display name via the registry, falling
        back to the raw id when the service is unavailable or the
        workspace can't be resolved (PA-T9 toast copy)."""
        registry_service = getattr(
            self.app_instance, "workspace_registry_service", None
        )
        if registry_service is not None:
            try:
                workspace = registry_service.get_workspace(workspace_id)
                if workspace is not None and workspace.name:
                    return workspace.name
            except Exception:
                logger.opt(exception=True).debug(
                    "Unable to resolve Console workspace name for approval toast"
                )
        return str(workspace_id)


_WORKSPACE_AVAILABILITY_METHODS = tuple(
    (name, function, function.__code__, function.__defaults__, function.__kwdefaults__)
    for name in (
        "_capture_workspace_files_availability",
        "_capture_workspace_files_availability_for_registry",
        "_read_workspace_files_availability",
        "_read_owned_workspace_availability",
    )
    for function in (getattr(ConsoleWorkspaceController, name),)
)
_WORKSPACE_AVAILABILITY_REGISTRY_METHODS = tuple(
    (name, function, function.__code__, function.__defaults__, function.__kwdefaults__)
    for name in ("list_folder_bindings", "list_runtime_bindings")
    for function in (getattr(LocalWorkspaceRegistryService, name),)
)


# Definition-time owner of the optional stock pair.
_CONSOLE_BROWSER_CONTROLLER_SOURCE = (
    globals(),
    __file__,
    __spec__,
    getattr(__spec__, "origin", None),
    tuple(
        (
            ConsoleWorkspaceController,
            name,
            inspect.getattr_static(ConsoleWorkspaceController, name),
        )
        for name in ("__getattribute__", "__dict__", "_persisted_console_browser_rows", "_workspace_availability_runtime")
    ),
    (("ConsoleWorkspaceController", ConsoleWorkspaceController),),
    tuple(
        (
            function,
            function.__code__,
            function.__globals__,
            function.__defaults__,
            function.__kwdefaults__,
            tuple((function.__kwdefaults__ or {}).items()),
            function.__closure__,
            tuple((cell, cell.cell_contents) for cell in function.__closure__ or ()),
            vars(function).get("__wrapped__"),
        )
        for function in (ConsoleWorkspaceController._persisted_console_browser_rows,
                         ConsoleWorkspaceController._workspace_availability_runtime)
    ),
)


def _capture_stock_browser_read(controller, service, local_service, scope_service):
    # Retain first-use import behavior: the stock source carries its own
    # definition-time factory record, checked before invoking it.
    from . import console_browser_read as source

    factory, code, defaults, kwdefaults = source._CAPTURE_SOURCE
    def current():
        return (
            source.capture_stock_browser_read is factory
            and factory.__code__ is code
            and factory.__defaults__ is defaults
            and factory.__kwdefaults__ is kwdefaults
        )
    if not current():
        return None
    return factory(
        controller, service, local_service, scope_service,
        controller_source=_CONSOLE_BROWSER_CONTROLLER_SOURCE,
        factory_is_current=current,
    )
