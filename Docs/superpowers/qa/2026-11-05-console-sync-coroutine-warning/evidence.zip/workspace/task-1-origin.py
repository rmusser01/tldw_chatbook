import json
import subprocess
import sys
import time
from pathlib import Path
from Tests.Backup_Recovery.test_home_citation_retirement import _run
root = Path(sys.argv[1])
root.mkdir(parents=True)
script = '''
import asyncio, gc, os, sys, tracemalloc, warnings
from pathlib import Path
from Tests import network_guard, real_profile_guard
from Tests.windows_private_fixture_runner import user_fixture_default_owner
network_guard.install()
real_profile_guard.install()
os.environ.update(TLDW_AGENTS_WORKFLOW_RUNS_ENABLED="true", TLDW_AGENTS_AUTOWAKE_ENABLED="true", OPENAI_API_KEY="private-native-workflow-test")
from Tests.UI.test_workflow_existing_admission import existing_journey
sys.set_coroutine_origin_tracking_depth(12)
tracemalloc.start(1)
with warnings.catch_warnings(record=True) as caught:
    warnings.simplefilter("always", RuntimeWarning)
    try:
        with user_fixture_default_owner():
            asyncio.run(existing_journey(Path(os.environ["XDG_DATA_HOME"]).parent, "mounted"))
    except BaseException as error:
        print("JOURNEY_ERROR", repr(error), flush=True)
    gc.collect()
for warning in caught:
    print("RAW_WARNING", warning.category.__name__, str(warning.message), flush=True)
    print("WARNING_RECEIVER", warning.filename, warning.lineno, flush=True)
    if warning.source is not None:
        print("COROUTINE_ORIGIN", getattr(warning.source, "cr_origin", None), flush=True)
        allocation = tracemalloc.get_object_traceback(warning.source)
        print("ALLOCATION", "\\n".join(allocation.format()) if allocation else None, flush=True)
assert not [w for w in caught if issubclass(w.category, RuntimeWarning) and "_sync_native_console_chat_ui" in str(w.message)], "unawaited native sync coroutine captured in actual mounted child"
'''
start=time.monotonic()
try:
    _run(root, 'workflow-existing', 'mounted', script=script, timeout=100)
except BaseException:
    print((root / 'restart-output.log').read_text()[-14000:])
    raise
finally:
    print('ELAPSED', time.monotonic()-start)
