# Combined final correction report

Status: DONE_WITH_CONCERNS — implementation complete; root-owned scoped rereview/adjudication remains.

Base: `1b5db03c8eee8903cf4fb0e109bade41f49c0b4f`.
Commit: `8fc02744869122f961cb92af0b069fccb7b7d6f2` (`fix(workflows): enforce capacity and per-chat admission`).

## Scope and governing evidence

Read the complete 35,474-byte final-whole-review.md (SHA256 `6f52ed9950645f358e682e56ff1cea8f15821028704be2dc4c7ac79365536d18`), including I1/I2/M1/M2, all nineteen prior triage mentions, evidence reliance and CannotVerify. The brief, global/plan constraints, relevant task38524/38525/38531/38532/38533 areas, spec section10 and A5/A9/A12, existing ADR285, applicable testing/live lessons and UI constitution/component patterns governed this correction. Parent confirmed the bounded refusal subtype and exact-target UI handling. No new architectural decision was needed.

ADR required: no new ADR.
ADR path: `backlog/decisions/285-native-phased-agent-workflows.md`.
Reason: direct correction of existing joint capacity, one-nonterminal-per-chat and passive-view contracts. Root owns canonical task/spec/ADR/plan updates and final archive.

No native source/receiving-frame/physical-return semantics were modified, so this wave did not reopen or weaken the thirteen frozen supporting contracts. No other agents, helpers, reviewers, provider/network calls, full suite, source swap, branch/worktree, push/merge, dependency, migration, GC/packing or cleanup operation was introduced.

## I1 — joint decision/reservation admission resolved

`AutomaticWorkLedger._prepare_workflow` now saves the new initial/remaining decision before checking the complete new result-reservation amount, inside the SAME existing `_admission_transaction`/FULL `BEGIN IMMEDIATE` transaction. The capacity check therefore sees retained bytes plus decision bytes plus all new reservation bytes. The decision's own size/identity/control-CAS checks remain intact. A capacity refusal rolls back the decision, control change, reservations, attempts, claims and accounting together.

The prior-command branch is unchanged: exact original command and complete decision equality return the existing accepted attempt inertly. Different decision bytes still conflict. Original native approval producers, source custody, command IDs, current control gates and dispatch/acceptance ownership remain unchanged. Planning/repair reservations retain their original amount rules.

New real SQLite tests cover initial and remaining producers, workflow and aggregate ceilings, two required task slots, exact-fit versus one-byte-over admission, full-row rollback, exact accepted duplicate lookup even after a live ceiling is lowered to zero, unchanged counters and conflicting decision bytes. Remaining cases use the existing actual recovery closure of prepared never-run tasks, not fabricated physical proof or execution authority. A second chat supplies aggregate retained bytes. Bounds are reduced for precise arithmetic tests; the existing full configured-capacity fixture also passes in the covering run.

## I2 — one nonterminal workflow per chat resolved

`WorkflowRunsStore.create` now checks saved same-chat state inside its original FULL transaction, AFTER exact same-launch payload/hash equality and BEFORE chain creation. It refuses every status except the existing terminal set (`stopped`, `completed`, `closed`, `removed`). Thus approval, awaiting-plan, running, paused, awaiting-resume and recovery states all block new launch IDs. The already-existing conversation index and SQLite write serialization suffice; no unique schema/index migration was added.

`WorkflowAlreadyExists` extends existing `AutomaticWorkRefused`, with the stable body-free reason `workflow_already_exists` and an Identity-validated existing workflow ID. The normal native preparation failure path returns original resources and propagates that refusal. Console setup catches this subtype, reads that exact workflow, checks its conversation, and uses existing generation-aware/safe-on-top dismissal to open the original detail target. The notice is fixed text; generic diagnostics allow only the stable reason. Neither objective nor required bodies enter warning metadata.

New DB checks cover every saved status, same-launch inert lookup and payload conflict, fresh launch after every terminal status, old-launch lookup even with a newer nonterminal successor, no new native runs, and two actual concurrent SQLite creators (exactly one chain/workflow, one refusal naming the winner). Existing history/accounting is preserved. No deletion, automatic Stop, allowance transfer, scheduler or imported-row rewrite occurs; existing recovery/schema/restore checks pass.

New original public-path tests exercise approval/paused/resume/recovery refusals with complete before/after DB row equality, no live/pending coordinator run, no retained capacity and zero provider entries. Mounted Console clicks Prepare plan and lands on the exact original detail workflow/chat, with one history row and zero provider calls. The saved initial plan is passive SQLite setup; no model/planning execution receipt is claimed for its creation. Actual original preparation/creation/refusal/cleanup and view paths run without replacing native source functions. Both native private App creators retire normally.

Shared DB fixture changes give genuinely independent workflows distinct conversations and keep each plan's request equal to its workflow. The aggregate fixture still reaches its configured capacity, and active-time helpers still use their actual snapshot request.

## M2 — current architecture corrected

`Docs/Architecture/agent-runtime.md` now names the delivered public coordinator and native phase-wave producer, current Console setup/status/history callers, and existing physical owners. It removes obsolete future-slice claims while retaining that passive reservations and preparation APIs alone grant no scheduling authority, generic controller submission refuses, and restored history cannot adopt an old owner.

## M1 — retained, not diagnosed

The original restart9 unawaited `ChatScreen._sync_native_console_chat_ui` warning remains a nonblocking Minor. It also recurred in this wave's mounted no-provider checks: `final-fix-green-child1.log:1130` and the corresponding final covering mounted child log. Neither origin, introduction by this range, lifetime consequence nor harmlessness has been established. No provider replay or separate investigation was run to remove it.

## Exact changed paths

- `Docs/Architecture/agent-runtime.md`
- `Tests/DB/test_workflow_active_time.py`
- `Tests/DB/test_workflow_admission_boundaries.py`
- `Tests/DB/test_workflow_attempts.py`
- `Tests/DB/test_workflow_runs.py`
- `Tests/UI/test_workflow_existing_admission.py`
- `tldw_chatbook/Agents/workflow_models.py`
- `tldw_chatbook/DB/automatic_work.py`
- `tldw_chatbook/DB/workflow_runs.py`
- `tldw_chatbook/UI/Console_Modules/workflows.py`
- `tldw_chatbook/Widgets/Console/console_workflow_setup.py`

The exact eleven paths above are the complete commit. `final-fix-commit.log` retains commit metadata/stat. Scratch evidence/report remains under `final-fix-*` for root archival; canonical task/ADR/spec/plan and QA/rulings paths were not committed by this writer.

## Commands, outcomes and source attribution

Every listed receipt retains the exact argv, exit, measured subprocess duration, all current Python source hashes at launch (8,326 in the final covering run), and post-run source differences. No Python source changed during any listed test/static invocation. The raw logs preserve warnings; successful counts do not imply pristine output.

### db-red

11 failed / 8 passed, 1.94s pytest; genuine I1/I2 RED on original product source.

- Command: `.venv/bin/python -m pytest Tests/DB/test_workflow_admission_boundaries.py -q --junitxml=.superpowers/sdd/2026-11-01-native-phased-agent-workflows-implementation/final-fix-db-red.xml`
- Exit: 1; measured duration: 3.476544458s.
- Raw: `final-fix-db-red.log`; receipt/source map: `final-fix-db-red-receipt.json`.
- JUnit: `final-fix-db-red.xml`.
### ui-red

2 failed / 10.15s pytest; fixture-only setup refusal (`unsupported_workflow_operation`) followed by disposed-capacity cleanup lookup. Not a product RED.

- Command: `.venv/bin/python -m pytest Tests/UI/test_workflow_existing_admission.py -q --junitxml=.superpowers/sdd/2026-11-01-native-phased-agent-workflows-implementation/final-fix-ui-red.xml`
- Exit: 1; measured duration: 11.464608917s.
- Raw: `final-fix-ui-red.log`; receipt/source map: `final-fix-ui-red-receipt.json`.
- JUnit: `final-fix-ui-red.xml`.
### ui-red2

2 failed / 22.56s pytest; with DB fixes present, real public refusal lacked safe reason display and mounted setup did not open target. Corrected fixture preserved.

- Command: `.venv/bin/python -m pytest Tests/UI/test_workflow_existing_admission.py -q --junitxml=.superpowers/sdd/2026-11-01-native-phased-agent-workflows-implementation/final-fix-ui-red2.xml`
- Exit: 1; measured duration: 23.838796500s.
- Raw: `final-fix-ui-red2.log`; receipt/source map: `final-fix-ui-red2-receipt.json`.
- JUnit: `final-fix-ui-red2.xml`.
### green

21 passed / 16.73s pytest; new boundaries before final import/format and independent-chat fixture adjustments.

- Command: `.venv/bin/python -m pytest Tests/DB/test_workflow_admission_boundaries.py Tests/UI/test_workflow_existing_admission.py -q --junitxml=.superpowers/sdd/2026-11-01-native-phased-agent-workflows-implementation/final-fix-green.xml`
- Exit: 0; measured duration: 18.146998042s.
- Raw: `final-fix-green.log`; receipt/source map: `final-fix-green-receipt.json`.
- JUnit: `final-fix-green.xml`.
### covering

149 passed / 63.79s pytest; final committed Python bytes, including backup/restore/rebackup, accounting, passive imports, models and both original safe-modal completion guards.

- Command: `.venv/bin/python -m pytest Tests/DB/test_workflow_admission_boundaries.py Tests/DB/test_workflow_attempts.py Tests/DB/test_workflow_runs.py Tests/DB/test_workflow_active_time.py Tests/Agents/test_workflow_models.py Tests/Agents/test_workflow_passive_import.py Tests/Backup_Recovery/test_workflow_recovery_schema.py Tests/UI/test_workflow_existing_admission.py Tests/UI/test_console_workflow_controls.py::test_setup_completion_cannot_pop_a_cover_or_reopen_a_closed_setup -q --junitxml=.superpowers/sdd/2026-11-01-native-phased-agent-workflows-implementation/final-fix-covering.xml`
- Exit: 0; measured duration: 65.099533333s.
- Raw: `final-fix-covering.log`; receipt/source map: `final-fix-covering-receipt.json`.
- JUnit: `final-fix-covering.xml`.
### lint

Exit1: one inherited SIM117 in Tests/DB/test_workflow_runs.py. No introduced diagnostics.

- Command: `.venv/bin/ruff check tldw_chatbook/DB/automatic_work.py tldw_chatbook/DB/workflow_runs.py tldw_chatbook/Agents/workflow_models.py tldw_chatbook/UI/Console_Modules/workflows.py tldw_chatbook/Widgets/Console/console_workflow_setup.py Tests/DB/test_workflow_admission_boundaries.py Tests/DB/test_workflow_runs.py Tests/DB/test_workflow_attempts.py Tests/DB/test_workflow_active_time.py Tests/UI/test_workflow_existing_admission.py --output-format json`
- Exit: 1; measured duration: 0.011223083s.
- Raw: `final-fix-lint.log`; receipt/source map: `final-fix-lint-receipt.json`.
### format

Exit1: inherited three formatting differences in untouched workflow_runs.py accounting expressions; nine other files already formatted.

- Command: `.venv/bin/ruff format --check tldw_chatbook/DB/automatic_work.py tldw_chatbook/DB/workflow_runs.py tldw_chatbook/Agents/workflow_models.py tldw_chatbook/UI/Console_Modules/workflows.py tldw_chatbook/Widgets/Console/console_workflow_setup.py Tests/DB/test_workflow_admission_boundaries.py Tests/DB/test_workflow_runs.py Tests/DB/test_workflow_attempts.py Tests/DB/test_workflow_active_time.py Tests/UI/test_workflow_existing_admission.py`
- Exit: 1; measured duration: 0.013617750s.
- Raw: `final-fix-format.log`; receipt/source map: `final-fix-format-receipt.json`.
### format-range

Exit0: modified workflow create range already formatted.

- Command: `.venv/bin/ruff format --check --range 128:1-180:1 tldw_chatbook/DB/workflow_runs.py`
- Exit: 0; measured duration: 0.020828208s.
- Raw: `final-fix-format-range.log`; receipt/source map: `final-fix-format-range-receipt.json`.

The fixture-only UI attempt and genuine UI RED are distinct retained receipts; no earlier failure is relabelled as passing. The old original-capacity diagnostic is supporting review input, not substituted evidence. Each cohort is separately source-frozen and is not summed as an all-final-suite count.

Final covering command includes exactly:
`Tests/DB/test_workflow_admission_boundaries.py`, `Tests/DB/test_workflow_attempts.py`, `Tests/DB/test_workflow_runs.py`, `Tests/DB/test_workflow_active_time.py`, `Tests/Agents/test_workflow_models.py`, `Tests/Agents/test_workflow_passive_import.py`, `Tests/Backup_Recovery/test_workflow_recovery_schema.py`, `Tests/UI/test_workflow_existing_admission.py`, and the two parameterizations of `Tests/UI/test_console_workflow_controls.py::test_setup_completion_cannot_pop_a_cover_or_reopen_a_closed_setup`.

Raw public/mounted child logs are copied as `final-fix-{ui-red,ui-red2,green}-child{0,1}.log`. Final covering child logs and hashes are indexed by `final-fix-covering-children.json`: child0/1 original/restored archive journey, child2 public refusal, child3 mounted exact-target refusal. All four contain the fixture's actual `retired and reopened` completion marker; public/mounted provider entry counts are zero. Optional python-frontmatter/pydub/PyAudio and pytest garbage-directory cleanup warnings remain in raw logs. The test wrapper did not replace actual child receipts or fabricate independent per-child PID/PGID evidence.

Static debt was checked against original BASE bytes via Ruff stdin (no installed-source swap): `final-fix-static-baseline.json`, `final-fix-lint-base.log`, `final-fix-format-base.log`. The same SIM117 diagnostic corresponds to the same original line shifted by the fixture addition. `final-fix-format-base-diff.log` and `final-fix-format-current-diff.log` contain the exact same twelve added/deleted formatting lines; only line positions differ. The modified create range passes. `git diff --check -- <the eleven owned paths>` returned0. No unrelated formatter cleanup was performed.

## Self-review and preservation

Reviewed connected original callers before changing the shared functions: `_prepare_workflow`'s public planning/phase wrappers and native initial/remaining approval producer; the native `commit_request` creation callback; store decision/CAS/remaining/recovery/capacity consumers; passive model import surface; setup submission and diagnostic/safe-modal callbacks. Reviewed the complete final diff and both new test bodies after verification. Generic controller submission's actual rejection was checked in `console_automatic_submission.py` before documenting it.

No physical acceptance, receiver/source validation, native return/retirement, command equality, permission, control, accounting, startup or restore guard was relaxed. The tests compare complete rows on refusal and accepted duplicate replay. One nonterminal predicate uses serialized existing SQLite storage; it does not make multi-process physical scheduling claims.

`final-fix-pre-edit.json`, `final-fix-precommit-audit.json`, and `final-fix-final-audit.json` establish:

- All original protected279 file hashes match before and after.
- Original staged61 binary diff SHA256 is exactly `c5fcb00eab4ea09c49d1797567cbd4cc9f0eb9bb8d99cc2355f764638aaa7248` before/after.
- Each owned path had no foreign staged bytes before editing/staging; after commit, all11 worktree bytes equal their exact committed blob and index.
- Final committed Python bytes match the covering run's 8,326-source launch map with no midrun source differences.
- Only the two new tests were explicitly staged, then `git -c gc.auto=0 commit --only -- <the eleven exact paths>` created the correction commit. No broad add/reset/clean/stash, branch operation, push/merge/config mutation or maintenance ran.

## Limits and remaining work

M1 remains unexplained and explicitly disclosed. Existing whole-file lint/format debt and raw warning output are retained. No full test suite, live/provider replay, cross-platform/remote-host qualification, all-final clean live run, broad timing/fault certification or clean-clone reproducibility is claimed. Historical adverse cohorts and all CannotVerify qualifications from the full review remain unchanged. Per-chat historical/imported duplicates are not deleted or rewritten; new creation refuses when any saved nonterminal exists and directs the user to one deterministic existing target.

Root owns the one scoped rereview/adjudication and canonical archival/census/delivery closure. This report is implementation evidence, not that independent gate.
