# Task 23 empty-parent preflight

Status: source preflight complete; correctness repair and its tests remain proposed. No production/test/index/HEAD changes, product imports, test runs, children, external calls, or sibling SDD reads were performed. This is the sole written artifact.

## Confirmed failure and contract

Task 21's frozen `task-21-safe-evidence/red-sqlite-profile.json` records HEAD `ed846b20a56c48e2a4de4cdf95133bc5d7234287`, source-stable closed execution, exit 1, and selector `Tests/UI/test_console_resume_active_path.py::test_resumed_untrusted_handoff_keeps_provider_sequence`. Its frozen profile test durably inserts bad → answer → human → machine → emptyUSER → omitted-image → image, selects image, and expects six retained ancestors. The supplied failure reports only omitted-image and image. This report does not rerun that test. Its assistant fixture's missing `assistant_generation_state="complete"` is a separate Task 21 correction.

`console_conversation_hydration.py:177–313` explicitly takes structural parenthood from nesting and makes discarded empty rows transparent. The kept predicate is content truthiness, valid bytes/bytearray image presence (including empty bytes), non-null generation state, or non-null continuation JSON. Metadata alone does not retain an empty node. At line 307 children receive the nearest kept ancestor.

`console_chat_store.py:4200–4298` fetches raw rows and attaches continuation/thinking state. Lines 4264–4268 overwrite every retained structural parent with its raw durable parent. `_ingest_full_tree:21711` then resolves only retained persisted IDs. Thus omitted-image points at absent emptyUSER, becomes a root, and its selected branch loses four preceding retained messages. This is a shared restore bug, independent of untrusted handoff disclosure.

ADR-100 decision 4 explicitly defines imported root status after empty-row removal/reparenting, rather than by the raw DB parent column. ADR-063 keeps continuation on its assistant branch/generation. Both support the existing structural contract.

## Narrow caller and lifetime census

The continuation hydrator and full-tree ingester each have exactly one production caller: `restore_persisted_session:3147–3163`, in that order. Its production entry points are:

- `hydrate_console_session:684`, used by screen workspace resume and launch wake. Direct hydration flattens first, then store reads raw rows; prepared hydration flattens and reads continuation rows in `prepare_console_session_data:492–505`, then publishes later.
- `console_chat_controller:17278`, newly created durable blank chat, with `all_nodes=[]`.
- `chat_screen:24397`, agent-created/fork completion, supplied nodes from the controller worker's flattener at 17736 (or empty on its existing degraded path).

No caller updates an already-registered tree through the continuation hydrator. Nevertheless, skipping all parent refresh would regress current durable reparenting between the structural snapshot and raw-row read. It would also ignore parents on blank owners appended by continuation/thinking hydration. Sidecar owners must all be appended before the retained-ID set used for normalization is final.

Recovery reconciliation precedes these calls. `_hydrate_dispatch_recovery:3222` reconciles repository ownership and may refresh the selected cursor; `_normalize_restored_provider_continuation:4317` and sync-intent reconciliation follow tree ingestion. Keep their ordering, IDs, state, versions, and sidecar behavior intact. The repository's recovery code reads ancestry; it does not establish a replacement structural tree.

`CharactersRAGDB.get_messages_for_conversation:14492–14552` SELECTs all undeleted rows of the undeleted conversation, including content, image, parent, state, continuation and thinking fields. There is no empty-content filter. Both raw-read paths use the existing 100,000-row limit. The fixture's skipped empty ancestor is therefore available in raw rows. This proves coverage for that fixture, not completeness past existing bounds or missing/deleted ancestors.

## Proposed minimum repair

Use one private pure helper in the existing `console_conversation_hydration.py`, tentatively `_refresh_console_message_parents(nodes, rows) -> None`. It changes only `parent_message_id` on supplied/sidecar-appended retained messages. Build one raw-row lookup and the final retained-ID lookup. For each represented raw row, refresh its current raw parent, walking only absent ancestors proven to meet the existing flattener's truly-empty predicate until a retained ancestor or null root is reached.

Required cases:

| Current raw ancestry | Result |
| --- | --- |
| Parent is a retained ID | Use that current durable parent, even if the supplied structural link differs. |
| Parent is null | Use null, preserving real durable root reparenting. |
| Parent is absent but is a fetched, truly-empty row | Continue to its current raw parent; repeat across multiple transparent rows. |
| Empty chain reaches a different retained ancestor after a durable reparent | Use that ancestor, not the stale supplied structural parent. |
| Parent is a continuation/thinking-only owner appended later in the hydration pass | Use its retained ID after all owners are appended. |
| Raw child row missing, ancestor missing/deleted, absent ancestor is nonempty/state-bearing/continuation-bearing, or chain cycles/self-links | Preserve that node's supplied structural parent; do not invent ancestry or broaden retention. |

Normalize IDs as the existing code does. A visited set must terminate malformed chains. Memoize only successfully resolved transparent ancestors in the local parent map so branch fan-out does not repeatedly traverse the same long skipped chain; no service/cache abstraction. Keep pre-order, native and persisted IDs, child/sibling order, full-tree ingest, legacy-flat repair, active/before-first cursor rules, and all durable rows unchanged.

Call the helper via a method-local import at the end of `_hydrate_provider_continuations_from_persistence`, after all sidecar owners append, replacing the unconditional five-line parent assignment. No new module/dependency or new authority rule. Do not use the earlier retained/None-only guard: it silently misses a real durable reparent through a skipped empty ancestor. Do not remove all refresh.

Existing `_nearest_persisted_ancestor_id:19767` cannot be reused: it requires the registered native tree, which does not exist yet. Legacy-flat normalization also runs after ingest and concerns root chaining, not missing interior ancestors. The flattener already resolves structural empty ancestry but cannot see current raw-row reparenting without a current tree. The proposed helper fills that exact gap.

Import closure is source-verified: workspace resume imports the hydration module at line 52, launch wake at line 20, and fork worker imports it before flattening. The Task 21 frozen RED closure lists this module at hash `a1a86a42fe12af5a3078d1b60d03be712629703c9d5351afb27a1a4f1c9b7fcf`, equal to the present source. The lazy helper import introduces no module absent from that qualified resume closure. This does not claim a fresh runtime import measurement.

## Proposed canonical checks and selectors

Add tests to existing `Tests/Chat/test_console_conversation_hydration.py`; use its real DB/persistence/service patterns, not only a tree fake:

1. `test_restore_preserves_empty_parent_transparency`: real SQLite root → retained assistant → two empty users → child, with an off-branch sibling and selected child. Assert full active ancestry, all retained nodes/sibling navigation, ID/order stability, unchanged raw DB parent rows/cursor, and before-first imported-root semantics. Parametrize direct/prepared rows if useful within the same test.
2. `test_restore_refreshes_current_durable_parents`: small table supplies older flattened nodes, then current raw rows (real DB authored update for the positive case) representing retained-parent change, null-parent change, and reparent through empty ancestors to a different retained branch. Include missing/cyclic/ineligible-gap fallbacks. Assert final native links and unchanged content/sidecars/IDs. Include a sidecar-only owner appended after its child in raw order so a one-pass guard fails.

RED: those two exact new selectors against baseline source, before the helper exists. Expect the transparency/current-empty-ancestor cases to fail on native-parent/path assertions. Existing retained/null cases are preservation checks, not claimed REDs.

GREEN: those same two selectors, then the existing Task 21 exact SQLite UI selector after its fixture correction, plus:

- `Tests/Chat/test_console_conversation_hydration.py::test_the_screen_tree_walk_still_flattens_every_branch`
- `Tests/Chat/test_console_chat_store_tree.py::test_restore_persisted_session_registers_tree_and_supports_append`
- `Tests/Chat/test_console_provider_continuation.py::test_restore_hydrates_blank_owner_without_exposing_private_fields`
- `Tests/Chat/test_console_thinking_persistence.py::test_restore_hydrates_supported_thinking`
- `Tests/Chat/test_console_dispatch_cursor_recovery.py::test_restore_repairs_old_cursor_and_publishes_same_pending_turn`

Static/cap: targeted Ruff for the changed two sources/test module; the two store-parameter selectors in `Tests/Architecture/test_module_size_ratchet.py` (growth and slack). Run through the root's isolated evidence harness and existing closed import scope. No full suite, marker/timeout broadening, or cap changes.

## Preservation, cap, ADR, and handoff

Store currently measures 22,334 lines; its pinned ceiling is 22,344, slack tolerance 50. Removing the five-line unconditional assignment and adding a short lazy import/call funds the helper without increasing that ceiling. Exact formatted count and AST impact are proposed verification, not measured implementation. Require executable AST outside `_hydrate_provider_continuations_from_persistence` to match baseline. New code belongs only in the existing hydration owner plus its canonical tests; no unrelated store compression or framework.

Source read fingerprints: store `bf6eb20181f4cdf893ae4615041170929fab2b0091a42cdc25278959cd7c8771`; hydration `a1a86a42fe12af5a3078d1b60d03be712629703c9d5351afb27a1a4f1c9b7fcf`; dispatch repository `fc43b02efa8f4afc931fb3165583a60c8dbec4fb510fab76fa2aedef5043dc77`; DB `6db4931c842af37a3d6de2315c8bb9f085ebf4308827bac78f3e494584b1ae45`.

ADR required: no. ADR path: existing `backlog/decisions/100-console-active-path-before-first-cursor.md`, with `063-hosted-provider-wire-and-durable-tool-continuation.md` for generation ownership. Reason: routine repair of an existing imported-tree contract; no schema, storage, authority, cursor, service, or runtime boundary change. Read Console lesson: `lessons-console-wiring.md`, especially the warning that an apparently redundant operation can carry a caller's promised invariant.

Further whole-store/controller, nested test-closure, or ADR sweeps risk observing Task 21's moving files, expanding evidence ownership, and introducing unrelated findings without proving this link bug. Stop at this census. Root must create/track bounded Task 23 and assign source ownership after Task 21 relinquishes its clean scope. The known baseline correctness failure must be resolved before merge; this preflight is not a GREEN receipt.
