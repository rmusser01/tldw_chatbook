### Task 22: Document provider-worker custody and reuse fingerprint limit

ADR required: no
ADR path: N/A for docstring and constant reuse under existing runtime/fork contracts.
Reason: no executable behavior or authority change.

Read own-SDD task-22-mechanical-preflight.json and findings4180396187/6190. One fresh sole writer after Task21 approval; no children. Exactly console_chat_start.py and console_chat_fork.py; no test edit.

- [ ] Google Args/Returns docstring for run_provider_worker(session_id,operation): without accepted exact active item directly await; afterward create/store/shield exact provider coroutine task; result is operation result, cancellation of awaiter does not detach task, errors propagate. Do not claim acceptance checks or immediate drain that method does not perform. Preserve executable method AST.
- [ ] Replace only repeated64*1024 in fingerprint_console_fork_video with existing CONSOLE_FORK_FINGERPRINT_JSON_MAX_BYTES. Constant remains64*1024, existing validation/hash/caller behavior unchanged; expression reversal reproduces executable AST and current constant identity. No new alias/config/framework/literal-mirroring test.
- [ ] Run only existing test_console_chat_fork.py::test_video_projection_wrapper_resolves_class_fingerprint_at_invocation, sharedcanonical runner and unchanged300s bounds. AST/value/caller proof plus scoped fatal Ruff/added-hunk formatting/source whitespace and source/QA carry; freeze compact report/manifest, commit two files, return clean closed-process handoff. Independent scoped review before one additive publication, reply/resolve five findings, one new-head Qodo and normal exact-head gates/merge.


