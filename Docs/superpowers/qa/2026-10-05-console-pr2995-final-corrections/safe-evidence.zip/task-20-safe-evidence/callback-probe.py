import json,sqlite3,os
from pathlib import Path
from contextlib import closing
import Tests.conftest
from Tests.Backup_Recovery.test_chachanotes_native76_compatibility import _shipped76,_owner
from tldw_chatbook.Backup_Recovery import sqlite_validation as v
from threading import Event
p=Path(os.environ['HOME'])/'probe.sqlite';_shipped76(p)
assert v.validate_candidate(_owner(),p,Event(),migrate=False)==()
script=(Path.cwd()/'tldw_chatbook/DB/migrations/chachanotes_v76_to_v77_agent_chat_starts.sql').read_text()
statements=[];pending=''
for line in script.splitlines(keepends=True):
 pending+=line
 if sqlite3.complete_statement(pending):statements.append(pending);pending=''
for trusted in [False,True]:
 callbacks=[];completed=[];error=None
 with closing(sqlite3.connect(p,cached_statements=0)) as c:
  c.execute('PRAGMA trusted_schema=OFF');r=v._Restrictions(c);r.migrating=True;r.migration_owner='db.chachanotes.primary'
  schema=tuple(row[3] for row in v._catalog(c) if row[3] is not None)
  def log(*args):
   callbacks.append((*args,r.authorize(*args)));return sqlite3.SQLITE_OK
  # Measurement only: fixed installed statements on a disposable exact database;
  # the callback retains every decision of the original production authorizer.
  c.set_authorizer(log)
  from contextlib import nullcontext
  try:
   with v._canvas_schema_access(c,schema,r) if trusted else nullcontext():
    c.execute('BEGIN IMMEDIATE')
    for i,sql in enumerate(statements): c.execute(sql);completed.append(i)
  except sqlite3.Error as exc:error=str(exc)
  finally:c.rollback()
 record=dict(sqlite=sqlite3.sqlite_version,canvas_scope=trusted,completed=completed,error=error,callbacks=list(dict.fromkeys(callbacks)))
 print(json.dumps(record))
 assert (error is None)==trusted
