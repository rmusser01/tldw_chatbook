import ast,difflib,json,subprocess,hashlib
from pathlib import Path
E=Path(__file__).resolve().parent;P='/Users/macbook-dev/Documents/GitHub/tldw_chatbook/.venv/bin/python'
paths=['tldw_chatbook/Backup_Recovery/sqlite_validation.py','Tests/Backup_Recovery/test_chachanotes_native76_compatibility.py','Tests/Backup_Recovery/test_restore_plan.py'];records=[]
for path in paths:
 p=Path(path);src=p.read_text();before=ast.dump(ast.parse(src));old=(E/('base-'+p.name)).read_text().splitlines(True)
 (E/('preformat-'+p.name)).write_text(src)
 for iteration in range(4):
  lines=src.splitlines(True);changed=[(c,d) for tag,a,b,c,d in difflib.SequenceMatcher(a=old,b=lines,autojunk=False).get_opcodes() if tag!='equal']
  argv=[P,'-m','ruff','format','--no-cache','--stdin-filename',path,'-'];r=subprocess.run(argv,input=src,text=True,capture_output=True);assert r.returncode==0
  name='format-'+p.stem+'-'+str(iteration);(E/(name+'.stdout')).write_text(r.stdout);(E/(name+'.stderr')).write_text(r.stderr)
  formatted=r.stdout.splitlines(True);ops=[(a,b,c,d) for tag,a,b,c,d in difflib.SequenceMatcher(a=lines,b=formatted,autojunk=False).get_opcodes() if tag!='equal' and any(a<=y and b>=x for x,y in changed)]
  records.append(dict(path=path,argv=argv,exit=r.returncode,operations=ops,iteration=iteration))
  if not ops:break
  for a,b,c,d in reversed(ops):lines[a:b]=formatted[c:d]
  src=''.join(lines)
 assert ast.dump(ast.parse(src))==before
 p.write_text(src);(E/('final-'+p.name)).write_text(src)
(E/'format-receipts.json').write_text(json.dumps(records,indent=2));print(json.dumps(records))
