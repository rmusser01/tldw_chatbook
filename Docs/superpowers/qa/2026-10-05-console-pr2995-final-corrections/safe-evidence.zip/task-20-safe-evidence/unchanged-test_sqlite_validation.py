"""Real staged SQLite validation under installed recovery policies."""

import importlib
import sqlite3
from contextlib import closing, contextmanager
from dataclasses import replace
from threading import Event

import pytest

from Tests.Backup_Recovery.test_core_owners import core_store, seed_domain  # noqa: F401
from Tests.Backup_Recovery.test_domain_owners import adapter as domain_adapter
from Tests.Backup_Recovery.test_domain_owners import (  # noqa: F401
    domain_store,
    study_store,
)
from Tests.Backup_Recovery.test_operational_owners import STORES, operational_adapter
from Tests.Backup_Recovery.test_participant_lifetimes import (
    local_root as local_root,  # noqa: PLC0414
)
from tldw_chatbook.Backup_Recovery import sqlite_validation as validation
from tldw_chatbook.Backup_Recovery.sqlite_validation import validate_candidate
from tldw_chatbook.DB.private_sqlite import open_recovery_validation
from tldw_chatbook.DB.recovery_core import core_adapters
from tldw_chatbook.Research_Interop.recovery import recovery_adapters


def research_candidate(tmp_path):
    owner = recovery_adapters()[0]
    path = tmp_path / "research.db"
    with closing(sqlite3.connect(path)) as db:
        for sql in owner.schema_policy().schema_sql[0][1]:
            if not sql.startswith("CREATE TABLE sqlite_sequence"):
                db.execute(sql)
        db.execute(
            "INSERT INTO research_runs(id,query,created_at,updated_at) VALUES ('kept','nebula','now','now')"
        )
        db.commit()
    return owner, path


def test_unknown_trigger_is_rejected_before_migration(tmp_path):
    candidate = tmp_path / "hostile.db"
    with sqlite3.connect(candidate) as db:
        db.executescript(
            "CREATE TABLE payload(x); CREATE TRIGGER surprise AFTER INSERT ON payload "
            "BEGIN DELETE FROM payload; END;"
        )
    assert "unsupported_schema" in validate_candidate(
        core_adapters()[0], candidate, Event(), migrate=True
    )


def test_real_installed_core_and_fts_survive(core_store):  # noqa: F811
    name, path, store, _ = core_store
    seed_domain(name, store)
    store.close()
    owner = next(
        a
        for a in core_adapters()
        if a.owner_id
        == "db."
        + name
        + (".primary" if name in {"chachanotes", "media", "prompts"} else "")
    )
    assert validate_candidate(owner, path, Event(), migrate=False) == ()
    fts = {
        "chachanotes": "messages_fts",
        "media": "media_fts",
        "prompts": "prompts_fts",
    }.get(name)
    if fts:
        with open_recovery_validation(owner.owner_id, path, writable=False) as db:
            assert db.execute(
                f"SELECT count(*) FROM {fts} WHERE {fts} MATCH 'nebula'"
            ).fetchone() == (1,)


@pytest.mark.parametrize("core_store", ["chachanotes"], indirect=True)
def test_installed_reference_does_not_materialize_catalog_per_statement(
    core_store,  # noqa: F811
    monkeypatch,
):
    _, path, store, _ = core_store
    store.close()
    owner = validation._installed_owner("db.chachanotes.primary")
    catalog = validation._catalog
    calls = []

    def observed(connection):
        result = catalog(connection)
        calls.append(result)
        return result

    monkeypatch.setattr(validation, "_catalog", observed)
    assert validate_candidate(owner, path, Event(), migrate=False) == ()
    assert len(calls) == 2 and calls[0] == calls[1]


@pytest.mark.parametrize("limit,value", [("_CATALOG_LIMIT", 0), ("_CATALOG_BYTES", 1)])
def test_reference_catalog_limits_refuse_before_next_installed_statement(
    monkeypatch, limit, value
):
    from tldw_chatbook.DB import private_sqlite

    connect = private_sqlite.connect_private_sqlite
    tables = []

    def observed(*args, **kwargs):
        connection = connect(*args, **kwargs)

        def authorize(action, first, second, database, source):
            if action == sqlite3.SQLITE_CREATE_TABLE:
                tables.append(first)
            return sqlite3.SQLITE_OK

        connection.set_authorizer(authorize)
        return connection

    monkeypatch.setattr(private_sqlite, "connect_private_sqlite", observed)
    monkeypatch.setattr(validation, limit, value)
    with pytest.raises(ValueError, match="^sqlite_resource_limit$"):
        validation._reference(("CREATE TABLE naïve(x)", "CREATE TABLE extra(y)"))
    assert tables == ["naïve"]


@pytest.fixture
def legacy_fts_metadata(monkeypatch):
    """Replay SQLite 3.37's declaration callbacks on a real frozen candidate."""
    from tldw_chatbook.DB import private_sqlite

    original = private_sqlite.open_recovery_validation

    def install(
        *,
        query='PRAGMA table_xinfo("character_cards_fts")',
        extra=None,
        failure=None,
    ):
        observed = []

        @contextmanager
        def open_candidate(*args, **kwargs):
            with original(*args, **kwargs) as (connection, restrictions):
                observed.append(restrictions)

                class Candidate:
                    def __getattr__(self, name):
                        return getattr(connection, name)

                    def execute(self, sql):
                        if sql == query:
                            callbacks = [
                                (
                                    sqlite3.SQLITE_UPDATE,
                                    "sqlite_master",
                                    column,
                                    "main",
                                    None,
                                )
                                for column in (
                                    "type",
                                    "name",
                                    "tbl_name",
                                    "rootpage",
                                    "sql",
                                )
                            ]
                            if extra is not None:
                                callbacks.append(extra)
                            for callback in callbacks:
                                if (
                                    restrictions.authorize(*callback)
                                    != sqlite3.SQLITE_OK
                                ):
                                    raise sqlite3.OperationalError(
                                        "declaration refused"
                                    )
                            if failure == "prepare":
                                raise sqlite3.OperationalError(
                                    "metadata preparation failed"
                                )
                            if failure == "iterate":

                                class FailedCursor:
                                    def __iter__(self):
                                        raise sqlite3.OperationalError(
                                            "metadata iteration failed"
                                        )

                                return FailedCursor()
                        return connection.execute(sql)

                yield Candidate(), restrictions

        monkeypatch.setattr(private_sqlite, "open_recovery_validation", open_candidate)
        return observed

    return install


@pytest.mark.parametrize("core_store", ["chachanotes"], indirect=True)
@pytest.mark.parametrize("migrate", [False, True])
def test_legacy_fts_metadata_accepts_frozen_candidate_without_changes(
    core_store,  # noqa: F811
    legacy_fts_metadata,
    migrate,
):
    _, path, store, _ = core_store
    store.close()
    before = path.read_bytes()
    observed = legacy_fts_metadata()
    owner = validation._installed_owner("chat.attachments")
    assert validate_candidate(owner, path, Event(), migrate=migrate) == ()
    assert path.read_bytes() == before
    for column in ("type", "name", "tbl_name", "rootpage", "sql"):
        assert (
            observed[0].authorize(
                sqlite3.SQLITE_UPDATE, "sqlite_master", column, "main", None
            )
            == sqlite3.SQLITE_DENY
        )


@pytest.mark.parametrize("core_store", ["chachanotes"], indirect=True)
@pytest.mark.parametrize("failure", ["prepare", "iterate"])
def test_legacy_fts_metadata_refusal_closes_declaration_scope(
    core_store,  # noqa: F811
    legacy_fts_metadata,
    failure,
):
    _, path, store, _ = core_store
    store.close()
    before = path.read_bytes()
    observed = legacy_fts_metadata(failure=failure)
    owner = validation._installed_owner("chat.attachments")
    assert validate_candidate(owner, path, Event(), migrate=False) == (
        "sqlite_validation_unavailable",
    )
    assert (
        observed[0].authorize(
            sqlite3.SQLITE_UPDATE, "sqlite_master", "type", "main", None
        )
        == sqlite3.SQLITE_DENY
    )
    assert path.read_bytes() == before


@pytest.mark.parametrize("core_store", ["chachanotes"], indirect=True)
@pytest.mark.parametrize(
    "extra",
    [
        (sqlite3.SQLITE_UPDATE, "sqlite_master", "rowid", "main", None),
        (sqlite3.SQLITE_UPDATE, "notes", "content", "main", None),
        (sqlite3.SQLITE_UPDATE, "sqlite_master", "type", "temp", None),
        (sqlite3.SQLITE_UPDATE, "sqlite_master", "type", "main", "surprise"),
        (sqlite3.SQLITE_INSERT, "sqlite_master", None, "main", None),
        (sqlite3.SQLITE_DELETE, "sqlite_master", None, "main", None),
    ],
)
def test_legacy_fts_metadata_refuses_unrelated_writes(
    core_store,  # noqa: F811
    legacy_fts_metadata,
    extra,
):
    _, path, store, _ = core_store
    store.close()
    before = path.read_bytes()
    legacy_fts_metadata(extra=extra)
    owner = validation._installed_owner("chat.attachments")
    assert validate_candidate(owner, path, Event(), migrate=True) == (
        "sqlite_validation_unavailable",
    )
    assert path.read_bytes() == before


@pytest.mark.parametrize("core_store", ["chachanotes"], indirect=True)
@pytest.mark.parametrize(
    "query",
    [
        'PRAGMA table_xinfo("canvas_revisions")',
        'PRAGMA index_list("character_cards_fts")',
    ],
)
def test_legacy_fts_declaration_permission_is_only_for_fts_columns(
    core_store,  # noqa: F811
    legacy_fts_metadata,
    query,
):
    _, path, store, _ = core_store
    store.close()
    legacy_fts_metadata(query=query)
    owner = validation._installed_owner("chat.attachments")
    assert validate_candidate(owner, path, Event(), migrate=False) == (
        "sqlite_validation_unavailable",
    )


@pytest.mark.parametrize("core_store", ["chachanotes"], indirect=True)
def test_legacy_fts_metadata_does_not_inspect_uninstalled_catalog(
    core_store,  # noqa: F811
    legacy_fts_metadata,
):
    _, path, store, _ = core_store
    store.close()
    with closing(sqlite3.connect(path)) as db:
        db.execute("CREATE VIRTUAL TABLE surprise USING fts5(content)")
    before = path.read_bytes()
    legacy_fts_metadata(failure="prepare")
    owner = validation._installed_owner("chat.attachments")
    assert validate_candidate(owner, path, Event(), migrate=True) == (
        "unsupported_schema",
    )
    assert path.read_bytes() == before


def test_owned_tts_reference_digest_checked_on_restricted_connection(tmp_path):
    import hashlib

    from tldw_chatbook.TTS.profile_schema import open_profile_store
    from tldw_chatbook.TTS.recovery import recovery_adapters

    path = tmp_path / "tts.db"
    with closing(open_profile_store(path)) as db:
        # Existing constructor supplies the real installed v4 layout.
        db.execute(
            "INSERT INTO tts_generation_profiles VALUES (?,?,?,?,?,?,?,?,?,?,?,?)",
            (
                "p",
                "Voice",
                "voice",
                "openai",
                "tts-1",
                "alloy",
                "wav",
                1.0,
                "{}",
                1,
                "2026-01-01",
                "2026-01-01",
            ),
        )
        db.execute(
            "INSERT INTO tts_profile_clone_references VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
            (
                "p",
                "r",
                b"voice",
                "Transcript",
                hashlib.sha256(b"voice").hexdigest(),
                5,
                1,
                8000,
                1,
                "pcm_s16le",
                "2026-01-01",
                "2026-01-01",
                None,
                None,
            ),
        )
        db.commit()
    owner = next(a for a in recovery_adapters() if a.owner_id == "tts.profile_store")
    assert validate_candidate(owner, path, Event(), migrate=False) == ()
    with closing(sqlite3.connect(path)) as db:
        db.execute("UPDATE tts_profile_clone_references SET wav_bytes=?", (b"wrong",))
        db.commit()
    assert validate_candidate(owner, path, Event(), migrate=False) == (
        "tts_reference_digest_mismatch",
    )


def test_actual_domain_owners(domain_store):  # noqa: F811
    name, path, service = domain_store
    service.close()
    assert validate_candidate(domain_adapter(name), path, Event(), migrate=False) == ()


@pytest.mark.parametrize("name", tuple(STORES))
def test_actual_operational_owners(tmp_path, name):
    path = tmp_path / "operational.db"
    module, symbol, *_ = STORES[name]
    constructor = getattr(importlib.import_module("tldw_chatbook." + module), symbol)
    # File Notes' unrelated filesystem admission needs the app config selector.
    # Its actual memory constructor gives the identical schema to stage here.
    store = (
        constructor(":memory:")
        if name == "file_notes"
        else constructor(db_path=path)
        if name == "kanban"
        else constructor(path)
    )
    try:
        if name == "file_notes":
            with closing(sqlite3.connect(path)) as destination:
                store._get_connection().backup(destination)
        if name in {"kanban", "notifications", "events", "sync"}:
            store._ensure_schema()
    finally:
        if hasattr(store, "close"):
            store.close()
    assert (
        validate_candidate(operational_adapter(name), path, Event(), migrate=False)
        == ()
    )


def test_shared_study_assets_and_memberships(study_store):  # noqa: F811
    path, _ = study_store
    for identity in (
        "study.local",
        "quiz.local",
        "notes.sync_bindings",
        "chat.attachments",
    ):
        assert (
            validate_candidate(
                validation._installed_owner(identity), path, Event(), migrate=False
            )
            == ()
        )
    with closing(sqlite3.connect(path)) as db:
        db.execute("UPDATE flashcard_assets SET content=x'00'")
        db.commit()
    assert validate_candidate(
        validation._installed_owner("study.local"), path, Event(), migrate=False
    ) == ("missing_required_asset",)


def test_recovered_catalog_domain_validation_uses_candidate_only(tmp_path, local_root):
    from tldw_chatbook.Backup_Recovery.recovered_media import RecoveredMedia

    source = tmp_path / "source"
    source.write_bytes(b"opaque media")
    store = RecoveredMedia(tmp_path / "recovered")
    asset = store.retain(
        source, profile="p", message="m", slug="s", media_type="image/png"
    )
    owner = store.recovery_adapter()
    assert validate_candidate(owner, store.db_path, Event(), migrate=False) == ()
    # Cross-owner file validation needs the caller's staging map: this entry
    # checks the catalog, and cannot follow a locator to source bytes.
    store.resolve(asset)[1].unlink()
    assert validate_candidate(owner, store.db_path, Event(), migrate=False) == ()
    with closing(sqlite3.connect(store.db_path)) as db:
        db.execute("INSERT INTO operations VALUES (?,'retain')", (asset,))
        db.commit()
    assert validate_candidate(owner, store.db_path, Event(), migrate=False) == (
        "recovered_operation_pending",
    )


def test_inert_trusted_schema_pragma_is_not_accepted(tmp_path, monkeypatch):
    from tldw_chatbook.DB import private_sqlite

    owner, path = research_candidate(tmp_path)
    connector = private_sqlite._connect_registered_sqlite

    class UnsupportedTrust:
        def __init__(self, connection):
            self.connection = connection

        def __getattr__(self, name):
            return getattr(self.connection, name)

        def execute(self, query, *args):
            if query == "PRAGMA trusted_schema":
                return self.connection.execute("SELECT 1")
            return self.connection.execute(query, *args)

    monkeypatch.setattr(
        private_sqlite,
        "_connect_registered_sqlite",
        lambda *a, **kw: UnsupportedTrust(connector(*a, **kw)),
    )
    assert validate_candidate(owner, path, Event(), migrate=True) == (
        "sqlite_security_unavailable",
    )


def test_research_older_migration_preserves_committed_rows(tmp_path):
    owner, path = research_candidate(tmp_path)
    assert validate_candidate(owner, path, Event(), migrate=False) == ()
    with closing(sqlite3.connect(path)) as db:
        assert db.execute("PRAGMA user_version").fetchone() == (0,)
    assert validate_candidate(owner, path, Event(), migrate=True) == ()
    with closing(sqlite3.connect(path)) as db:
        assert db.execute("PRAGMA user_version").fetchone() == (1,)
        assert db.execute(
            "SELECT query,lease_attempts FROM research_runs"
        ).fetchall() == [("nebula", 0)]


@pytest.mark.parametrize("core_store", ["prompts"], indirect=True)
def test_prompt_v4_staged_migration_preserves_source_and_prompt_data(
    core_store,  # noqa: F811
    tmp_path,
):
    from shutil import copyfile

    name, source, store, db = core_store
    seed_domain(name, store)
    db.execute("DROP TABLE LocalPromptDrafts")
    db.execute("UPDATE schema_version SET version=4")
    db.commit()
    store.close()
    before = source.read_bytes()
    owner = next(a for a in core_adapters() if a.owner_id == "db.prompts.primary")
    with open_recovery_validation(owner.owner_id, source, writable=False) as db:
        expected = db.execute("SELECT * FROM Prompts ORDER BY id").fetchall()
    candidate = tmp_path / "candidate.db"
    copyfile(source, candidate)
    assert validate_candidate(owner, candidate, Event(), migrate=True) == ()
    assert validation.validated_schema_version(owner, candidate, Event()) == 5
    assert source.read_bytes() == before
    with closing(sqlite3.connect(candidate)) as db:
        assert db.execute("SELECT * FROM Prompts ORDER BY id").fetchall() == expected
        assert db.execute(
            "SELECT count(*) FROM prompts_fts WHERE prompts_fts MATCH 'nebula'"
        ).fetchone() == (1,)
        assert db.execute("SELECT count(*) FROM LocalPromptDrafts").fetchone() == (0,)
        db.execute(
            "INSERT INTO LocalPromptDrafts (content,created_at,updated_at) "
            "VALUES ('Retained draft','2026-09-29','2026-09-29')"
        )
        db.commit()
    assert validate_candidate(owner, candidate, Event(), migrate=False) == ()


@pytest.mark.parametrize("core_store", ["prompts"], indirect=True)
@pytest.mark.parametrize("version", [4, 5])
def test_prompt_migration_rejects_extra_trigger_before_writing(core_store, version):  # noqa: F811
    _, path, store, db = core_store
    if version == 4:
        db.execute("DROP TABLE LocalPromptDrafts")
        db.execute("UPDATE schema_version SET version=4")
    db.execute(
        "CREATE TRIGGER surprise AFTER UPDATE ON schema_version "
        "BEGIN SELECT load_extension('hostile'); END"
    )
    db.commit()
    store.close()
    before = path.read_bytes()
    owner = next(a for a in core_adapters() if a.owner_id == "db.prompts.primary")
    assert validate_candidate(owner, path, Event(), migrate=True) == (
        "unsupported_schema",
    )
    assert path.read_bytes() == before


@pytest.mark.parametrize("core_store", ["prompts"], indirect=True)
@pytest.mark.parametrize("cancelled", [False, True])
def test_prompt_failed_migration_rolls_back_created_table(
    core_store,  # noqa: F811
    cancelled,
    monkeypatch,
):
    _, path, store, db = core_store
    db.execute("DROP TABLE LocalPromptDrafts")
    db.execute("UPDATE schema_version SET version=4")
    db.commit()
    store.close()
    cancel = Event()
    authorize = validation._Restrictions.authorize

    def refuse_index(self, action, first, second, database, source):
        if (
            action == sqlite3.SQLITE_CREATE_INDEX
            and first == "idx_local_prompt_drafts_updated"
        ):
            if cancelled:
                cancel.set()
            return sqlite3.SQLITE_DENY
        return authorize(self, action, first, second, database, source)

    monkeypatch.setattr(validation._Restrictions, "authorize", refuse_index)
    owner = next(a for a in core_adapters() if a.owner_id == "db.prompts.primary")
    assert validate_candidate(owner, path, cancel, migrate=True) == (
        "cancelled" if cancelled else "sqlite_validation_unavailable",
    )
    assert validation.validated_schema_version(owner, path, Event()) == 4
    assert owner.validate(path) == ()


@pytest.mark.parametrize(
    "sql",
    [
        "CREATE TRIGGER surprise AFTER UPDATE ON research_runs BEGIN SELECT writefile('sentinel','bad'); END",
        "CREATE VIEW surprise AS SELECT load_extension('hostile')",
        "CREATE VIRTUAL TABLE surprise USING fts5(content)",
        "CREATE TABLE surprise(x GENERATED ALWAYS AS (hostile(id)), id)",
    ],
)
def test_altered_valid_catalog_never_executes_schema(tmp_path, sql):
    owner, path = research_candidate(tmp_path)
    sentinel = tmp_path.parent / (tmp_path.name + "-sentinel")
    sentinel.write_bytes(b"preserved")
    with closing(sqlite3.connect(path)) as db:
        db.create_function(
            "hostile",
            1,
            lambda value: sentinel.write_bytes(b"changed"),
            deterministic=True,
        )
        db.execute(sql)
    assert validate_candidate(owner, path, Event(), migrate=True) == (
        "unsupported_schema",
    )
    assert sentinel.read_bytes() == b"preserved"
    with closing(sqlite3.connect(path)) as db:
        assert db.execute("PRAGMA user_version").fetchone() == (0,)


@pytest.mark.parametrize(
    "sql",
    [
        "ATTACH ':memory:' AS surprise",
        "CREATE TABLE surprise(x)",
        "DELETE FROM research_runs",
        "PRAGMA writable_schema=ON",
        "PRAGMA trusted_schema=ON",
        "SELECT load_extension('surprise')",
        "SELECT writefile('outside','payload')",
    ],
)
def test_registered_seam_denies_side_effects_even_on_writable_candidate(tmp_path, sql):
    owner, path = research_candidate(tmp_path)
    with (
        open_recovery_validation(owner.owner_id, path, writable=True) as db,
        pytest.raises(sqlite3.Error),
    ):
        db.execute(sql)


def test_newer_schema_stamp_rejected(tmp_path):
    owner, path = research_candidate(tmp_path)
    with closing(sqlite3.connect(path)) as db:
        db.execute("PRAGMA user_version=999")
    assert validate_candidate(owner, path, Event(), migrate=True) == (
        "unsupported_schema_version",
    )


def test_archive_cannot_supply_migration_authority(tmp_path):
    owner, path = research_candidate(tmp_path)

    class ForeignOwner:
        owner_id = owner.owner_id

        def schema_policy(self):
            return replace(
                owner.schema_policy(),
                migration_steps=((0, 1, ("DELETE FROM research_runs",)),),
            )

    assert validate_candidate(ForeignOwner(), path, Event(), migrate=True) == (
        "unsupported_schema_policy",
    )


def test_failed_installed_migration_rolls_back(tmp_path, monkeypatch):
    owner, path = research_candidate(tmp_path)
    authorize = validation._Restrictions.authorize
    count = 0

    def fail_late(self, action, first, second, database, source):
        nonlocal count
        if action == sqlite3.SQLITE_ALTER_TABLE:
            count += 1
            if count == 3:
                return sqlite3.SQLITE_DENY
        return authorize(self, action, first, second, database, source)

    monkeypatch.setattr(validation._Restrictions, "authorize", fail_late)
    assert validate_candidate(owner, path, Event(), migrate=True)
    assert count == 3
    with closing(sqlite3.connect(path)) as db:
        assert db.execute("PRAGMA user_version").fetchone() == (0,)
        assert "lease_owner" not in {
            r[1] for r in db.execute("PRAGMA table_info(research_runs)")
        }
        assert db.execute("SELECT query FROM research_runs").fetchall() == [("nebula",)]


def test_cancel_during_installed_migration_rolls_back(tmp_path, monkeypatch):
    owner, path = research_candidate(tmp_path)
    cancel = Event()
    authorize = validation._Restrictions.authorize
    alters = 0

    def cancel_late(self, action, first, second, database, source):
        nonlocal alters
        if action == sqlite3.SQLITE_ALTER_TABLE:
            alters += 1
            if alters == 3:
                cancel.set()
        return authorize(self, action, first, second, database, source)

    monkeypatch.setattr(validation._Restrictions, "authorize", cancel_late)
    assert validate_candidate(owner, path, cancel, migrate=True) == ("cancelled",)
    with closing(sqlite3.connect(path)) as db:
        assert db.execute("PRAGMA user_version").fetchone() == (0,)
        assert "lease_owner" not in {
            r[1] for r in db.execute("PRAGMA table_info(research_runs)")
        }


def test_migration_never_reopens_candidate_unrestricted(tmp_path, monkeypatch):
    from tldw_chatbook.DB import private_sqlite

    owner, path = research_candidate(tmp_path)
    connector = private_sqlite._connect_registered_sqlite
    opened = []

    def record(owner_id, candidate, **kwargs):
        connection = connector(owner_id, candidate, **kwargs)
        if candidate != ":memory:":
            opened.append((owner_id, candidate, connection))
        return connection

    monkeypatch.setattr(private_sqlite, "_connect_registered_sqlite", record)
    assert validate_candidate(owner, path, Event(), migrate=True) == ()
    assert len(opened) == 1 and opened[0][:2] == ("recovery.validation", path)
    with pytest.raises(sqlite3.ProgrammingError, match="closed"):
        opened[0][2].execute("SELECT 1")


def test_sql_progress_budget_interrupts(tmp_path, monkeypatch):
    owner, path = research_candidate(tmp_path)
    monkeypatch.setattr(validation, "_STEP_BUDGET", 0)
    monkeypatch.setattr(validation, "_PROGRESS_INTERVAL", 1)
    assert validate_candidate(owner, path, Event(), migrate=True) == (
        "sqlite_resource_limit",
    )


def test_cancelled_query_stops_without_migration(tmp_path, monkeypatch):
    owner, path = research_candidate(tmp_path)
    cancel = Event()
    progress = validation._Restrictions.progress

    def cancel_on_progress(self):
        cancel.set()
        return progress(self)

    monkeypatch.setattr(validation, "_PROGRESS_INTERVAL", 1)
    monkeypatch.setattr(validation._Restrictions, "progress", cancel_on_progress)
    assert validate_candidate(owner, path, cancel, migrate=True) == ("cancelled",)


def test_extension_restrictions_without_optional_enable_method(tmp_path, monkeypatch):
    from tldw_chatbook.DB import private_sqlite

    owner, path = research_candidate(tmp_path)
    connector = private_sqlite._connect_registered_sqlite

    class MissingOptionalMethod:
        def __init__(self, connection):
            self.connection = connection
            enable_extensions = getattr(connection, "enable_load_extension", None)
            if enable_extensions is None:
                connection.setconfig(
                    sqlite3.SQLITE_DBCONFIG_ENABLE_LOAD_EXTENSION, True
                )
            else:
                enable_extensions(True)
            assert connection.getconfig(sqlite3.SQLITE_DBCONFIG_ENABLE_LOAD_EXTENSION)

        def __getattr__(self, name):
            if name == "enable_load_extension":
                raise AttributeError(name)
            return getattr(self.connection, name)

    monkeypatch.setattr(
        private_sqlite,
        "_connect_registered_sqlite",
        lambda *a, **kw: MissingOptionalMethod(connector(*a, **kw)),
    )
    assert validate_candidate(owner, path, Event(), migrate=True) == ()
    with open_recovery_validation(owner.owner_id, path, writable=False) as connection:
        assert (
            connection.getconfig(sqlite3.SQLITE_DBCONFIG_ENABLE_LOAD_EXTENSION) is False
        )
        with pytest.raises(sqlite3.OperationalError, match="not authorized"):
            connection.execute("SELECT load_extension('surprise')")
        # Verify the configuration itself also refuses loading, apart from the authorizer.
        connection.set_authorizer(None)
        with pytest.raises(sqlite3.OperationalError, match="not authorized"):
            connection.execute("SELECT load_extension('surprise')")


@pytest.mark.parametrize(
    "failure",
    [
        "missing_setconfig",
        "missing_getconfig",
        "failed_setconfig",
        "failed_getconfig",
        "inert_setconfig",
        "false_lookalike",
        "missing_option",
    ],
)
def test_extension_config_fallback_fails_closed(monkeypatch, failure):
    option = sqlite3.SQLITE_DBCONFIG_ENABLE_LOAD_EXTENSION

    class BrokenConfiguration:
        def __init__(self, connection):
            self.connection = connection

        def __getattr__(self, name):
            if name == "enable_load_extension":
                raise AttributeError(name)
            return getattr(self.connection, name)

        def setconfig(self, *args):
            if failure == "missing_setconfig":
                raise AttributeError("setconfig")
            if failure == "failed_setconfig":
                raise NotImplementedError
            if failure != "inert_setconfig":
                self.connection.setconfig(*args)

        def getconfig(self, *args):
            if failure == "missing_getconfig":
                raise AttributeError("getconfig")
            if failure == "failed_getconfig":
                raise sqlite3.OperationalError
            if failure == "false_lookalike":
                return 0
            return self.connection.getconfig(*args)

    with closing(sqlite3.connect(":memory:")) as connection:
        connection.setconfig(option, True)
        if failure == "missing_option":
            monkeypatch.delattr(sqlite3, "SQLITE_DBCONFIG_ENABLE_LOAD_EXTENSION")
        with pytest.raises(ValueError, match="^sqlite_security_unavailable$"):
            validation._restrict_connection(BrokenConfiguration(connection))


@pytest.mark.parametrize(
    "missing",
    [
        "enable_load_extension",
        "setlimit",
        "getlimit",
        "set_authorizer",
        "set_progress_handler",
    ],
)
def test_missing_security_primitive_fails_closed(tmp_path, monkeypatch, missing):
    from tldw_chatbook.DB import private_sqlite

    owner, path = research_candidate(tmp_path)
    connector = private_sqlite._connect_registered_sqlite

    class MissingPrimitive:
        def __init__(self, connection):
            self.connection = connection

        def __getattr__(self, name):
            if name == missing or (
                missing == "enable_load_extension"
                and name in {"setconfig", "getconfig"}
            ):
                raise AttributeError(name)
            return getattr(self.connection, name)

    monkeypatch.setattr(
        private_sqlite,
        "_connect_registered_sqlite",
        lambda *a, **kw: MissingPrimitive(connector(*a, **kw)),
    )
    assert validate_candidate(owner, path, Event(), migrate=True) == (
        "sqlite_security_unavailable",
    )


def test_observed_schema_version_preserves_historical_layout(tmp_path):
    owner, path = research_candidate(tmp_path)
    assert validation.validated_schema_version(owner, path, Event()) == 0
    assert validate_candidate(owner, path, Event(), migrate=True) == ()
    assert validation.validated_schema_version(owner, path, Event()) == 1


@pytest.fixture
def native_rag_indexing_candidate(tmp_path):
    """Populate the installed tracking writer without a model or vector engine."""
    from datetime import UTC, datetime

    from tldw_chatbook.Backup_Recovery.rag_indexing import recovery_adapters
    from tldw_chatbook.DB.RAG_Indexing_DB import RAGIndexingDB

    path = tmp_path / "rag-indexing.db"
    store = RAGIndexingDB(path)
    try:
        store.mark_item_indexed(
            "retained-note",
            "note",
            datetime(2026, 9, 7, tzinfo=UTC),
            chunk_count=3,
            metadata={"collection": "retained_notes"},
        )
        store.update_collection_state("retained_notes", 1, 1)
        expected = store.get_indexed_item_info("retained-note", "note")
    finally:
        store.close()
    return recovery_adapters()[0], path, expected


@pytest.mark.parametrize("migrate", [False, True])
def test_native_rag_indexing_schema_zero_survives_restricted_validation(
    native_rag_indexing_candidate, migrate
):
    from tldw_chatbook.DB.RAG_Indexing_DB import RAGIndexingDB

    owner, path, expected = native_rag_indexing_candidate
    assert validate_candidate(owner, path, Event(), migrate=migrate) == ()
    assert validation.validated_schema_version(owner, path, Event()) == 0
    store = RAGIndexingDB(path)
    try:
        assert store.get_indexed_item_info("retained-note", "note") == expected
    finally:
        store.close()


def test_native_rag_indexing_uninstalled_schema_is_refused(
    native_rag_indexing_candidate,
):
    owner, path, _ = native_rag_indexing_candidate
    with closing(sqlite3.connect(path)) as db:
        db.execute("CREATE TABLE uninstalled_payload(value TEXT)")
        db.commit()
    assert validate_candidate(owner, path, Event(), migrate=True) == (
        "unsupported_schema",
    )


def test_native_rag_indexing_cannot_supply_foreign_policy(
    native_rag_indexing_candidate,
):
    owner, path, _ = native_rag_indexing_candidate

    class ForeignOwner:
        owner_id = owner.owner_id

        def schema_policy(self):
            return replace(
                owner.schema_policy(),
                migration_steps=((0, 1, ("DELETE FROM indexed_items",)),),
            )

    assert validate_candidate(ForeignOwner(), path, Event(), migrate=True) == (
        "unsupported_schema_policy",
    )
