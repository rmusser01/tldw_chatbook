# Task 23 incomplete source checkpoint

Status: NEEDS_CONTEXT. Root requested this clean checkpoint before the inherited screen-test profile extension. Implementation and the two new regression selectors are committed; remaining verification is pending.

Commit: `9c8a42ff6427795db94baf9a966275ab565b5eb7` — `fix(console): preserve transparent parents during persisted restore`.
Base: `6324c15bc27c8de3b7eb044688e73f0a07c33ee3`. Only the three assigned source paths changed. Index/worktree clean after commit; test and command processes returned and their receipts record closure. Normal git commit emitted existing automatic-gc warnings about gc.log/unreachable loose objects; no cleanup was requested or performed.

## Implementation

The new private, I/O-free `_refresh_console_message_parents` mutates supplied message parents using the fetched raw rows and the final retained set. It refreshes retained/null durable parents and walks absent ancestors only when the exact flattener predicate proves them truly empty. Missing rows, ineligible gaps, skipped cycles and self-links preserve supplied structural parents. Local successful-chain caching handles fan-out; the visited guard also rejects a cached target equal to the current child. The store calls it after continuation/thinking owners have all appended, replacing the unconditional raw-parent assignment. No fetch bound, retention, cursor, durable bytes, cap, import owner or recovery ordering change was intended.

Exactly two new test selectors use canonical per-node bootstrap profiles. Real SQLite/service/persistence proves two transparent empty ancestors, sibling preservation, selected ancestry, imported before-first roots, current durable reparent to retained/null/different retained ancestry through empties, and late appended thinking ownership. Bounded supplied-row projections cover missing/cyclic/self/ineligible ancestry and the cache-self case; the actual continuation warning owner is explicitly retained with exact ID/role/content/state/parent/order. IDs/order/content, cursor, raw rows and real sidecar bytes are asserted.

ADR required: no. Existing ADRs `backlog/decisions/100-console-active-path-before-first-cursor.md` and `backlog/decisions/063-hosted-provider-wire-and-durable-tool-continuation.md` govern imported roots and generation-owned continuation. This is a routine contract repair; no new boundary was chosen.

## Evidence and preserved failures

Every phase has its actual source hashes, argv, private environment overrides, unchanged 300-second bound, independent stdout/stderr, JUnit, selected node IDs, product import closure and exit in `task-23-safe-evidence/`. `checkpoint-phase-map.json` maps exact saved source snapshots for every phase. All seven selected executions were closed and source stable, and loaded product modules came from the fixed worktree. No full suite, installs, new skip/xfail, suppression or benchmark loop occurred.

| Phase | Exit | Meaning |
| --- | ---: | --- |
| red-transparent | 1 | Unqualified setup: DB add rejected an empty user row. Original test source preserved. |
| red-transparent-v2 | 1 | Qualified RED after ruling 95: canonical versioned content clears succeeded; child parent was `empty-2`, expected `answer`. |
| red-current | 1 | Unqualified cardinality assertion: malformed continuation correctly appended a warning owner. Original source preserved. |
| red-current-v2 | 1 | Qualified RED after ruling 96 retained that owner: current empty-chain child parent was `empty-2`, expected `new`. Retained/null changes and warning-owner invariants passed first. |
| green-transparent | 0 | New transparency selector passed, covering direct/prepared restore, off-branch navigation and imported before-first cursor. |
| green-current | 0 | New current-parent selector passed, including cache-self/fallback controls and raw/sidecar/cursor preservation. |
| green-screen-walk | 1 | Existing selector failed before store/helper in `_fixture_app → _build_test_app → build_test_app_config → load_settings → config_participants/raw_participants`, with `RecoveryRequired("raw_source_selection_changed")`. |

The first GREEN used a 22,332-line store with one long added import. Only that import was subsequently wrapped to formatter style, yielding 22,334 lines. Its prior store bytes are preserved in `green-transparent-store.py`; this PASS is carried across that formatting-only source phase, and is not presented as a test run on final bytes/HEAD. The second GREEN and failed existing control used checkpoint bytes. Executable-AST proof of the formatting carry remains pending with the static checks.

No pytest warnings were recorded in any phase. The optional PyAudio import warning appears transparently in failure streams and captured success logs; closure JSON captures successful report sections without changing pytest markers or behavior. The RED plugin retained warning streams; its earlier bytes are saved separately. No warning is hidden or described as pristine output.

## Scope and pending work

`checkpoint-preservation.json` verifies unchanged hashes for all 30,735 unowned tracked files and 3,857 prior safe artifacts, excluding root's mutable `progress.md`. Raw store measurement is 22,334 against unchanged 22,344 cap and 50-line slack tolerance; the two cap pytest nodes remain unrun. Only assigned source paths were staged/committed; actual stage/commit/status command receipts and streams are retained.

The five existing control selectors, Task 21 SQLite provenance selector, two cap selectors, fatal Ruff, added-hunk formatting, executable AST preservation, whitespace and final scoped self-review are pending. Only the screen-tree control was attempted; the remaining seven control/cap nodes have not run. Root intends to track a narrow per-node bootstrap marker extension for the inherited screen test, then resume this same writer for only the failed node, remaining unrun controls and statics. No successful cohort replay has occurred.

Self-review found a concrete pending helper edge: `str(node.persisted_message_id)` converts anonymous `None` to literal `"None"`, which could collide with a legitimate fetched row having that string ID. Match the existing lookup's exclusion of anonymous owners before normalization, and qualify within the existing second selector if root authorizes it. This was raised during the pause and is not silently claimed resolved. No new source changes were made after the failed existing control.

This checkpoint is incomplete and has no completion/merge-ready verdict. Root independent review/publication and all external gates remain pending.


## Follow-up completion (current handoff)

Status: DONE for the bounded Task 23 source work and targeted verification. The earlier incomplete checkpoint above is retained verbatim as historical evidence.

Final source commit: `f42fcebe5a70982989e6133b007bd88f17ae763c` — `fix(console): keep anonymous restore owners outside durable refresh` (two changed owners). Original store/root-cause implementation remains in `9c8a42ff6427795db94baf9a966275ab565b5eb7`; combined original-BASE-to-final change owns exactly the three assigned source paths. Root metadata base for this follow-up was `0818f1d146d4dd0da2e56bb31ff332f913aee983`.

The exact screen-tree node now carries the canonical bootstrap-profile marker; its original body/assertions/fixtures remain unchanged. A bounded supplementary anonymous/literal-`"None"` control was added inside the second regression after the real SQLite proof. It reached RED (`anonymous.parent_message_id == "new"`, expected supplied `"old"`) before the helper's exact `persisted_message_id is None` guard was added. The changed second selector then passed; legitimate literal IDs continue to refresh. This resolves the pending helper concern above.

### Selected execution and source qualification

`red-anonymous` exited 1 on the required collision assertion; `green-anonymous` exited 0 on the changed second selector. `green-screen-walk-v2`, `green-store-tree`, `green-blank-owner`, `green-thinking`, `green-cursor-recovery`, and `green-task21-provenance` each selected exactly one requested node and passed. `green-store-caps` selected exactly the two store growth/slack parameter nodes and passed. These nine passing cases ran against final source bytes before the final commit, in separately isolated canonical processes (the two source-only cap nodes shared one process). Every process closed, remained source stable, and retained exact argv/environment/stdout/stderr/JUnit/node IDs/import closure.

The first transparency selector's existing PASS was carried, without replay: its full function AST is unchanged, all nine fixture IDs are explicit nonanonymous strings, and removing only the exact None guard yields the previously passing helper AST. Its earlier store import-wrap change is executable-AST identical to final store. `static-ast-proof-result.json` records these proofs. This is a scoped source carry, not a test execution on final HEAD or a blanket final-head PASS claim. Ten distinct requested cases are qualified in total: nine on final bytes plus this carried first selector.

No pytest warnings were recorded. Captured logs disclose the optional PyAudio warning. The screen-tree and Task 21 app-factory cases additionally record the original app initialization logs that Prompts service is unset and ChaChaNotesDB is not assigned before fixture attachment. They passed their actual assertions; no logs or warnings were suppressed and output is not called pristine.

### Static checks, preserved failures and scope

Fatal Ruff passed. Added-helper/changed-store-method/new-regression formatting passed. Executable AST matches original BASE outside the one store method and new hydration helper; the store method differs only by the intended parent-block replacement. Removing only the two new selectors and the exact screen marker restores the complete test-owner BASE AST. Whitespace passed. Actual Ruff formatting of baseline and final store each measures **22,334** lines, under unchanged **22,344** cap and **50** slack tolerance; both actual formatter commands retain separate exits/input hashes/stdout/stderr. All static checks have actual command receipts/streams and source pins, rather than report-only claims.

Two evidence-tool failures are retained. `static-added-format` rejected an extra terminal blank line introduced by the snippet extractor; under ruling99, the original snippet/driver bytes were retained and a distinct one-terminal-newline snippet passed `static-added-format-v2`, with product/test source untouched. `static-preservation` rejected my in-place enhanced runner against its original checkpoint pin; under ruling100, original `run.py` was restored exactly and the enhanced bytes moved to the additive `run-with-static-input-binding.py`. `static-preservation-v2` passed. The historical enhanced-runner commands preserve their old argv path and bind it to the explicit enhanced snapshot in the final phase map; no historical receipt was rewritten. No passed check or test cohort was replayed for these artifact corrections.

Preservation verified **30,735** unowned tracked paths against the follow-up metadata base and **3,857** prior safe artifacts, excluding root's mutable progress. The **12,582** QA file hashes in the receipt are the combined exact prefixes: **10,555** tracked/readable `Docs/superpowers/qa/` entries and **2,027** top-level `qa/` entries, as clarified in `qa-count-basis.json`; this does not label the combined number as tracked Docs QA alone. Only the two authorized root metadata files differ outside the three owners from original BASE. Original checkpoint67 pins remain verifiable through only the frozen report/brief aliases; current report keeps the frozen report as its exact byte prefix.

Scoped self-review found no remaining implementation concern. Anonymous owners preserve supplied links; legitimate IDs, current raw retained/null/transparent ancestry, successful-cache fan-out, cache-to-self/malformed fallback, final sidecar owner membership and durable bytes/cursors are covered. No other source, dependency, retention, database boundary, fetch limit, cap, profile fixture, skip/xfail, timeout or governance gate was changed. The index/worktree is clean; execution and commit/status receipts are closed. Normal git commit emitted automatic identity/gc messages; no identity configuration, history rewrite or object cleanup was performed.

ADR check remains no new ADR, under the existing ADR-100/063 contract; the profile marker and missing-ID guard are routine repairs. No additional general lesson was added: the repository already documents collection-time profile admission and evidence provenance. Original6324-to-final scoped independent review, additive publication and current hosted/external/merge gates remain root work and are outside this DONE verdict.

Final safe export: `task-23-safe-evidence-manifest-final.json`; explicit own-SDD-relative artifact paths map to byte length/SHA256, and `sources` uses repository-relative paths. It pins the current report/brief, frozen pre-follow-up aliases, source snapshots, every preserved failure/success/static phase, original checkpoint manifest and runner relocation. Private profile/config/DB/archive/bundle payloads are excluded.
