# Task 23 incomplete source checkpoint

Status: NEEDS_CONTEXT. Root requested this clean checkpoint before the inherited screen-test profile extension. Implementation and the two new regression selectors are committed; remaining verification is pending.

Commit: `9c8a42ff6427795db94baf9a966275ab565b5eb7` — `fix(console): preserve transparent parents during persisted restore`.
Base: `6324c15bc27c8de3b7eb044688e73f0a07c33ee3`. Only the three assigned source paths changed. Index/worktree clean after commit; test and command processes returned and their receipts record closure. Normal git commit emitted existing automatic-gc warnings about gc.log/unreachable loose objects; no cleanup was requested or performed.

## Implementation

The new private, I/O-free `_refresh_console_message_parents` mutates supplied message parents using the fetched raw rows and the final retained set. It refreshes retained/null durable parents and walks absent ancestors only when the exact flattener predicate proves them truly empty. Missing rows, ineligible gaps, skipped cycles and self-links preserve supplied structural parents. Local successful-chain caching handles fan-out; the visited guard also rejects a cached target equal to the current child. The store calls it after continuation/thinking owners have all appended, replacing the unconditional raw-parent assignment. No fetch bound, retention, cursor, durable bytes, cap, import owner or recovery ordering change was intended.

Exactly two new test selectors use canonical per-node bootstrap profiles. Real SQLite/service/persistence proves two transparent empty ancestors, sibling preservation, selected ancestry, imported before-first roots, current durable reparent to retained/null/different retained ancestry through empties, and late appended thinking ownership. Bounded supplied-row projections cover missing/cyclic/self/ineligible ancestry and the cache-self case; the actual continuation warning owner is explicitly retained with exact ID/role/content/state/parent/order. IDs/order/content, cursor, raw rows and real sidecar bytes are asserted.

ADR required: no. Existing ADRs `backlog/decisions/100-console-active-path-before-first-cursor.md` and `backlog/decisions/063-hosted-provider-wire-and-durable-tool-continuation.md` govern imported roots and generation-owned continuation. This is a routine contract repair; no new boundary was chosen.

## Evidence and preserved failures

Every phase has its actual source hashes, argv, private environment overrides, unchanged 300-second bound, independent stdout/stderr, JUnit, selected node IDs, product import closure and exit in `task-23-safe-evidence/`. `checkpoint-phase-map.json` maps exact saved source snapshots for every phase. All seven selected executions were closed and source stable, and loaded product modules came from the fixed worktree. No full suite, installs, new skip/xfail, suppression or benchmark loop occurred.

| Phase | Exit | Meaning |
| --- | ---: | --- |
| red-transparent | 1 | Unqualified setup: DB add rejected an empty user row. Original test source preserved. |
| red-transparent-v2 | 1 | Qualified RED after ruling 95: canonical versioned content clears succeeded; child parent was `empty-2`, expected `answer`. |
| red-current | 1 | Unqualified cardinality assertion: malformed continuation correctly appended a warning owner. Original source preserved. |
| red-current-v2 | 1 | Qualified RED after ruling 96 retained that owner: current empty-chain child parent was `empty-2`, expected `new`. Retained/null changes and warning-owner invariants passed first. |
| green-transparent | 0 | New transparency selector passed, covering direct/prepared restore, off-branch navigation and imported before-first cursor. |
| green-current | 0 | New current-parent selector passed, including cache-self/fallback controls and raw/sidecar/cursor preservation. |
| green-screen-walk | 1 | Existing selector failed before store/helper in `_fixture_app → _build_test_app → build_test_app_config → load_settings → config_participants/raw_participants`, with `RecoveryRequired("raw_source_selection_changed")`. |

The first GREEN used a 22,332-line store with one long added import. Only that import was subsequently wrapped to formatter style, yielding 22,334 lines. Its prior store bytes are preserved in `green-transparent-store.py`; this PASS is carried across that formatting-only source phase, and is not presented as a test run on final bytes/HEAD. The second GREEN and failed existing control used checkpoint bytes. Executable-AST proof of the formatting carry remains pending with the static checks.

No pytest warnings were recorded in any phase. The optional PyAudio import warning appears transparently in failure streams and captured success logs; closure JSON captures successful report sections without changing pytest markers or behavior. The RED plugin retained warning streams; its earlier bytes are saved separately. No warning is hidden or described as pristine output.

## Scope and pending work

`checkpoint-preservation.json` verifies unchanged hashes for all 30,735 unowned tracked files and 3,857 prior safe artifacts, excluding root's mutable `progress.md`. Raw store measurement is 22,334 against unchanged 22,344 cap and 50-line slack tolerance; the two cap pytest nodes remain unrun. Only assigned source paths were staged/committed; actual stage/commit/status command receipts and streams are retained.

The five existing control selectors, Task 21 SQLite provenance selector, two cap selectors, fatal Ruff, added-hunk formatting, executable AST preservation, whitespace and final scoped self-review are pending. Only the screen-tree control was attempted; the remaining seven control/cap nodes have not run. Root intends to track a narrow per-node bootstrap marker extension for the inherited screen test, then resume this same writer for only the failed node, remaining unrun controls and statics. No successful cohort replay has occurred.

Self-review found a concrete pending helper edge: `str(node.persisted_message_id)` converts anonymous `None` to literal `"None"`, which could collide with a legitimate fetched row having that string ID. Match the existing lookup's exclusion of anonymous owners before normalization, and qualify within the existing second selector if root authorizes it. This was raised during the pause and is not silently claimed resolved. No new source changes were made after the failed existing control.

This checkpoint is incomplete and has no completion/merge-ready verdict. Root independent review/publication and all external gates remain pending.
