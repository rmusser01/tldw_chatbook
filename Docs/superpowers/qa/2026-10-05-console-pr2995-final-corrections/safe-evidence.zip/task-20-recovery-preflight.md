# Task 20 — Qodo comment4180396202 recovery preflight

Source: PR #2995, worktree `/Users/macbook-dev/.codex/worktrees/console-chat-starts/tldw_chatbook`, HEAD `76bce76345f20743d309d44b82f5d45d93c58801`.
Read-only investigation; no tests, imports of application code, source/index/HEAD edits, or child agents. Only this private report was written. Initial source status was clean.

## Verdict

**The reported recovery refusal is real by direct source trace.** An exact shipped ChaChaNotes v76 catalog passes validation and restore planning, but ordinary archive staging requests migration, and `_validate_candidate` rejects it with `unsupported_schema_migration`. A local snapshot avoids this migration path. Native v76 has different physical checkpoint columns and already receives its permitted metadata-only upgrade.

**Policy qualification:** this is not an accidental violation of an unambiguous current “all supported versions restore” policy. ADR-219's `Native receipt schema compatibility (2026-10-04)` explicitly states that ordinary v75 and shipped v76 validate/export but do not receive staged DDL migration. The existing test explicitly requires the v76 refusal. Correcting ordinary v76 restore is a narrow policy amendment to that clarification, subject to ADR-126's existing safeguards. The review points out a real product compatibility gap; it does not justify silently deleting the gate or relabeling shipped v76 as native.

## Compact source map

| Boundary | Source and observed behavior |
| --- | --- |
| Installed ownership | `Backup_Recovery/owner_registry.py:45` installs inert owner factories. `sqlite_validation.py:40` independently resolves the installed owner. `_validate_candidate:643-646` rejects a caller-supplied differing policy. Archive contents never supply migration authority. |
| Catalogs | `DB/recovery_core_schema.py:778-814` retains v75, shipped v76, native v76 and current v77 variants. Shipped v76 uses the old checkpoint table, without `agent_chat_start_attempt_id`; native v76/current v77 have it. Both dictionary trigger variants are explicit complete tuples. `CHACHANOTES_V76_SCHEMA` is the earlier native-name constant, not the shipped catalog. |
| Policy | `DB/recovery_core.py:461-495` accepts versions 77/76/75 and both v76 families, but declares only `(76,77,CHACHANOTES_NATIVE_V76_TO_V77_SQL)`. That SQL is one version UPDATE; it cannot upgrade a shipped checkpoint table. |
| Export/validation | `_CoreAdapter.validate`, `recovery_core.py:248-295`, matches complete catalog and stamp before integrity checks. `sqlite_validation.py:576-630` additionally compares reference metadata and domain checks. `migrate=False` never reaches the migration gate. |
| Preview | `Backup_Recovery/restore_plan.py:925-937` checks selected installed owners and membership of the manifest version in `policy.versions`. Thus shipped v76 is accepted at this point. |
| Extraction/staging | `staging.py:511-525,600-643` creates private extracted files, verifies payload digests and sealed archive, and resolves installed owners. `773-786` calls `validate_candidate(..., migrate=plan.local_snapshot is None)`. With no local snapshot this is true. Failure is raised at `803-804` before publication. |
| Exact failure | `sqlite_validation.py:653-670`: full `_check` passes; 76 differs from max 77; primary owner must match `CHACHANOTES_V76_NATIVE_SCHEMAS`; shipped v76 returns `unsupported_schema_migration`. The refusal precedes BEGIN and all mutation. |
| Native transaction | `671-718`: same restricted connection, BEGIN, unique declared forward step, bounded execution, final `_check` of expected version, commit; failure/cancellation rolls back with progress interruption disabled for cleanup. |
| Connection/authority | `DB/private_sqlite.py:1946-1982` opens a required existing private candidate, disables statement caching, applies restrictions before imported queries. `sqlite_validation.py:92-340` owns the temporary migration permissions. Primary-owner addition currently allows only direct `main.db_schema_version.version` UPDATE. Existing migration machinery also has narrowly installed owner DDL patterns and common catalog-update/transaction allowances; do not describe the entire authorizer as literally allowing only one SQLite action. |
| Other callers | `credentials.py:866`, `publication.py:2569` call `validate_candidate(...,migrate=False)`; `validated_schema_version:746` also uses false. These need no production edits. `stage_restore` is the common migration caller; do not patch individual restore entrypoints. |
| Runtime migration | `DB/ChaChaNotes_DB.py:7776-7831` executes `DB/migrations/chachanotes_v76_to_v77_agent_chat_starts.sql` for ordinary v76. Native column presence only selects full-catalog qualification; qualified native catalog receives stamp-only update. Runtime also separately qualifies Subscription combined catalogs. Runtime constructor access must not be used as a recovery bypass. |

## Existing evidence and the missing test

Source-read controls, **not executions in this preflight**:

- `Tests/Backup_Recovery/test_chachanotes_native76_compatibility.py::test_native76_staged_upgrade_preserves_machine_receipts` covers native variants and exact receipt/message preservation.
- `::test_ordinary_older_schema_validates_but_staged_ddl_remains_refused` parametrizes 75 and 76 and explicitly requires the reported refusal. Keep v75 refusal; change only the shipped-v76 contract when the amendment is approved.
- The same file covers hybrid/other-owner refusal, stamp rollback on validation failure/cancellation, exact metadata authority, and Subscription outer/inner stamps.
- `Tests/DB/test_chachanotes_v77_agent_chat_starts_migration.py::test_v77_keeps_every_predecessor_checkpoint_column_and_indexes` proves the ordinary runtime/standalone SQL path with a populated queued checkpoint. It does not exercise the restricted recovery authorizer.
- Its native upgrade, malformed native catalog, and constructor-catalog capture tests qualify different important routes; none proves shipped v76 staged restore.
- `Tests/Backup_Recovery/test_restore_plan.py::test_real_older_sqlite_migrates_only_private_candidate` is the existing real archive → plan → stage pattern, currently for Research.

**Essential missing regression:** create a genuine shipped v76 with `chachanotes_db_at_version(path,76)`, seed valid manual and queued checkpoint rows plus their messages/conversation, and exercise both qualified dictionary variants. Close the fixture and preserve original bytes. Package those bytes using the existing `sealed` helper, declare primary owner/version76, then `plan_restore` and real `stage_restore` with `local_snapshot is None`. Assert the returned candidate is exact validated v77; every predecessor checkpoint field and all message rows remain identical; new `agent_chat_start_attempt_id` values are NULL; indexes/FKs remain valid; original DB and sealed/input archive bytes remain unchanged; no live destination was created. Keep candidate cleanup under the existing fixture lifecycle.

On current HEAD this must fail at the actual stage call with `unsupported_schema_migration`, after a positive assertion that direct `migrate=False` validation succeeds. Do not construct a current DB and merely stamp it76, patch `_check` to pass, or assert only an error disappears. Successful post-migration validation alone cannot prove saved rows survived.

## Minimum safe repair proposal

1. Amend ADR-219 first: support exact **shipped v76 primary-owner** staged migration using installed v76→v77 SQL, alongside the existing native metadata-only route. Retain v75 refusal and exact Subscription policy. Link ADR-126, ADR-208, and the owning implementation task/plan.
2. In `sqlite_validation.py`, retain initial `_check`, installed policy equality, budgets and one transaction. Classify the already-validated full catalog as native76 or shipped76; reject every other older primary catalog as today. Select the existing one-statement path for native. For shipped, execute the installed v77 SQL file and then the existing stamp statement, followed by the same final `_check` and commit/rollback lifecycle.
3. Read the packaged SQL file, never copy its CREATE/INSERT body into another embedded constant. ADR-208 makes the on-disk migration authoritative. Use the established `sqlite3.complete_statement` accumulation pattern (`ChaChaNotes_DB._split_sql_statements:514-539`) rather than naive `split(';')` or `executescript` (which would compromise the enclosing transaction). The existing splitter resides in the runtime DB module; avoid importing that heavyweight module solely for recovery parsing. A small local installed-file reader/loop in the validator is preferable to introducing a general migration framework or broad parser relocation. Keep this exception owner/version/catalog-specific.
4. Add one temporary **shipped checkpoint migration** restriction flag, enabled only after shipped catalog qualification and cleared in `finally`. DDL/copy permissions must require this flag, `migrating`, primary owner, expected database and no trigger source. Do not grant these actions to native metadata-only migration merely because its owner/version is the same.
5. Permit only the actual installed table-rebuild objects/actions: create `console_dispatch_checkpoints_v77`; insert copied rows into it; drop old `console_dispatch_checkpoints`; rename the temporary table; recreate the two fixed indexes; their fixed automatic uniqueness indexes and required SQLite catalog operations. Keep unrelated tables, messages writes, other owners, trigger-origin writes and attachment/extension operations denied. Reuse the current owner-gated authorizer shape and Evals' narrow internal-schema exception pattern where needed.
6. Preserve final exact v77 matching, integrity/domain validation, cancellation rollback, `migrate=False`, local snapshot behavior and original archive bytes. Do not disable security pragmas, invoke constructors, reopen unrestricted, or weaken catalog matching to column presence.

**Implementation uncertainty to resolve, not permission to widen:** SQLite table RENAME rewrites catalog text and calls internal rename functions; its exact main/temp callbacks vary by SQLite version (the Evals authorizer documents this class of variation). Current allowed functions include `sqlite_rename_test`/`sqlite_rename_quotefix` but not necessarily every function needed by RENAME. Measure the fixed installed script's callbacks on a disposable exact candidate and allow only those required. Canvas CHECK validation also uses a bounded installed UDF/trust scope; determine whether RENAME's schema reparse needs the existing `_canvas_schema_access` scope. Never toggle trust around unqualified schema or permit arbitrary functions to make the test green. Native tests must prove their DDL permissions remain closed.

### Owned implementation files

Expected minimum: `tldw_chatbook/Backup_Recovery/sqlite_validation.py`; existing `Tests/Backup_Recovery/test_chachanotes_native76_compatibility.py`; `Tests/Backup_Recovery/test_restore_plan.py`; `backlog/decisions/219-console-chat-destinations-and-bounded-starts.md`; the owning Backlog task/plan/notes. A small shipped-specific test module is optional only if it makes the test ownership clearer. No required changes to schema versions, frozen catalogs, registry, staging/publication callers, `ChaChaNotes_DB`, Subscription policy, or the SQL migration file. Avoid changing `SchemaPolicy`'s public tuple shape to solve one same-number catalog exception.

ADR required: **yes, amendment**.
ADR path: `backlog/decisions/219-console-chat-destinations-and-bounded-starts.md`.
Reason: explicitly reverses its shipped-v76 staged-DDL exclusion and narrows new recovery write authority; ADR-126's safety contract still governs. No duplicate new ADR is necessary.

## Focused RED / control / GREEN contract

Use the established private-profile test runner and installed environment; no installs and no full sweep. New node names below are proposed, not existing tests or claimed results.

RED first:

- `Tests/Backup_Recovery/test_restore_plan.py::test_shipped76_archive_stages_v77_without_changing_source` (dictionary false/true; genuine populated v76, actual planning/staging). Preserve its exact failing exception evidence.

New focused safeguards:

- `Tests/Backup_Recovery/test_chachanotes_native76_compatibility.py::test_shipped76_staged_failure_rolls_back_checkpoint_rebuild` — parameterize a denial late in index creation, a failed final validation, and cancellation after rebuild. Prove the old stamp/catalog/checkpoint/message rows return; the source artifact remains byte-identical. A branch that never reached DDL is not rollback evidence.
- `::test_shipped76_migration_authority_is_exact` — actual SQL denial for unrelated table/row writes, plus authorizer action tuples for trigger/temp/wrong-owner/nonmigration/native-context permissions. Include positive witnesses for intended operations on disposable shipped candidate.
- `::test_shipped76_malformed_catalog_refuses_before_writing` — extra trigger or changed checkpoint index; error `unsupported_schema`; unchanged candidate bytes. Native malformed tests alone do not cover the new branch.
- Installed-file consumption witness in the shipped test: instrument the exact file read or inject an inert detectable failing statement via its file-read seam, assert recovery observes it and rolls back. This prevents an embedded twin from silently replacing the artifact.

Existing controls to run unchanged except the deliberate v76 refusal expectation:

- Entire `Tests/Backup_Recovery/test_chachanotes_native76_compatibility.py` (small affected owner).
- `Tests/DB/test_chachanotes_v77_agent_chat_starts_migration.py::test_v77_keeps_every_predecessor_checkpoint_column_and_indexes`
- `Tests/DB/test_chachanotes_v77_agent_chat_starts_migration.py::test_legacy_native76_upgrade_preserves_exact_receipts`
- `Tests/DB/test_chachanotes_v77_agent_chat_starts_migration.py::test_unknown_native76_catalog_refuses_without_rewriting`
- `Tests/DB/test_chachanotes_v77_agent_chat_starts_migration.py::test_v77_constructor_catalog_matches_exact_native76_capture`
- `Tests/Backup_Recovery/test_sqlite_validation.py::test_archive_cannot_supply_migration_authority`
- `Tests/Backup_Recovery/test_sqlite_validation.py::test_migration_never_reopens_candidate_unrestricted`
- `Tests/Backup_Recovery/test_sqlite_validation.py::test_prompt_v4_staged_migration_preserves_source_and_prompt_data`
- `Tests/Backup_Recovery/test_evals_recovery_migration.py::test_v5_evals_candidate_migrates_to_v6_and_keeps_its_rows`
- `Tests/Backup_Recovery/test_evals_recovery_migration.py::test_evals_drop_column_authority_is_exact`
- `Tests/Backup_Recovery/test_restore_plan.py::test_real_older_sqlite_migrates_only_private_candidate`
- `Tests/Backup_Recovery/test_restore_plan.py::test_cancel_after_private_copy_cleans_candidates_without_touching_live_data`
- `Tests/Backup_Recovery/test_installed_restore_validation.py::test_actual_migrated_sqlite_is_revalidated_only_on_disposable_copy`
- `Tests/Backup_Recovery/test_core_owners.py::test_schema_policy_matches_installed_store`

GREEN reruns the RED node plus the new safeguards and those exact controls; lint/format only modified files. Read skip counts and distinguish skipped native qualification from passing coverage. This list is an execution proposal, not proof it passes.

## Scope, cost and limits

Small owner-specific production change, moderate verification cost: table rebuild authorizer details are the difficult part, not catalog selection. Expect one implementation/review cycle if the existing SQLite platform works; budget a second bounded pass if RENAME requires a documented internal callback. Do not estimate runtime from the static source. No new dependencies, migration framework, schema bump, v75 upgrade promise or cross-platform success claim.

Applicable lessons read: testing-evidence “Migration rebases also change exact recovery declarations”; “Recovery tests must cover cleanup after commit”; live-verification “Private config and data paths do not replace a private recovery HOME” and “A schema bump is a one-way door for every OTHER worktree”. Use genuine historical constructors and private HOME/USERPROFILE before application imports; no app launch against real user storage. Static trace establishes the current refusal and missing route coverage, not executable RED/GREEN or exact SQLite authorization callback behavior.
