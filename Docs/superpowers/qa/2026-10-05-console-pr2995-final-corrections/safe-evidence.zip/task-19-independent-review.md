# Task 19 independent review

## Spec Compliance

**✅ Spec compliant.** Reviewed BASE `ef5917842bfd5aab4d3c3678548fe632363c2bed` through HEAD `2aa30feba83e3a215614670debb882ecfba5ecb7`, including both selected extensions. No Critical or Important finding.

- **Ownership and bindings:** `session.py:1186`, `:1219`, `:1259` contain the three selected orchestration methods. `wiring.py:1527` supplies required named state/sibling callbacks; `chat_screen.py:7433` supplies live screen-module teardown, asyncio, awaitability and logger lookups. The moved bodies do not reach through the existing screen argument. The new `is_current` property reads a framework service; new Session imports are type-only (`session.py:299`). Existing store/sync accessors still invoke the screen dynamically (`session.py:1366`, `:1390`; `wiring.py:1594`, `:1630`). No new owner, proxy, runtime reverse import or authority fallback.
- **Lifetime/order:** `session.py:1186` cancels the prior startup only if unfinished and uncancelled, shields its drain, then rechecks current visit, teardown, exact Worker identity and nullable requests. Retirement (`:1219`) stops timers, clears old requests, drains dispatch before startup and clears only the identical startup Worker. Consumption (`:1259`) preserves first-chat → handoff → repair → prompt → optional awaited fleet → typed/local opener → conversation-return → fallback order. Cancellation is re-raised and retains the request; other exceptions propagate. Cleanup compares local ID by equality, typed request by identity and gate owner by Worker identity. The fallback diagnostic remains identical except its live logger receiver.
- **Screen contracts:** genuine synchronous timer dispatch and async bool retirement entry remain (`chat_screen.py:16726`, `:16738`). Nullable state, group names, attach/resume gate, suspension cancellation and permanent-unmount clearing remain screen-owned (`:7250`, `:16555`, `:16831`, `:23353`, `:23491`). The external retirement probe remains callable (`app_destinations.py:773`). Incoming shutdown drains only its three named view groups before runtime disposal (`app_lifecycle.py:545`). Accepted-turn authority remains outside this relocation.
- **Adapters:** the three direct wiring sites add only four required lambdas (`Tests/Chat/test_console_video_actions.py:93`, `Tests/UI/test_console_auto_speak_wiring.py:163`, `Tests/UI/test_console_recovery_live_bindings.py:26`). Direct release/acquisition controls use a real Session and explicit helper (`Tests/UI/test_console_roleplay_resume_navigation.py:756`, `:877`, `:927`). Existing assertions, events and failure behavior remain; unrelated dependencies fail if reached. Whole-owner reversal receipts support the bounded changes.
- **Timer/inventory:** `Tests/UI/test_chat_screen_resume_handoff_registration.py:26` adds only pytest import and canonical bootstrap marker beyond the composed census; both timer branches and feature Session consumers remain. `Docs/security/production-diagnostic-inventory.json:2825` and `:3203` change exactly Session 28→29 / `10357c60a9ad7f2d6ea8`→`943227c3619571ab7f26` and Screen 122→121 / `0fed6b822c37fa27d53a`→`57a9f58f7cb553d34899`. No sink or other row changes appear. AST/JSON reversal receipts agree.
- **Budgets/carry:** independently measured Screen **25202 lines / 759 actual methods**, Session 6508 and wiring 2506. Controller 29299, host 6471, store 22334 and compaction 4185 hashes equal preflight; limits remain 29299/6471/22344/4185. Independently checked all nine final source hashes and **66 exact incoming files**, with only the selected Roleplay adapter excepted from the original 67. The workflow retains upstream third shard, 20-minute cap and fail-fast false (`.github/workflows/derived-artifacts.yml:178`); selected CI receipts cover actual partitioning and required aggregate failure. Root's pinned packet/tree comparisons cover historical QA, ZIP, unowned source and mode/blob preservation. No archival doubt required opening the 34 omitted exact-dev blocks.
- **Governance:** `backlog/decisions/094-console-turn-lifetime-and-navigation-boundary.md:134` explicitly covers Session-owned reusable Resume. Root metadata predates relocation. Incoming lessons and historical source-specific acceptance remain preserved.

## Strengths

The changes preserve physical rollback ownership. Home tests hold actual load/presentation and rollback boundaries, prove restoration of the prior session, retain the exact target and prevent later navigation from cancelling rollback twice (`Tests/UI/test_home_console_resume.py:276`, `:480`). Character supersession waits on genuine retirement. The direct acquisition control retains its exact warning and propagated exception assertions.

## Evidence checked

Evidence names below refer to this review's `task-19-safe-evidence/` directory.

- Read the scoped diff sequentially, restoring output-truncated portions only; reviewed brief/report/preflight, receiver map, reversal/carry proofs, collection, per-run argv/source records, JUnit and static receipts. No test or Git command was rerun; no application/provider/UAT action was performed.
- Parsed retained JUnit: v2 **8 Home + 7 Roleplay PASS, 2 timer setup ERROR**; v3 **25 PASS**; v4 **3 PASS**, exactly the two repaired timer nodes and existing inventory guard. Thus **43 distinct selected cases have passing evidence across recorded source phases**, not a fresh all-at-final-head run. Initial caps remain **1 FAIL / 1 slack PASS**; selected final cap pair passes. Only that explicitly selected slack guard repeats a prior pass.
- Run records retain shared Python 3.12, worktree PYTHONPATH, private profiles, fresh basetemps, `-p no:randomly`, stable-source/closed flags and unchanged 300-second bounds. Collection records exactly 42 cases. Original setup errors retain `raw_source_selection_changed` before either body (`green-v2-merged_resume_timer_census.stdout:76`, `:159`).
- Independently compared all three final method ASTs with frozen declared relocation ASTs using shared Python 3.12. An initial read-only probe used older system Python, whose AST dump omits `type_params=[]`; shared Python resolves this serialization mismatch. It was not a source defect or behavioral test failure.
- `type-only-separator-v3.json:1` bridges the first 15 passes to final Session bytes through one blank line and whole-AST equality. Independently comparing final/baseline Ruff records leaves only the moved BLE001; the introduced I001 is removed. Raw Screen F811 embedded reference shift remains recorded. Fatal Ruff, added-hunk formatter and whitespace receipts pass for source and follow-up overlays.
- `composition-count-label-correction-v4.json:1` correctly distinguishes **836 class-body entries / 761 actual original methods** at 25312 lines. Initial guard failed first on lines and did not reach the method assertion. Final 25202/759 was independently measured.
- Focused checks outside diff addressed three named risks: source/evidence drift (nine hashes, relocated ASTs and incoming/cap hashes); stale existing store/sync receivers (the two Session accessors and exact wiring sites); missing ADR prerequisite (October 5 clarification). Other historical preservation relies on the supplied root verification and pinned receipts; no broader source crawl or archived QA replay.

## Issues

### Critical / Important

None.

### Minor — retained inherited diagnostic noise

`green-v2-merged_resume_timer_census.stdout:81` and `:84` retain optional PyAudio/python-frontmatter warnings. Full Ruff retains inherited debt, including the moved fallback catch (`session.py:1302`). These are disclosed existing diagnostics, not introduced failures. Preserve attribution; do not suppress warnings or expand this task into installs/unrelated cleanup. Evidence supports scoped checks, not a pristine full-lint claim.

## Cannot Verify

- **New-head hosted acceptance and merge:** Qodo, PR Fast Lane, UI1/UI2/UI3, Derived aggregation, actual PerfGuard, fresh remote-dev ancestry and normal protected merge are not established by this local review. Root must complete them after remaining tasks/publication. This is Task 19 approval only.
- **Fresh loading/timing/UAT:** unchanged import/constructor contracts support qualified source carry. No new full startup census, timing, native or human-voice pass is claimed or verified.
- **External process/history state:** recovery ref/bundle, sole-writer handoffs and clean closed-process state are supported by pinned receipts/root verification. This review did not re-enumerate Git/process state or inspect the shared dirty checkout. Historical QA retains original sources and limits.

## Task Quality

**Approved.** The selected relocation preserves behavior through explicit dependencies and meaningful lifecycle evidence. Both bounded extensions restore qualification without weakening admission, assertions, timeouts, caps, diagnostics or external merge gates.
