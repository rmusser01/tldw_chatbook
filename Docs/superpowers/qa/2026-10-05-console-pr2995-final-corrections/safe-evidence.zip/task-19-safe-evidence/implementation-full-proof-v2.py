from pathlib import Path
import ast,copy,json,subprocess,hashlib,difflib
E=Path('.superpowers/sdd/2026-10-03-console-pr2995-review-and-merge/task-19-safe-evidence');BASE='55037a9803c67a3a3d5dd814c74b42da070214e2';params=set(json.loads((E/'relocation-constructor-bindings.json').read_text()));globals={'resume_screen_is_torn_down','read_resume_asyncio','resume_isawaitable','read_resume_logger'};proof={}
def dump(n):return ast.dump(n,include_attributes=False)
def trees(p):return ast.parse(subprocess.check_output(['git','show',BASE+':'+p],text=True)),ast.parse(Path(p).read_text())
def cls(t,name):return next(n for n in t.body if isinstance(n,ast.ClassDef) and n.name==name)
def fn(c,name):return next(n for n in c.body if isinstance(n,(ast.FunctionDef,ast.AsyncFunctionDef)) and n.name==name)
def strip_args(n,names):
 keep=[(a,d) for a,d in zip(n.args.kwonlyargs,n.args.kw_defaults) if a.arg not in names];n.args.kwonlyargs=[a for a,d in keep];n.args.kw_defaults=[d for a,d in keep]
def restore_doc(b,n):n.body[0]=copy.deepcopy(b.body[0])
p='tldw_chatbook/UI/Console_Modules/session.py';b,n=trees(p);bc,nc=cls(b,'ConsoleSessionController'),cls(n,'ConsoleSessionController');new_methods={'settle_and_start_resume_navigation','consume_resume_navigation_startup','retire_resume_navigation_startup','is_current'};nc.body=[x for x in nc.body if not isinstance(x,(ast.FunctionDef,ast.AsyncFunctionDef)) or x.name not in new_methods];bi,ni=fn(bc,'__init__'),fn(nc,'__init__');strip_args(ni,params);restore_doc(bi,ni);ni.body=[x for x in ni.body if not (isinstance(x,ast.Assign) and len(x.targets)==1 and isinstance(x.targets[0],ast.Attribute) and x.targets[0].attr in {'_'+p for p in params})]
for x,y in zip(b.body,n.body):
 if isinstance(x,ast.If) and isinstance(x.test,ast.Name) and x.test.id=='TYPE_CHECKING':y.body=copy.deepcopy(x.body)
assert dump(b)==dump(n);proof['session_whole_ast_reverses_only_selected_imports_signature_doc_bindings_methods']=True
p='tldw_chatbook/UI/Console_Modules/wiring.py';b,n=trees(p);bf,nf=fn(b,'build_console_controllers'),fn(n,'build_console_controllers');strip_args(nf,globals);restore_doc(bf,nf)
for node in ast.walk(nf):
 if isinstance(node,ast.Call) and isinstance(node.func,ast.Name) and node.func.id=='ConsoleSessionController':node.keywords=[x for x in node.keywords if x.arg not in params]
assert dump(b)==dump(n);proof['wiring_whole_ast_reverses_only_selected_signature_doc_constructor_keywords']=True
p='tldw_chatbook/UI/Screens/chat_screen.py';b,n=trees(p);bc,nc=cls(b,'ChatScreen'),cls(n,'ChatScreen');approved={'__init__','_start_resume_navigation_startup','_settle_and_start_resume_navigation','_consume_resume_navigation_startup','_retire_resume_navigation_startup'}
# Filter full ordered body, retaining duplicate property/method declarations.
bc.body=[x for x in bc.body if not isinstance(x,(ast.FunctionDef,ast.AsyncFunctionDef)) or x.name not in approved];nc.body=[x for x in nc.body if not isinstance(x,(ast.FunctionDef,ast.AsyncFunctionDef)) or x.name not in approved];assert dump(b)==dump(n);proof['screen_complete_unrelated_AST_including_duplicate_methods_attributes_exact']=True
p='Tests/UI/test_console_roleplay_resume_navigation.py';b,n=trees(p);n.body=[x for x in n.body if not isinstance(x,ast.FunctionDef) or x.name!='_resume_session'];changed={'test_resume_navigation_continues_after_chat_handoff_release','test_resume_navigation_propagates_logged_chat_handoff_acquisition_failure'}
class ReverseRoleplay(ast.NodeTransformer):
 def visit_Call(self,node):
  if ast.unparse(node.func)=='screen._session.consume_resume_navigation_startup':node.func=ast.parse('screen._consume_resume_navigation_startup',mode='eval').body
  return self.generic_visit(node)
for name in changed:
 bf,nf=fn(b,name),fn(n,name);orig=next(x for x in bf.body if isinstance(x,ast.Assign) and ast.unparse(x.targets[0])=='screen._session');body=[]
 for x in nf.body:
  if isinstance(x,ast.Assign):
   target=ast.unparse(x.targets[0])
   if target=='screen._session':body.append(copy.deepcopy(orig));continue
   if target in {'screen._session._start_character_console_session','screen._session.consume_pending_console_first_chat_intent'}:continue
  body.append(x)
 nf.body=body;ReverseRoleplay().visit(nf)
assert dump(b)==dump(n);proof['roleplay_whole_owner_AST_reverses_only_real_session_adapter_and_two_invocations']=True
# Source ownership carry over BASE, including all tracked QA. Whole blob maps are pinned separately.
changed_paths=subprocess.check_output(['git','diff','--name-only'],text=True).splitlines();proof['only_tracked_overlays']=changed_paths
j=json.loads((E.parent/'task-19-latest-dev-preflight-selection.json').read_text());incoming=[]
for row in j['paths']:
 if row['composition']=='exact_selected_dev':
  p=row['path'];same=hashlib.sha256(Path(p).read_bytes()).hexdigest()==row['sources']['dev']['sha256'];assert same or p=='Tests/UI/test_console_roleplay_resume_navigation.py',p;incoming.append({'path':p,'exact_dev':same,'authorized_adapter':not same})
proof['incoming_nonoverlap']=incoming
caps={}
for p,row in j['caps'].items():
 if 'actual' in row:
  data=Path(p).read_bytes();assert hashlib.sha256(data).hexdigest()==row['sha256'];caps[p]={'lines':len(data.splitlines()),'limit':row['limit'],'exact_preflight':True}
proof['caps']=caps
for root,row in j['qa_carry'].items():
 if root=='original_zip':continue
 a=subprocess.check_output(['git','ls-tree','-r','ef5917842b','--',root]);bmap=subprocess.check_output(['git','ls-tree','-r','HEAD','--',root]);assert a==bmap;proof[root]={'unchanged_paths':len(a.splitlines()),'git_tree_rows_sha256':hashlib.sha256(a).hexdigest()}
z=j['qa_carry']['original_zip'];assert hashlib.sha256(Path(z['path']).read_bytes()).hexdigest()==z['sha256'];proof['zip']={'bytes':Path(z['path']).stat().st_size,'sha256':z['sha256']}
p='backlog/docs/lessons-testing-evidence.md';current=Path(p).read_text().splitlines(True)
for rev in ['ef5917842b','3146bbd8']:
 prior=subprocess.check_output(['git','show',rev+':'+p],text=True).splitlines(True);ops=difflib.SequenceMatcher(a=prior,b=current,autojunk=False).get_opcodes();assert all(tag in {'equal','insert'} for tag,*rest in ops),rev
proof['both_lesson_sources_preserved_as_complete_ordered_subsequences']=True
(E/'full-reversal-and-carry-v2.json').write_text(json.dumps(proof,indent=2));print('Whole-owner reversals and carry pass; incoming66exact+1authorized adapter; caps,QA,ZIP unchanged.')
