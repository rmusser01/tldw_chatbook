from pathlib import Path
import ast,copy,json,hashlib,subprocess,textwrap
R=Path.cwd();E=R/'.superpowers/sdd/2026-10-03-console-pr2995-review-and-merge/task-19-safe-evidence'
assert subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()=='55037a9803c67a3a3d5dd814c74b42da070214e2'
assert not subprocess.check_output(['git','status','--porcelain'],text=True).strip()
frozen=json.loads((E.parent/'task-19-before-wiring-caller-extension-manifest.json').read_text())
assert all(hashlib.sha256((E/p).read_bytes()).hexdigest()==v['sha256'] for p,v in frozen['files'].items())
m=json.loads((E/'receiver-map-before.json').read_text())
params={
'resume_screen_is_torn_down':('Callable[[], bool]','resume_screen_is_torn_down'),
'read_resume_asyncio':('Callable[[], Any]','read_resume_asyncio'),
'resume_isawaitable':('Callable[[Any], bool]','resume_isawaitable'),
'read_resume_logger':('Callable[[], Any]','read_resume_logger'),
'read_resume_startup_worker':('Callable[[], Worker | None]','lambda: screen._resume_navigation_startup_worker'),
'write_resume_startup_worker':('Callable[[Worker | None], None]','lambda worker: setattr(screen, "_resume_navigation_startup_worker", worker)'),
'read_resume_dispatch_worker':('Callable[[], Worker | None]','lambda: screen._resume_navigation_dispatch_worker'),
'read_resume_local_conversation_id':('Callable[[], str | None]','lambda: screen._pending_resume_local_conversation_id'),
'write_resume_local_conversation_id':('Callable[[str | None], None]','lambda target: setattr(screen, "_pending_resume_local_conversation_id", target)'),
'read_resume_character_target':('Callable[[], CharacterConversationActivationRequest | None]','lambda: screen._pending_character_conversation_target'),
'write_resume_character_target':('Callable[[CharacterConversationActivationRequest | None], None]','lambda target: setattr(screen, "_pending_character_conversation_target", target)'),
'write_resume_startup_in_progress':('Callable[[bool], None]','lambda active: setattr(screen, "_resume_navigation_startup_in_progress", active)'),
'read_resume_handoff_timers':('Callable[[], Sequence[Timer]]','lambda: getattr(screen, "_console_resume_handoff_timers", ())'),
'write_resume_handoff_timers':('Callable[[list[Timer]], None]','lambda timers: setattr(screen, "_console_resume_handoff_timers", timers)'),
'consume_resume_chat_handoff':('Callable[..., Any]','lambda **kwargs: screen._consume_pending_chat_handoff(**kwargs)'),
'consume_resume_roleplay_repair':('Callable[[], Any]','lambda: screen._consume_pending_console_roleplay_repair()'),
'consume_resume_prompt_insert':('Callable[[], Any]','lambda: screen._consume_pending_console_prompt_insert()'),
'consume_resume_fleet_completion':('Callable[[], Any]','lambda: screen._fleet.consume_pending_console_fleet_completion()'),
'open_resume_character_target':('Callable[[CharacterConversationActivationRequest], Any]','lambda target: screen._workspace.open_character_navigation_target(target)'),
'open_resume_local_conversation':('Callable[[str], Any]','lambda target: screen._workspace.open_console_workspace_conversation(target)'),
'consume_resume_conversation_return':('Callable[[], Any]','lambda: screen._consume_pending_conversation_resume()'),
'reconcile_resume_session_with_registry':('Callable[[], None]','lambda: screen._workspace._reconcile_console_session_with_registry()'),
}
ops={k:ast.parse(v,mode='eval').body for k,v in m['operations'].items()}
class Move(ast.NodeTransformer):
 def visit_Assign(self,node):
  if len(node.targets)==1 and isinstance(node.targets[0],ast.Attribute) and isinstance(node.targets[0].value,ast.Name) and node.targets[0].value.id=='self' and node.targets[0].attr in m['writes']:
   return ast.Expr(value=ast.Call(func=ast.Attribute(value=ast.Name(id='self',ctx=ast.Load()),attr='_'+m['writes'][node.targets[0].attr],ctx=ast.Load()),args=[self.visit(node.value)],keywords=[]))
  return self.generic_visit(node)
 def visit_Attribute(self,node):
  key=ast.unparse(node)
  if key in ops:return copy.deepcopy(ops[key])
  if isinstance(node.value,ast.Name) and node.value.id=='self' and node.attr in m['reads']:
   return ast.Call(func=ast.Attribute(value=ast.Name(id='self',ctx=ast.Load()),attr='_'+m['reads'][node.attr],ctx=ast.Load()),args=[],keywords=[])
  return self.generic_visit(node)
 def visit_Call(self,node):
  key=ast.unparse(node)
  # ast.unparse chooses single quotes; normalize timer getter independently.
  if isinstance(node.func,ast.Name) and node.func.id=='getattr' and len(node.args)==3 and isinstance(node.args[1],ast.Constant) and node.args[1].value=='_console_resume_handoff_timers':return ast.parse('self._read_resume_handoff_timers()',mode='eval').body
  if key in ops:return copy.deepcopy(ops[key])
  return self.generic_visit(node)
 def visit_Name(self,node):
  if node.id in ops:return copy.deepcopy(ops[node.id])
  return node
screen_path=R/'tldw_chatbook/UI/Screens/chat_screen.py';screen=screen_path.read_text(); tree=ast.parse(screen);cls=next(n for n in tree.body if isinstance(n,ast.ClassDef) and n.name=='ChatScreen');methods={n.name:n for n in cls.body if isinstance(n,(ast.FunctionDef,ast.AsyncFunctionDef))}; moved=[]; expected={}
for name in m['bodies']:
 old=methods[name];new=Move().visit(copy.deepcopy(old));new.name=name.removeprefix('_');ast.fix_missing_locations(new);expected[new.name]=ast.dump(new,include_attributes=False)
 body=ast.unparse(new)
 if 'consume_resume_navigation_startup'==new.name:
  body=body.replace('        cancelled = True\n','        # The opener settles owned hydration before propagating cancellation.\n        # Keep this exact request for the next ordinary visible visit.\n        cancelled = True\n')
 if new.name=='retire_resume_navigation_startup':
  body=body.replace('"""Retire an older request and drain its rollback before a newer choice."""','"""Retire an older request and drain its rollback before a newer choice.\n\n    Returns:\n        Whether an older request or unfinished startup worker was present.\n    """')
 moved.append(textwrap.indent(body,'    ')+'\n')
lines=screen.splitlines(True)
for name in sorted(m['bodies'],key=lambda n:methods[n].lineno,reverse=True):
 n=methods[name]
 replacement=[]
 if name=='_retire_resume_navigation_startup':replacement=['    async def _retire_resume_navigation_startup(self) -> bool:\n','        """Retire an older request and drain its rollback before a newer choice."""\n','        return await self._session.retire_resume_navigation_startup()\n']
 # remove following blank for the two removed methods only
 end=n.end_lineno+(0 if replacement else 1)
 lines[n.lineno-1:end]=replacement
screen=''.join(lines).replace('            self._settle_and_start_resume_navigation(),','            self._session.settle_and_start_resume_navigation(),')
global_bindings={'resume_screen_is_torn_down':'lambda: _console_screen_is_torn_down(self)','read_resume_asyncio':'lambda: asyncio','resume_isawaitable':'lambda result: inspect.isawaitable(result)','read_resume_logger':'lambda: logger'}
needle='            read_trace_recovery_state=lambda: trace_call_recovery_state,\n'
screen=screen.replace(needle,needle+''.join(f'            {k}={v},\n' for k,v in global_bindings.items()),1)
session_path=R/'tldw_chatbook/UI/Console_Modules/session.py';session=session_path.read_text();session=session.replace('if TYPE_CHECKING:\n','if TYPE_CHECKING:\n    from textual.timer import Timer\n    from textual.worker import Worker\n    from ...Chat.console_conversation_activation import (\n        CharacterConversationActivationRequest,\n    )\n',1)
needle='        read_trace_recovery_dispatch: Callable[[], Callable[..., Any]],\n'
session=session.replace(needle,''.join(f'        {k}: {t},\n' for k,(t,v) in params.items())+needle,1)
needle='        self._read_trace_recovery_dispatch = read_trace_recovery_dispatch\n'
session=session.replace(needle,''.join(f'        self._{k} = {k}\n' for k in params)+ '\n'+needle,1)
needle='    # -- Framework services (live-read via `@property`) --------------------\n'
session=session.replace(needle,'\n'.join(moved)+'\n'+needle,1)
needle='    @property\n    def is_attached(self) -> bool:\n'
session=session.replace(needle,'    @property\n    def is_current(self) -> bool:\n        """Read the current framework visit at use time."""\n        return self._screen.is_current\n\n'+needle,1)
needle='        Args:\n            current_chat_controller_accessor:'
docs='''        Resume orchestration keeps its nullable requests, timers and exact Workers
        on the reusable screen visit. Every read/write and sibling operation below
        is a named late-bound callable. The four module callbacks retain the
        screen's live helper, asyncio, awaitability and logger patch routes.
        First-chat consumption, store access and UI sync remain this owner's
        existing operations; no callback grants execution authority.

        Args:
'''
for k in params:
 descriptions={
 'resume_screen_is_torn_down':'Invoke the current screen-module teardown helper.',
 'read_resume_asyncio':'Read the current screen-module asyncio binding.',
 'resume_isawaitable':'Invoke the current screen-module awaitability check.',
 'read_resume_logger':'Read the current screen-module logger binding.',
 'read_resume_startup_worker':'Read the exact nullable visit startup Worker.',
 'write_resume_startup_worker':'Replace the nullable visit startup Worker.',
 'read_resume_dispatch_worker':'Read the exact nullable dispatch Worker.',
 'read_resume_local_conversation_id':'Read the nullable saved conversation request.',
 'write_resume_local_conversation_id':'Replace the nullable saved conversation request.',
 'read_resume_character_target':'Read the exact nullable typed character request.',
 'write_resume_character_target':'Replace the nullable typed character request.',
 'write_resume_startup_in_progress':'Set the visit presentation gate.',
 'read_resume_handoff_timers':'Read the current visit handoff timers.',
 'write_resume_handoff_timers':'Replace the visit handoff timer list.',
 'consume_resume_chat_handoff':'Consume the current chat handoff with release policy.',
 'consume_resume_roleplay_repair':'Consume the current roleplay repair intent.',
 'consume_resume_prompt_insert':'Consume the current pending prompt insertion.',
 'consume_resume_fleet_completion':'Consume a fleet completion; may return an awaitable.',
 'open_resume_character_target':'Open the exact typed character request.',
 'open_resume_local_conversation':'Open the exact saved conversation ID.',
 'consume_resume_conversation_return':'Consume the remaining conversation-return intent.',
 'reconcile_resume_session_with_registry':'Reconcile the fallback with the registry.',
 }
 docs+=f'            {k}: {descriptions[k]}\n'
session=session.replace(needle,docs+'            current_chat_controller_accessor:',1)
wiring_path=R/'tldw_chatbook/UI/Console_Modules/wiring.py';wiring=wiring_path.read_text();needle='    read_trace_recovery_dispatch: Callable[[], Callable[..., Any]],\n';wiring=wiring.replace(needle,''.join(f'    {k}: {params[k][0]},\n' for k in global_bindings)+needle,1)
needle='    screen._session = ConsoleSessionController(\n        screen,\n';wiring=wiring.replace(needle,needle+''.join(f'        {k}={v},\n' for k,(t,v) in params.items()),1)
# Root-selected direct wiring adapters.
for path in json.loads((E/'direct-wiring-extension-proposal.json').read_text())['callers']:
 p=R/path['path'];s=p.read_text();needle='    build_console_controllers(\n        screen,\n';assert s.count(needle)==1
 additions={'resume_screen_is_torn_down':'lambda: chat_screen._console_screen_is_torn_down(screen)','read_resume_asyncio':'lambda: chat_screen.asyncio','resume_isawaitable':'lambda result: chat_screen.inspect.isawaitable(result)','read_resume_logger':'lambda: chat_screen.logger'}
 s=s.replace(needle,needle+''.join(f'        {k}={v},\n' for k,v in additions.items()));p.write_text(s)
# Real, explicitly constructed Session for the two direct __new__ harnesses.
test_path=R/'Tests/UI/test_console_roleplay_resume_navigation.py';test=test_path.read_text();init=next(n for n in ast.parse(session).body if isinstance(n,ast.ClassDef) and n.name=='ConsoleSessionController');init=next(n for n in init.body if isinstance(n,ast.FunctionDef) and n.name=='__init__')
helper='''def _resume_session(screen: ChatScreen) -> session_module.ConsoleSessionController:
    """Wire a real Session; unexpected non-Resume dependencies fail at their call."""
    def unused(*_args: object, **_kwargs: object) -> None:
        raise AssertionError("unexpected non-Resume dependency")

    return session_module.ConsoleSessionController(
        screen,
'''
for arg,default in zip(init.args.kwonlyargs,init.args.kw_defaults):
 k=arg.arg
 if k in params:
  v=params[k][1]
  if k in global_bindings:
   v={'resume_screen_is_torn_down':'lambda: chat_screen_module._console_screen_is_torn_down(screen)','read_resume_asyncio':'lambda: chat_screen_module.asyncio','resume_isawaitable':'lambda result: chat_screen_module.inspect.isawaitable(result)','read_resume_logger':'lambda: chat_screen_module.logger'}[k]
 elif k=='app_instance':v='screen.app_instance'
 elif default is not None:continue
 else:v='unused'
 helper+=f'        {k}={v},\n'
helper+='    )\n\n\n'
needle='@pytest.mark.asyncio\n@private_profile_test\nasync def test_resume_navigation_continues_after_chat_handoff_release('
test=test.replace(needle,helper+needle,1)
test=test.replace('''    screen._session = SimpleNamespace(
        _start_character_console_session=release_handoff,
        consume_pending_console_first_chat_intent=lambda **_kwargs: False,
    )''','''    screen._session = _resume_session(screen)
    screen._session._start_character_console_session = release_handoff
    screen._session.consume_pending_console_first_chat_intent = lambda **_kwargs: False''',1)
test=test.replace('''    screen._session = SimpleNamespace(
        consume_pending_console_first_chat_intent=lambda **_kwargs: False,
    )''','''    screen._session = _resume_session(screen)
    screen._session.consume_pending_console_first_chat_intent = lambda **_kwargs: False''',1)
assert test.count('await screen._consume_resume_navigation_startup()')==2
test=test.replace('await screen._consume_resume_navigation_startup()','await screen._session.consume_resume_navigation_startup()')
for p,s in [(screen_path,screen),(session_path,session),(wiring_path,wiring),(test_path,test)]:ast.parse(s);p.write_text(s)
(E/'relocation-expected-asts.json').write_text(json.dumps(expected,indent=2)+'\n')
(E/'relocation-constructor-bindings.json').write_text(json.dumps(params,indent=2)+'\n')
print('Relocated source; screen lines',len(screen.splitlines()))
