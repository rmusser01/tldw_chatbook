import hashlib,json,os,subprocess,sys,tempfile,time,shutil
from pathlib import Path
ROOT=Path.cwd();E=ROOT/'.superpowers/sdd/2026-10-03-console-pr2995-review-and-merge/task-19-safe-evidence';PYTHON='/Users/macbook-dev/Documents/GitHub/tldw_chatbook/.venv/bin/python'
selection=json.loads((E.parent/'task-19-latest-dev-preflight-selection.json').read_text());extension=json.loads((E/'direct-wiring-extension-proposal.json').read_text())
groups=selection['test_groups']+[{'name':'explicit_direct_wiring_callers','selectors':[x for row in extension['callers'] for x in row['selectors']]}]
mode=sys.argv[1]
groups=groups[3:]  # Only the 25 selected groups not yet executed.
if mode=='collect':groups=[{'name':'all42','selectors':[x for g in groups for x in g['selectors']]}]
for group in groups:
 name=mode+'-v3-'+group['name'];profile=Path(tempfile.mkdtemp(prefix='task19-'+name+'-'));env=os.environ.copy();env['PYTHONPATH']=str(ROOT);env['TLDW_TEST_CONFIG_ROOT']=str(profile/'profile');(profile/'profile').mkdir();env.pop('PYTEST_ADDOPTS',None)
 argv=[PYTHON,'-m','pytest','-p','no:randomly','-q','--basetemp='+str(profile/'basetemp'),'--junitxml='+str(E/(name+'.xml'))]
 if mode=='collect':argv+=['--collect-only']
 argv+=group['selectors'];paths=set(subprocess.check_output(['git','diff','--name-only'],text=True).splitlines())|{x.split('::')[0] for x in group['selectors']};sources={p:hashlib.sha256((ROOT/p).read_bytes()).hexdigest() for p in sorted(paths)}
 start=time.monotonic();receipt={'argv':argv,'cwd':str(ROOT),'profile_root':str(profile),'environment_overrides':{'PYTHONPATH':str(ROOT),'TLDW_TEST_CONFIG_ROOT':env['TLDW_TEST_CONFIG_ROOT']},'timeout_seconds':300,'sources_sha256':sources};assert not (E/(name+'.json')).exists();(E/(name+'.json')).write_text(json.dumps(receipt,indent=2));print('START',name,flush=True)
 try:p=subprocess.run(argv,capture_output=True,text=True,env=env,timeout=300);out,err,code=p.stdout,p.stderr,p.returncode
 except subprocess.TimeoutExpired as exc:out,err,code=exc.stdout or b'',exc.stderr or b'',124
 for suffix,data in [('stdout',out),('stderr',err)]:(E/(name+'.'+suffix)).write_bytes(data.encode() if isinstance(data,str) else data)
 receipt.update(exit=code,elapsed=time.monotonic()-start,closed=True,source_stable=all(hashlib.sha256((ROOT/p).read_bytes()).hexdigest()==h for p,h in sources.items()))
 # Retain actual child reports and logs without exporting private config/DB/profile data.
 child=[]
 for path in sorted((profile/'basetemp').rglob('private-profile-process/pytest.*')):
  if path.suffix not in {'.log','.xml'}:continue
  target=E/(name+'-children')/path.relative_to(profile/'basetemp');target.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(path,target);child.append(str(target.relative_to(E)))
 receipt['child_receipts']=child;(E/(name+'.json')).write_text(json.dumps(receipt,indent=2));print('END',name,code,round(receipt['elapsed'],2),flush=True)
 if code:sys.exit(code)
