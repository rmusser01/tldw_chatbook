from pathlib import Path
import subprocess,json,os,collections,re,time
E=Path('.superpowers/sdd/2026-10-03-console-pr2995-review-and-merge/task-19-safe-evidence');P='/Users/macbook-dev/Documents/GitHub/tldw_chatbook/.venv/bin/python';base='55037a9803c67a3a3d5dd814c74b42da070214e2';paths=subprocess.check_output(['git','diff','--name-only'],text=True).splitlines();receipts=[]
def run(name,argv,input=None):
 start=time.monotonic();p=subprocess.run(argv,input=input,text=True,capture_output=True,timeout=300);(E/(name+'.stdout')).write_text(p.stdout);(E/(name+'.stderr')).write_text(p.stderr);r={'name':name,'argv':argv,'exit':p.returncode,'elapsed':time.monotonic()-start};receipts.append(r);print(name,p.returncode,flush=True);return p
run('source-whitespace-v2',['git','diff','--check'])
run('fatal-ruff-v2',[P,'-m','ruff','check','--no-cache','--select','E9,F63,F7,F82',*paths])
run('formatter-baseline-v2',[P,'scripts/terminal_qualification/format_ratchet.py','snapshot','--base',base,'--output',str(E/'format-baseline-v2.json'),*[a for p in paths for a in ['--path',p]]])
run('formatter-verify-v2',[P,'scripts/terminal_qualification/format_ratchet.py','verify','--baseline',str(E/'format-baseline-v2.json')])
comparison={}
for index,path in enumerate(paths):
 old=subprocess.check_output(['git','show',base+':'+path],text=True);current=Path(path).read_text();results=[]
 for phase,src in [('base',old),('current',current)]:
  argv=[P,'-m','ruff','check','--no-cache','--output-format','json','--stdin-filename',path,'-'];r=run(f'ruff-diagnostics-{index}-{phase}-v2',argv,src);results.append(json.loads(r.stdout))
 def counter(rows,normalize=False):
  return collections.Counter((x['filename'],x['code'],re.sub(r'line \d+','line <location>',x['message']) if normalize and x['code']=='F811' else x['message']) for x in rows)
 a,b=results;comparison[path]={'baseline_count':len(a),'current_count':len(b),'raw_introduced':list((counter(b)-counter(a)).items()),'raw_removed':list((counter(a)-counter(b)).items()),'introduced_after_F811_reference_location_only':list((counter(b,True)-counter(a,True)).items()),'removed_after_F811_reference_location_only':list((counter(a,True)-counter(b,True)).items())}
(E/'checks-v2.json').write_text(json.dumps(receipts,indent=2));(E/'ruff-diagnostic-comparison-v2.json').write_text(json.dumps(comparison,indent=2));print('diagnostic comparison',json.dumps(comparison,indent=2),flush=True)
