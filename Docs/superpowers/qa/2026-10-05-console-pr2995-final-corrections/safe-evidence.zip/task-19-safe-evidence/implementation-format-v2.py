from pathlib import Path
import difflib,subprocess,json,ast
E=Path('.superpowers/sdd/2026-10-03-console-pr2995-review-and-merge/task-19-safe-evidence');P='/Users/macbook-dev/Documents/GitHub/tldw_chatbook/.venv/bin/python';base='55037a9803c67a3a3d5dd814c74b42da070214e2'
p=Path('tldw_chatbook/UI/Console_Modules/wiring.py');s=p.read_text();n='    Args:\n        screen: The Console screen (`ChatScreen`) to wire.';s=s.replace(n,'''    Args:
        resume_screen_is_torn_down: Invoke the live screen-module teardown helper.
        read_resume_asyncio: Read the live screen-module asyncio binding.
        resume_isawaitable: Invoke the live screen-module awaitability check.
        read_resume_logger: Read the live screen-module logger binding.
        screen: The Console screen (`ChatScreen`) to wire.''',1);p.write_text(s)
paths=subprocess.check_output(['git','diff','--name-only'],text=True).splitlines();records=[]
for path in paths:
 p=Path(path);old=subprocess.check_output(['git','show',base+':'+path],text=True).splitlines(True);src=p.read_text();before=ast.dump(ast.parse(src));original=src
 for iteration in range(3):
  lines=src.splitlines(True);changed=[(c,d) for tag,a,b,c,d in difflib.SequenceMatcher(a=old,b=lines,autojunk=False).get_opcodes() if tag!='equal'];argv=[P,'-m','ruff','format','--no-cache','--stdin-filename',path,'-'];r=subprocess.run(argv,input=src,text=True,capture_output=True);assert r.returncode==0,r.stderr;formatted=r.stdout.splitlines(True)
  operations=[(a,b,c,d) for tag,a,b,c,d in difflib.SequenceMatcher(a=lines,b=formatted,autojunk=False).get_opcodes() if tag!='equal' and any(a<=y and b>=x for x,y in changed)]
  records.append({'path':path,'iteration':iteration,'argv':argv,'stdout_formatted_lines':len(formatted),'stderr':r.stderr,'exit':r.returncode,'applied_hunks':operations})
  if not operations:break
  for a,b,c,d in reversed(operations):lines[a:b]=formatted[c:d]
  src=''.join(lines)
 assert ast.dump(ast.parse(src))==before,path
 p.write_text(src)
(E/'scoped-format-operations.json').write_text(json.dumps(records,indent=2))
print([(p,len(Path(p).read_text().splitlines())) for p in paths])
