import ast,copy,json,subprocess,hashlib
from pathlib import Path
E=Path('.superpowers/sdd/2026-10-03-console-pr2995-review-and-merge/task-19-safe-evidence');base='55037a9803c67a3a3d5dd814c74b42da070214e2';proof={}
def old(p):return subprocess.check_output(['git','show',base+':'+p],text=True)
def methods(s,c):return {n.name:n for n in next(n for n in ast.parse(s).body if isinstance(n,ast.ClassDef) and n.name==c).body if isinstance(n,(ast.FunctionDef,ast.AsyncFunctionDef))}
def dump(n):return ast.dump(n,include_attributes=False)
def nodoc(n):
 n=copy.deepcopy(n)
 if n.body and isinstance(n.body[0],ast.Expr) and isinstance(n.body[0].value,ast.Constant) and isinstance(n.body[0].value.value,str):n.body=n.body[1:]
 return n
p='tldw_chatbook/UI/Console_Modules/session.py';actual=methods(Path(p).read_text(),'ConsoleSessionController');expected=json.loads((E/'relocation-expected-asts.json').read_text())
for name,exp in expected.items():
 # Expected serialized AST includes only the original one-line docstring.
 obj=copy.deepcopy(actual[name]);obj.body[0].value.value={'settle_and_start_resume_navigation':"Start one visible request after the prior visit's rollback settles.",'retire_resume_navigation_startup':"Retire an older request and drain its rollback before a newer choice.",'consume_resume_navigation_startup':"Consume older Console intents before the explicit resume target."}[name]
 assert dump(obj)==exp,name
proof['three_moved_executable_asts_match_declared_map']=True
before=methods(old(p),'ConsoleSessionController');assert all(dump(n)==dump(actual[k]) for k,n in before.items() if k!='__init__');proof['all_existing_session_methods_except_constructor_exact']=len(before)-1
p='tldw_chatbook/UI/Screens/chat_screen.py';before=methods(old(p),'ChatScreen');after=methods(Path(p).read_text(),'ChatScreen');approved={'__init__','_start_resume_navigation_startup','_settle_and_start_resume_navigation','_consume_resume_navigation_startup','_retire_resume_navigation_startup'};assert all(dump(n)==dump(after[k]) for k,n in before.items() if k not in approved);proof['all_unrelated_screen_methods_exact']=len(before)-len(approved)
# Complete three direct caller owners reverse by deleting only the four selected keywords.
globals_names={'resume_screen_is_torn_down','read_resume_asyncio','resume_isawaitable','read_resume_logger'}
class ReverseGlobals(ast.NodeTransformer):
 def visit_Call(self,n):
  if isinstance(n.func,ast.Name) and n.func.id=='build_console_controllers':n.keywords=[k for k in n.keywords if k.arg not in globals_names]
  return self.generic_visit(n)
for row in json.loads((E/'direct-wiring-extension-proposal.json').read_text())['callers']:
 p=row['path'];assert dump(ReverseGlobals().visit(ast.parse(Path(p).read_text())))==dump(ast.parse(old(p))),p
proof['three_direct_wiring_whole_owner_ast_reversals']=True
p='Tests/UI/test_console_roleplay_resume_navigation.py';b=ast.parse(old(p));n=ast.parse(Path(p).read_text());original={x.name:x for x in b.body if isinstance(x,(ast.FunctionDef,ast.AsyncFunctionDef))};new={x.name:x for x in n.body if isinstance(x,(ast.FunctionDef,ast.AsyncFunctionDef))};changed={'test_resume_navigation_continues_after_chat_handoff_release','test_resume_navigation_propagates_logged_chat_handoff_acquisition_failure'}
for name,x in original.items():
 if name not in changed:assert dump(x)==dump(new[name]),name
 else:
  assert [dump(a) for a in ast.walk(x) if isinstance(a,ast.Assert)]==[dump(a) for a in ast.walk(new[name]) if isinstance(a,ast.Assert)],name
  assert [dump(a) for a in x.decorator_list]==[dump(a) for a in new[name].decorator_list]
proof['all_unrelated_roleplay_functions_exact']=len(original)-2;proof['direct_roleplay_assertions_markers_exact']=True
# Record literal absence of runtime imports, annotations and precise caps.
for p in ['tldw_chatbook/UI/Screens/chat_screen.py','tldw_chatbook/UI/Console_Modules/session.py','tldw_chatbook/UI/Console_Modules/wiring.py']:
 b=ast.parse(old(p));n=ast.parse(Path(p).read_text());assert [dump(x) for x in b.body if isinstance(x,(ast.Import,ast.ImportFrom))]==[dump(x) for x in n.body if isinstance(x,(ast.Import,ast.ImportFrom))],p
proof['top_level_runtime_imports_exact']=True
s=Path('tldw_chatbook/UI/Screens/chat_screen.py').read_text();c=next(n for n in ast.parse(s).body if isinstance(n,ast.ClassDef) and n.name=='ChatScreen');proof['screen']={'lines':len(s.splitlines()),'methods':sum(isinstance(x,(ast.FunctionDef,ast.AsyncFunctionDef)) for x in c.body)};assert proof['screen']['lines']<=25218 and proof['screen']['methods']==759
proof['source_hashes']={p:hashlib.sha256(Path(p).read_bytes()).hexdigest() for p in subprocess.check_output(['git','diff','--name-only'],text=True).splitlines()}
(E/'stable-ast-and-cap-proof.json').write_text(json.dumps(proof,indent=2));print(json.dumps({k:v for k,v in proof.items() if k!='source_hashes'},indent=2))
