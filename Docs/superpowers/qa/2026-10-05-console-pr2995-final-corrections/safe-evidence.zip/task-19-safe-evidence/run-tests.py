import hashlib,json,os,subprocess,sys,tempfile,time
from pathlib import Path
ROOT=Path.cwd(); E=ROOT/'.superpowers/sdd/2026-10-03-console-pr2995-review-and-merge/task-19-safe-evidence'
PYTHON='/Users/macbook-dev/Documents/GitHub/tldw_chatbook/.venv/bin/python'
selection=json.loads((E.parent/'task-19-latest-dev-preflight-selection.json').read_text())
phase=sys.argv[1]
groups=selection['test_groups'][-1:] if phase=='red-caps' else selection['test_groups']
for group in groups:
 name=phase+'-'+group['name']; profile=Path(tempfile.mkdtemp(prefix='task19-'+name+'-')); env=os.environ.copy();env['PYTHONPATH']=str(ROOT);env['TLDW_TEST_CONFIG_ROOT']=str(profile/'profile');(profile/'profile').mkdir();env.pop('PYTEST_ADDOPTS',None)
 argv=[PYTHON,'-m','pytest','-p','no:randomly','-q','--basetemp='+str(profile/'basetemp'),'--junitxml='+str(E/(name+'.xml')),*group['selectors']]
 sources={str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in [ROOT/'tldw_chatbook/UI/Screens/chat_screen.py',ROOT/'tldw_chatbook/UI/Console_Modules/session.py',ROOT/'tldw_chatbook/UI/Console_Modules/wiring.py',*[ROOT/x.split('::')[0] for x in group['selectors']]]}
 start=time.monotonic(); receipt={'argv':argv,'cwd':str(ROOT),'profile_root':str(profile),'environment_overrides':{'PYTHONPATH':str(ROOT),'TLDW_TEST_CONFIG_ROOT':env['TLDW_TEST_CONFIG_ROOT']},'timeout_seconds':300,'sources_sha256':sources}; (E/(name+'.json')).write_text(json.dumps(receipt,indent=2))
 try:
  p=subprocess.run(argv,capture_output=True,text=True,env=env,timeout=300);out,err,code=p.stdout,p.stderr,p.returncode
 except subprocess.TimeoutExpired as exc:out,err,code=exc.stdout or b'',exc.stderr or b'',124
 for suffix,data in [('stdout',out),('stderr',err)]: (E/(name+'.'+suffix)).write_bytes(data.encode() if isinstance(data,str) else data)
 receipt.update(exit=code,elapsed=time.monotonic()-start,closed=True,source_stable=all(hashlib.sha256(Path(p).read_bytes()).hexdigest()==h for p,h in sources.items()));(E/(name+'.json')).write_text(json.dumps(receipt,indent=2));print(name,code,round(receipt['elapsed'],2),flush=True)
 if code and phase!='red-caps':sys.exit(code)
