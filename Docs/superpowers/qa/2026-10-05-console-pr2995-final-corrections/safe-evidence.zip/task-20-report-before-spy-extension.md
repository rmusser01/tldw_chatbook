# Task 20 — shipped-v76 recovery checkpoint

Status: NEEDS_CONTEXT. The production fix and owned tests are implemented; one unchanged, preflight-selected publication control requires root to track an additional test-owner extension before completion. No source outside the three authorized owners was edited.

Base: `c37f73fb158215281231bf16d7c3396e70f30b73`. ADR required: yes, existing ADR219 October5 amendment, already tracked at base; ADR126/208 govern. No catalog, SQL artifact, public SchemaPolicy, owner registry, staging/publication production, runtime constructor, Subscription or budget change.

## Implementation and authority

The common restricted validator qualifies the complete primary76 catalog after the existing full check. Native76 retains the registered stamp-only step. Exact shipped76 executes the authoritative installed migration file with SQLite complete-statement accumulation on the same restricted connection and transaction, followed by the registered stamp and existing exact77/integrity/domain check. V75 staged migration remains refused.

The temporary scope admits only measured checkpoint create/copy/drop/rename/index objects and necessary catalog callbacks, requiring shipped qualification, active primary migration, expected database and no trigger source. The primary branch denies before unrelated generic migration allowances. A second flag covers exactly the installed ALTER statement: sqlite_sequence.name, temp-catalog rewrite and sqlite_rename_table authority are absent for other statements. Actual appended sequence-row UPDATE, messages UPDATE, unrelated CREATE, final-table INSERT and random() calls are denied after the script reaches its final index. Both flags reset in finally; existing cancellation-safe rollback remains.

SQLite3.49.1 measurement completed all six installed statements with trusted_schema OFF and no Canvas scope/UDF. No extra trust was added. The initial diagnostic expected Canvas failure and failed its own assertion *after six successful statements*; this was an incorrect probe assumption, not migration failure or green test evidence. Original source/output remain; corrected callbacks-v2 exits0. This establishes the observed platform only.

Installed SQL SHA256: `423978f7c23189e36ce4c5172cfd6d2b887abcc1f6abc057f86f61e55ca17fa8`, unchanged.

## Exact evidence phases

Shared Python, WT PYTHONPATH, private HOME/USERPROFILE/config/data before app imports, canonical test bootstrap, fresh basetemps, -p no:randomly, unchanged300s bound. Each receipt retains argv/environment/source SHA256/stdout/stderr/JUnit/exit/stability/closure. all-test-outcomes.json lists actual parameter IDs; run-source-map.json binds each phase to exact retained source bytes. No install, full sweep, new skip, warning suppression, limit change, security bypass or old passing-cohort replay.

| Receipt | Actual result / reached phase |
| --- | --- |
| red-archive | 2FAIL,2.51s pytest: both genuine historical variants passed migrate=False then reached actual stage_restore unsupported_schema_migration before production edits. |
| callbacks | Diagnostic exit1: incorrect anticipated-UDF assertion after six successful statements. |
| callbacks-v2 | Diagnostic exit0: six statements without extra trust/UDF. |
| green-owned-v1 | 28PASS/3FAIL,22.02s: full native compatibility owner plus archives. Archives advanced to producer_inventory_required; undefined witness function failed preparation before callback assertion. |
| green-shipped-v2 | 11PASS/2FAIL,10.42s: shipped safeguards pass with ALTER-only authority; archives reached dependency validation and refused the fixture's noncanonical logical ID. |
| green-archive-v3 | 2FAIL,3.62s: staging, exact77 and receipt/message checks passed; SQL-text index comparison failed on installed two-space→four-space indentation. |
| green-archive-v4 | 2PASS,3.09s: index_list/index_xinfo semantics, FK, every predecessor field/message, NULL machine IDs, original DB and both archive bytes, and absent live destination all pass. |
| green-controls | 34PASS/1FAIL,9.10s: exact13 preflight selectors expand to35 cases; only the unchanged publication spy keyword mismatch fails. |
| fatal-ruff | E9,F63,F7,F82 exit0 on three owners. |
| formatter / whitespace | Changed hunks only; whole-file AST preserved for all three owners; final changed-hunk formatter ratchet zero operations; diff --check exit0. |

The new archive fixture now uses existing producer metadata, a synthetic container and canonical profile:profile:db.chachanotes.primary ID. No production gate was bypassed. Index metadata replaces a whitespace-sensitive assertion; production full-catalog equality stays exact. The installed-file witness uses random() plus an identifying comment because undefined UDFs fail before authorizer callbacks. Every original failure and actual reached phase is retained.

The19 native/v75/hybrid/Subscription passes carry from green-owned-v1 through exact original-test AST comparison and a validator comparison excluding only new shipped-only blocks/helper plus the default-false rename field. No native rerun occurred. The11 shipped safeguards carry after formatting and a read-only fixture index inspection adjustment; two archive passes qualify the final fixture.66 distinct selected cases have successful evidence across these phases, with one selected control outstanding. This is not a blanket28PASS-on-final-bytes claim.

No pytest warning summary or skip occurred. Optional-dependency warnings including PyAudio remain in raw failed-run logs. A filtered process check confirms no owned subprocess remains; the initial sandbox-denied process read did not establish closure. An evidence script initially used an incorrect controller path; the corrected path proves exact Task19 controller bytes. A reconstructed RED snapshot had one surplus trailing newline; the additive exact copy matches the original run's unchanged hash. Both corrections are recorded without changing test results.

## Outstanding selected control

The unchanged checked(owner,path,*,writable) spy in test_installed_restore_validation.py::test_actual_migrated_sqlite_is_revalidated_only_on_disposable_copy rejects with_restrictions=True/cancel=cancel before entering its body. The unchanged common validator catches TypeError as sqlite_validation_unavailable. Exact BASE/current spy bytes and validator-call AST equality are frozen in installed-control-proposal.json. Root independently confirmed the argument-binding mismatch; no baseline replay is selected.

Root selected a narrow future correction: add with_restrictions=False/cancel=None to that spy and forward both, retaining every original path/writable assertion and body step, then rerun only this failed node. Root must track the extra owner before same-agent continuation. This checkpoint does not edit it or mark Task20 complete.

## Carry and self-review

Only the validator and two selected test owners differ from base. Original test functions remain exact by AST except removal of the shipped76 refusal parameter; v75 remains. Entire Task19 Screen/Session/wiring/controller source and caps, all unowned/upstream paths, SQL/catalog/registry/public policy and historical QA blobs are unchanged. checkpoint-source.json records the complete QA blob map and key source hashes; base-tree.stdout retains the complete tracked tree. Shared dirty checkout was not edited.

Self-review inspected all three diffs, fixed names, installed-policy equality, fail-closed full-catalog qualification, same-transaction execution, reached-phase evidence and cleanup. Late-index denial follows rename and first-index REINDEX; final-failure/cancel controls observe validated77 and two rebuilt rows before rollback. Complete old dump and source bytes are preserved. Malformed trigger/index catalogs refuse before migration callbacks. No remaining production concern found; the outstanding spy and independent source-specific spec/quality review prevent completion.

No new generalized lesson: canonical fixture qualification and reached-phase evidence are already covered by existing testing lessons. No rebase, push, external comment, publication, arming or merge occurred; root retains these actions.

Checkpoint commit: `18fb6b62675927336b17150dfef499bc6b0bf2ff`. Exactly three owned source/test files committed. Source/index clean; all owned processes closed. Sole-writer ownership returns to root for the tracked spy extension. Status remains NEEDS_CONTEXT.
