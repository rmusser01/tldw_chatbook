# Task19 latest-dev Buddy/Resume integration preflight

**Verdict: source composition is bounded, but an unchanged-cap integration needs a Session-owned Resume relocation.** Head `76bce76345f20743d309d44b82f5d45d93c58801`; reviewed dev ancestor `8c4dfe59a243ce0cec8e131aff3935646c64b298`; fetched new dev `3146bbd8da2f30eaa97d72bd0ab860de4c40de75` (PR3011). This report proposes scope for root selection. No implementation, rebase, checkout, index/HEAD/source mutation, Git-object creation, tests/collection, dependency install, provider/audio/UAT run, child or sibling SDD access occurred. Temporary sketches are under `/private/tmp/pr2995-task19-preflight`; these reports are the only own-SDD writes.

Read the plan Global Constraints, source Task17 preflight/selection, Task18 final ownership notes, new lesson deltas, design language and DESIGN §7. Read incoming TASK32108.1–.6 and relevant existing ADR094/139/147/097/103; incoming task notes retain their own prior-source test/UAT limits. The config loader omission, cold metadata validation, visit suspension/rollback, lifecycle drain and three-shard matrix are actual incoming changes; no new schema, provider, dependency or execution authority is introduced.

## Complete incoming map and actual overlaps

`task-19-latest-dev-preflight-selection.json` pins all70 paths with base/head/dev Git blobs, SHA256, byte/line counts, incoming changed declaration hashes and candidate source ownership. **67 take exact selected-dev bytes.** Only three overlap feature work:

1. `tldw_chatbook/UI/Screens/chat_screen.py`: clean `git merge-file -p` sketch. Incoming adds120 net lines and two methods; its10 altered/new class method bodies and `_console_screen_is_torn_down` compose. The only same-method intersections are `_start_console_view_after_reconciliation` and `on_screen_resume`: retain the feature's Session-owned vLLM + llamacpp consumer callbacks alongside the incoming tracked ordered-Resume timer branches. Neither overlap substitutes the other. All other incoming changed methods and the teardown helper are AST-exact in the sketch. Class annotations add `Worker | None` for both retained view workers.
2. `Tests/UI/test_chat_screen_resume_handoff_registration.py`: clean sketch. Preserve feature `self._session.consume_pending_vllm_console_intent` and `self._session.consume_pending_llamacpp_console_intent`, plus incoming `self._start_resume_navigation_startup` expected callback and `re.findall` collecting both timer lists. No shared changed function; the expected set is composed.
3. `backlog/docs/lessons-testing-evidence.md`: one textual append conflict at the end. Preserve all existing feature lessons (Stop geometry/empty-draft persistence, validated cleanup, postcommit registry cleanup, storage outside registry locks, live Close witness) and both incoming final entries (timer/rollback worker ownership and F811 embedded source locations). The earlier incoming realtime backing-store and accepted-UAT entries merge cleanly. The conflicted temporary sketch is marked merge_exit1 and is not a valid final document. No historical lesson paragraph should be rewritten.

The eight incoming production paths outside screen include guarded saved Buddy metadata, Home copy, inert deferred scroll after modal close, character-postcommit Resume retirement, app view-worker draining, lazy motion parser use and copied `buddy_interaction` config projection. Preserve all incoming test/profile/teardown/loopback corrections. Historical UAT screenshots/receipts are dev-owned evidence, not a current PR2995 UAT claim.

The JSON also pins146 protected feature/test/script/guard owners at HEAD. All protected production files outside screen remain untouched by incoming dev, including native/automatic start, runtime, controller/store, interrupt, compaction, durable ledger, Session first-chat/trace recovery, prompt queue, hooks and typed-answer seams. JSON identifies the only two protected path intersections: screen and timer-census test.

## Fixed-cap consequence and smallest coherent repair

| Actual owner | Current/incoming composed size | Fixed cap | Consequence |
| --- | ---: | ---: | --- |
| ChatScreen |25312lines /761methods|25218 /759|94lines +2methods over |
| Console controller |29299|29299|exact head carry |
| Interrupt host |6471|6471|exact head carry |
| Store |22334|22344|10lines headroom, exact carry |
| Compaction |4185|4185|exact head carry |

These are source/AST measurements, not executed guard results. Task18's reviewed controller/host shrink must remain29299/6471. Neither a raised ceiling nor an unrelated deletion is justified.

The minimum **coherent existing owner** is `ConsoleSessionController` in `UI/Console_Modules/session.py`, which already owns native session activation, first-chat handoff and session lifecycle. Move the bodies of:

- `_settle_and_start_resume_navigation` (28lines): prior visit cancellation/drain and exact request/Worker fences.
- `_consume_resume_navigation_startup` (56lines): first-chat/handoff/repair/prompt/fleet consumption, exact local/character opener and fallback.
- `_retire_resume_navigation_startup` (31lines): old request/timer/dispatch/startup retirement and shielded rollback drain.

Retain two genuine screen entry points: synchronous `_start_resume_navigation_startup` schedules `self._session.settle_and_start_resume_navigation()` in the existing `console-resume-navigation-dispatch` group; async `_retire_resume_navigation_startup` delegates to Session for the existing external character-postcommit probe. Remove the two class methods `settle` and `consume`; do not re-export them with aliases/properties/dynamic binding. The screen-only sketch after those exact moves and a3line retirement delegation measures **25198lines /759methods**,20lines headroom. The sketch is not a complete implementation: final named dependencies/docs may change its exact count, which must be remeasured. Wiring lives in existing `wiring.py`, so constructor bindings need no extra screen methods.

Keep incoming screen navigation fields, timers, suspend/unmount and attach/resume gate hooks where they are. Their lifetime is the reused screen visit; relocate the orchestration into Session using **explicit named keyword-only late-binding constructor callables**, following the actual DESIGN contract. Do not add an opaque screen surrogate, callback namespace, `getattr` fallback routing, a new controller, or a controller→ChatScreen runtime import. Reuse Session's existing `_ensure_console_chat_store`, `_sync_native_console_chat_ui` and own first-chat consumer. New sibling bindings must explicitly name chat handoff, roleplay repair, prompt insertion, fleet completion, saved/typed opener, conversation-resume continuation and registry reconcile. Screen-state dependencies must explicitly name the nullable local/typed request and exact Worker getters/writers, gate writer, timer read/clear and request clearing; no authority can be inferred from an absent callback. Framework `run_worker`/`is_current` may live-read through documented framework properties.

## Caller, patch, annotation and exception compatibility census

Complete incoming `git grep` finds:

- `_start_resume_navigation_startup`: two production timer callbacks (cold mount and reused resume); timer census expects its screen name; Roleplay mounted timer ordering expects its callback name; Home shutdown calls it; queued-character test intercepts `set_timer` by that name. Keep the name and synchronous entry semantics exactly.
- `_settle_and_start_resume_navigation`: only screen start's production call. No direct test/unbound/patch consumer. Retarget once to Session.
- `_retire_resume_navigation_startup`: only `app_destinations.py::_complete_character_conversation_post_commit` probes the screen with `getattr`; Home held-rollback character case reads and monkeypatches that bound screen method. Retain the real async screen entry and exact bool result. No other production caller or unbound consumer.
- `_consume_resume_navigation_startup`: only settle's production call; two direct test callers at incoming Roleplay lines801/850. These use `ChatScreen.__new__` and substitute `_session` with a SimpleNamespace; they are the only fixture compatibility edits needed. Route them to a real Session owner with explicit test dependencies, retaining every event, failure propagation, final request/gate, original marker, log and opener assertion. Do not add a general screen alias to satisfy these two old harnesses.
- Worker fields: read in screen suspend; startup field inspected by Home held rollback; both declared `Worker | None = None`, read in settlement/retirement/consumption. Keep screen fields and these genuine lifetime observations. No other consumer, unbound call, monkeypatch or reflective lookup exists.
- Local request: `str | None`; character request: postponed `CharacterConversationActivationRequest | None`; gate:bool. None continues to mean no request/Worker. Typed request clearing uses object identity; local target uses exact saved-ID equality. Exact current Worker identity fences gate clearing; an older cancelled worker cannot lower a newer gate or erase a newer request.

Cancel only once (`not is_finished and not is_cancelled`); `asyncio.shield(gather(wait(), return_exceptions=True))` drains rollback without a second cancellation. Suspension cancels the two view groups, retains the request; permanent unmount clears it. The consumed cancellation catch re-raises `CancelledError`, retains exact request, and clears only its exact worker's gate in finally. Other handoff acquisition exceptions propagate and retain the original safe warning/cleanup behavior. `inspect.isawaitable` fleet handling stays intact; no fake coroutine expectation. An opened target returns directly; missing target falls back to existing store/registry/sync only when there is no active session. No blanket error catch, new timeout or different return/nullability is proposed.

The late-binding proof already exists in the selected mounted first-chat tests: they replace handoff/fleet/opener/sync behavior after construction and assert the ordered event sequence/final focus with no intermediate presentation. The two direct release/acquisition controls retain exact exception/cleanup assertions. Compare moved executable AST after only the declared dependency-receiver retargets; then qualify these specific mounted and direct controls. New explicit named state bindings may warrant one small focused nullable/late-replacement check in the existing owner if the writer finds a gap; root must admit its exact new ID before execution. No permissive mock or count-only alias is acceptable.

## Canonical ADR clarification before source work

ADR required: existing canonical clarification; no new schema/service/provider decision.
ADR path: `backlog/decisions/094-console-turn-lifetime-and-navigation-boundary.md` (amend, linking ADR139/147 and existing ADR219/220).

Record that visit-owned saved/character Resume hydration and its rollback settlement are Session-controller orchestration behind genuine screen timer/retirement hooks on the **existing reusable Console route** (ADR139). Leaving the visit cancels this navigation presentation; rollback drains before retry or a newer character commit; permanent unmount clears the request. Accepted ordinary/Buddy/automatic turns remain app-runtime custody and do not move to Session or the screen. This clarifies ADR094's older fresh-disposable-view wording against ADR139's actual reused route, without reopening its accepted-execution boundary. ADR147 still owns exact persisted identity and handoff supersession. Shutdown drains only named view groups before existing runtime disposal; `_exit=True` closes existing Textual mount admission. Link the clarification from the root Backlog plan/notes before relocating source.

## Proposed exact qualification and source carry

JSON proposes **33 exact node IDs /33 source-derived cases**, pending root scope selection and actual bounded collection:

- 8 real Home cases: cold/reused identity+independent drafts, held shutdown, load/presentation suspension, queued newer character, and both held-rollback successors.
- 7 Roleplay cases: first-chat defer/release ordering, ordinary/no-resume and global Resume, permanent unmount, two direct release/acquisition compatibility cases.
- 2 exact merged timer census cases.
- 3 Buddy cases: both controlled native streaming durable-draft sends and the deferred closed-scroll callback.
- 5 real TOML/motion cases: conversation/workspace copied binding, static, malformed zero and global override.
- 2 cold metadata cases: positive no-execution construction and repurposed-slot refusal.
- 1 queued actual-child-removal shutdown regression.
- 3 CI cases: serial minimal-dependency lane, exact real3shard census/order coverage, required aggregate failure.
- 2 unchanged screen size/slack cases, before/after relocation as root admits.

No full incoming owner, native/automatic start suite, prior command22case selection, realtime181case cohort, older58/35/61/27/58 or Task18 53case replay is proposed. The two controlled Buddy cases provide the specific incoming native send seam coverage; all other unchanged native/automatic/Close/interrupt/decision ownership carries by source hashes and original receipts. No audio/provider/human UAT needs repeating. Incoming loopback/profile/teardown test corrections carry upstream exactly; the actual changed lifecycle shutdown is exercised by the held Home and queued rebuild cases.

No loading node is proposed. The only new module-scope name is `Worker` from Textual's already-loaded worker module; `parse_preferences` imports the stdlib-only interaction leaf inside the existing first-use Buddy constructor. Session already resides in the app/Chat baseline; the relocation adds no module or construction-time execution. Route/CSS sources and startup guard budgets carry exactly: ready1033, preimport557/425347/135111, app686 and CSS608090. The pinned preimport marginal route map bills Home's2line shrink and does not bill already-baseline screen/session. Full final constructor/type-import closure remains unmeasured; if the writer adds a genuine eager import, root must select the affected bounded loading guard before running it. No current timing/module-census pass is claimed.

The incoming workflow changes only `[1, 2]`→`[1, 2, 3]`. Keep20minute limit, `fail-fast:false`, minimal installed dependencies, ordered serial census subsequences, job-index/job-total-driven real shard selection, nonempty refusal and `needs` aggregation. A failed/timed-out/cancelled shard cannot become a successful UI lane; required stable `Derived artifacts reproduce from their sources` must enforce both lane results. Latest-dev strict-base external gating remains root's responsibility; this source preflight does not certify live branch protection or hosted checks.

Use the shared Python3.12, worktree PYTHONPATH, canonical private_profile_test/bootstrap profiles and original300s timeout. Preserve incoming assertions/markers and Task18 existing adapters, warnings and all current cap assertions. No new skip/XFAIL, warning suppression, profile bypass, unrelated formatting or changed expected behavior is authorized. Source/lint diagnostic comparisons must keep same filenames and multiplicity; preserve any embedded F811 line-reference difference explicitly, as incoming lesson requires.

## Historical evidence and final read-only receipt

Incoming70paths intersect no existing QA path. Verified current tracked QA maps: original review354paths and latest-dev632paths; JSON pins their exact path/blob-map hashes. Original qualification ZIP is directly hashed at63166118bytes, SHA256 `acecbdfb6ddbafe6df679c39f9f137f2bfb49a1f87b62556e1345021f8384c84`; no decompression/regeneration. Original527 and subsequent158 publications, earlier phase counts, failed/green attempts, native/live limits and warnings remain source-specific history. Do not relabel them as new HEAD passes, update their manifests or retarget receipts. The JSON maps protected source owners compactly rather than copying historical logs.

Final HEAD remains `76bce76345f20743d309d44b82f5d45d93c58801`, index SHA256 `c6c7ccde4ab10aecb22d28c5ef9b10e898911b46b3ac407a21aa9d778141c519`, clean porcelain. Root must select/record this cap/ADR/compatibility scope before the sole writer integrates. Outstanding uncertainty is the final explicit Session binding design/size and fresh composed behavior evidence; the clean merge alone is insufficient.
