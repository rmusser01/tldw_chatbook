# Task21 initial setup handoff

Status: NEEDS_CONTEXT. No production edits or commit. All tracked files restored exactly to BASE `3c5dd77a15290f4c9f7d66b4c7cf19d804d20b3d`; source/index/HEAD clean. All preexisting own-SDD artifacts except root-owned `progress.md` match the baseline hashes.

## Requirement and implementation scope

Read Task21 brief, origin preflight, admission risk, implementer prompt, applicable AGENTS.md, Console wiring lessons and relevant testing/live-profile lessons. ADR219 October5 authorship clarification is tracked and supplies the valid machine user-wire contract. Intended production scope remains shared typed metadata labels and pure USER+untrusted disclosure, both export adapters, saved-note speaker branch, and lightweight retained-final-text seam after admission. No production, caps, SQL, UI, constructors, dependencies or parser changed.

## Actual RED evidence

Exact argv/env/source pins, 300s bound, stdout/stderr/JUnit, exit and loaded source closure are in `task-21-safe-evidence/red.*`. Same five proposed node IDs executed in one source-stable process using Python3.12 and the canonical private HOME/USERPROFILE/XDG/config/data selection. Exit1, 5 failed, 2.68s pytest / 4.76s process. All actual product modules came from the worktree; no pytest warnings recorded. Four export failures reached the intended exact heading mismatch: `## Agent handoff` expected, `## User` actual. These also compare Unverified handoff and verbatim text/fidelity in the golden document.

The SQLite node reached the real database writes and `_resume_into_store` but failed before its provenance assertion. Trace: added test line2380 -> existing `_resume_into_store` line341 -> `Tests/UI/app_factory.py:357` `_build_test_app` -> `build_test_app_config:113` real `load_settings` -> config.py:2106 -> config_participants.py:421/352 -> raw_participants.py:649/296/132 `RecoveryRequired(raw_source_selection_changed)`. This is unqualified setup failure, not disclosure RED or provider evidence. Exact new test source and patch retained as `*.red-source` and `red-tests.patch` before restoring both owners. No failure is discarded or relabeled.

## Canonical isolation mechanism (read-only diagnosis requested by root)

`Tests/conftest.py:1183` retains collection-time bootstrap profile only for `is_private_profile_child(request)`, a closest `bootstrap_profile` marker, or a closed filename list. The resume owner has no such marker/decorator and is not in that list. Otherwise lines1433-1452 redirect XDG, HOME and TLDW_CONFIG_PATH to the per-test `tmp_path/test_data` after collection-bound config participants already exist. `get_closest_marker` recognizes the node's own or inherited marker, so a per-node opt-in avoids changing sibling tests.

`Tests/private_profile.py` is the established fresh-process decorator: it marks the wrapped function `_private_profile_test`, launches exactly its node in a private child, and `is_private_profile_child` requires the exact node ID plus that attribute. The root autouse fixture then retains the selected bootstrap profile in the child; UI/conftest.py:152 avoids app import in its parent. It also reads the closest timeout marker and otherwise the configured unchanged timeout.

Inference from this source and trace: fresh-process separation alone still imports the resume owner/config at collection and redirects to a different profile at fixture time. It therefore does not address this same intra-process binding mismatch. The canonical exact-node profile retention mechanism is needed (closest bootstrap_profile marker or private_profile_test child); no marker/decorator was added and no retry executed pending root ruling.

## Preservation and closure

The runner only creates task-owned disposable profile files, no live config/database/archive payload is exported. Test receipts record selected paths/hashes and generated canaries only. Child exited and the unified exec session closed. No provider I/O occurred before the setup refusal; no successful provider preparation claimed. No other tests, installs, baseline/cohort replay, suppressions, skips, caps/timeouts edits, push, rebase, PR comments or merge. Fatal Ruff/formatting/GREEN not run because implementation stopped at setup. Root owns the next scope ruling and same implementer can continue from retained test source.
