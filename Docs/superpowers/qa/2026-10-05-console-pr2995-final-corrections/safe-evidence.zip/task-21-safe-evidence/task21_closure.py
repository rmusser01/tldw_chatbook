import hashlib,json,os,sys
from pathlib import Path
import pytest
selected=[];warnings=[]
def pytest_collection_finish(session):
    selected.extend(item.nodeid for item in session.items)
def pytest_warning_recorded(warning_message,when,nodeid,location):
    warnings.append(dict(message=str(warning_message.message),category=warning_message.category.__name__,when=when,nodeid=nodeid))
def pytest_sessionfinish(session,exitstatus):
    modules={}
    root=Path(__file__).resolve().parents[4]
    for name,module in list(sys.modules.items()):
        if name=='tldw_chatbook' or name.startswith('tldw_chatbook.'):
            path=getattr(module,'__file__',None)
            if path:
                p=Path(path).resolve()
                modules[name]=dict(path=str(p),sha256=hashlib.sha256(p.read_bytes()).hexdigest())
    Path(os.environ['TASK21_CLOSURE_PATH']).write_text(json.dumps(dict(nodeids=selected,warnings=warnings,exit=int(exitstatus),loaded_modules=modules,all_product_modules_from_worktree=all(str(root)+os.sep in v['path'] for v in modules.values())),indent=2))
