import ast,hashlib,json,subprocess
from pathlib import Path
base='3c0a66c1183a0d84770db964b14185fd2c2715e3'
files=['tldw_chatbook/Chat/console_chat_start.py','tldw_chatbook/Chat/console_chat_fork.py']
def parse(text): return ast.parse(text)
def find(tree,name): return next(n for n in ast.walk(tree) if isinstance(n,(ast.FunctionDef,ast.AsyncFunctionDef)) and n.name==name)
def executable(func):
    node=ast.fix_missing_locations(ast.parse(ast.unparse(func)).body[0])
    if ast.get_docstring(node,clean=False) is not None: node.body=node.body[1:]
    return ast.dump(node,include_attributes=False)
old={p:subprocess.check_output(['git','show',f'{base}:{p}'],text=True) for p in files}
new={p:Path(p).read_text() for p in files}
a0=parse(old[files[0]]);a1=parse(new[files[0]])
b0=parse(old[files[1]]);b1=parse(new[files[1]])
worker_same=executable(find(a0,'run_provider_worker'))==executable(find(a1,'run_provider_worker'))
f0=find(b0,'fingerprint_console_fork_video');f1=find(b1,'fingerprint_console_fork_video')
# More precise full-expression reversal in the sole comparison RHS.
compare=next(n for n in ast.walk(f1) if isinstance(n,ast.Compare) and isinstance(n.left,ast.Call) and ast.unparse(n.left)=='len(payload)')
assert len(compare.comparators)==1 and ast.unparse(compare.comparators[0])=='CONSOLE_FORK_FINGERPRINT_JSON_MAX_BYTES'
compare.comparators[0]=ast.BinOp(left=ast.Constant(64),op=ast.Mult(),right=ast.Constant(1024))
fork_same=ast.dump(f0,include_attributes=False)==ast.dump(f1,include_attributes=False)
constant=next(n for n in ast.walk(b1) if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='CONSOLE_FORK_FINGERPRINT_JSON_MAX_BYTES' for t in n.targets))
value=ast.literal_eval(constant.value.left)*ast.literal_eval(constant.value.right)
assert worker_same and fork_same and value==65536
result={'base':base,'worker_executable_ast_unchanged':worker_same,'video_ast_unchanged_after_reversing_reference':fork_same,'existing_constant_value_bytes':value,'source_sha256':{p:hashlib.sha256(Path(p).read_bytes()).hexdigest() for p in files}}
Path('.superpowers/sdd/2026-10-03-console-pr2995-review-and-merge/task-22-safe-evidence/ast-proof.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result))
