# Task 19 — integration checkpoint

Status: NEEDS_CONTEXT (root scope extension).

Pinned ef5917842b with recovery ref and bundle; selected rebase to3146bbd8 replayed101commits and finished at9888080b60292cfac4c2de9c30a77f8447575539. Only expected lessons append conflict; both blocks preserved.67incoming exact paths and screen/timer preflight hashes match. Source/index clean. No relocation edit occurred.

Actual two cap checks:1failed at25312>25218,1slack PASS,2.57s process/0.61s pytest. Screen has761methods by source AST; the failing line assertion prevents reaching the method assertion. Original stdout/stderr/JUnit/argv/profile/source hashes retained in task-19-safe-evidence/red-caps-fixed_screen_caps.*. No passing cohort replay.

The new exact global callback boundary affects three existing direct wiring test call sites (nine source-derived cases), not four as initially reported. Required callbacks preserve torn-down helper and screen-module asyncio/inspect/logger lookup without a reverse import. Root must select these bounded adapters before production signature changes. Details and exact selectors:task-19-safe-evidence/direct-wiring-extension-proposal.json. All original test assertions and timing remain unchanged.

Recovery/source/QA Git blob maps:base-tree.txt,dev-tree.txt,composed-tree.txt and pin.json. Exact moved bodies/declared substitutions:receiver-map-before.json. Complete caller/module patch census retained. Rebase stdout/stderr preserve inherited gc/unreachable warnings; no housekeeping performed. No pending process.
