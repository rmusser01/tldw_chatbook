import ast
import copy
import hashlib
import json
from pathlib import Path

W = Path(__file__).resolve().parents[4]
E = Path(__file__).resolve().parent

def tree(path):
    return ast.parse(path.read_text())

def dump(node):
    return ast.dump(node, include_attributes=False)

def named(module, name):
    matches = [node for node in ast.walk(module) if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)) and node.name == name]
    assert len(matches) == 1, name
    return matches[0]

hydration_path = W / 'tldw_chatbook/Chat/console_conversation_hydration.py'
store_path = W / 'tldw_chatbook/Chat/console_chat_store.py'
tests_path = W / 'Tests/Chat/test_console_conversation_hydration.py'
hydration = tree(hydration_path)
helper = named(hydration, '_refresh_console_message_parents')
without_helper = copy.deepcopy(hydration)
without_helper.body = [node for node in without_helper.body if getattr(node, 'name', None) != helper.name]
assert dump(without_helper) == dump(tree(E / 'base-hydration.py'))

store = tree(store_path)
method = named(store, '_hydrate_provider_continuations_from_persistence')
base_store = tree(E / 'base-store.py')
base_method = named(base_store, method.name)
unchanged_store = copy.deepcopy(store)
for node in ast.walk(unchanged_store):
    if isinstance(node, ast.ClassDef):
        for index, child in enumerate(node.body):
            if child is not None and getattr(child, 'name', None) == method.name:
                node.body[index] = copy.deepcopy(base_method)
assert dump(unchanged_store) == dump(base_store)
# The owned method differs only by the replaced parent assignment and late import/call.
old_method = copy.deepcopy(base_method)
old_loop = next(node for node in old_method.body if isinstance(node, ast.For))
parent_assignments = [node for node in old_loop.body if isinstance(node, ast.Assign) and dump(node.targets[0]) == dump(ast.parse('node.parent_message_id = None').body[0].targets[0])]
assert len(parent_assignments) == 1
old_loop.body.remove(parent_assignments[0])
new_method = copy.deepcopy(method)
assert isinstance(new_method.body[-3], ast.ImportFrom)
assert new_method.body[-3].module == 'tldw_chatbook.Chat.console_conversation_hydration'
assert [x.name for x in new_method.body[-3].names] == [helper.name]
assert dump(new_method.body[-2]) == dump(ast.parse('_refresh_console_message_parents(nodes, rows)').body[0])
del new_method.body[-3:-1]
assert dump(new_method) == dump(old_method)
assert dump(tree(E / 'green-transparent-store.py')) == dump(store)

new_test_names = {'test_restore_preserves_empty_parent_transparency', 'test_restore_refreshes_current_durable_parents'}
tests = tree(tests_path)
original_tests = copy.deepcopy(tests)
assert {getattr(node, 'name', None) for node in tests.body} >= new_test_names
original_tests.body = [node for node in original_tests.body if getattr(node, 'name', None) not in new_test_names]
screen = named(original_tests, 'test_the_screen_tree_walk_still_flattens_every_branch')
marker = ast.parse('@pytest.mark.bootstrap_profile\ndef f(): pass').body[0].decorator_list[0]
assert [dump(node) for node in screen.decorator_list] == [dump(marker)]
screen.decorator_list.clear()
assert dump(original_tests) == dump(tree(E / 'base-tests.py'))
first_name = 'test_restore_preserves_empty_parent_transparency'
assert dump(named(tests, first_name)) == dump(named(tree(E / 'checkpoint-tests.py'), first_name))

# Removing the exact None guard yields the previously passing helper executable AST.
checkpoint_helper = named(tree(E / 'checkpoint-hydration.py'), helper.name)
helper_without_guard = copy.deepcopy(helper)
loop = next(node for node in helper_without_guard.body if isinstance(node, ast.For))
guard = ast.parse('if node.persisted_message_id is None:\n    continue').body[0]
assert dump(loop.body[0]) == dump(guard)
del loop.body[0]
assert dump(helper_without_guard) == dump(checkpoint_helper)
# First selector's real fixture explicitly supplies non-null persisted IDs.
first = named(tests, first_name)
rows_assignment = next(node for node in ast.walk(first) if isinstance(node, ast.Assign) and isinstance(node.targets[0], ast.Name) and node.targets[0].id == 'rows')
fixture_ids = [node.elts[0].value for node in rows_assignment.value.elts]
assert all(isinstance(value, str) and value for value in fixture_ids)

for node, path in [(helper, 'added-helper.py'), (method, 'changed-store-method.py')]:
    source = hydration_path.read_text() if node is helper else store_path.read_text()
    lines = source.splitlines(keepends=True)[node.lineno - 1:node.end_lineno]
    (E / path).write_text(''.join(lines) if node is helper else 'class Owner:\n' + ''.join(lines))
new_test_parts = []
for node in tests.body:
    if getattr(node, 'name', None) in new_test_names:
        start = min([node.lineno] + [decorator.lineno for decorator in node.decorator_list])
        new_test_parts.append(''.join(tests_path.read_text().splitlines(keepends=True)[start-1:node.end_lineno]))
(E / 'added-regressions.py').write_text('\n\n'.join(new_test_parts)+'\n')
result = {
    'preexisting_hydration_module_AST_preserved': True,
    'store_AST_outside_owned_method_preserved': True,
    'owned_store_method_only_parent_block_replacement': True,
    'whole_test_owner_BASE_AST_minus_two_new_selectors_and_exact_marker': True,
    'first_selector_AST_exact_checkpoint': True,
    'first_selector_nonanonymous_fixture_ids': fixture_ids,
    'helper_AST_minus_exact_None_guard_exact_checkpoint': True,
    'prior_import_format_store_AST_exact_current': True,
    'first_PASS_qualification': 'carried across exact import-format AST equality and a guard unreachable for its explicit nonanonymous IDs; no final-byte replay claim',
    'new_helper_import_owner': 'tldw_chatbook.Chat.console_conversation_hydration',
    'runtime_import_qualification': 'existing qualified resume closure already contains owner; no fresh loading claim',
    'store_lines': len(store_path.read_text().splitlines()),
    'sources_sha256': {str(path.relative_to(W)): hashlib.sha256(path.read_bytes()).hexdigest() for path in [hydration_path, store_path, tests_path]},
}
(E / 'static-ast-proof-result.json').write_text(json.dumps(result, indent=2))
print(json.dumps(result, indent=2))
