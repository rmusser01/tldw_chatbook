import hashlib,json,subprocess
from pathlib import Path
W=Path(__file__).resolve().parents[4];E=Path(__file__).resolve().parent;S=E.parent
h=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
owned={'tldw_chatbook/Chat/console_conversation_hydration.py','tldw_chatbook/Chat/console_chat_store.py','Tests/Chat/test_console_conversation_hydration.py'}
base=json.loads((E/'baseline.json').read_text());followup=json.loads((E/'followup-baseline.json').read_text())
changed=[p for p,v in followup['tracked'].items() if p not in owned and (not (W/p).is_file() or h(W/p)!=v)]
assert not changed,changed
current_files=set(subprocess.check_output(['git','ls-files','-z'],cwd=W).decode().split('\0'))-{''}
assert current_files==set(followup['tracked'])
carry_changed=[p for p,v in base['carry'].items() if not (S/p).is_file() or h(S/p)!=v]
assert not carry_changed,carry_changed
qa=[p for p in base['tracked'] if p.startswith('Docs/superpowers/qa/') or p.startswith('qa/')]
assert all(h(W/p)==base['tracked'][p] for p in qa)
root_metadata=set(subprocess.check_output(['git','diff','--name-only',base['head'],followup['head']],cwd=W,text=True).splitlines())-owned
initial_other_changed=[p for p,v in base['tracked'].items() if p not in owned|root_metadata and (not (W/p).is_file() or h(W/p)!=v)]
assert not initial_other_changed,initial_other_changed
checkpoint=json.loads((S/'task-23-checkpoint-manifest-frozen.json').read_text())
for p,v in checkpoint['files'].items():
    path=S/({'task-23-brief.md':'task-23-brief-before-followup.md','task-23-report.md':'task-23-report-before-followup.md'}.get(p,p))
    assert path.stat().st_size==v['bytes'] and h(path)==v['sha256'],p
assert (S/'task-23-report.md').read_bytes().startswith((S/'task-23-report-before-followup.md').read_bytes())
selected=['green-anonymous','green-screen-walk-v2','green-store-tree','green-blank-owner','green-thinking','green-cursor-recovery','green-task21-provenance','green-store-caps']
for name in selected:
    r=json.loads((E/(name+'.json')).read_text());c=json.loads((E/(name+'.closure.json')).read_text())
    assert r['exit']==0 and r['closed'] and r['source_stable'] and c['all_product_modules_from_worktree'],name
    assert all(h(W/p)==v for p,v in r['sources_sha256'].items()),name
    assert all(h(Path(v['path']))==v['sha256'] for v in c['loaded_modules'].values()),name
cap='Tests/Architecture/test_module_size_ratchet.py'
assert h(W/cap)==base['tracked'][cap]
for path,name in [('tldw_chatbook/Chat/console_conversation_hydration.py','final-hydration.py'),('tldw_chatbook/Chat/console_chat_store.py','final-store.py'),('Tests/Chat/test_console_conversation_hydration.py','final-tests.py')]: (E/name).write_bytes((W/path).read_bytes())
result={'unowned_tracked_paths_verified_against_followup':len(followup['tracked'])-3,'initial_unowned_changes_only_authorized_root_metadata':sorted(root_metadata),'qa_files_unchanged':len(qa),'prior_safe_artifacts_unchanged':len(base['carry']),'checkpoint67_verified_via_report_brief_aliases':True,'report_prefix_preserved':True,'all_final_source_selected_runtime_receipts_current':True,'unchanged_cap_file_sha256':h(W/cap),'store_lines':len((W/'tldw_chatbook/Chat/console_chat_store.py').read_text().splitlines()),'scope':'three owners only; no private profile/config/DB content exported'}
(E/'static-preservation-result.json').write_text(json.dumps(result,indent=2));print(json.dumps(result,indent=2))
