"""One hydration policy, two callers (task-15860 Task 6).

`ChatScreen._resume_console_workspace_conversation` used to be the ONLY
code that could turn a persisted conversation into a Console session, and
it interleaved that policy with a screen's own work. A wake fired at
launch needs a session for a conversation nobody has opened, so the
session-producing half moved to
`Chat/console_conversation_hydration.py` -- a pure refactor, pinned here
in both directions:

* **characterization** -- the screen's `_console_messages_from_conversation
  _tree` seam (eight test files call it by name) still produces the same
  flattened tree, branches, parenthood and dropped-empty-row transparency;
* **equivalence** -- for one fixture conversation, the session a LAUNCH
  hydrates headlessly and the session the SCREEN resumes agree field for
  field on everything that reaches a provider payload.

The equivalence test is the one that matters: it is what stops the launch
path quietly drifting into a second, worse resume policy -- which is the
failure the plan named ("rather than duplicating it").
"""

from __future__ import annotations

import asyncio
import json
from dataclasses import replace
from types import SimpleNamespace

import pytest

from Tests.UI.app_factory import _build_test_app
from Tests.UI.test_console_fleet_wake_wiring import _attach_real_dbs
from Tests.UI.test_console_native_chat_flow import (
    StaticConversationTreeService,
    _configure_native_ready_console,
)
from tldw_chatbook.Chat.chat_conversation_service import ChatConversationService
from tldw_chatbook.Chat.chat_persistence_service import ChatPersistenceService
from tldw_chatbook.Chat.console_chat_models import ConsoleMessageRole
from tldw_chatbook.Chat.console_chat_store import ConsoleChatStore
from tldw_chatbook.Chat.console_conversation_hydration import (
    apply_resume_settings_overrides,
    console_messages_from_conversation_tree,
    hydrate_console_generation_settings,
    hydrate_console_session,
    load_console_conversation_tree,
    prepare_console_session_data,
)
from tldw_chatbook.Chat.console_session_settings import (
    ConsoleSessionSettings,
    default_console_session_settings,
)
from tldw_chatbook.UI.Screens.chat_screen import ChatScreen

CONVERSATION_ID = "conv-fixture"


def test_legacy_resume_wrapper_preserves_base_settings_and_restores_row_owners() -> (
    None
):
    base = ConsoleSessionSettings(provider="base", model="base-model")
    persisted = ConsoleSessionSettings(
        provider="openai",
        model="gpt-test",
        base_url="https://example.test/v1",
        temperature=0.12,
        top_p=0.34,
        min_p=0.05,
        top_k=17,
        max_tokens=2345,
        seed=19,
        presence_penalty=0.25,
        frequency_penalty=-0.5,
        reasoning_effort="high",
        reasoning_summary="detailed",
        verbosity="low",
        thinking_effort="medium",
        thinking_budget_tokens=4096,
        streaming=False,
        character_label="Ada",
        system_prompt="metadata prompt must not win",
        source="user",
        pinned_prefill="metadata prefill must not win",
    )
    metadata = {
        "console_session_settings": {
            "version": 1,
            **persisted.__dict__,
        },
        "pinned_response_prefill": "Canonical prefill",
    }

    restored = apply_resume_settings_overrides(
        base,
        {
            "system_prompt": "Canonical row prompt",
            "metadata": json.dumps(metadata),
        },
    )

    # ADR-095: legacy complete snapshots are not the canonical generation owner.
    # This compatibility helper only applies the row-owned prompt and prefill.
    assert restored == replace(
        base,
        system_prompt="Canonical row prompt",
        pinned_prefill="Canonical prefill",
    )


@pytest.mark.parametrize(
    "payload",
    (
        "not-json",
        json.dumps({"console_session_settings": []}),
        json.dumps({"console_session_settings": {"version": 2}}),
        json.dumps(
            {
                "console_session_settings": {
                    "version": 1,
                    **ConsoleSessionSettings(provider="openai").__dict__,
                    "streaming": "yes",
                }
            }
        ),
        '{"nested":' * 1_200 + "null" + "}" * 1_200,
    ),
)
def test_resume_malformed_settings_fall_back_without_partial_poisoning(
    payload: str,
) -> None:
    base = ConsoleSessionSettings(
        provider="base",
        model="safe-model",
        temperature=0.61,
        streaming=True,
        system_prompt="old prompt",
        pinned_prefill="old prefill",
    )

    restored = apply_resume_settings_overrides(
        base,
        {"system_prompt": "Row prompt", "metadata": payload},
    )

    assert restored == ConsoleSessionSettings(
        **{
            **base.__dict__,
            "system_prompt": "Row prompt",
            "pinned_prefill": None,
        }
    )


@pytest.mark.parametrize(
    ("field", "invalid"),
    (
        ("provider", ""),
        ("provider", "   "),
        ("provider", " openai"),
        ("provider", "openai "),
        ("source", "external"),
        ("source", " user"),
        ("temperature", -0.01),
        ("temperature", 2.01),
        ("temperature", True),
        ("top_p", -0.01),
        ("top_p", 1.01),
        ("min_p", -0.01),
        ("min_p", 1.01),
        ("top_k", -1),
        ("top_k", True),
        ("max_tokens", 0),
        ("seed", -1),
        ("presence_penalty", -2.01),
        ("presence_penalty", 2.01),
        ("frequency_penalty", -2.01),
        ("frequency_penalty", 2.01),
        ("thinking_budget_tokens", 1023),
        ("reasoning_effort", "ultra"),
        ("reasoning_effort", " high"),
        ("reasoning_summary", "verbose"),
        ("verbosity", "max"),
        ("thinking_effort", "minimal"),
    ),
)
def test_resume_structurally_invalid_settings_fall_back_as_one_snapshot(
    field: str,
    invalid: object,
) -> None:
    base = ConsoleSessionSettings(
        provider="base",
        model="safe-model",
        temperature=0.61,
        streaming=True,
    )
    persisted = {
        **ConsoleSessionSettings(
            provider="openai",
            model="gpt-test",
            min_p=0.1,
            top_k=0,
            max_tokens=1,
            seed=0,
            presence_penalty=0.0,
            frequency_penalty=0.0,
            reasoning_effort="high",
            reasoning_summary="auto",
            verbosity="medium",
            thinking_effort="off",
            thinking_budget_tokens=1024,
            source="user",
        ).__dict__,
        field: invalid,
    }
    metadata = json.dumps({"console_session_settings": {"version": 1, **persisted}})

    restored = apply_resume_settings_overrides(
        base,
        {"system_prompt": None, "metadata": metadata},
    )

    assert restored == base


@pytest.mark.parametrize(
    "field",
    (
        "temperature",
        "top_p",
        "min_p",
        "presence_penalty",
        "frequency_penalty",
    ),
)
def test_resume_oversized_float_settings_fall_back_as_one_snapshot(
    field: str,
) -> None:
    base = ConsoleSessionSettings(provider="base", model="safe-model")
    persisted = {
        **ConsoleSessionSettings(provider="openai", model="gpt-test").__dict__,
        field: 10**400,
    }

    restored = apply_resume_settings_overrides(
        base,
        {
            "system_prompt": None,
            "metadata": json.dumps(
                {"console_session_settings": {"version": 1, **persisted}}
            ),
        },
    )

    assert restored == base


#: Deliberately awkward: two branches off one root, a truly-empty node in
#: the middle of a branch (its child must re-parent through it), a system
#: prompt, roleplay metadata and a pinned prefill.
FIXTURE_TREE = {
    "conversation": {
        "id": CONVERSATION_ID,
        "title": "Fixture conversation",
        "system_prompt": "  You are Alraune.\n",
        "workspace_id": "ws-fixture",
        "runtime_backend": "local",
        "assistant_kind": "character",
        "assistant_id": "7",
        "assistant_authority_id": "local-authority",
        "character_id": 7,
        "metadata": {
            "console_roleplay_context": {
                "version": 2,
                "user_name_override": "Robert",
                "character_system_template": "  You are {{char}}.\n",
                "character_name_snapshot": "Alraune",
            },
            "pinned_response_prefill": "Certainly,",
        },
    },
    "root_threads": [
        {
            "id": "m1",
            "sender": "user",
            "content": "first user message",
            "children": [
                {
                    "id": "m2",
                    "sender": "assistant",
                    "content": "branch A reply",
                    "children": [
                        {
                            "id": "m3-empty",
                            "sender": "assistant",
                            "content": "",
                            "children": [
                                {
                                    "id": "m4",
                                    "sender": "user",
                                    "content": "after an empty row",
                                    "children": [],
                                }
                            ],
                        }
                    ],
                },
                {
                    "id": "m5",
                    "sender": "assistant",
                    "content": "branch B reply",
                    "children": [],
                },
            ],
        }
    ],
}


def _fixture_app(tmp_path):
    app = _build_test_app()
    _attach_real_dbs(app, tmp_path)
    _configure_native_ready_console(app)
    app.app_config.setdefault("console", {})["agent_runtime"] = False
    if app.chachanotes_db.get_conversation_by_id(CONVERSATION_ID) is None:
        app.chachanotes_db.add_conversation(
            {"id": CONVERSATION_ID, "title": "Fixture conversation"}
        )
    app.chat_conversation_scope_service = StaticConversationTreeService(
        {CONVERSATION_ID: FIXTURE_TREE}
    )
    return app


def _message_shape(store, session_id):
    return [
        (
            m.role.value,
            m.content,
            m.persisted_message_id,
            m.parent_message_id,
        )
        for m in store.messages_for_session(session_id)
    ]


@pytest.mark.asyncio
@pytest.mark.parametrize("preload", [False, True])
async def test_production_hydration_restores_before_first_cursor(
    tmp_path, preload
) -> None:
    app = _fixture_app(tmp_path)
    assert (
        app.chachanotes_db.set_conversation_active_cursor(
            CONVERSATION_ID,
            active_leaf_message_id=None,
            before_message_id="m1",
        )
        is True
    )
    store = app.console_runtime.ensure_chat_store()

    prepared = (
        await prepare_console_session_data(
            app=app, store=store, conversation_id=CONVERSATION_ID, tree=FIXTURE_TREE
        )
        if preload
        else None
    )
    session = await hydrate_console_session(
        app=app,
        store=store,
        conversation_id=CONVERSATION_ID,
        tree=FIXTURE_TREE,
        settings=default_console_session_settings(app.app_config),
        prepared_data=prepared,
    )

    assert store.active_path_message_ids(session.id) == []
    assert store.active_leaf(session.id) is None
    assert store.session_draft(session.id) == "first user message"
    assert session.has_user_work is True


@pytest.mark.asyncio
async def test_hydration_keeps_scalar_only_cursor_reader_compatibility() -> None:
    class _ScalarOnlyDB:
        def __init__(self) -> None:
            self.calls: list[str] = []

        def get_conversation_active_leaf(self, conversation_id: str) -> None:
            self.calls.append(conversation_id)
            return None

    db = _ScalarOnlyDB()
    store = ConsoleChatStore()
    tree = {
        "conversation": {"id": "legacy", "title": "Legacy adapter"},
        "root_threads": [],
    }

    session = await hydrate_console_session(
        app=SimpleNamespace(chachanotes_db=db),
        store=store,
        conversation_id="legacy",
        tree=tree,
        settings=None,
    )

    assert db.calls == ["legacy"]
    assert store.active_path_message_ids(session.id) == []
    assert store.active_leaf(session.id) is None


def test_the_screen_tree_walk_still_flattens_every_branch(tmp_path):
    """Characterization: the screen seam eight test files call by name.

    Asserts the three properties the walk owns -- ALL branches (not the
    latest), parenthood taken from NESTING, and an empty row dropped but
    transparent to its children -- so a refactor that quietly kept only the
    active path cannot pass.
    """
    app = _fixture_app(tmp_path)
    screen = ChatScreen(app)
    messages = screen._console_messages_from_conversation_tree(FIXTURE_TREE)

    shape = [(m.persisted_message_id, m.parent_message_id) for m in messages]
    assert shape == [
        ("m1", None),
        ("m2", "m1"),
        ("m4", "m2"),
        ("m5", "m1"),
    ], (
        "the walk must keep BOTH branches, take parenthood from nesting, and "
        f"re-parent through the dropped empty row; got {shape}"
    )
    assert [m.role.value for m in messages] == [
        "user",
        "assistant",
        "user",
        "assistant",
    ]

    # `ConsoleChatMessage.id` is a per-instance uuid, so compare the fields
    # the walk actually decides rather than object identity.
    def _walk_shape(built):
        return [
            (m.role.value, m.content, m.persisted_message_id, m.parent_message_id)
            for m in built
        ]

    assert _walk_shape(messages) == _walk_shape(
        console_messages_from_conversation_tree(FIXTURE_TREE, db=app.chachanotes_db)
    ), "the screen seam and the module function disagree"


@pytest.mark.asyncio
async def test_a_launch_hydrated_session_matches_a_screen_resumed_one(tmp_path):
    """The equivalence pin: both callers, one fixture, identical sessions.

    Everything that can reach a provider payload is compared -- the whole
    message tree with its parenthood, the durable identity fields, the
    roleplay overlay, and the full settings snapshot.

    The one field that legitimately differs is named rather than skipped:
    the session's own `id` is a fresh uuid per session.
    """
    screen_app = _fixture_app(tmp_path)
    screen = ChatScreen(screen_app)
    async with screen_app.run_test(size=(160, 48)) as pilot:
        await screen_app.push_screen(screen)
        screen_app._initial_screen_pushed = True
        await pilot.pause()
        resumed = await screen._workspace._resume_console_workspace_conversation(
            CONVERSATION_ID
        )
        assert resumed is True, f"the screen resume did not succeed: {resumed!r}"
        screen_store = screen._console_chat_store
        screen_session = next(
            s
            for s in screen_store.sessions()
            if s.persisted_conversation_id == CONVERSATION_ID
        )
        screen_shape = _message_shape(screen_store, screen_session.id)

    # A second app, no screen at all: the launch shape.
    launch_app = _fixture_app(tmp_path)
    launch_store = launch_app.console_runtime.ensure_chat_store()
    tree = await load_console_conversation_tree(launch_app, CONVERSATION_ID)
    assert tree is not None
    conversation = tree["conversation"]
    launch_session = await hydrate_console_session(
        app=launch_app,
        store=launch_store,
        conversation_id=CONVERSATION_ID,
        tree=tree,
        settings=apply_resume_settings_overrides(
            default_console_session_settings(launch_app.app_config), conversation
        ),
    )

    assert _message_shape(launch_store, launch_session.id) == screen_shape, (
        "the launch-hydrated transcript differs from the screen-resumed one"
    )
    for field in (
        "title",
        "workspace_id",
        "persisted_conversation_id",
        "runtime_backend",
        "assistant_kind",
        "assistant_id",
        "assistant_authority_id",
        "character_id",
        "character_name",
        "user_display_name_override",
        "character_system_template",
    ):
        assert getattr(launch_session, field) == getattr(screen_session, field), (
            f"session field {field!r} differs: "
            f"launch={getattr(launch_session, field)!r} "
            f"screen={getattr(screen_session, field)!r}"
        )
    assert launch_session.settings == screen_session.settings, (
        "the settings snapshots differ:\n"
        f"launch={launch_session.settings!r}\nscreen={screen_session.settings!r}"
    )
    assert launch_session.settings is not None
    assert launch_session.settings.system_prompt == ("  You are Alraune.\n"), (
        "the saved system prompt must be restored VERBATIM -- the comparison "
        "above is worthless if both sides restored nothing"
    )
    assert launch_session.user_display_name_override == "Robert", (
        "the roleplay overlay never reached either session, so comparing them "
        "proved nothing"
    )
    assert launch_session.character_name == "Alraune"
    assert launch_session.settings.character_label == "Alraune"
    assert launch_session.id != screen_session.id, (
        "session ids are per-session uuids; equal ids would mean the two "
        "stores are the same object and this test is not comparing two callers"
    )


@pytest.mark.asyncio
async def test_production_hydration_never_activates_placeholder_authority(
    tmp_path, monkeypatch
):
    app = _fixture_app(tmp_path)
    store = app.console_runtime.ensure_chat_store()
    prior = store.create_session(title="Prior")
    observed = []
    original_hydrate = store.hydrate_session_library_policy

    async def observe_before_activation(session_id):
        observed.append((store.active_session_id, session_id))
        await asyncio.sleep(0)
        observed.append((store.active_session_id, session_id))
        return await original_hydrate(session_id)

    monkeypatch.setattr(
        store, "hydrate_session_library_policy", observe_before_activation
    )
    session = await hydrate_console_session(
        app=app,
        store=store,
        conversation_id=CONVERSATION_ID,
        tree=FIXTURE_TREE,
        settings=default_console_session_settings(app.app_config),
        target_scope_type="global",
    )

    assert observed == [(prior.id, session.id), (prior.id, session.id)]
    assert session.library_policy_hydrated is True
    assert store.active_session_id == session.id


@pytest.mark.asyncio
@pytest.mark.parametrize(
    "failure_boundary",
    ("hydrate_session_library_policy", "reconcile_pending_workspace_projection"),
)
async def test_hydration_rollback_is_atomic_across_policy_boundaries(
    failure_boundary,
    monkeypatch,
):
    store = _build_test_app().console_runtime.ensure_chat_store()
    prior_settings = default_console_session_settings({})
    prior = store.create_session(title="Prior", settings=prior_settings)
    store.set_session_draft(prior.id, "draft stays exact")

    async def fail_after_restore(_session_id):
        raise RuntimeError(f"failed {failure_boundary}")

    monkeypatch.setattr(store, failure_boundary, fail_after_restore)
    app = type(
        "HydrationApp",
        (),
        {
            "chachanotes_db": type(
                "HydrationDB",
                (),
                {"get_conversation_active_leaf": lambda _self, _target: None},
            )()
        },
    )()
    tree = {
        "conversation": {"id": "rollback-target", "title": "Rollback target"},
        "root_threads": [],
    }

    with pytest.raises(RuntimeError, match=f"failed {failure_boundary}"):
        await hydrate_console_session(
            app=app,
            store=store,
            conversation_id="rollback-target",
            tree=tree,
            settings=prior_settings,
        )

    assert store.active_session_id == prior.id
    assert store.sessions() == [prior]
    assert prior.settings is prior_settings
    assert prior.draft == "draft stays exact"


@pytest.mark.asyncio
@pytest.mark.parametrize(
    "failure_boundary",
    ("hydrate_session_library_policy", "reconcile_pending_workspace_projection"),
)
async def test_hydration_cancellation_rolls_back_then_propagates(
    failure_boundary,
    monkeypatch,
):
    store = _build_test_app().console_runtime.ensure_chat_store()
    prior_settings = default_console_session_settings({})
    prior = store.create_session(title="Prior", settings=prior_settings)
    store.set_session_draft(prior.id, "draft stays exact")

    async def cancel_after_restore(_session_id):
        raise asyncio.CancelledError

    monkeypatch.setattr(store, failure_boundary, cancel_after_restore)
    app = type(
        "HydrationApp",
        (),
        {
            "chachanotes_db": type(
                "HydrationDB",
                (),
                {"get_conversation_active_leaf": lambda _self, _target: None},
            )()
        },
    )()
    tree = {
        "conversation": {"id": "cancel-target", "title": "Cancel target"},
        "root_threads": [],
    }

    with pytest.raises(asyncio.CancelledError):
        await hydrate_console_session(
            app=app,
            store=store,
            conversation_id="cancel-target",
            tree=tree,
            settings=prior_settings,
        )

    assert store.active_session_id == prior.id
    assert store.sessions() == [prior]
    assert prior.settings is prior_settings
    assert prior.draft == "draft stays exact"


@pytest.mark.asyncio
async def test_hydration_restores_v2_local_character_snapshot_for_future_projections(
    tmp_path,
):
    """A saved name, not a mutable character card, owns resumed identity."""
    app = _fixture_app(tmp_path)
    store = app.console_runtime.ensure_chat_store()
    tree = {
        "conversation": {
            "id": "v2-character",
            "title": "Saved Alraune",
            "system_prompt": "Saved prompt for Alraune.",
            "runtime_backend": "local",
            "assistant_kind": "character",
            "assistant_id": "7",
            "assistant_authority_id": "local-authority",
            "character_id": 7,
            "metadata": {
                "console_roleplay_context": {
                    "version": 2,
                    "user_name_override": "Captain Rowan",
                    "character_system_template": "{{char}} speaks with {{user}}.",
                    "character_name_snapshot": "Alraune",
                }
            },
        },
        "root_threads": [],
    }

    session = await hydrate_console_session(
        app=app,
        store=store,
        conversation_id="v2-character",
        tree=tree,
        settings=replace(
            apply_resume_settings_overrides(
                default_console_session_settings(app.app_config), tree["conversation"]
            ),
            character_label="Renamed current card",
        ),
    )

    assert session.character_name == "Alraune"
    assert session.settings is not None
    assert session.settings.character_label == "Alraune"
    assert session.settings.system_prompt == "Saved prompt for Alraune."
    store._materialize_roleplay_projections_live(session.id, global_default="User")
    assert session.settings.system_prompt == "Alraune speaks with Captain Rowan."
    assert "Renamed current card" not in session.settings.system_prompt


@pytest.mark.asyncio
async def test_hydration_keeps_v1_roleplay_without_unsaved_character_identity(tmp_path):
    """Legacy templates survive, but v1 never guesses a current card name."""
    app = _fixture_app(tmp_path)
    store = app.console_runtime.ensure_chat_store()
    tree = {
        "conversation": {
            "id": "v1-character",
            "title": "Legacy character",
            "system_prompt": "Saved legacy prompt.",
            "runtime_backend": "local",
            "assistant_kind": "character",
            "assistant_id": "7",
            "character_id": 7,
            "metadata": {
                "console_roleplay_context": {
                    "version": 1,
                    "user_name_override": "Captain Rowan",
                    "character_system_template": "{{char}} speaks with {{user}}.",
                }
            },
        },
        "root_threads": [],
    }

    session = await hydrate_console_session(
        app=app,
        store=store,
        conversation_id="v1-character",
        tree=tree,
        settings=replace(
            apply_resume_settings_overrides(
                default_console_session_settings(app.app_config), tree["conversation"]
            ),
            character_label="Renamed current card",
        ),
    )

    assert session.character_name is None
    assert session.settings is not None
    assert session.settings.character_label == ""
    assert session.settings.system_prompt == "Saved legacy prompt."
    assert session.user_display_name_override == "Captain Rowan"
    assert session.character_system_template == "{{char}} speaks with {{user}}."


@pytest.mark.asyncio
async def test_hydration_keeps_generic_sessions_without_character_identity(tmp_path):
    """A snapshot never grants a generic conversation character authority."""
    app = _fixture_app(tmp_path)
    store = app.console_runtime.ensure_chat_store()
    tree = {
        "conversation": {
            "id": "generic-session",
            "title": "Generic session",
            "system_prompt": "Saved generic prompt.",
            "runtime_backend": "local",
            "assistant_kind": "generic",
            "assistant_id": "console",
            "metadata": {
                "console_roleplay_context": {
                    "version": 2,
                    "character_name_snapshot": "Alraune",
                }
            },
        },
        "root_threads": [],
    }

    session = await hydrate_console_session(
        app=app,
        store=store,
        conversation_id="generic-session",
        tree=tree,
        settings=replace(
            apply_resume_settings_overrides(
                default_console_session_settings(app.app_config), tree["conversation"]
            ),
            character_label="Inherited label",
        ),
    )

    assert session.assistant_kind == "generic"
    assert session.character_name is None
    assert session.settings is not None
    assert session.settings.character_label == ""


@pytest.mark.asyncio
async def test_canonical_hydration_makes_persisted_generic_console_forkable(tmp_path):
    """Resume the ordinary saved Console identity as one unscoped identity."""
    app = _fixture_app(tmp_path)
    service = ChatPersistenceService(app.chachanotes_db)
    source_store = ConsoleChatStore(persistence=service)
    source = source_store.create_session(
        title="Generic Console",
        settings=default_console_session_settings(app.app_config),
        assistant_kind="generic",
        assistant_id="console",
        assistant_authority_id=None,
    )
    source_message = source_store.append_message(
        source.id,
        role=ConsoleMessageRole.USER,
        content="Persist the ordinary Console identity",
        persist=True,
    )
    conversation_id = source.persisted_conversation_id
    assert conversation_id is not None
    persisted = app.chachanotes_db.get_conversation_by_id(conversation_id)
    assert persisted["assistant_kind"] == "generic"
    assert persisted["assistant_id"] == "console"
    assert "assistant_authority_id" in persisted
    assert persisted["assistant_authority_id"] is None

    tree = ChatConversationService(app.chachanotes_db).get_conversation_tree(
        conversation_id
    )
    assert tree["conversation"]["assistant_kind"] is None
    assert tree["conversation"]["assistant_id"] == "console"
    resumed_store = ConsoleChatStore(persistence=service)

    resumed = await hydrate_console_session(
        app=SimpleNamespace(chachanotes_db=app.chachanotes_db),
        store=resumed_store,
        conversation_id=conversation_id,
        tree=tree,
        settings=default_console_session_settings(app.app_config),
    )

    # Explicit None is the current plain Console identity (ADR-139).
    assert resumed.assistant_kind == "generic"
    assert resumed.assistant_id == "console"
    assert resumed.assistant_authority_id is None
    assert resumed.persona_memory_mode is None
    resumed_message = next(
        message
        for message in resumed_store.messages_for_session(resumed.id)
        if message.persisted_message_id == source_message.persisted_message_id
    )
    eligibility = resumed_store.fork_eligibility(resumed_message.id)
    assert eligibility.eligible is True, eligibility.reason


@pytest.mark.asyncio
async def test_canonical_settings_apply_refreshes_the_durable_resume_snapshot(tmp_path):
    app = _fixture_app(tmp_path)
    service = ChatPersistenceService(app.chachanotes_db)
    source_store = ConsoleChatStore(persistence=service)
    initial = default_console_session_settings(app.app_config)
    source = source_store.create_session(title="Settings snapshot", settings=initial)
    source_store.append_message(
        source.id,
        role=ConsoleMessageRole.USER,
        content="Make this session durable",
        persist=True,
    )
    conversation_id = source.persisted_conversation_id
    assert conversation_id is not None

    assert service.update_conversation_system_prompt(
        conversation_id=conversation_id,
        system_prompt="Canonical system prompt",
    )
    assert service.update_conversation_pinned_prefill(
        conversation_id=conversation_id,
        pinned_prefill="Canonical pinned prefill",
    )
    record = app.chachanotes_db.get_conversation_by_id(conversation_id)
    metadata = json.loads(record["metadata"])
    metadata["unrelated_owner"] = {"keep": True}
    assert app.chachanotes_db.update_conversation(
        conversation_id,
        {"metadata": json.dumps(metadata)},
        expected_version=record["version"],
    )

    latest = replace(
        initial,
        provider="openai",
        model="gpt-test",
        temperature=0.22,
        system_prompt="Stale snapshot prompt",
        pinned_prefill="Stale snapshot prefill",
        source="user",
    )
    from Tests.Chat.test_console_settings_apply_store import _submission

    submission = _submission(
        source_store, source.id, submission_id="resume-settings", model="gpt-test"
    )
    submission = replace(submission, draft=replace(submission.draft, settings=latest))
    commit = source_store.commit_console_settings_live(submission)
    outcome = await source_store.persist_console_settings_commit_serialized(commit)
    assert not outcome.failed_components

    persisted = app.chachanotes_db.get_conversation_by_id(conversation_id)
    persisted_metadata = json.loads(persisted["metadata"])
    assert persisted_metadata["unrelated_owner"] == {"keep": True}
    assert persisted_metadata["console_generation_settings"]["provider"] == "openai"
    assert persisted_metadata["console_generation_settings"]["temperature"] == 0.22

    tree = ChatConversationService(app.chachanotes_db).get_conversation_tree(
        conversation_id
    )
    resumed_store = ConsoleChatStore(persistence=service)
    resumed = await hydrate_console_session(
        app=SimpleNamespace(chachanotes_db=app.chachanotes_db),
        store=resumed_store,
        conversation_id=conversation_id,
        tree=tree,
        settings=hydrate_console_generation_settings(
            app.app_config, tree["conversation"]
        ).settings,
    )

    assert resumed.settings is not None
    assert resumed.settings.provider == "openai"
    assert resumed.settings.model == "gpt-test"
    assert resumed.settings.temperature == 0.22
    assert resumed.settings.system_prompt == "Canonical system prompt"
    assert resumed.settings.pinned_prefill == "Canonical pinned prefill"


@pytest.mark.asyncio
async def test_first_persist_and_canonical_hydration_round_trip_persona_memory_mode(
    tmp_path,
):
    app = _fixture_app(tmp_path)
    service = ChatPersistenceService(app.chachanotes_db)
    source_store = ConsoleChatStore(persistence=service)
    source = source_store.create_session(
        title="Persona memory",
        settings=default_console_session_settings(app.app_config),
        assistant_kind="persona",
        assistant_id="persona-1",
        persona_memory_mode="read_write",
    )
    user = source_store.append_message(
        source.id,
        role=ConsoleMessageRole.USER,
        content="Remember this",
        persist=True,
    )
    assistant = source_store.append_message(
        source.id,
        role=ConsoleMessageRole.ASSISTANT,
        content="I will",
        persist=True,
    )
    conversation_id = source.persisted_conversation_id
    conversation = app.chachanotes_db.get_conversation_by_id(conversation_id)
    tree = {
        "conversation": conversation,
        "root_threads": [
            {
                "id": user.persisted_message_id,
                "sender": "user",
                "content": "Remember this",
                "children": [
                    {
                        "id": assistant.persisted_message_id,
                        "sender": "assistant",
                        "content": "I will",
                        "children": [],
                    }
                ],
            }
        ],
    }
    resumed_store = ConsoleChatStore(persistence=service)

    resumed = await hydrate_console_session(
        app=SimpleNamespace(chachanotes_db=app.chachanotes_db),
        store=resumed_store,
        conversation_id=conversation_id,
        tree=tree,
        settings=default_console_session_settings(app.app_config),
    )

    assert conversation["persona_memory_mode"] == "read_write"
    assert resumed.assistant_kind == "persona"
    assert resumed.assistant_id == "persona-1"
    assert resumed.assistant_authority_id is None
    assert resumed.persona_memory_mode == "read_write"


@pytest.mark.asyncio
async def test_memory_database_preload_keeps_its_own_connection():
    from tldw_chatbook.DB.ChaChaNotes_DB import CharactersRAGDB

    db = CharactersRAGDB(":memory:", "memory-hydration")
    try:
        service = ChatConversationService(db)
        target = service.create_conversation(
            title="Memory", runtime_backend="local", scope_type="global"
        )
        db.add_message(
            {
                "conversation_id": target,
                "sender": "user",
                "role": "user",
                "content": "Memory input",
            }
        )
        tree = service.get_conversation_tree(target)
        store = ConsoleChatStore(persistence=ChatPersistenceService(db))
        app = SimpleNamespace(chachanotes_db=db)
        prepared = await prepare_console_session_data(
            app=app, store=store, conversation_id=target, tree=tree
        )
        session = await hydrate_console_session(
            app=app,
            store=store,
            conversation_id=target,
            tree=tree,
            settings=None,
            prepared_data=prepared,
        )
        assert store.messages_for_session(session.id)[0].content == "Memory input"
        assert db.get_conversation_by_id(target)["title"] == "Memory"
    finally:
        db.close_connection()


@pytest.mark.bootstrap_profile
@pytest.mark.asyncio
async def test_restore_preserves_empty_parent_transparency() -> None:
    from tldw_chatbook.DB.ChaChaNotes_DB import CharactersRAGDB

    db = CharactersRAGDB(":memory:", "transparent-parent-restore")
    try:
        service = ChatConversationService(db)
        target = service.create_conversation(
            title="Transparent parents", scope_type="global"
        )
        rows = [
            ("root", None, "user", "Root prompt"),
            ("answer", "root", "assistant", "Answer"),
            ("empty-1", "answer", "user", ""),
            ("empty-2", "empty-1", "user", ""),
            ("child", "empty-2", "user", "Follow-up"),
            ("sibling", "answer", "user", "Other branch"),
            ("empty-root", None, "user", ""),
            ("imported-root", "empty-root", "user", "Imported prompt"),
            ("imported-answer", "imported-root", "assistant", "Imported answer"),
        ]
        for index, (message_id, parent, role, content) in enumerate(rows):
            db.add_message(
                dict(
                    id=message_id,
                    conversation_id=target,
                    parent_message_id=parent,
                    sender=role,
                    role=role,
                    content="Historical row"
                    if role == "user" and not content
                    else content,
                    timestamp=f"2026-10-05T00:00:{index:02}.000000+00:00",
                )
            )
            if role == "user" and not content:
                current = db.get_message_by_id(message_id)
                assert db.update_message(
                    message_id,
                    {"content": ""},
                    current["version"],
                    preserve_descendants=True,
                )
                durable = db.get_message_by_id(message_id)
                assert durable["content"] == ""
                assert durable["parent_message_id"] == parent
        tree = service.get_conversation_tree(
            target, depth_cap=10_000, root_limit=10_000
        )
        flattened = console_messages_from_conversation_tree(tree)
        expected_ids = [
            "root",
            "answer",
            "child",
            "sibling",
            "imported-root",
            "imported-answer",
        ]
        assert [node.persisted_message_id for node in flattened] == expected_ids
        expected_content = [
            (node.persisted_message_id, node.content) for node in flattened
        ]
        raw_before = db.get_messages_for_conversation(target)
        app = SimpleNamespace(chachanotes_db=db)
        for prepared in (False, True):
            for leaf, before in (("child", None), (None, "imported-root")):
                assert db.set_conversation_active_cursor(
                    target, active_leaf_message_id=leaf, before_message_id=before
                )
                store = ConsoleChatStore(persistence=ChatPersistenceService(db))
                data = (
                    await prepare_console_session_data(
                        app=app, store=store, conversation_id=target, tree=tree
                    )
                    if prepared
                    else None
                )
                session = await hydrate_console_session(
                    app=app,
                    store=store,
                    conversation_id=target,
                    tree=tree,
                    settings=None,
                    prepared_data=data,
                )
                restored = store.all_messages_for_session(session.id)
                assert [
                    (node.persisted_message_id, node.content) for node in restored
                ] == expected_content
                by_id = {node.persisted_message_id: node for node in restored}
                assert len({node.id for node in restored}) == len(expected_ids)
                if prepared:
                    assert [node.id for node in restored] == [
                        node.id for node in data.nodes
                    ]
                assert by_id["child"].parent_message_id == "answer"
                assert (
                    store._native_parent_by_message[by_id["child"].id]
                    == by_id["answer"].id
                )
                assert by_id["imported-root"].parent_message_id is None
                assert [
                    node.persisted_message_id
                    for node in store.siblings_at(by_id["child"].id)[0]
                ] == ["child", "sibling"]
                if leaf:
                    assert [
                        node.persisted_message_id
                        for node in store.messages_for_session(session.id)
                    ] == ["root", "answer", "child"]
                    assert store.active_leaf(session.id) == by_id["child"].id
                else:
                    assert store.messages_for_session(session.id) == []
                    assert store.active_leaf(session.id) is None
                    assert store.session_draft(session.id) == "Imported prompt"
                assert db.get_conversation_active_cursor(target) == (leaf, before)
                assert db.get_messages_for_conversation(target) == raw_before
    finally:
        db.close_connection()


@pytest.mark.bootstrap_profile
@pytest.mark.asyncio
async def test_restore_refreshes_current_durable_parents() -> None:
    from Tests.Chat.test_console_provider_continuation import _complete_k3_checkpoint
    from Tests.Chat.test_console_thinking_persistence import _thinking
    from tldw_chatbook.Chat.provider_continuation import dump_provider_continuation_json
    from tldw_chatbook.Chat.thinking_blocks import dump_thinking_blocks_json
    from tldw_chatbook.DB.ChaChaNotes_DB import CharactersRAGDB

    checkpoint = _complete_k3_checkpoint("Old answer")
    checkpoint_json = dump_provider_continuation_json(checkpoint)
    thinking_json = dump_thinking_blocks_json(_thinking("Sidecar owner"))
    db = CharactersRAGDB(":memory:", "current-parent-restore")
    try:
        service = ChatConversationService(db)
        target = service.create_conversation(
            title="Current parents", scope_type="global"
        )
        entries = [
            ("root", None, "user", "Root"),
            ("old", "root", "assistant", "Old answer"),
            ("new", "root", "assistant", "New branch"),
            ("new-child", "new", "user", "Keep branch"),
            ("empty-1", "old", "user", ""),
            ("empty-2", "empty-1", "user", ""),
            ("retained-change", "old", "user", "Retained change"),
            ("null-change", "old", "user", "Root change"),
            ("empty-change", "empty-2", "user", "Empty change"),
            ("fanout", "empty-2", "user", "Same empty chain"),
            ("sidecar", "old", "assistant", ""),
            ("sidecar-child", "sidecar", "user", "Sidecar child"),
        ]
        controls = [
            "missing-child",
            "missing-ancestor",
            "cycle",
            "self",
            "back-to-child",
            "content-gap",
            "image-gap",
            "bytearray-gap",
            "state-gap",
            "continuation-gap",
        ]
        entries += [(name, "old", "user", name) for name in controls]
        for index, (message_id, parent, role, content) in enumerate(entries):
            extra = {}
            if message_id == "old":
                extra = dict(
                    provider_continuation_json=checkpoint_json,
                    assistant_generation_state="complete",
                )
            elif message_id == "sidecar":
                extra = dict(thinking_blocks_json=thinking_json)
            elif message_id == "null-change":
                extra = dict(metadata_json='{"root_fork":true}')
            db.add_message(
                dict(
                    id=message_id,
                    conversation_id=target,
                    parent_message_id=parent,
                    sender=role,
                    role=role,
                    content="Historical row"
                    if role == "user" and not content
                    else content,
                    timestamp=f"2026-10-05T00:00:{index:02}.000000+00:00",
                    **extra,
                )
            )
            if role == "user" and not content:
                current = db.get_message_by_id(message_id)
                assert db.update_message(
                    message_id,
                    {"content": ""},
                    current["version"],
                    preserve_descendants=True,
                )
                durable = db.get_message_by_id(message_id)
                assert durable["content"] == ""
                assert durable["parent_message_id"] == parent
        tree = service.get_conversation_tree(
            target, depth_cap=10_000, root_limit=10_000
        )
        store = ConsoleChatStore(persistence=ChatPersistenceService(db))
        app = SimpleNamespace(chachanotes_db=db)
        assert db.set_conversation_active_cursor(
            target, active_leaf_message_id="empty-change", before_message_id=None
        )
        data = await prepare_console_session_data(
            app=app, store=store, conversation_id=target, tree=tree
        )
        assert "sidecar" not in {node.persisted_message_id for node in data.nodes}
        supplied = [
            (node.id, node.persisted_message_id, node.content) for node in data.nodes
        ]
        for message_id, parent in (
            ("retained-change", "new"),
            ("null-change", None),
            ("empty-1", "new"),
        ):
            current = db.get_message_by_id(message_id)
            assert db.update_message(
                message_id,
                {"parent_message_id": parent},
                current["version"],
                preserve_descendants=True,
            )
        raw_before = db.get_messages_for_conversation(target)
        current_rows = [
            dict(row)
            for row in raw_before
            if row["id"] not in {"sidecar", "missing-child"}
        ]
        gaps = {
            "missing-ancestor": "unfetched",
            "cycle": "cycle-1",
            "self": "self",
            "back-to-child": "back-gap",
            "content-gap": "gap-content",
            "image-gap": "gap-image",
            "bytearray-gap": "gap-bytearray",
            "state-gap": "gap-state",
            "continuation-gap": "gap-continuation",
        }
        for row in current_rows:
            if row["id"] in gaps:
                row["parent_message_id"] = gaps[row["id"]]
        current_rows += [
            dict(id="cycle-1", parent_message_id="cycle-2"),
            dict(id="cycle-2", parent_message_id="cycle-1"),
            dict(id="back-gap", parent_message_id="back-to-child"),
            dict(id="gap-content", parent_message_id="new", content="retained"),
            dict(id="gap-image", parent_message_id="new", image_data=b""),
            dict(id="gap-bytearray", parent_message_id="new", image_data=bytearray()),
            dict(
                id="gap-state",
                parent_message_id="new",
                assistant_generation_state="complete",
            ),
            dict(
                id="gap-continuation",
                parent_message_id="new",
                provider_continuation_json="null",
            ),
        ]
        # The real thinking-only owner is appended after its child in the raw pass.
        current_rows += [dict(row) for row in raw_before if row["id"] == "sidecar"]
        data = replace(data, continuation_rows=current_rows)
        session = await hydrate_console_session(
            app=app,
            store=store,
            conversation_id=target,
            tree=tree,
            settings=None,
            prepared_data=data,
        )
        restored = store.all_messages_for_session(session.id)
        by_id = {node.persisted_message_id: node for node in restored}
        assert [
            (node.id, node.persisted_message_id, node.content) for node in restored[:-2]
        ] == supplied
        assert [node.persisted_message_id for node in restored[-2:]] == [
            "gap-continuation",
            "sidecar",
        ]
        warning_owner = restored[-2]
        assert warning_owner.id == "gap-continuation"
        assert warning_owner.role is ConsoleMessageRole.ASSISTANT
        assert warning_owner.content == ""
        assert warning_owner.assistant_generation_state is None
        assert warning_owner.provider_continuation is None
        assert (
            warning_owner.provider_continuation_warning
            == "Exact tool continuation was discarded."
        )
        assert warning_owner.parent_message_id == "new"
        assert store._native_parent_by_message[warning_owner.id] == by_id["new"].id
        for child, parent in {
            "retained-change": "new",
            "null-change": None,
            "empty-change": "new",
            "fanout": "new",
            "sidecar-child": "sidecar",
            **{name: "old" for name in controls if name != "continuation-gap"},
            "continuation-gap": "gap-continuation",
        }.items():
            assert by_id[child].parent_message_id == parent, child
            assert store._native_parent_by_message[by_id[child].id] == (
                by_id[parent].id if parent else None
            ), child
        assert [
            node.persisted_message_id for node in store.messages_for_session(session.id)
        ] == ["root", "new", "empty-change"]
        assert by_id["old"].provider_continuation == checkpoint
        assert by_id["sidecar"].thinking == _thinking("Sidecar owner")
        assert db.get_conversation_active_cursor(target) == ("empty-change", None)
        assert db.get_messages_for_conversation(target) == raw_before
        assert (
            db.get_message_by_id("old")["provider_continuation_json"] == checkpoint_json
        )
        assert db.get_message_by_id("sidecar")["thinking_blocks_json"] == thinking_json
    finally:
        db.close_connection()
