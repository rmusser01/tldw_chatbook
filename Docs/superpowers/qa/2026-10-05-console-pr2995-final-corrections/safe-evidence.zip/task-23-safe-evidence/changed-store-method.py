class Owner:
    def _hydrate_provider_continuations_from_persistence(
        self,
        session_id: str,
        conversation_id: str,
        nodes: list[ConsoleChatMessage],
        *,
        remote_active: bool = False,
        prepared_rows: object = _HYDRATION_NOT_PREPARED,
    ) -> list[ConsoleChatMessage]:
        """Tolerantly attach private checkpoints without exposing their data."""
        if prepared_rows is not _HYDRATION_NOT_PREPARED:
            if prepared_rows is None:
                self._quarantine_continuation_hydration(session_id, conversation_id)
                return nodes
            rows = prepared_rows
        else:
            database = (
                getattr(self.persistence, "db", None) if self.persistence else None
            )
            getter = getattr(database, "get_messages_for_conversation", None)
            if not callable(getter):
                self._quarantine_continuation_hydration(session_id, conversation_id)
                return nodes
            try:
                rows = getter(conversation_id, limit=100_000)
            except Exception:
                logger.warning("Console continuation restore was unavailable.")
                self._quarantine_continuation_hydration(session_id, conversation_id)
                return nodes
        by_persisted_id = {
            node.persisted_message_id: node
            for node in nodes
            if node.persisted_message_id is not None
        }
        for row in rows:
            persisted_id = str(row.get("id") or "")
            safe = read_provider_continuation_json(
                row.get("provider_continuation_json")
            )
            thinking = read_thinking_blocks_json(row.get("thinking_blocks_json"))
            node = by_persisted_id.get(persisted_id)
            if node is None and (
                safe.checkpoint is not None
                or safe.warning
                or thinking.envelope is not None
                or thinking.warning
            ):
                node = ConsoleChatMessage(
                    id=persisted_id,
                    role=ConsoleMessageRole.ASSISTANT,
                    content=str(row.get("content") or ""),
                    persisted_message_id=persisted_id,
                    parent_message_id=(
                        str(row["parent_message_id"])
                        if row.get("parent_message_id") is not None
                        else None
                    ),
                )
                nodes.append(node)
                by_persisted_id[persisted_id] = node
            if node is None:
                continue
            if thinking.envelope is not None:
                node.id = persisted_id
            node.provider_continuation = safe.checkpoint
            node.provider_continuation_warning = safe.warning
            node.provider_continuation_remote = bool(
                safe.checkpoint is not None and remote_active
            )
            version = row.get("version")
            node.provider_continuation_message_version = (
                version if type(version) is int else None
            )
            node.assistant_generation_state = row.get("assistant_generation_state")
            node.provider_continuation_actions_enabled = False
            node.thinking = thinking.envelope
            node.opaque_thinking_json = thinking.opaque_json
            node.thinking_warning = thinking.warning
            node.thinking_actions_enabled = (
                thinking.generation_actions_enabled and thinking.warning is None
            )
        from tldw_chatbook.Chat.console_conversation_hydration import (
            _refresh_console_message_parents,
        )

        _refresh_console_message_parents(nodes, rows)
        return nodes
