import hashlib,json,os,subprocess,sys,tempfile,time,re
from pathlib import Path
W=Path(__file__).resolve().parents[4]; E=Path(__file__).resolve().parent
P='/Users/macbook-dev/Documents/GitHub/tldw_chatbook/.venv/bin/python3.12'
name,*args=sys.argv[1:]; profile=Path(tempfile.mkdtemp(prefix='task23-'+name+'-'))
for part in ('home','config','data'): (profile/part).mkdir(mode=0o700)
(profile/'config/config.toml').write_text('[paths]\ndata_dir = "'+str(profile/'data')+'"\n')
env=dict(os.environ);env.pop('PYTEST_ADDOPTS',None)
overrides=dict(PYTHONPATH=str(W)+os.pathsep+str(E),TLDW_TEST_CONFIG_ROOT=str(profile),HOME=str(profile/'home'),USERPROFILE=str(profile/'home'),XDG_CONFIG_HOME=str(profile/'config'),XDG_DATA_HOME=str(profile/'data'),TLDW_CONFIG_PATH=str(profile/'config/config.toml'),PYTHONDONTWRITEBYTECODE='1',TASK23_CLOSURE_PATH=str(E/(name+'.closure.json')))
env.update(overrides)
cmd=[P,*args]
if args[:2]==['-m','pytest']: cmd+=['-p','no:randomly','-p','task23_closure','--basetemp='+str(profile/'basetemp'),'--junitxml='+str(E/(name+'.xml'))]
paths=['tldw_chatbook/Chat/console_conversation_hydration.py','tldw_chatbook/Chat/console_chat_store.py','Tests/Chat/test_console_conversation_hydration.py']
paths+= [x.split('::')[0] for x in args if x.startswith('Tests/')]
hashes={p:hashlib.sha256((W/p).read_bytes()).hexdigest() for p in paths}
r=dict(argv=cmd,cwd=str(W),environment_overrides=overrides,timeout_seconds=300,sources_sha256=hashes,driver_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),inputs_sha256={arg:hashlib.sha256((W/arg).read_bytes()).hexdigest() for arg in args if (W/arg).is_file()},head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=W,text=True).strip())
(E/(name+'.json')).write_text(json.dumps(r,indent=2));start=time.monotonic()
try:
 result=subprocess.run(cmd,cwd=W,env=env,capture_output=True,timeout=300);out,err,code=result.stdout,result.stderr,result.returncode
except subprocess.TimeoutExpired as exc:out,err,code=exc.stdout or b'',exc.stderr or b'',124
(E/(name+'.stdout')).write_bytes(out);(E/(name+'.stderr')).write_bytes(err)
r.update(exit=code,seconds=time.monotonic()-start,closed=True,source_stable=all(hashlib.sha256((W/p).read_bytes()).hexdigest()==h for p,h in hashes.items()),log_warning_lines=[line for line in (out+err).decode(errors='replace').splitlines() if re.search(r'\b(WARNING|ERROR)\b',line)])
(E/(name+'.json')).write_text(json.dumps(r,indent=2));print(json.dumps(dict(name=name,exit=code,seconds=r['seconds'],source_stable=r['source_stable'])));print(out.decode()[-6500:]);print(err.decode()[-1500:]);sys.exit(code)
