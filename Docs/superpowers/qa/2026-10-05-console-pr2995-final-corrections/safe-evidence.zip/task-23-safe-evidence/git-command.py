import hashlib,json,subprocess,sys,time
from pathlib import Path
W=Path(__file__).resolve().parents[4]; E=Path(__file__).resolve().parent
name,*argv=sys.argv[1:]
owned=['tldw_chatbook/Chat/console_conversation_hydration.py','tldw_chatbook/Chat/console_chat_store.py','Tests/Chat/test_console_conversation_hydration.py']
r={'argv':argv,'cwd':str(W),'timeout_seconds':300,'driver_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'sources_sha256':{p:hashlib.sha256((W/p).read_bytes()).hexdigest() for p in owned},'head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=W,text=True).strip()}
start=time.monotonic();result=subprocess.run(argv,cwd=W,capture_output=True,timeout=300)
(E/(name+'.stdout')).write_bytes(result.stdout);(E/(name+'.stderr')).write_bytes(result.stderr)
r.update(exit=result.returncode,seconds=time.monotonic()-start,closed=True,source_stable=all(hashlib.sha256((W/p).read_bytes()).hexdigest()==v for p,v in r['sources_sha256'].items()))
(E/(name+'.json')).write_text(json.dumps(r,indent=2));print(json.dumps(r,indent=2));print(result.stdout.decode());print(result.stderr.decode());sys.exit(result.returncode)
