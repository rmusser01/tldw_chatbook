"""Check extracted source hashes and syntax; no product imports."""
import ast
import hashlib
import json
from pathlib import Path
root = Path(__file__).resolve().parent
manifest = json.loads((root / 'bundle-manifest.json').read_bytes())
for name, digest in manifest['files'].items():
    path = root / name
    if not path.resolve().is_relative_to(root):
        raise ValueError('Escaping archive member')
    raw = path.read_bytes()
    if hashlib.sha256(raw).hexdigest() != digest:
        raise ValueError('Changed archive member: ' + name)
    if name.endswith('.py'):
        compile(ast.parse(raw), name, 'exec')
print(json.dumps({'members_verified': len(manifest['files']), 'native_launched': False}))
