"""Optional NONQUALIFYING original-code observer. No product imports or wrappers."""

import hashlib
import importlib._bootstrap
import json
import sys
import threading
import time
from pathlib import Path
from types import CodeType, FunctionType


TARGETS = (
    ("Agents.agent_service", "_call_with_timeout::_runner", "tool_worker"),
    (
        "Agents.agent_service",
        "AgentService._run_one::observe_trace_step",
        "trace_persist",
    ),
    ("DB.AgentRuns_DB", "AgentRunsDB.insert_steps_at_indices", "step_write"),
    ("Agents.run_log", "RunLogWriter.append", "run_log_append"),
    (
        "Agents.local_tool_provider",
        "LocalToolProvider._invoke_detailed",
        "local_invoke",
    ),
    ("Agents.local_tool_dispatch", "_invoke_detailed", "local_dispatch"),
    (
        "Agents.local_tool_dispatch",
        "_invoke_detailed::_invoke_allowed",
        "allowed_dispatch",
    ),
    (
        "Agents.local_tool_provider",
        "LocalToolProvider._verdict_for",
        "permission_verdict",
    ),
    (
        "Agents.local_tool_provider",
        "LocalToolProvider._authority_is_valid",
        "authority_check",
    ),
    ("Agents.local_tool_provider", "LocalToolProvider._stale_targets_for", "cas_check"),
    ("MCP.permission_store", "MCPPermissionStore.load", "permission_load"),
    (
        "Tools.workspace_tool_executor",
        "WorkspaceToolExecutor.execute",
        "workspace_execute",
    ),
    (
        "Tools.workspace_tool_executor",
        "WorkspaceToolExecutor._build_request",
        "request_build",
    ),
    (
        "Tools.workspace_tool_executor",
        "WorkspaceToolExecutor._call_context",
        "sensitive_context",
    ),
    ("Tools.workspace_tool_executor", "_parent_read_exclusions", "read_exclusions"),
    ("Utils.sensitive_paths", "resolve_sensitive_context", "sensitive_resolve"),
    ("Tools.local_tool_impls", "resolve_workspace_path", "path_resolve"),
    (
        "Chat.console_interrupt_rounds",
        "build_combined_review_hook::review_tool_calls",
        "combined_review",
    ),
    (
        "Chat.console_local_review_hook",
        "build_local_review_hook::review_tool_calls",
        "local_review",
    ),
    ("Chat.console_interrupt_rounds", "InterruptRoundHost.run_round", "approval_round"),
    (
        "Chat.console_interrupt_rounds",
        "InterruptRoundHost._publish_pending_decision",
        "approval_publish",
    ),
    (
        "Chat.console_interrupt_rounds",
        "InterruptRoundHost._marshal_pending_approval",
        "approval_marshal",
    ),
    (
        "Chat.console_interrupt_rounds",
        "InterruptRoundHost.resolve_pending_approval",
        "approval_resolve",
    ),
    ("Agents.agent_request_execution", "make_call_model::call_model", "model_call"),
    ("Backup_Recovery.storage_admission", "_acquire_storage", "storage_acquire"),
    ("Agents.agent_runtime", "run_agent_loop::trace", "runtime_trace"),
    ("Agents.agent_service", "_call_with_timeout", "tool_timeout_owner"),
    (
        "Agents.agent_service",
        "_call_with_timeout::_admitted_call",
        "tool_admitted_call",
    ),
)
PROCESS_ROLE = "backend"
SCOPED_TARGETS = frozenset({"permission_load", "sensitive_resolve", "path_resolve"})
MAX_CALLS = 2048
MAX_ADMISSIONS = 2048
MAX_ROWS = 16384


def _resolve(module, path):
    value = module
    for name in path.split("."):
        value = vars(value).get(name)
        if value is None:
            return None
    if isinstance(value, (staticmethod, classmethod)):
        value = value.__func__
    return value


def _pin(function):
    return (
        function.__code__,
        function.__globals__,
        function.__defaults__,
        function.__kwdefaults__,
        tuple((function.__kwdefaults__ or {}).items()),
        function.__closure__,
        tuple(cell.cell_contents for cell in (function.__closure__ or ())),
        vars(function).get("__wrapped__"),
    )


def _same(left, right):
    return (
        all(left[index] is right[index] for index in (0, 1, 2, 3, 5, 7))
        and len(left[4]) == len(right[4])
        and all(
            a[0] == b[0] and a[1] is b[1]
            for a, b in zip(left[4], right[4], strict=True)
        )
        and len(left[6]) == len(right[6])
        and all(a is b for a, b in zip(left[6], right[6], strict=True))
    )


class Observer:
    PREFIX = "TOOL_FOREGROUND"

    def __init__(self, stream, pins, *, targets=TARGETS, role=PROCESS_ROLE):
        self.targets, self.role = targets, role
        self.context = {}
        self.handovers = {}
        self.stream, self.pins = stream, pins
        self.origin = time.perf_counter()
        self.admissions = {}
        self.admission_sequence = 0
        self.records, self.active, self.counts, self.threads = {}, {}, {}, {}
        self.seen, self.rejected = set(), set()
        self.errors = self.sequence = 0
        self.rows = 0
        self.truncated = False
        self.closed = False
        self.discovery = importlib._bootstrap._find_and_load.__code__
        monitor = sys.monitoring
        self.slot = next((n for n in (3, 4, 5, 2) if monitor.get_tool(n) is None), None)
        if self.slot is None:
            raise RuntimeError("agent_prefix_no_monitoring_slot")
        monitor.use_tool_id(self.slot, "lab-tool-foreground")
        events = monitor.events
        for event, callback in (
            (events.PY_START, self.start),
            (events.PY_RETURN, self.finish),
            (events.PY_YIELD, self.pause),
            (events.PY_RESUME, self.resume),
            (events.PY_UNWIND, self.unwind),
        ):
            monitor.register_callback(self.slot, event, callback)
        monitor.set_local_events(self.slot, self.discovery, events.PY_RETURN)
        self.emit(
            event="installed",
            qualifying=False,
            monotonic_origin=self.origin,
            process_role=self.role,
        )
        self.discover()

    def emit(self, **row):
        if self.rows >= MAX_ROWS and row.get("event") != "summary":
            self.truncated = True
            return
        self.rows += 1
        try:
            self.stream.write(
                self.PREFIX + " " + json.dumps(row, sort_keys=True) + "\n"
            )
            self.stream.flush()
        except Exception:
            self.errors += 1

    def discover(self):
        if self.closed:
            return
        for suffix, path, label in self.targets:
            if label in self.seen or label in self.rejected:
                continue
            module = sys.modules.get(
                suffix if suffix.startswith("Tests.") else "tldw_chatbook." + suffix
            )
            if module is None:
                continue
            owner_path, _, child_path = path.partition("::")
            function = _resolve(module, owner_path)
            if type(function) is not FunctionType:
                continue  # A module can still be executing its original body.
            try:
                source = Path(vars(module)["__file__"])
                if hashlib.sha256(source.read_bytes()).hexdigest() != self.pins[suffix]:
                    self.rejected.add(label)
                    self.emit(event="source_refused", producer=label)
                    continue
                chain = []
                while type(function) is FunctionType and len(chain) < 8:
                    chain.append((function, _pin(function)))
                    nested = vars(function).get("__wrapped__")
                    if nested is None:
                        break
                    function = nested
                if type(function) is not FunctionType or len(chain) == 8:
                    raise ValueError("unsupported_definition")
                code = function.__code__
                for child in child_path.split(".") if child_path else ():
                    matches = [
                        value
                        for value in code.co_consts
                        if type(value) is CodeType and value.co_name == child
                    ]
                    if len(matches) != 1:
                        raise ValueError("ambiguous_nested_code")
                    code = matches[0]
                if code in self.records:
                    raise ValueError("ambiguous_code")
                self.records[code] = (label, module, owner_path, chain)
                events = sys.monitoring.events
                flags = (
                    events.PY_START
                    | events.PY_RETURN
                    | events.PY_YIELD
                    | events.PY_RESUME
                )
                sys.monitoring.set_local_events(self.slot, code, flags)
                self.seen.add(label)
                self.emit(event="registered", producer=label)
            except Exception:
                self.rejected.add(label)
                self.emit(event="registration_refused", producer=label)

    def original(self, record):
        _label, module, path, chain = record
        return (
            sys.modules.get(vars(module)["__name__"]) is module
            and _resolve(module, path) is chain[0][0]
            and all(_same(pin, _pin(function)) for function, pin in chain)
        )

    def frame(self, code):
        frame = sys._getframe(1)
        for _ in range(96):
            if frame is None or frame.f_code is code:
                return frame
            frame = frame.f_back
        return None

    def ancestors(self, frame):
        """Actual synchronous retained invocations; never infer a worker parent."""
        rows = []
        ancestor = frame.f_back
        for _ in range(96):
            if ancestor is None:
                break
            row = self.active.get(id(ancestor))
            if row is not None and row["frame"] is ancestor:
                record = self.records[ancestor.f_code]
                if not self.original(record):
                    raise ValueError("ancestor_definition_changed")
                rows.append((row, ancestor.f_lineno))
            ancestor = ancestor.f_back
        return rows

    def storage(self, frame, action, now, cpu):
        """Time actual admission only under a retained foreground invocation."""
        key = id(frame)
        if action == "start":
            ancestors = self.ancestors(frame)
            if not ancestors:
                return
            if self.admission_sequence >= MAX_ADMISSIONS:
                self.emit(event="limit", limit=MAX_ADMISSIONS, category="admissions")
                self.truncated = True
                self.close()
                return
            self.admission_sequence += 1
            for row, _line in ancestors:
                row["acquisitions"] += 1
            nearest = ancestors[0][0]
            self.admissions[key] = {
                "frame": frame,
                "admission": self.admission_sequence,
                "call": nearest["call"],
                "thread": nearest["thread"],
                "start": now,
                "cpu": cpu,
                "context": dict(nearest["context"]),
            }
            # Each stack member is an exact monitored original code object.
            # Deliberately omit arbitrary intermediate frames and all locals.
            self.emit(
                event="storage_start",
                admission=self.admission_sequence,
                call=nearest["call"],
                thread=nearest["thread"],
                wall=now - self.origin,
                context=dict(nearest["context"]),
                stack=[
                    {
                        "call": row["call"],
                        "producer": row["producer"],
                        "owner": row["owner"],
                        "function": row["function"],
                        "line": line,
                    }
                    for row, line in ancestors[:16]
                ],
            )
            sys.monitoring.set_events(self.slot, sys.monitoring.events.PY_UNWIND)
            return
        row = self.admissions.pop(key, None)
        if row is None:
            return
        if row["frame"] is not frame or action not in {"return", "unwind"}:
            raise ValueError("storage_invocation_changed")
        self.emit(
            event="storage_" + action,
            admission=row["admission"],
            call=row["call"],
            thread=row["thread"],
            wall=now - self.origin,
            elapsed_wall=now - row["start"],
            thread_cpu=cpu - row["cpu"],
            context=row["context"],
        )
        if not self.active and not self.admissions:
            sys.monitoring.set_events(self.slot, 0)

    def metadata(self, record, frame, now):
        label = record[0]
        if label not in {
            "runtime_trace",
            "journey_mark",
            "tool_timeout_owner",
            "tool_admitted_call",
            "workspace_execute",
        }:
            return
        values = frame.f_locals
        thread = threading.get_ident()
        if label == "tool_timeout_owner":
            function = values.get("fn")
            if type(function) is FunctionType:
                if id(function) in self.handovers:
                    raise ValueError("ambiguous_actual_tool_callable")
                self.handovers[id(function)] = (
                    function,
                    frame,
                    dict(self.context.get(thread, {})),
                )
            return
        if label == "tool_admitted_call":
            function = values.get("fn")
            retained = self.handovers.get(id(function))
            if retained is not None and retained[0] is function:
                parent = self.active.get(id(retained[1]))
                if parent is not None and parent["frame"] is retained[1]:
                    owner = self.records[retained[1].f_code]
                    if not self.original(owner):
                        raise ValueError("tool_owner_definition_changed")
                    self.context[thread] = dict(retained[2])
            return
        if label == "workspace_execute":
            operation = values.get("operation")
            if type(operation) is str and operation in {
                "fs_list",
                "fs_read",
                "fs_edit",
                "git_diff",
            }:
                current = dict(self.context.get(thread, {}))
                current["operation"] = operation
                self.context[thread] = current
            return
        event = values.get("kind") if label == "runtime_trace" else values.get("event")
        allowed = {
            "model_request_started",
            "model_response_completed",
            "tool_proposed",
            "approval_requested",
            "approval_approved",
            "tool_execution_started",
            "tool_succeeded",
            "tool_failed",
            "agent_run_created",
            "agent_run_started",
            "agent_run_completed",
            "send",
            "reply_completed",
            "reply_seen",
            "reply_verified",
            "http_send",
            "http_response_sent",
            "disclosure_click",
            "disclosure_observed",
            "approval_click",
            "approval_observed",
            "painted_approval",
        }
        if type(event) is not str or event not in allowed:
            return
        data = values.get("kw") if label == "runtime_trace" else values.get("data")
        if type(data) is not dict:
            return
        tool = data.get("tool_name") if label == "runtime_trace" else data.get("tool")
        call = data.get("call_id") if label == "runtime_trace" else data.get("call")
        tools = {
            "find_tools",
            "load_tools",
            "fs_list",
            "fs_read",
            "fs_edit",
            "git_diff",
        }
        calls = {f"uat-dev-{index}" for index in range(5)} | {
            f"uat-call-{index}" for index in range(5)
        }
        context = {"phase": event}
        if type(tool) is str and tool in tools:
            context["tool"] = tool
        if type(call) is str and call in calls:
            context["fixture_call"] = call
        if label == "journey_mark":
            trace = values.get("self")
            # Only original fixture's fixed turn and numeric clock; no events/body lookup.
            state = vars(trace)
            turn, origin = state.get("turn"), state.get("start")
            if type(turn) is str and turn in {"setup", "readme", "edit"}:
                context["journey"] = turn
            if type(origin) is float:
                context["trace_origin"] = origin
        thread = threading.get_ident()
        self.context[thread] = context
        self.threads.setdefault(thread, len(self.threads) + 1)
        self.emit(
            event="milestone",
            producer=label,
            thread=self.threads[thread],
            wall=now - self.origin,
            **context,
        )

    def callback(self, code, action):
        if self.closed or code not in self.records:
            return
        try:
            record = self.records[code]
            if not self.original(record):
                self.errors += 1
                self.emit(event="definition_refused", producer=record[0])
                self.close()
                return
            frame = self.frame(code)
            if frame is None:
                raise ValueError("missing_original_frame")
            if frame.f_globals is not record[3][-1][0].__globals__:
                raise ValueError("foreign_original_globals")
            key, now, cpu = id(frame), time.perf_counter(), time.thread_time()
            if action == "start":
                self.metadata(record, frame, now)
            if record[0] == "storage_acquire":
                self.storage(frame, action, now, cpu)
                return
            if action == "start":
                if record[0] in SCOPED_TARGETS and not self.ancestors(frame):
                    return
                if self.sequence >= MAX_CALLS:
                    self.emit(event="limit", limit=MAX_CALLS, category="calls")
                    self.truncated = True
                    self.close()
                    return
                self.sequence += 1
                label = record[0]
                self.counts[label] = self.counts.get(label, 0) + 1
                thread = threading.get_ident()
                self.threads.setdefault(thread, len(self.threads) + 1)
                ancestor, parent = frame.f_back, None
                while ancestor is not None:
                    if id(ancestor) in self.active:
                        parent = self.active[id(ancestor)]["call"]
                        break
                    ancestor = ancestor.f_back
                self.active[key] = {
                    "frame": frame,
                    "call": self.sequence,
                    "producer": label,
                    "owner": vars(record[1])["__name__"],
                    "function": record[2],
                    "context": dict(self.context.get(thread, {})),
                    "thread": self.threads[thread],
                    "parent_call": parent,
                    "start": now,
                    "segment": now,
                    "cpu": cpu,
                    "active_wall": 0.0,
                    "active_cpu": 0.0,
                    "acquisitions": 0,
                }
                self.emit(
                    event="start",
                    call=self.sequence,
                    producer=label,
                    owner=vars(record[1])["__name__"],
                    function=record[2],
                    line=frame.f_lineno,
                    context=self.active[key]["context"],
                    count=self.counts[label],
                    parent_call=parent,
                    thread=self.threads[thread],
                    wall=now - self.origin,
                    thread_cpu=cpu,
                )
                # PY_UNWIND cannot be local on Python 3.12. Filter global events.
                sys.monitoring.set_events(self.slot, sys.monitoring.events.PY_UNWIND)
                return
            row = self.active.get(key)
            if row is None:
                return
            if action == "resume":
                row["segment"], row["cpu"] = now, cpu
                return
            if row["segment"] is not None:
                row["active_wall"] += now - row["segment"]
                row["active_cpu"] += cpu - row["cpu"]
                row["segment"] = None
            if action == "yield":
                self.emit(
                    event="yield",
                    call=row["call"],
                    producer=row["producer"],
                    wall=now - self.origin,
                    thread_cpu=cpu,
                    elapsed_wall=now - row["start"],
                    active_wall=row["active_wall"],
                    active_thread_cpu=row["active_cpu"],
                )
                return
            self.emit(
                event=action,
                call=row["call"],
                producer=row["producer"],
                owner=row["owner"],
                function=row["function"],
                line=frame.f_lineno,
                context=row["context"],
                current_context=dict(self.context.get(threading.get_ident(), {})),
                thread=row["thread"],
                parent_call=row["parent_call"],
                wall=now - self.origin,
                thread_cpu=cpu,
                elapsed_wall=now - row["start"],
                active_wall=row["active_wall"],
                active_thread_cpu=row["active_cpu"],
                storage_acquisitions_inclusive=row["acquisitions"],
            )
            del self.active[key]
            if row["producer"] == "tool_timeout_owner":
                for handover_key, retained in tuple(self.handovers.items()):
                    if retained[1] is frame:
                        del self.handovers[handover_key]
            if row["producer"] == "tool_worker":
                self.context.pop(threading.get_ident(), None)
            if not self.active and not self.admissions:
                sys.monitoring.set_events(self.slot, 0)
        except Exception:
            self.errors += 1

    def start(self, code, offset):
        self.callback(code, "start")

    def finish(self, code, offset, result):
        if code is self.discovery:
            self.discover()
        else:
            self.callback(code, "return")

    def pause(self, code, offset, result):
        self.callback(code, "yield")

    def resume(self, code, offset):
        self.callback(code, "resume")

    def unwind(self, code, offset, error):
        self.callback(code, "unwind")

    def close(self):
        if self.closed:
            return
        self.closed = True
        monitor = sys.monitoring
        monitor.set_events(self.slot, 0)
        for code in (*self.records, self.discovery):
            monitor.set_local_events(self.slot, code, 0)
        for name in ("PY_START", "PY_RETURN", "PY_YIELD", "PY_RESUME", "PY_UNWIND"):
            monitor.register_callback(self.slot, getattr(monitor.events, name), None)
        monitor.free_tool_id(self.slot)
        self.emit(
            event="summary",
            calls=self.counts,
            registered=sorted(self.seen),
            source_refused=sorted(self.rejected),
            errors=self.errors,
            unfinished=len(self.active),
            admissions=self.admission_sequence,
            unfinished_admissions=len(self.admissions),
            truncated=self.truncated,
            qualifying=False,
        )
        self.active.clear()
        self.admissions.clear()
        self.context.clear()
        self.handovers.clear()


def install(stream=None):
    """Return cleanup for an explicitly disposable diagnostic interpreter only."""
    pins = json.loads(Path(__file__).with_name("source-pins.json").read_text())
    observer = Observer(sys.stderr if stream is None else stream, pins)
    return observer.close
