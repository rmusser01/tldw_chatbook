"""Read a finished diagnostic run; never execute product code or infer receipts."""

import argparse
import json
from pathlib import Path


def summarize(root):
    timings_file = root / "timings.json"
    timings = json.loads(timings_file.read_bytes()) if timings_file.is_file() else {}
    result = {
        "qualifying": False,
        "original_status": timings.get("status"),
        "same_run_total_seconds": timings.get("original_duration_seconds"),
        "journeys": {
            name: {
                key: turn.get(key)
                for key in (
                    "completed_s",
                    "original_adjusted_s",
                    "verified_s",
                    "common_adjusted_reply_seen_s",
                    "approval_wait_s",
                )
            }
            for name, turn in timings.get("turns", {}).items()
        },
        "processes": [],
    }
    for path in sorted((root / "lab-observer").glob("*.jsonl")):
        rows = [
            json.loads(line.removeprefix("TOOL_FOREGROUND "))
            for line in path.read_text(encoding="utf-8").splitlines()
            if line.startswith("TOOL_FOREGROUND ")
        ]
        if not rows:
            continue
        installed = next((row for row in rows if row["event"] == "installed"), {})
        summary = next(
            (row for row in reversed(rows) if row["event"] == "summary"), None
        )
        starts = {row["call"]: row for row in rows if row["event"] == "start"}
        ends = {
            row["call"]: row for row in rows if row["event"] in {"return", "unwind"}
        }
        admissions = {
            row["admission"]: row for row in rows if row["event"] == "storage_start"
        }
        admission_ends = {
            row["admission"]: row
            for row in rows
            if row["event"] in {"storage_return", "storage_unwind"}
        }
        calls = []
        for number, row in starts.items():
            context = row.get("context", {})
            if (
                context.get("fixture_call") != "uat-dev-3"
                and context.get("operation") != "fs_edit"
            ):
                continue
            end = ends.get(number, {})
            calls.append(
                {
                    "invocation": number,
                    "producer": row["producer"],
                    "owner": row["owner"],
                    "function": row["function"],
                    "entry_line": row["line"],
                    "return_line": end.get("line"),
                    "thread": row["thread"],
                    "parent_call": row["parent_call"],
                    "entry": row["wall"],
                    "return": end.get("wall"),
                    "elapsed_wall": end.get("elapsed_wall"),
                    "active_thread_cpu": end.get("active_thread_cpu"),
                    "outcome": end.get("event"),
                    "context": context,
                }
            )
        storage = []
        for number, row in admissions.items():
            context = row.get("context", {})
            if (
                context.get("fixture_call") != "uat-dev-3"
                and context.get("operation") != "fs_edit"
            ):
                continue
            end = admission_ends.get(number, {})
            storage.append(
                {
                    "admission": number,
                    "call": row["call"],
                    "thread": row["thread"],
                    "entry": row["wall"],
                    "elapsed_wall": end.get("elapsed_wall"),
                    "outcome": end.get("event"),
                    "stack": row["stack"],
                    "context": context,
                }
            )
        execution = next(
            (
                row["wall"]
                for row in rows
                if row["event"] == "milestone"
                and row.get("phase") == "tool_execution_started"
                and row.get("fixture_call") == "uat-dev-3"
            ),
            None,
        )
        executor = next(
            (row["entry"] for row in calls if row["producer"] == "workspace_execute"),
            None,
        )
        result["processes"].append(
            {
                "role": installed.get("process_role"),
                "summary": summary,
                "complete_observation": summary is not None
                and not any(
                    summary.get(key)
                    for key in (
                        "errors",
                        "source_refused",
                        "unfinished",
                        "unfinished_admissions",
                        "truncated",
                    )
                ),
                "fs_edit_pre_executor_seconds": None
                if execution is None or executor is None
                else executor - execution,
                "fs_edit_calls": calls,
                "fs_edit_admissions": storage,
            }
        )
    return result


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("run_directory", type=Path)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    data = summarize(args.run_directory.resolve(strict=True))
    with args.output.open("x", encoding="utf-8") as stream:
        json.dump(data, stream, indent=2)
        stream.write("\n")
