"""Bounded early metadata until the original guard creates its output directory."""

import os
from pathlib import Path


_owned = []


class DeferredStream:
    def __init__(self, prefix):
        if prefix not in {"tool-foreground", "tool-approval"}:
            raise ValueError("Unknown fixed diagnostic")
        self.prefix, self.stream, self.pending = prefix, None, []
        self.bytes = 0

    def write(self, text):
        if self.stream is not None:
            return self.stream.write(text)
        self.bytes += len(text.encode("utf-8"))
        if self.bytes > 4 * 1024 * 1024:
            raise RuntimeError("Parent diagnostic buffer exceeded its fixed limit")
        self.pending.append(text)
        return len(text)

    def flush(self):
        directory = os.environ.get("TLDW_TEST_LAB_OUTPUT")
        if self.stream is None and directory and Path(directory).is_dir():
            self.stream = (
                Path(directory) / f"{self.prefix}-ui-{os.getpid()}.jsonl"
            ).open("x", encoding="utf-8")
            self.stream.writelines(self.pending)
            self.pending.clear()
        if self.stream is not None:
            self.stream.flush()

    def close(self):
        self.flush()
        if self.stream is not None:
            self.stream.close()


def start_parent(install, prefix):
    stream = DeferredStream(prefix)
    _owned.append((install(stream), stream))


def close_parent():
    failed = False
    try:
        for close, stream in reversed(_owned):
            try:
                close()
            except Exception:
                failed = True
            try:
                stream.close()
            except Exception:
                failed = True
    finally:
        _owned.clear()
    if failed:
        raise RuntimeError("foreground_diagnostic_cleanup_failed") from None
