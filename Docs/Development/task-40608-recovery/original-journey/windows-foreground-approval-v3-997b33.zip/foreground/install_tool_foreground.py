"""Install foreground diagnostics on a fresh original local/process replay."""

import argparse
import ast
import importlib.util
import json
from pathlib import Path


def install(root, replay_tools, source, approval=None, *, check_only=False):
    root, replay_tools, source = (
        path.resolve(strict=True) for path in (root, replay_tools, source)
    )
    spec = importlib.util.spec_from_file_location(
        "_foreground_replay", replay_tools / "replay.py"
    )
    replay = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(replay)
    manifest = replay.verify(root)
    if (root / "replay-runs").exists() or (root / "tool-foreground-preimage").exists():
        raise ValueError("Use a fresh unused disposable replay")
    route = manifest.get("lab_observer", {}).get("route")
    if route not in {"local", "process"}:
        raise ValueError("Expected original guarded local or process replay")
    plugin_name, config = "task40608_lab_observer.py", "task40608-lab-observer.json"
    plugin = (root / plugin_name).read_text(encoding="utf-8-sig").replace("\r\n", "\n")
    settings = json.loads((root / config).read_bytes())
    if settings["route"] != route:
        raise ValueError("Original route disagrees with manifest")
    files, all_pins = {}, {}

    def package(directory, name, role):
        pins = json.loads((directory / "source-pins.json").read_bytes())
        for module, digest in pins.items():
            path = module.replace(".", "/") + ".py"
            if not module.startswith("Tests."):
                path = "tldw_chatbook/" + path
            if (
                replay.sha((root / path).read_bytes()) != digest
                or manifest["candidate_sources"].get(path) != digest
            ):
                raise ValueError("Foreground source changed: " + module)
            settings["sources"][path] = digest
        all_pins[role] = pins
        names = ["observer.py", "source-pins.json"]
        if (directory / "targets.json").is_file():
            json.loads((directory / "targets.json").read_bytes())
            names.append("targets.json")
        for filename in names:
            data = (directory / filename).read_bytes()
            if filename.endswith(".py"):
                ast.parse(data)
            files[name + "/" + filename] = data

    package(
        source / ("baseline" if route == "local" else "parent"),
        "task40608_tool_foreground",
        "local" if route == "local" else "ui",
    )
    files["task40608_tool_foreground/deferred.py"] = (
        source / "deferred.py"
    ).read_bytes()
    anchor = "    _state.ui_hooks(_original_guard(settings))\n"
    if plugin.count(anchor) != 1 or "task40608_tool_foreground" in plugin:
        raise ValueError("Original parent configure boundary changed")
    parent_lines = [
        "    from task40608_tool_foreground.deferred import start_parent",
        "    from task40608_tool_foreground.observer import install as install_tool_foreground",
        "    start_parent(install_tool_foreground, 'tool-foreground')",
    ]
    if approval is not None:
        approval = approval.resolve(strict=True)
        package(approval, "task40608_tool_approval", "approval_ui")
        parent_lines += [
            "    from task40608_tool_approval.observer import install as install_tool_approval",
            "    start_parent(install_tool_approval, 'tool-approval')",
        ]
    plugin = plugin.replace(anchor, anchor + "\n".join(parent_lines) + "\n", 1)
    # Preserve all original finish checks even if diagnostic cleanup fails.
    tree = ast.parse(plugin)
    finish = next(
        node
        for node in tree.body
        if isinstance(node, ast.FunctionDef) and node.name == "pytest_sessionfinish"
    )
    lines = plugin.splitlines(keepends=True)
    guard = finish.body[0]
    if not isinstance(guard, ast.If) or ast.unparse(guard.test) != "_state is None":
        raise ValueError("Original finish guard changed")
    tail = "".join(lines[guard.end_lineno : finish.end_lineno])
    replacement = (
        "    from task40608_tool_foreground.deferred import close_parent\n"
        "    try:\n        close_parent()\n    finally:\n"
        + "".join(
            "    " + line if line.strip() else line
            for line in tail.splitlines(keepends=True)
        )
    )
    plugin = (
        "".join(lines[: guard.end_lineno])
        + replacement
        + "".join(lines[finish.end_lineno :])
    )
    if route == "process":
        command = 'runpy.run_module("tldw_chatbook.Chat.console_execution_worker", run_name="__main__")'
        if manifest.get("agent_prefix_diagnostic"):
            for marker in (
                "from task40608_agent_prefix.observer import install as install_agent_prefix",
                "close_agent_prefix = install_agent_prefix(prefix_file)",
                "close_agent_prefix()",
            ):
                if plugin.count(marker) != 1:
                    raise ValueError("Existing backend observer ownership changed")
            package(source, "task40608_agent_prefix", "backend")
        else:
            package(source, "task40608_tool_foreground_backend", "backend")
            [line] = [
                line
                for line in plugin.splitlines(keepends=True)
                if line.strip() == command
            ]
            indent = line[: len(line) - len(line.lstrip())]
            body = [
                "from task40608_tool_foreground_backend.observer import install as install_foreground_backend",
                "with (Path(os.environ['TLDW_TEST_LAB_OUTPUT']) / f'tool-foreground-backend-{os.getpid()}.jsonl').open('x', encoding='utf-8') as foreground_file:",
                "    close_foreground_backend = install_foreground_backend(foreground_file)",
                "    try:",
                "        " + command,
                "    finally:",
                "        close_foreground_backend()",
            ]
            plugin = plugin.replace(
                line, "".join(indent + item + "\n" for item in body), 1
            )
        if approval is not None and (approval / "backend").is_dir():
            package(
                approval / "backend",
                "task40608_tool_approval_backend",
                "approval_backend",
            )
            [line] = [
                line
                for line in plugin.splitlines(keepends=True)
                if line.strip() == command
            ]
            indent = line[: len(line) - len(line.lstrip())]
            body = [
                "from task40608_tool_approval_backend.observer import install as install_approval_backend",
                "with (Path(os.environ['TLDW_TEST_LAB_OUTPUT']) / f'tool-approval-backend-{os.getpid()}.jsonl').open('x', encoding='utf-8') as approval_file:",
                "    close_approval_backend = install_approval_backend(approval_file)",
                "    try:",
                "        " + command,
                "    finally:",
                "        close_approval_backend()",
            ]
            plugin = plugin.replace(
                line, "".join(indent + item + "\n" for item in body), 1
            )
    ast.parse(plugin)
    files[plugin_name] = plugin.encode("utf-8")
    settings["sources"].update({name: replay.sha(data) for name, data in files.items()})
    files[config] = replay.encoded(settings)
    installed_tool = replay_tools / Path(__file__).name
    if installed_tool.read_bytes() != Path(__file__).read_bytes():
        raise ValueError(
            "Copy this exact installer to the existing replay-tools directory first"
        )
    if check_only:
        print("Verified foreground install preflight; no files changed; NONQUALIFYING")
        return
    backup = root / "tool-foreground-preimage"
    backup.mkdir()
    for name in (*files, "replay-manifest.json"):
        if (root / name).exists():
            destination = backup / name
            destination.parent.mkdir(parents=True, exist_ok=True)
            destination.write_bytes((root / name).read_bytes())
    for name, data in files.items():
        replay.atomic(root / name, data)
        manifest["candidate_sources"][name] = manifest["diagnostic_sources"][name] = (
            replay.sha(data)
        )
    manifest["tool_foreground_diagnostic"] = {
        "qualifying": False,
        "product_sources_changed": False,
        "route": route,
        "roles": list(all_pins),
        "inputs": all_pins,
        "original_manifest_sha256": replay.sha(
            (backup / "replay-manifest.json").read_bytes()
        ),
    }
    manifest["tool_sha256"][Path(__file__).name] = replay.sha(
        installed_tool.read_bytes()
    )
    replay.atomic(root / "replay-manifest.json", replay.encoded(manifest))
    replay.verify(root)
    print(
        "Verified NONQUALIFYING foreground observer; original product/QA/route unchanged"
    )


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--candidate-directory", type=Path, required=True)
    parser.add_argument("--replay-tools", type=Path, required=True)
    parser.add_argument("--observer-source", type=Path, required=True)
    parser.add_argument("--approval-observer-source", type=Path)
    parser.add_argument("--check-only", action="store_true")
    args = parser.parse_args()
    install(
        args.candidate_directory,
        args.replay_tools,
        args.observer_source,
        args.approval_observer_source,
        check_only=args.check_only,
    )
