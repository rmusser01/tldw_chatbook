"""Exercise diagnostic bookkeeping only, without product imports/monitoring."""

import importlib.util
import io
import json
from pathlib import Path
from types import SimpleNamespace


path = Path(__file__).with_name("observer.py")
spec = importlib.util.spec_from_file_location("_foreground_offline", path)
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)
events = []
module.sys = SimpleNamespace(
    monitoring=SimpleNamespace(
        events=SimpleNamespace(PY_UNWIND=1),
        set_events=lambda *args: events.append(args),
    )
)
observer = module.Observer.__new__(module.Observer)
observer.stream = io.StringIO()
observer.origin = 10.0
observer.admissions = {}
observer.admission_sequence = 0
observer.records = {}
observer.rows = observer.errors = 0
observer.truncated = observer.closed = False
observer.slot = 3
observer.original = lambda _record: True
outer = SimpleNamespace(f_code=object(), f_lineno=101, f_back=None)
inner = SimpleNamespace(f_code=object(), f_lineno=202, f_back=outer)
storage = SimpleNamespace(f_code=object(), f_lineno=303, f_back=inner)


def row(frame, number):
    observer.records[frame.f_code] = ("test", None, None, None)
    return {
        "frame": frame,
        "call": number,
        "producer": "test",
        "thread": 1,
        "owner": "fixed.owner",
        "function": "fixed.function",
        "context": {},
        "acquisitions": 0,
    }


observer.active = {id(outer): row(outer, 1), id(inner): row(inner, 2)}
observer.storage(storage, "start", 11.0, 5.0)
observer.storage(storage, "return", 13.5, 5.2)
observer.storage(storage, "start", 14.0, 6.0)
observer.storage(storage, "unwind", 15.0, 6.1)
recorded = [
    json.loads(line.split(" ", 1)[1])
    for line in observer.stream.getvalue().splitlines()
]
assert [item["event"] for item in recorded] == [
    "storage_start",
    "storage_return",
    "storage_start",
    "storage_unwind",
]
assert recorded[0]["call"] == 2
assert [item["call"] for item in recorded[0]["stack"]] == [2, 1]
assert recorded[1]["admission"] == recorded[0]["admission"]
assert recorded[1]["elapsed_wall"] == 2.5
assert recorded[3]["elapsed_wall"] == 1.0
assert not observer.admissions
assert all(item["acquisitions"] == 2 for item in observer.active.values())
# An admission without a real retained synchronous ancestor is not assigned to
# the most recent call on some other thread.
observer.active.clear()
observer.storage(storage, "start", 20.0, 8.0)
assert observer.admission_sequence == 2
assert not observer.admissions
observer.context, observer.handovers, observer.threads = {}, {}, {}
thread = [10]
module.threading = SimpleNamespace(get_ident=lambda: thread[0])


def actual_callable():
    return None


trace_frame = SimpleNamespace(
    f_locals={
        "kind": "tool_execution_started",
        "kw": {
            "tool_name": "fs_edit",
            "call_id": "uat-dev-3",
            "args": object(),
            "summary": object(),
        },
    }
)
observer.metadata(("runtime_trace",), trace_frame, 30.0)
assert observer.context[10] == {
    "phase": "tool_execution_started",
    "tool": "fs_edit",
    "fixture_call": "uat-dev-3",
}
owner_frame = SimpleNamespace(f_locals={"fn": actual_callable}, f_code=object())
observer.metadata(("tool_timeout_owner",), owner_frame, 31.0)
observer.active[id(owner_frame)] = {"frame": owner_frame}
observer.records[owner_frame.f_code] = ("tool_timeout_owner",)
thread[0] = 20
worker_frame = SimpleNamespace(f_locals={"fn": actual_callable})
observer.metadata(("tool_admitted_call",), worker_frame, 32.0)
assert observer.context[20] == observer.context[10]
# A physically late worker with no retained original owning invocation gets no
# borrowed context, even though the callable reference still exists.
observer.active.clear()
observer.context.pop(20)
observer.metadata(("tool_admitted_call",), worker_frame, 33.0)
assert 20 not in observer.context
assert "args" not in observer.stream.getvalue()
assert "summary" not in observer.stream.getvalue()
print(
    json.dumps(
        {
            "bookkeeping_cases": 6,
            "native_executed": False,
            "product_imported": False,
            "monitoring_installed": False,
        }
    )
)
