"""Verify target/pin and privacy boundaries without importing any product code."""

import ast
import hashlib
import json
import sys
from pathlib import Path
from types import CodeType


def assignments(tree):
    return {
        target.id: node.value
        for node in tree.body
        if isinstance(node, ast.Assign)
        for target in node.targets
        if isinstance(target, ast.Name)
    }


def verify(directory, repository, fixture):
    observer = directory / "observer.py"
    text = observer.read_text(encoding="utf-8")
    tree = ast.parse(text)
    compile(tree, str(observer), "exec")
    targets = ast.literal_eval(assignments(tree)["TARGETS"])
    pins = json.loads((directory / "source-pins.json").read_bytes())
    assert len({target[2] for target in targets}) == len(targets)
    assert set(pins) == {target[0] for target in targets}
    for suffix, qualified, _label in targets:
        path = (
            fixture / (suffix.replace(".", "/") + ".py")
            if suffix.startswith("Tests.")
            else repository / "tldw_chatbook" / (suffix.replace(".", "/") + ".py")
        )
        content = path.read_bytes()
        assert hashlib.sha256(content).hexdigest() == pins[suffix], suffix
        code = compile(content, str(path), "exec")
        for name in qualified.replace("::", ".").split("."):
            matches = [
                value
                for value in code.co_consts
                if type(value) is CodeType and value.co_name == name
            ]
            assert len(matches) == 1, (qualified, name)
            code = matches[0]
    # All runtime imports are stdlib. Locals are confined to the explicitly
    # source-pinned fixed metadata method, never the generic timing/stack path.
    allowed_imports = {
        "hashlib",
        "importlib._bootstrap",
        "json",
        "sys",
        "threading",
        "time",
        "pathlib",
        "types",
    }
    for node in ast.walk(tree):
        if isinstance(node, ast.Import):
            assert all(alias.name in allowed_imports for alias in node.names)
        if isinstance(node, ast.ImportFrom):
            assert node.module in allowed_imports
        if isinstance(node, ast.Attribute):
            assert node.attr not in {"f_trace", "settrace", "setprofile"}
        if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
            if node.name != "metadata":
                assert not any(
                    isinstance(item, ast.Attribute) and item.attr == "f_locals"
                    for item in ast.walk(node)
                )
            if node.name in {"finish", "pause", "unwind"}:
                assert not any(
                    isinstance(item, ast.Name)
                    and isinstance(item.ctx, ast.Load)
                    and item.id in {"result", "error"}
                    for item in ast.walk(node)
                )
    assert "self.original(record)" in text
    assert "frame.f_globals is not record[3][-1][0].__globals__" in text
    assert "self.active.clear()" in text and "self.admissions.clear()" in text
    assert "monitor.free_tool_id(self.slot)" in text
    return {"static_targets": len(targets), "pinned_files": len(pins)}


if __name__ == "__main__":
    here = Path(__file__).resolve().parent
    repository = Path(sys.argv[1]).resolve(strict=True)
    fixture = Path(sys.argv[2]).resolve(strict=True)
    result = {
        role: verify(folder, source, fixture)
        for role, folder, source in (
            ("backend", here, repository),
            ("ui", here / "parent", repository),
            ("local", here / "baseline", fixture),
        )
    }
    result["native_executed"] = False
    print(json.dumps(result, sort_keys=True))
