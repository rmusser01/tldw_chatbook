"""Replace only the fixed approval observer in an unused checked replay."""

import argparse
import ast
import importlib.util
import json
from pathlib import Path


def replace(root, tools, source, previous_hash, *, check_only=False):
    root, tools, source = (path.resolve(strict=True) for path in (root, tools, source))
    spec = importlib.util.spec_from_file_location(
        "_approval_replay", tools / "replay.py"
    )
    replay = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(replay)
    manifest = replay.verify(root)
    if (root / "replay-runs").exists() or (root / "approval-v2-preimage").exists():
        raise ValueError("Expected an unused replay without an earlier replacement")
    if not manifest.get("tool_foreground_diagnostic"):
        raise ValueError("Expected the installed foreground observer lifetime")
    package = "task40608_tool_approval/"
    if replay.sha((root / package / "observer.py").read_bytes()) != previous_hash:
        raise ValueError("Previous approval observer changed")
    plugin = (root / "task40608_lab_observer.py").read_text(encoding="utf-8")
    if plugin.count("start_parent(install_tool_approval, 'tool-approval')") != 1:
        raise ValueError("Original installed approval lifetime changed")
    pins = json.loads((source / "source-pins.json").read_bytes())
    settings_name = "task40608-lab-observer.json"
    settings = json.loads((root / settings_name).read_bytes())
    for module, digest in pins.items():
        name = module.replace(".", "/") + ".py"
        if not module.startswith("Tests."):
            name = "tldw_chatbook/" + name
        if (
            replay.sha((root / name).read_bytes()) != digest
            or manifest["candidate_sources"].get(name) != digest
        ):
            raise ValueError("Approval original source changed: " + module)
        settings["sources"][name] = digest
    files = {}
    for filename in ("observer.py", "source-pins.json", "targets.json"):
        name = package + filename
        if (
            name not in manifest["diagnostic_sources"]
            or name not in settings["sources"]
        ):
            raise ValueError("Expected the original guarded approval package")
        raw = (source / filename).read_bytes()
        ast.parse(raw) if filename.endswith(".py") else json.loads(raw)
        files[name] = raw
    settings["sources"].update({name: replay.sha(raw) for name, raw in files.items()})
    files[settings_name] = replay.encoded(settings)
    tool = tools / Path(__file__).name
    if tool.read_bytes() != Path(__file__).read_bytes():
        raise ValueError("Copy the exact replacement tool before use")
    if check_only:
        print("Verified approval replacement; no files changed")
        return
    backup = root / "approval-v2-preimage"
    backup.mkdir()
    for name in (*files, "replay-manifest.json"):
        destination = backup / name
        destination.parent.mkdir(parents=True, exist_ok=True)
        destination.write_bytes((root / name).read_bytes())
    for name, raw in files.items():
        replay.atomic(root / name, raw)
        manifest["candidate_sources"][name] = manifest["diagnostic_sources"][name] = (
            replay.sha(raw)
        )
    manifest["tool_foreground_diagnostic"]["inputs"]["approval_ui"] = pins
    manifest["approval_observer_replacement"] = {
        "qualifying": False,
        "product_sources_changed": False,
        "plugin_lifetime_changed": False,
        "previous_observer_sha256": previous_hash,
        "observer_sha256": replay.sha(files[package + "observer.py"]),
        "previous_manifest_sha256": replay.sha(
            (backup / "replay-manifest.json").read_bytes()
        ),
    }
    manifest["tool_sha256"][tool.name] = replay.sha(tool.read_bytes())
    replay.atomic(root / "replay-manifest.json", replay.encoded(manifest))
    replay.verify(root)
    print("Verified NONQUALIFYING approval replacement; product/QA/lifetime unchanged")


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--candidate-directory", type=Path, required=True)
    parser.add_argument("--replay-tools", type=Path, required=True)
    parser.add_argument("--approval-observer-source", type=Path, required=True)
    parser.add_argument("--previous-observer-sha256", required=True)
    parser.add_argument("--check-only", action="store_true")
    args = parser.parse_args()
    replace(
        args.candidate_directory,
        args.replay_tools,
        args.approval_observer_source,
        args.previous_observer_sha256,
        check_only=args.check_only,
    )
