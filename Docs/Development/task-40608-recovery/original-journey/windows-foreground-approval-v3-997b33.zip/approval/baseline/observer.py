"""Optional original approval milestones. No arguments, bodies, or identities."""

import hashlib
import json
import sys
import threading
import time
from pathlib import Path
from types import CodeType, FunctionType, MappingProxyType
from weakref import ReferenceType

from task40608_tool_foreground.observer import Observer, _pin, _same


CALLS = {f"uat-call-{i}": ("readme", i) for i in range(5)} | {
    f"uat-dev-{i}": ("edit", i) for i in range(5)
}
MAX_ROWS = 2048
PROBE_REVISION = 3


def region_tuple(value):
    if isinstance(value, tuple) and len(value) == 4 and all(type(n) is int for n in value):
        return tuple(value)
    return None


def overlaps(left, right):
    x, y, width, height = left
    a, b, w, h = right
    return width > 0 and height > 0 and w > 0 and h > 0 and x < a+w and a < x+width and y < b+h and b < y+height


def intersection(left, right):
    x, y = max(left[0], right[0]), max(left[1], right[1])
    return x, y, max(0, min(left[0]+left[2], right[0]+right[2])-x), max(0, min(left[1]+left[3], right[1]+right[3])-y)


def attached_below(child, owner):
    if owner is None:
        return False
    for _ in range(32):
        reference = state(child).get("_MessagePump__parent")
        child = reference() if type(reference) is ReferenceType else None
        if child is None or child is owner:
            return child is owner
    return False


def update_cells(update, region):
    """Only inspect supplied strip lengths/spans; never render/crop a strip."""
    if region is None:
        return False, False
    values = state(update)
    x, y, width, height = region
    spans = values.get("spans")
    chops = values.get("chops")
    if type(spans) is list and type(chops) in (list, tuple):
        ends = values.get("chop_ends")
        if type(ends) not in (list, tuple) or len(ends) != len(chops):
            return False, False
        for row, left, right in spans:
            if not y <= row < y+height:
                continue
            if len(ends[row]) != len(chops[row]):
                return False, False
            for end, (start, strip) in zip(ends[row], chops[row].items(), strict=True):
                if strip is None:
                    continue
                length = object.__getattribute__(strip, "_cell_length")
                if type(length) is not int:
                    return False, False
                if type(end) is not int:
                    return False, False
                if max(start, left, x) < min(start+length, end, right, x+width):
                    return True, True
        return True, False
    strips = values.get("strips")
    box = region_tuple(values.get("region"))
    if type(strips) is list and box is not None:
        for row, line in enumerate(strips, box[1]):
            if not y <= row < y+height:
                continue
            if type(line) not in (tuple, list):
                return False, False
            start = box[0]
            for strip in line:
                length = object.__getattribute__(strip, "_cell_length")
                if type(length) is not int:
                    return False, False
                if max(start, x) < min(start+length, x+width):
                    return True, True
                start += length
        return True, False
    return False, False


def matched_cells_emitted(values):
    """Qualify the original match against its exact already-issued chop."""
    update, strip = values.get("update"), values.get("strip")
    y, x, start, end = (values.get(name) for name in ("y", "x", "start", "end"))
    if not all(type(n) is int for n in (y, x, start, end)) or start >= end:
        return False
    data = state(update)
    if type(data.get("chops")) in (list, tuple):
        left, right = values.get("left"), values.get("right")
        chops, ends = data["chops"], data.get("chop_ends")
        if type(ends) not in (list, tuple) or not 0 <= y < len(chops) or len(ends) != len(chops):
            return False
        if type(left) is not int or type(right) is not int or len(ends[y]) != len(chops[y]):
            return False
        for boundary, (offset, actual) in zip(ends[y], chops[y].items(), strict=True):
            if offset == x and actual is strip:
                return type(boundary) is int and start >= max(x, left) and end <= min(boundary, right)
        return False
    box, strips = region_tuple(data.get("region")), data.get("strips")
    if box is None or type(strips) is not list or not 0 <= y-box[1] < len(strips):
        return False
    line = strips[y-box[1]]
    if type(line) not in (list, tuple):
        return False
    offset = box[0]
    for actual in line:
        length = object.__getattribute__(actual, "_cell_length")
        if type(length) is not int:
            return False
        if actual is strip and offset == x:
            return start >= x and end <= x+length
        offset += length
    return False


def state(value):
    try:
        result = object.__getattribute__(value, "__dict__")
    except (AttributeError, TypeError):
        return {}
    return result if type(result) is dict else {}


def call_ids(value):
    """Inspect only the original fixed call-id field; never stringify a value."""
    if type(value) in (dict, MappingProxyType):
        value = value.get("calls", ())
    if type(value) not in (list, tuple) or len(value) > 16:
        return ()
    found = []
    for row in value:
        raw = row.get("call_id") if type(row) in (dict, MappingProxyType) else getattr(row, "call_id", None)
        if type(raw) is str and raw in CALLS and raw not in found:
            found.append(raw)
    return tuple(found)


class ApprovalObserver(Observer):
    PREFIX = "APPROVAL_MILESTONE"

    def __init__(self, stream, pins, plan):
        self.cards = {}
        self.rows_by_object = {}
        self.last_screen = None
        self.pending_invocations = {}
        self.finished_stages = set()
        self.stage_counts = {}
        self.value = threading.local()
        self.trace_callers = {}
        self.trace_sources = []
        self.dependency_pins = plan.get("dependency_pins", {})
        self.dependencies = {}
        self.update_types = ()
        self.frame_evidence = {}
        self.frame_states = {}
        super().__init__(stream, pins, targets=tuple(map(tuple, plan["targets"])), role=plan["role"])

    def require_paint_sources(self):
        for name, digest in self.dependency_pins.items():
            module = sys.modules.get(name)
            if module is None:
                raise RuntimeError("paint_dependency_not_loaded")
            if name not in self.dependencies:
                if hashlib.sha256(Path(vars(module)["__file__"]).read_bytes()).hexdigest() != digest:
                    raise RuntimeError("paint_dependency_source_changed")
                self.dependencies[name] = module
            elif self.dependencies[name] is not module:
                raise RuntimeError("paint_dependency_module_changed")
        if not self.dependency_pins:
            raise RuntimeError("paint_dependency_pins_missing")
        compositor = self.dependencies["textual._compositor"]
        current_types = tuple(vars(compositor)[name] for name in ("LayoutUpdate", "ChopsUpdate"))
        if not self.update_types:
            self.update_types = current_types
        elif any(old is not new for old, new in zip(self.update_types, current_types, strict=True)):
            raise RuntimeError("paint_update_class_changed")

    def current_button(self, card):
        for button in state(card).get("_batch_fast_buttons", ()):
            classes = state(button).get("_classes", ())
            if type(classes) in (set, frozenset) and "approval-row-fast-approve" in classes:
                return button
        return None

    def paint_facts(self, screen, app, card, button, update=None):
        """Read only already-built resident geometry and original control state."""
        self.require_paint_sources()
        app_state, button_state = state(app), state(button)
        stacks = app_state.get("_screen_stacks", {})
        stack = stacks.get(app_state.get("_current_mode"), ())
        active = type(stack) is list and bool(stack) and stack[-1] is screen
        compositor = state(state(screen).get("_compositor"))
        visible = compositor.get("_visible_widgets")
        mapped = type(visible) is dict and button in visible
        geometry = visible.get(button) if mapped else None
        if geometry is None:
            source = compositor.get("_visible_map")
            if source is None and compositor.get("_full_map_invalidated") is False:
                source = compositor.get("_full_map")
            original = source.get(button) if type(source) is dict else None
            if isinstance(original, tuple) and len(original) == 7:
                geometry = (original[0], original[2])
        region = region_tuple(geometry[0]) if type(geometry) is tuple else None
        clip = region_tuple(geometry[1]) if type(geometry) is tuple else None
        size = compositor.get("size")
        viewport = (0, 0, *size) if isinstance(size, tuple) and len(size) == 2 else None
        known = region is not None and clip is not None and viewport is not None
        in_viewport = known and overlaps(region, viewport)
        in_clip = known and overlaps(region, clip)
        covered = False
        if mapped and known:
            target = intersection(intersection(region, clip), viewport)
            for widget, pair in visible.items():
                if widget is button:
                    break
                upper, upper_clip = region_tuple(pair[0]), region_tuple(pair[1])
                if upper is None or upper_clip is None:
                    raise RuntimeError("original_visible_map_shape_changed")
                if overlaps(target, intersection(upper, upper_clip)):
                    covered = True
                    break
        supported = type(update) in self.update_types
        cell_known, cells = update_cells(update, region) if supported else (False, False)
        disabled = button_state.get("_reactive_disabled")
        facts = {
            "active_console": active, "button_present": button is not None,
            "card_belongs_to_console": attached_below(card, screen),
            "button_belongs_to_card": attached_below(button, card),
            "button_mounted": button_state.get("_is_mounted") is True,
            "button_disabled_known": type(disabled) is bool,
            "button_disabled": disabled is True,
            "button_closing": button_state.get("_closing") is True or button_state.get("_closed") is True,
            "geometry_known": known, "visible_map_known": type(visible) is dict,
            "button_in_visible_map": mapped, "outside_viewport": known and not in_viewport,
            "fully_clipped": known and not in_clip,
            "fully_within_visible_clip": bool(known and intersection(region, clip) == region
                                               and intersection(region, viewport) == region),
            "front_layer_overlap": covered,
            "information_ready": state(card).get("_information_ready") is True,
            "approval_phase": state(card).get("_batch_phase") == "approval",
            "already_submitted": state(card).get("_batch_submitted") is True,
            "update_present": update is not None, "update_cells_known": cell_known,
            "supported_compositor_update": supported,
            "update_has_button_region_cells": cells,
        }
        facts["eligible_visible_button"] = bool(
            active and mapped and in_viewport and in_clip and facts["button_mounted"]
            and not covered
            and facts["card_belongs_to_console"] and facts["button_belongs_to_card"]
            and disabled is False and not facts["button_closing"] and facts["information_ready"]
            and facts["approval_phase"] and not facts["already_submitted"]
        )
        # At the original Trace.paint return, these are cells supplied to the
        # original display. This is deliberately distinct from a label match.
        facts["qualified_delivered_button_region_cells"] = bool(
            facts["eligible_visible_button"] and facts["fully_within_visible_clip"]
            and facts["supported_compositor_update"] and facts["update_has_button_region_cells"]
        )
        return facts

    def paint_event(self, record, frame, original_match=None):
        match_emitted = False
        if record[0] == "original_label_probe":
            if frame.f_locals.get("marker") not in {"Allow once", "Once"}:
                return
            match_emitted = original_match is True and matched_cells_emitted(frame.f_locals)
            parent = frame.f_back
            for _ in range(6):
                if parent is None or parent.f_code is self.trace_callers.get("paint"):
                    break
                parent = parent.f_back
            if parent is None or parent.f_code is not self.trace_callers.get("paint"):
                return
            if not self.original(self.records[parent.f_code]):
                raise RuntimeError("original_paint_changed")
            frame = parent
        values = frame.f_locals
        trace, screen, app = values.get("self"), values.get("screen"), values.get("app")
        if screen is not state(trace).get("screen"):
            return
        self.last_screen = screen
        update = values.get("renderable")
        for card in self.cards.values():
            ids = tuple(raw for raw in state(card).get("_batch_names", ()) if raw in CALLS)
            if len(ids) != 1:
                continue  # Original fixture has one pending row per call.
            raw = ids[0]
            button = self.current_button(card)
            generation = state(card).get("_batch_generation")
            if record[0] == "original_label_probe":
                retained = self.rows_by_object.get(id(values.get("row")))
                if retained is None or retained[1] is not card or retained[2] != generation or retained[3] != raw:
                    continue
                if values.get("button") is not button:
                    continue
            facts = self.paint_facts(screen, app, card, button, update)
            facts["original_trace_started"] = state(trace).get("turn_started") is True
            key = (raw, id(screen), generation)
            if len(self.frame_evidence) >= 128 and key not in self.frame_evidence:
                self.truncated = True
                return
            evidence = self.frame_evidence.setdefault(key, {"frame_seen": False, "eligible_seen": False,
                                                           "cells_seen": False, "label_match_seen": False,
                                                           "qualified_rendered_seen": False,
                                                           "qualified_region_cells_seen": False})
            evidence["frame_seen"] = True
            evidence["eligible_seen"] |= facts["eligible_visible_button"]
            evidence["cells_seen"] |= facts["update_has_button_region_cells"]
            evidence["qualified_region_cells_seen"] |= facts["qualified_delivered_button_region_cells"]
            evidence["label_match_seen"] |= original_match is True
            if original_match is not None:
                facts["original_fixed_label_match"] = original_match
                facts["original_match_cells_emitted"] = match_emitted
                facts["qualified_rendered_fast_approve"] = bool(
                    original_match and match_emitted and facts["eligible_visible_button"]
                    and facts["fully_within_visible_clip"]
                    and facts["supported_compositor_update"] and facts["update_has_button_region_cells"]
                )
                evidence["qualified_rendered_seen"] |= facts["qualified_rendered_fast_approve"]
            stage = "actual_approval_frame" if original_match is None else "original_label_probe"
            signature = (key, stage, json.dumps(facts, sort_keys=True))
            if signature in self.frame_states:
                continue
            if len(self.frame_states) >= MAX_ROWS:
                self.truncated = True
                return
            self.frame_states[signature] = True
            journey, ordinal = CALLS[raw]
            self.emit(event="milestone", stage=stage, journey=journey, fixture_call_ordinal=ordinal,
                      wall=time.perf_counter()-self.origin, visit=self.visit(screen),
                      card_generation=generation, owner=frame.f_globals["__name__"],
                      producer=record[0],
                      function=frame.f_code.co_qualname, line=frame.f_lineno, **facts)

    def discover(self):
        super().discover()
        if self.trace_sources or "approval_trace" not in self.seen:
            return
        module = sys.modules.get("Tests.QA.task40608_trace")
        owner = vars(module).get("Trace")
        for name in ("install", "wait_with_approvals"):
            function = vars(owner).get(name)
            if type(function) is not FunctionType:
                raise RuntimeError("original_trace_caller_changed")
            self.trace_sources.append((module, owner, name, function, _pin(function)))
            if name == "install":
                for code in function.__code__.co_consts:
                    if type(code) is CodeType and code.co_name in {"paint", "press"}:
                        self.trace_callers[code.co_name] = code
            else:
                self.trace_callers["observed"] = function.__code__
        if set(self.trace_callers) != {"paint", "press", "observed"}:
            raise RuntimeError("original_trace_caller_missing")

    def emit(self, **row):
        if row.get("event") in {"installed", "summary"}:
            row["approval_probe_revision"] = PROBE_REVISION
        if row.get("event") == "summary":
            row["approval_unfinished"] = len(self.pending_invocations)
            row["approval_stage_counts"] = self.stage_counts
        if self.rows >= MAX_ROWS and row.get("event") != "summary":
            self.truncated = True
            return
        super().emit(**row)

    def visit(self, screen=None, host=None):
        """Sample actual resident visit facts, without calling a product getter."""
        presentation = state(host).get("presentation")
        lifecycle = state(presentation).get("view_lifecycle")
        current = state(lifecycle).get("_current_values")
        if type(current) is tuple and len(current) == 3 and type(current[1]) is int:
            return {"kind": "backend_checkpoint", "generation": current[1],
                    "visible": current[2] in {"mount", "visible", "resume"}}
        if screen is None:
            return None
        app = state(screen).get("app_instance")
        client = state(app).get("console_execution_client")
        if client is not None and state(client).get("_view") is screen:
            visit = state(client).get("_visit")
            if type(visit) is int:
                return {"kind": "process_view", "generation": visit}
        runtime = state(app).get("console_runtime")
        generation = state(runtime).get("_attached_generation")
        attached = state(runtime).get("_view")
        # Some original runtimes keep their bound view in `view` directly.
        if attached is None:
            attached = state(runtime).get("view")
        if attached is screen and type(generation) is int:
            return {"kind": "local_attachment", "generation": generation}
        return None

    def remember_card(self, card, values):
        if card is None:
            return
        names = state(card).get("_batch_names", ())
        if type(names) not in (list, tuple) or len(names) > 16:
            return
        ids = tuple(name for name in names if type(name) is str and name in CALLS)
        if not ids:
            return
        if len(self.cards) >= 32 and id(card) not in self.cards:
            self.truncated = True
            return
        self.cards[id(card)] = card
        generation = state(card).get("_batch_generation")
        rows = values.get("rows", ())
        if type(rows) in (list, tuple) and len(rows) == len(names):
            for row, raw in zip(rows, names, strict=True):
                if type(raw) is str and raw in CALLS:
                    if len(self.rows_by_object) >= 128 and id(row) not in self.rows_by_object:
                        self.truncated = True
                        return
                    self.rows_by_object[id(row)] = (row, card, generation, raw)
        row = values.get("row")
        if row is not None and len(ids) == 1:
            self.rows_by_object[id(row)] = (row, card, generation, ids[0])

    def card_for_button(self, button):
        for card in self.cards.values():
            buttons = state(card).get("_batch_fast_buttons", ())
            if type(buttons) in (list, tuple) and any(item is button for item in buttons):
                return card
        return None

    def details(self, label, frame):
        values = frame.f_locals
        receiver = values.get("self")
        result = {"visit": None}
        ids = ()
        if label == "approval_trace":
            trace = receiver
            self.last_screen = state(trace).get("screen")
            event = values.get("event")
            if event not in {"painted_approval", "approval_observed", "approval_click"}:
                return (), result
            caller = frame.f_back
            original_trace = sys.modules.get("Tests.QA.task40608_trace")
            if caller is None or caller.f_globals is not vars(original_trace):
                return (), result
            source = caller.f_locals
            card = None
            if not all(
                sys.modules.get("Tests.QA.task40608_trace") is module
                and vars(module).get("Trace") is owner and vars(owner).get(name) is function
                and _same(original, _pin(function))
                for module, owner, name, function, original in self.trace_sources
            ):
                raise RuntimeError("original_trace_caller_changed")
            if event == "painted_approval" and caller.f_code is self.trace_callers.get("paint"):
                row = source.get("row")
                captured = self.rows_by_object.get(id(row))
                if captured is not None and captured[0] is row:
                    _row, card, generation, raw = captured
                    if state(card).get("_batch_generation") == generation:
                        ids = (raw,)
            elif event == "approval_click" and caller.f_code is self.trace_callers.get("press"):
                card = self.card_for_button(source.get("button"))
                names = state(card).get("_batch_names", ())
                ids = tuple(raw for raw in names if type(raw) is str and raw in CALLS)
            elif event == "approval_observed" and caller.f_code is self.trace_callers.get("observed"):
                raw = source.get("call_id")
                ids = (raw,) if type(raw) is str and raw in CALLS else ()
            result.update(stage=event, visit=self.visit(self.last_screen))
            if event in {"approval_observed", "approval_click"} and len(ids) == 1:
                if card is None:
                    card = next((value for value in self.cards.values()
                                 if ids[0] in state(value).get("_batch_names", ())), None)
                button = self.current_button(card)
                result.update(self.paint_facts(self.last_screen, state(self.last_screen).get("app_instance"), card, button))
                key = (ids[0], id(self.last_screen), state(card).get("_batch_generation"))
                evidence = self.frame_evidence.get(key, {})
                result.update({"prior_"+name: evidence.get(name, False) for name in
                               ("frame_seen", "eligible_seen", "cells_seen", "label_match_seen", "qualified_rendered_seen", "qualified_region_cells_seen")})
            if card is not None:
                result["card_generation"] = state(card).get("_batch_generation")
            return ids, result
        raw = values.get("call_id")
        if type(raw) is str and raw in CALLS:
            ids = (raw,)
        for key in ("calls", "pending", "payload", "approval"):
            ids = ids or call_ids(values.get(key))
        projection = values.get("projection")
        if getattr(projection, "decision_type", None) == "approval":
            ids = ids or call_ids(getattr(projection, "payload", None))
        for key in ("state", "round_state"):
            ids = ids or call_ids(values.get(key))
        if label in {"card_batch", "card_reuse", "row_mounts", "controls_ready"}:
            self.remember_card(receiver, values)
            names = state(receiver).get("_batch_names", ())
            ids = ids or tuple(raw for raw in names if type(raw) is str and raw in CALLS)
            result["card_generation"] = state(receiver).get("_batch_generation")
            generation = values.get("generation", result["card_generation"])
            result["same_generation"] = generation == result["card_generation"]
            result["information_ready"] = state(receiver).get("_information_ready") is True
            phase = state(receiver).get("_batch_phase")
            result["phase"] = phase if phase in {"approval", "finishing"} else "unknown"
        screen = receiver if label in {"ui_projection", "ui_approval"} else self.last_screen
        result["visit"] = self.visit(screen, receiver)
        return ids, result

    def callback(self, code, action):
        if self.closed or code not in self.records or action not in {"start", "return", "unwind"}:
            return
        try:
            record = self.records[code]
            if not self.original(record):
                self.errors += 1
                self.emit(event="definition_refused", producer=record[0])
                self.close()
                return
            frame = self.frame(code)
            if frame is None or frame.f_globals is not record[3][-1][0].__globals__:
                raise ValueError("original_frame_changed")
            label = record[0]
            if label in {"actual_frame", "original_label_probe"}:
                if action == "return":
                    self.paint_event(record, frame, getattr(self.value, "returned", None)
                                     if label == "original_label_probe" else None)
                return
            ids, details = self.details(label, frame)
            if label == "approval_trace":
                if action != "start":
                    return
                stage = details.pop("stage", None)
                if stage is None:
                    return
            else:
                stage = label + "_" + action
            if not ids:
                return
            if label in {"row_mounts", "controls_ready"} and action != "return":
                return
            if label == "policy_gate" and action == "return":
                details["pending"] = getattr(self.value, "returned", None) is not None
            if label == "card_reuse" and action == "return":
                details["reused"] = getattr(self.value, "returned", None) is True
            if label in {"pending_publish", "ui_projection", "ui_approval", "round_register"} and action == "return":
                details["returned_true"] = getattr(self.value, "returned", None) is True
            if label in {"approval_request", "local_review", "policy_gate"}:
                if action == "start":
                    self.pending_invocations[id(frame)] = label
                elif action in {"return", "unwind"}:
                    self.pending_invocations.pop(id(frame), None)
            thread = threading.get_ident()
            self.threads.setdefault(thread, len(self.threads) + 1)
            for raw in ids:
                journey, ordinal = CALLS[raw]
                dedupe = (stage, journey, ordinal, json.dumps(details, sort_keys=True))
                if stage in {"painted_approval", "row_mounts_return", "controls_ready_return"}:
                    if dedupe in self.finished_stages:
                        continue
                    self.finished_stages.add(dedupe)
                self.stage_counts[stage] = self.stage_counts.get(stage, 0) + 1
                self.emit(event="milestone", stage=stage, journey=journey,
                          fixture_call_ordinal=ordinal, thread=self.threads[thread],
                          wall=time.perf_counter()-self.origin,
                          owner=vars(record[1])["__name__"], function=code.co_qualname,
                          line=frame.f_lineno, **details)
        except Exception:
            self.errors += 1
            self.emit(event="observation_refused", producer=self.records[code][0])

    def finish(self, code, offset, value):
        self.value.returned = value
        try:
            super().finish(code, offset, value)
        finally:
            self.value.returned = None


def install(stream=None):
    directory = Path(__file__).resolve().parent
    pins = json.loads((directory / "source-pins.json").read_text())
    plan = json.loads((directory / "targets.json").read_text())
    return ApprovalObserver(sys.stderr if stream is None else stream, pins, plan).close
