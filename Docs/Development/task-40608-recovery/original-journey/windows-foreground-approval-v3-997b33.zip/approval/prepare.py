"""Pin a fixed approval observer variant to exact original replay source bytes."""

import argparse
import ast
import hashlib
import json
from pathlib import Path


TARGETS = (
    ("Agents.local_tool_provider", "LocalToolProvider.pending_gate_for", "policy_gate"),
    ("Chat.console_local_review_hook", "build_local_review_hook::review_tool_calls", "local_review"),
    ("Chat.console_interrupt_rounds", "InterruptRoundHost.request_mcp_approvals", "approval_request"),
    ("Chat.console_interrupt_rounds", "InterruptRoundHost.register_round", "round_register"),
    ("Chat.console_interrupt_rounds", "InterruptRoundHost._publish_pending_decision", "pending_publish"),
    ("Chat.console_interrupt_rounds", "InterruptRoundHost._marshal_pending_approval", "pending_marshal"),
    ("UI.Screens.chat_screen", "ChatScreen._set_console_pending_decision", "ui_projection"),
    ("UI.Screens.chat_screen", "ChatScreen._set_console_pending_approval", "ui_approval"),
    ("Widgets.Chat_Widgets.chat_approval_card", "ChatApprovalCard.set_batch", "card_batch"),
    ("Widgets.Chat_Widgets.chat_approval_card", "ChatApprovalCard._defer_decisions::after_mount", "row_mounts"),
    ("Widgets.Chat_Widgets.chat_approval_card", "ChatApprovalCard._defer_decisions::ready", "controls_ready"),
    ("Tests.QA.task40608_trace", "Trace.mark", "approval_trace"),
    ("Tests.QA.task40608_trace", "Trace.install::paint", "actual_frame"),
    ("Tests.UI.test_console_configuration_worker_feedback", "_update_contains", "original_label_probe"),
)
OPTIONAL = (
    ("Widgets.Chat_Widgets.chat_approval_card", "ChatApprovalCard._update_mounted_single_row", "card_reuse"),
)


def find(tree, qualified):
    scope = tree
    for name in qualified.replace("::", ".").split("."):
        matches = [node for node in scope.body if isinstance(
            node, (ast.ClassDef, ast.FunctionDef, ast.AsyncFunctionDef)
        ) and node.name == name]
        if len(matches) != 1:
            return None
        scope = matches[0]
    return scope


def prepare(root, output, role, dependency_root):
    pins, chosen, coordinates = {}, [], {}
    for module, function, label in (*TARGETS, *OPTIONAL):
        name = ("" if module.startswith("Tests.") else "tldw_chatbook/") + module.replace(".", "/") + ".py"
        raw = (root / name).read_bytes()
        node = find(ast.parse(raw), function)
        if node is None:
            if (module, function, label) in OPTIONAL:
                continue
            raise ValueError("Original fixed approval target missing: " + function)
        pins[module] = hashlib.sha256(raw).hexdigest()
        chosen.append((module, function, label))
        coordinates[label] = node.lineno
    trace = ast.parse((root / "Tests/QA/task40608_trace.py").read_bytes())
    for function in ("Trace.install::paint", "Trace.install::press", "Trace.wait_with_approvals"):
        if find(trace, function) is None:
            raise ValueError("Original paint/pilot caller missing")
    output.mkdir()
    origin = Path(__file__).resolve().parent
    (output / "observer.py").write_bytes((origin / "observer.py").read_bytes())
    (output / "source-pins.json").write_text(json.dumps(pins, indent=2) + "\n")
    (output / "targets.json").write_text(json.dumps({
        "role": role, "targets": chosen, "coordinates": coordinates,
        "qualifying": False, "original_qa_unchanged": True,
        "dependency_pins": {name: hashlib.sha256(
            (dependency_root / (name.replace(".", "/") + ".py")).read_bytes()
        ).hexdigest() for name in ("textual.app", "textual._compositor", "textual.strip",
                                  "textual.geometry", "textual.map_geometry", "textual.reactive",
                                  "textual.widget", "textual.message_pump", "textual.dom")},
    }, indent=2) + "\n")
    print(json.dumps({"targets": len(chosen), "source_files": len(pins), "role": role,
                      "native_launched": False}))


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--source", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--role", choices=("local", "ui", "backend"), required=True)
    parser.add_argument("--dependency-root", type=Path, required=True)
    args = parser.parse_args()
    prepare(args.source.resolve(strict=True), args.output, args.role, args.dependency_root)
