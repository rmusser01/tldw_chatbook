"""Check original source pins and bounded correlation with stdlib-only objects."""

import argparse
import ast
import hashlib
import importlib.util
import io
import json
import sys
import types
import weakref
from pathlib import Path


def load(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    spec.loader.exec_module(module)
    return module


parser = argparse.ArgumentParser()
parser.add_argument("--variant", type=Path, required=True)
parser.add_argument("--source", type=Path, required=True)
parser.add_argument("--common", type=Path, required=True)
parser.add_argument("--dependency-root", type=Path, required=True)
args = parser.parse_args()
pins = json.loads((args.variant / "source-pins.json").read_text())
plan = json.loads((args.variant / "targets.json").read_text())
for module, digest in plan["dependency_pins"].items():
    raw = (args.dependency_root / (module.replace(".", "/") + ".py")).read_bytes()
    assert hashlib.sha256(raw).hexdigest() == digest
prepare = load("approval_prepare", Path(__file__).with_name("prepare.py"))
for module, digest in pins.items():
    name = ("" if module.startswith("Tests.") else "tldw_chatbook/") + module.replace(".", "/") + ".py"
    raw = (args.source / name).read_bytes()
    assert hashlib.sha256(raw).hexdigest() == digest
    tree = ast.parse(raw)
    compile(tree, name, "exec")
    for suffix, function, _label in plan["targets"]:
        if suffix == module:
            assert prepare.find(tree, function) is not None

package = types.ModuleType("task40608_tool_foreground")
package.__path__ = []
sys.modules[package.__name__] = package
load("task40608_tool_foreground.observer", args.common)
probe = load("approval_probe", args.variant / "observer.py")
assert probe.call_ids([{"call_id": "uat-dev-3", "arguments": "PRIVATE_BODY"}]) == ("uat-dev-3",)
assert not probe.call_ids([{"call_id": "PRIVATE_ID"}])
observer = object.__new__(probe.ApprovalObserver)
observer.cards, observer.rows_by_object = {}, {}
observer.truncated = False
observer.trace_sources = []
observer.frame_evidence = {}
observer.frame_states = {}
observer.require_paint_sources = lambda: None  # Pure metadata checks below use no imported product/dependency.


class SyntheticUpdate:
    pass


observer.update_types = (SyntheticUpdate,)
# Execute only the pinned original parent property's AST in its original class
# name. This catches name-mangling/backing-field errors that a fake _parent
# attribute would conceal. No Textual or product module is imported.
dependency_tree = ast.parse((args.dependency_root / "textual/message_pump.py").read_bytes())
pump = next(node for node in dependency_tree.body if isinstance(node, ast.ClassDef) and node.name == "MessagePump")
parent_methods = [node for node in pump.body if isinstance(node, ast.FunctionDef) and node.name == "_parent"]
assert len(parent_methods) == 2
source = "from __future__ import annotations\nclass MessagePump:\n" + "\n".join(
    "\n".join("    " + line for line in ast.unparse(node).splitlines()) for node in parent_methods
)
namespace = {"ref": weakref.ref}
exec(compile(source, "<pinned-original-parent-property>", "exec"), namespace)
MessagePump = namespace["MessagePump"]
row, button, card, screen = (MessagePump() for _ in range(4))
card._batch_names, card._batch_generation = ["uat-dev-3"], 2
card._batch_fast_buttons, card._batch_phase = [button], "approval"
button._parent, card._parent = card, screen
assert "_MessagePump__parent" in vars(button) and "_parent" not in vars(button)
assert probe.attached_below(button, card) and probe.attached_below(button, screen)
assert not probe.attached_below(button, MessagePump())
dead = MessagePump()
button._parent = dead
del dead
assert not probe.attached_below(button, card)
vars(button)["_MessagePump__parent"] = lambda: card
assert not probe.attached_below(button, card)  # Never execute arbitrary callbacks.
button._parent = card
runtime = types.SimpleNamespace(view=screen, _attached_generation=7)
screen.app_instance = types.SimpleNamespace(console_runtime=runtime)
observer.last_screen = screen
observer.remember_card(card, {"rows": [row]})


class Trace:
    def install(self):
        pass

    def wait_with_approvals(self):
        pass


trace_module = types.ModuleType("Tests.QA.task40608_trace")
trace_module.Trace = Trace
assert trace_module.__name__ not in sys.modules
sys.modules[trace_module.__name__] = trace_module
observer.trace_sources = [(trace_module, Trace, "install", Trace.install, probe._pin(Trace.install))]
observer.trace_callers = {"paint": Trace.install.__code__, "press": Trace.install.__code__,
                         "observed": Trace.wait_with_approvals.__code__}
trace = types.SimpleNamespace(screen=screen)
caller = types.SimpleNamespace(f_globals=vars(trace_module), f_code=Trace.install.__code__,
                               f_locals={"row": row, "button": button})
frame = types.SimpleNamespace(f_locals={"self": trace, "event": "painted_approval"}, f_back=caller)
ids, details = observer.details("approval_trace", frame)
assert ids == ("uat-dev-3",) and details["card_generation"] == 2
assert details["visit"] == {"kind": "local_attachment", "generation": 7}
card._batch_generation = 3
assert not observer.details("approval_trace", frame)[0]
observer.remember_card(card, {"rows": [row]})
frame.f_locals["event"] = "approval_click"
assert observer.details("approval_trace", frame)[0] == ("uat-dev-3",)
caller.f_locals["button"] = types.SimpleNamespace()
assert not observer.details("approval_trace", frame)[0]
original = Trace.install
Trace.install = lambda self: None
try:
    observer.details("approval_trace", frame)
except RuntimeError as error:
    assert str(error) == "original_trace_caller_changed"
else:
    raise AssertionError("changed original paint/pilot caller accepted")
finally:
    Trace.install = original
    del sys.modules[trace_module.__name__]

# Exercise the actual monitoring callbacks with stdlib-only synthetic code.
# This is observer plumbing evidence, not product or native qualification.
monitor_module = types.ModuleType("Tests.QA.approval_monitor_check")
monitor_module.__file__ = str(Path(__file__).resolve())
exec("def pending_gate_for(call_id):\n    return None\n", vars(monitor_module))
sys.modules[monitor_module.__name__] = monitor_module
stream = io.StringIO()
live = probe.ApprovalObserver(stream, {
    monitor_module.__name__: hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
}, {"targets": [[monitor_module.__name__, "pending_gate_for", "policy_gate"]],
    "role": "local"})
try:
    monitor_module.pending_gate_for("uat-dev-3")
finally:
    live.close()
    del sys.modules[monitor_module.__name__]
events = [json.loads(line.split(" ", 1)[1]) for line in stream.getvalue().splitlines()]
milestones = [event for event in events if event["event"] == "milestone"]
assert [event["stage"] for event in milestones] == ["policy_gate_start", "policy_gate_return"]
assert milestones[-1]["pending"] is False
assert events[-1]["errors"] == 0 and events[-1]["approval_unfinished"] == 0
assert events[0]["approval_probe_revision"] == events[-1]["approval_probe_revision"] == 3

# Read-only compositor facts: actual update spans, current geometry and control
# eligibility are independent of the original pilot seeing a payload.
class Button(MessagePump):
    pass


button = Button()
button._classes = {"approval-row-fast-approve"}
button._is_mounted = True
button._reactive_disabled = False
button._parent = card
card._parent = screen
card._batch_fast_buttons = [button]
card._information_ready = True
screen.app_instance._screen_stacks = {"default": [screen]}
screen.app_instance._current_mode = "default"
screen._compositor = types.SimpleNamespace(
    _visible_widgets={button: ((1, 1, 8, 1), (0, 0, 20, 5))}, size=(20, 5),
)
update = SyntheticUpdate()
update.spans = [(1, 0, 20)]
update.chops = [{}, {0: types.SimpleNamespace(_cell_length=20)}]
update.chop_ends = [[], [20]]
before = dict(vars(screen._compositor))
facts = observer.paint_facts(screen, screen.app_instance, card, button, update)
assert facts["eligible_visible_button"] and facts["update_has_button_region_cells"]
assert facts["fully_within_visible_clip"]
assert facts["qualified_delivered_button_region_cells"]
assert not observer.paint_facts(screen, screen.app_instance, card, button)["qualified_delivered_button_region_cells"]
assert before == vars(screen._compositor)  # No render, layout or cache construction.
matched = {"update": update, "strip": update.chops[1][0], "y": 1, "x": 0,
           "left": 0, "right": 20, "start": 1, "end": 9}
assert probe.matched_cells_emitted(matched)
update.chop_ends[1] = [5]
assert not probe.matched_cells_emitted(matched)
assert probe.update_cells(update, (6, 1, 3, 1)) == (True, False)
update.chop_ends[1] = [20]
button._reactive_disabled = True
assert not observer.paint_facts(screen, screen.app_instance, card, button, update)["eligible_visible_button"]
button._reactive_disabled = False
screen._compositor._visible_widgets = {button: ((1, 1, 8, 1), (0, 0, 5, 5))}
facts = observer.paint_facts(screen, screen.app_instance, card, button, update)
assert facts["eligible_visible_button"] and not facts["fully_within_visible_clip"]
assert not facts["qualified_delivered_button_region_cells"]
screen._compositor._visible_widgets = {
    MessagePump(): ((1, 1, 8, 1), (0, 0, 20, 5)),
    button: ((1, 1, 8, 1), (0, 0, 20, 5)),
}
assert not observer.paint_facts(screen, screen.app_instance, card, button, update)["qualified_delivered_button_region_cells"]
screen._compositor._visible_widgets = {button: ((30, 1, 8, 1), (0, 0, 20, 5))}
facts = observer.paint_facts(screen, screen.app_instance, card, button, update)
assert facts["outside_viewport"] and facts["fully_clipped"] and not facts["eligible_visible_button"]
assert facts["update_cells_known"] and not facts["update_has_button_region_cells"]
screen._compositor._visible_widgets = None
facts = observer.paint_facts(screen, screen.app_instance, card, button, update)
assert not facts["geometry_known"] and not facts["eligible_visible_button"]
print(json.dumps({"source_files": len(pins), "targets": len(plan["targets"]),
                  "exact_row_generation_checked": True, "unrelated_button_refused": True,
                  "changed_caller_refused": True, "synthetic_visit_checked": True,
                  "actual_monitor_callbacks_checked": True,
                  "compositor_facts_read_only_checked": True,
                  "pinned_original_parent_property_checked": True,
                  "dead_wrong_malformed_parent_refused": True,
                  "covered_and_absent_delivery_refused": True,
                  "product_imported": False, "native_launched": False}))
