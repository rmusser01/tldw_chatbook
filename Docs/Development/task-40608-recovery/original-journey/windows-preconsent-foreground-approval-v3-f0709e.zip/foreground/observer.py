"""NONQUALIFYING combined prefix/foreground; one backend monitor slot."""
import hashlib
import json
import sys
import threading
from pathlib import Path
from types import CodeType, FunctionType
from task40608_tool_foreground.observer import Observer, _pin, _resolve

def _observed_module(suffix):
    name = suffix if suffix.startswith("Tests.") else "tldw_chatbook." + suffix
    module = sys.modules.get(name)
    if suffix == "Chat.console_execution_worker":
        running = sys.modules.get("__main__")
        spec = vars(running).get("__spec__") if running is not None else None
        if getattr(spec, "name", None) == name:
            module = running
    return module

TARGETS = (('Agents.agent_service', '_call_with_timeout::_runner', 'tool_worker'), ('Agents.agent_service', 'AgentService._run_one::observe_trace_step', 'trace_persist'), ('DB.AgentRuns_DB', 'AgentRunsDB.insert_steps_at_indices', 'step_write'), ('Agents.run_log', 'RunLogWriter.append', 'run_log_append'), ('Agents.local_tool_provider', 'LocalToolProvider._invoke_detailed', 'local_invoke'), ('Agents.local_tool_dispatch', '_invoke_detailed', 'local_dispatch'), ('Agents.local_tool_dispatch', '_invoke_detailed::_invoke_allowed', 'allowed_dispatch'), ('Agents.local_tool_provider', 'LocalToolProvider._verdict_for', 'permission_verdict'), ('Agents.local_tool_provider', 'LocalToolProvider._authority_is_valid', 'authority_check'), ('Agents.local_tool_provider', 'LocalToolProvider._stale_targets_for', 'cas_check'), ('MCP.permission_store', 'MCPPermissionStore.load', 'permission_load'), ('Tools.workspace_tool_executor', 'WorkspaceToolExecutor.execute', 'workspace_execute'), ('Tools.workspace_tool_executor', 'WorkspaceToolExecutor._build_request', 'request_build'), ('Tools.workspace_tool_executor', 'WorkspaceToolExecutor._call_context', 'sensitive_context'), ('Tools.workspace_tool_executor', '_parent_read_exclusions', 'read_exclusions'), ('Utils.sensitive_paths', 'resolve_sensitive_context', 'sensitive_resolve'), ('Tools.local_tool_impls', 'resolve_workspace_path', 'path_resolve'), ('Chat.console_interrupt_rounds', 'build_combined_review_hook::review_tool_calls', 'combined_review'), ('Chat.console_local_review_hook', 'build_local_review_hook::review_tool_calls', 'local_review'), ('Chat.console_interrupt_rounds', 'InterruptRoundHost.run_round', 'approval_round'), ('Chat.console_interrupt_rounds', 'InterruptRoundHost._publish_pending_decision', 'approval_publish'), ('Chat.console_interrupt_rounds', 'InterruptRoundHost._marshal_pending_approval', 'approval_marshal'), ('Chat.console_interrupt_rounds', 'InterruptRoundHost.resolve_pending_approval', 'approval_resolve'), ('Agents.agent_request_execution', 'make_call_model::call_model', 'model_call'), ('Backup_Recovery.storage_admission', '_acquire_storage', 'storage_acquire'), ('Agents.agent_runtime', 'run_agent_loop::trace', 'runtime_trace'), ('Agents.agent_service', '_call_with_timeout', 'tool_timeout_owner'), ('Agents.agent_service', '_call_with_timeout::_admitted_call', 'tool_admitted_call'), ('Chat.console_backend_presentation', 'ConsoleBackendPresentation.project_received_input', 'draft_checkpoint'), ('Chat.console_chat_controller', 'ConsoleChatController._apply_conversation_memory_preflight', 'preflight_entry'), ('Chat.console_context_compaction', 'ConsoleCompactionPreflight._apply_conversation_memory_preflight', 'preflight_body'), ('Chat.console_agent_reply', '_run_agent_reply', 'agent_reply'), ('Chat.console_chat_controller', 'resolve_project_instruction_binding', 'binding_lookup'), ('Chat.console_chat_controller', 'list_project_instruction_bindings', 'binding_options'), ('Agents.project_instruction_resolver', 'ProjectInstructionResolver.resolve_startup', 'startup_lookup'), ('Chat.console_project_dispatch', 'build_project_dispatch_callbacks::confirm_project_dispatch', 'dispatch_consent'), ('Chat.console_runtime', 'ConsoleRuntime._confirm_project_instruction_dispatch', 'consent_request'), ('Chat.console_runtime', 'ConsoleRuntime._schedule_project_instruction_projection', 'head_schedule'), ('Chat.console_runtime', 'ConsoleRuntime._project_pending_project_instruction_decisions', 'head_ready'), ('Chat.console_backend_presentation', 'ConsoleBackendPresentation.project_pending', 'head_notification'), ('Chat.console_execution_worker', '_BackendService.queue_decision_changed', 'hint_queue'), ('Chat.console_execution_worker', '_BackendService._stage_decision_hint', 'hint_stage'), ('Chat.console_execution_worker', '_BackendService._flush_decision_hint', 'hint_flush'), ('Chat.console_backend_project_decisions', 'ConsoleBackendProjectDecisions.read_head', 'head_read'), ('Chat.console_execution_decision_head', 'encode_decision_head', 'head_encode'), ('Chat.console_backend_send_capture', 'capture_backend_send_selection', 'send_selection'), ('Chat.console_received_dispatch', 'run_received_intent', 'received_intent'), ('Chat.console_native_commit', 'commit_reserved_durable_turn_owned', 'durable_commit'), ('Chat.console_provider_composition', '_compose_agent_request_providers', 'provider_composition'), ('Chat.console_provider_composition', '_compose_virtual_cli_provider', 'virtual_cli_composition'), ('MCP.permission_process', 'PermissionProcess._start', 'permission_child_start'), ('Chat.console_project_index_preparation', 'prepare_project_index_for_composition', 'project_index_prepare'), ('Chat.console_domain_services', 'ConsoleDomainServices.build_skill_trust', 'skill_trust_factory'), ('Chat.console_domain_services', 'ConsoleDomainServices.ensure_skill_trust', 'skill_trust_ensure'), ('Chat.console_domain_skill_trust', 'build_domain_skill_trust', 'skill_trust_build'), ('Skills_Interop.skill_trust_store', 'build_skill_trust_marker_store_with_fallback', 'skill_marker_factory'), ('Skills_Interop.skill_trust_store', 'build_default_skill_trust_key_cache', 'skill_key_cache_factory'), ('Skills_Interop.skill_trust_store', '_resolve_keyring_backend', 'skill_keyring_resolve'), ('runtime_policy.server_credentials', 'is_secure_keyring_backend', 'keyring_secure_probe'), ('Chat.console_domain_services', 'ConsoleDomainServices.build_plugin_service', 'plugin_factory'), ('Chat.console_agent_preparation', '_prepare_native_reply', 'native_prepare'), ('Chat.console_agent_bridge', 'build_console_first_request_plan', 'first_request_plan'), ('Agents.agent_service', 'AgentService._run_one', 'agent_run'), ('Agents.agent_service', 'AgentService.build_project_instruction_request', 'project_request_build'), ('Chat.console_chat_controller', 'ConsoleChatController._wait_for_trace_maintenance_dispatch', 'trace_maintenance_wait'), ('Chat.console_chat_controller', 'ConsoleChatController._pre_provider_setup_phase', 'setup_phase'), ('Chat.console_pre_provider_stop', 'PreProviderSetupStop.__aexit__', 'setup_owner_exit'), ('Chat.console_agent_bridge', 'ConsoleAgentBridge.end_setup_phase', 'setup_end'), ('Chat.console_chat_start', 'ConsoleChatStartCoordinator.run_provider_worker', 'provider_worker_wait'))

class CombinedObserver(Observer):
    def discover(self):
        if self.closed:
            return
        for suffix, path, label in self.targets:
            if label in self.seen or label in self.rejected:
                continue
            module = _observed_module(suffix)
            if module is None:
                continue
            owner_path, _, child_path = path.partition('::')
            function = _resolve(module, owner_path)
            if type(function) is not FunctionType:
                continue
            try:
                source = Path(vars(module)['__file__'])
                if hashlib.sha256(source.read_bytes()).hexdigest() != self.pins[suffix]:
                    self.rejected.add(label)
                    self.emit(event='source_refused', producer=label)
                    continue
                chain = []
                while type(function) is FunctionType and len(chain) < 8:
                    chain.append((function, _pin(function)))
                    nested = vars(function).get('__wrapped__')
                    if nested is None:
                        break
                    function = nested
                if type(function) is not FunctionType or len(chain) == 8:
                    raise ValueError('unsupported_definition')
                code = function.__code__
                for child in child_path.split('.') if child_path else ():
                    matches = [value for value in code.co_consts if type(value) is CodeType and value.co_name == child]
                    if len(matches) != 1:
                        raise ValueError('ambiguous_nested_code')
                    code = matches[0]
                if code in self.records:
                    raise ValueError('ambiguous_code')
                self.records[code] = (label, module, owner_path, chain)
                events = sys.monitoring.events
                flags = events.PY_START | events.PY_RETURN | events.PY_YIELD | events.PY_RESUME
                sys.monitoring.set_local_events(self.slot, code, flags)
                self.seen.add(label)
                self.emit(event='registered', producer=label)
            except Exception:
                self.rejected.add(label)
                self.emit(event='registration_refused', producer=label)

    def consent_checkpoint(self, frame, now, cpu):
        """Read only active original ancestors on this exact callback thread."""
        ancestors = []
        thread = self.threads[threading.get_ident()]
        ancestor = frame.f_back
        while ancestor is not None:
            row = self.active.get(id(ancestor))
            if row is not None and row['thread'] == thread:
                if row['segment'] is None:
                    raise ValueError('suspended_active_ancestor')
                ancestors.append({'call': row['call'], 'producer': row['producer'], 'thread': thread, 'elapsed_wall': now - row['start'], 'active_wall': row['active_wall'] + now - row['segment'], 'active_thread_cpu': row['active_cpu'] + cpu - row['cpu'], 'storage_acquisitions_inclusive': row['acquisitions']})
            ancestor = ancestor.f_back
        self.emit(event='preconsent_checkpoint', consent_call=self.sequence, wall=now - self.origin, thread=thread, ancestors=ancestors)


    def callback(self, code, action):
        super().callback(code, action)
        if self.closed or code not in self.records:
            return
        record = self.records[code]
        if not self.original(record):
            return
        try:
            frame = self.frame(code)
            if frame is None:
                return
            if action == "start" and record[0] == "dispatch_consent":
                row = self.active.get(id(frame))
                if row is not None:
                    self.consent_checkpoint(frame, row["start"], row["cpu"])
            if action in {"start", "return"} and record[0] in {
                "skill_trust_build", "skill_keyring_resolve", "skill_marker_factory",
                "skill_key_cache_factory", "provider_composition",
            }:
                self.preparation_metadata(record, frame, action)
        except Exception:
            self.errors += 1

    def preparation_metadata(self, record, frame, action):
        values = frame.f_locals
        facts = {key: value if type(value) is bool else value is not None
                 for key in ("recovered_skills", "keyring_backend", "publish_mcp_counts")
                 if key in values for value in (values[key],)}
        self.emit(event="preparation_branch", producer=record[0], phase=action, facts=facts)

def install(stream=None):
    pins = json.loads(Path(__file__).with_name("source-pins.json").read_bytes())
    observer = CombinedObserver(sys.stderr if stream is None else stream, pins,
                                targets=TARGETS, role="backend")
    return observer.close
