"""Verify portable source provenance only; never import or launch the product."""

import argparse
import ast
import hashlib
import json
from pathlib import Path


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def child(root, relative):
    path = (root / relative).resolve(strict=True)
    if not path.is_relative_to(root.resolve(strict=True)):
        raise ValueError("Source escaped its selected root")
    return path


def verify(root, replay=None, dependencies=None, strict_manifest=False):
    receipt = json.loads((root / "receipt.json").read_bytes())
    for name, expected in receipt["files"].items():
        path = child(root, name)
        if digest(path) != expected:
            raise ValueError("Portable source checksum differs")
        if name.endswith(".py"):
            ast.parse(path.read_bytes())
    if replay is not None:
        actual_manifest = child(replay, "replay-manifest.json")
        actual = json.loads(actual_manifest.read_bytes())
        if actual["candidate_commit"] != receipt["candidate_commit"]:
            raise ValueError("Candidate commit differs")
        if strict_manifest and digest(actual_manifest) != receipt["installed_replay_manifest_sha256"]:
            raise ValueError("Installed replay manifest differs")
        for name, packed in receipt["installed_sources"].items():
            if digest(child(replay, name)) != receipt["files"][packed]:
                raise ValueError("Installed observer source differs")
        for name, expected in receipt["observed_source_pins"].items():
            if digest(child(replay, name)) != expected or actual["candidate_sources"].get(name) != expected:
                raise ValueError("Observed original source differs")
        for name, expected in receipt["original_qa_pins"].items():
            if digest(child(replay, name)) != expected:
                raise ValueError("Original QA or guard differs")
    if dependencies is not None:
        for module, expected in receipt["dependency_pins"].items():
            if digest(child(dependencies, module.replace(".", "/") + ".py")) != expected:
                raise ValueError("Original display dependency differs")
    print(json.dumps({"portable_source_files": len(receipt["files"]),
                      "installed_sources": len(receipt["installed_sources"]),
                      "observed_source_files": len(receipt["observed_source_pins"]),
                      "replay_checked": replay is not None,
                      "dependencies_checked": dependencies is not None,
                      "strict_manifest_checked": strict_manifest,
                      "qualifying": False, "native_executed": False,
                      "run_outcome_claimed": False}))


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--replay", type=Path)
    parser.add_argument("--dependencies", type=Path)
    parser.add_argument("--strict-manifest", action="store_true")
    args = parser.parse_args()
    try:
        verify(Path(__file__).resolve().parent, args.replay, args.dependencies, args.strict_manifest)
    except (OSError, ValueError, KeyError, SyntaxError):
        raise SystemExit("Source-only verification failed; no product was imported or launched") from None
