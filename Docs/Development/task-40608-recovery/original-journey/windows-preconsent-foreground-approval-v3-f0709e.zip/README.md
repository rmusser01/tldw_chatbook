# g36f: installed pre-consent / foreground / approval v3 diagnostic

**NONQUALIFYING. Run not yet completed at packaging; no outcome or performance improvement is claimed.** This archive contains source and provenance only, not logs, receipts containing live events, fixture data, user settings, credentials or absolute host paths.

Candidate commit: `f0709ee4c01b0875fb9d932256043f62610e6658`.
Installed replay manifest SHA256: `45248c623fabfec3c353636879ab18162b2519bd5ed9ded48da4df83fda245a1`.
Installed combined backend observer SHA256: `db5251d2291ac22b1be2dc9b3e8f245e30d1a02a591f3d8b52e72f0a042b2a37`.

The host-bearing replay manifest is intentionally not copied. Its exact digest, observed source hashes, original QA/guard hashes, installed-file mapping and dependency hashes are retained in `receipt.json`. These pins bind the actual replay overlay, including its previously reviewed original-source integrations and guarded launcher; clean git-blob hashes are not substituted for its bytes.

## Contents and verified preparation

- `foreground/observer.py`: actual installed 69-target backend subclass. Prefix and per-tool observations share one backend monitor, one storage-admission target and original foreground attribution.
- `foreground/parent/`: actual installed common six-target parent observer. Its common Observer implementation is also the unchanged base for backend and approval observers.
- `approval/` and `approval/backend/`: actual installed corrected v3 observers, source pins, AST coordinates and Textual dependency pins. Weak-reference ancestry, fixed-label evidence and delivered-region-cell evidence remain distinct.
- `installed/`: exact installed guarded plugin/config and optional body-free backend-failure observer. `preimage/` retains the guarded plugin/config immediately before this combined installer. Neither contains actual run records.
- `foreground/install_tool_foreground.py`: exact source-only installer used, with normal check-only mode. It needs no obsolete source-predicate observer.
- `verify.py`: standard-library source/AST/checksum verification. It neither imports the application nor runs its tests, installer, service or native workload.

Before g36f launch, actual overlay packaging, the original replay verifier, installer check-only and actual installation all passed. Original product/QA/route remained unchanged. Source-only synthetic controls exercised main/worker-thread consent, suspension, same-thread CPU accounting, admissions, definition replacement refusal and private argument/return sentinels. These controls are not real-run timing evidence. The original runner belongs to the task's workload coordinator.

## Portable verification and use

Extract to a fresh directory and run:

```text
python -I -S verify.py
python -I -S verify.py --replay <matching-original-replay> --dependencies <its-site-packages> --strict-manifest
```

`--strict-manifest` checks the exact installed original manifest digest. Omit it only for a deliberately reconstructed replay whose location-dependent manifest necessarily differs; source, candidate, original QA and installed-file pins are still checked. No checksum/identity refusal should be bypassed.

For a fresh diagnostic replay, first establish its original guarded route/QA using the existing replay tooling. The installer below must match the copy in the chosen disposable tool kit, as its original preflight requires:

```text
python -I -S foreground/install_tool_foreground.py --candidate-directory <fresh-matching-replay> --replay-tools <matching-disposable-kit> --observer-source foreground --approval-observer-source approval --check-only
```

Install only after successful exact preflight and workload coordination by removing `--check-only`. Do not install into an active run or a qualifying pair. Do not install a separate prefix observer as well. For another product revision, derive fresh pins and approval coordinates from that exact reviewed overlay; these hashes are not authority to observe different sources. The archived optional failure observer is provenance, not a command to modify an unrelated launcher.

## Readout

Read the normal `tool-foreground-backend` / parent foreground / approval outputs under the existing lab observer directory. The installed backend emits `TOOL_FOREGROUND` records with an explicit `monotonic_origin`; original unmodified UI Trace records retain `clock_ns` and `trace_start`. Use within-process spans, or the explicit original perf-counter anchors where cross-process alignment is supported; do not subtract unrelated log clocks.

The prefix includes original Send selection/commit, memory preflight, provider composition, project-index preparation, skill-trust ensure/factory/build, OS-keyring resolution/secure checks, plugin construction, native first-request preparation, setup exit and maintenance wait. `permission_child_start` is the zero-call control for the old nested-startup defect. `preconsent_checkpoint` captures only monitored active ancestors actually on the consent thread, including accumulated wall/thread CPU and admissions. First inspect the interval before the original consent callback for each journey; do not charge user approval or subsequent model/tool lifetime to startup.

Compare cold skill/keyring factory duration to the warm second journey only when the observed original path actually ran. Recovered/default branches may legitimately avoid keyring. No credential values or backend/account identifiers are emitted. Partial checkpoints do not prove completion or native retirement.

Prefix ancestors broaden admission coverage relative to the older foreground-only probe. Keep original nearest-call/per-tool handover attribution; never add overlapping ancestor durations or inclusive counts. Preserve the distinction between first visible pending decision, actual eligible delivered button region, fixed-label paint and the fixture's later detection/click. Require clean `registered`, `source_refused`, `errors`, `unfinished`, `unfinished_admissions` and `truncated` summaries. A missing/unregistered target is not a proven zero-call result. Existing bounds remain 2,048 calls, 2,048 admissions and 16,384 foreground rows.

Synchronous diagnostic writes and callbacks add overhead. This run is for attribution and functionality, not clean acceptance timing. No numerical result is recorded in this source archive.
