"""Nonqualifying body-free sink at the original contained worker failure catch."""

from contextlib import contextmanager
import hashlib
import json
import os
from pathlib import Path
import sys

_WORKER = "tldw_chatbook/Chat/console_execution_worker.py"
_CONTROLS = "tldw_chatbook/Chat/console_control_dispatch.py"
_OPS = frozenset(
    {
        "OpenSession",
        "ReadProjection",
        "UpdateInputs",
        "ReceiveTurn",
        "CommitPlanAck",
        "CancelTurn",
        "ResolveDecision",
        "ProjectDecisionPresentation",
        "PermissionAction",
        "FenceSource",
        "ApplySourceRevision",
        "SetWorkspaceBindingAccess",
        "CloseIntake",
        "Drain",
        "Shutdown",
        "ApplySettings",
    }
)
_STAGES = frozenset({"admission", "applied", "terminal", "retirement"})


@contextmanager
def failure_locations(root, settings):
    """Keep the existing guard, original worker code and original logger intact."""
    if settings.get("backend_failure_diagnostic") is not True:
        raise RuntimeError("Explicit nonqualifying backend diagnostic required")
    worker = root / _WORKER
    if hashlib.sha256(worker.read_bytes()).hexdigest() != settings["sources"][_WORKER]:
        raise RuntimeError("Original backend diagnostic source pin changed")
    if (
        hashlib.sha256((root / _CONTROLS).read_bytes()).hexdigest()
        != settings["sources"][_CONTROLS]
    ):
        raise RuntimeError("Original pressed comparison source pin changed")
    from loguru import logger

    directory = Path(os.environ["TLDW_TEST_LAB_OUTPUT"])
    fd = os.open(
        directory / f"backend-failure-{os.getpid()}.jsonl",
        os.O_WRONLY | os.O_CREAT | os.O_EXCL,
        0o600,
    )
    count = 0
    original = None
    expected_file = os.path.normcase(os.path.abspath(worker))
    root_prefix = os.path.normcase(os.path.abspath(root)) + os.sep

    def write(value):
        payload = json.dumps(value, separators=(",", ":")).encode() + b"\n"
        while payload:
            size = os.write(fd, payload)
            if size <= 0:
                raise OSError("Backend diagnostic write stopped")
            payload = payload[size:]

    def mismatch_fields(trace):
        if (
            os.path.normcase(os.path.abspath(trace.tb_frame.f_code.co_filename))
            != os.path.normcase(os.path.abspath(root / _CONTROLS))
            or trace.tb_frame.f_code.co_name != "_apply_input_command"
            or trace.tb_lineno != settings["backend_failure_values_line"]
        ):
            return None
        frame = trace.tb_frame
        cls = frame.f_globals.get("ConsoleLocalControls")
        function = (
            vars(cls).get("_apply_input_command") if isinstance(cls, type) else None
        )
        if (
            getattr(function, "__code__", None) is not frame.f_code
            or type(frame.f_locals.get("self")) is not cls
        ):
            return None
        # The original comparison's retained inputs/local settings only. No
        # getter, source resolver, DB call, identifier or value is published.
        values = frame.f_locals
        pressed, inputs, session, original_settings = (
            values[name] for name in ("pressed", "inputs", "session", "settings")
        )
        checks = (
            ("session_id", pressed["session_id"] != inputs.session_id),
            ("incarnation_id", pressed["incarnation_id"] != inputs.incarnation_id),
            ("draft", pressed["draft"] != inputs.draft),
            (
                "authored_token",
                tuple(pressed["authored_token"]) != session._draft_authored_token,
            ),
            ("settings", pressed["settings"] != original_settings),
            (
                "settings_revision",
                pressed["settings_revision"] != inputs.settings_revision,
            ),
            (
                "attachment_revision",
                pressed["attachment_revision"] != inputs.attachment_revision,
            ),
            (
                "attachment_ids",
                tuple(pressed["attachment_ids"]) != inputs._attachment_ids,
            ),
            (
                "one_shot_prefill",
                pressed["one_shot_prefill"] != inputs.one_shot_prefill,
            ),
            (
                "prefill_revision",
                pressed["prefill_revision"] != inputs.prefill_revision,
            ),
            (
                "attachments_count",
                len(pressed["attachments"]) != len(inputs.attachments),
            ),
        )
        return [name for name, changed in checks if changed]

    def sink(message):
        nonlocal count, original
        record = message.record
        if record["function"] != "_failure" or count >= 32:
            return
        frame = sys._getframe(1)
        try:
            while frame is not None:
                code = frame.f_code
                if (
                    code.co_name == "_failure"
                    and os.path.normcase(os.path.abspath(code.co_filename))
                    == expected_file
                ):
                    break
                frame = frame.f_back
            if frame is None:
                return
            service = frame.f_globals.get("_BackendService")
            method = (
                vars(service).get("_failure") if isinstance(service, type) else None
            )
            if type(method) is not staticmethod:
                return
            function = method.__func__
            if (
                function.__code__ is not frame.f_code
                or function.__globals__ is not frame.f_globals
            ):
                return
            if original is None:
                original = (service, function, function.__code__)
            elif original != (service, function, function.__code__):
                write({"event": "backend_failure_source_changed"})
                return
            operation, stage = (
                frame.f_locals.get("operation"),
                frame.f_locals.get("stage"),
            )
            error = frame.f_locals.get("error")
            if (
                type(operation) is not str
                or operation not in _OPS
                or type(stage) is not str
                or stage not in _STAGES
                or not isinstance(error, BaseException)
            ):
                return
            pending, seen, failures = [("original", error)], set(), []
            while pending and len(failures) < 8:
                relation, current = pending.pop(0)
                if id(current) in seen:
                    continue
                seen.add(id(current))
                trace, frames, mismatches = current.__traceback__, [], None
                while trace is not None and len(frames) < 48:
                    selected_mismatches = mismatch_fields(trace)
                    if selected_mismatches is not None:
                        mismatches = selected_mismatches
                    filename = os.path.normcase(
                        os.path.abspath(trace.tb_frame.f_code.co_filename)
                    )
                    relative = (
                        filename[len(root_prefix) :].replace(os.sep, "/")
                        if filename.startswith(root_prefix)
                        else "<external>"
                    )
                    frames.append(
                        {
                            "file": relative,
                            "function": trace.tb_frame.f_code.co_name,
                            "line": trace.tb_lineno,
                        }
                    )
                    trace = trace.tb_next
                failures.append(
                    {
                        "relationship": relation,
                        "exception_type": type(current).__name__,
                        "frames": frames,
                        "frames_truncated": trace is not None,
                        "pressed_mismatch_fields": mismatches,
                    }
                )
                if isinstance(current.__cause__, BaseException):
                    pending.append(("cause", current.__cause__))
                if isinstance(current.__context__, BaseException):
                    pending.append(("context", current.__context__))
            write(
                {
                    "event": "original_backend_failure",
                    "operation": operation,
                    "stage": stage,
                    "exceptions": failures,
                    "chain_truncated": bool(pending),
                }
            )
            count += 1
        except Exception:
            # Never let a diagnostic formatter expose the caught exception text.
            try:
                write({"event": "backend_failure_observation_unavailable"})
            except Exception:
                pass
        finally:
            del frame

    token = None
    try:
        write({"event": "backend_failure_observer_installed", "qualifying": False})
        token = logger.add(
            sink,
            level="WARNING",
            enqueue=False,
            catch=True,
            backtrace=False,
            diagnose=False,
        )
        yield
    finally:
        if token is not None:
            logger.remove(token)
        os.close(fd)
