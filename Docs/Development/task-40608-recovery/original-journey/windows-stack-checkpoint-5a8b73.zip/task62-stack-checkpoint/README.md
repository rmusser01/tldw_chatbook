# Live diagnostic checkpoints

This optional extension applies to a fresh disposable observer before it is installed. It checks the reviewed g57 sampler checksum and adds a one-shot export to both roles. It does not modify a running observer. Only the original paired driver and original guard provide acceptance evidence.

Prepare a fresh g57-compatible overlay, then run `attach.py --overlay NEW_OVERLAY` using isolated CPython. Install the result with the existing foreground installer. When a diagnostic has a verified negative retirement, create one empty `stack-checkpoint.request` in that run's unique public receipt directory beside `progress.jsonl`. The two sampler threads check for that file once every 20 samples. Each captures the already observed immutable code objects, stacks and tick history, then continues its original collection while a bounded worker qualifies the frozen snapshot. A checkpoint performs no product, provider or native retirement observation. Source authentication at checkpoint time can affect subsequent diagnostic timings.

The UI reads the original guarded clock observer's existing fixed event types and numeric timestamps. It omits message contents, trace payloads and the original guard token. Both processes publish separate completed `stack-checkpoint-ROLE-PID.json` files by renaming closed temporary files. The analyzer checks process identities, the hashed run token, the manifest, each original clock and actual sampled coverage. It reports only journeys whose reply the original fixture verified before the checkpoint. An incomplete edit has counts and no ranked journey windows. Source refusals produce a fixed `.refused` marker without partial symbols. The original complete-run analyzer and shutdown proof remain independent.

```powershell
python -I -S -B verify.py
python -I -S -B attach.py --overlay NEW_OVERLAY
python -I -S -B analyze_checkpoint.py ORIGINAL_RUN_DIRECTORY --output NEW_PARTIAL_REPORT.json
```
