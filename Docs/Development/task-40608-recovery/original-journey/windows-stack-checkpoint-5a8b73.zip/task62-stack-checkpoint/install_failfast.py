"""Install the failure-only fixture adapter in a fresh double-instrumented diagnostic."""
import argparse
import ast
import hashlib
import json
import os
from pathlib import Path
import sys


def main(args):
    sys.path.insert(0, str(args.tools.resolve(strict=True)))
    from replay import verify
    root = args.replay.resolve(strict=True)
    m = verify(root)
    if (m["candidate_commit"] != "5a8b730cfab84a6fe6df5fa5a8d5211bc13809c8" or (root/"replay-runs").exists()
            or m["tool_foreground_diagnostic"]["qualifying"] or m["retirement_failure_diagnostic"]["qualifying"]):
        raise ValueError("Expected the unused exact isolated diagnostic")
    plugin = "task40608_lab_observer.py"
    cfg = "task40608-lab-observer.json"
    helper = "task40608_diagnostic_wait.py"
    if (root/helper).exists():
        raise ValueError("Diagnostic wait already installed")
    sha = lambda data: hashlib.sha256(data).hexdigest()
    src = Path(__file__).with_name("failfast.py").read_bytes()
    old = (root/plugin).read_bytes()
    text = old.decode()
    anchor = "    start_parent(install_tool_foreground, 'tool-foreground')\n"
    if text.count(anchor) != 1:
        raise ValueError("Guard startup source changed")
    text = text.replace(anchor, anchor + "    from task40608_diagnostic_wait import install_diagnostic_wait\n"
                        + "    install_diagnostic_wait(_ROOT, settings)\n")
    ast.parse(text)
    ast.parse(src)
    settings = json.loads((root/cfg).read_bytes())
    if settings["sources"]["Tests/QA/task40608_trace.py"] != "afe87984e26d77b86c80f5f034881717e82b3ecc8681b56fe6ea2148f0073a6c":
        raise ValueError("Original fixture trace changed")
    settings["sources"].update({plugin:sha(text.encode()),helper:sha(src)})
    updates = {plugin:text.encode(),helper:src,cfg:(json.dumps(settings,indent=2)+"\n").encode()}
    print(json.dumps({"checked":True,"wait_sha256":sha(src),"fixture_sha256":m["candidate_journey_sha256"]}))
    if args.check_only:
        return
    backup = root / "diagnostic-wait-preimage"
    backup.mkdir()
    for name in (plugin,cfg,"replay-manifest.json"):
        (backup/name).write_bytes((root/name).read_bytes())
    for name,data in updates.items():
        m["candidate_sources"][name]=m["diagnostic_sources"][name]=sha(data)
    m["diagnostic_wait"] = {"qualifying":False,"source_bytes_changed":False,"wait_sha256":sha(src),
                            "prior_manifest_sha256":sha((root/"replay-manifest.json").read_bytes())}
    updates["replay-manifest.json"]=(json.dumps(m,indent=2)+"\n").encode()
    for name,data in updates.items():
        path=root/name
        tmp=path.with_name(path.name+".diagnostic-new")
        with tmp.open("xb") as out:
            out.write(data)
        os.replace(tmp,path)
    verify(root)
    print(json.dumps({"installed":True,"manifest_sha256":sha(updates["replay-manifest.json"])}))


if __name__ == "__main__":
    parser=argparse.ArgumentParser()
    parser.add_argument("--replay",required=True,type=Path)
    parser.add_argument("--tools",required=True,type=Path)
    parser.add_argument("--check-only",action="store_true")
    main(parser.parse_args())
