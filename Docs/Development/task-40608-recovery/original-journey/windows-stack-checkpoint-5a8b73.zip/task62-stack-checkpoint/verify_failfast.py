"""Check that an ordinary wait cannot settle from an unrelated or incomplete receipt."""
from concurrent.futures import Future
from pathlib import Path
import sys
from types import SimpleNamespace

sys.path.insert(0, str(Path(__file__).resolve().parent))
from failfast import observed_failure


class Wire(SimpleNamespace):
    pass


class Receipt(SimpleNamespace):
    pass


def done(value):
    future = Future()
    future.set_result(value)
    return future


identity = SimpleNamespace(sequence=5, request_id="r", session_id="s", incarnation_id="i",
                           source_revision=1, profile_epoch="p", service_epoch="e")
def event(kind, **payload):
    return Wire(kind=kind, operation="ReceiveTurn", identity=identity, payload=payload)


failed = event("failed", stage="terminal", code="turn_failed")
terminal = event("terminal", turn_id="t", accepted=False)
receipt = Receipt(identity=identity, operation="ReceiveTurn", received=done(None), retired=done(False),
                  applied=done({"turn_id":"t"}), turn_id="t", events=[failed, terminal])
client = SimpleNamespace(_requests={"r":receipt})
def qualified(lower=4, session="s"):
    return observed_failure(client, lower, session, Receipt, Wire)


assert qualified() and not qualified(lower=5) and not qualified(session="different")
for name, refused in (
    ("events", [terminal, failed]), ("events", [terminal]), ("events", [failed]),
    ("events", [event("failed", stage="admission", code="turn_failed"), terminal]),
    ("events", [failed, event("terminal", turn_id="different", accepted=True)]),
    ("retired", done(True)), ("applied", done({"turn_id":"different"})), ("received", Future()),
    ("received", done(False)),
):
    original = getattr(receipt, name)
    setattr(receipt, name, refused)
    assert not qualified(), name
    setattr(receipt, name, original)
print("PASS only an authenticated terminal failure after confirmed receive/apply and negative retirement ends the fixture wait")
