"""Wake both deployed diagnostic samplers only after the original verifies README."""
import argparse
import json
from pathlib import Path
import time


def request(run):
    metadata = json.loads((run / "run-metadata.json").read_text(encoding="utf-8-sig"))
    replay = run.parent.parent
    manifest = json.loads((replay / "replay-manifest.json").read_bytes())
    if (run.parent.name != "replay-runs" or metadata.get("originalJourneySha256") !=
            "448015c99604ce96754436c7dc4f784daed6241bed99062cb8d6ab6e66cbe850"
            or not manifest.get("diagnostic_wait") or manifest["diagnostic_wait"]["qualifying"] is not False):
        raise ValueError("Expected the disposable diagnostic, with the original fixture")
    marker = run / "stack-checkpoint.request"
    for _ in range(1600):
        if marker.is_file():
            return "checkpoint already requested"
        progress = run / "progress.jsonl"
        if progress.is_file():
            rows = progress.read_bytes().split(b"\n")[:-1]
            if any(e.get("turn") == "readme" and e.get("event") == "reply_verified"
                   for e in (json.loads(r) for r in rows if r)):
                try:
                    with marker.open("xb"):
                        pass
                except FileExistsError:
                    pass
                return "checkpoint requested after original README reply_verified"
        if (run / "timings.json").exists():
            raise ValueError("Diagnostic exited before README verification")
        time.sleep(.25)
    raise TimeoutError("No verified README to checkpoint")


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("run", type=Path)
    print(request(parser.parse_args().run.resolve(strict=True)))
