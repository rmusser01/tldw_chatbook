"""End only a diagnostic wait whose own authenticated ReceiveTurn has already failed."""
import hashlib
import json
import os
from pathlib import Path
import sys
from types import CodeType, FunctionType
from weakref import WeakKeyDictionary


def done_value(future):
    if not future.done() or future.cancelled() or future.exception() is not None:
        return object()
    return future.result()


def observed_failure(client, lower_bound, session_id, receipt_type, wire_type):
    # Successful receipts retire out of this dictionary. A negative receipt stays owned by its client.
    candidates = [r for key, r in client._requests.items() if type(r) is receipt_type
                  and r.operation == "ReceiveTurn" and r.identity.sequence > lower_bound
                  and r.identity.request_id == key and r.identity.session_id == session_id]
    if len(candidates) != 1:
        return False
    receipt = candidates[0]
    identity = receipt.identity
    def same_request(event):
        return (type(event) is wire_type and event.operation == "ReceiveTurn"
                and all(getattr(event.identity, key) == getattr(identity, key) for key in
                        ("request_id", "session_id", "incarnation_id", "source_revision", "profile_epoch", "service_epoch")))
    events = [e for e in receipt.events if same_request(e)]
    failed = [i for i, e in enumerate(events) if e.kind == "failed" and e.payload.get("stage") == "terminal"
              and e.payload.get("code") in {"turn_failed", "cancelled"}]
    terminal = [i for i, e in enumerate(events) if e.kind == "terminal" and e.payload.get("turn_id") == receipt.turn_id
                and type(e.payload.get("accepted")) is bool]
    return (len(failed) == len(terminal) == 1 and failed[0] < terminal[0]
            and done_value(receipt.received) is None and done_value(receipt.retired) is False
            and done_value(receipt.applied) == {"turn_id": receipt.turn_id})


def install_diagnostic_wait(replay, settings):
    from Tests.QA.task40608_trace import Trace
    path = replay / "Tests/QA/task40608_trace.py"
    source = path.read_bytes()
    if hashlib.sha256(source).hexdigest() != settings["sources"]["Tests/QA/task40608_trace.py"]:
        raise ValueError("Original fixture source changed")
    compiled = [compile(source, str(path), "exec", dont_inherit=True)]
    originals = {}
    while compiled:
        code = compiled.pop()
        compiled.extend(item for item in code.co_consts if type(item) is CodeType)
        if code.co_qualname in {"Trace.watch", "Trace.wait_with_approvals"}:
            originals[code.co_qualname] = code
    watch, wait = vars(Trace)["watch"], vars(Trace)["wait_with_approvals"]
    for method in (watch, wait):
        if (type(method) is not FunctionType or method.__code__ != originals[method.__qualname__]
                or Path(method.__code__.co_filename) != path):
            raise ValueError("Original fixture method changed")
    captures = WeakKeyDictionary()

    def watch_original(trace, console, turn):
        result = watch(trace, console, turn)
        client = getattr(console.app_instance, "console_execution_client", None)
        process = sys.modules.get("tldw_chatbook.Chat.console_execution_process")
        protocol = sys.modules.get("tldw_chatbook.Chat.console_execution_protocol")
        if (process is not None and protocol is not None and type(client) is process.ConsoleExecutionClient
                and turn in {"readme", "edit"}):
            captures[trace] = (client, client._sent_sequence, turn, console,
                               process.ConsoleProcessReceipt, protocol.ConsoleWireMessage)
        return result

    async def wait_original(trace, pilot, console, controller, session, server, final, click, *, main=None):
        capture = captures.get(trace)
        if (capture is None or capture[3] is not console or trace.turn != capture[2]
                or console.app_instance.console_execution_client is not capture[0]):
            return await wait(trace, pilot, console, controller, session, server, final, click, main=main)
        client, lower_bound, turn, _, receipt_type, wire_type = capture
        def checked_final():
            result = final()
            if result is None and observed_failure(
                    client, lower_bound, session.id, receipt_type, wire_type):
                directory = Path(os.environ["TLDW_TEST_LATENCY_PROGRESS"]).parent
                with (directory / "diagnostic-terminal-failure.json").open("x", encoding="utf-8") as out:
                    json.dump({"turn": turn, "received": True, "applied": True, "failed_stage": "terminal",
                               "logical_terminal_seen": True, "retired": False, "qualifying": False}, out)
                (directory / "stack-checkpoint.request").touch(exist_ok=True)
                raise AssertionError("Diagnostic wait stopped after the authenticated ReceiveTurn terminal failure and negative retirement")
            return result
        # The original polling coroutine, server errors, approval clicks and final() run on their original task.
        return await wait(trace, pilot, console, controller, session, server, checked_final, click, main=main)

    Trace.watch, Trace.wait_with_approvals = watch_original, wait_original
