"""Add the checkpoint to a fresh, uninstalled g57-compatible observer staging directory."""
import argparse
import ast
import hashlib
from pathlib import Path


BASE_SHA = "17d7272c4b934449a22ce1ca22046270fdbf4f20f28516d058b86ab7db07cbda"


def attach(overlay):
    extra = Path(__file__).with_name("checkpoint.py").read_text(encoding="utf-8")
    # No new modules need to be imported into the application or original CLI.
    for path in (overlay / "observer.py", overlay / "parent" / "observer.py"):
        if hashlib.sha256(path.read_bytes()).hexdigest() != BASE_SHA:
            raise ValueError("Expected original pinned g57 sampler")
    text = (overlay / "observer.py").read_text(encoding="utf-8")
    replacements = {
        "    stop = threading.Event()": "    checkpoint = StackCheckpoint(replay, package, origin)\n    stop = threading.Event()",
        "                observed = census.snapshot(sys._current_frames(), threads, threading.get_ident(), main_ident)": (
            "                frames = sys._current_frames()\n"
            "                if checkpoint.worker is not None and threads.get(checkpoint.worker.ident) is checkpoint.worker:\n"
            "                    frames.pop(checkpoint.worker.ident, None)\n"
            "                observed = census.snapshot(frames, threads, threading.get_ident(), main_ident)\n"
            "                del frames\n"
            "                checkpoint.tick(start - origin, observed, census)"),
        "        watcher.join()": "        watcher.join()\n        checkpoint.close(census)",
    }
    for old, new in replacements.items():
        if text.count(old) != 1:
            raise ValueError("Expected exact reviewed sampler body")
        text = text.replace(old, new)
    data = (text + "\n\n" + extra).encode("utf-8")
    ast.parse(data)
    for path in (overlay / "observer.py", overlay / "parent" / "observer.py"):
        path.write_bytes(data)
    return hashlib.sha256(data).hexdigest()


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--overlay", type=Path, required=True)
    print(attach(parser.parse_args().overlay.resolve(strict=True)))
