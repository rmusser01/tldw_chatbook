"""One bounded, observer-owned snapshot of already sampled code. Embedded by attach.py."""
from copy import copy


class StackCheckpoint:
    def __init__(self, replay, package, origin):
        self.replay = replay
        self.origin = origin
        self.role = {"task40608_tool_foreground_backend": "backend", "task40608_tool_foreground": "ui"}[package.name]
        progress = Path(os.environ["TLDW_TEST_LATENCY_PROGRESS"])
        if progress.name != "progress.jsonl" or progress.parent.parent != replay / "replay-runs":
            raise ValueError("Expected the original replay progress location")
        self.directory = progress.parent
        self.history = []
        self.worker = None

    def capture_clocks(self):
        if self.role != "ui":
            return [], []
        plugin = sys.modules.get("task40608_lab_observer")
        path = self.replay / "task40608_lab_observer.py"
        manifest = json.loads((self.replay / "replay-manifest.json").read_bytes())
        data = path.read_bytes()
        if (plugin is None or Path(plugin.__file__).resolve() != path
                or hashlib.sha256(data).hexdigest() != manifest["candidate_sources"][path.name]):
            raise ValueError("Changed original clock observer")
        cls = vars(plugin)["_Observation"]
        state = vars(plugin)["_state"]
        if type(state) is not cls or state.guard_started is not True or state.attempts:
            raise ValueError("Original guard has no usable running window")
        receiver = vars(cls)["_returned"]
        approved = index_codes(compile(data, str(path), "exec", dont_inherit=True))
        if (type(receiver) is not type(self.capture_clocks.__func__) or receiver.__globals__ is not vars(plugin)
                or receiver.__code__ not in approved.get((receiver.__qualname__, receiver.__code__.co_firstlineno), ())):
            raise ValueError("Changed original clock receiver")
        kinds = {"send", "http_request_received", "http_response_sent", "approval_observed", "approval_click",
                 "reply_seen", "reply_verified", "disclosure_observed", "disclosure_click"}
        events = []
        for item in tuple(state.events):
            if item.get("turn") in {"readme", "edit"} and item.get("event") in kinds:
                stamp = item["trace_start"] + item["t"]
                events.append([item["turn"], item["event"], stamp])
        pids = list(state.backend_pids)
        if any(type(pid) is not int for pid in pids):
            raise ValueError("Invalid original backend attribution")
        return events, pids

    def tick(self, stamp, observations, census):
        if self.worker is not None:
            return
        self.history.append((stamp, observations))
        # The original collector keeps its full cadence. Only diagnostic code needs a checkpoint.
        if len(self.history) % 20 or not (self.directory / "stack-checkpoint.request").is_file():
            return
        self.start(census)

    def start(self, census):
        captured = copy(census)
        captured.codes = dict(census.codes)
        captured.stacks = dict(census.stacks)
        history = self.history
        self.history = []
        self.worker = threading.Thread(target=self.write, args=(captured, history), daemon=True)
        self.worker.start()

    def write(self, captured, history):
        stem = f"stack-checkpoint-{self.role}-{os.getpid()}"
        started = time.perf_counter()
        tmp = self.directory / (stem + ".writing")
        try:
            symbols, refused = captured.symbols()
            clocks, pids = self.capture_clocks()
            if refused or captured.truncated:
                raise ValueError("Incomplete observed code evidence")
            record = {"kind": "partial-stack-checkpoint", "role": self.role, "pid": os.getpid(),
                      "manifest_sha256": hashlib.sha256((self.replay / "replay-manifest.json").read_bytes()).hexdigest(),
                      "guard_run_sha256": hashlib.sha256(os.environ["TLDW_TEST_LAB_RUN_ID"].encode()).hexdigest(),
                      "origin": self.origin, "clocks": clocks, "backend_pids": pids,
                      "ticks": history, "symbols": symbols, "stacks": {n: s for s, n in captured.stacks.items()},
                      "validated": True, "preparation_seconds": time.perf_counter() - started}
            with tmp.open("x", encoding="utf-8") as out:
                json.dump(record, out, separators=(",", ":"))
                out.flush()
                os.fsync(out.fileno())
            tmp.rename(self.directory / (stem + ".json"))
        except Exception:
            with (self.directory / (stem + ".refused")).open("x", encoding="ascii") as out:
                out.write("Checkpoint unavailable\n")

    def close(self, census=None):
        if (self.worker is None and self.history and census is not None
                and (self.directory / "stack-checkpoint.request").is_file()):
            self.start(census)
        if self.worker is not None:
            self.worker.join()
