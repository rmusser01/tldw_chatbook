"""Read a completed diagnostic checkpoint without treating it as whole-run retirement."""
import argparse
from collections import Counter, defaultdict
import json
from pathlib import Path


def read_role(run, role):
    [path] = list(run.glob(f"stack-checkpoint-{role}-*.json"))
    doc = json.loads(path.read_bytes())
    if (doc["kind"] != "partial-stack-checkpoint" or doc["role"] != role or not doc["validated"]
            or path.name != f"stack-checkpoint-{role}-{doc['pid']}.json"):
        raise ValueError("Unexpected checkpoint identity")
    symbols = {0: ("outside pinned Python", False)}
    symbols.update({int(k): (f"{group}/{name} {func}@{first}", group == "app")
                    for k, (group, name, func, first) in doc.pop("symbols").items()})
    stacks = {}
    for key, stack in doc.pop("stacks").items():
        ranked = [(symbols[code][0], line, symbols[code][1]) for code, line in stack]
        name, line, _ = ranked[0]
        nearest = next((f"{n}:{l}" for n, l, app in ranked if app), None)
        chain = tuple(dict.fromkeys(n for n, _, app in ranked if app))
        stacks[int(key)] = (f"{name}:{line}", nearest, chain)
    ticks = [(doc["origin"] + t, observed) for t, observed in doc.pop("ticks")]
    if not ticks or any(left[0] >= right[0] for left, right in zip(ticks, ticks[1:])):
        raise ValueError("Missing or unordered sample coverage")
    return doc, stacks, ticks


def summarize(stacks, ticks, begin, end):
    if not ticks[0][0] <= begin <= end <= ticks[-1][0]:
        raise ValueError("Window outside source-qualified checkpoint")
    counters = {}
    samples = 0
    for stamp, observations in ticks:
        if begin <= stamp < end:
            samples += 1
            for thread, stack in observations:
                top, nearest, chain = stacks[stack]
                row = counters.setdefault(thread, defaultdict(Counter))
                row["leaf"][top] += 1
                if nearest:
                    row["nearest_product"][nearest] += 1
                    row["product_chain"][" <- ".join(chain[:4])] += 1
                row["product_ancestry"].update(chain)
    return {"ticks": samples, "wall_seconds": end - begin,
            "threads": {str(t): {k: counter.most_common(8) for k, counter in row.items()}
                        for t, row in sorted(counters.items())}}


def analyze(run):
    records = {role: read_role(run, role) for role in ("ui", "backend")}
    ui, backend = (records[r][0] for r in ("ui", "backend"))
    run_meta = json.loads((run / "run-metadata.json").read_text(encoding="utf-8-sig"))
    if (ui["guard_run_sha256"] != backend["guard_run_sha256"] or backend["pid"] not in ui["backend_pids"]
            or ui["pid"] == backend["pid"] or ui["manifest_sha256"] != backend["manifest_sha256"]
            or ui["manifest_sha256"] != run_meta["manifestSha256"].lower()
            or run_meta["originalJourneySha256"] != run_meta["candidateJourneySha256"]):
        raise ValueError("Process, source or guard attribution changed")
    windows, coverage = {}, {}
    for turn, count in (("readme", 5), ("edit", 6)):
        events = defaultdict(list)
        for name, kind, stamp in ui["clocks"]:
            if name == turn:
                events[kind].append(stamp)
        coverage[turn] = {"requests": len(events["http_request_received"]),
                          "reply_seen": len(events["reply_seen"]), "reply_verified": len(events["reply_verified"])}
        if not events["reply_verified"]:
            continue
        [begin], [reply], [verified] = events["send"], events["reply_seen"], events["reply_verified"]
        requests, responses = events["http_request_received"], events["http_response_sent"]
        if len(requests) != count or len(responses) != count or not begin <= reply <= verified:
            raise ValueError("Incomplete original pilot evidence")
        windows[turn + "/all"] = begin, reply
        windows[turn + "/before-first-http"] = begin, requests[0]
        for i, response in enumerate(responses):
            after = requests[i + 1] if i < count - 1 else reply
            if not begin <= requests[i] <= response <= after <= reply:
                raise ValueError("Reversed original HTTP windows")
            window = f"after-response-{i+1}" if i < count - 1 else "final-response-to-reply"
            windows[f"{turn}/{window}"] = response, after
    if not windows:
        raise ValueError("No verified original reply present at checkpoint")
    return {"kind": "partial, source-qualified diagnostic windows", "qualifying": False,
            "native_shutdown_verified": False, "coverage_at_checkpoint": coverage,
            "roles": {role: {"pid": doc["pid"], "source_validation_seconds": doc["preparation_seconds"],
                             "windows": {name: summarize(stacks, ticks, *bounds) for name, bounds in windows.items()}}
                      for role, (doc, stacks, ticks) in records.items()}}


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("run", type=Path)
    parser.add_argument("--output", required=True, type=Path)
    args = parser.parse_args()
    result = analyze(args.run)
    with args.output.open("x", encoding="utf-8") as out:
        json.dump(result, out, indent=2)
        out.write("\n")
