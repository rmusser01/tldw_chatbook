"""Exercise a two-role checkpoint, fixed original clocks, source refusal and a still-incomplete edit."""
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import sys
import tempfile

here = Path(__file__).resolve().parent
sys.path.insert(0, str(here))
from attach import attach
from analyze_checkpoint import analyze


def load(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def sha(data):
    return hashlib.sha256(data).hexdigest()


with tempfile.TemporaryDirectory() as temp:
    root = Path(temp).resolve()
    (root / "parent").mkdir()
    original = (here.parent / "task62-stack-census" / "observer.py").read_bytes()
    for directory in (root, root / "parent"):
        (directory / "observer.py").write_bytes(original)
    attach(root)
    sampler = load("stack_checkpoint_synthetic", root / "observer.py")
    run = root / "replay-runs" / "g-test"
    run.mkdir(parents=True)
    os.environ["TLDW_TEST_LATENCY_PROGRESS"] = str(run / "progress.jsonl")
    os.environ["TLDW_TEST_LAB_RUN_ID"] = "test-run-token-not-exported"
    source = root / "sample.py"
    source.write_text("def work():\n    return 21\n")
    plugin_path = root / "task40608_lab_observer.py"
    plugin_path.write_text("class _Observation:\n    def _returned(self):\n        pass\n")
    plugin = load("task40608_lab_observer", plugin_path)
    sys.modules[plugin.__name__] = plugin
    state = plugin._state = plugin._Observation()
    state.guard_started, state.attempts, state.backend_pids = True, [], {202}
    events = [("readme", "send", 1)]
    for i in range(5):
        events.extend([("readme", "http_request_received", 2 + i * 2),
                       ("readme", "http_response_sent", 2.3 + i * 2)])
    events.extend([("readme", "reply_seen", 12), ("readme", "reply_verified", 13), ("edit", "send", 18)])
    state.events = [{"turn": t, "event": k, "trace_start": 100, "t": v, "private": "never_export_me"}
                    for t, k, v in events]
    manifest = root / "replay-manifest.json"
    manifest.write_text(json.dumps({"candidate_sources": {plugin_path.name: sha(plugin_path.read_bytes())}}))
    (run / "run-metadata.json").write_text(json.dumps({"manifestSha256": sha(manifest.read_bytes()),
        "originalJourneySha256": "test", "candidateJourneySha256": "test"}))
    census = sampler.Census([("app", source.name, sha(source.read_bytes()))], {"app": root})
    work = load("sample", source).work
    ident = census.code_id(work.__code__)
    census.stacks[((ident, 2),)] = 1
    marker = run / "stack-checkpoint.request"
    marker.touch()
    old_getpid = os.getpid
    for name, pid in (("task40608_tool_foreground", 101), ("task40608_tool_foreground_backend", 202)):
        try:
            os.getpid = lambda: pid
            chk = sampler.StackCheckpoint(root, root / name, 100)
            for stamp in range(20):
                chk.tick(stamp, [[0, 1]], census)
            chk.close()
        finally:
            os.getpid = old_getpid
    report = analyze(run)
    assert report["coverage_at_checkpoint"] == {
        "readme":{"requests":5,"reply_seen":1,"reply_verified":1},
        "edit":{"requests":0,"reply_seen":0,"reply_verified":0}}
    assert report["qualifying"] is False and report["native_shutdown_verified"] is False
    assert report["roles"]["backend"]["windows"]["readme/all"]["ticks"] == 11
    public = [p.read_text() for p in run.glob("stack-checkpoint-*.json")]
    assert len(public) == 2 and not any("never_export_me" in s or "test-run-token" in s for s in public)
    source.write_bytes(source.read_bytes() + b"# unexpected drift")
    failed = sampler.StackCheckpoint(root, root / "task40608_tool_foreground_backend", 100)
    failed.write(census, [(1, [[0, 1]])])
    assert len(list(run.glob("*.refused"))) == 1 and len(list(run.glob("stack-checkpoint-*.json"))) == 2
    print("PASS two independently qualified role checkpoints, real clock receiver identity, incomplete edit, privacy and drift")
