# Windows Console source-check timings

This diagnostic times seven synchronous guard functions in the parent and contained backend. It also samples which of 34 selected product functions appear on active thread stacks every 50 ms. The clock boundaries come from the original README and approved-edit pilot. Only the separate guard-only paired runs qualify the performance target.

## Reproduce

Use CPython 3.12 and the original guarded replay kit. Start with a separate, unused process replay at the chosen commit. The included source pins describe commit `737e2a1ba88f2fcc3c7ac8fb20dc5fe2192ed46b`. The preparer derives pins from the chosen replay manifest and verifies every selected code object against the actual file.

```powershell
python -I -S -B verify.py
python -I -S -B prepare.py --replay FRESH_REPLAY --installer installer --destination FRESH_OBSERVER
Copy-Item -LiteralPath installer/install_tool_foreground.py -Destination REPLAY_TOOLS/install_tool_foreground.py
python -I -B REPLAY_TOOLS/install_tool_foreground.py --candidate-directory FRESH_REPLAY --replay-tools REPLAY_TOOLS --observer-source FRESH_OBSERVER --check-only
python -I -B REPLAY_TOOLS/install_tool_foreground.py --candidate-directory FRESH_REPLAY --replay-tools REPLAY_TOOLS --observer-source FRESH_OBSERVER
& REPLAY_TOOLS/run_replay.ps1 -CandidateDirectory FRESH_REPLAY -RunLabel g56s -Exhaustive
python -I -S -B analyze.py FRESH_REPLAY/replay-runs/g56s
```

Use a fresh short run label if `g56s` already exists. Install into a disposable replay-tools directory containing the original verifier and runner. A matching copy of the included installer may already be present. The native runner retains the original socket guards, fixture, provider, assertions and source checks.

## Read the results

The seven timers cover selection of the active client, detached reader validation, backend and domain source checks, backend presentation definitions, and the change-review marker reader and factory. A timer starts at the original function's entry and stops at return or unwind. The analyzer reports completed calls, exceptions, inclusive wall and thread CPU time, wall time excluding synchronous nested timed guards, and the union of wall intervals clipped to the original window. Cross-window calls appear separately. Counts are complete for a window only if the target attached before its beginning. A target never loaded by a process has no registration there.

The sampled stacks cover authorization, file qualification, named metadata, project-index preparation, workspace policy, DB step writes and selected guard functions. A sample can contain several nested labels and multiple active threads. Each label contributes at most once to a sample. Sample counts identify where threads were observed. They do not measure exclusive CPU or prove the critical path.

The sampler emits fixed labels, numeric thread ordinals, times and counts. The synthetic test exercises nested timers, the original exception path, body-free output, source drift, crossing intervals and an interrupted receipt. The parser requires complete summaries from both processes. Observer and scheduling overhead remain in the instrumented run. Its times cannot be used as clean-pair results.
