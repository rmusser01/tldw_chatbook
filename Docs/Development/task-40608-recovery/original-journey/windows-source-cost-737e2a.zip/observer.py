"""Nonqualifying sampled Windows backend stacks. Only enumerated labels leave memory."""
import hashlib
import json
import os
from collections import deque
from pathlib import Path
import sys
import threading
import time
from types import CodeType, FunctionType


# Functions that can distinguish independently owned work inside the observed
# Send and model windows. Never export a filename, a live frame or its locals.
TARGETS = {
    "Backup_Recovery.storage_admission": {
        "_acquire_storage": "admission", "_windows_inputs": "authority_inputs",
        "_observe_evidence": "metadata_union", "_scope": "full_derivation",
    },
    "Backup_Recovery.qualification": {"_load_evidence": "qualification_file"},
    "Utils.windows_files": {
        "WindowsOS.stat_many_for_admission": "named_metadata",
        "_Native.open_handle": "named_open", "_Native.ntfs": "volume_check",
        "_Native.info": "handle_info", "_Native.security": "security_descriptor",
        "_component": "component_check",
    },
    "Chat.console_domain_services": {
        "ConsoleDomainServices.require_current": "domain_current",
        "ConsoleDomainServices.configuration_sources": "configuration_sources",
    },
    "Chat.console_backend_presentation": {
        "ConsoleBackendPresentation.definitions_current": "presentation_current",
    },
    "Chat.console_execution_readers": {"require_reader_sources": "reader_sources"},
    "UI.Console_Modules.execution_state": {"selected_client": "selected_client"},
    "Chat.console_execution_backend": {"ConsoleExecutionBackend.require_sources": "backend_sources"},
    "Chat.console_change_review_read": {
        "_factory_sources_current": "marker_factory", "_MarkerRead.require_current": "marker_current",
    },
    "Utils.definition_records": {"definitions_current": "definition_records"},
    "Chat.console_configuration_preparation": {
        "capture_console_turn_configuration_owned": "turn_configuration",
    },
    "Chat.console_turn_context": {
        "resolve_turn_tool_policy_profile_id": "workspace_policy",
        "resolve_turn_persona_policy_rules": "persona_policy",
    },
    "Chat.console_project_index_preparation": {
        "prepare_project_index_scopes": "index_worker",
    },
    "Workspaces.project_index.runtime": {
        "_AdmittedStoreFactory.retain": "index_data_pin",
        "_project_index_key_owned": "index_key",
        "_console_missing_index_base": "index_absence",
    },
    "Agents.run_log": {"RunLogWriter.append": "run_log"},
    "DB.AgentRuns_DB": {"AgentRunsDB.insert_steps_at_indices": "step_write"},
    "Agents.local_tool_provider": {"LocalToolProvider._invoke_detailed": "local_tool"},
    "Chat.console_received_dispatch": {"run_received_intent": "received_intent"},
    "Chat.console_streaming_request": {"chat_call_impl": "model_bridge"},
    "Chat.console_backend_readiness": {"ConsoleBackendReadiness.current_value": "readiness"},
    "Utils.sensitive_paths": {"resolve_sensitive_context": "sensitive_paths"},
}

TIMED = {"reader_sources", "selected_client", "backend_sources", "domain_current",
         "marker_current", "marker_factory", "presentation_current"}


class GuardTimes:
    """Count selected synchronous bodies on actual threads, including exceptional exits."""

    def __init__(self, expected, origin, thread_ids):
        self.wanted = [(name, qualname, spec) for (name, qualname), spec in expected.items()
                       if spec[2] in TIMED]
        self.origin = origin
        self.threads = thread_ids
        self.registered = {}
        self.codes = {}
        self.stacks = {}
        self.pending = deque()
        self.mismatch = set()
        self.events = self.orphans = 0
        self.cap = 100_000
        self.slot = next(i for i in (5, 4, 3, 2, 1, 0) if sys.monitoring.get_tool(i) is None)
        mon = sys.monitoring
        mon.use_tool_id(self.slot, "task40608_guard_times")
        mon.register_callback(self.slot, mon.events.PY_START, self.start)
        mon.register_callback(self.slot, mon.events.PY_RETURN, self.end)
        mon.register_callback(self.slot, mon.events.PY_UNWIND, self.unwind)
        mon.set_events(self.slot, mon.events.PY_UNWIND)

    def discover(self):
        for module_name, qualname, (path, pinned, label) in self.wanted:
            current = sys.modules.get(module_name)
            if current is None:
                continue
            for name in qualname.split("."):
                current = vars(current).get(name)
                if current is None:
                    break
            if current is None and label not in self.registered:
                continue
            if (type(current) is not FunctionType or os.path.normcase(current.__code__.co_filename) != path
                    or current.__code__ != pinned
                    or label in self.registered and (self.registered[label][0] is not current
                        or self.registered[label][1] is not current.__code__)):
                self.mismatch.add(label)
                continue
            if label not in self.registered:
                self.registered[label] = current, current.__code__, time.perf_counter() - self.origin
                self.codes[id(current.__code__)] = label
                mon = sys.monitoring
                mon.set_local_events(self.slot, current.__code__, mon.events.PY_START | mon.events.PY_RETURN)

    def start(self, code, offset):
        label = self.codes.get(id(code))
        if label is None:
            return
        ident = threading.get_ident()
        stack = self.stacks.setdefault(ident, [])
        stack.append([code, label, time.perf_counter(), time.thread_time(), 0.0])

    def end(self, code, offset, value):
        self.finish(code, False)

    def unwind(self, code, offset, exception):
        if id(code) in self.codes:
            self.finish(code, True)

    def finish(self, code, unwound):
        end, cpu = time.perf_counter(), time.thread_time()
        ident = threading.get_ident()
        stack = self.stacks.get(ident)
        if not stack:
            # Discovery can attach to a function already in progress.
            self.orphans += 1
            return
        if stack[-1][0] is not code:
            self.mismatch.add("guard_stack")
            return
        _, label, start, start_cpu, children = stack.pop()
        duration = end - start
        if stack:
            stack[-1][-1] += duration
        self.events += 1
        if self.events <= self.cap:
            thread = self.threads.setdefault(ident, len(self.threads) + 1)
            self.pending.append(["guard", label, thread, start - self.origin, end - self.origin,
                                 cpu - start_cpu, duration - children, int(unwound)])

    def flush(self, emit):
        while self.pending:
            emit(self.pending.popleft())

    def close(self, emit):
        mon = sys.monitoring
        mon.set_events(self.slot, 0)
        for _, code, _ in self.registered.values():
            mon.set_local_events(self.slot, code, 0)
        for event in (mon.events.PY_START, mon.events.PY_RETURN, mon.events.PY_UNWIND):
            mon.register_callback(self.slot, event, None)
        mon.free_tool_id(self.slot)
        self.flush(emit)
        emit(["guard_summary", {name: stamp for name, (_, _, stamp) in self.registered.items()},
              self.events, self.events > self.cap, sorted(self.mismatch), self.orphans,
              sum(map(len, self.stacks.values()))])


def resolve_codes(source, filenames, targets):
    expected = {}
    for module, functions in targets.items():
        path = source / "tldw_chatbook" / (module.replace(".", "/") + ".py")
        data = path.read_bytes()
        if hashlib.sha256(data).hexdigest() != filenames[module]:
            raise ValueError("Sampled source changed")
        codes = [compile(data, str(path), "exec", dont_inherit=True)]
        found = set()
        while codes:
            code = codes.pop()
            codes.extend(item for item in code.co_consts if type(item) is CodeType)
            label = functions.get(code.co_qualname)
            if label is not None:
                if label in found:
                    raise ValueError("Ambiguous sampled source")
                found.add(label)
                expected["tldw_chatbook." + module, code.co_qualname] = (
                    os.path.normcase(str(path)), code, label,
                )
        if found != set(functions.values()):
            raise ValueError("Sampled function missing")
    return expected


def install(stream):
    package = Path(__file__).resolve().parent
    origin = time.perf_counter()
    expected = resolve_codes(
        package.parent, json.loads((package / "source-pins.json").read_bytes()), TARGETS
    )
    qualified = {}
    rejected = set()
    thread_ids = {}
    guards = GuardTimes(expected, origin, thread_ids)
    stopped = threading.Event()
    ticks = 0
    max_ticks = 7200
    overhead = 0.0
    truncated = failed = False

    def emit(row):
        stream.write("CRITICAL_SAMPLE " + json.dumps(row, separators=(",", ":")) + "\n")

    def snapshot(frames):
        nonlocal truncated
        observations = []
        for ident, frame in frames.items():
            if ident == threading.get_ident():
                continue
            labels = []
            depth = 0
            while frame is not None and depth < 160:
                code = frame.f_code
                record = expected.get((frame.f_globals.get("__name__"), code.co_qualname))
                if record is not None:
                    identity = id(code)
                    if identity not in qualified:
                        path, pinned, label = record
                        # Compile with the running interpreter, including its optimize level.
                        # Exact file plus bytecode/constants avoids accepting replacement bodies.
                        if os.path.normcase(code.co_filename) != path or code != pinned:
                            rejected.add(label)
                        else:
                            qualified[identity] = code
                    if qualified.get(identity) is code:
                        labels.append(record[2])
                frame = frame.f_back
                depth += 1
            if frame is not None:
                truncated = True
            if labels:
                ordinal = thread_ids.setdefault(ident, len(thread_ids) + 1)
                observations.append([ordinal, labels])
        return observations

    def sample():
        nonlocal ticks, overhead, failed
        try:
            while ticks < max_ticks and not stopped.wait(0.050):
                start = time.perf_counter()
                if ticks % 10 == 0:
                    guards.discover()
                guards.flush(emit)
                observations = snapshot(sys._current_frames())
                emit(["tick", start - origin, observations])
                ticks += 1
                if ticks % 20 == 0:
                    stream.flush()
                overhead += time.perf_counter() - start
        except Exception:
            failed = True

    emit(["installed", origin, time.perf_counter() - origin])
    stream.flush()
    watcher = threading.Thread(target=sample, name="task40608-sampler", daemon=True)
    watcher.start()

    def close():
        stopped.set()
        watcher.join()
        guards.close(emit)
        emit(["closed", ticks, overhead, sorted(rejected), truncated, failed, ticks >= max_ticks])
        stream.flush()
    return close
