"""Prepare a source-pinned observer for the original disposable replay installer."""
import argparse
import hashlib
import json
from pathlib import Path
import shutil
import sys

# -I -S keeps application code, site and its optional dependencies out of this tool.
sys.path.insert(0, str(Path(__file__).resolve().parent))
from observer import TARGETS, resolve_codes


def prepare(replay, installer, destination):
    here = Path(__file__).resolve().parent
    manifest = json.loads((replay / "replay-manifest.json").read_bytes())
    pins = {key: manifest["candidate_sources"]["tldw_chatbook/" + key.replace(".", "/") + ".py"]
            for key in TARGETS}
    sources = resolve_codes(replay, pins, TARGETS)
    destination.mkdir(parents=True, exist_ok=False)
    (destination / "parent").mkdir()
    (destination / "source-pins.json").write_text(json.dumps(pins) + "\n", encoding="utf-8")
    shutil.copyfile(here / "observer.py", destination / "observer.py")
    for name in ("observer.py", "source-pins.json"):
        shutil.copyfile(destination / name, destination / "parent" / name)
    for name in ("deferred.py", "install_tool_foreground.py"):
        shutil.copyfile(installer / name, destination / name)
    print(json.dumps({"diagnostic": "sampled_critical_path", "native_workload": False,
                      "sampled_functions": len(sources), "commit": manifest["candidate_commit"],
                      "observer_sha256": hashlib.sha256((destination / "observer.py").read_bytes()).hexdigest()}))


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    for name in ("replay", "installer", "destination"):
        parser.add_argument("--" + name, type=Path, required=True)
    args = parser.parse_args()
    prepare(args.replay.resolve(strict=True), args.installer, args.destination)
