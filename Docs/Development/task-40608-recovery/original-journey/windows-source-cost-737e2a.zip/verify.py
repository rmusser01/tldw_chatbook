"""Synthetic controls for code qualification, sampling, limits and original clock windows."""
import hashlib
import importlib.util
import io
import json
from pathlib import Path
import sys
import tempfile
import threading
import time


def module(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return mod


here = Path(__file__).resolve().parent
analyze = module("critical_analyze", here / "analyze.py").analyze
with tempfile.TemporaryDirectory(dir=here) as temporary:
    root = Path(temporary)
    product = root / "tldw_chatbook"
    product.mkdir()
    path = product / "test_sample.py"
    sentinel = "private-content-not-for-observer"
    path.write_text("def owned(block, value):\n    return inside(block, value)\n"
                    "def inside(block, value):\n    block.wait(1)\n    return value\n"
                    "def refused():\n    raise LookupError('private-content-not-for-observer')\n")
    probe_path = root / "probe"
    probe_path.mkdir()
    (probe_path / "source-pins.json").write_text(json.dumps({
        "test_sample": hashlib.sha256(path.read_bytes()).hexdigest()
    }))
    monitor = module("critical_monitor", here / "observer.py")
    monitor.__file__ = str(probe_path / "observer.py")
    monitor.TARGETS = {"test_sample": {"owned": "fixed_label", "inside": "child", "refused": "refusal"}}
    monitor.TIMED = {"fixed_label", "child", "refusal"}
    real = module("tldw_chatbook.test_sample", path)
    sys.modules[real.__name__] = real
    stream = io.StringIO()
    close = monitor.install(stream)
    deadline = time.monotonic() + 3
    while '"tick"' not in stream.getvalue():
        if time.monotonic() >= deadline:
            raise AssertionError("Sampler did not start")
        time.sleep(0.01)
    block = threading.Event()
    worker = threading.Thread(target=real.owned, args=(block, sentinel))
    worker.start()
    time.sleep(0.2)
    block.set()
    worker.join()
    try:
        real.refused()
    except LookupError:
        pass
    close()
    del sys.modules[real.__name__]
    rows = [json.loads(row.partition(" ")[2]) for row in stream.getvalue().splitlines()]
    assert sentinel not in stream.getvalue() and str(root) not in stream.getvalue()
    assert rows[0][0] == "installed" and rows[-1][0] == "closed"
    assert rows[-1][3:] == [[], False, False, False], rows[-1]
    assert any("fixed_label" in stack for _, _, observed in (r for r in rows if r[0] == "tick")
               for _, stack in observed)
    guard_calls = {row[1]:row for row in rows if row[0] == "guard"}
    assert set(guard_calls) == monitor.TIMED and guard_calls["refusal"][7] == 1
    parent, child = guard_calls["fixed_label"], guard_calls["child"]
    assert parent[2] == child[2] and parent[3] <= child[3] < child[4] <= parent[4]
    assert abs((parent[4]-parent[3]) - parent[6] - (child[4]-child[3])) < 1e-6
    try:
        monitor.resolve_codes(root, {"test_sample": "bad"}, monitor.TARGETS)
    except ValueError:
        pass
    else:
        raise AssertionError("Changed source allowed")

    logs = root / "lab-observer"
    logs.mkdir()
    events = [["installed", 100, 0], *[
        ["tick", stamp, [[1, ["authority_inputs", "admission"]], [2, ["admission"]]]]
        for stamp in (0.1, 1.1, 2.1, 3.1)
    ], ["guard","one",1,.1,.4,.02,.3,0], ["guard","one",2,.3,1.1,.01,.8,1],
        ["guard_summary",{"one":0},2,False,[],0,0],["closed", 4, 0.001, [], False, False, False]]
    def receipt_rows(rows):
        for role in ("ui", "backend"):
            receipt = logs / f"tool-foreground-{role}-1.jsonl"
            receipt.write_text("".join("CRITICAL_SAMPLE " + json.dumps(row) + "\n" for row in rows))
    receipt_rows(events)
    (logs / "ui-1.json").write_text(json.dumps({
        "guard_finished": True, "blocked_destinations": [],
        "events": [{"trace_start": 100, "turn": turn, "event": event, "t": t + i}
                   for turn, t in (("readme", 0), ("edit", 2))
                   for i, event in enumerate(("send", "http_request_received", "reply_seen"))]
    }))
    windows = analyze(root)["backend"]["windows"]
    assert len(windows) == 4
    assert all(v["ticks"] == v["labels_present"]["admission"] == 1 for v in windows.values())
    timing = windows["readme_before_first_http"]["timed_guards"]["one"]
    assert timing["completed_inside"] == timing["crossing"] == 1
    assert timing["clipped_wall_union_seconds"] == .9
    receipt_rows(events[:-1])
    try:
        analyze(root)
    except ValueError:
        pass
    else:
        raise AssertionError("Partial sample counted")
print("PASS fixed-code sampled worker, source drift, private-value omission, original timing windows, partial refusal")
