"""Group sampled backend work against the original same-host monotonic journey."""
import argparse
import collections
import json
from pathlib import Path


def report(source, points):
    rows = [json.loads(line.removeprefix("CRITICAL_SAMPLE "))
            for line in source.read_text("utf-8").splitlines()]
    if rows[0][0] != "installed" or rows[-1][0] != "closed":
        raise ValueError("Partial sampled attempt")
    origin = rows[0][1]
    ticks = [row for row in rows if row[0] == "tick"]
    guards = [row for row in rows if row[0] == "guard"]
    summary, = (row for row in rows if row[0] == "guard_summary")
    _, registration, guard_count, overflow, changed, orphan, unfinished = summary
    _, count, overhead, refused, depth_limited, failed, capped = rows[-1]
    if count != len(ticks) or not count or refused or depth_limited or failed or capped:
        raise ValueError("Incomplete sampled attempt")
    if guard_count != len(guards) or overflow or changed or unfinished:
        raise ValueError("Guard timings refused or truncated")
    result = {}
    for name in ("readme", "edit"):
        times = {kind: next(point["trace_start"] + point["t"] for point in points
                            if point.get("turn") == name and point["event"] == kind)
                 for kind in ("send", "http_request_received", "reply_seen")}
        for title, start, end in (
            ("before_first_http", times["send"], times["http_request_received"]),
            ("after_first_http", times["http_request_received"], times["reply_seen"]),
        ):
            sampled = [observations for phase, stamp, observations in ticks
                       if phase == "tick" and start <= origin + stamp < end]
            if not sampled:
                raise ValueError("No ticks in original window")
            tick_coverage = collections.Counter()
            for observations in sampled:
                # One tick counts at most once per label, irrespective of thread count.
                tick_coverage.update({label for _, stack in observations for label in stack})
            targets = {}
            for label, attached in registration.items():
                calls = [row for row in guards if row[1] == label
                         and origin + row[3] < end and origin + row[4] > start]
                contained = [row for row in calls if start <= origin + row[3] and origin + row[4] <= end]
                last, union = start, 0.0
                for row in sorted(calls, key=lambda r: r[3]):
                    right = min(end, origin + row[4])
                    union += max(0.0, right - max(last, origin + row[3]))
                    last = max(last, right)
                targets[label] = {
                    "attached_before_window": origin + attached <= start, "completed_inside": len(contained),
                    "crossing": len(calls) - len(contained), "unwinds_inside": sum(r[7] for r in contained),
                    "inclusive_seconds_inside": round(sum(r[4] - r[3] for r in contained), 6),
                    "thread_cpu_seconds_inside": round(sum(r[5] for r in contained), 6),
                    "seconds_excluding_nested_timed_guards_inside": round(sum(r[6] for r in contained), 6),
                    "clipped_wall_union_seconds": round(union, 6),
                }
            result[name + "_" + title] = {
                "elapsed_seconds": round(end - start, 6),
                "ticks": len(sampled), "labels_present": dict(tick_coverage.most_common()),
                "timed_guards": targets,
            }
    return {"sampler_wall_seconds": overhead, "unpaired_attach_returns": orphan,
            "compile_seconds_before_worker_entry": rows[0][2], "windows": result}


def analyze(directory):
    logs = directory / "lab-observer"
    original, = logs.glob("ui-*.json")
    guard = json.loads(original.read_bytes())
    if not guard["guard_finished"] or guard["blocked_destinations"]:
        raise ValueError("Original parent network guard incomplete")
    result = {"qualifying": False}
    for role in ("ui", "backend"):
        source, = logs.glob("tool-foreground-" + role + "-*.jsonl")
        result[role] = report(source, guard["events"])
    return result


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("directory", type=Path)
    print(json.dumps(analyze(parser.parse_args().directory), indent=2))
