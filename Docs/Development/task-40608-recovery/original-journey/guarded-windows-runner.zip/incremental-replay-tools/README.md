# Incremental original-journey replay

This lab-only tool freezes a committed product delta onto the verified 48b730
original-journey replay. It retains the original #3496 overlay, both original QA
files and assertions, the pinned profile-core package, and the original private
profile entry. No live product, original `before/` source, standard runner, or
existing replay is edited. ADR-126/230 continue to govern product behavior.

The fresh replay owns its import environment. Unchanged manifest-pinned source
files use native hard links. The three original QA/trace/socket-guard files are
independent, read-only copies. Git applies the exact binary delta to private
preimages in a separate staging directory. Changed files are installed with
`os.replace`, so an inherited hard link is never written through. Unknown patch
conflicts fail closed; the tool never discards the original controller overlay.

Only two fixed lab product differences are present: the App constructor selects
`process`, and the canonical backend bootstrap enters the unchanged original
`only_owned_server(actual_port)` guard before calling the same worker module.
The copied observer is the existing `original-journey-child-observer` artifact;
its README explains actual PID/port/exit receipts and diagnostic counts. The
default mode is `guard`, without admission monitoring. Neither difference is
applied to the PR product.

## Single-command next candidate

Run from any directory. Use a fresh label and a committed SHA. Omitting `--seed`
uses the pinned 48b730 replay; supplying a later frozen replay reduces the delta.

```powershell
$v = 'C:/Users/GDesktop-1/.codex/visualizations/2026/11/12/01a1d221-2d16-7b61-ad34-242e2e3f86cf/task-40608/verification'
$tools = "$v/test-snapshots/incremental-replay-tools"
& "$v/worktree-env/Scripts/python.exe" -I -B "$tools/replay.py" build --candidate COMMITTED-SHA --label UNIQUE-LABEL
```

This command never starts the app or a native workload. It creates
`test-snapshots/original-journey-UNIQUE-LABEL`, records the exact git patch, seed
manifest, pre/postimage hashes, changed paths, fixed lab pins and tool hashes,
then performs the fast diagnostic check. Files are read/written as bytes; Git
uses the original replay's `core.autocrlf=true` behavior and explicit Windows
long-path support. Original QA is never passed through text conversion.

Do not edit a completed replay or write through any linked source. Build a fresh
directory for the next SHA. Pytest uses the original private profile and disables
bytecode and its cache provider. Generated logs live under `replay-runs/`, not
inside source files. The new environment explicitly includes its own root and
`packages/tldw_profile_core/src` before shared dependencies; the unchanged
canonical `-I -S` backend launcher discovers those same application roots.

## Launch and verification

Only root launches Windows workloads. Use a fresh **short private run label**
such as `g1`, `g2`, `b1`, or `c1`. The label becomes part of the original private
fixture's disposable Git path. On this host, `win10-999b90-guarded-01` pushed
`.git/objects` beyond MAX_PATH and failed before App setup; root retried the
identical frozen candidate with `g1`. Keep descriptive labels on the replay
directory, not the private run. No product or fixture change is needed.

The alternate runner preserves the exact
original pytest node and native private-directory setup, automatically scopes
and restores `PYTEST_PLUGINS=task40608_lab_observer`, copies original artifacts,
and preserves failed pytest/guard exit status.

```powershell
$candidate = "$v/test-snapshots/original-journey-win10-999b90-guarded"
& "$tools/run_replay.ps1" -CandidateDirectory $candidate -RunLabel g2
```

Default verification is **diagnostic**: it trusts unchanged entries in the
verified seed manifest and rehashes the exact changed cohort, previous diagnostic
cohorts, original QA/guard, profile-core package, lab plugin/config, provenance,
import roots and tools. It does not claim that an unexamined source could not
have changed. The run metadata explicitly records `diagnostic-pins`.

For final qualification, use `-Exhaustive`; this rehashes every candidate source
and every original source both before and after the run. Guarded baseline and
candidate must still run sequentially with the original journey outcomes,
30% comparison and each candidate's sub-five-second checks. This artifact does
not supply successful timings or qualification evidence.

```powershell
& "$tools/run_replay.ps1" -CandidateDirectory $candidate -RunLabel c1 -Exhaustive
& "$tools/run_replay.ps1" -CandidateDirectory $candidate -RunLabel v -VerifyOnly
```

For symmetric baseline guard installation and optional separate `counts` runs,
use the companion observer README. Original `costs.json` describes UI-process
work only; the observer's supplemental report reports actual backend work. The
unchanged timing summary still reports original endpoints plus the common
`reply_seen` endpoint; backend execution timings remain unobserved without the
separate count run. Counts-mode latency is not qualification evidence.

## Frozen screening input and checks

- Candidate: `999b90d61ca6770c98beb8a1bf568b6575aa546c`.
- Replay: `original-journey-win10-999b90-guarded`.
- Manifest SHA256: `4b8b4f88b2a28ea9ec6b5b67007324b2f7e23dd2d746ce06b754f6baf58141fa`.
- Chain: verified 48b730 plus exact 12-file delta to 156055, then exact one-file
  delta to 999b90. `product_diff_sha256` inherited from the old builder identifies
  the original base-to-48b730 patch; subsequent exact patches are identified by
  each `incremental_replay` record and retained seed manifests.
- Actual build times: 42.078 seconds for the first linked copy; 37.391 seconds
  for the next fresh copy. Native link creation still traverses source metadata;
  it avoids repeated file-content hashing/copying.
- Actual pre-launch verification: 116 diagnostic pins in 0.515 seconds.
- Old 48b730 and 156055 manifest hashes remained unchanged. Source-only checks
  confirmed QA byte equality, read-only independent QA file identities, changed
  file independence and actual unchanged native hard links.
- Isolated and ordinary interpreter import-spec checks resolved `tldw_chatbook`,
  `Tests`, and `tldw_profile_core` into the replay (ordinary interpreter checked
  from its actual replay working directory). No product module was imported.
- Configured Ruff and PowerShell parser checks pass. Native journeys are run
  separately by root; no successful journey or performance result is claimed.

The first unused failed attempt remains as evidence: Git rejected long paths
before cloning sources. Explicit `core.longpaths=true` fixes the build itself.
No partial directory is reused or deleted automatically.
