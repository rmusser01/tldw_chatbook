"""Freeze a committed product delta over the verified original-journey overlay.

Diagnostic verification deliberately trusts unchanged seed manifest entries.
Use verify --exhaustive before qualification. No application is imported here.
"""

from __future__ import annotations

import argparse
import ast
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import stat
import subprocess
import time
import venv

HERE = Path(__file__).resolve().parent
SNAPSHOTS = HERE.parent
LAB = SNAPSHOTS.parent
REPO = Path("C:/Users/GDesktop-1/.codex/worktrees/task-40608-windows-admission/tldw_tui")
SEED = SNAPSHOTS / "original-journey-win10-48b730-screen"
SEED_MANIFEST = "643148b7c43f6e88e96b956b15e84c5aa5e17b071aa4d139c2be03d7989cf06d"
OBSERVER = SNAPSHOTS / "original-journey-child-observer"
APP = "tldw_chatbook/app.py"
PROCESS = "tldw_chatbook/Chat/console_execution_process.py"
QA = ("Tests/QA/test_task40608.py", "Tests/QA/task40608_trace.py", "Tests/uat_project_chat_support.py")
LOCAL = b'console_execution: str = "local"'
SELECTED = b'console_execution: str = "process"'
STOCK_BOOT = b";runpy.run_module('tldw_chatbook.Chat.console_execution_worker',run_name='__main__')"
GUARDED_BOOT = b";import task40608_lab_observer;task40608_lab_observer.run_backend()"
TOOLS = ("replay.py", "inspect_replay.py", "run_replay.ps1")


def sha(data):
    return hashlib.sha256(data).hexdigest()


def encoded(value):
    return (json.dumps(value, indent=2) + "\n").encode("utf-8")


def child(root, name):
    path = root / name
    if not path.resolve().is_relative_to(root.resolve()):
        raise RuntimeError("Replay path escapes its root: " + name)
    return path


def atomic(path, data):
    """Replace a directory entry; never write through an inherited hard link."""
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_name(path.name + ".replay-tmp")
    with temporary.open("xb") as stream:
        stream.write(data)
    os.replace(temporary, path)


def git(*arguments, cwd=REPO):
    result = subprocess.run(
        ["git", "-c", "safe.directory=" + REPO.as_posix(), "-c", "core.autocrlf=true",
         "-c", "core.longpaths=true", *arguments],
        cwd=cwd, capture_output=True, check=False,
    )
    if result.returncode:
        raise RuntimeError(result.stderr.decode("utf-8", errors="replace"))
    return result.stdout


def verify(directory, exhaustive=False):
    directory = directory.resolve(strict=True)
    manifest = json.loads((directory / "replay-manifest.json").read_bytes())
    if Path(manifest["candidate_directory"]).resolve() != directory:
        raise RuntimeError("Replay moved; its import environment is no longer valid")
    names = manifest["candidate_sources"] if exhaustive else manifest["diagnostic_sources"]
    for name, expected in names.items():
        if sha(child(directory, name).read_bytes()) != expected:
            raise RuntimeError("Replay source pin changed: " + name)
    for name in QA:
        if child(directory, name).read_bytes() != child(LAB / "before", name).read_bytes():
            raise RuntimeError("Original QA/guard changed: " + name)
    if exhaustive:
        for name, expected in manifest["original_sources"].items():
            if sha(child(LAB / "before", name).read_bytes()) != expected:
                raise RuntimeError("Original source pin changed: " + name)
    pth = directory / ".venv/Lib/site-packages/original-journey-source.pth"
    if sha(pth.read_bytes()) != manifest["environment_pth_sha256"]:
        raise RuntimeError("Replay import roots changed")
    for name, expected in manifest["tool_sha256"].items():
        if sha((HERE / name).read_bytes()) != expected:
            raise RuntimeError("Replay tool changed: " + name)
    return manifest


def build(candidate, label, seed=SEED, mode="guard"):
    started = time.monotonic()
    if not re.fullmatch(r"[A-Za-z0-9_-]+", label):
        raise ValueError("Use a plain fresh label")
    seed = seed.resolve(strict=True)
    if seed.parent != SNAPSHOTS or not seed.name.startswith("original-journey-"):
        raise RuntimeError("Seed must be a fixed original-journey lab replay")
    raw_manifest = (seed / "replay-manifest.json").read_bytes()
    previous = json.loads(raw_manifest)
    if seed == SEED:
        if sha(raw_manifest) != SEED_MANIFEST:
            raise RuntimeError("Verified 48b730 seed manifest changed")
    else:
        verify(seed)
    head = git("rev-parse", candidate + "^{commit}").decode().strip()
    old = previous["candidate_commit"]
    git("merge-base", "--is-ancestor", old, head)
    target = SNAPSHOTS / ("original-journey-" + label)
    if target.exists():
        raise FileExistsError("Choose a fresh replay label; old trees are never overwritten")
    patch = git("diff", "--binary", "--full-index", "--no-renames", old, head,
                "--", "tldw_chatbook", "packages/tldw_profile_core/src")
    changed = [name.decode() for name in git(
        "diff", "--name-only", "--no-renames", "-z", old, head,
        "--", "tldw_chatbook", "packages/tldw_profile_core/src",
    ).split(b"\0") if name]
    expected = dict(previous["candidate_sources"])
    checked = set(QA) | {APP, PROCESS} | set(changed)
    checked.update(name for name in expected if name.startswith("packages/tldw_profile_core/src/"))
    for name in checked:
        if name in expected and sha(child(seed, name).read_bytes()) != expected[name]:
            raise RuntimeError("Seed preimage changed: " + name)
    for name in QA:
        if child(seed, name).read_bytes() != child(LAB / "before", name).read_bytes():
            raise RuntimeError("Seed lost the original QA/guard: " + name)
    target.mkdir()
    provenance = target / "replay-provenance" / head[:12]
    provenance.mkdir(parents=True)
    work = provenance / "delta-work"
    work.mkdir()
    patch_path = provenance / "incremental.patch"
    atomic(patch_path, patch)
    atomic(provenance / "seed-manifest.json", raw_manifest)
    for name in changed:
        if name in expected:
            data = child(seed, name).read_bytes()
            if name == APP:
                if data.count(SELECTED) != 1:
                    raise RuntimeError("Lab App selector drifted")
                data = data.replace(SELECTED, LOCAL)
            if name == PROCESS and previous.get("lab_observer"):
                if data.count(GUARDED_BOOT) != 1:
                    raise RuntimeError("Lab bootstrap drifted")
                data = data.replace(GUARDED_BOOT, STOCK_BOOT)
            atomic(child(work, name), data)
    if patch:
        git("apply", "--whitespace=nowarn", "--check", str(patch_path), cwd=work)
        git("apply", "--whitespace=nowarn", str(patch_path), cwd=work)
    print(f"Exact {old[:10]} -> {head[:10]} delta applied to {len(changed)} private preimages", flush=True)
    linked = copied = 0
    for name in expected:
        destination = child(target, name)
        if destination.exists():
            raise RuntimeError("Provenance path collision: " + name)
        destination.parent.mkdir(parents=True, exist_ok=True)
        if name in QA:
            shutil.copyfile(child(seed, name), destination)
            destination.chmod(stat.S_IREAD)
            copied += 1
        else:
            os.link(child(seed, name), destination)
            linked += 1
    print(f"Cloned {linked} source links; {copied} private read-only original QA files", flush=True)
    records = {}
    for name in changed:
        staged = child(work, name)
        destination = child(target, name)
        before = expected.get(name)
        if staged.exists():
            data = staged.read_bytes()
            if data.endswith(b"\n") and name.endswith(".py"):
                ast.parse(data.decode("utf-8-sig"), filename=name)
            atomic(destination, data)
            expected[name] = sha(data)
        else:
            destination.unlink()
            expected.pop(name)
        records[name] = {"seed_sha256": before, "product_overlay_sha256": expected.get(name)}
    app = child(target, APP).read_bytes()
    if APP in changed:
        if app.count(LOCAL) != 1:
            raise RuntimeError("Canonical local-default constructor changed")
        app = app.replace(LOCAL, SELECTED)
        atomic(child(target, APP), app)
    elif app.count(SELECTED) != 1:
        raise RuntimeError("Inherited lab process selection changed")
    bootstrap = child(target, PROCESS).read_bytes()
    if previous.get("lab_observer") and PROCESS not in changed:
        bootstrap = bootstrap.replace(GUARDED_BOOT, STOCK_BOOT)
    if bootstrap.count(STOCK_BOOT) != 1:
        raise RuntimeError("Canonical backend bootstrap changed")
    guarded = bootstrap.replace(STOCK_BOOT, GUARDED_BOOT)
    ast.parse(guarded.decode("utf-8-sig"))
    atomic(child(target, PROCESS), guarded)
    plugin = "task40608_lab_observer.py"
    plugin_data = (OBSERVER / plugin).read_bytes()
    atomic(target / plugin, plugin_data)
    settings = {"mode": mode, "route": "process", "sources": {
        name: sha(child(target, name).read_bytes()) for name in (*QA, plugin)
    }}
    config = "task40608-lab-observer.json"
    atomic(target / config, encoded(settings))
    environment = target / ".venv"
    venv.EnvBuilder(with_pip=False).create(environment)
    pth = environment / "Lib/site-packages/original-journey-source.pth"
    # The UI/private-profile subprocess uses .pth; the -I -S backend discovers
    # the same local package source in the unchanged canonical _launch method.
    roots = [target.as_posix(), (target / "packages/tldw_profile_core/src").as_posix()]
    dependencies = Path(previous["dependencies"]).as_posix()
    atomic(pth, ("\n".join(roots) + "\nimport site; site.addsitedir(" + repr(dependencies) + ")\n").encode())
    atomic(provenance / "delta-receipt.json", encoded(records))
    fresh = {APP, PROCESS, plugin, config}
    fresh.update(path.relative_to(target).as_posix() for path in provenance.rglob("*") if path.is_file())
    for name in fresh:
        expected[name] = sha(child(target, name).read_bytes())
    checked.update(fresh)
    checked.update(previous.get("diagnostic_sources", {}))
    manifest = dict(previous)
    manifest.update(
        candidate_commit=head, candidate_directory=str(target), candidate_sources=expected,
        diagnostic_sources={name: expected[name] for name in sorted(checked) if name in expected},
        environment_pth_sha256=sha(pth.read_bytes()), native_workload_executed=False,
        import_probes=[], only_test_delta=None,
        lab_observer={"mode": mode, "route": "process", "qa_sources_unchanged": True,
                      "count_timings_qualification": False},
        incremental_replay={"seed_directory": str(seed), "seed_manifest_sha256": sha(raw_manifest),
                            "from_commit": old, "to_commit": head, "delta_sha256": sha(patch),
                            "changed_paths": changed, "source_links": linked,
                            "verification": "diagnostic pins; unchanged seed entries trusted",
                            "elapsed_seconds": round(time.monotonic() - started, 3)},
        tool_sha256={name: sha((HERE / name).read_bytes()) for name in TOOLS},
    )
    atomic(target / "replay-manifest.json", encoded(manifest))
    verify(target)
    print(json.dumps({"candidate_directory": str(target), "candidate_commit": head,
                      "manifest_sha256": sha((target / "replay-manifest.json").read_bytes()),
                      "elapsed_seconds": round(time.monotonic() - started, 3),
                      "native_workload_executed": False}, indent=2), flush=True)
    return target


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    commands = parser.add_subparsers(dest="command", required=True)
    builder = commands.add_parser("build")
    builder.add_argument("--candidate", required=True)
    builder.add_argument("--label", required=True)
    builder.add_argument("--seed", type=Path, default=SEED)
    builder.add_argument("--mode", choices=("guard", "counts"), default="guard")
    checker = commands.add_parser("verify")
    checker.add_argument("--candidate-directory", type=Path, required=True)
    checker.add_argument("--exhaustive", action="store_true")
    args = parser.parse_args()
    if args.command == "build":
        build(args.candidate, args.label, args.seed, args.mode)
    else:
        result = verify(args.candidate_directory, args.exhaustive)
        print(json.dumps({"candidate": result["candidate_commit"],
                          "verification": "exhaustive" if args.exhaustive else "diagnostic",
                          "checked_sources": len(result["candidate_sources"] if args.exhaustive
                                                 else result["diagnostic_sources"])}))
