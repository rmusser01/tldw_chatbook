"""Verify replay source pins and report the original journey's observed timings."""

from __future__ import annotations

import argparse
import hashlib
import importlib.util
import json
from pathlib import Path


def sha(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def verify(candidate: Path) -> dict:
    # Isolated Python excludes the script directory: import our pinned helper explicitly.
    import sys
    sys.path.insert(0, str(Path(__file__).resolve().parent))
    from replay import verify as verify_sources
    return verify_sources(candidate, EXHAUSTIVE)

EXHAUSTIVE = False


def inspect(candidate: Path, run: Path | None) -> dict:
    manifest = verify(candidate)
    result = {"source_verified": True, "candidate_commit": manifest["candidate_commit"],
              "original_journey_sha256": manifest["original_journey_sha256"],
              "candidate_journey_sha256": manifest["candidate_journey_sha256"]}
    if run is None:
        return result
    artifacts = list(run.glob("native-*"))
    if len(artifacts) != 1:
        raise RuntimeError("Expected one original native journey artifact directory")
    receipt = json.loads((artifacts[0] / "receipt.json").read_text(encoding="utf-8-sig"))
    rows = [json.loads(line) for line in (run / "progress.jsonl").read_text(encoding="utf-8-sig").splitlines()]
    costs = json.loads((artifacts[0] / "costs.json").read_text(encoding="utf-8-sig"))
    original_summary = Path(manifest["original_directory"]).parent / "summarize.py"
    if sha(original_summary) != manifest["original_summary_sha256"]:
        raise RuntimeError("Original timing summary changed")
    spec = importlib.util.spec_from_file_location("original_journey_summary", original_summary)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    result.update(status=receipt["status"], original_duration_seconds=receipt.get("duration_seconds"), turns={})
    for turn in ("readme", "edit"):
        events = [row for row in rows if row["turn"] == turn]
        summary = module.summarize(rows, turn)
        if summary is None:
            result["turns"][turn] = {"status": "not-started"}
            continue
        points = {}
        for row in events:
            points.setdefault(row["event"], row["t"])
        waits, previous = [], -1.0
        for click in (row for row in events if row["event"] == "approval_click"):
            attempts = [row for row in events if previous < row["t"] <= click["t"]
                        and row["event"] in ("painted_approval", "approval_observed")]
            painted = [row for row in attempts if row["event"] == "painted_approval"]
            if not attempts:
                raise RuntimeError("Approval click lacks its original observed/painted boundary")
            waits.append(click["t"] - min(painted or attempts, key=lambda row: row["t"])["t"])
            previous = click["t"]
        adjustment = summary.get("disclosure_wait_s", 0) + sum(waits)
        observed = points.get("reply_seen")
        observed_s = None if observed is None else observed - points["send"]
        summary.update(
            original_completion_endpoint="reply_completed" if "reply_completed" in points else "reply_seen",
            original_adjusted_s=None if "completed_s" not in summary else round(summary["completed_s"] - adjustment, 4),
            common_reply_seen_s=None if observed_s is None else round(observed_s, 4),
            common_adjusted_reply_seen_s=None if observed_s is None else round(observed_s - adjustment, 4),
            approval_wait_s=round(sum(waits), 4),
            parent_work_counts={name: sum(row["count"] for row in costs if row["turn"] == turn and row["function"] == name)
                                for name in ("_acquire_storage", "_scope", "_reuse_evidence_hit")},
            backend_work_counts=None,
            backend_execution_phase_timings=None,
        )
        result["turns"][turn] = summary
    result["coverage"] = (
        "Original trace observes this pytest process and its loopback server. "
        "Backend process storage counts and execution-phase hooks are not installed; "
        "parent AgentStep copies are not backend execution timestamps. Null means unobserved."
    )
    return result


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--candidate-directory", required=True, type=Path)
    parser.add_argument("--run-directory", type=Path)
    parser.add_argument("--exhaustive", action="store_true")
    args = parser.parse_args()
    EXHAUSTIVE = args.exhaustive
    print(json.dumps(inspect(args.candidate_directory, args.run_directory), indent=2))
