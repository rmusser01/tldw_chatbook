param(
    [Parameter(Mandatory=$true)][string]$CandidateDirectory,
    [Parameter(Mandatory=$true)][ValidatePattern('^[A-Za-z0-9_-]+$')][string]$RunLabel,
    [string]$PrivateParent = 'C:/Users/GDesktop-1/.chatbook-uat-6bd97b1-1111',
    [switch]$VerifyOnly,
    [switch]$Exhaustive
)
$ErrorActionPreference = 'Stop'
$src = (Resolve-Path -LiteralPath $CandidateDirectory).Path
$python = Join-Path $src '.venv/Scripts/python.exe'
$inspector = Join-Path $PSScriptRoot 'inspect_replay.py'
$verificationArgs = @()
if ($Exhaustive) { $verificationArgs += '--exhaustive' }
& $python -I -B $inspector --candidate-directory $src @verificationArgs
if ($LASTEXITCODE -ne 0) { throw 'Replay source verification failed' }
if ($VerifyOnly) { return }
$manifestPath = Join-Path $src 'replay-manifest.json'
$manifest = Get-Content -LiteralPath $manifestPath -Raw | ConvertFrom-Json
$runRoot = Join-Path $PrivateParent ('40608-replay-' + $RunLabel)
$receipts = Join-Path $src ('replay-runs/' + $RunLabel)
if ((Test-Path -LiteralPath $runRoot) -or (Test-Path -LiteralPath $receipts)) {
    throw 'Choose a fresh run label; runs are never overwritten'
}
$savedLocation = Get-Location
$names = @('TLDW_TEST_CONFIG_ROOT','TLDW_UAT_ARTIFACTS','TLDW_TEST_LATENCY_PROGRESS',
           'TMP','TEMP','PYTHONUTF8','PYTHONDONTWRITEBYTECODE','PYTEST_DISABLE_PLUGIN_AUTOLOAD','PYTEST_ADDOPTS','PYTEST_PLUGINS')
$savedEnvironment = @{}
foreach ($name in $names) { $savedEnvironment[$name] = [Environment]::GetEnvironmentVariable($name, 'Process') }
$exitCode = 1
try {
    Set-Location -LiteralPath $src
    # Same native private-directory construction and pytest/private-profile entry as run-subfive.ps1.
    & $python -I -B -c "from pathlib import Path; import sys; from tldw_chatbook.Utils import platform_files; root=Path(sys.argv[1]); platform_files.os.mkdir(root,0o700); [platform_files.os.mkdir(root/name,0o700) for name in ('bootstrap','temp','artifacts')]" $runRoot
    if ($LASTEXITCODE -ne 0) { throw 'Private original-journey profile creation failed' }
    New-Item -ItemType Directory -Path $receipts | Out-Null
    $env:TLDW_TEST_CONFIG_ROOT = Join-Path $runRoot 'bootstrap'
    $env:TLDW_UAT_ARTIFACTS = Join-Path $runRoot 'artifacts'
    $env:TLDW_TEST_LATENCY_PROGRESS = Join-Path $receipts 'progress.jsonl'
    $env:TMP = Join-Path $runRoot 'temp'
    $env:TEMP = $env:TMP
    $env:PYTHONUTF8 = '1'
    $env:PYTHONDONTWRITEBYTECODE = '1'
    $env:PYTEST_DISABLE_PLUGIN_AUTOLOAD = '1'
    $env:PYTEST_ADDOPTS = ''
    $env:PYTEST_PLUGINS = 'task40608_lab_observer'
    $metadata = [ordered]@{
        candidate = $manifest.candidate_commit
        verification = $(if ($Exhaustive) { 'exhaustive' } else { 'diagnostic-pins' })
        observer = $manifest.lab_observer.mode
        manifestSha256 = (Get-FileHash -LiteralPath $manifestPath).Hash
        originalJourneySha256 = $manifest.original_journey_sha256
        candidateJourneySha256 = $manifest.candidate_journey_sha256
        privateRoot = $runRoot
        startedUtc = [DateTimeOffset]::UtcNow.ToString('o')
    }
    $metadata | ConvertTo-Json | Set-Content -LiteralPath (Join-Path $receipts 'run-metadata.json') -Encoding utf8
    & $python -I -B -m pytest -p no:cacheprovider -p pytest_asyncio.plugin -p pytest_timeout --basetemp (Join-Path $env:TMP 'pytest') -q 'Tests/QA/test_task40608.py::test_project_chat_uat[native]' *> (Join-Path $runRoot 'pytest.log')
    $exitCode = $LASTEXITCODE
    $metadata['finishedUtc'] = [DateTimeOffset]::UtcNow.ToString('o')
    $metadata['exitCode'] = $exitCode
    $metadata | ConvertTo-Json | Set-Content -LiteralPath (Join-Path $receipts 'run-metadata.json') -Encoding utf8
    Copy-Item -LiteralPath (Join-Path $runRoot 'pytest.log') -Destination $receipts
    Get-ChildItem -LiteralPath $env:TLDW_UAT_ARTIFACTS | ForEach-Object {
        Copy-Item -LiteralPath $_.FullName -Destination $receipts -Recurse
    }
    & $python -I -B $inspector --candidate-directory $src --run-directory $receipts @verificationArgs *> (Join-Path $receipts 'timings.json')
    if ($LASTEXITCODE -ne 0 -and $exitCode -eq 0) { $exitCode = $LASTEXITCODE }
    Get-Content -LiteralPath (Join-Path $runRoot 'pytest.log') -Tail 35
} finally {
    Set-Location -LiteralPath $savedLocation
    foreach ($name in $names) { [Environment]::SetEnvironmentVariable($name, $savedEnvironment[$name], 'Process') }
}
exit $exitCode
