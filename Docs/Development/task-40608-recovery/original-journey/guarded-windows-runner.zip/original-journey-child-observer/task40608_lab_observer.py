"""Lab-only original UAT socket guard and optional passive admission counts.

Loaded as an explicit pytest plugin, and explicitly by the lab -I -S backend
bootstrap. No product callable is replaced; the socket patches are the original
Tests.uat_project_chat_support.only_owned_server context manager.
"""

from __future__ import annotations

import hashlib
import json
import os
from pathlib import Path
import runpy
import secrets
import sys
import threading
import time


_ROOT = Path(__file__).resolve().parent
_state = None
_STORAGE = {"_acquire_storage", "_scope", "_reuse_evidence"}


def _hash(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def _settings():
    settings = json.loads((_ROOT / "task40608-lab-observer.json").read_text(encoding="utf-8"))
    if settings["mode"] not in {"guard", "counts"} or settings["route"] not in {"local", "process"}:
        raise RuntimeError("Unknown fixed lab observation mode")
    for name, expected in settings["sources"].items():
        path = _ROOT / name
        if not path.resolve().is_relative_to(_ROOT) or _hash(path) != expected:
            raise RuntimeError("Lab observer source changed: " + name)
    return settings


def _original_guard(settings):
    from Tests.uat_project_chat_support import only_owned_server

    source = Path(only_owned_server.__wrapped__.__code__.co_filename).resolve()
    expected = _ROOT / "Tests/uat_project_chat_support.py"
    if source != expected.resolve() or _hash(source) != settings["sources"]["Tests/uat_project_chat_support.py"]:
        raise RuntimeError("Original network guard source changed")
    return only_owned_server


class _Observation:
    def __init__(self, settings, role):
        self.settings = settings
        self.role = role
        self.pid = os.getpid()
        self.started_ns = time.perf_counter_ns()
        self.events = []
        self.calls = []
        self.starts = {}
        self.codes = {}
        self.backend_pids = set()
        self.guard_started = False
        self.guard_finished = False
        self.attempts = []
        self.port = None
        self.run_id = None
        self.directory = None
        self.slot = None
        self.discovering = False
        self.global_events = 0
        self.guard_code = self.trace_mark_code = self.trace_watch_code = self.trace_install_code = None

    def install(self):
        monitoring = sys.monitoring
        self.slot = next(value for value in range(6) if monitoring.get_tool(value) is None)
        monitoring.use_tool_id(self.slot, "task40608-lab-" + self.role)
        monitoring.register_callback(self.slot, monitoring.events.PY_START, self._start)
        monitoring.register_callback(self.slot, monitoring.events.PY_RETURN, self._returned)
        monitoring.register_callback(self.slot, monitoring.events.PY_UNWIND, self._unwind)
        monitoring.register_callback(self.slot, monitoring.events.PY_YIELD, self._yielded)

    def local(self, code, events):
        # CPython 3.12 exposes PY_UNWIND only as a global event. Its callback
        # filters against starts belonging to the three exact watched codes.
        unwind = sys.monitoring.events.PY_UNWIND
        if events & unwind:
            events &= ~unwind
            self.global_events |= unwind
            discovery = sys.monitoring.events.PY_START if self.discovering else 0
            sys.monitoring.set_events(self.slot, self.global_events | discovery)
        self.codes.setdefault(code, None)
        sys.monitoring.set_local_events(self.slot, code, events)

    def ui_hooks(self, guard):
        from Tests.QA.task40608_trace import Trace

        self.guard_code = guard.__wrapped__.__code__
        self.trace_mark_code = Trace.mark.__code__
        self.trace_watch_code = Trace.watch.__code__
        self.trace_install_code = Trace.install.__code__
        events = sys.monitoring.events
        self.local(self.guard_code, events.PY_START | events.PY_YIELD | events.PY_RETURN)
        self.local(self.trace_mark_code, events.PY_RETURN)
        self.local(self.trace_watch_code, events.PY_RETURN)
        if self.settings["mode"] == "counts":
            self.local(self.trace_install_code, events.PY_RETURN)

    def storage_hooks(self):
        # UI calls this only after the ORIGINAL Trace.install imported its
        # targets. The backend discovers actual entries without early imports.
        module = sys.modules.get("tldw_chatbook.Backup_Recovery.storage_admission")
        if module is None:
            self.discovering = True
            sys.monitoring.set_events(self.slot, self.global_events | sys.monitoring.events.PY_START)
            return
        events = sys.monitoring.events
        for name in sorted(_STORAGE):
            code = getattr(module, name).__code__
            self.codes[code] = name
            self.local(code, events.PY_START | events.PY_RETURN | events.PY_UNWIND)

    def _start(self, code, _offset):
        frame = sys._getframe(1)
        if code is self.guard_code:
            if self.guard_started:
                raise RuntimeError("Original lab guard entered twice")
            port = frame.f_locals["port"]
            if type(port) is not int or not 0 < port < 65536:
                raise RuntimeError("Original server port is invalid")
            self.port, self.run_id = port, secrets.token_hex(16)
            self.directory = Path(os.environ["TLDW_UAT_ARTIFACTS"]) / "lab-observer"
            self.directory.mkdir(mode=0o700)
            self.guard_started = True
            os.environ["TLDW_TEST_LAB_PORT"] = str(port)
            os.environ["TLDW_TEST_LAB_RUN_ID"] = self.run_id
            os.environ["TLDW_TEST_LAB_OUTPUT"] = str(self.directory)
            return
        if self.discovering and code.co_name in _STORAGE and code.co_filename.replace("\\", "/").endswith(
            "/tldw_chatbook/Backup_Recovery/storage_admission.py"
        ):
            self.storage_hooks()
            if all(name in self.codes.values() for name in _STORAGE):
                self.discovering = False
                sys.monitoring.set_events(self.slot, self.global_events)
        name = self.codes.get(code)
        if name in _STORAGE:
            self.starts[(threading.get_ident(), id(frame))] = (time.perf_counter_ns(), name)

    def _yielded(self, code, _offset, _value):
        if code is self.guard_code:
            self.attempts = sys._getframe(1).f_locals["attempts"]

    def _returned(self, code, _offset, value):
        frame = sys._getframe(1)
        if code is self.guard_code:
            self.guard_finished = True
        elif code is self.trace_mark_code:
            trace = frame.f_locals["self"]
            row = dict(frame.f_locals["row"])
            self.events.append({"clock_ns": round(frame.f_locals["stamp"] * 1e9), "trace_start": trace.start, **row})
        elif code is self.trace_watch_code:
            console = frame.f_locals["console"]
            client = getattr(console.app_instance, "console_execution_client", None)
            if client is not None:
                process = client._process
                if process is None or process.poll() is not None:
                    raise RuntimeError("Original journey has no live backend process")
                self.backend_pids.add(process.pid)
        elif code is self.trace_install_code:
            self.storage_hooks()
        self._finish_call(frame, "return", value is not None)

    def _unwind(self, code, _offset, _error):
        self._finish_call(sys._getframe(1), "unwind", False)

    def _finish_call(self, frame, outcome, nonempty):
        key = (threading.get_ident(), id(frame))
        started = self.starts.pop(key, None)
        if started is not None:
            stamp, name = started
            self.calls.append({"start_ns": stamp, "end_ns": time.perf_counter_ns(),
                               "function": name, "thread": key[0], "outcome": outcome,
                               "reuse_hit": name == "_reuse_evidence" and outcome == "return" and nonempty})

    def finish(self, *, exit_code=None):
        if self.slot is not None:
            monitoring = sys.monitoring
            monitoring.set_events(self.slot, 0)
            for code in self.codes:
                monitoring.set_local_events(self.slot, code, 0)
            for event in (monitoring.events.PY_START, monitoring.events.PY_RETURN,
                          monitoring.events.PY_UNWIND, monitoring.events.PY_YIELD):
                monitoring.register_callback(self.slot, event, None)
            monitoring.free_tool_id(self.slot)
            self.slot = None
        result = {
            "role": self.role, "pid": self.pid, "run_id": self.run_id, "mode": self.settings["mode"],
            "port": self.port, "guard_started": self.guard_started, "guard_finished": self.guard_finished,
            "blocked_destinations": list(self.attempts), "backend_pids": sorted(self.backend_pids),
            "started_ns": self.started_ns, "finished_ns": time.perf_counter_ns(), "exit_code": exit_code,
            "events": self.events, "calls": self.calls, "unfinished_calls": len(self.starts),
            "discovery_still_active": self.discovering,
            "storage_functions_observed": sorted(name for name in self.codes.values() if name is not None),
        }
        if self.directory is not None:
            (self.directory / f"{self.role}-{self.pid}.json").write_text(
                json.dumps(result, indent=2) + "\n", encoding="utf-8",
            )
        return result


def validate_receipts(ui, children, expected_backend):
    """Require actual matching completed guards, never infer absence as success."""
    if not ui["guard_started"] or not ui["guard_finished"] or ui["blocked_destinations"]:
        raise RuntimeError("Original UI network guard is incomplete or refused a destination")
    expected = set(ui["backend_pids"])
    if bool(expected) is not expected_backend:
        raise RuntimeError("Original journey did not observe the selected backend process")
    if {item["pid"] for item in children} != expected or len(children) != len(expected):
        raise RuntimeError("Actual backend network guard receipt is missing or duplicated")
    for item in children:
        if (item["role"] != "backend" or item["run_id"] != ui["run_id"] or item["port"] != ui["port"]
            or not item["guard_started"] or not item["guard_finished"] or item["blocked_destinations"]
            or item["exit_code"] != 0 or item["mode"] != ui["mode"]):
            raise RuntimeError("Actual backend network guard did not complete cleanly")


def pytest_configure(config):
    global _state
    if not os.environ.get("TLDW_TEST_PRIVATE_PROFILE_NODE"):
        return
    settings = _settings()
    _state = _Observation(settings, "ui")
    _state.install()
    _state.ui_hooks(_original_guard(settings))


def pytest_sessionfinish(session, exitstatus):
    if _state is None:
        return
    ui = _state.finish(exit_code=int(exitstatus))
    try:
        children = [] if _state.directory is None else [
            json.loads(path.read_text(encoding="utf-8")) for path in _state.directory.glob("backend-*.json")
        ]
        validate_receipts(ui, children, _state.settings["route"] == "process")
    except Exception as error:
        session.exitstatus = 1
        reporter = session.config.pluginmanager.get_plugin("terminalreporter")
        if reporter is not None:
            reporter.write_line("TASK40608 lab guard failed: " + str(error), red=True)


def run_backend():
    """Execute the original module under its original fixed-server guard."""
    settings = _settings()
    if settings["route"] != "process":
        raise RuntimeError("Backend launched in a local-only lab run")
    observation = _Observation(settings, "backend")
    observation.port = int(os.environ["TLDW_TEST_LAB_PORT"])
    observation.run_id = os.environ["TLDW_TEST_LAB_RUN_ID"]
    observation.directory = Path(os.environ["TLDW_TEST_LAB_OUTPUT"])
    if not observation.directory.is_dir() or not observation.run_id or not 0 < observation.port < 65536:
        raise RuntimeError("Backend has no original UI guard selection")
    exit_code = 1
    worker_exit = None
    try:
        with _original_guard(settings)(observation.port) as blocked:
            observation.attempts = blocked
            observation.guard_started = True
            if settings["mode"] == "counts":
                observation.install()
                observation.storage_hooks()
            try:
                runpy.run_module("tldw_chatbook.Chat.console_execution_worker", run_name="__main__")
            except SystemExit as outcome:
                exit_code = 0 if outcome.code is None else outcome.code
                worker_exit = outcome
            else:
                exit_code = 0
        observation.guard_finished = True
        if worker_exit is not None:
            raise worker_exit
    finally:
        # A positive guard flag is set only after the original context exits.
        # This separate lab result says nothing about native DB retirement.
        observation.finish(exit_code=exit_code)
