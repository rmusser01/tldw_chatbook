"""Copy the untouched original overlay into a fresh symmetric lab baseline."""
import argparse
import hashlib
import json
from pathlib import Path
import re
import subprocess
import venv

from install_observer import LAB, install


def sha(data):
    return hashlib.sha256(data).hexdigest()


def prepare(candidate, label, mode):
    if not re.fullmatch(r"[A-Za-z0-9_-]+", label):
        raise ValueError("Use a new plain label")
    reference = json.loads((candidate / "replay-manifest.json").read_text(encoding="utf-8"))
    original = Path(reference["original_directory"])
    target = LAB / "test-snapshots" / ("original-journey-" + label)
    target.mkdir()
    copied = {}
    for name, expected in reference["original_sources"].items():
        data = (original / name).read_bytes()
        if sha(data) != expected:
            raise RuntimeError("Original overlay changed: " + name)
        output = target / name
        output.parent.mkdir(parents=True, exist_ok=True)
        output.write_bytes(data)
        copied[name] = expected
    dependency = candidate / "packages/tldw_profile_core/src"
    if not (dependency / "tldw_profile_core/__init__.py").is_file():
        raise RuntimeError("Candidate must first pin the unchanged profile_core dependency")
    for path in dependency.rglob("*"):
        if path.is_file() and "__pycache__" not in path.parts:
            name = path.relative_to(candidate).as_posix()
            data = path.read_bytes()
            expected = reference["candidate_sources"].get(name)
            if expected is None or sha(data) != expected:
                raise RuntimeError("Candidate dependency is not pinned in its source manifest: " + name)
            output = target / name
            output.parent.mkdir(parents=True, exist_ok=True)
            output.write_bytes(data)
            copied[name] = expected
    (target / "replay-provenance").mkdir()
    environment = target / ".venv"
    venv.EnvBuilder(with_pip=False).create(environment)
    pth = environment / "Lib/site-packages/original-journey-source.pth"
    pth.write_text(target.as_posix() + "\n" + (target / "packages/tldw_profile_core/src").as_posix()
                   + "\nimport site; site.addsitedir(" + repr(reference["dependencies"]) + ")\n", encoding="utf-8")
    probe = (
        "import importlib.util,json,sys;from pathlib import Path;root=Path(sys.argv[1]).resolve();"
        "found={n:str(Path(importlib.util.find_spec(n).origin).resolve()) "
        "for n in ('tldw_chatbook','Tests','tldw_profile_core')};"
        "assert all(Path(p).is_relative_to(root) for p in found.values()),found;print(json.dumps(found))"
    )
    result = subprocess.run([str(environment / "Scripts/python.exe"), "-I", "-B", "-c", probe, str(target)],
                            cwd=target, check=True, capture_output=True, text=True)
    journey = "Tests/QA/test_task40608.py"
    tools = LAB / "test-snapshots/qa-intact-screen-tools"
    manifest = {
        "base_commit": reference["base_commit"], "candidate_commit": reference["base_commit"],
        "source_label": "original before overlay, including original #3496 changes",
        "original_directory": str(original), "candidate_directory": str(target),
        "original_journey_sha256": copied[journey], "candidate_journey_sha256": copied[journey],
        "original_sources": reference["original_sources"], "candidate_sources": copied,
        "original_summary_sha256": reference["original_summary_sha256"],
        "dependencies": reference["dependencies"], "environment_pth_sha256": sha(pth.read_bytes()),
        "import_probes": [json.loads(result.stdout)], "only_test_delta": None, "lab_app_selection": None,
        "native_workload_executed": False,
        "tool_sha256": {name: sha((tools / name).read_bytes()) for name in
                        ("build_replay.py", "run_replay.ps1", "inspect_replay.py")},
        "profile_core_reference_manifest_sha256": sha((candidate / "replay-manifest.json").read_bytes()),
    }
    (target / "replay-manifest.json").write_text(json.dumps(manifest, indent=2) + "\n", encoding="utf-8")
    install(target, mode, "local")
    print(target)


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--candidate", required=True, type=Path)
    parser.add_argument("--label", required=True)
    parser.add_argument("--mode", choices=("guard", "counts"), default="guard")
    args = parser.parse_args()
    prepare(args.candidate.resolve(strict=True), args.label, args.mode)
