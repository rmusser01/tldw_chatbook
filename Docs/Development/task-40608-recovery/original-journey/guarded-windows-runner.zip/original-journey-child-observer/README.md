# Actual child guard and optional diagnostic counts

This is lab-only verification code for ADR-126/230. Nothing is installed into the live worktree or an already-run replay. Both original QA files, the model scripts, fixtures and original assertions remain byte-identical. The baseline remains original local execution; the candidate's lab App default selects real process execution while the PR default remains local.

`guard` is the acceptance mode. `counts` is a separate diagnostic mode; do not use its latency as the sub-five-second qualification until observation overhead has been independently justified. Both modes leave all product admission functions, source checks, DB operations and canonical worker entry unchanged.

## Mechanism and boundaries

- `PYTEST_PLUGINS=task40608_lab_observer` loads the plugin in the parent and original private-profile child. The original environment fixture preserves `PYTEST_*`; the original `private_profile.py` also preserves it. The plugin acts only in the actual private-profile child.
- Passive `sys.monitoring` observes entry/yield/return of the original `only_owned_server.__wrapped__`. It captures the **actual ephemeral port passed by the existing QA context**, and transfers that port plus a fresh per-run identity/output directory through `TLDW_TEST_LAB_*`. No port is inferred from settings or hard-coded.
- The candidate's existing backend launcher uses the base interpreter with `-I -S`, so `.pth`, `sitecustomize`, and pytest plugins cannot install the child guard implicitly. The one documented lab bootstrap delta calls `task40608_lab_observer.run_backend()` instead of directly calling `runpy.run_module(...)`. That wrapper enters the **original copied** `Tests.uat_project_chat_support.only_owned_server(port)` and calls the exact same canonical worker module. Its original allow-only-model policy and socketpair IPC exemption are preserved. No new network policy implementation exists.
- The original `Trace.watch` supplies the actual current client's `Popen.pid`; the plugin later requires a matching completed child guard receipt, run identity, port and normal worker exit. Missing, duplicate, foreign, unfinished or refused receipts fail pytest at session finish. A positive guard flag is set only after the original context exits normally. This does **not** claim native DB retirement; product retirement checks remain separate and unchanged.
- Guard-only mode adds no admission hooks. It keeps original Trace marks and PID/guard witnesses. All original QA outcomes and exit codes must still pass; a passing network receipt alone is not qualification.
- Counts mode adds the same passive monitor in the actual UI process and execution backend for `_acquire_storage`, `_scope`, `_reuse_evidence`. It observes actual code entries/returns/unwinds and non-None reuse results. The UI installs after the original Trace installed its own targets; the backend discovers the actual first storage entry without importing storage early. Global discovery stops immediately once that resident module exposes the three exact code objects. CPython 3.12 PY_UNWIND is a global event; its callback filters against starts from these exact targets. No product function is wrapped/replaced and no result is fabricated.
- Counts are buffered in memory and written at finalization. The report keeps PID, thread, real monotonic entry/exit, normal returns, unwinds, reuse hits and unfinished calls. It aligns the two interpreters to the original Trace's actual `send`/`reply_seen` timestamps and reports calls crossing either boundary separately. Summed call durations are never presented as wall time, and pre-send setup is not silently counted as journey work. Separate `fs_*` worker processes are outside this Console admission count scope, just as they were outside the old UI Trace's counters.

## Install on a fresh QA-intact candidate

Do not apply to the current screening run or mutate a pinned executed replay. Build a fresh coherent committed candidate with the QA-intact builder first, including `packages/tldw_profile_core/src` in its source manifest and parent `.pth` as well as the backend's explicit roots.

```powershell
$lab = 'C:/Users/GDesktop-1/.codex/visualizations/2026/11/12/01a1d221-2d16-7b61-ad34-242e2e3f86cf/task-40608/verification'
$observer = Join-Path $lab 'test-snapshots/original-journey-child-observer'
$runner = Join-Path $lab 'test-snapshots/qa-intact-screen-tools/run_replay.ps1'
$python = Join-Path $lab 'worktree-env/Scripts/python.exe'
$freshCandidate = Join-Path $lab 'test-snapshots/original-journey-NEW-UNUSED-LABEL'
& $python -B "$observer/install_observer.py" $freshCandidate --route process --mode guard
```

The installer refuses used replays, checks all existing pinned sources, verifies both original QA files and guard bytes, saves the old manifest, records the bootstrap diff, copies the fixed plugin/config, and adds their hashes to the replay manifest. It never edits the live repository, `before/`, `subfive/`, original standard runners, or QA source.

Use the same plugin for an independent unchanged baseline. `prepare_baseline.py` copies the original overlay, and copies only the candidate's manifest-pinned unchanged profile-core dependency. It does not apply the candidate product patch. It creates its own import environment and verifies all three package origins, then installs local guard mode:

```powershell
& $python -B "$observer/prepare_baseline.py" --candidate $freshCandidate --label NEW-BASELINE-LABEL --mode guard
$freshBaseline = Join-Path $lab 'test-snapshots/original-journey-NEW-BASELINE-LABEL'
```

Root alone launches the real Windows workloads. Preserve and restore the caller's explicit plugin list:

```powershell
$savedPlugins = $env:PYTEST_PLUGINS
try {
    $env:PYTEST_PLUGINS = 'task40608_lab_observer'
    & $runner -CandidateDirectory $freshBaseline -RunLabel guarded-pair-1-baseline
    if ($LASTEXITCODE -ne 0) { throw 'Original guarded baseline failed' }
    & $runner -CandidateDirectory $freshCandidate -RunLabel guarded-pair-1-candidate
    if ($LASTEXITCODE -ne 0) { throw 'Original guarded candidate failed' }
} finally { $env:PYTEST_PLUGINS = $savedPlugins }
```

The original runner copies `lab-observer/` alongside the original `native-*/` artifacts. Verify the receipts separately:

```powershell
& $python -B "$observer/summarize_observer.py" "$freshCandidate/replay-runs/guarded-pair-1-candidate/lab-observer" --route process
```

For diagnostics, build **new** baseline/candidate directories with `--mode counts`, run the same original journey sequentially, then use the same summarizer. Original `costs.json` remains untouched and describes the UI process only. The supplemental report describes the actual UI + execution backend and names its narrower time window.

## Validation and remaining native gate

`check_observer.py` passes: actual monitoring callback entry/normal-return/unwind/hit mechanics; eight missing/foreign/refused guard receipt cases; and both original `connect`/`connect_ex` guards refusing a foreign destination before native socket entry and restoring their original descriptors. It constructs no socket and imports no product. Configured Ruff passes all artifact Python files.

Native integration is **unrun** here: root must verify the original backend can reach the owned loopback server, the Windows event-loop socketpair exemption works, actual backend guard receipts match the observed PID, and the original QA still passes. Failure stays a failed run, never a reason to relax the guard. No phase-count result or performance improvement is claimed by these mechanics checks.
