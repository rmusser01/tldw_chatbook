"""Add the fixed observer to an unused lab replay, never a live product tree."""

import argparse
import ast
import difflib
import hashlib
import json
from pathlib import Path
import shutil


HERE = Path(__file__).resolve().parent
LAB = HERE.parents[1]
BOOTSTRAP = "tldw_chatbook/Chat/console_execution_process.py"
PLUGIN = "task40608_lab_observer.py"
CONFIG = "task40608-lab-observer.json"


def sha(data):
    return hashlib.sha256(data).hexdigest()


def install(directory, mode, route):
    directory = directory.resolve(strict=True)
    if directory.parent != LAB / "test-snapshots" or not directory.name.startswith("original-journey-"):
        raise RuntimeError("Use a fresh original-journey-* scratch replay under test-snapshots")
    if (directory / "replay-runs").exists() or (directory / CONFIG).exists():
        raise RuntimeError("This replay has run or already has an observer; use a fresh replay")
    manifest_path = directory / "replay-manifest.json"
    original_manifest = manifest_path.read_bytes()
    manifest = json.loads(original_manifest)
    if Path(manifest["candidate_directory"]).resolve() != directory:
        raise RuntimeError("Replay must own its actual import environment")
    for name in ("Tests/QA/test_task40608.py", "Tests/QA/task40608_trace.py", "Tests/uat_project_chat_support.py"):
        data = (directory / name).read_bytes()
        if data != (LAB / "before" / name).read_bytes() or sha(data) != manifest["candidate_sources"][name]:
            raise RuntimeError("Original QA/guard is not byte-identical: " + name)
    for name, expected in manifest["candidate_sources"].items():
        if sha((directory / name).read_bytes()) != expected:
            raise RuntimeError("Replay source changed before observer installation: " + name)
    app = (directory / "tldw_chatbook/app.py").read_text(encoding="utf-8")
    selected = 'console_execution: str = "process"' in app
    if selected != (route == "process"):
        raise RuntimeError("Observer route differs from the explicit lab App selection")
    provenance = directory / "replay-provenance"
    saved = provenance / "pre-observer-manifest.json"
    saved.write_bytes(original_manifest)
    changed = {saved.relative_to(directory).as_posix(): sha(original_manifest)}
    if route == "process":
        path = directory / BOOTSTRAP
        previous = path.read_bytes()
        old = b";runpy.run_module('tldw_chatbook.Chat.console_execution_worker',run_name='__main__')"
        new = b";import task40608_lab_observer;task40608_lab_observer.run_backend()"
        if previous.count(old) != 1:
            raise RuntimeError("Original fixed -I -S bootstrap changed")
        updated = previous.replace(old, new)
        ast.parse(updated.decode("utf-8"))
        path.write_bytes(updated)
        delta = "".join(difflib.unified_diff(previous.decode().splitlines(keepends=True),
                                           updated.decode().splitlines(keepends=True),
                                           fromfile="original/" + BOOTSTRAP, tofile="lab/" + BOOTSTRAP))
        patch = provenance / "backend-observer-bootstrap.diff"
        patch.write_text(delta, encoding="utf-8", newline="")
        changed.update({BOOTSTRAP: sha(updated), patch.relative_to(directory).as_posix(): sha(patch.read_bytes())})
    shutil.copyfile(HERE / PLUGIN, directory / PLUGIN)
    sources = {
        name: sha((directory / name).read_bytes()) for name in (
            PLUGIN, "Tests/uat_project_chat_support.py", "Tests/QA/task40608_trace.py",
            "Tests/QA/test_task40608.py",
        )
    }
    settings = {"mode": mode, "route": route, "sources": sources}
    config = directory / CONFIG
    config.write_text(json.dumps(settings, indent=2) + "\n", encoding="utf-8")
    changed.update({PLUGIN: sources[PLUGIN], CONFIG: sha(config.read_bytes())})
    manifest["candidate_sources"].update(changed)
    manifest["lab_observer"] = {
        "mode": mode, "route": route, "config_sha256": sha(config.read_bytes()),
        "pre_observer_manifest_sha256": sha(original_manifest),
        "installer_sha256": sha(Path(__file__).read_bytes()), "qa_sources_unchanged": True,
        "count_timings_qualification": False,
    }
    manifest_path.write_text(json.dumps(manifest, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({"replay": str(directory), "mode": mode, "route": route,
                      "manifest_sha256": sha(manifest_path.read_bytes()),
                      "set_environment": {"PYTEST_PLUGINS": "task40608_lab_observer"}}, indent=2))


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("directory", type=Path)
    parser.add_argument("--mode", choices=("guard", "counts"), default="guard")
    parser.add_argument("--route", choices=("local", "process"), required=True)
    args = parser.parse_args()
    install(args.directory, args.mode, args.route)
