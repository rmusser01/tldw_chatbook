"""Report guard receipts and explicitly diagnostic UI/backend work windows."""
import argparse
from collections import Counter
import json
from pathlib import Path

from task40608_lab_observer import validate_receipts


def summarize(directory, route):
    ui_paths = list(directory.glob("ui-*.json"))
    if len(ui_paths) != 1:
        raise RuntimeError("Expected one original private-profile UI process")
    ui = json.loads(ui_paths[0].read_text(encoding="utf-8"))
    children = [json.loads(path.read_text(encoding="utf-8")) for path in directory.glob("backend-*.json")]
    validate_receipts(ui, children, route == "process")
    processes = [ui, *children]
    result = {"network_guards_verified": True, "mode": ui["mode"], "run_id": ui["run_id"],
              "processes": [{"pid": p["pid"], "role": p["role"]} for p in processes],
              "admission_counts_enabled": ui["mode"] == "counts",
              "requires_original_qa_pass": True, "turns": {}}
    if ui["mode"] != "counts":
        result["counts"] = None
        return result
    result["counts_complete"] = all(
        not p["unfinished_calls"] and not p["discovery_still_active"]
        and set(p["storage_functions_observed"]) == {"_acquire_storage", "_scope", "_reuse_evidence"}
        for p in processes
    )
    for turn in ("readme", "edit"):
        events = [row for row in ui["events"] if row["turn"] == turn]
        starts = [row for row in events if row["event"] == "send"]
        ends = [row for row in events if row["event"] == "reply_seen"]
        if len(starts) != 1 or len(ends) != 1:
            raise RuntimeError("Original journey interval is missing or duplicated")
        start, end = starts[0]["clock_ns"], ends[0]["clock_ns"]
        rows = []
        for process in processes:
            calls = [call for call in process["calls"] if start <= call["start_ns"] <= end]
            returned = [call for call in calls if call["outcome"] == "return"]
            rows.append({
                "pid": process["pid"], "role": process["role"],
                "normal_returns": dict(Counter(call["function"] for call in returned)),
                "unwinds": dict(Counter(call["function"] for call in calls if call["outcome"] == "unwind")),
                "reuse_hits": sum(call["reuse_hit"] for call in returned),
                "entered_in_window_finished_after_reply_seen": sum(call["end_ns"] > end for call in calls),
                "entered_before_send_overlapped_window": sum(
                    call["start_ns"] < start <= call["end_ns"] for call in process["calls"]
                ),
            })
        result["turns"][turn] = {"interval": "actual original Send to reply_seen",
                                  "observed_seconds": (end - start) / 1e9, "processes": rows}
    result["note"] = "Diagnostic only: same passive monitor in both designs, distinct process and unwind counts; durations are not summed."
    return result


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("directory", type=Path)
    parser.add_argument("--route", choices=("local", "process"), required=True)
    args = parser.parse_args()
    print(json.dumps(summarize(args.directory, args.route), indent=2))
