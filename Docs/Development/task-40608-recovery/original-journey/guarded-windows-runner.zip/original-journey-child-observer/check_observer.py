"""Pure observer/receipt mechanics; no product, socket, DB, or app execution."""
from copy import deepcopy
import importlib.util
from pathlib import Path
import socket
from types import SimpleNamespace

from task40608_lab_observer import _Observation, validate_receipts


def _acquire_storage():
    return object()


def _scope():
    raise RuntimeError("actual unwind")


def _reuse_evidence(hit):
    return object() if hit else None


def check_counts():
    import sys

    observation = _Observation({"mode": "counts"}, "mechanics-check")
    observation.install()
    try:
        for function in (_acquire_storage, _scope, _reuse_evidence):
            observation.codes[function.__code__] = function.__name__
            observation.local(function.__code__, sys.monitoring.events.PY_START
                              | sys.monitoring.events.PY_RETURN | sys.monitoring.events.PY_UNWIND)
        _acquire_storage()
        _reuse_evidence(False)
        _reuse_evidence(True)
        try:
            _scope()
        except RuntimeError:
            pass
    finally:
        result = observation.finish()
    assert len(result["calls"]) == 4
    assert sum(row["outcome"] == "unwind" for row in result["calls"]) == 1
    assert sum(row["reuse_hit"] for row in result["calls"]) == 1
    assert all(row["end_ns"] >= row["start_ns"] for row in result["calls"])
    assert result["unfinished_calls"] == 0


def check_refusals():
    ui = {"guard_started": True, "guard_finished": True, "blocked_destinations": [],
          "backend_pids": [123], "run_id": "exact", "port": 456, "mode": "guard"}
    backend = {"role": "backend", "pid": 123, "run_id": "exact", "port": 456,
               "guard_started": True, "guard_finished": True, "blocked_destinations": [],
               "exit_code": 0, "mode": "guard"}
    validate_receipts(ui, [backend], True)
    cases = [[], [backend, backend]]
    for name, value in (("pid", 987), ("run_id", "other"), ("port", 999),
                        ("guard_finished", False), ("exit_code", 1),
                        ("blocked_destinations", [["127.0.0.1", 999]])):
        invalid = deepcopy(backend)
        invalid[name] = value
        cases.append([invalid])
    for children in cases:
        try:
            validate_receipts(ui, children, True)
        except RuntimeError:
            pass
        else:
            raise AssertionError("Unknown/refused child guard became success")
    validate_receipts(dict(ui, backend_pids=[]), [], False)


def check_original_guard_before_native_entry():
    path = Path(__file__).resolve().parents[2] / "before/Tests/uat_project_chat_support.py"
    spec = importlib.util.spec_from_file_location("original_uat_guard_check", path)
    source = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(source)
    connect, connect_ex = socket.socket.connect, socket.socket.connect_ex
    # Both original guard functions refuse before reaching the native socket
    # descriptor. No socket is constructed, bound or connected by this check.
    sock = SimpleNamespace(family=socket.AF_INET)
    with source.only_owned_server(12345) as blocked:
        for operation in (socket.socket.connect, socket.socket.connect_ex):
            try:
                operation(sock, ("127.0.0.1", 12346))
            except OSError as error:
                assert "only the owned model server" in str(error)
            else:
                raise AssertionError("Original guard allowed a foreign destination")
        assert blocked == [("127.0.0.1", 12346), ("127.0.0.1", 12346)]
    assert socket.socket.connect is connect and socket.socket.connect_ex is connect_ex


if __name__ == "__main__":
    check_counts()
    check_refusals()
    check_original_guard_before_native_entry()
    print("Callback mechanics, eight receipt refusals and original guard refusal before native entry passed")
