"""Disposable Windows sampler. Live samples contain numeric metadata only."""
import _imp
from collections import defaultdict
import hashlib
import json
import os
from pathlib import Path
import random
import sys
import threading
import time
from types import CodeType
from weakref import WeakKeyDictionary


def index_codes(module):
    result = defaultdict(list)
    todo = [module]
    while todo:
        code = todo.pop()
        result[(code.co_qualname, code.co_firstlineno)].append(code)
        todo.extend(c for c in code.co_consts if type(c) is CodeType)
    return result


class Census:
    def __init__(self, targets, roots):
        self.sources = {}
        for group, relative, digest in targets:
            path = roots[group] / relative
            key = os.path.normcase(str(path))
            self.sources[key] = (group, relative, digest, path)
        self.by_identity = {}
        self.codes = {}
        self.stacks = {}
        self.threads = WeakKeyDictionary()
        self.last_foreign = {}
        self.next_thread = 1
        self.truncated = False

    def code_id(self, code):
        identity = id(code)
        if identity in self.by_identity:
            return self.by_identity[identity][1]
        key = os.path.normcase(code.co_filename)
        if key in self.sources:
            source = self.sources[key]
        else:
            frozen = code.co_filename.removeprefix("<frozen ").removesuffix(">")
            frozen_name = {"importlib._bootstrap": "_frozen_importlib",
                           "importlib._bootstrap_external": "_frozen_importlib_external"}.get(frozen, frozen)
            if (code.co_filename.startswith("<frozen ") and frozen_name in sys.stdlib_module_names
                    and _imp.is_frozen(frozen_name)):
                source = ("frozen", frozen_name, None, None)
            else:
                return 0
        number = len(self.codes) + 1
        self.codes[number] = (code, source)
        self.by_identity[identity] = (code, number)
        return number

    def snapshot(self, frames, threads, sampler_ident, main_ident):
        observations = []
        foreign = {}
        for ident, frame in frames.items():
            if ident == sampler_ident:
                continue
            if ident == main_ident:
                ordinal = 0
            else:
                thread = threads.get(ident)
                ordinal = self.threads.get(thread) if thread is not None else self.last_foreign.get(ident)
                if ordinal is None:
                    ordinal = self.next_thread
                    self.next_thread += 1
                    if thread is not None:
                        self.threads[thread] = ordinal
                if thread is None:
                    foreign[ident] = ordinal
            stack = []
            for _ in range(256):
                if frame is None:
                    break
                code = self.code_id(frame.f_code)
                pair = (code, (frame.f_lineno or 0) if code else 0)
                if code or not stack or stack[-1] != pair:
                    stack.append(pair)
                frame = frame.f_back
            if frame is not None:
                self.truncated = True
            stack = tuple(stack)
            stack_id = self.stacks.setdefault(stack, len(self.stacks) + 1)
            observations.append([ordinal, stack_id])
        self.last_foreign = foreign
        return observations

    def symbols(self):
        grouped = defaultdict(list)
        for number, (code, source) in self.codes.items():
            grouped[source].append((number, code))
        labels = {}
        rejected = 0
        for (group, relative, digest, path), observed in grouped.items():
            if group == "frozen":
                compiled = _imp.get_frozen_object(relative)
            else:
                data = path.read_bytes()
                if hashlib.sha256(data).hexdigest() != digest:
                    raise ValueError("Observed source changed")
                compiled = compile(data, str(path), "exec", dont_inherit=True)
            expected = index_codes(compiled)
            for number, code in observed:
                candidates = expected.get((code.co_qualname, code.co_firstlineno), ())
                if not any(code == original for original in candidates):
                    rejected += 1
                    continue
                labels[number] = [group, relative, code.co_qualname, code.co_firstlineno]
        return labels, rejected


def install(stream):
    package = Path(__file__).resolve().parent
    replay = package.parent
    manifest = json.loads((replay / "replay-manifest.json").read_bytes())
    targets = json.loads((package / "targets.json").read_bytes())
    roots = {"app": replay, "stdlib": Path(sys.base_prefix) / "Lib",
             "dep": Path(manifest["dependencies"])}
    census = Census(targets, roots)
    origin = time.perf_counter()
    stop = threading.Event()
    ticks = 0
    overhead = 0.0
    failed = False
    period = random.Random(40608)
    main_ident = threading.main_thread().ident

    def emit(row):
        stream.write("STACK_SAMPLE " + json.dumps(row, separators=(",", ":")) + "\n")

    def sample():
        nonlocal ticks, overhead, failed
        try:
            while ticks < 12000 and not stop.wait(period.uniform(.035, .065)):
                start = time.perf_counter()
                threads = {thread.ident: thread for thread in threading.enumerate()}
                observed = census.snapshot(sys._current_frames(), threads, threading.get_ident(), main_ident)
                emit(["tick", start - origin, observed])
                ticks += 1
                if ticks % 20 == 0:
                    stream.flush()
                overhead += time.perf_counter() - start
                if len(census.stacks) > 120000 or len(census.by_identity) > 120000:
                    census.truncated = True
                    break
        except Exception:
            failed = True

    emit(["installed", origin])
    stream.flush()
    watcher = threading.Thread(target=sample, daemon=True)
    watcher.start()

    def close():
        stop.set()
        watcher.join()
        # Compile and authenticate only after all measured foreground work has finished.
        labels, rejected = census.symbols()
        for number, label in labels.items():
            emit(["symbol", number, *label])
        for stack, number in census.stacks.items():
            emit(["stack", number, stack])
        emit(["closed", ticks, overhead, rejected, census.truncated, failed, ticks >= 12000])
        stream.flush()

    return close
