# Windows Console stack sampling

This nonqualifying diagnostic samples every Python thread in the UI and contained backend at jittered 35–65 ms intervals. Thread 0 is each process's main thread. The analyzer ranks exact Python source locations and call chains separately for each worker, each inter-request gap, terminal response to reply, and the pilot's approval waits.

The sampler writes timestamps, numeric stack and thread identifiers, and code locations. It never reads locals, arguments, tracebacks, messages or source lines. The symbol table is produced at shutdown after comparing the observed code with the compiled hash-pinned source. All frozen product Python files, the listed dependencies and selected stdlib modules are eligible. Python frames outside these roots are represented by a single fixed label. Running and blocked Python threads are both sampled. Native code may appear as its calling Python line. Suspended coroutines and native stacks are outside the sampling mechanism. A wait frame indicates the call was on a stack. Counts across threads and nested frames do not measure elapsed time.

Use the original CPython 3.12 guarded replay, an unused disposable candidate snapshot, and a dedicated copy of its replay tools. The installer is the same reviewed parent/child bootstrap included with the previous source-cost observer. The clean qualification environments keep their original guards alone.

```powershell
python -I -S -B verify.py
python -I -S -B prepare.py --replay FRESH_REPLAY --installer REVIEWED_INSTALLER --destination FRESH_OVERLAY
python -I -B REPLAY_TOOLS/install_tool_foreground.py --candidate-directory FRESH_REPLAY --replay-tools REPLAY_TOOLS --observer-source FRESH_OVERLAY --check-only
python -I -B REPLAY_TOOLS/install_tool_foreground.py --candidate-directory FRESH_REPLAY --replay-tools REPLAY_TOOLS --observer-source FRESH_OVERLAY
& REPLAY_TOOLS/run_replay.ps1 -CandidateDirectory FRESH_REPLAY -RunLabel g57 -Exhaustive
python -I -S -B analyze.py FRESH_REPLAY/replay-runs/g57 --output NEW_REPORT.json
```

An interrupted run, missing original clocks, refused source match, source drift, truncated stack, dropped thread stream, or failed original socket guard precludes a complete report. Every histogram includes the count of process-wide ticks and the count containing that thread. The actual duration, sample spacing and measured observer work accompany the ranked locations. Symbols and stacks are qualified after the timed pilot, so an interrupted run has no exportable stack identities.
