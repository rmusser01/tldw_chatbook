"""Offline controls. No application imports and no native workload."""
import hashlib
import io
import json
from pathlib import Path
import sys
import tempfile
import threading
import time

sys.path.insert(0, str(Path(__file__).resolve().parent))
import analyze
import observer


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def controls(root):
    package = root / "probe"
    package.mkdir()
    product = root / "tldw_chatbook"
    product.mkdir()
    workload = product / "workload.py"
    workload.write_text("def foreground(wait, secret):\n    return wait.wait(.25)\n")
    source = workload.read_bytes()
    functions = {}
    exec(compile(source, str(workload), "exec"), functions)
    observer.__file__ = str(package / "observer.py")
    thread_path = Path(threading.__file__).resolve()
    targets = [["app", "tldw_chatbook/workload.py", digest(workload)],
               ["stdlib", "threading.py", digest(thread_path)]]
    (package / "targets.json").write_text(json.dumps(targets))
    (root / "replay-manifest.json").write_text(json.dumps({"dependencies": str(root)}))
    output = io.StringIO()
    close = observer.install(output)
    original = functions["foreground"]
    private = "private-argument-must-never-be-exported"
    event = threading.Event()
    child = threading.Thread(target=original, args=(event, private))
    child.start()
    original(event, private)
    child.join()
    close()
    data = output.getvalue()
    assert private not in data and str(root) not in data
    log = root / "stream.jsonl"
    log.write_text(data, encoding="utf-8")
    ticks, cache, overhead = analyze.read_samples(log)
    summary = analyze.histogram(ticks, cache, ticks[0][0], ticks[-1][0] + .1)
    matching = [key for key, row in summary["threads"].items()
                if any("foreground" in label for label, _ in row.get("nearest_product", []))]
    assert "0" in matching and len(matching) >= 2 and overhead >= 0
    assert any("Condition.wait" in label for label, _ in summary["threads"]["0"]["wait_frame_present"])
    observation = observer.Census(targets, {"app": root, "stdlib": thread_path.parent})
    assert observation.code_id(original.__code__) > 0
    exec(compile(source.replace(b".25", b".42"), str(workload), "exec"), functions)
    observation.code_id(functions["foreground"].__code__)
    assert observation.symbols()[1] == 1
    workload.write_bytes(source + b"# drift")
    try:
        observation.symbols()
    except ValueError:
        pass
    else:
        raise AssertionError("Changed file accepted")
    lab = root / "lab-observer"
    lab.mkdir()
    (root / "timings.json").write_text(json.dumps({"source_verified": True, "status": "passed"}))
    events = []
    for turn, start, count in (("readme", 1, 5), ("edit", 20, 6)):
        def mark(name, absolute):
            events.append({"turn": turn, "event": name, "trace_start": 100, "t": absolute})
        mark("send", start)
        for i in range(count):
            mark("http_request_received", start + 1 + 2*i)
            mark("http_response_sent", start + 1.2 + 2*i)
            if i < count - 3:
                mark("approval_observed", start + 1.4 + 2*i)
                mark("approval_click", start + 1.5 + 2*i)
        mark("reply_seen", start + 2*count)
    for role, pid in (("ui", 1), ("backend", 2)):
        guard = {"pid": pid, "exit_code": 0, "guard_finished": True, "blocked_destinations": [],
                 "backend_pids": [2], "events": events if role == "ui" else []}
        (lab / f"{role}-{pid}.json").write_text(json.dumps(guard))
        rows = [["installed", 100], *[["tick", n, [[0, 1]]] for n in range(35)],
                ["symbol", 1, "app", "tldw_chatbook/workload.py", "foreground", 1],
                ["stack", 1, [[1, 2]]], ["closed", 35, .01, 0, False, False, False]]
        (lab / f"tool-foreground-{role}-{pid}.jsonl").write_text(
            "".join("STACK_SAMPLE " + json.dumps(row) + "\n" for row in rows))
    report = analyze.analyze(root)
    assert not report["qualifying"]
    for role in report["roles"].values():
        assert len(role["windows"]) == 20
        assert role["windows"]["edit/after-response-3"]["ticks"] == 1
    log.write_text("\n".join(data.splitlines()[:-1]) + "\n", encoding="utf-8")
    try:
        analyze.read_samples(log)
    except ValueError:
        pass
    else:
        raise AssertionError("Partial stream accepted")


with tempfile.TemporaryDirectory() as tmp:
    controls(Path(tmp).resolve())
print("PASS main and worker, wait frame, pinned names, unknown data omission, code drift, partial refusal")
