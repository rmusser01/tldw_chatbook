"""Materialize a separate diagnostic overlay for the original verified process runner."""
import argparse
import hashlib
import json
from pathlib import Path
import shutil
import sys


DEPENDENCIES = ("textual", "rich", "rich_style", "requests", "urllib3", "httpx", "httpcore",
                "anyio", "loguru", "pydantic", "click", "aiofiles", "regex", "platformdirs")
STDLIB = ("asyncio", "concurrent", "ctypes", "multiprocessing", "sqlite3", "logging",
          "http", "urllib", "collections", "email", "encodings", "json", "importlib", "re",
          "threading.py", "queue.py", "selectors.py", "socket.py", "ssl.py", "subprocess.py",
          "contextlib.py", "pathlib.py", "inspect.py", "ntpath.py", "genericpath.py",
          "dataclasses.py", "functools.py", "copy.py", "weakref.py", "tempfile.py",
          "typing.py", "linecache.py", "shutil.py", "zipfile", "traceback.py", "codecs.py")


def fixed_files(root, names):
    for name in names:
        path = root / name
        children = sorted(path.rglob("*.py")) if path.is_dir() else [path]
        for file in children:
            if file.is_file() and "__pycache__" not in file.parts:
                yield file.relative_to(root).as_posix(), hashlib.sha256(file.read_bytes()).hexdigest()


def prepare(replay, installer, destination):
    manifest = json.loads((replay / "replay-manifest.json").read_bytes())
    if manifest["lab_observer"]["route"] != "process":
        raise ValueError("Expected a disposable process replay")
    sources = manifest["candidate_sources"]
    targets = [["app", name, digest] for name, digest in sorted(sources.items())
               if name.startswith(("tldw_chatbook/", "packages/")) and name.endswith(".py")]
    for group, root, names in (("dep", Path(manifest["dependencies"]), DEPENDENCIES),
                               ("stdlib", Path(sys.base_prefix) / "Lib", STDLIB)):
        targets.extend([group, relative, digest] for relative, digest in fixed_files(root, names))
    if not any(row[:2] == ["dep", "textual/app.py"] for row in targets):
        raise ValueError("Textual dependency source is missing")
    pins = {name: sources["tldw_chatbook/" + name.replace(".", "/") + ".py"]
            for name in ("Agents.agent_runtime", "Chat.console_execution_worker")}
    destination.mkdir(parents=True, exist_ok=False)
    (destination / "parent").mkdir()
    for directory in (destination, destination / "parent"):
        shutil.copyfile(Path(__file__).with_name("observer.py"), directory / "observer.py")
        for name, value in (("source-pins", pins), ("targets", targets)):
            (directory / (name + ".json")).write_text(json.dumps(value, separators=(",", ":")) + "\n")
    for name in ("deferred.py", "install_tool_foreground.py"):
        shutil.copyfile(installer / name, destination / name)
    print(json.dumps({"verified_replay_commit": manifest["candidate_commit"], "files": len(targets),
                      "executed_workload": False}))


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    for name in ("replay", "installer", "destination"):
        parser.add_argument("--" + name, type=Path, required=True)
    args = parser.parse_args()
    prepare(args.replay.resolve(strict=True), args.installer, args.destination)
