"""Rank sampled frames per window, process and thread. Never infer elapsed CPU from ticks."""
import argparse
from collections import Counter, defaultdict
import json
from pathlib import Path
import statistics


def original_windows(events):
    windows = {}
    for name, count in (("readme", 5), ("edit", 6)):
        turn = [r for r in events if r["turn"] == name]

        def points(kind):
            return [row["trace_start"] + row["t"] for row in turn if row["event"] == kind]

        [send], [reply] = points("send"), points("reply_seen")
        requests, responses = points("http_request_received"), points("http_response_sent")
        if len(requests) != count or len(responses) != count:
            raise ValueError("Incomplete original HTTP boundaries")
        windows[name + "/all"] = send, reply
        windows[name + "/before-first-http"] = send, requests[0]
        for i, response in enumerate(responses, 1):
            end = requests[i] if i < count else reply
            if not send <= requests[i - 1] <= response <= end <= reply:
                raise ValueError("Reversed original clock boundary")
            suffix = f"after-response-{i}" if i < count else "final-response-to-reply"
            windows[name + "/" + suffix] = response, end
        observed, clicked = points("approval_observed"), points("approval_click")
        if len(observed) != count - 3 or len(clicked) != count - 3:
            raise ValueError("Incomplete original approval events")
        for i, (begin, end) in enumerate(zip(observed, clicked, strict=True), 1):
            if not send <= begin <= end <= reply:
                raise ValueError("Reversed approval clock boundary")
            windows[f"{name}/approval-wait-{i}"] = begin, end
    return windows


def one(path):
    [found] = list(path)
    return found


def read_samples(file):
    def rows():
        with file.open(encoding="utf-8") as stream:
            for line in stream:
                prefix, sep, row = line.partition(" ")
                if prefix != "STACK_SAMPLE" or not sep:
                    raise ValueError("Unexpected sample format")
                yield json.loads(row)

    it = rows()
    kind, origin = next(it)
    if kind != "installed":
        raise ValueError("Missing install marker")
    ticks, stacks, symbols, closed = [], {}, {0:("outside pinned Python", False)}, None
    for kind, *fields in it:
        if closed is not None:
            raise ValueError("Events after shutdown")
        if kind == "tick":
            stamp, observations = fields
            if ticks and stamp <= ticks[-1][0] - origin:
                raise ValueError("Nonmonotonic sample clock")
            ticks.append((origin + stamp, observations))
        elif kind == "symbol":
            number, group, relative, name, first = fields
            symbols[number] = (f"{group}/{relative} {name}@{first}", group == "app")
        elif kind == "stack":
            number, frames = fields
            stacks[number] = frames
        elif kind == "closed":
            closed = fields
        else:
            raise ValueError("Unknown sampler event")
    if closed is None or closed[0] != len(ticks) or len(closed) != 6 or any(closed[2:]):
        raise ValueError("Incomplete or refused sample stream")
    cache = {}
    for number, stack in stacks.items():
        if not stack:
            raise ValueError("Empty sampled thread stack")
        named = [(symbols[code][0], lineno, symbols[code][1]) for code, lineno in stack]
        top, top_line, _ = named[0]
        app = next(((name, line) for name, line, product in named if product), None)
        waits = tuple(dict.fromkeys(name for name, _, _ in named if any(
            mark in name for mark in ("threading.py Condition.wait@", "threading.py Thread.join@",
                                      "windows_events.py IocpProactor._poll@", "selectors.py SelectSelector.select@",
                                      "queues.py Queue.get@", "queue.py Queue.get@", "socket.py SocketIO.readinto@",
                                      "base_subprocess.py BaseSubprocessTransport._wait@"))))
        app_chain = tuple(dict.fromkeys(name for name, _, product in named if product))
        cache[number] = (f"{top}:{top_line}", f"{app[0]}:{app[1]}" if app else None, waits, app_chain)
    return ticks, cache, closed[1]


def histogram(ticks, cache, begin, end):
    selected = [(stamp, observations) for stamp, observations in ticks if begin <= stamp < end]
    per_thread = {}
    for _, observations in selected:
        for thread, stack in observations:
            leaf, app, waits, chain = cache[stack]
            counters = per_thread.setdefault(thread, defaultdict(Counter))
            counters["leaf"][leaf] += 1
            if app:
                counters["nearest_product"][app] += 1
            counters["product_ancestry"].update(chain)
            counters["wait_frame_present"].update(waits)
            if chain:
                counters["product_call_chain"][" <- ".join(chain[:4])] += 1
    return {"wall_seconds": round(end - begin, 6), "ticks": len(selected),
            "threads": {str(k): {"samples": v["leaf"].total(),
                                 **{metric: counts.most_common(8) for metric, counts in v.items()}}
                        for k, v in sorted(per_thread.items())}}


def analyze(run):
    lab = run / "lab-observer"
    timing = json.loads((run / "timings.json").read_bytes())
    if not timing["source_verified"] or timing["status"] != "passed":
        raise ValueError("Original journey did not pass source and workload checks")
    roles = {}
    guards = {}
    for role in ("ui", "backend"):
        guard = json.loads(one(lab.glob(role + "-*.json")).read_bytes())
        if not guard["guard_finished"] or guard["blocked_destinations"] or guard["exit_code"] != 0:
            raise ValueError("Original guard did not complete")
        guards[role] = guard
    if guards["backend"]["pid"] not in guards["ui"]["backend_pids"]:
        raise ValueError("Unexpected backend")
    windows = original_windows(guards["ui"]["events"])
    for role, guard in guards.items():
        ticks, cache, cost = read_samples(lab / f"tool-foreground-{role}-{guard['pid']}.jsonl")
        if not ticks or ticks[0][0] > min(v[0] for v in windows.values()) or ticks[-1][0] < max(v[1] for v in windows.values()):
            raise ValueError("Sampler did not cover original windows")
        gaps = [b[0] - a[0] for a, b in zip(ticks, ticks[1:])]
        roles[role] = {"sample_wall_seconds": cost, "total_ticks": len(ticks),
                       "median_tick_spacing_seconds": statistics.median(gaps),
                       "maximum_tick_spacing_seconds": max(gaps),
                       "windows": {k: histogram(ticks, cache, *span) for k, span in windows.items()}}
    return {"qualifying": False, "roles": roles}


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("run", type=Path)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    report = analyze(args.run)
    with args.output.open("x", encoding="utf-8") as stream:
        json.dump(report, stream, indent=2)
        stream.write("\n")
